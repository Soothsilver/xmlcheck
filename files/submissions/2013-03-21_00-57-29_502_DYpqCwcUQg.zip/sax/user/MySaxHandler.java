package user;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 * Sax. Trida vypisuje: 1) pocet serveru, ktere jsou prave online, 2) Ke kazdemu
 * hraci napise na kolika serverech hral, 3) pocet serveru, ktere byli offline
 * alespon 1, nebo meli ping vetsi nez 100ms.
 *
 * @author theodik
 */
public class MySaxHandler extends DefaultHandler {
    public static void main(String[] args) {
        // Cesta ke zdrojovemu XML dokumentu  
        String sourcePath = "data.xml";
        try {
            // Vytvorime instanci parseru.
            XMLReader parser = XMLReaderFactory.createXMLReader();
            // Vytvorime vstupni proud XML dat.
            InputSource source = new InputSource(sourcePath);
            // Nastavime naa vlastni content handler pro obsluhu SAX udalosti.
            parser.setContentHandler(new MySaxHandler());
            // Zpracujeme vstupni proud XML dat.
            parser.parse(source);
        } catch (SAXException e) {
        } catch (IOException e) {
        }
    }
    private final List<DefaultHandler> handlers = new ArrayList<DefaultHandler>(3);

    public MySaxHandler() {
        handlers.add(new OnlineServers());
        handlers.add(new PlayerStats());
        handlers.add(new ServerStats());
    }

    @Override
    public void setDocumentLocator(Locator locator) {
        for (DefaultHandler handler : handlers) {
            handler.setDocumentLocator(locator);
        }
    }

    @Override
    public void startDocument() throws SAXException {
        for (DefaultHandler handler : handlers) {
            handler.startDocument();
        }
    }

    @Override
    public void endDocument() throws SAXException {
        for (DefaultHandler handler : handlers) {
            handler.endDocument();
        }
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        for (DefaultHandler handler : handlers) {
            handler.startElement(uri, localName, qName, attributes);
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        for (DefaultHandler handler : handlers) {
            handler.endElement(uri, localName, qName);
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        for (DefaultHandler handler : handlers) {
            handler.characters(ch, start, length);
        }
    }

    private class MyDefaultHandler extends DefaultHandler {
        protected Locator locator;
        protected final LinkedList<String> path = new LinkedList<String>();

        @Override
        public void setDocumentLocator(Locator locator) {
            this.locator = locator;
        }

        @Override
        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
            path.add(qName);
        }

        @Override
        public void endElement(String uri, String localName, String qName) throws SAXException {
            if (!path.removeLast().equals(qName)) {
                throw new SAXException("Invalid path: " + Arrays.toString(path.toArray()));
            }
        }

        protected boolean inPath(String... nodes) {
            int i = 0;
            for (; i < nodes.length; i++) {
                if (i >= path.size()) {
                    return false;
                }
                if (!nodes[i].equals(path.get(i))) {
                    return false;
                }
            }
            return true;
        }

        protected boolean inExactPath(String... nodes) {
            int i = 0;
            for (; i < nodes.length; i++) {
                if (i >= path.size()) {
                    return false;
                }
                if (!nodes[i].equals(path.get(i))) {
                    return false;
                }
            }
            return i == path.size();
        }
    }

    /**
     * Pocet serveru, ktere jsou prave online.
     */
    private class OnlineServers extends MyDefaultHandler {
        private int serverCount = 0;

        @Override
        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
            super.startElement(uri, localName, qName, attributes);
            if (inPath("servers", "list", "server", "status")) {
                String value = attributes.getValue("online");
                if (value != null && value.equals("1")) {
                    serverCount++;
                }
            }
        }

        @Override
        public void endDocument() throws SAXException {
            System.out.println("Pocet online serveru: " + serverCount);
            System.out.println();
        }
    }

    /**
     * Ke kazdemu hraci napise servery na kterych hral.
     */
    private class PlayerStats extends MyDefaultHandler {
        private boolean inServerName = false;
        private String serverName;
        private boolean inPlayerName = false;
        private Map<String, Set<String>> playerServers = new HashMap<String, Set<String>>();

        @Override
        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
            super.startElement(uri, localName, qName, attributes);
            inServerName = inPath("servers", "list", "server", "name");
            inPlayerName = inPath("servers", "list", "server", "stats", "stat", "players", "player", "name");
        }

        @Override
        public void characters(char[] ch, int start, int length) throws SAXException {
            super.characters(ch, start, length);
            String name = (new String(ch, start, length)).trim();
            if (inServerName) {
                serverName = name;
            }
            if (inPlayerName) {
                Set<String> servers = playerServers.get(name);
                if (servers == null) {
                    servers = new HashSet<String>();
                    playerServers.put(name, servers);
                }
                servers.add(serverName);
            }
        }

        @Override
        public void endDocument() throws SAXException {
            super.endDocument();
            System.out.println("Hraci a jejich servery:");
            for (Map.Entry<String, Set<String>> entry : playerServers.entrySet()) {
                System.out.println(entry.getKey() + ": " + Arrays.toString(entry.getValue().toArray()));
            }
            System.out.println();
        }
    }

    /**
     * Pocet serveru, ktere byli offline alespon 1, nebo meli ping vetsi nez
     * 100ms.
     */
    private class ServerStats extends MyDefaultHandler {
        private int count = 0;
        private int inServer = 0;
        private boolean inPing = false;

        private void incServer() {
            if (inServer > 0) {
                System.err.println("inc: " + locator.getLineNumber());
            }
            count += inServer;
            inServer = 0;
        }

        @Override
        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
            super.startElement(uri, localName, qName, attributes);
            if (inExactPath("servers", "list", "server")) {
                inServer = 1;
            }
            inPing = inPath("servers", "list", "server", "stats", "stat", "ping");
            if (inExactPath("servers", "list", "server", "stats", "stat")) {
                String value = attributes.getValue("online");
                if (value.equals("0")) {
                    incServer();
                }
            }
        }

        @Override
        public void endElement(String uri, String localName, String qName) throws SAXException {
            if (inExactPath("servers", "list", "server")) {
                inServer = 0;
            }
            inPing = inPath("servers", "list", "server", "stats", "stat", "ping");
            super.endElement(uri, localName, qName);
        }

        @Override
        public void characters(char[] ch, int start, int length) throws SAXException {
            super.characters(ch, start, length);
            if (inPing) {
                String text = (new String(ch, start, length)).trim();
                try {
                    int ping = Integer.parseInt(text);
                    if (ping > 100) {
                        incServer();
                    }
                } catch (Exception e) {
                }
            }

        }

        @Override
        public void endDocument() throws SAXException {
            super.endDocument();
            System.out.println("Pocet serveru, ktere byli offline alespon 1, nebo meli ping vetsi nez 100ms: " + count);
        }
    }
}
