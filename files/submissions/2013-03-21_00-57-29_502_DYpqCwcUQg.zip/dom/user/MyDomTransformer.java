package user;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author theodik
 */
public class MyDomTransformer {
    public static void main(String[] args) {
        try {
            // DocumentBuilderFactory creates DOM parsers
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            // We don't want to validate file
            dbf.setValidating(false);
            // Creating of DOM parser instance
            DocumentBuilder builder = dbf.newDocumentBuilder();
            // Parser processes input file and creates a DOM tree of objects
            Document doc = builder.parse("data.xml");
            // DOM tree processing
            new MyDomTransformer().transform(doc);
            // TransformerFactory creates an object for DOM serialization
            TransformerFactory tf = TransformerFactory.newInstance();
            // Transformer serializes DOM tree
            Transformer writer = tf.newTransformer();
            // Setting of output file encoding
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            // Run transformation of DOM tree to XML document
            writer.transform(new DOMSource(doc), new StreamResult(new File("data.out.xml")));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void transform(Document xmlDocument) {
        // smazani serveru s vice jak 2 offline staty
        deleteOfflineServers(xmlDocument);
        // pridani serveru
        addServer(xmlDocument);

    }

    private void deleteOfflineServers(Document xmlDocument) {
        List<Node> removed = new ArrayList<Node>();
        NodeList statsList = xmlDocument.getElementsByTagName("stats");
        for (int i = 0; i < statsList.getLength(); i++) {
            Element stats = (Element) statsList.item(i);
            NodeList statList = stats.getElementsByTagName("stat");
            int offlineCount = 0;
            for (int j = 0; j < statList.getLength(); j++) {
                Element stat = (Element) statList.item(j);
                String online = stat.getAttribute("online");
                if (online == null || online.equals("0")) {
                    offlineCount++;
                }
            }
            if (offlineCount > 2) {
                removed.add(stats.getParentNode());
            }
        }
        Element list = (Element) xmlDocument.getElementsByTagName("list").item(0);
        for (Node node : removed) {
            list.removeChild(node);
        }
    }

    private void addServer(Document xmlDocument) {
        Element server = xmlDocument.createElement("server");
        server.setAttribute("id", "s00");
        server.setAttribute("game-id", getRandomGame(xmlDocument));

        Element elem = xmlDocument.createElement("name");
        elem.setTextContent("Generated server");
        server.appendChild(elem);

        /*
         * <rank>2</rank>
         <host>server1.example.com</host>
         <port>1234</port>
         <query-port>4321</query-port>
         <type>Game</type>
         <status online="1"/>
         <location>&cz;</location>
         */

        elem = xmlDocument.createElement("rank");
        elem.setTextContent("1");
        server.appendChild(elem);

        elem = xmlDocument.createElement("host");
        elem.setTextContent("localhost");
        server.appendChild(elem);

        elem = xmlDocument.createElement("port");
        elem.setTextContent("4321");
        server.appendChild(elem);

        elem = xmlDocument.createElement("query-port");
        elem.setTextContent("4322");
        server.appendChild(elem);

        elem = xmlDocument.createElement("type");
        elem.setTextContent("Game");
        server.appendChild(elem);

        elem = xmlDocument.createElement("status");
        elem.setAttribute("online", "1");
        server.appendChild(elem);

        elem = xmlDocument.createElement("location");
        elem.setTextContent("&cs;");
        server.appendChild(elem);

        elem = xmlDocument.createElement("description");
        elem.setTextContent("Popis");
        server.appendChild(elem);
        /*
         <stats>
         <stat timestamp="123456790" online="0">
         <ping>0</ping>
         <players></players>
         </stat>
         </stats>
         */
        Element stats = xmlDocument.createElement("stats");
        server.appendChild(stats);
        Element stat = xmlDocument.createElement("stat");
        stat.setAttribute("timestamp", "6516964645");
        stat.setAttribute("online", "1");
        stats.appendChild(stat);
        elem = xmlDocument.createElement("ping");
        elem.setTextContent("50");
        stat.appendChild(elem);
        Element players = xmlDocument.createElement("players");
        stat.appendChild(players);
        /*
         <player>
         <name>player1</name>
         <nick>nick1</nick>
         </player>
         */
        for (int i = 0; i < 5; i++) {
            Element player = xmlDocument.createElement("player");
            Element name = xmlDocument.createElement("name");
            name.setTextContent("name"+i);
            player.appendChild(name);
            Element nick = xmlDocument.createElement("nick");
            nick.setTextContent("nick"+i);
            player.appendChild(nick);
            players.appendChild(player);
        }
        Element list = (Element) xmlDocument.getElementsByTagName("list").item(0);
        list.appendChild(server);
    }

    private String getRandomGame(Document xmlDocument) {
        NodeList games = xmlDocument.getElementsByTagName("game");
        int r = (new Random()).nextInt(games.getLength());
        return ((Element) games.item(r)).getAttribute("id");
    }
}