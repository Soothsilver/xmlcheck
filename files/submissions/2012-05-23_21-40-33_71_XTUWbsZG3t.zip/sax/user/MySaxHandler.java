package user; 

import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;

import org.xml.sax.helpers.DefaultHandler;

// vypise nasledujici informace o dokumentu
// - celkovy pocet elementu
// - delka nejdelsiho nazvu elementu
// - delka prumerneho nazvu elementu
public class MySaxHandler extends DefaultHandler { 
// overrides of DefaultHandler methods 
	Locator locator;
	int max = 0;
	int sum = 0;
	int cnt = 0;
public void setDocumentLocator(Locator locator)
{
        this.locator = locator;
}
public void startDocument() throws SAXException {}
public void endDocument() throws SAXException
{
	System.out.printf("%d elements\n%d maximal element name length\n%f average element name length\n", cnt, max, (double)sum/cnt);
}
public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
{
	int len = localName.length();

	if(len > max)
	{
		max = len;
	}

	sum += len;
	++cnt;
}
public void characters(char[] ch, int start, int length) throws SAXException {}
public void startPrefixMapping(String prefix, String uri) throws SAXException {}
public void endPrefixMapping(String prefix) throws SAXException {}
public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {}
public void processingInstruction(String target, String data) throws SAXException {}
public void skippedEntity(String name) throws SAXException {}
}
