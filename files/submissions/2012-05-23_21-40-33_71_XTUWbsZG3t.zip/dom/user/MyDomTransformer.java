package user;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*; 

public class MyDomTransformer { 

// Prevede vsechny atrubuty na elementy - <e attr="val" /> => <e><attr>val</attr></e>
public void transform (Document xmlDocument) { 
// code transforming xmlDocument object 
// (method works on the object itself - no return value) 

	NodeList elems = xmlDocument.getElementsByTagName("*");

	for(int i = 0; i < elems.getLength(); ++i)
	{
		NamedNodeMap attrs = elems.item(i).getAttributes();

		for(int j = 0; j < attrs.getLength(); ++j)
		{
			String attr_name = ((Attr)attrs.item(j)).getName();
			String attr_val = ((Attr)attrs.item(j)).getValue();

			Element new_elem = xmlDocument.createElement(attr_name);
			new_elem.setTextContent(attr_val);

			elems.item(i).appendChild(new_elem);
			((Element)elems.item(i)).removeAttribute(attr_name);
		}
	}
} 

}
