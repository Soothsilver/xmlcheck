package user;

import java.util.Random;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
public class MyDomTransformer {
    
    public void transform(Document xmlDocument) {
        // Pridavani noveho uzivatele
        Random ran = new Random();
        Element users = (Element) xmlDocument.getElementsByTagName("seznam_uzivatelu").item(0);
        Element newUser = xmlDocument.createElement("uzivatel");
        newUser.appendChild(xmlDocument.createElement("username")).setTextContent("kolla");
        newUser.appendChild(xmlDocument.createElement("popis")).setTextContent("student");
        newUser.setAttribute("id", "u00"+(100+ran.nextInt(10000)));
        users.appendChild(newUser);
        
               
        //Smazani vsech recenzi s hodnocenim < 4.0
        NodeList  reviews = xmlDocument.getElementsByTagName("recenze");
        for (int i = 0; i < reviews.getLength(); i++) {
            Element review = (Element) reviews.item(i);
            Element value = (Element) review.getElementsByTagName("hodnoceni").item(0);
            double vd = Double.parseDouble(value.getTextContent().trim());
            if (vd < 4.0) {
                review.getParentNode().removeChild(review);
            }
        }
        
    }
}
