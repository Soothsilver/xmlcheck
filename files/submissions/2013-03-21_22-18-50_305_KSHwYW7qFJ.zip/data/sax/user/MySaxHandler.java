
package user;

import java.util.LinkedList;
import java.util.List;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
    int countOfSmokePlaces = 0;
    
    List<MySaxHandler.Review> reviewList = new LinkedList();
    MySaxHandler.Review current;
    boolean reviewFlag = false;
    boolean reviewValueFlag = false;
    boolean reviewCommentFlag = false;
    
    List<MySaxHandler.Restaurant> restList = new LinkedList();
    boolean restFlag = false;
    boolean restTagFlag = false;
    boolean restNameFlag = false;
    MySaxHandler.Restaurant currentRest = null;
    
    @Override
    public void startDocument() throws SAXException {       
    }
    
    @Override
    public void endDocument() throws SAXException {
        double stredniHodnoceni = 0.0;        
        for (MySaxHandler.Review r : reviewList){
            stredniHodnoceni+=r.value;            
        }
        stredniHodnoceni /= reviewList.size();
        System.out.println("SAX - 1: prace s hodnoty atributu");
        System.out.println("Pocet restauraci pro kuraky: "+countOfSmokePlaces); 
        System.out.println("SAX - 2: prace s obsahem elementu");
        System.out.println("Stredni hodnoceni vsech recenzi: "+ stredniHodnoceni);
        System.out.println("SAX - 3: prace s kontextem");
        System.out.println("Seznam restauraci, ktere maji vice nez 1 adresu, a jsou kavarny:");
        for (MySaxHandler.Restaurant r : restList){
            boolean kavarna = false;
            for (String t : r.tags) {
                if (t.equals("kavarna")) {
                    kavarna = true;
                }
            }
            if (r.countOfPlaces > 1 && kavarna){
                System.out.println("Nazev: "+r.name +", pocet adres: "+r.countOfPlaces);
            }
        }
        
        
    }
    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes)
    throws SAXException {            
        if (qName.equals("kontakt")){            
            if (restFlag) {
                currentRest.countOfPlaces++;
            }
            if (attributes.getValue("koureni").equals("kuraci_a_nekuraci") || 
                   attributes.getValue("koureni").equals("kuraci"))
                countOfSmokePlaces++;
            
           
        } else if (qName.equals("recenze")){
            current = new MySaxHandler.Review();
            reviewFlag = true;
        } else if (reviewFlag && qName.equals("hodnoceni")){
            reviewValueFlag = true;
        } else if (reviewFlag && qName.equals("komentar")){
            reviewCommentFlag = true;
        } else if (qName.equals("restaurace")){
            currentRest = new MySaxHandler.Restaurant();
            restFlag = true;
        } else if (restFlag && qName.equals("tag")){
            restTagFlag = true;
        } else if (restFlag && qName.equals("nazev")){
            restNameFlag = true;
        }

       
    }

    @Override
    public void endElement(String uri, String localName, String qName){
        if (qName.equals("recenze")){
            reviewList.add(current);
            current = null;
            reviewFlag = false;
            
        } else if (reviewFlag && qName.equals("hodnoceni")){
            reviewValueFlag = false;
        } else if (reviewFlag && qName.equals("komentar")){
            reviewCommentFlag = false;
        } else if (qName.equals("restaurace")){
            restList.add(currentRest);
            currentRest = null;
            restFlag = false;
        } else if (restFlag && qName.equals("tag")){
            restTagFlag = false;
        } else if (restFlag && qName.equals("nazev")){
            restNameFlag = false;
        }    
        
    }

    @Override
    public void characters(char ch[], int start, int length) throws SAXException {
        if (reviewFlag && reviewValueFlag){
            current.value = Double.parseDouble(new String(ch, start, length));
        } else if (reviewFlag && reviewCommentFlag) {
            current.comment = new String(ch, start, length);
        } else if (restFlag && restTagFlag){
            currentRest.tags.add(new String(ch, start, length));
        } else if (restFlag && restNameFlag) {
            currentRest.name = new String(ch, start, length).trim();
        }
    }
    class Review {
        Double value;
        String comment;
    }
    class Restaurant {
        String name;
        int countOfPlaces;
        List<String> tags;
        Restaurant(){
            tags = new LinkedList();
        }        
    }
}
