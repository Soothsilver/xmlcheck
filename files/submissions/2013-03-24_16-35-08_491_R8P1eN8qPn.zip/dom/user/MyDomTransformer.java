/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;  
import org.w3c.dom.Attr;  
import org.w3c.dom.Text; 
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.dom.DOMSource;


public class MyDomTransformer {

     public static void main(String argv[]) {

        /*
	File fXmlFile = new File("data.xml");
	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	Document doc = dBuilder.parse(fXmlFile);
        */
     }
        public void transform(Document xmlDocument){
                    try {
        Document doc = xmlDocument;
	doc.getDocumentElement().normalize();
        
        
        Element novyStudent = doc.createElement("student");  
        Element novaOsoba = doc.createElement("osoba");
        novaOsoba.setAttribute("id", "o" + (System.currentTimeMillis() / 1000L));
        Element meno = doc.createElement("krstneMeno");
        Element priezvisko = doc.createElement("priezvisko");
        Text menoVal = doc.createTextNode("Kleofas");
        Text priezviskoVal = doc.createTextNode("Veleznaly");
        meno.appendChild(menoVal);
        priezvisko.appendChild(priezviskoVal);
        novaOsoba.appendChild(meno);
        novaOsoba.appendChild(priezvisko);
        novyStudent.appendChild(novaOsoba);
        
        Element stavStudia = doc.createElement("stavStudia");
        stavStudia.setAttribute("ziskaneKredity", "0");
        stavStudia.setAttribute("rocnik", "1");
        novyStudent.appendChild(stavStudia);
        
        Element d = doc.getDocumentElement();
        Node studenti = d.getElementsByTagName("studenti").item(0);
        studenti.appendChild(novyStudent);
        
        NodeList stavy = d.getElementsByTagName("stavStudia");
        for(int i = 0; i < stavy.getLength(); i++){
            Node studium = stavy.item(i);
            //String s1 = student.getNodeValue();
            //String s = studium.getAttributes().item(0).getNodeName();
            int kredity = 
                    Integer.parseInt(studium.getAttributes().getNamedItem("ziskaneKredity").getNodeValue());
            int rocnik =
                    Integer.parseInt(studium.getAttributes().getNamedItem("rocnik").getNodeValue());
            if(rocnik > 1 && (kredity / (rocnik - 1) < 45))
                    studenti.removeChild(studium.getParentNode());
        }
        }
        //Transformer transformer = TransformerFactory.newInstance().newTransformer();
        //Result output = new StreamResult(new File("data.xml"));
        //Source input = new DOMSource(doc);

        //transformer.transform(input, output);

   catch (Exception e) {
	e.printStackTrace();
    }
  }
}
