package user;

import java.util.Collection;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Set;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.helpers.DefaultHandler;


public class MySaxHandler extends DefaultHandler {

    private static final String INPUT_FILE = "data.xml";



    int zapocet = 0, predmety = 0, druhaci_na_analyze = 0, year; 
    boolean ma_zapocet = false, inside_student_element = false, inside_name_element = false;
    boolean tretiSemester = false;
    String name;
    
    StringBuffer element_content;
    
    Hashtable<String,Integer> names = new Hashtable<String,Integer>();
    
    @Override
    public void startDocument() throws SAXException {
    }

    @Override
    public void endDocument() throws SAXException {
        System.out.println("Zapocet vyzaduje " + zapocet + " predmetov z " +  predmety);
        
        int max = 0, act;
        String max_name = "";
        
        Enumeration keys = names.keys(); 
        while(keys.hasMoreElements()) { 
            String str = (String) keys.nextElement(); 
            act = names.get(str);
            if(act > max)
                max_name = str;
        } 
        
        System.out.println("Najcastejsie meno studnetov je \"" + max_name + "\"");
        
        System.out.println("Pocet studentov, ktori si v tretom semestri zapisali Matematicku analyzu I: " 
                + druhaci_na_analyze);
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        if(qName.equals("predmet"))
        {
            ++predmety;
            
            for(int i = 0; i < attributes.getLength(); ++i)
            {
                if(attributes.getQName(i).equals("zapocet"))
                {
                    String tmp = attributes.getValue(i);
                    if(tmp.equals("Z"))
                        ma_zapocet = true;
                }
            }
        }
        
        if(qName.equals("semesterStudia"))
        {
            for(int i = 0; i < attributes.getLength(); ++i)
            {
                if(attributes.getQName(i).equals("poradoveCislo"))
                {
                    String tmp = attributes.getValue(i);
                    if(tmp.equals("3"))
                        tretiSemester = true;
                }
            }
        }
        
        if(qName.equals("zapisanyPredmet") && tretiSemester){
            for(int i = 0; i < attributes.getLength(); ++i)
            {
                if(attributes.getQName(i).equals("id"))
                {
                    String tmp = attributes.getValue(i);
                    if(tmp.equals("p2"))
                        druhaci_na_analyze++;
                }
            }
        }
        
        if(qName.equals("krstneMeno"))
        {
            inside_name_element = true;
            element_content = new StringBuffer();
        }
        
        if(qName.equals("student"))
        {
            inside_student_element = true;
            element_content = new StringBuffer();
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName)
    throws SAXException {
        if(qName.equals("predmet"))
        {
            if(ma_zapocet) zapocet++;
            ma_zapocet = false;
        }
        
        if(qName.equals("student")){
            inside_student_element = false;
        }
        
        if(qName.equals("semesterStudia")){
            tretiSemester = false;
        }
        
        
        if(qName.equals("rok"))
        {
            //inside_year_element = false;
            year = Integer.parseInt(element_content.toString());
        }
        
        if(qName.equals("krstneMeno"))
        {
            inside_name_element = false;
            if(inside_student_element){
                name = element_content.toString();
                
                if(names.containsKey(name))
                {
                    int tmp = names.get(name);
                    names.put(name, tmp + 1);
                }
                else
                {
                    names.put(name, 1);
                }
            }
            
        }
    }

    @Override
    public void characters(char ch[], int start, int length)
    throws SAXException {
        if(inside_name_element || inside_student_element)
        {
            element_content.append(ch, start, length);
        }
    }
}