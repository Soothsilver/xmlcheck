package user;

import org.w3c.dom.*;

public class MyDomTransformer {
  
  public void transform(Document xmlDocument) {
        NodeList zamestnanci = xmlDocument.getElementsByTagName("zamestnanec");
        for (int i = 0; i < zamestnanci.getLength(); i++) {
            Element zam = (Element) zamestnanci.item(i);
            Attr jmeno = zam.getAttributeNode("jmeno");
            Attr prijmeni = zam.getAttributeNode("prijmeni");
            Attr funkce = zam.getAttributeNode("funkce");
            Element jmenoprijmeni = xmlDocument.createElement("jmenoprijmeni");
            if (jmeno != null && prijmeni != null){
            jmenoprijmeni.setTextContent(jmeno.getTextContent() + " " + prijmeni.getTextContent());
            zam.appendChild(jmenoprijmeni);
            }
            
            if (funkce != null){
                Element novafunkce = xmlDocument.createElement("funkce");
                novafunkce.setTextContent(funkce.getTextContent());
                zam.appendChild(novafunkce);
            } 

            zam.setAttribute("plat", "15000");
            zam.removeAttribute("jmeno");
            zam.removeAttribute("prijmeni");
            zam.removeAttribute("funkce");
                       
        }
  }  
}
