package user;

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;
import java.util.*;

public class MySaxHandler extends DefaultHandler {
   // override metod DefaultHandleru
  
  HashMap<String, ArrayList<String>> hmap = new HashMap<String, ArrayList<String>>();
  
  public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
    if (localName == "zamestnanec"){
            String jmeno = "",prijmeni = "",funkce = "";
            for (int i = 0; i < atts.getLength (); i++ ) {
                if (atts.getQName(i) == "jmeno") jmeno = atts.getValue (i);
                if (atts.getQName(i) == "prijmeni") prijmeni = atts.getValue (i);
                if (atts.getQName(i) == "funkce") funkce = atts.getValue (i);
            }   
            if (funkce != "") {
                ArrayList<String> al =  hmap.get(funkce);
                if (al == null) {
                    al = new ArrayList<String>();
                    al.add(jmeno+" "+prijmeni);
                    hmap.put(funkce, al);
                } else
                {
                    al.add(jmeno+" "+prijmeni);                    
                }
            }
        }
  }

  public void endDocument() throws SAXException {
    Iterator iterator = hmap.keySet().iterator();
        
        while(iterator. hasNext()){  
            String funkce = (String) iterator.next();
            System.out.println(funkce.toUpperCase());
            System.out.println();
            ArrayList<String> al =  hmap.get(funkce);
                 for (int i=0; i < al.size(); i++)
                    System.out.println(al.get(i));
            System.out.println();
        }              
  }
}
