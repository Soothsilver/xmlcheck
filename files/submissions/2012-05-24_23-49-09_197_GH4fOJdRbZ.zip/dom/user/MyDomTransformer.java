package user;

import java.util.ArrayList;
import java.util.Collections;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Tato DOM transformace prevede vsechny podelementy Prijmeni a Jmeno na jeden textovy uzel s
 * obsahem textu puvodnich elementu. Nasledne elementy Uzivatel seradi podle nove vytvoreneho uzlu.
 * @author Jakub Dubeda
 */

public class MyDomTransformer {
    public void transform (Document xmlDocument) {
        ArrayList<Element> seznam = new <Element>ArrayList();
        ArrayList<String> seznamJmen = new <String>ArrayList();
        NodeList list = xmlDocument.getElementsByTagName("uzivatele");
        Element e = (Element) list.item(0);
        if (e.hasChildNodes()) {
            NodeList childNodes = e.getChildNodes();
            for (int i = 0; i < childNodes.getLength(); i++) {
                Node item = childNodes.item(i);
                if (item.getNodeType() == Element.ELEMENT_NODE) {
                    seznam.add((Element)item);
                    e.removeChild(item);
                }
            }
        }
        
        for (int i = 0; i < seznam.size(); i++) {
            Element element = seznam.get(i);
            NodeList l;
            l = element.getElementsByTagName("krestni");
            Element krestni = (Element) l.item(0);
            l = element.getElementsByTagName("prijmeni");
            Element prijmeni = (Element) l.item(0);
            l = element.getElementsByTagName("jmeno");
            Element jmeno = (Element) l.item(0);
            jmeno.removeChild(krestni);
            jmeno.removeChild(prijmeni);
            
            Node krestniTextNode = krestni.getChildNodes().item(0);
            Node prijmeniTextNode = prijmeni.getChildNodes().item(0);
            
            // Trim odstrani zbytecne whitespaces
            String newJmeno = prijmeniTextNode.getNodeValue().trim()+" "+krestniTextNode.getNodeValue().trim();
            Node textNode = xmlDocument.createTextNode(newJmeno);
            jmeno.appendChild(textNode);
            seznamJmen.add(newJmeno);
        }
        
        // Zde setrizeni
        Collections.sort(seznamJmen);
        for (String s : seznamJmen) {
            for (Element element : seznam) {
                NodeList nl = element.getElementsByTagName("jmeno");
                Element el = (Element) nl.item(0);
                nl = el.getChildNodes();
                String nodeValue = "";
                for (int i = 0; i < nl.getLength(); i++) {
                    nodeValue = nl.item(i).getNodeValue().trim();
                    if (nodeValue.length() != 0) {
                        break;
                    }
                }
                if(nodeValue.equals(s)) e.appendChild(element);
            }
        }
    }
}
