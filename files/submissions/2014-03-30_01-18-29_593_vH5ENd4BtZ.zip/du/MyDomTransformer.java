package user;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;
import java.util.ArrayList;
import java.util.Random;

public class MyDomTransformer {
public void transform (Document xmlDocument) {
    // Transformace 1: nastavi price-class podle materialu ramu
    NodeList frames = xmlDocument.getElementsByTagName("frame-material");
    for (int i = frames.getLength() - 1; i >= 0; i--) {
        Element frame = (Element) frames.item(i);
        Element bike = (Element) frame.getParentNode();
        if ("Carbon".equals(frame.getTextContent())) {
            bike.setAttribute("price-class", "A");
        }
        else {
            bike.setAttribute("price-class", "D");
        }
    }
    
    // Transformace 2: pridani noveho kola se vsemi parametry
    Random rand = new Random();
    String bikeID = "b_" + Math.abs(rand.nextInt());
    while (xmlDocument.getElementById(bikeID) != null)
    {
        bikeID= "b_" + Math.abs(rand.nextInt());
    }

    Element newBike = xmlDocument.createElement("bike");
    newBike.setAttribute("type", "MTB");
    newBike.setAttribute("bik_ID", bikeID);
    newBike.setAttribute("price-class", "B");
    newBike.appendChild(xmlDocument.createElement("gender")).setTextContent("male");
    Element man = (Element) newBike.appendChild(xmlDocument.createElement("manufacturer"));
    man.setAttribute("company", "Canyon");
    newBike.appendChild(xmlDocument.createElement("model")).setTextContent("GRAND CANYON CF SLX 9.9 TEAM");
    newBike.appendChild(xmlDocument.createElement("size")).setTextContent("19");
    newBike.appendChild(xmlDocument.createElement("wheelsize")).setTextContent("29");
    Element c = (Element) newBike.appendChild(xmlDocument.createElement("components"));
    Element set = (Element) c.appendChild(xmlDocument.createElement("set"));
    set.appendChild(xmlDocument.createElement("derailleur")).setTextContent("sram XX");
    set.appendChild(xmlDocument.createElement("levers")).setTextContent("avid XX");
    set.appendChild(xmlDocument.createElement("brakes")).setTextContent("avid XX");
    c.appendChild(xmlDocument.createElement("wheels")).setTextContent("DT Swiss XR 1450 90 Spline");
    c.appendChild(xmlDocument.createElement("fork")).setTextContent("RockShox SID 29 XX World Cup");
    newBike.appendChild(xmlDocument.createElement("color")).setTextContent("team replica");
    newBike.appendChild(xmlDocument.createElement("problems"));
    newBike.appendChild(xmlDocument.createElement("frame-material")).setTextContent("Carbon");
    xmlDocument.getElementsByTagName("bikes").item(0).appendChild(newBike);
  }
} */