package user;

import static java.lang.Integer.parseInt;
import java.util.ArrayList;
import java.util.LinkedList;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

public class MySaxHandler extends DefaultHandler {
    /**
     * Method to handle "document start"
     *
     * @throws SAXException
     */

    private ArrayList<Integer> sizes;
    private LinkedList<String> path;
    private int cntMtb;
    private int cntFix;
    private int cntStreet;
    private int cntNiner;
    private int cntSix;
    private String curType;
    private int wheelsize; 
    private int s;

    /**
     * Method to handle "document start"
     *
     * @throws SAXException
     */
    @Override
    public void startDocument() throws SAXException {
        path = new LinkedList<>();
        wheelsize=0; s=0;
        
        // budeme pocitat nejcastejsi typ kol (hodnota atributu)
        cntMtb = 0; cntFix=0; cntStreet = 0;
        
        // budeme pocitat nejcastejsi rozmer kol u MTB
        cntNiner = 0; cntSix = 0;
        
        //budeme pocitat prumernou velikost kol
        sizes = new ArrayList<>();
    }

    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
        if (cntMtb > cntFix && cntMtb > cntStreet)
            System.out.println("The most common type is MTB");
        else {
            if(cntStreet > cntMtb && cntStreet > cntFix)
                System.out.println("The most common type is street bike");
            else 
                System.out.println("The most common type is fixie");
        }
        if (cntNiner > cntSix) 
            System.out.println("The most common wheelsize for MTB is 29");
        else
        {
           if (cntSix > cntNiner)
               System.out.println("The most common wheelsize for MTB is 26");
           else
               System.out.println("Both MTB wheelsizes are equally common");
        }
        
        int sum = 0;
        for (int i = sizes.size() -1; i >=0; i--) {
            sum += sizes.get(i);
        }
        sum /= sizes.size();
        System.out.println("The average size is " + sum);
    }

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        path.push(qName);
        if ("bike".equals(qName)) {
            curType = atts.getValue("type");
            if ("MTB".equals(curType)) {
                cntMtb++;
            }
            if ("street".equals(curType)) {
                cntStreet++;
            }
            if ("fixie".equals(curType)) {
                cntFix++;
            }
        }
        if ("wheelsize".equals(qName)) {
            wheelsize++;
        }
        if ("size".equals(qName)) {
            s++;
        }
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        path.pop();
        if ("wheelsize".equals(qName)) {
            wheelsize--;
        }
         if ("size".equals(qName)) {
            s--;
        }
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        if (wheelsize > 0) {
            int size = parseInt(new String(chars, start, length));
            if ("MTB".equals(curType)) {
                if (size == 29)
                    cntNiner++;
                else
                    cntSix++;  
            }
        }
        if (s > 0) {
            int size = parseInt(new String(chars, start, length));
            sizes.add(size);
        }
    }

    /**
     * Method to handle " start of namespace declaration"
     *
     * @param prefix Prefix of the namespace
     * @param uri URI of the namespace
     * @throws SAXException
     */
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    /**
     * Method to handle "end of namespace declaration"
     *
     * @param prefix
     * @throws SAXException
     */
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    /**
     * Method to handle "ignoring of whitespaces" Text is in array 'chars' from
     * position ('start') to ('start' + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     * @throws SAXException
     */
    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
        // ...
    }

    /**
     * Method to handle "processing instructions"
     *
     * @param target The processing instruction target
     * @param data  The processing instruction data
     * @throws SAXException
     */
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

    /**
     * Method to handle "unprocessed entity"
     *
     * @param name
     * @throws SAXException
     */
    @Override
    public void skippedEntity(String name) throws SAXException {
        // ...
    }
}