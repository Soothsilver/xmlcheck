package user;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

public class MyDomTransformer {

    private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "data.out.xml";

    public static void main(String[] args) {
        
        try {
            
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            dbf.setValidating(false);

            DocumentBuilder builder = dbf.newDocumentBuilder();

            Document doc = builder.parse(VSTUPNI_SOUBOR);

            processTree(doc);

            TransformerFactory tf = TransformerFactory.newInstance();

            Transformer writer = tf.newTransformer();

            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


        } catch (Exception e) {
            
            e.printStackTrace();
            
        }
    }


    
    //funkce pro zjisteni hostname podle id_prostredi
    private static Node getHostnameByIdProstredi(Document doc, String hledaneIdProstredi) {

       NodeList seznamProstredi = doc.getElementsByTagName("prostredi");
       
       Node prostredi = null;
       
       for (int i = 0; i < seznamProstredi.getLength(); i++) {
          String idProstredi = seznamProstredi.item(i).getAttributes().getNamedItem("id_prostredi").getNodeValue();

          if ((idProstredi != null) && (idProstredi.contentEquals(hledaneIdProstredi))) {
             prostredi = seznamProstredi.item(i);
          }
       }
       
       if (prostredi == null) {
          return null;
       }
       
       Node hostName = null;
       NodeList seznamElementuVProstredi = prostredi.getChildNodes(); 
       
       for (int i = 0; i < seznamElementuVProstredi.getLength(); i++) {
          String tagName = seznamElementuVProstredi.item(i).getNodeName();

          if ((tagName != null) && (tagName.contentEquals("hostname"))) {
             hostName = seznamElementuVProstredi.item(i);
          }
       }
       
       return hostName;
    }
    
    /**
     * Zpracuje DOM strom
     */
    public void transform(Document doc) {
       processTree(doc);
    }
    
    /**
     * Zpracuje DOM strom
     */
    private static void processTree(Document doc) {
        
       
       
       NodeList jobs = doc.getElementsByTagName("job");

       // u jobu zmenit atribut aktivni na element - pokud ma atribut hodnotu ANO, tak na element job_aktivni, jinak job_neaktivni
       for (int i = 0; i < jobs.getLength(); i++) {
          String jobAktivni = jobs.item(i).getAttributes().getNamedItem("aktivni").getTextContent();
          
          Element jobAktivniElement = null;
          if (jobAktivni.contentEquals("ANO")) {
             jobAktivniElement = doc.createElement("job_aktivni");
          } else {
             jobAktivniElement = doc.createElement("job_neaktivni");
          }
          
          jobs.item(i).appendChild(jobAktivniElement);
          
          jobs.item(i).getAttributes().removeNamedItem("aktivni");         
         }
        
       
       // u jobu odstranit seznam kroku
       for (int i = 0; i < jobs.getLength(); i++) {
          
          Node seznamKroku = null;
          
          // najdi seznam_kroku pod aktualnim jobem
          for (int j = 0; j < jobs.item(i).getChildNodes().getLength(); j++) {

             String localName = jobs.item(i).getChildNodes().item(j).getNodeName();

             if ((localName != null) &&  (localName.contentEquals("seznam_kroku"))) {
                seznamKroku = jobs.item(i).getChildNodes().item(j);
             }
          }
          
          if (seznamKroku != null) {
             jobs.item(i).removeChild(seznamKroku);
          }
             
       }

       
       // processing instruction premistit do XML jako element
       NodeList documentChildren = doc.getChildNodes();
       
       for (int i = 0; i < documentChildren.getLength(); i++) {
          
          Element processingInstructionElement = null;

          if (documentChildren.item(i) instanceof ProcessingInstruction) {
             String processingInstructionValue = documentChildren.item(i).toString();
             
             processingInstructionElement = doc.createElement("processing_instruction");
             processingInstructionElement.appendChild(doc.createTextNode(processingInstructionValue));
             
             doc.getElementsByTagName("prehled_ETL").item(0).appendChild(processingInstructionElement);
          }
       }
       

       
       // k informaci o nainstalovanem jobu na prostredi pridat hostname daneho prostredi - naklonuju element hostname ze seznamu prostredi
       NodeList installedJobs = doc.getElementsByTagName("nainstalovane_prostredi");

       for (int i = 0; i < installedJobs.getLength(); i++) {

          String idProstredi = installedJobs.item(i).getAttributes().getNamedItem("id_prostredi").getTextContent();
          
          Node hostName = getHostnameByIdProstredi(doc, idProstredi);

          if (hostName != null) {
             installedJobs.item(i).appendChild(hostName).cloneNode(true);
          }
       }
       
          
    }
}

