package user;

import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.helpers.DefaultHandler; 
import org.xml.sax.Attributes;
import java.lang.String;
import java.util.HashMap;

public class MySaxHandler extends DefaultHandler {

	
	
    public static void main(String[] args) {

        String sourcePath = "data.xml";

        try {
            
            XMLReader parser = XMLReaderFactory.createXMLReader();
            
            InputSource source = new InputSource(sourcePath);
            
            parser.setContentHandler(new MujContentHandler());
            
            parser.parse(source);
            
        } catch (Exception e) {
        
            e.printStackTrace();
            
        }
        
    }
    
}


class jobHandler {
   private static Integer countOfStatements = 0;
   private static Integer countOfJobs = 0;
   
   private static String longestJobId = "";
   private static Integer longestJobCount = 0;
   
   private static String currentJobId = "";
   private static Integer currentJobCount = 0;

   
   public static void jobTag(String jobId) {
      countOfJobs++;
      
      // dalsi job
      if (jobId.contentEquals(currentJobId) == false) {
         
         // novy job je delsi
         if (currentJobCount > longestJobCount) {
            longestJobId = currentJobId;
            longestJobCount = currentJobCount;
         }
         
         
         currentJobId = jobId;
         currentJobCount = 0;
      }
      
   }
   
   public static void stepTag() {
      countOfStatements++;
      currentJobCount++;
   }
   
   public static Integer getCountOfStatements() {
      return countOfStatements;
   }
   
   public static Integer getCountOfJobs() {
      return countOfJobs;
   }
   
   public static String getIdOfLongestJob() {
      return longestJobId;
   }

   public static Integer getCountOfLongestJob() {
      return longestJobCount;
   }
   
}


class tagHandler {
   private static Integer countTags = 0;
   private static Integer countTagsWithAttributes = 0;
   
   private static Integer sumDepth = 0;
   private static HashMap<String, Integer> countPerTagname = new HashMap<String, Integer>();
   
   public static void processTag(String tagName, Integer depth, Attributes atts) {
      
      countTags++;
      sumDepth += depth;
      
      if(countPerTagname.containsKey(tagName)) {
         Integer previousCount = countPerTagname.get(tagName).intValue();
         countPerTagname.put(tagName, previousCount + 1);
      } else {
         countPerTagname.put(tagName, 1);
      }
      
      if (atts.getLength() > 0) {
         countTagsWithAttributes++;
      }
      

   }
   
   
   public static Integer getCountTags () {
      return countTags;
   }
   
   public static Integer getSumDepth () {
      return sumDepth;
   }
   
   public static Integer getCountTagsWithAttributes () {
      return countTagsWithAttributes;
   }

   
   public static void printTagCounts () {
      
      for (String entryKey : (countPerTagname.keySet())) {
         System.out.println ("Tag \"" + entryKey + "\" se vyskytuje " + countPerTagname.get(entryKey) + "x.");
         
      }
   }

}


class MujContentHandler implements ContentHandler {

	Integer elementDepth = 0;
	
	void indent(int x) {
		System.out.println();
		for (int i=0; i<x; i++)
			System.out.print('\t');
	}
	
	
    Locator locator;
    
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    public void startDocument() throws SAXException {
    }

    
    
    public void endDocument() throws SAXException {
       
       System.out.println("Statistiky z obsahu: ");
       System.out.println("Prumerny pocet kroku v jobu: " + jobHandler.getCountOfStatements()/jobHandler.getCountOfJobs());
       
       
       jobHandler.jobTag("");
       
       
       System.out.println("Nejdelsi job: " + jobHandler.getIdOfLongestJob() + " ma " + jobHandler.getCountOfLongestJob() + " kroku.");
        // ...
        
       System.out.println();
       System.out.println("Statistiky XML dokumentu: ");
       
       System.out.println("Pocet tagu: " + tagHandler.getCountTags());
       System.out.println("Pocet tagu s atributy: " + tagHandler.getCountTagsWithAttributes());
       System.out.println("Zanoreni celkem: " + tagHandler.getSumDepth());
       System.out.println("Prumerne zanoreni: " + tagHandler.getSumDepth() / tagHandler.getCountTags());
       
       System.out.println();
       System.out.println("Pocty jednotlivych tagu: ");
       tagHandler.printTagCounts();
    }
    

    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
    	
       
      tagHandler.processTag(localName, elementDepth, atts); 
       
      if (localName.contentEquals("job"))
      {
         String jobId = atts.getValue(atts.getIndex("id_jobu"));
         jobHandler.jobTag(jobId);
      }

      if (localName.contentEquals("krok"))
      {
         jobHandler.stepTag();
      }
    
      elementDepth++;
    }

    
    public void endElement(String uri, String localName, String qName) throws SAXException {
       elementDepth--;
    }
    
    public void characters(char[] ch, int start, int length) throws SAXException {
    }
    
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
    }

    public void endPrefixMapping(String prefix) throws SAXException {
    }

    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
    }

    public void processingInstruction(String target, String data) throws SAXException {
    }

    public void skippedEntity(String name) throws SAXException {
    }
}