/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.StringTokenizer;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author j
 */
public class MyDomTransformer {
    public void transform (Document xmlDocument) {
        deleteEmployeesWithoutValidContract(xmlDocument);
        createNewClient(xmlDocument);
    }

    private void deleteEmployeesWithoutValidContract(Document xmlDocument) {
        NodeList employees = xmlDocument.getElementsByTagName("zamestnanec");
        List<Node> toErase = new ArrayList<Node>();
        findEmployeesContracts(employees, toErase);
        deleteCorruptedNodes(toErase);
    }

    /**
     * Creates new client with default values.
     * @param xmlDocument 
     */
    private void createNewClient(Document xmlDocument) {
        NodeList clients = xmlDocument.getElementsByTagName("klient"); 
        Node client = clients.item(clients.getLength() - 1);
        String id = client.getAttributes().getNamedItem("id").getTextContent();
        String newId = parseId(id);
        Node clientList = client.getParentNode();
        addNewDefaultClientNode(clientList, xmlDocument, newId);
    }

    /**
     * Parse textContent as date in dd/MM/yyyy format and matches it with
     * current date.
     * @param textContent
     * @return true, if today is before parsed date
     */
    private boolean isContractDateStillValid(String textContent) {
        Date today = new Date(System.currentTimeMillis());
        StringTokenizer st = new StringTokenizer(textContent, "/");
        String token = "";
        Integer j = 0;
        int[] date = new int[3];
        for (int i = 0; st.hasMoreTokens() && i < 3; i++) {
            token = st.nextToken();
            j = Integer.parseInt(token);
            date[i] = j;
        }
        return today.before(new Date(date[2] - 1900, date[1] - 1, date[0]));
    }

    /**
     * Find employees without valid contracts.
     * je to hruza, ale nevim jakym lepsim zpusobem se k tomu dostat :-((( 
     * @param employees
     * @param toErase 
     */
    private void findEmployeesContracts(NodeList employees, List<Node> toErase) {
        for (int i = 0; i < employees.getLength(); i++) {
            Node empl = employees.item(i);
            NodeList emplChilds = empl.getChildNodes();
            for (int j = 0; j < emplChilds.getLength(); j++) {
                Node child = emplChilds.item(j);
                if(child.getNodeName().equals("karta")){
                    NodeList karta = child.getChildNodes();
                    for (int k = 0; k < karta.getLength(); k++) {
                        Node platnost = karta.item(k);
                        if(platnost.getNodeName().equals("platnost")) {
                            if (!isContractDateStillValid(platnost.getTextContent())) {
                                toErase.add(empl);
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Erase certain nodes from document tree.
     * @param toErase
     * @throws DOMException 
     */
    private void deleteCorruptedNodes(List<Node> toErase) throws DOMException {
        for (int i = toErase.size() - 1; i >= 0; i--) {
            Node n = toErase.get(i);
            Node parentNode = n.getParentNode();
            toErase.remove(n);
            parentNode.removeChild(n);
        }
    }

    /**
     * Parses id in format %c*_[0-9]* and adds 1 to it.
     * @param id
     * @return 
     */
    private String parseId(String id) {
        String[] split = id.split("_");
        int i = Integer.parseInt(split[1]);
        return "k_" + ++i;
    }

    /**
     * Add new client element with default values to document tree.
     * @param clientList
     * @param xmlDocument
     * @param newId
     * @throws DOMException 
     */
    private void addNewDefaultClientNode(Node clientList, Document xmlDocument, String newId) throws DOMException {
        Element newClient = (Element) clientList.appendChild(xmlDocument.createElement("klient"));
        newClient.setAttribute("id", newId);
        newClient.appendChild(xmlDocument.createElement("jmeno")).setTextContent("Nova Osoba");
        newClient.appendChild(xmlDocument.createElement("rc")).setTextContent("000000/000");
        Element contact = (Element) newClient.appendChild(xmlDocument.createElement("kontakt"));
        Element adress = (Element) contact.appendChild(xmlDocument.createElement("adresa"));
        adress.appendChild(xmlDocument.createElement("ulice")).setTextContent("Ulice");
        adress.appendChild(xmlDocument.createElement("cp")).setTextContent("12343");
        adress.appendChild(xmlDocument.createElement("mesto")).setTextContent("Mesto");
        adress.appendChild(xmlDocument.createElement("psc")).setTextContent("34563");
        contact.appendChild(xmlDocument.createElement("telefon")).setTextContent("1234565");
        newClient.appendChild(xmlDocument.createElement("role")).setTextContent("klient");
        Element card = (Element) newClient.appendChild(xmlDocument.createElement("karta"));
        Date today = new Date(System.currentTimeMillis());
        card.appendChild(xmlDocument.createElement("vydano"))
                .setTextContent(today.getDay() + "/" + today.getMonth() + 1
                + "/" + today.getYear() + 1900);
        card.appendChild(xmlDocument.createElement("platnost"))
                .setTextContent(today.getDay() + "/" + today.getMonth() + 1
                + "/" + today.getYear() + 1901);
    }
}
