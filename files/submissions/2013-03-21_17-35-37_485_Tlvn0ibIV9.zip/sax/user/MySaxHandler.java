/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.StringTokenizer;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;



/**
 * Counts total quantity and value from equipments attributes.
 * Creates statistics of clients whereabouts.
 * Checks employees with contracts ending this year.
 * 
 * @author Jan Helbich
 */
public class MySaxHandler extends DefaultHandler {
    int totalEquipmentValue, totalEquipmentCount;
    boolean getEmployeesContract, getClientWhereabouts;
    boolean getEmployeesName, checkDate, checkCity;
    
    Map<String, Integer> whereabouts = new HashMap<String, Integer>();
    LinkedList<Pair<String, String>> employees = new LinkedList<Pair<String, String>>();

    @Override
    public void startDocument() throws SAXException {
    }

    @Override
    public void endDocument() throws SAXException {
        printTotalEquipmentStat();
        printTotalClientWhereaboutsStat();
        printTotalEndingContractsStat();
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        if(qName.equals("vybaveni")) {
            countEquipment(attributes);
        } if(qName.equals("klient")) {
            getClientWhereabouts = true;
        } if(qName.equals("zamestnanec")) {
            getEmployeesContract = true;
        } if(getEmployeesContract && qName.equals("jmeno")) {
            getEmployeesName = true;
        } if(getClientWhereabouts && qName.equals("mesto")) {
            checkCity = true;
        } if(getEmployeesContract && qName.equals("platnost")) {
            checkDate = true;
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if(qName.equals("klient")) {
            getClientWhereabouts = false;
        }
        if(qName.equals("zamestnanec")) {
            getEmployeesContract = false;
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        String s = new String(ch, start, length);
        if(checkCity){
            updateClientsWhereaboutsStatistic(s);
            checkCity = false;
        }
        if(getEmployeesName ) {
            employees.add(new Pair<String, String>(s, ""));
            getEmployeesName = false;
        }
        if(checkDate) {
            employees.getLast().value = s;
            checkDate = false;
        }
        
    }

    /**
     * Count total equipment and its total value.
     * @param attributes
     * @throws NumberFormatException 
     */
    private void countEquipment(Attributes attributes) throws NumberFormatException {
        int count = 0, value = 0;
        for (int i = 0; i < attributes.getLength(); i++) {
            String attr = attributes.getQName(i);
            if(attr.equals("mnozstvi")){
                count = Integer.parseInt(attributes.getValue(i));
            }
            if(attr.equals("cena-kusu")) {
                value = Integer.parseInt(attributes.getValue(i));
            }
        }
        totalEquipmentValue += count*value;
        totalEquipmentCount+= count;
    }
    
    /**
     * Create statistics about clients hometowns.
     * @param s 
     */
    private void updateClientsWhereaboutsStatistic(String s) {
        if(whereabouts.containsKey(s)){
            Integer i = whereabouts.get(s);
            whereabouts.put(s, i + 1);
        }
        else
            whereabouts.put(s, 1);
    }
    /**
     * Parse recieved value and check, if current and parsed year match.
     * Date format is dd/MM/yyyy
     * @param value
     * @return 
     */
    private boolean contractEndsThisYear(String value) {
        Date d = new Date(System.currentTimeMillis());
        StringTokenizer st = new StringTokenizer(value, "/");
        String token = "";
        Integer i = 0;
        while(st.hasMoreTokens()) {
            token = st.nextToken();
            i = Integer.parseInt(token);
            if(i > 1000) break;
        }
        return d.getYear() == (i - 1900);
    }

    /*
     * Print total equipment statistics (quantity and total value).
     */
    private void printTotalEquipmentStat() {
        System.out.println("There are " + totalEquipmentCount + " available"
                + " equipments in " + "the hobby centre, which total value is "
                + totalEquipmentValue +"$.\n");
    }

    /**
     * Print a town where most clients reside.
     */
    private void printTotalClientWhereaboutsStat() {
        if(whereabouts.isEmpty()) {
            System.out.println("There are no clients.\n");
        }
        Set<Entry<String, Integer>> entrySet = whereabouts.entrySet();
        Iterator<Entry<String, Integer>> iterator = entrySet.iterator();
        String city = "";
        int frequency = 0;
        while(iterator.hasNext()){
            Entry<String, Integer> entry = iterator.next();
            if(entry.getValue() > frequency) {
                frequency = entry.getValue();
                city = entry.getKey();
            }
        }
        System.out.println("The majority (" + frequency
                + ") of hobby centre's clients comes from "
                + city + ".\n");
    }

    /**
     * Print employees with ending contracts and total number of those.
     */
    private void printTotalEndingContractsStat() {
        int endingContracts = 0;
        Iterator<Pair<String,String>> i = employees.iterator();
        while(i.hasNext()) {
            Pair<String, String> entry = i.next();
            if(contractEndsThisYear(entry.value)) {
                System.out.println(entry.key + "'s contract"
                        + " is ending this year");
                endingContracts++;
            }
        }
        System.out.println("There are totally " + endingContracts
                + " employees with contracts ending this year.\n");
    }
    
}
class Pair<K,V> {
    protected K key;
    protected V value;

    public Pair(K key, V value) {
        this.key = key;
        this.value = value;
    }
    
    public boolean hasAssignedValue() {
        return !value.equals("");
    }

    public K getKey() {
        return key;
    }

    public V getValue() {
        return value;
    }
}