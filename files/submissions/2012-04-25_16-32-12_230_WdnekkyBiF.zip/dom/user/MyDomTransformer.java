package user;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;
import java.util.*;

/**
 * Vstupni trida programu, ktera zaroven definuje provadenou transformaci.
 */
public class MyDomTransformer
{
    /**
     * Provede danou transformaci - vsechny textove elementy transformuje
     * na atributy. Transformuji se pouze takove textove elementy, ktere
     * nemaji zadne atributy. Pokud v danem elementu existuje vice textovych
     * podelementu stejneho nazvu, tak se netransformuje ani jeden. Pokud
     * by nahodou jiz element mel atribut, ktery se jmenuje stejne jako
     * textovy element urceny k transformaci, tak se transformace rovnez
     * neprovede.
     */
    public void transform(Document xmlDocument)
    {
        Element root = xmlDocument.getDocumentElement();
        processTree(root, xmlDocument);
    }
    
    /**
     * U korenoveho elementu nas nezajima, jestli je to textovy uzel nebo ne,
     * nebot bychom jej stejne nemohli transformovat na atribut nadrazeneho
     * elementu, nebot zadny takovy element neexistuje.
     */
    private static void processTree(Element element, Document document)
    {
        // Rekurzivni zpracovani potomku daneho uzlu
        Map<String, Element> textElements = new HashMap<String, Element>();
        Map<String, Boolean> textElementsUse = new HashMap<String, Boolean>();
        NodeList children = element.getChildNodes();
        int childrenCount = children.getLength();
        
        // Projdeme vsechny potomky a najdeme vhodne uzly s textovym obsahem
        for (int i = 0; i < childrenCount; i++)
        {
            Node child = children.item(i);
            
            // Jedna se o uzel typu element?
            if (child.getNodeType() == Node.ELEMENT_NODE)
            {
                Element childElement = (Element)child;
                
                // Jedna se o textovy element? Pokud ano, pridame jej do danych kolekci
                if (isPureTextElement(childElement))
                {
                    String elementName = childElement.getTagName();
                    textElements.put(elementName, childElement);
                    
                    // Pokud existuje jiny textovy element stejneho jmena,
                    // tak ani jeden z nich nebudeme prevadet na atribut
                    if (textElementsUse.containsKey(elementName))
                        textElementsUse.put(elementName, false);
                    else
                        textElementsUse.put(elementName, true);
                }
                // Jinak jej rekurzivne zpracujeme
                else
                    processTree(childElement, document);
            }
        }
        
        // Transformujeme vybrane textove elementy na atributy
        for (String elementName : textElementsUse.keySet())
        {
            // Zkontrolujeme, jestli je mozne tento element skutecne transformovat
            // a jestli jeho rodic jiz neobsahuje atribut daneho nazvu.
            if (textElementsUse.get(elementName) == true && element.hasAttribute(elementName) == false)
            {
                Element childElement = textElements.get(elementName);
                
                // Odstranime dany element
                element.removeChild(childElement);
                
                // Vytvorime misto nej atribut
                element.setAttribute(elementName, childElement.getTextContent());
            }
        }
    }
    
    /**
     * Zjisti, jestli ma predany element pouze jednoho potomka, zadne
     * atributy a jestli tento jeho potomek textovy uzel. Pouze uzly
     * tohoto typu transformujeme na atributy.
     */
    private static boolean isPureTextElement(Element element)
    {
        if (element.getChildNodes().getLength() == 1 && element.getAttributes().getLength() == 0)
        {
            if (element.getFirstChild().getNodeType() == Node.TEXT_NODE)
                return true;
            else
                return false;
        }
        else
            return false;
    }
    
    /**
     * Vstupni bod programu - provede transformaci na zadanem XML dokumentu.
     */
    public static void main(String[] args)
    {
        String inputFilename = "../../data.xml";
        String outputFilename = "../../data.out.xml";
	
        try
        {
            // Nastaveni DOM rozhrani
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setValidating(false);
            DocumentBuilder builder = dbf.newDocumentBuilder();
            
            // Zpracujeme vstupni XML soubor - vytvorime z nej strom objektu
            Document doc = builder.parse(inputFilename);
            
            // Zpracujeme XML strom
            MyDomTransformer myTransformer = new MyDomTransformer();
            myTransformer.transform(doc);
            
            // Vytvorime transformer
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer writer = tf.newTransformer();
            
            // Nastaveni kodováni
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            
            // Ulozime DOM stromu jako XML dokument
            writer.transform(new DOMSource(doc), new StreamResult(new File(outputFilename)));
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }    
}
