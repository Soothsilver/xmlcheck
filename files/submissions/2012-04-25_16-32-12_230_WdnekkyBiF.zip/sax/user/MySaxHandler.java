package user;

import org.xml.sax.helpers.DefaultHandler;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.*;
import java.util.*;

/**
 * Trida pro zpracovani XML pomoci rozhrani SAX a vstupni trida programu.
 */
public class MySaxHandler extends DefaultHandler
{
    Stack<Integer> stack;       // Zasobnik, do ktereho si ukladame prubezne fan-outy jednotlivych elementu
    List<Integer> fanOuts;      // Seznam jiz spocitanych fan-outu
    
    /**
     * Obsluha udalosti volane pri zacatku cteni XML dokumentu.
     */
    public void startDocument() throws SAXException
    {
        this.stack = new Stack<Integer>();
        this.fanOuts = new ArrayList<Integer>();
    }
    
    /**
     * Obsluha udalosti volane, kdyz parser narazi na zacatek elementu.
     * Pokud je na vrcholu zasobniku jiz nejake cislo, tak jej zvysime o 1, tj.
     * element, ktery otevirame je podelementem elementu, jehoz fan-out je
     * na vrcholu zasobniku.
     */
    public void startElement(String namespaceURI, String localName, String qName, Attributes atts) throws SAXException
    {
        if (!stack.isEmpty())
        {
            Integer lastElementFanOut = stack.pop();
            stack.push(lastElementFanOut + 1);
        }
        
        stack.push(0);
    }
    
    /**
     * Kdyz uzavirame element, vybereme cislo z vrcholu zasobniku, ktere
     * predstavuje fan-out nejakeho drive otevreneho elementu. Toto cislo
     * si ulozime do seznamu fan-outu jiz uzavrenych elementu.
     */
    public void endElement (String uri, String localName, String qName)
    {
        if (!stack.isEmpty())
        {
            Integer lastElementFanOut = stack.pop();
            this.fanOuts.add(lastElementFanOut);
        }
    }
    
    /**
     * Jakmile je XML dokument docten, vypiseme danou statistiku. Tj.
     * projdeme seznam fan-outu jednotlivych elementu a spocitame maximalni
     * a prumerny fan-out.
     */
    public void endDocument() throws SAXException
    {
        Iterator<Integer> iterator = fanOuts.iterator();
        int maxFanOut = 0;
        int sum = 0;
        
        // Projdeme jednotlive fan-outy
        while (iterator.hasNext())
        {
            Integer actualFanOut = iterator.next();
            sum += actualFanOut;
            
            if (actualFanOut > maxFanOut)
                maxFanOut = actualFanOut;
        }
        
        // Vypiseme statistiku
        System.out.println("Maximalni fan-out elementu: " + maxFanOut);
        System.out.println("Prumerny fan-out elementu: " + (sum / (float)fanOuts.size()));
    }
    
    /**
     * Behem zpracovani XML nastala chyba.
     */
    public void error(SAXParseException e)
    {
        System.out.println("SAXParseException: error");
        e.printStackTrace();
    }

    /**
     * Behem zpracovani XML nastalo varovani.
     */
    public void warning(SAXParseException e)
    {
        System.out.println("SAXParseException: warning");
        e.printStackTrace();
    }

    /**
     * Behem zpracovani XML nastal fatal error.
     */
    public void fatalError(SAXParseException e)
    {
        System.out.println("SAXParseException: fatal error");
        e.printStackTrace();
        System.exit(1);
    }
    
    /**
     * Vstupni funkce programu.
     */
    public static void main(String[] args)
    {
        String filename = "../../data.xml";
        
        try
        {
            // Nastaveni SAX rozhrani
            SAXParserFactory spfactory = SAXParserFactory.newInstance();
            spfactory.setValidating(false);
            SAXParser saxparser = spfactory.newSAXParser();
            
            // Vytvorime instanci parseru
            XMLReader xmlreader = saxparser.getXMLReader();
            
            // Vytvorime vstupni proud dat
            InputSource source = new InputSource(filename);
            
            // Nastavime handler pro obsluhu udalosti
            xmlreader.setContentHandler(new MySaxHandler());
            
            // Ten samy handler pro kontrolu chyb
            xmlreader.setErrorHandler(new MySaxHandler());
            
            // Samotne zpracovani vstupniho XML souboru
            xmlreader.parse(source);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}
