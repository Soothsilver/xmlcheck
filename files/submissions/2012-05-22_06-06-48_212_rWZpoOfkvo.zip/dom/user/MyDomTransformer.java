package user; 

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/*
 * Prostřednictvím rozhraní DOM provést vybranou transformaci XML dokumentu, 
 * která změní jeho strukturu (např. obrátit pořadí elementů, převést atributy 
 * na elementy, převést elementy s textovým obsahem na atributy, smazat 
 * elementy v zadané hloubce/přesahující povolený fan-out/s danou hloubkou, 
 * doplnit fan-out na dané minimum, doplnit max. hloubku na dané minimum apod.) 
 * Každý si vymyslí a předem ohlásí vlastní téma.
 * 
 * TÉMA: Přidat uzel výpisy, kde bude vlastník a výměra parcel, které vlastní. 
 * 
 * Na konec data.xml přidá tedy:
 * 
 * <vypisy description="Vypis vsech vlastniku...">
 * 	<vlastnik id="v8808275007">
 * 		<jmeno>Nováček Adam</jmeno>
 * 		<vymera>82.3747</vymera>
 * 	</vlastnik>
 * ...
 * </vypisy>
 * 
 */
public class MyDomTransformer { 

	
    
    private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "data.out.xml";

    public static void main(String[] args) {
        
        try {
        	
        	// System.out.println("Starting up...");
        	
            //DocumentBuilderFactory vytváří DOM parsery
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            //nebudeme validovat
            dbf.setValidating(false);

            //vytvoříme si DOM parser
            DocumentBuilder builder = dbf.newDocumentBuilder();

            //parser zpracuje vstupní soubor a vytvoří z něj strom DOM objektů
            Document doc = builder.parse(VSTUPNI_SOUBOR);
            
            MyDomTransformer trans = new MyDomTransformer();
            
            // System.out.println("Transforming...");
            //zpracujeme DOM strom
            trans.transform(doc);

            //TransformerFactory vytváří serializátory DOM stromů
            TransformerFactory tf = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer = tf.newTransformer();
            
            //nastavíme kodování
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spustíme transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


            // System.out.println("DONE");
        } catch (Exception e) {
            
            e.printStackTrace();
            
        }
    }    
    
    /**
     * vrati element <vlastnik>, ktery obsahujuje podelement <aktualni>
     * 
     * @param lv element <lv>
     * @return Node <vlastnik> nebo null, pokud zadny z elementu <vlastnik>
     * nema podrizeny element <aktualni>
     */
    public String getAktualniVlastnikId(Node lv) {		
		
		for (Node lvVlastnik = lv.getFirstChild(); 
				lvVlastnik.getNextSibling() != null; 
				lvVlastnik = lvVlastnik.getNextSibling())	{
			
			// System.out.print("aktualniVlastnik()?-");
			
			if (lvVlastnik.getNodeName().equals("vlastnik")) {
				
				
				// hleda vzorek 
				// <vlastnik id="v8808275007">            
	            //     <zmeneno>12.12.2011</zmeneno>
	            //     <aktualni />
	            // </vlastnik>
				for (Node lvVlastnikAktualni = lvVlastnik.getFirstChild(); 
						lvVlastnikAktualni.getNextSibling() != null;
						lvVlastnikAktualni = lvVlastnikAktualni.getNextSibling()) {
							
						if (lvVlastnikAktualni.getNodeName().equals("aktualni")) {
							
							// <vlastnik id="v8808275007">
							
							Attr id = (Attr)lvVlastnikAktualni.getParentNode().getAttributes().item(0);
							String lvVlastnikId = id.getValue(); 
							
							return lvVlastnikId;
						} // if
				} // for
			
			} // if
		}
		
		return null;
    }
    
    Map<String, Double> vypisVymer = new HashMap<String, Double>();
    
    /**
     * TÉMA: Přidat uzel výpisy, kde bude vlastník a výměra vlastněné půdy. 
     * 
     * @param xmlDocument
     */
	public void transform (Document xmlDocument) { 
		// code transforming xmlDocument object 
		// (method works on the object itself - no return value) 
		
				
		// pouze lv, ktere jsou soucasti <listy-vlastnictvi> a <ku>
		Node listyVlastnictvi = xmlDocument.
				getElementsByTagName("listy-vlastnictvi").item(0);	
		
		// <listy-vlastnictvi>/<ku>		
		if (!listyVlastnictvi.hasChildNodes()) {
			System.err.println("V "+VSTUPNI_SOUBOR+" nejsou zadne listy vlastnictvi.");
			return;
		}		
		for (int iku = 0; iku < listyVlastnictvi.getChildNodes().getLength(); iku++) {
			
			Node ku = listyVlastnictvi.getChildNodes().item(iku);
			
			if (!ku.getNodeName().equals("ku")) continue;
			
			// System.out.print("ku-");
			
			// <listy-vlastnictvi>/<ku>/<lv>
			if (!ku.hasChildNodes()) {
				String nazev = ((Attr)(ku.getAttributes().getNamedItem("nazev"))).getValue();
				System.err.println("V katastru "+nazev+" neni zadny LV.");
				continue;
			}
			for (Node lv = ku.getFirstChild(); lv.getNextSibling() != null; 
					lv = lv.getNextSibling()) {
				
				if (!lv.getNodeName().equals("lv")) continue;
				
				// System.out.print("lv-");
				
				// 1. vybrat aktualniho vlastnika
				// <listy-vlastnictvi>/<ku>/<lv>/<vlastnik>/<aktualni>
				String aktualniVlastnik = getAktualniVlastnikId(lv);
				
				if (aktualniVlastnik == null) {
					System.err.println("Aktualni vlastnik LV nenalezen.");
					continue;
				}				
				// System.out.print("vlastnik: "+aktualniVlastnik+"-");
				
				// 2. secist vymery parcel, ktere vlastnik vlastni v danem listu vlastnictvi
				// <listy-vlastnictvi>/<ku>/<lv>/<parcela id="p123">
				Double meziSoucet = 0.0;
				for (Node parcela = lv.getFirstChild(); 
						parcela.getNextSibling() != null;
						parcela = parcela.getNextSibling()) {
					
					// vybrat pouze podelementy <parcela> elementu <lv>
					if (!parcela.getNodeName().equals("parcela")) continue;
					
					meziSoucet += getParcelaVymeraFromLv(parcela);
					
					if (vypisVymer.containsKey(aktualniVlastnik)) {
						vypisVymer.put(aktualniVlastnik, meziSoucet+vypisVymer.get(aktualniVlastnik));
					} else {
						vypisVymer.put(aktualniVlastnik, meziSoucet);
					}
				} // for
				
				
				
			} // for lv's
			
		} // for ku's
		
		
		// 3. vytvorit souhrnny vypis
		
		Element vypisy = xmlDocument.createElement("vypisy");
		
		Attr desc = xmlDocument.createAttribute("description");
		desc.setValue("Vypis vsech vlastniku a soucet jejich vlastnenych vymer k aktualnimu datu.");
		vypisy.setAttributeNode(desc);
		
		for (String vlastnikId : vypisVymer.keySet()) {
			Double vymera = vypisVymer.get(vlastnikId);
			
			Element vlastnikElem = xmlDocument.createElement("vlastnik");
			vlastnikElem.setAttribute("id", vlastnikId);
			
			Element vlastnikNameElem = xmlDocument.createElement("jmeno");
			
			String vlastnik = getVlastnikName(
					xmlDocument.getElementsByTagName("vlastnik"), 
					vlastnikId);
			
			
			if (vlastnik == null) {
				System.err.println("Vlastnik "+vlastnikId+" neexistuje!");
				continue;
			}
			
			vlastnikNameElem.setTextContent(vlastnik);
			
			vlastnikElem.appendChild(vlastnikNameElem);
			
			Element vymeraElem = xmlDocument.createElement("vymera");
			vymeraElem.setTextContent(vymera.toString());			
			vlastnikElem.appendChild(vymeraElem);
			
			vypisy.appendChild(vlastnikElem);
		}
		
		
		
		
		// get root node "evidence"
		NodeList evList = xmlDocument.getElementsByTagName("evidence");		
		Node evidence = evList.item(0);
		evidence.appendChild(vypisy);
		
		
	}

	/**
	 * vratit jmeno a prijmeni vlastnika / nazev firmy
	 * 
	 * @param vlastnici doc.getElementsByTagName("vlastnik")
	 * @param vlastnikId <vlastnik id="v3455">
	 * @return Josef Vlacil nebo null, pokud vlastnik nenalezen
	 */
	private String getVlastnikName(NodeList vlastnici, String vlastnikId) {
		
		for (int i = 0; i < vlastnici.getLength(); i++) {
			Node current = vlastnici.item(i);
			
			String currentId = ((Attr)(current.getAttributes().item(0))).getValue();
			
			// System.out.print("currentId: "+currentId+"-");
			
			String jmeno = "";
			String prijmeni = "";
			String firma = "";
			
			if (currentId.equals(vlastnikId)) {
				for (Node child = current.getFirstChild(); 
						child.getNextSibling() != null;
						child = child.getNextSibling()) {
					
					// <jmeno>Adam</jmeno>
					if (child.getNodeName().equals("jmeno")) {
						jmeno = child.getTextContent();
					}
					
					// <prijmeni>Nováček</prijmeni>
					if (child.getNodeName().equals("prijmeni")) {
						prijmeni = child.getTextContent();
					}
					
					// <firma>Obec Přímětín</firma>
					if (child.getNodeName().equals("firma")) {
						firma = child.getTextContent();
					}
					
					if (jmeno.length() > 0 && prijmeni.length() > 0) {
						return prijmeni+" "+jmeno;
					}
					
					if (firma.length() > 0) {
						return firma;
					}
					
				}
			}
		}
		
		return null;
		
	}

	/**
	 * vrati vymeru parcely
	 * @param id identifikator parcely
	 * @return vymera parcely nebo 0.0 pokud parcela nebyla nalezena
	 */
	private Double getParcelaVymeraFromLv(Node parcela) {
		
		String id = ((Attr)(parcela.getAttributes().getNamedItem("id"))).getValue();
		
		// moving from <lv>/<parcela> -> ... -> <parcely>/<parcela>/<vymera>
		Document doc = parcela.getOwnerDocument();
		
		NodeList vymery = doc.getElementsByTagName("vymera");
		
		for (int i = 0; i < vymery.getLength(); i++) {
			Node vymera = vymery.item(i);
			
			// <parcela id="p1.1">
	        // ...
	        // <vymera>1.2584</vymera>
			// ...
			// </parcela>
			String currentId = ((Attr)(vymera.getParentNode().
					getAttributes().getNamedItem("id"))).getValue();
			
			if (id.equals(currentId)) {
				return Double.parseDouble(vymera.getTextContent());
			}
		}
		
		// parcela not found
		return 0.0;
	} 
	
	
}
