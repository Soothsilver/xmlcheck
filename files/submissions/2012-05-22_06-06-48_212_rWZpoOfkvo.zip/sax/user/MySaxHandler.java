package user; 

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

/*
 * Prostřednictvím rozhraní SAX spočítat zvolenou charakteristiku XML dokumentu 
 * (např. maximální/průměrnou hloubku, počet elementů, počet atributů, 
 * maximální/průměrnou délku názvů elementů/atributů, počet elementů 
 * s textovým obsahem/s atributy/s podelementy, maximální/průměrný 
 * fan-out apod.). Každý si vymyslí a předem ohlásí vlastní téma.
 * 
 * TÉMA: Vytvoření součtů výměr půdy za jednotlivé kultury.
 * 
 * Součty jsou uloženy v HasSetu<String kultura, Double vymera>
 * a zároveň při volání endDocument() jsou vypsány na stdout.
 * 
 * =================================================
 *  Vypis celkovych vymer evidovane pudy dle kultur.
 * =================================================
 *  
 *  - les:		9 ha.
 *  - orná:		14 ha.
 *  
 *  CELKEM: 2 kultur na 23 ha.
 * 
 */
public class MySaxHandler extends DefaultHandler {
    // Umožňuje zacílit místo v dokumentu, kde vznikla aktualní událost
    Locator locator;
    
    public static void main(String[] params) {
    	
    	// Vytvorime instanci parseru
    	XMLReader parser;
		try {
			parser = XMLReaderFactory.createXMLReader ();
			
			// Vytvorime vstupni proud XML dat
	    	InputSource source = new InputSource ("data.xml");
	    	// Nastavime vlastni content handler pro obsluhu udalosti
	    	parser.setContentHandler (new MySaxHandler ());
	    	// Zpracujeme vstupni proud XML dat
	    	parser.parse (source);
			
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	

    	
    	
    }
    
    /**
     * Nastaví locator
     */     
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    
    /**
     * Obsluha události "konec dokumentu"
     */     
    public void endDocument() throws SAXException {
        
    	// System.out.println();
    	// System.out.println();
    	
        // System.out.println("=================================================");
    	// System.out.println(" Vypis celkovych vymer evidovane pudy dle kultur.");
    	// System.out.println("=================================================");
    	// System.out.println();
    	
    	Double celkem = 0.0;
    	
    	for (String kultura : vymery.keySet()) {
    		vymera = vymery.get(kultura);
    		celkem += vymera;
    		// System.out.println("- "+kultura+":\t\t"+Math.round(vymera)+" ha.");
    	}
    	
    	// System.out.println();
    	// System.out.println("CELKEM: "+vymery.size()+" kultur na "+
    	//		Math.round(celkem)+" ha.");
    }
    
    boolean parcelaStarted = false;
    boolean vymeraStarted  = false;
    boolean kulturaStarted = false;
    StringBuilder buffer    = new StringBuilder();
    
    double vymera          = 0.0;    
    String kultura;
    Map<String, Double> vymery = new HashMap<String, Double>();
    
    
    /**
     * Obsluha události "začátek elementu".
     * @param uri URI jmenného prostoru elementu (prázdné, pokud element není v žádném jmenném prostoru)
     * @param localName Lokální jméno elementu (vždy neprázdné)
     * @param qName Kvalifikované jméno (tj. prefix-uri + ':' + localName, pokud je element v nějakém jmenném prostoru, nebo localName, pokud element není v žádném jmenném prostoru)
     * @param atts Atributy elementu     
     */     
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        if (qName.equals("parcela")) {
        	// System.out.print("parcela-");
        	parcelaStarted = true;
        	vymera = 0.0;
        	kultura = "";
        }
        
        if (parcelaStarted && qName.equals("vymera")) {
        	// System.out.print("vymera-");
        	vymeraStarted = true;
        }
        
        if (parcelaStarted && qName.equals("kultura")) {        	
        	kulturaStarted = true;
        	kultura = atts.getValue("typ");
        	// System.out.print("kultura: "+kultura+"-");
        }

    }
    /**
     * Obsluha události "konec elementu"
     * Parametry mají stejný význam jako u @see startElement     
     */     
    public void endElement(String uri, String localName, String qName) throws SAXException {

    	if (qName.equals("parcela")) {
    		parcelaStarted = false;    		
    	}
    	
        if (qName.equals("vymera")) {
        	vymeraStarted = false;
        	if (buffer.length() > 0) {
        		
        		// System.out.print("buffer: "+buffer.toString()+"-");
        		vymera = Double.parseDouble(buffer.toString());
        		
        		if (vymera > 0.0 && kultura.length() > 0) {
        			if (vymery.containsKey(kultura)) {
        				vymera += vymery.get(kultura);
        				vymery.put(kultura, vymera);
        			} else {
        				vymery.put(kultura, vymera);
        			}
        		}
        		
        		buffer = new StringBuilder();
        	}
        }
        
        if (qName.equals("kultura")) {
        	kulturaStarted = false;
        	   		
			if (vymera > 0.0 && kultura.length() > 0) {
				if (vymery.containsKey(kultura)) {
					vymera += vymery.get(kultura);
					vymery.put(kultura, vymera);
				} else {
					vymery.put(kultura, vymera);
				}
			}
        		
        	        	
        }

    }
    
    /**
     * Obsluha události "znaková data".
     * SAX parser muľe znaková data dávkovat jak chce. Nelze tedy počítat s tím, že je celý text dorucen v rámci jednoho volání.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakovými daty
     * @param start Index zacátku úseku platných znakových dat v poli.
     * @param length Délka úseku platných znakových dat v poli.
     */               
    public void characters(char[] ch, int start, int length) throws SAXException {
    	if (parcelaStarted && vymeraStarted) {
    		// System.out.print("characters0("+(new String(ch, start, length))+")");
    		buffer.append(ch, start, length);    		
    		// System.out.print("characters("+buffer.toString()+")-");
    	}
    }  
}