package user;

import org.w3c.dom.Document;
import java.io.File;
import java.io.FileInputStream;
import java.io.StringWriter;
import java.io.Writer;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Attr;
import org.w3c.dom.Text;
import org.w3c.dom.NodeList;


public class MyDomTransformer {
    
    public static void transform (Document xmlDocument) {
        // libovolne transformace objektu 'xmlDocument'
        // (metoda pracuje primo na objektu, nic nevraci)
        
        pridajElement(xmlDocument);
        
        zmazZanre(xmlDocument);

    }
    
    //ak ma film rating R, dopon poznamku Nevhodne pre deti
    public static void zmazZanre(Document xmlDocument)
    {
        NodeList nl = xmlDocument.getElementsByTagName("zanerFilmu");
        for (int i = 0; i < nl.getLength(); i++)
        {
            Element em = (Element)xmlDocument.getElementsByTagName("film").item(i);
            if (em.getAttribute("rating") == "R")
            {
                em.setAttribute("rating", "R - nevhodne pre deti");
            }
        }
    }
    
    public static void pridajElement(Document xmlDocument)
    {
        Element root = xmlDocument.getDocumentElement();
        Element node = xmlDocument.createElement("film");

        root.appendChild(node);
        node.setAttribute("fid", "f_10"); 
        node.setAttribute("rating", "R");         
        
        //info
        Element info = xmlDocument.createElement("info");
        node.appendChild(info);
        
        Node blabla = xmlDocument.createTextNode("Film Home alone z roku 1990 s dĺžkou 103 minút režíroval režisér Chris Columbus.");
        info.appendChild(blabla);
        
        //zanre
        Element zanre = xmlDocument.createElement("zanre");
        node.appendChild(zanre);
        
        Element zaner1 = xmlDocument.createElement("zanerFilmu");
        zaner1.setAttribute("gid_ref", "g_1");
        zanre.appendChild(zaner1);
        
        //herci
        Element herci = xmlDocument.createElement("herci");
        node.appendChild(herci);
        
        Element herec1 = xmlDocument.createElement("herec");
        herci.appendChild(herec1);
        
        Element meno1 = xmlDocument.createElement("meno");
        herec1.appendChild(meno1);
        
        Node Maculay = xmlDocument.createTextNode("Macaulay Culkin");
        meno1.appendChild(Maculay);
        
        Element hral1 = xmlDocument.createElement("hralPostavy");
        herec1.appendChild(hral1);
        
        Element hranaPostava1 = xmlDocument.createElement("hranaPostava");
        hranaPostava1.setAttribute("meno", "Kevin McCallister"); 
        hral1.appendChild(hranaPostava1);
        
               
        Element herec2 = xmlDocument.createElement("herec");
        herci.appendChild(herec2);
        
        Element meno2 = xmlDocument.createElement("meno");
        herec2.appendChild(meno2);
        
        Node Joe = xmlDocument.createTextNode("Joe Pesci");
        meno2.appendChild(Joe);
        
        Element hral2 = xmlDocument.createElement("hralPostavy");
        herec2.appendChild(hral2);
        
        Element hranaPostava2 = xmlDocument.createElement("hranaPostava");
        hranaPostava2.setAttribute("meno", "Harry Lime"); 
        hral2.appendChild(hranaPostava2);
        
        
        
        Element herec3 = xmlDocument.createElement("herec");
        herci.appendChild(herec3);
        
        Element meno3 = xmlDocument.createElement("meno");
        herec3.appendChild(meno3);
        
        Node Daniel = xmlDocument.createTextNode("Daniel Stern");
        meno3.appendChild(Daniel);
        
        Element hral3 = xmlDocument.createElement("hralPostavy");
        herec3.appendChild(hral3);
        
        Element hranaPostava3 = xmlDocument.createElement("hranaPostava");
        hranaPostava3.setAttribute("meno", "Marv Merchants"); 
        hral3.appendChild(hranaPostava3);
    }
    
}