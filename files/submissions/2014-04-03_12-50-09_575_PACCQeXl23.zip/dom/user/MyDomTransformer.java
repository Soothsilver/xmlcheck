package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer {
	public void transform (Document xmlDocument) {
		
		// removes contact with id id_467 from document 
		NodeList contacts = xmlDocument.getElementsByTagName("contact-entry");
		Node contactToRemove = null;
		for (int i = 0; i < contacts.getLength(); i++) {
			Element contact = (Element) contacts.item(i);
			if("id_467".equals(contact.getAttribute("contact-entry-id"))) {
				contactToRemove = contact;
			}
		}
		if(contactToRemove != null) {
			xmlDocument.getElementsByTagName("contacts").item(0).removeChild(contactToRemove);
		}
		
		// adds new contact with id id_468 to document
		Element newContact = xmlDocument.createElement("contact-entry");
		newContact.setAttribute("contact-entry-id", "id_468");
		Element newContactName = xmlDocument.createElement("name");
		newContactName.appendChild(xmlDocument.createTextNode("John Doe Reborn"));
		newContact.appendChild(newContactName);
		Element newContactEmail = xmlDocument.createElement("contact");
		newContactEmail.setAttribute("type", "email");
		newContactEmail.appendChild(xmlDocument.createTextNode("john.doe@reborn.com"));
		newContact.appendChild(newContactEmail);
		
		Node contactsElement = xmlDocument.getElementsByTagName("contacts").item(0);
		contactsElement.appendChild(newContact);
	}
}
