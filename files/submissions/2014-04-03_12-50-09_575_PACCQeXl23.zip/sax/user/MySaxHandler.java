package user;

import java.util.ArrayList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler { 

	private static int LOWEST_CONTACT_COUNT = 2;
	
	private int phonesCount;
	private int emailsCount;
	private int faxesCount;
	
	private List<String> domains = new ArrayList<String>();
	private List<Integer> domainsCounts = new ArrayList<Integer>();
	
	private String lastProjectName;
	private int projectContactsCount;
	// all projects with at least two associated contacts
	private List<String> resultProjects = new ArrayList<String>();

    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
    	System.out.println("Phone number appears "+phonesCount+" times in our contacts");
    	System.out.println("Email appears "+emailsCount+" times in our contacts");
    	System.out.println("Fax appears "+faxesCount+" times in our contacts");
    	
    	List<String> mostUsedDomains = new ArrayList<String>();
    	int maxCount = 0;
    	for(int i = 0; i < domains.size(); i++) {
    		int domainCount = domainsCounts.get(i);
    		if(domainCount > maxCount) {
    			mostUsedDomains.clear();
    			maxCount = domainCount;
    			mostUsedDomains.add(domains.get(i));
    		} else if (domainCount == maxCount) {
    			mostUsedDomains.add(domains.get(i));
    		}
    	}
    	System.out.print("Following domain/s occured "+maxCount+" times in our contacts:");
    	for(String domain : mostUsedDomains) {
    		System.out.print(" "+domain);
    	}
    	System.out.println();
    	
    	System.out.println("Following project/s have at least "+LOWEST_CONTACT_COUNT+" associated contacts:");
    	for(String project : resultProjects) {
    		System.out.println("   "+project);
    	}
    }

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
    	if("contact".equals(localName)) {
    		String contactType = atts.getValue("type");
    		if("phone".equals(contactType)) {
    			phonesCount++;
    		} else if("email".equals(contactType)) {
    			emailsCount++;
    		} else if("fax".equals(contactType)) {
    			faxesCount++;
    		}
    	} else if("project".equals(localName)) {
    		lastProjectName = atts.getValue("name");
    		projectContactsCount = 0;
    	} else if("project-contact".equals(localName)) {
    		projectContactsCount++;
    	}
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
    	if("project".equals(localName) && projectContactsCount >= LOWEST_CONTACT_COUNT) {
    		resultProjects.add(lastProjectName);
    	}
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
    	String content = new String(chars, start, length).trim();
    	if(content.length() > 0 && content.contains("@") && content.contains(".")) {
        	String[] emailParts = content.split("\\.");
        	String emailDomain = emailParts[emailParts.length - 1];
    		int domainListPos = domains.indexOf(emailDomain);
    		if (domainListPos < 0) {
    			domains.add(emailDomain);
    			domainsCounts.add(1);
    		} else {
    			int domainCount = domainsCounts.get(domainListPos);
    			domainsCounts.remove(domainListPos);
    			domainsCounts.add(domainListPos, ++domainCount);
    		}
    	}
    }
    
}
