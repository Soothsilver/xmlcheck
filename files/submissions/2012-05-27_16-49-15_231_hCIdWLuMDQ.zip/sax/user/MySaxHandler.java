/*
tento kod vypise ke kazdemu attributu, ve kterych elementech se nachazi.
*/
package user;

import java.util.Map;
import java.util.Iterator;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Enumeration;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;
import java.util.Hashtable;
import org.xml.sax.helpers.DefaultHandler; 


public class MySaxHandler extends DefaultHandler {

    Locator locator;
    Map<String,ArrayList<String>> counter=new HashMap<String,ArrayList<String>>();
    private boolean Update(ArrayList<String> founded,String newelem)
    {
        Iterator<String> iterator = founded.iterator();

        while(iterator.hasNext())
        {
          if(iterator.next() == newelem)
          {
            return false;
          }
        }
        founded.add(newelem);
        return true;
    }
    public void WriteOutResults()
    {
        for (Map.Entry<String,ArrayList<String>> entry : counter.entrySet()) 
        {
            System.out.print(entry.getKey()+": ");
            
            Iterator<String> iterator = entry.getValue().iterator();
            
            while(iterator.hasNext())
            {
                System.out.print(iterator.next()+" ");
            }
            System.out.println();
        }
    }
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }
    public void startDocument() throws SAXException {
        
        // ...
        
    }    
    public void endDocument() throws SAXException {
        
        WriteOutResults();
        
    }
    
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        for(int at=0;at<atts.getLength();at++)
        {
            String an = atts.getQName(at);
            if(counter.containsKey(an))
            {
                Update(counter.get(an),qName);
            }
            else
            {
                ArrayList<String> str = new ArrayList<String>();
                str.add(qName);
                counter.put(an, str);
            }
        }
    }
    public void endElement(String uri, String localName, String qName) throws SAXException {

        // ...

    }
    public void characters(char[] ch, int start, int length) throws SAXException {

        // ...
        
    }
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
        
    }
    public void endPrefixMapping(String prefix) throws SAXException {
    
        // ...
    
    }
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
        // ...
        
    }
    public void processingInstruction(String target, String data) throws SAXException {
      
      // ...
            
    }
    public void skippedEntity(String name) throws SAXException {
    
      // ...
    
    }
}