/* 
  tento kod zmeni v xml vsechny attributy na podelementy s nazvem "nazev elementu" + "nazev attributu"
*/
package user;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

public class MyDomTransformer { 
    private static Document doc;
    public void transform (Document xmlDocument) {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            
            dbf.setValidating(false);
            dbf.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd",false);

            DocumentBuilder builder = dbf.newDocumentBuilder();

            doc = builder.parse("data.xml");


            processTree(doc);
            TransformerFactory tf = TransformerFactory.newInstance();
            

            Transformer writer = tf.newTransformer();

            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            writer.transform(new DOMSource(doc), new StreamResult(new File("output.xml")));
        } catch (Exception e) {
            
        }
    }
    private static void TreeSearch(Node nod,int depth)
    {
        NodeList list = nod.getChildNodes();
        if(nod.getNodeType()==1)
        {
            NamedNodeMap attributes = nod.getAttributes();
            for(int i = 0;i<attributes.getLength();i++)
            {
                Attr attrib = (Attr)attributes.item(i);
                Element elem = doc.createElement(nod.getNodeName()+"."+attrib.getNodeName());
                elem.setTextContent(attrib.getNodeValue());
                nod.appendChild(elem);
            }
            while(attributes.getLength()>0)
            {
                ((Element)nod).removeAttributeNode((Attr)attributes.item(0));
            }
        }
        for(int i=0;i<list.getLength();i++) 
        {
            Node currentNode = list.item(i);
            TreeSearch(currentNode, depth+1);
        }
    }
    private static void processTree(Document doc) {
         Element root = doc.getDocumentElement();
         TreeSearch(root,0);
    }
}
