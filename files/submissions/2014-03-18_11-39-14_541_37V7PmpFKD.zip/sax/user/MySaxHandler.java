package user;

import java.util.HashMap;
import java.util.Map;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {

	/*
	Prostřednictvím rozhraní SAX spočítat alespoň 3 zvolené charakteristiky Vašich dat z nichž jedna se bude
	vztahovat k hodnotám atributů (např. průměrná váha výrobku), druhá k obsahu elementů (např. tři nejčastější
	příjmení zaměstnanců) a třetí ke kontextu (např. počet zaměstnanců, kteří jsou starší 60ti let, ale
	nemají dovolenou).
	*/

	private double sum_quality = 0;
	private int orders_count = 0;
	private double sum_price = 0;
	private long sum_vol_remaining = 0;
	Map<String, Integer> stations = new HashMap<String, Integer>();

	private boolean in_selling = false;
	private boolean in_station = false;
	private boolean in_price = false;
	private boolean in_vol_remain = false;


	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {
		if (localName.equals("sell_orders")) {
			in_selling = true;
		} else if (localName.equals("order")) {
			sum_quality += Double.parseDouble(attributes.getValue("quality"));
			++orders_count;
		} else if (localName.equals("price") && in_selling) {
			in_price = true;
			cur_price = new StringBuilder();
		} else if (localName.equals("station_name")) {
			in_station = true;
			cur_station = new StringBuilder();
		} else if (localName.equals("vol_remain")) {
			in_vol_remain = true;
			cur_vol_remain = new StringBuilder();
		}
	}

	StringBuilder cur_station;
	StringBuilder cur_price;
	StringBuilder cur_vol_remain;

	@Override
	public void characters(char[] ch, int start, int length)
			throws SAXException {
		if (in_station) {
			cur_station.append(new String(ch, start, length));
		} else if (in_price) {
			cur_price.append(new String(ch, start, length));
		} else if (in_vol_remain) {
			cur_vol_remain.append(new String(ch, start, length));
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		if (localName.equals("station_name")) {
			in_station = false;
			if (stations.containsKey(cur_station.toString())) {
				stations.put(cur_station.toString(), stations.get(cur_station.toString()) +1);
			} else {
				stations.put(cur_station.toString(), 1);
			}
		} else if (localName.equals("price")) {
			in_price = false;
		} else if (localName.equals("vol_remain")) {
			in_vol_remain = false;
		} else if (localName.equals("order")) {
			sum_price += Double.parseDouble(cur_price.toString()) * Double.parseDouble(cur_vol_remain.toString());
			sum_vol_remaining += Double.parseDouble(cur_vol_remain.toString());
		}
	}

	@Override
	public void endDocument() throws SAXException {
		double average_quality = sum_quality / orders_count;
		double average_price = sum_price / sum_vol_remaining;

		String most_frequent_station = new String();
		int occurences = 0;
		for (String station : stations.keySet()) {
			if (occurences < stations.get(station)) {
				occurences = stations.get(station);
				most_frequent_station = station;
			}
		}

		/*
		 * Vysledky jsou v:
		 *     average_price - prumerna cena za jednotku
		 *     average_quality - prumerna kvalita
		 *     most_frequent_station - ve ktere stanici je nejvice obchodovano? tedy ktera je nejzivejsi
		 */
	}

}