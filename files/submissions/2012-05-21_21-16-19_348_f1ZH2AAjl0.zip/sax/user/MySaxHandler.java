package user;

import java.io.IOException;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXParseException;

/**
 * ZADANI: Vypsat pocet medii vydanych po roce 1998.
 *         Vypsat celkovy pocet osob, z toho pocet interpretu a reziseru.
 *         Vypsat pocet pisni od bobsin (Bob Sinclair).
 */
public class MySaxHandler extends DefaultHandler {
    // override metod DefaultHandleru

    private int countMedium; //Pocet medii vydanych po roce 1998
    private int countSongs; //Pocet pisni od bobsin 
    private int countInterprets;
    private int countDirectors;
    private boolean processElmtVydani = false;
    private boolean processElmtMedium = false;
    private int vydani;
    private final String jmeno = "bobsin"; //Bob Sinclair

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        /* Zacatek elementu medium */
        if (localName.equals("medium")) {
            processElmtMedium = true;
            //System.out.println("Zacatek medium");
        }

        /* Zacatek elementu vydani */
        if (localName.equals("vydani") && processElmtMedium) {
            //System.out.println("Zacatek vydani");
            processElmtVydani = true;
        }

        /* Scitani interpretu a reziseru */
        if (localName.equals("osoba")) {
            int i = atts.getIndex("role");
            if (atts.getValue(i).equalsIgnoreCase("reziser")) {
                countDirectors++;
            } else {
                countInterprets++;
            }
        }

        /* Zacatek elementu pisen */
        if (localName.equals("pisen")) {
            int i = atts.getIndex("interpret");
            if (jmeno.equals(atts.getValue(i))) {
                countSongs++;
            }
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        /* Ulozeni vydani */
        if (processElmtVydani) {
            //System.out.println("Uvnitr vydani");
            vydani = Integer.parseInt(new String(ch, start, length));
            //System.out.println(vydani);
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        /* Ukonceni elementu medium */
        if (localName.equals("medium") && processElmtMedium) {
            processElmtMedium = false;
            //System.out.println("Ukonceni medium");
        }

        /* Ukonceni elementu vydani */
        if (localName.equals("vydani") && processElmtVydani) {
            /* Pokud je splnena tato vlastnost, inkrementuji si stav*/
            if (vydani > 1998) {
                countMedium++;
            }
            processElmtVydani = false;
            //System.out.println("Ukonceni vydani");
        }
    }

    @Override
    public void setDocumentLocator(Locator locator) {
        //todo
    }

    @Override
    public void startDocument() throws SAXException {
        //todo
    }

    @Override
    public void endDocument() throws SAXException {
        System.out.println("Pocet medii vydanych po roce 1998: " + countMedium + "; \n");
        System.out.println("Pocet osob celkem: " + (countDirectors + countInterprets) + ", z toho " + countInterprets + " interprets a " + countDirectors + " directors; \n");
        System.out.println("Pocet pisni od " + jmeno + " je: " + countSongs);
    }

    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        //todo
    }

    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        //todo
    }

    @Override
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        throw new UnsupportedOperationException("ignorableWhitespace.");
    }

    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        //todo
    }

    @Override
    public void skippedEntity(String name) throws SAXException {
        throw new UnsupportedOperationException("skippedEntity.");
    }

    @Override
    public InputSource resolveEntity(String publicId, String systemId) throws IOException, SAXException {
        //compiled code
        throw new RuntimeException("Compiled Code");
    }

    @Override
    public void notationDecl(String name, String publicId, String systemId) throws SAXException {
        //compiled code
        throw new RuntimeException("Compiled Code");
    }

    @Override
    public void unparsedEntityDecl(String name, String publicId, String systemId, String notationName) throws SAXException {
        //compiled code
        throw new RuntimeException("Compiled Code");
    }

    @Override
    public void warning(SAXParseException e) throws SAXException {
        //compiled code
        throw new RuntimeException("Compiled Code");
    }

    @Override
    public void error(SAXParseException e) throws SAXException {
        //compiled code
        throw new RuntimeException("Compiled Code");
    }

    @Override
    public void fatalError(SAXParseException e) throws SAXException {
        //compiled code
        throw new RuntimeException("Compiled Code");
    }
}