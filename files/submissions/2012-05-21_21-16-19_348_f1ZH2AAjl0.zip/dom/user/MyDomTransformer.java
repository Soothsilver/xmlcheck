package user;

import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * ZADANI: Seradit vzestupne media (elementy medium) podle roku vydani (elementu vydano).
 *         Odstranit media (vcetne podelementu), starsi jak 2000.
 *         Prevest atributy "role" v elementu "osoba" na elementy.
 */
public class MyDomTransformer {

    private Document doc = null;

    public void transform(Document xmlDocument) {

        doc = xmlDocument;

        sortMedium("vydani");
        deleteOldMedium(2000);
        convertAttributeToElement("role", "osoba");//atribut, element

    }

    /**
     * Radi elementy dle daneho elementu
     * vyuziva insertBefore
     * funguje podobne jako bubble sort
     * @param element 
     */
    public void sortMedium(String element) {
        boolean sorted = false;

        while (!sorted) {
            sorted = true;

            NodeList listMedium = doc.getElementsByTagName("medium");

            for (int i = 0; i < listMedium.getLength() - 1; i++) {
                Node medium1 = listMedium.item(i);
                Node medium2 = listMedium.item(i + 1);

                Element elmt1 = (Element) medium1;
                Element elmt2 = (Element) medium2;

                /*Prvni uzel*/

                NodeList vydaniElmtList1 = elmt1.getElementsByTagName(element); //Ziskani elementu
                Element vydaniElmt1 = (Element) vydaniElmtList1.item(0); //Mam jenom jednou
                NodeList vydani1 = vydaniElmt1.getChildNodes();

                /*Nasledujici uzel*/
                NodeList vydaniElmtList2 = elmt2.getElementsByTagName(element); //Ziskani elementu
                Element vydaniElmt2 = (Element) vydaniElmtList2.item(0); //Mam jenom jednou
                NodeList vydani2 = vydaniElmt2.getChildNodes();

                String hodnota1 = ((Node) vydani1.item(0)).getNodeValue();
                String hodnota2 = ((Node) vydani2.item(0)).getNodeValue();

                if (hodnota1.compareTo(hodnota2) > 0) {
                    medium1.getParentNode().insertBefore(medium2, medium1);
                    sorted = false;
                }
            }
        }
    }

    /**
     * Prevod atributu na elementy
     * @param attribute
     * @param element
     */
    public void convertAttributeToElement(String attribute, String element) {
        String content = "";

        /* Najde vsechny dany elementy */
        NodeList listOsoba = doc.getElementsByTagName(element);
        for (int i = 0; i < listOsoba.getLength(); i++) {
            /* Dany element osoba */
            Node osoba = listOsoba.item(i);
            if (osoba.getNodeType() == Node.ELEMENT_NODE) {
                Element elmt = (Element) osoba;

                content = elmt.getAttribute(attribute); //Ulozeni obsahu atributu
                elmt.removeAttribute(attribute); //Odstraneni atributu

                Element role = doc.createElement(attribute); //Vytvoreni noveho uzlu
                role.setTextContent(content); //Vlozeni obsahu
                osoba.appendChild(role); //Vlozeni uzlu do elementu osoba
            }
        }
    }

    /**
     * Delete old medium - cely element
     * Odstrani cely element medium, jehoz element vydani obsahuje starsi rok 
     * @param year
     */
    public void deleteOldMedium(int year) {
        /* Najde vsechny elementy medium */
        NodeList listMedium = doc.getElementsByTagName("medium");

        //Musim to delat opacne
        for (int i = listMedium.getLength() - 1; i >= 0; i--) {

            /* Dany element medium */
            Node medium = listMedium.item(i);
            if (medium.getNodeType() == Node.ELEMENT_NODE) {
                Element elmt = (Element) medium;
                NodeList vydaniElmtList = elmt.getElementsByTagName("vydani"); //Ziskani elementu vydani
                Element vydaniElmt = (Element) vydaniElmtList.item(0); //Mam jenom jednou
                NodeList vydani = vydaniElmt.getChildNodes();

                int result = Integer.parseInt(((Node) vydani.item(0)).getNodeValue());

                if (result <= year) {
                    medium.getParentNode().removeChild(medium);
                }
            }
        }
    }
}