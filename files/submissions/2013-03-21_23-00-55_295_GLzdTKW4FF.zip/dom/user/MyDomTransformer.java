package user;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

public class MyDomTransformer
{
    private static Document xmlDocument;
    
    public MyDomTransformer()
    {
        /*
        File fXmlFile = new File("E:\\documents\\ČVUT\\6.semestr\\A7B36XML\\ukoly\\2013\\ukol_02\\data.xml");
        
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        dbFactory.setValidating(false);
        
        DocumentBuilder dBuilder;
        
        try
        {
            dBuilder = dbFactory.newDocumentBuilder();
            xmlDocument = dBuilder.parse(fXmlFile);
        }
        catch(Exception e)
        {
            System.err.println(e.getMessage());
        }
        */
    }
    
    public static void main(String[] args)
    {
        /*
        MyDomTransformer transformer = new MyDomTransformer();
        transformer.transform(xmlDocument);
        */
    }
    
    public void transform (Document xmlDocument)
    {
        // libovolne transformace objektu 'xmlDocument'
        // (metoda pracuje primo na objektu, nic nevraci)
        xmlDocument.getDocumentElement().normalize();
        Element root = xmlDocument.getDocumentElement();
        
        // Pridani elementu auto se vsemi parametry.        
        Node listOfCars = root.getElementsByTagName("seznam-aut").item(0);
        
        Element newCar = xmlDocument.createElement("auto");
        newCar.setAttribute("id", "auto_4");
        listOfCars.appendChild(newCar);
        
        Element newVrp = xmlDocument.createElement("spz");
        newVrp.setTextContent("A88 20-20");
        newCar.appendChild(newVrp);
        
        Element newEngineType = xmlDocument.createElement("typ-motoru");
        newEngineType.setAttribute("typ", "naftovy");
        newCar.appendChild(newEngineType);
        
        Element newVendor = xmlDocument.createElement("vyrobce");
        newVendor.setTextContent("Skoda");
        newCar.appendChild(newVendor);
        
        Element newModel = xmlDocument.createElement("model");
        newModel.setTextContent("Octavia");
        newCar.appendChild(newModel);
        
        Element newAssambleYear = xmlDocument.createElement("vyrobeno");
        newCar.appendChild(newAssambleYear);
        
        Element newDay = xmlDocument.createElement("den");
        newDay.setTextContent("2");
        newAssambleYear.appendChild(newDay);
        
        Element newMonth = xmlDocument.createElement("mesic");
        newMonth.setTextContent("11");
        newAssambleYear.appendChild(newMonth);
        
        Element newYear = xmlDocument.createElement("rok");
        newYear.setTextContent("2010");
        newAssambleYear.appendChild(newYear);
        
        Element newCountry = xmlDocument.createElement("zeme");
        newAssambleYear.appendChild(newCountry);
        
        Element newCode = xmlDocument.createElement("kod");
        newCode.setTextContent("CZ");
        newCountry.appendChild(newCode);
        
        Element newCountryName = xmlDocument.createElement("nazev");
        newCountryName.setTextContent("Ceska republika");
        newCountry.appendChild(newCountryName);
        
        Element newColor = xmlDocument.createElement("barva");
        newColor.setTextContent("bila");
        newCar.appendChild(newColor);
        
        // Smazani vypujcek, kterej maji podelement <vypujcene-auto id="auto_2">
        Node listOfBorrowings = root.getElementsByTagName("seznam-vypujcek").item(0);
        
        NodeList borrowings = listOfBorrowings.getChildNodes();
        
        for(int i = 0; i < borrowings.getLength(); i++)
        {
            Node borrowing = borrowings.item(i);
            
            if(borrowing.getNodeType() == Node.ELEMENT_NODE)
            {
                //System.out.println(borrowing.getNodeName());
                
                NodeList borrowingChilds = borrowing.getChildNodes();
                
                for(int j = 0; j < borrowingChilds.getLength(); j++)
                {
                    Node borrowingChild = borrowingChilds.item(j);
                    
                    if(borrowingChild.getNodeType() == Node.ELEMENT_NODE && borrowingChild.getNodeName().equals("vypujcene-auto"))
                    {
                        //System.out.println(borrowingChild.getNodeName());
                            
                        NamedNodeMap attributes = borrowingChild.getAttributes();

                        for(int k = 0; k < attributes.getLength(); k++)
                        {
                            Node attribute = attributes.item(k);

                            if(attribute.getNodeType() == Node.ATTRIBUTE_NODE && attribute.getNodeValue().equals("auto_2"))
                            {
                                //System.out.println(attribute.getNodeName() +"="+ attribute.getNodeValue());
                                
                                listOfBorrowings.removeChild(borrowing);
                            }
                        }
                    }
                }
            }
        }
        
        
        // Ulozit vystup
        String outfile = "E:\\documents\\ČVUT\\6.semestr\\A7B36XML\\ukoly\\2013\\ukol_02\\data.out.xml";
        outfile = "data.out.xml";
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer writer;
        
        try
        {
            writer = tf.newTransformer();
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            writer.transform(new DOMSource(xmlDocument), new StreamResult(new File(outfile)));
        }
        catch(Exception e)
        {
            System.err.println(e.getMessage());
        }
    }
}