package user;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

public class MySaxHandler extends DefaultHandler
{
    Locator locator;
    
    private HashMap<String, Integer> mostCommonRentedCar = new HashMap<String, Integer>();
    private HashSet<String> carColors = new HashSet<String>();
    
    private boolean insideColor;
    
    private int differentLocation;
    
    private String pickupLocation;
    private String returnLocation;
    
    public static void main(String[] args)
    {
        /*
        SAXParserFactory factory = SAXParserFactory.newInstance();
        
        try
        {
            SAXParser saxParser = factory.newSAXParser();
            MySaxHandler handler = new MySaxHandler();
            saxParser.parse("data.xml", handler);
        }
        catch(Exception e)
        {
            System.err.println(e.getMessage());
        }
        */
        try
        {
            XMLReader parser = XMLReaderFactory.createXMLReader();
            InputSource source = new InputSource("data.xml");
            parser.setContentHandler(new MySaxHandler());
            parser.parse(source);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    public void setDocumentLocator(Locator locator)
    {
        this.locator = locator;
    }

    @Override
    public void startDocument() throws SAXException
    {   
    }
    
    @Override
    public void endDocument() throws SAXException
    {
        // 1) Nejcastejsi vypujcene auto?
        /* // Na PC funguje, v systemu XML pise "Cannot load external Java class". //
        Iterator it = mostCommonRentedCar.entrySet().iterator();
        String mostCommonRentedCarID = "";
        int mostCommonRentedCarCount = 0;
        
        while(it.hasNext())
        {
            Map.Entry<String, Integer> pairs = (Map.Entry<String, Integer>)it.next();
            
            if(pairs.getValue() > mostCommonRentedCarCount)
            {
                mostCommonRentedCarCount = pairs.getValue();
                mostCommonRentedCarID = pairs.getKey();
            }

            it.remove(); // avoids a ConcurrentModificationException
        }
        */
        String mostCommonRentedCarID = "";
        int mostCommonRentedCarCount = 0, count = 0;
        
        for(int i = 1; i <= 3; i++)
        {
             count = mostCommonRentedCar.get("auto_"+ i);
             
             if(mostCommonRentedCarCount < count)
             {
                 mostCommonRentedCarCount = count;
                 mostCommonRentedCarID = "auto_"+ i;
             }
        }
        
        System.out.println("Nejcastejsi vypujcene auto je auto s ID = "+mostCommonRentedCarID+" (vypujceno "+mostCommonRentedCarCount+"x).");
        
        // 2) Vsechny barvy nasich aut?
        Iterator it = carColors.iterator();
        StringBuilder sb = new StringBuilder();
        
        while(it.hasNext())
        {
            String color = (String) it.next();
            sb.append(color);
            
            if(it.hasNext())
                sb.append(", ");
        }
        
        System.out.println("Nabizime k pujceni auta v techto barvach: "+sb.toString()+".");
        
        // 3) Pocet vypujcek, ktere byly vyzvednuty a vraceny v ruznych mistech?
        System.out.println("Celkem bylo vypujceno "+differentLocation+" aut, ktere byly vraceny na jine misto, nez kde byly vyzvednuty.");
    }
        
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
    {
        if(qName.equals("vypujcene-auto"))
        {
            for(int i = 0; i < atts.getLength(); i++)
            {
                if(atts.getQName(i).equals("id"))
                {
                    if(!mostCommonRentedCar.containsKey(atts.getValue(i)))
                        mostCommonRentedCar.put(atts.getValue(i), 0);
                    
                    mostCommonRentedCar.put(atts.getValue(i), mostCommonRentedCar.get(atts.getValue(i)) + 1);
                }
            }
        }
        
        if(qName.equals("barva"))
            insideColor = true;
        
        if(qName.equals("kod-mista-vyzvednuti"))
            pickupLocation = atts.getValue(0);
        
        if(qName.equals("kod-mista-vraceni"))
        {
            returnLocation = atts.getValue(0);
            
            if(!pickupLocation.equals(returnLocation))
                ++differentLocation;
            
            pickupLocation = null;
            returnLocation = null;
        }
    }
    
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException
    {
        if(qName.equals("barva"))
            insideColor = false;
    }
   
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException
    {
        if(insideColor)
        {
            StringBuilder sb = new StringBuilder();
            
            for(int i = start; i < start + length; i++)
                sb.append(ch[i]);
            
            carColors.add(sb.toString());
        }
    }
    
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException
    {
    }

    @Override
    public void endPrefixMapping(String prefix) throws SAXException
    {
    }

    @Override
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException
    {
    }

    @Override
    public void processingInstruction(String target, String data) throws SAXException
    {
    }
 
    @Override
    public void skippedEntity(String name) throws SAXException
    {
    }
}