package domsax;

import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;

public class MySaxHandler {

    static int elementsWithArguments = 0;
    static int elementsWithoutArguments = 0;
    static int attributes = 0;
    public static void main(String[] args) {

        String sourcePath = "data.xml";

        try {
            
            XMLReader parser = XMLReaderFactory.createXMLReader();
            
            InputSource source = new InputSource(sourcePath);
            
            parser.setContentHandler(new SAXContentHandler());
            
            parser.parse(source);
            
        } catch (Exception e) {
        
            e.printStackTrace();
            
        }
        System.out.println("Celkovy pocet argumentu: " + MySaxHandler.attributes);
        System.out.println("Celkovy pocet elementu s argumenty: " + MySaxHandler.elementsWithArguments);
        if (MySaxHandler.elementsWithArguments > 0){
        	System.out.println("Prumerny pocet argumentu u elementu s argumenty: " + (double)(MySaxHandler.attributes)/MySaxHandler.elementsWithArguments);
        }
        System.out.println("Celkovy pocet elementu bez argumentu: " + MySaxHandler.elementsWithoutArguments);
        if (MySaxHandler.elementsWithoutArguments > 0){
        	System.out.println("Prumerny pocet argumentu u elementu bez argumentu: " + (double)(MySaxHandler.attributes)/MySaxHandler.elementsWithoutArguments);
        }
        
    }
    
}

class SAXContentHandler implements ContentHandler {

    Locator locator;
      
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }
   
    public void startDocument() throws SAXException {
        
    	// ...
        
    }
    
    public void endDocument() throws SAXException {
        
        // ...
        
    }
        
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
    	if(atts.getLength() > 0){
    		++MySaxHandler.elementsWithArguments;
    		MySaxHandler.attributes += atts.getLength();
    	}
    	else{
    		++MySaxHandler.elementsWithoutArguments;
    	}
        // ...

    }
    
    public void endElement(String uri, String localName, String qName) throws SAXException {
    	
        // ...

    }
                   
    public void characters(char[] ch, int start, int length) throws SAXException {
    }
        
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
        // ...
        
    }
  
    public void endPrefixMapping(String prefix) throws SAXException {
    
        // ...
    
    }
    
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
        // ...
        
    }
        
    public void processingInstruction(String target, String data) throws SAXException {
      
      // ...
            
    }
       
    public void skippedEntity(String name) throws SAXException {
    
      // ...
    
    }
}