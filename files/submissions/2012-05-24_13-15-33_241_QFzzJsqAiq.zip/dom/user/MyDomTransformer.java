package domsax;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

public class MyDomTransformer {

    private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "data.domout.xml";
    private static Document doc;

    public static void main(String[] args) {
        
        try {
            
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            dbf.setValidating(false);

            DocumentBuilder builder = dbf.newDocumentBuilder();

            Document doc = builder.parse(VSTUPNI_SOUBOR);

            processTree(doc);

            TransformerFactory tf = TransformerFactory.newInstance();

            Transformer writer = tf.newTransformer();

            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));
            

        } catch (Exception e) {
            
            e.printStackTrace();
            
        }
    }

    private static void processTree(Document doc) {
        Node n = doc.getFirstChild();
        MyDomTransformer.doc = doc;
        processNode(n);
    }
    private static void processNode(Node n){
    	if (n!= null){
    		if ((n.getNodeType() == Node.TEXT_NODE) && (n.getNodeValue().trim().length() > 0)){
    			Node a = MyDomTransformer.doc.createAttribute("textContent");
    			a.setNodeValue(n.getNodeValue());
    			n.getParentNode().getAttributes().setNamedItem(a);
    			n.getParentNode().removeChild(n);
    		}
	    	processNode(n.getFirstChild());
	    	processNode(n.getNextSibling());
    	}
    }
}
