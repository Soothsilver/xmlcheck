/*
 * Vypise maximalni,prumernou hloubku XML dokumentu
 * Vypise celkovy pocet elementu v dokumentu
 */

//package dom_sax;
package user;

/**
 *
 * @author ziber
 */
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
public class MySaxHandler extends DefaultHandler {
    // overrides of DefaultHandler methods }
    int maxHloubka;
    int aktualniHloubka;
    int pocetEl;
    List hloubky;

  
    @Override
    public void startDocument() throws SAXException {
        this.maxHloubka = 0;
        this.aktualniHloubka=0;
        this.pocetEl = 0;
        this.hloubky = new ArrayList<Integer>();
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        this.aktualniHloubka--;
        this.hloubky.add(this.aktualniHloubka);
    }





    @Override
    public void startElement(String namespaceURI, String localName, String qName, Attributes atts) throws SAXException {
            this.aktualniHloubka++;
            this.hloubky.add(this.aktualniHloubka);
            this.maxHloubka = this.aktualniHloubka;

            this.pocetEl++;
    }

    
    @Override
    public void endDocument() throws SAXException{
        int sumHloubky = 0;
        Iterator i=this.hloubky.iterator();
        while(i.hasNext()){
            int hloubka=(Integer)i.next();
            sumHloubky+=hloubka;
        }

        int prumer = (int)(sumHloubky/this.hloubky.size());
        System.out.println("Maximalni hloubka = " + this.maxHloubka);
        System.out.println("Pocet elementu = " + this.pocetEl);
        System.out.println("Prumerna hloubka = " + prumer);
    }


}