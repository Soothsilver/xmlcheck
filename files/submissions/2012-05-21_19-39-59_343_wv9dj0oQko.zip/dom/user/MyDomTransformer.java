/*
 * Prevede atributy elementu telefon na deti daneho elementu
 */

//package dom_sax;
package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
public class MyDomTransformer {
    public void transform (Document xmlDocument) {
    // code transforming xmlDocument object // (method works on the object itself - no return value)
         Element root = xmlDocument.getDocumentElement();
        
        NodeList telefony = root.getElementsByTagName("telefon");
		for(int i = 0; i < telefony.getLength(); i++){
			Element t = (Element)telefony.item(i);
			this.processAttributes(t,xmlDocument);
		}
    }

    public void processAttributes(Element el,Document doc){
               NamedNodeMap attrs=el.getAttributes();
               //Zamena obsahu elementu za element cislo
               String cisloText = el.getTextContent();
               System.out.println("cisloText = " + cisloText);
               Node obsah=el.getFirstChild();
               Element cisloEl=doc.createElement("cislo");
               cisloEl.setTextContent(cisloText);
               el.removeChild(obsah);
               el.appendChild(cisloEl);
               //zpracovani atributu
               if(attrs.getLength() != 0){
                    for (int i = 0; i < attrs.getLength(); i++) {
                        Node at = attrs.item(i);
                        String name=at.getNodeName();
                        String val=at.getNodeValue();
                        el.removeAttribute(name);
                        Element attrEl=doc.createElement(name);
                        attrEl.setTextContent(val);
                        el.appendChild(attrEl);
                        //el.appendChild(at)
                   }
               }

    }
}
