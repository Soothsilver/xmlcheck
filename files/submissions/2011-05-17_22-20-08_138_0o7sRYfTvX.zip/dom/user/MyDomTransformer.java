package user;
import org.w3c.dom.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
public class MyDomTransformer {
public void transform (Document xmlDocument) {
  for (int i=0;i<=xmlDocument.getElementsByTagName("motor").getLength();i++){
              Element n = (Element) xmlDocument.getElementsByTagName("motor").item(i);
  
              if (n!=null) {
                  Element spotreba = (Element) n.getElementsByTagName("spotreba").item(0);
                  Element objem = (Element) n.getElementsByTagName("objem").item(0);
                  Element maxrychlost = (Element) n.getElementsByTagName("maxrychlost").item(0);
                  
                  Element novyMotor = xmlDocument.createElement("motor");
                  
                  if (spotreba!=null){                    
                        novyMotor.setAttribute("spotreba", spotreba.getTextContent());
                  }
                  if (objem!=null){                    
                        novyMotor.setAttribute("objem", objem.getTextContent());
                  }
                  if (maxrychlost!=null){                    
                        novyMotor.setAttribute("maxrychlost", maxrychlost.getTextContent());
                  }
                  n.getParentNode().appendChild(novyMotor);
                  n.getParentNode().removeChild(n);
                  
              }
              
          }
  }
}