package user;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;
public class MySaxHandler extends DefaultHandler {
  
    
    Locator locator;
    double sum = 0;
    int n = 0;
    boolean vAute = false;
    boolean spotreba=false;
    
        
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

         
    public void endDocument() throws SAXException {
        
       System.out.print("Celkem "+n+" auta.\n");
       double avg = sum/n;
       System.out.print("Prumerna spotreba: "+avg+" l/100km\n");
        
    }
    
   
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        if (qName.equals("auto"))
            vAute=true;
        if (qName.equals("spotreba") && vAute){
            n++;
            spotreba=true;            
        }

    }
    
    public void endElement(String uri, String localName, String qName) throws SAXException {

        if (qName.equals("auto"))
            vAute=true;

    }
    
       
    public void characters(char[] ch, int start, int length) throws SAXException {

        if (spotreba){
            String cdata = new String(ch, start, length);
            sum += Double.parseDouble(cdata);
            
            spotreba=false;
        }
        
    }
    
}