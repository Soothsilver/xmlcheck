package user;
import org.w3c.dom.Document;
import org.w3c.dom.*;
public class MyDomTransformer 
{
public void transform (Document xmlDocument) 
{
   Element names = xmlDocument.createElement("names");
   
   for(Node loc = xmlDocument.getDocumentElement().getFirstChild(); loc != null; loc=loc.getNextSibling())
   {
	   if (loc.getNodeName() == "location")
	   {
		   for (Node animal = loc.getFirstChild(); animal != null; animal = animal.getNextSibling())
		   {
			   if (animal.getNodeName() == "animal")
			   {
				   Element name = xmlDocument.createElement("name");
				   name.setTextContent(((Element)animal).getAttribute("name"));
				   names.appendChild(name);
			   }
		   }
	   }
   }
   
   xmlDocument.getDocumentElement().appendChild(names);
  }
}