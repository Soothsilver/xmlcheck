package user;

import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;


/**
 * N� vlastn� content handler pro obsluhu SAX ud�lost�.
 * Implementuje metody interface ContentHandler. 
 */ 
public class MySaxHandler extends DefaultHandler {

    
    /** Po�et element� */
    int elementCount = 0;
    /** Sou�et d�lek n�zv� element� */
    double elementSumOfLength = 0;
    
    /**
     * Obsluha ud�losti "za��tek dokumentu"
     */     
    public void startDocument() throws SAXException {
        elementCount=0;
        elementSumOfLength=0;
    }
    /**
     * Obsluha ud�losti "konec dokumentu"
     */     
    public void endDocument() throws SAXException {
        System.out.println("Pr�m�rn� d�lka n�zv� element�: " + (elementSumOfLength / elementCount));
    }
    
    /**
     * Obsluha ud�losti "za��tek elementu".
     * @param uri URI jmenn�ho prostoru elementu (pr�zdn�, pokud element nen� v ��dn�m jmenn�m prostoru)
     * @param localName Lok�ln� jm�no elementu (v�dy nepr�zdn�)
     * @param qName Kvalifikovan� jm�no (tj. prefix-uri + ':' + localName, pokud je element v n�jak�m jmenn�m prostoru, nebo localName, pokud element nen� v ��dn�m jmenn�m prostoru)
     * @param atts Atributy elementu     
     */     
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
    	elementCount++;
    	elementSumOfLength+=localName.length();
    }
    
}