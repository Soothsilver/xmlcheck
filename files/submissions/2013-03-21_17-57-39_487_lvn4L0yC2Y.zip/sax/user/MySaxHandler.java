package user;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {

	private int bookRecordsCount = 0;
	private int editionNumberSum = 0;
	private int booksCount = 0;
	private int booksPresent = 0;
	private int bookPlacedRowSum = 0;
	private int borrowedBooksNotInDepoCount = 0;
	
	
	private String EDITION_NUM = "editionNum";
	private String PRINTS_IN_LIB = "printsInLib";
	private String BOOK = "book";
	private String PRESENT = "present";
	private String ROW = "row";
	private String DEPO = "depositary";
	private String BORROWED = "borrowed";
	
	private boolean editionNum = false; 
	private boolean printsInLib = false;
	
	private boolean bookBorrowed = false;
	private boolean bookInDepo = false;

    public void endDocument() throws SAXException {
        System.out.println("books count: "+booksCount);
        System.out.println("edition number mean: "+(bookRecordsCount == 0 ? 0 : editionNumberSum/bookRecordsCount));
        System.out.println("books placed in library near to row: "+(booksPresent == 0 ? 0 : bookPlacedRowSum/booksPresent));
        System.out.println("borrowed books that are not in depositary: "+borrowedBooksNotInDepoCount);
    }
    
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
    	if(localName.equals(BOOK)) {
    		++bookRecordsCount;
    	} else if(localName.equals(EDITION_NUM)) {
    		editionNum = true; 
    	} else if(localName.equals(PRINTS_IN_LIB)) {
    		printsInLib = true;
    	} else  if(localName.equals(PRESENT)) {
    		++booksPresent;
    		bookPlacedRowSum += Integer.parseInt(atts.getValue(ROW));
    	} else if(localName.equals(BORROWED)) {
    		bookBorrowed = true;
    	} else if(localName.equals(DEPO)) {
    		bookInDepo = true;
    	}
    		 
        
    }
    
    public void endElement(String uri, String localName, String qName) throws SAXException {
    	
    	if(localName.equals(BOOK)) {
    		if(bookBorrowed && !bookInDepo) {
    			++borrowedBooksNotInDepoCount;
    		}
        	bookBorrowed = false;
            bookInDepo = false;
    	}
    	
        editionNum = false;
        printsInLib = false;
    }

    public void characters(char[] chars, int start, int length) throws SAXException {
    	String a = new String(chars, start, length);
    	if(editionNum) {
    		editionNumberSum += Integer.parseInt(a);
    	} else if(printsInLib) {
    		booksCount += Integer.parseInt(a);
    	}
    }
}
