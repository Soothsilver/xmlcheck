package user;

//import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

//import javax.xml.parsers.DocumentBuilder;
//import javax.xml.parsers.DocumentBuilderFactory;
//import javax.xml.transform.OutputKeys;
//import javax.xml.transform.Transformer;
//import javax.xml.transform.TransformerFactory;
//import javax.xml.transform.dom.DOMSource;
//import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

/**
 * ASSIGNMENT: Update document to be able to transform input XML document to
 * output document by actions mentioned in comments of processTree method.
 */
public class MyDomTransformer {

    private static final String INPUT_FILE = "data.xml";
    private static final String OUTPUT_FILE = "data.out.xml";
    
    
    private static final String LIBRARY = "library";
	private static final String BOOK = "book";
	private static final String YEAR = "year";
	private static final String CZECH = "czech"; 
	private static final String LANGUAGE = "language";

    /**
     * Main method
     *
     * @param args command line arguments
     */
    /*public static void main(String[] args) {

        try {

            // DocumentBuilderFactory creates DOM parsers
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            // We don't want to validate file
            dbf.setValidating(false);

            // Creating of DOM parser instance
            DocumentBuilder builder = dbf.newDocumentBuilder();

            // Parser processes input file and creates a DOM tree of objects
            Document doc = builder.parse(INPUT_FILE);

            // DOM tree processing
            new MyDomTransformer().transform(doc);

            // TransformerFactory creates an object for DOM serialization
            TransformerFactory tf = TransformerFactory.newInstance();

            // Transformer serializes DOM tree
            Transformer writer = tf.newTransformer();

            // Setting of output file encoding
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            // Run transformation of DOM tree to XML document
            writer.transform(new DOMSource(doc), new StreamResult(new File(OUTPUT_FILE)));


        } catch (Exception e) {

            e.printStackTrace();

        }
    }*/

    /**
     * Process document tree
     *
     * @param doc Document to be parsed
     */
    public void transform (Document doc) {
        MyDomTransformer instance = new MyDomTransformer();
        
        instance.sortBooks(doc);
        instance.removeNonCzechBooks(doc);
    }
	
	
	/**
	 * Sorts all books by year, at which they were published.
	 */
	private void sortBooks(Document doc) {
		
		//prepare
		Element books = (Element) doc.getElementsByTagName(LIBRARY).item(0);
		List<Element> booksContainer = new ArrayList<Element>();
		
		//load books to container and remove them from document
		NodeList bookList = getDescendantList(BOOK, books);
		for(int i=0; i<bookList.getLength();) {
			Element book = (Element) bookList.item(i);
			booksContainer.add(book);
			books.removeChild(book);
		}		
		
		//sort
		Comparator<Element> comparator = new Comparator<Element>() {
			public int compare(Element o1, Element o2) {

				int o1Year = getBookPublishYear((Element)o1);
				int o2Year = getBookPublishYear((Element)o2);
				
				return o1Year - o2Year;
				
			}
		};
		Collections.sort(booksContainer, comparator);
		Iterator<Element> it = booksContainer.iterator();
		
		//put books back to the document sorted
		while(it.hasNext()) {
			Element e = it.next();
			books.appendChild(e);
		}
	}
	
	private int getBookPublishYear(Element book) {
		Node year = getDescendantElement(YEAR, book);
		
		if(year == null)
			return 0;
		return Integer.parseInt(year.getTextContent());
	}
	
	
	/**
	 * Removes all books, that do not have language element with value "czech".
	 */
	public void removeNonCzechBooks(Document doc) {
		
		Element library = (Element) doc.getElementsByTagName(LIBRARY).item(0);
		NodeList bookList = getDescendantList(BOOK, library);
		
		for(int i=0; i< bookList.getLength(); ++i) {
			Element book = (Element)bookList.item(i);
			if(!getBookLanguage(book).equals(CZECH)) {
				library.removeChild(book);
				--i;
			}
		}
	}
	
	private String getBookLanguage(Element book) {
		Node language = getDescendantElement(LANGUAGE, book);
		
		if(language == null)
			return "";
		return language.getTextContent();
	}
	
	private Node getDescendantElement(String name, Element parent) {
		NodeList children = parent.getElementsByTagName(name);
		return children.item(0);
	}
	
	private NodeList getDescendantList(String name, Element parent) {
		return parent.getElementsByTagName(name);
	}
}
