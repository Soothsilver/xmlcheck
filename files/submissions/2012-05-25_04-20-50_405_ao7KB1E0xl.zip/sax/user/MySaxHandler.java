package user;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 *
 * @author Jiri Tomes
 */
public class MySaxHandler extends DefaultHandler {

    /* Pro kazdeho udalost na sazence se vypise podle zvoleneho kurzu na co se vsadilo
     * a jaky byl prumerny kurz z nabizenych kurzu na tuto udalost
     */
    final String UDALOST="udalost";
    boolean udalost=false;

    boolean domaci=false;
    boolean hoste=false;
    boolean remiza=false;
    boolean vyhra=false;
    boolean neprohra=false;
    boolean vybranykurz=false;

    Map<String,String> mapa;
    Udalost aktualni;
    Queue<Udalost> udalosti=new LinkedList<Udalost>();


    public static void main(String[] args)
    {
        // Cesta ke zdrojovému XML dokumentu
        final String VSTUP = "data.xml";

        try
        {

            // Vytvoríme instanci parseru.
            XMLReader parser = XMLReaderFactory.createXMLReader();

            // Vytvoríme vstupní proud XML dat.
            InputSource source = new InputSource( VSTUP);

            // Nastavíme náą vlastní content handler pro obsluhu SAX událostí.
            parser.setContentHandler(new MySaxHandler());

            // Zpracujeme vstupní proud XML dat.
            parser.parse(source);

        }
        catch (Exception e)
        {

           e.printStackTrace();

        }
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException
    {
        if (udalost)
        {
            if (remiza)
            {
                
                String slovo=VratSlovo(ch, start, length);
                ZpracujHodnotu(slovo,"remiza");

            }
            if (domaci)
            {
                if (vyhra)
                {
                    String slovo=VratSlovo(ch, start, length);
                    ZpracujHodnotu(slovo, "vyhra domacich");
                }
                if (neprohra)
                {
                    String slovo=VratSlovo(ch, start, length);
                    ZpracujHodnotu(slovo, "neproha domacich");
                }

            }
            if (hoste)
            {
                if (vyhra)
                {
                    String slovo=VratSlovo(ch, start, length);
                    ZpracujHodnotu(slovo, "vyhra hostu");
                }

                if (neprohra)
                {
                    String slovo=VratSlovo(ch, start, length);
                    ZpracujHodnotu(slovo, "neprohra hostu");
                }
            }
            if (vybranykurz)
            {
                String slovo=VratSlovo(ch, start, length);
                double kurz=Double.valueOf(slovo);
                aktualni.NastavZvoleno(kurz);

            }
        }
    }

    private void ZpracujHodnotu(String slovo,String typ)
    {
        double hodnota=Double.valueOf(slovo);
        aktualni.PridejHodnotu(hodnota, typ);

    }

    private String VratSlovo(char[]ch,int start,int delka)
    {
        StringBuilder sb=new StringBuilder();

        for (int i=start;i<start+delka;i++)
        {
            sb.append(ch[i]);
        }

        return sb.toString();
    }


    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException
    {
        if (qName.equals(UDALOST))
        {
            udalost=true;

            for (int i=0;i<attributes.getLength();i++)
            {
                String name=attributes.getQName(i);
                String value=attributes.getValue(i);

                mapa=new HashMap<String,String>();
                mapa.put(name, value);
            }
            aktualni=new Udalost(mapa);
            udalosti.add(aktualni);
            

        }
        if (qName.equals("domaci") &&udalost)
        {
            domaci=true;
        }

        if (qName.equals("hoste") &&udalost) hoste=true;
        if (qName.equals("vyhra")) vyhra=true;
        if (qName.equals("neprohra")) neprohra=true;
        if (qName.equals("remiza")) remiza=true;
        if (qName.equals("zvoleny_kurz")) vybranykurz=true;

    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException
    {
        if (qName.equals(UDALOST))
        {
            udalost=false;
            
        }

        if (qName.equals("domaci")) domaci=false;
        if (qName.equals("hoste")) hoste=false;
        if (qName.equals("vyhra")) vyhra=false;
        if (qName.equals("neprohra")) neprohra=false;
        if (qName.equals("remiza")) remiza=false;
        if (qName.equals("zvoleny_kurz")) vybranykurz=false;
    }

    @Override
    public void endDocument() throws SAXException
    {
        VypisVysledky();
    }
    private void VypisVysledky()
    {
       System.out.println("Vysledky - seznam udalosti:");

       while (!udalosti.isEmpty())
       {
           Udalost dalsi=udalosti.poll();

           String id=dalsi.VratJmenoID();
           String sazka_na=dalsi.VratTypKurzu();

           double prumerny_kurz=dalsi.VratPrumer();


           System.out.println("<udalost "+id+">");
           System.out.println("<vsadilo_se_na> "+sazka_na+" </vsadilo_se_na>");
           System.out.println("<prumerny_kurz> "+String.valueOf(prumerny_kurz)+" </prumerny_kurz>");
           System.out.println();

       }
    }

class Udalost
{
   Map<String,String> mapa;
   List<HodnotaTyp>hodnoty=new ArrayList<HodnotaTyp>();
   double kurzzvolen=Double.NaN;



   public Udalost(Map<String,String> mapa)
   {
       this.mapa=mapa;
   }
   public void PridejHodnotu(double hodnota,String typ)
   {
       HodnotaTyp ht=new HodnotaTyp(hodnota, typ);
       hodnoty.add(ht);

   }
   public void NastavZvoleno(double zvolenkurz)
   {
       kurzzvolen=zvolenkurz;
   }

   public double VratPrumer()
   {
       if (hodnoty.isEmpty())
       {
           return 1.0;
       }
       else
       {
           double kolik=(double)hodnoty.size();
           double soucet=0.0;

           for (HodnotaTyp dalsi:hodnoty)
           {
                soucet+=dalsi.VratHodnotu();
           }

           double mezi=soucet/kolik;
           double vysledek=Math.round(mezi*100.0)/100.0;

           return vysledek;
       }
   }

   public String VratJmenoID()
   {
       StringBuilder sb=new StringBuilder();
       for (String dalsi:mapa.keySet())
       {
           sb.append(dalsi+"=");
           sb.append(mapa.get(dalsi));
       }
       sb.append("");

       return sb.toString();
   }

   public String VratTypKurzu()
   {
       StringBuilder vysledek=new StringBuilder("Zadny typ z nabizenych nevyhovuje");

       for (HodnotaTyp ht:hodnoty)
       {
           double hodnota=ht.VratHodnotu();
           if (hodnota==kurzzvolen)
           {
               String typ=ht.VratTyp();
               vysledek=new StringBuilder(typ);
               break;
           }
       }

       return vysledek.toString();
   }

}

class HodnotaTyp
{
    double hodnota;
    String typ;

    public HodnotaTyp(double hodnota, String typ)
    {
        this.hodnota = hodnota;
        this.typ = typ;
    }

    public double VratHodnotu()
    {
        return hodnota;
    }

    public String VratTyp()
    {
        return typ;
    }


}






}
