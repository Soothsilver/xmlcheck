package user;

import java.io.File;
import java.util.Stack;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Attr;

/**
 *
 * @author Jiri Tomes
 */
public class MyDomTransformer
{
    private final static String VSTUP = "data.xml";
    private final static String VYSTUP = "data.out.xml";

    public static void main(String[] args)
    {
        try
        {
        //DocumentBuilderFactory vytváří DOM parsery
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        //nebudeme validovat
        dbf.setValidating(false);

        //vytvoříme si DOM parser
        DocumentBuilder builder = dbf.newDocumentBuilder();

        //parser zpracuje vstupní soubor a vytvoří z něj strom DOM objektů
        Document doc = builder.parse(VSTUP);

        //zpracujeme DOM strom
        transform(doc);

        //TransformerFactory vytváří serializátory DOM stromů
        TransformerFactory tf = TransformerFactory.newInstance();

        //Transformer serializuje DOM stromy
        Transformer writer = tf.newTransformer();

        //nastavíme kodování
        writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

        //spustíme transformaci DOM stromu do XML dokumentu

        DOMSource zdroj=new DOMSource(doc);
        StreamResult cil=new StreamResult(new File(VYSTUP));

        writer.transform(zdroj,cil);


        }

        catch (Exception e)
        {
           System.err.println(e.getMessage());
        }
    }
    

    public static void transform(Document xmlDocument)
    {
        // code transforming xmlDocument object
        UdalostSoutez(xmlDocument);
        ObratDatum(xmlDocument);
        VycistiAtributyKorene(xmlDocument);
    }

    private static void UdalostSoutez(Document doc)
    {
        /* Z kazde udalosti slouci obsah elementu <typ_udalosti> a <typ_souteze>
         * do noveho elementu <typ_udalost-soutez> (puvodni zaniknout)
         *
         * priklad:
         * Z elementu:
         * <typ_udalosti>hokej</typ_udalosti>
         * <typ_souteze>extraliga</typ_souteze>
         *
         * vznikne:
         * <typ_udalost-soutez>hokej-extraliga</typ_udalost-soutez>
         */

        NodeList udalosti=doc.getElementsByTagName("udalost");

        for (int i=0;i<udalosti.getLength();i++)
        {
            Element udalost=(Element)udalosti.item(i);
            
            
            NodeList typ_udalosti=udalost.getElementsByTagName("typ_udalosti");
            NodeList typ_souteze=udalost.getElementsByTagName("typ_souteze");

            int kolik1=typ_udalosti.getLength();
            int kolik2=typ_souteze.getLength();

            if (kolik1==kolik2)
            {
                for (int j=0;j<kolik1;j++)
                {
                    Node event=typ_udalosti.item(j);
                    Node contest=typ_souteze.item(j);

                    String eventValue=event.getTextContent();
                    String contestValue=contest.getTextContent();

                    //element <typ_souteze> vymazeme
                    udalost.removeChild(contest);

                    Element element=doc.createElement("typ_udalost-soutez");
                    String value=eventValue+"-"+contestValue;
                    element.appendChild(doc.createTextNode(value));

                    //element <typ_udalosti> nahradime za novy <typ_udalost-soutez>
                    udalost.replaceChild(element, event);

                }
            }
           

        }

    }

    private static void ObratDatum(Document doc)
    {
        /*
         * Obrati poradi podelementu u elemetu <datum>
         * Z <den><mesic><rok> na <rok><mesic><den>
         */

        NodeList datumy=doc.getElementsByTagName("datum");

        for (int i=0;i<datumy.getLength();i++)
        {
            Element datum=(Element)datumy.item(i);

            //vytvorime si zasobnik na elementy pro datum
            Stack<Node> zasobnik=new Stack<Node>();

            while(datum.hasChildNodes())
            {
                //elementy postupne odebirame a pridavame do zasobniku
                Node dite=datum.getFirstChild();
                zasobnik.add(dite);
                datum.removeChild(dite);
            }

            while (!zasobnik.empty())
            {
                //ze zasobniku postavime novou obracenou strukturu
                Node dalsi=zasobnik.pop();
                datum.appendChild(dalsi);
            }
        }
    }

    private static void VycistiAtributyKorene(Document doc)
    {
      /* Korenovy element <sazkova_kancelar>
       * vycisti od vsech atributu (v puvodnim pro pripojeni DTD ci XML schema)
       * Schema noveho dokumentu se jiz zmenilo - dosavadni nebude vyhovovat,
       * proto jej touto procedurou odstranime
       */

      Element koren=doc.getDocumentElement();

      int kolik=koren.getAttributes().getLength();

      for (int i=0;i<kolik;i++)
      {
         Attr atribut=(Attr)koren.getAttributes().item(0);
         koren.removeAttribute(atribut.getName());
      }
    }



}
