/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import java.util.ArrayList;

public class MySaxHandler extends DefaultHandler {

    /**
     * Represents the statistics of series X minisieris, whre
     * typeOfSeriesArray[0] represents amount of series and typeOfSeriesArray[1]
     * represents amount of miniseries.
     */
    public int typeOfSeriesArray[] = new int[2];
    /**
     * Represents an array in which the ganres and number of their occurances is
     * stored.
     */
    public static ArrayList<Pair<String, Integer>> genres = new ArrayList<>();
    /**
     * Decides wheter weare currently in element genre.
     */
    public boolean genreFlag = false;
    /**
     * Used to count all neccesery conditions to determine, wheter the serie has
     * english dubbing and is longer then 30 miutes.
     */
    public int correctSeriesCounter = 0;
    /**
     * Used to store names of series with english dubbing and longer than 30
     * minutes.
     */
    public static ArrayList<String> titles = new ArrayList<>();
    /**
     * Used to store title of series, should it be eventualy considered as worth
     * saving to titles.
     */
    public String titleTMP = "";
    public String lastString = "";
    Locator locator;

    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    @Override
    public void startDocument() throws SAXException {
    }

    @Override
    public void endDocument() throws SAXException {
        printSeriesMiniseriesStatistics();
        System.out.println("");
        printGenresStatistic();
        System.out.println("");
        printSeriesStatistics();
    }

    /**
     * Used to print statistics of series at the end of program.
     */
    private void printSeriesMiniseriesStatistics() {
        System.out.println("SERIES VS. MINISERIES STATISTICS");
        System.out.println("------------------------------------------------");
        System.out.printf("%-16s %15s %15s%n", "", "Abs. occurance", "Rel. occurance");
        System.out.printf("%-16s %15d %15.2f%n", "Series", typeOfSeriesArray[0], (double) typeOfSeriesArray[0] / (double) (typeOfSeriesArray[0] + typeOfSeriesArray[1]));
        System.out.printf("%-16s %15d %15.2f%n", "Minisieries", typeOfSeriesArray[1], (double) typeOfSeriesArray[1] / (double) (typeOfSeriesArray[0] + typeOfSeriesArray[1]));
        System.out.printf("%-16s %15d %15.2f%n", "Sereies overall", (typeOfSeriesArray[0] + typeOfSeriesArray[1]), (double) (typeOfSeriesArray[0] + typeOfSeriesArray[1]) / (long) (typeOfSeriesArray[0] + typeOfSeriesArray[1]));
    }

    /**
     * Used to print the most frequent genre and statistic of other genres.
     */
    private void printGenresStatistic() {
        System.out.println("GENRE STATISTICS");
        Pair<String, Integer> max = new Pair<>("no genres", -1);
        for (Pair<String, Integer> p : genres) {
            max = max.getValue() < p.getValue() ? p : max;
        }
        System.out.println("The most favourite genre is " + max.getKey() + ". It has occured " + max.getValue() + " times.");
        for (Pair<String, Integer> p : genres) {
            System.out.print(p.getKey() + "(" + p.getValue() + ") ");
        }
        System.out.println("");
    }

    /**
     * Prints the list of series, which has english dubbing and are longer than 30 minutes.
     */
    private void printSeriesStatistics() {
        System.out.println("SERIES LIST (LENGTH >= 30 min, DUBBING = ENGLISH, BOTH MUST BE SPECIFIED IN XML DOCUMENT FOR CHOSEN ELEMENT)");
        for (int i = 0; i < titles.size(); i++) {
            System.out.println((i + 1) + ") " + titles.get(i));
        }
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if (localName.equals("serie")) {
            String value = atts.getValue("miniserie");
            if (value.equals("yes")) {
                typeOfSeriesArray[1]++;
            } else {
                typeOfSeriesArray[0]++;
            }
        }
        if (localName.equals("genre")) {
            genreFlag = true;
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (localName.equals("title")) {
            titleTMP = lastString;
        }
        if (localName.equals("dubbing")) {
            if (lastString.equals("English")) {
                correctSeriesCounter++;
            }
        }
        if (localName.equals("length")) {
            if (Integer.parseInt(lastString) >= 30) {
                correctSeriesCounter++;
            }
        }
        if (localName.equals("serie")) {
            if (correctSeriesCounter == 2) {
                titles.add(titleTMP);
            }
            titleTMP = "";
            correctSeriesCounter = 0;
        }
    }

    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        String name = "";
        for (int i = start; i < start + length; i++) {
            name += chars[i];
        }
        if (genreFlag) {
            for (Pair<String, Integer> p : genres) {
                if (p.getKey().equals(name)) {
                    int tmp = p.getValue() + 1;
                    p.setValue(tmp);
                    genreFlag = false;
                    return;
                }
            }
            genres.add(new Pair<>(name, 1));
            genreFlag = false;
        }
        lastString = name;
    }

    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
    }

    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
    }

    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
    }

    @Override
    public void processingInstruction(String target, String data) throws SAXException {
    }

    @Override
    public void skippedEntity(String name) throws SAXException {
    }

    /**
     * Class used to store genres.
     *
     * @param <K> Object representing key
     * @param <V> Object representing number of occurances
     */
    protected class Pair<K, V> {

        K key;
        V value;

        public Pair(K key, V value) {
            this.key = key;
            this.value = value;
        }

        public K getKey() {
            return key;
        }

        public V getValue() {
            return value;
        }

        public void setValue(V v) {
            value = v;
        }
    }
}