/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import org.w3c.dom.*;

import org.w3c.dom.Document;

public class MyDomTransformer {

    public void transform(Document xmlDocument) {
        
        /*
         * Creation of new elemet serie.
         */
        Element genres = xmlDocument.createElement("genres");
        genres.appendChild(xmlDocument.createElement("genre")).setTextContent("comedy");
        genres.appendChild(xmlDocument.createElement("genre")).setTextContent("drama");

        Element episodes = xmlDocument.createElement("episodes");
        ((Element) episodes.appendChild(xmlDocument.createElement("episode"))).setAttribute("number", "1");
        ((Element) episodes.appendChild(xmlDocument.createElement("episode"))).setAttribute("number", "2");
        ((Element) episodes.appendChild(xmlDocument.createElement("episode"))).setAttribute("number", "3");

        Element season = xmlDocument.createElement("season");
        season.setAttribute("number", "1");
        season.appendChild(episodes);

        Element seasons = xmlDocument.createElement("seasons");
        seasons.appendChild(season);

        Element serie = xmlDocument.createElement("serie");
        serie.setAttribute("id", "s15");
        serie.appendChild(xmlDocument.createElement("title")).setTextContent("Suburgatory");
        serie.appendChild(xmlDocument.createElement("dubbing")).setTextContent("&engL;");
        serie.appendChild(xmlDocument.createElement("country_of_origin")).setTextContent("&usa;");
        serie.appendChild(xmlDocument.createElement("length")).setTextContent("20");
        serie.appendChild(genres);
        serie.appendChild(seasons);
        NodeList list = xmlDocument.getElementsByTagName("series");
        list.item(0).appendChild(serie);

        /*
         * Removes all series, which have more then one season.
         */
        NodeList serieList = xmlDocument.getElementsByTagName("serie");
        for (int i = serieList.getLength() - 1; i >= 0; i--) {
            NodeList childs = serieList.item(i).getChildNodes();
            for (int j = 0; j < childs.getLength(); j++) {
                if (childs.item(j).getNodeName().equals("seasons")) {
                    NodeList seasonsList = childs.item(j).getChildNodes();
                    int counter = 0;
                    for (int k = 0; k < seasonsList.getLength(); k++) {
                        if (seasonsList.item(k).getNodeName().charAt(0) != '#') {
                            counter++;
                        }
                    }
                    if (counter >= 2) {
                        serieList.item(i).getParentNode().removeChild(serieList.item(i));
                        break;
                    }
                }

            }

        }

        }
}

