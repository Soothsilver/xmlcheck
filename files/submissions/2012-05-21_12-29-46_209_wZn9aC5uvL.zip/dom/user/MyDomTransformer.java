package user;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

/*
class MainDom{
    public static void main(String[] args) {
        MyDomTransformer mdt=new MyDomTransformer();
        mdt.load();
    }
}
*/

public class MyDomTransformer {

    private static final String IN="data.xml";
    private static final String OUT="data.out.xml";

    public void load() {
        
        try {           
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();      //DocumentBuilderFactory vytváří DOM parsery
            dbf.setValidating(false);                                               //zakazani validace
            DocumentBuilder builder=dbf.newDocumentBuilder();                 	    //vytvoreni DOM parseru           
            Document doc=builder.parse(IN);                                   	    //zpracovani vstupniho souboru a vytvoreni stromu DOM objektu
 
            transform(doc);                                             

            TransformerFactory tf=TransformerFactory.newInstance();           	    //TransformerFactory vytváří serializátory DOM stromů
            Transformer writer=tf.newTransformer();                           	    //Transformer serializuje DOM stromy
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");                 //nastaveni kodovani           
            writer.transform(new DOMSource(doc), new StreamResult(new File(OUT)));  //spusteni transformaci DOM stromu do XML dokumentu
        } catch (Exception e) {
            System.err.println(e);
        }
    }
    
    public void transform(Document xmlDocument){
        NodeList n=xmlDocument.getElementsByTagName("*");                       //vybere vsechny elementy
        String content;                                                         //pomocna promenna
        String atrib;                                                         	//pomocna promenna
        for(int i=0; i<n.getLength(); i++){
            if(n.item(i).hasAttributes() && !n.item(i).hasChildNodes()){        //kontrola jestli element obsahuje atributy
                content=n.item(i).getAttributes().item(0).getTextContent();     //vezme prvni atribut a ulozi jeho hodnotu
                atrib=n.item(i).getAttributes().item(0).getNodeName();
                n.item(i).setTextContent(content);                              //nastavi elemntu hodnotu
                n.item(i).getAttributes().removeNamedItem(atrib);               //odstrani atribut id
                 
                //System.out.println("element "+n.item(i).getNodeName()+" byl zmenen");
            }
        }
    }
}