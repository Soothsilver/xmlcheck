package user;

import org.xml.sax.helpers.DefaultHandler;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.*;
import java.util.*;

/*
class MainSax {    
    public static void main(String[] args) {
        String filename = "data.xml";
        
        try {            
            SAXParserFactory spfactory = SAXParserFactory.newInstance();
            spfactory.setValidating(false);
            
            SAXParser saxparser = spfactory.newSAXParser();
            
            XMLReader xmlreader = saxparser.getXMLReader();
            
            xmlreader.setContentHandler(new MySaxHandler());
            xmlreader.setErrorHandler(new MySaxHandler());
            
            InputSource source = new InputSource(filename);
            xmlreader.parse(source);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
*/

public class MySaxHandler extends DefaultHandler {
    int numElements = 0;
    int numAttributes = 0;
    int depth = 0;
    int maxDepth = 0;
    int minDepth = 1000;
    int averageDepth = 0;
    Map<String, Integer> attributes;
    Map<String, Integer> elements;
    ArrayList<String> names;
	
    public MySaxHandler() {
        
    }
    
     public void showEvent(String s) {
        System.out.println("show: " + s);
    }

    /**
     * zacatek documentu
     *
     */
    @Override
    public void startDocument() throws SAXException {
        attributes = new HashMap<String, Integer>();
        elements = new HashMap<String, Integer>();
        names = new ArrayList<String>();
    }

    /**
     * zacatek elementu
     */
    @Override
    public void startElement(String namespaceURI, String localName, String qName, Attributes atts) throws SAXException {
        numElements++;
        depth++;
        numAttributes += atts.getLength();
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if(depth>maxDepth) {
            maxDepth=depth;
        }
        if(depth<minDepth) {
            minDepth=depth;
        }
        averageDepth+=depth;
        depth--;
    }

    /**
     * konec dokumentu
     */
    @Override
    public void endDocument() throws SAXException {
        averageDepth = averageDepth / numElements;

        System.out.println("Statistika: ");
        System.out.println("Prumerna hloubka: " + averageDepth);
        System.out.println("Maximalni hloubka: " + maxDepth);
        System.out.println("Minimalni hloubka: " + minDepth);
        
        System.out.println("");
        System.out.println("Celkovy pocet elementu: " + numElements);
        System.out.println("Celkovy pocet attributu: " + numAttributes);
        System.out.println("");
    }

    /**
     * chyba
     */
    @Override
    public void error(SAXParseException e) {
        System.out.println("SAXParseException: error");
        e.printStackTrace();
    }

    /**
     * varovani
     */
    @Override
    public void warning(SAXParseException e) {
        System.out.println("SAXParseException: warning");
        e.printStackTrace();
    }

    /**
     * selhani
     */
    @Override
    public void fatalError(SAXParseException e) {
        System.out.println("SAXParseException: fatal error");
        System.exit(1);
    }
}