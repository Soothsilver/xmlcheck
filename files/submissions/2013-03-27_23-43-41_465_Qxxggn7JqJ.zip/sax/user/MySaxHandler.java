package user;

import java.util.HashMap;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

public class MySaxHandler extends DefaultHandler {
	  // override metod DefaultHandleru
	/*class Autor {
	       String name;
	   }*/
	
	HashMap<String, Integer> Autori = new HashMap<String, Integer>();
	Locator locator;
	int MamDomaCizich = 0;
	String currentElementName;
	String autor;
	
	@Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }
	
	@Override
    public void startDocument() throws SAXException {
        MamDomaCizich = 0;
        autor = "";
    }
	
	@Override
    public void endDocument() throws SAXException {
        System.out.println("Ciz�ch knih v knihovn� je - " + MamDomaCizich);
        
        String vypis = "";
        int highest = 0;
        for(String s : Autori.keySet())
        {
        	
        	int act = Autori.get(s);
        	//System.out.println(s + " " + Integer.toString(act));
        	if (act == highest) {
        		vypis += ", " + s;
        	}
        	if (act > highest) {
        		highest = act; 
        		vypis = s;
        	}
        }
        System.out.println("Autor(i) s nejpo�etn�j��m zastoupen�m v knihovn� (" + highest + ") - " + vypis);
    }
	 /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

    	if (localName.equals("kniha")) {
    		String s = atts.getValue("state");
    		if (s.equalsIgnoreCase("pujcenood")) MamDomaCizich++;
    	}
    	
    	currentElementName = localName;
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (localName.equals("autor")){
        	//System.out.println(autor.trim());
        	autor = autor.trim();
        	Integer i = Autori.get(autor);
        	if (i != null) Autori.put(autor, ++i);
        	else Autori.put(autor, 1);
        }
        
        if (localName.equals("kniha")){
        	 autor = "";
        }
       
    }
    
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        String s = new String(chars, start, length).toUpperCase().trim();
        if (currentElementName.equals("autor")) {
            autor += new String(chars, start, length);
        }
        
        if (currentElementName.equals("jmeno")) {
        	autor += (new String(chars, start, length));
        }

		if (currentElementName.equals("prijmeni")) {
			autor += " ";
		    autor += new String(chars, start, length);
		}
     }
//Prost�ednictv�m rozhran� SAX spo��tat alespo� 3 zvolen� charakteristiky Va�ich dat z nich� jedna se bude vztahovat k hodnot�m atribut� (nap�. pr�m�rn� v�ha v�robku), druh� k obsahu element� (nap�. t�i nej�ast�j�� p��jmen� zam�stnanc�) a t�et� ke kontextu (nap�. po�et zam�stnanc�, kte�� jsou star�� 60ti let, ale nemaj� dovolenou). 
	//- Pocet knih, kter� m�m p�j�en� j�
	//- Nejpocetneji zastoupen� autor v knihovne
	//
	
	

}
