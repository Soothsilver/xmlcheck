package user;

import java.io.File;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;


public class MyDomTransformer {

    /**
     * Process document tree
     *
     * @param doc Document to be parsed
     */
    public void transform(Document doc) {
        createProject(doc, "Java Assignment", "Vojtěch Vondra");
        linkRelatedIssues(doc, "i_1", "i_4");
        linkRelatedIssues(doc, "i_4", "i_1");
    }

    /**
     * Creates a new project in the document
     * @param doc document with projects
     * @param name project name
     * @param maintainer maintainer's name
     * @return new project node
     */
    private static Element createProject(Document doc, String name, String maintainer) {
        Element projects = doc.getDocumentElement();
        Element projectEl = doc.createElement("Project");

        Element nameEl = doc.createElement("Name");
        nameEl.appendChild(doc.createTextNode(name));

        Element maintainerEl = doc.createElement("Maintainer");
        maintainerEl.appendChild(doc.createTextNode(maintainer));

        projectEl.appendChild(nameEl);
        projectEl.appendChild(maintainerEl);
        projectEl.appendChild(doc.createElement("Issues"));

        String id = name.replaceAll("[-+.^:,&<>\\s]", "");
        projectEl.setAttribute("pid", id);

        projects.appendChild(projectEl);

        //System.out.println("Project " + name + " added");

        return projectEl;
    }

    /**
     *
     * @param source ID of source issue
     * @param target ID of target issue
     */
    private static void linkRelatedIssues(Document doc, String source, String target) {
        Element sourceElement = doc.getElementById(source);
        Element targetElement = doc.getElementById(target);

        if (sourceElement == null) {
            throw new IllegalArgumentException("Invalid source issue ID");
        }

        if (targetElement == null) {
            throw new IllegalArgumentException("Invalid target issue ID");
        }

        Node related = sourceElement.getElementsByTagName("RelatedIssues").item(0);
        NodeList relatedIssues = related.getChildNodes();
        boolean issueIsInRelated = false;
        for (int i = 0; i < relatedIssues.getLength(); i++) {
            Node node = relatedIssues.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                if (node.getAttributes().getNamedItem("i_id").getNodeValue().equals(target)) {
                    issueIsInRelated = true;
                }
            }
        }

        if (!issueIsInRelated) {
            Element relatedIssue = doc.createElement("RelatedIssue");
            relatedIssue.setAttribute("i_id", target);
            related.appendChild(relatedIssue);
            //System.out.println("Link between " + source + " and " + target + " added");
        } else {
            //System.out.println("Link between " + source + " and " + target + " already exists");
        }
    }
}