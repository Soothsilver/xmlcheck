package user;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.helpers.DefaultHandler;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;


public class MySaxHandler extends DefaultHandler {

    // Helper variable to store location of the handled event
    Locator locator;

    String currentElementName;

    /**
     * Maps the number of issues assigned to a user
     * Used to demonstrate I can work with element values
     */
    HashMap<String, Integer> issueCountByAssignee;

    /**
     * Maps the number of issues with a given priority
     * Used to demonstrate I can work with attributes
     */
    HashMap<String, Integer> issueCountByPriority;

    /**
     * Issues which are not done and the deadline has passed
     * Used to demonstrate I can work with context
     */
    HashMap<String, String> unfinishedAfterDeadline;

    /**
     * List of errors encountered during parsing
     */
    List<Exception> errors;

    Date currentIssueDeadline;

    Integer currentIssuePercentageDone;

    String currentIssueKey;

    String currentIssueName;

    DateFormat dateParser = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    /**
     * Used to extract text node contents
     */
    StringBuilder textBuffer;

    public MySaxHandler() {
        issueCountByPriority = new HashMap<String, Integer>();
        issueCountByAssignee = new HashMap<String, Integer>();
        unfinishedAfterDeadline = new HashMap<String, String>();
        textBuffer = new StringBuilder();
        errors = new ArrayList<Exception>();
    }

    /**
     * Method to handle "begin element"
     *
     * @param uri       URI of the element namespace (empty if element is no
     *                  namespace)
     * @param localName local name of the element (never empty)
     * @param qName     qualified name (prefix-URI + ':' + localName, if the element
     *                  is in some namespace or localName otherwise)
     * @param atts      Element's attributes
     * @throws SAXException
     */
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if (localName.equals("Issue")) {
            String priority = atts.getValue("priority");
            int count = issueCountByPriority.containsKey(priority) ? issueCountByPriority.get(priority) : 0;
            issueCountByPriority.put(priority, count + 1);
            currentIssueKey = atts.getValue("id");

            currentIssueDeadline = null;
            currentIssuePercentageDone = null;
        }

        // Clear buffer
        textBuffer.setLength(0);

        currentElementName = localName;
    }

    /**
     * Method to handle "element end"
     *
     * @param uri       URI of the element namespace (empty if element is no
     *                  namespace)
     * @param localName local name of the element (never empty)
     * @param qName     qualified name (prefix-URI + ':' + localName, if the element
     *                  is in some namespace or localName otherwise)
     * @throws SAXException
     */
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (localName.equals("Assignee")) {
            String assignee = textBuffer.toString();
            int count = issueCountByAssignee.containsKey(assignee) ? issueCountByAssignee.get(assignee) : 0;
            issueCountByAssignee.put(assignee, count + 1);
        }

        if (localName.equals("Title")) {
            currentIssueName = textBuffer.toString();
        }

        if (localName.equals("PercentDone")) {
            String percentDone = textBuffer.toString();
            int percentage;
            try {
                percentage = Integer.parseInt(percentDone);
            } catch (NumberFormatException e) {
                percentage = 0;
                errors.add(e);
            }

            currentIssuePercentageDone = percentage;
        }

        if (localName.equals("Deadline")) {
            try {
               currentIssueDeadline = dateParser.parse(textBuffer.toString());
            } catch (ParseException e) {
                errors.add(e);
            }
        }

        // Check if issue is not done and the deadline has passed
        if (localName.equals("Issue")) {
            if (currentIssueDeadline.before(new Date()) && currentIssuePercentageDone < 100) {
                unfinishedAfterDeadline.put(currentIssueKey, currentIssueName);
            }
        }
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars  Array with char data
     * @param start  Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    public void characters(char[] chars, int start, int length) throws SAXException {
        textBuffer.append(chars, start, length);
    }

    public void setDocumentLocator(Locator locator) {

    }

    public void startDocument() throws SAXException {

    }

    public void endDocument() throws SAXException {

    }

    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
        // ...
    }

    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

    public void skippedEntity(String name) throws SAXException {
        // ...
    }

    public HashMap<String, Integer> getIssueCountByAssignee() {
        return issueCountByAssignee;
    }

    public HashMap<String, Integer> getIssueCountByPriority() {
        return issueCountByPriority;
    }

    public HashMap<String, String> getUnfinishedAfterDeadline() {
        return unfinishedAfterDeadline;
    }
}