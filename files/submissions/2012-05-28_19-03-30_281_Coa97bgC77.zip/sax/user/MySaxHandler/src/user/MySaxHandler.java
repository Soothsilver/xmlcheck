package user;

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;

/**
 *
 * @author Jaroslav Kubat
 */
/*
public class MySaxHandler {
    public static void main(String[] args) {
        // Cesta ke zdrojovemu XML dokumentu  
        String sourcePath = "data.xml";

        try {
            // Vytvorime instanci parseru.
            XMLReader parser = XMLReaderFactory.createXMLReader();

            // Vytvorime vstupni proud XML dat.
            InputSource source = new InputSource(sourcePath);

            // Nastavime nas vlastni content handler pro obsluhu SAX udalosti.
            parser.setContentHandler(new MySaxHandler2());

            // Zpracujeme vstupni proud XML dat.
            parser.parse(source);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
*/

public class  MySaxHandler extends DefaultHandler {
    // Umoznuje zacilit misto v dokumentu, kde vznikla aktualni udalost
    Locator locator;
    
    int aktualniHloubka;
    int maxHloubka;
    int pocetElementu;
    int pocetKoncovychElementu;
    int pocetAtributu;
    double soucetHloubekElementu;
    double soucetHloubekKoncovychElementu;
    String nazevNejhlubsihoElementu;
    String plnaCesta;
    String nazevElementu;
    String nazevPredchozihoElementu;
    
    /**
     * Nastavi locator
     */    
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    
    /**
     * Obsluha udalosti "zacatek dokumentu"
     */    
    public void startDocument() throws SAXException {
        aktualniHloubka = 0;
        maxHloubka = 0;
        pocetElementu = 0;
        pocetKoncovychElementu = 0;
        pocetAtributu = 0;
        soucetHloubekElementu = 0;
        soucetHloubekKoncovychElementu = 0;
        nazevNejhlubsihoElementu = "";
        plnaCesta = "";
        nazevElementu = "";
        nazevPredchozihoElementu = "";
        
        System.out.printf("Vypis elementu:\n--------------------------------------------------------------\n");
    }

    
    /**
     * Obsluha udalosti "konec dokumentu"
     */    
    public void endDocument() throws SAXException {
        System.out.printf("==============================================================\n\nStatistiky:\n--------------------------------------------------------------\n");
        System.out.printf("Pocet elementu dokumentu je %s a jejich prumerna hloubka je %f.\n", pocetElementu, soucetHloubekElementu/(double)pocetElementu);
        System.out.printf("Pocet koncovych elementu (bez potomka) dokumentu je %s a jejich prumerna hloubka je %f. \n", pocetKoncovychElementu, soucetHloubekKoncovychElementu/(double)pocetKoncovychElementu);
        System.out.printf("Pocet atributu dokumentu je %s.\n", pocetAtributu);
        System.out.printf("Maximalni hloubka dokumentu je %d a dosahuje ji element %s.\n==============================================================\n", maxHloubka, nazevNejhlubsihoElementu);
    }

    String tabs = "";

    /**
     * Obsluha udalosti "zacatek elementu".
     * @param uri URI jmenneho prostoru elementu (prazdne, pokud element neni v zadnem jmennem prostoru)
     * @param localName Lokalni jmeno elementu (vzdy neprazdne)
     * @param qName Kvalifikovane jmeno (tj. prefix-uri + ':' + localName, pokud je element v nejakem jmennem prostoru, nebo localName, pokud element neni v zadnem jmennem prostoru)
     * @param atts Atributy elementu
     */    
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        aktualniHloubka++;
        if (aktualniHloubka>maxHloubka) {
            maxHloubka = aktualniHloubka;
            nazevNejhlubsihoElementu = localName;
        }
        pocetElementu++;
        pocetAtributu += atts.getLength();
        plnaCesta += "/" + localName;
        nazevElementu = localName;
        soucetHloubekElementu += aktualniHloubka;
        String spacing = "";
        if (nazevPredchozihoElementu.equals(nazevElementu)) {
            for (int i=0; i<plnaCesta.length() - localName.length() - 4; i++) {
                spacing += " ";
            }
            System.out.printf("Hloubka: %s ... Element: %s.../%s\n", aktualniHloubka, spacing, localName);
        } else {
            System.out.printf("Hloubka: %s ... Element: %s\n", aktualniHloubka, plnaCesta);
            nazevPredchozihoElementu = "";
        }
    }

    
    /**
     * Obsluha udalosti "konec elementu"
     * Parametry maji stejny vyznam jako u @see startElement    
     */    
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (nazevElementu.equals(localName)) {
            pocetKoncovychElementu++;
            soucetHloubekKoncovychElementu += aktualniHloubka;
        }
        nazevPredchozihoElementu = nazevElementu;
        aktualniHloubka--;
        plnaCesta = plnaCesta.substring(0, (plnaCesta.length() - localName.length() - 1));
    }


    /**
     * Obsluha udalosti "znakova data".
     * SAX parser muze znakova data davkovat jak chce. Nelze tedy pocitat s tim, ze je cely text dorucen v ramci jednoho volani.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakovymi daty
     * @param start Index zacatku useku platnych znakovych dat v poli.
     * @param length Delka useku platnych znakovych dat v poli.
     */              
    public void characters(char[] ch, int start, int length) throws SAXException {
        
    }
   
    String namespaces = "";

    /**
     * Obsluha udalosti "deklarace jmenneho prostoru".
     * @param prefix Prefix prirazeny jmennemu prostoru.
     * @param uri URI jmenneho prostoru.
     */    
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
    }

    
    /**
     * Obsluha udalosti "konec platnosti deklarace jmenneho prostoru".
     */
    public void endPrefixMapping(String prefix) throws SAXException {
        
    }

    
    /**
     * Obsluha udalosti "ignorovane bile znaky".
     * Stejne chovani a parametry jako @see characters    
     */    
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
    }

    
    /**
     * Obsluha udalosti "instrukce pro zpracovani".
     */        
    public void processingInstruction(String target, String data) throws SAXException {
        
    }

    
    /**
     * Obsluha udalosti "nezpracovana entita"
     */        
    public void skippedEntity(String name) throws SAXException {
        
    }

}