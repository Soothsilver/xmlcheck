package user;
import org.w3c.dom.Document;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author Jaroslav Kubát
 */
public class MyDomTransformer {
    private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "data.out.xml";

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        try {
            
            //DocumentBuilderFactory vytváří DOM parsery
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            //nebudeme validovat
            dbf.setValidating(false);

            //vytvoříme si DOM parser
            DocumentBuilder builder = dbf.newDocumentBuilder();

            //parser zpracuje vstupní soubor a vytvoří z něj strom DOM objektů
            Document doc = builder.parse(VSTUPNI_SOUBOR);

            //zpracujeme DOM strom
            transform(doc);

            //TransformerFactory vytváří serializátory DOM stromů
            TransformerFactory tf = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer = tf.newTransformer();

            //nastavíme kodování
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spustíme transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


        } catch (Exception e) {
            
            e.printStackTrace();
            
        }
    }
    
    public static void transform (Document xmlDocument) {
        // Setridime barvy v dokumentu podle abecedy
        setridBarvy(xmlDocument);
        
        // Rozepise vzory (atributy ve vzorech prevede na vnitrni elementy)
        rozepisVzory(xmlDocument);
    }
    
    public static void setridBarvy (Document xmlDocument) {
        NodeList barvy = xmlDocument.getElementsByTagName("barva");
        Node[] barvicky = new Node[barvy.getLength()];
        
        for (int i=0; i < barvy.getLength(); i++){
            barvicky[i] = barvy.item(i);
        }
        
        boolean zmena = true;
        Node x;
        while (zmena) {
            zmena = false;
            for (int i=0; i<(barvicky.length - 1); i++) {
                for (int j=i+1; j<barvicky.length; j++) {
                    if (barvicky[i]
                            .getAttributes()
                            .getNamedItem("id_nazev")
                            .getNodeValue()
                            .compareTo(
                                barvicky[j]
                                    .getAttributes()
                                    .getNamedItem("id_nazev")
                                    .getNodeValue()) > 0) {
                        x = barvicky[i];
                        barvicky[i]=barvicky[j];
                        barvicky[j]=x;
                        zmena = true;
                    }
                }
                if (zmena) {
                    break;
                }
            }
        }
        
        Element setridene = xmlDocument.createElement("barvy");
        for (int i=0; i<barvicky.length; i++) {
            setridene.appendChild(barvicky[i]);
        }
        
        Element b = (Element) xmlDocument.getElementsByTagName("barvy").item(0);
        b.getParentNode().removeChild(b);
        xmlDocument.getElementsByTagName("databaze_obleceni").item(0).insertBefore(setridene, xmlDocument.getElementsByTagName("vzory").item(0));
    }
    
    public static void rozepisVzory (Document xmlDocument) {
        Element vzory = (Element)xmlDocument.getElementsByTagName("vzory").item(0);
        NodeList vzor = vzory.getElementsByTagName("vzor");
        NodeList pouzitaBarva;
        Element novy;
        for (int i=0; i<vzor.getLength(); i++) {
            novy = xmlDocument.createElement("id_kod_vzoru");
            novy.setTextContent(vzor.item(i).getAttributes().getNamedItem("id_kod_vzoru").getNodeValue());
            vzor.item(i).appendChild(novy);
            vzor.item(i).getAttributes().removeNamedItem("id_kod_vzoru");
            
            pouzitaBarva = ((Element)vzor.item(i)).getElementsByTagName("pouzita_barva");
            for (int j=0; j<pouzitaBarva.getLength(); j++) {
                pouzitaBarva.item(j).setTextContent(pouzitaBarva.item(j).getAttributes().getNamedItem("barva_ref").getNodeValue());
                pouzitaBarva.item(j).getAttributes().removeNamedItem("barva_ref");
            }
        }
    }
}
