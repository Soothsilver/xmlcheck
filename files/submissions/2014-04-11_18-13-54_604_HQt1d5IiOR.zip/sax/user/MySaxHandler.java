package user; 

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler; 

public class MySaxHandler extends DefaultHandler { 
	
	private double avgMedPrice;
	private int medCount;
	private int medPriceSum;
	
	private boolean bEmploye;
	private boolean bSurname;
	private Map<String, Integer> surnames;
	private ArrayList<String> mostFrequentSurnames;
	
	private boolean bAge;
	private boolean bOnVacation;
	private boolean overSixty;
	private boolean onVacation;
	private int employeOverSixtyNotOnVacationCount;
	
	@Override
	public void startDocument() throws SAXException {
        medCount = 0;
        medPriceSum = 0;
        avgMedPrice = 0;
        
        bEmploye = false;
        bSurname = false;
        surnames = new HashMap<String, Integer>();
        mostFrequentSurnames = new ArrayList<String>();
        
        bAge = false;
        bOnVacation = false;
        overSixty = false;
        onVacation = false;
        employeOverSixtyNotOnVacationCount = 0;
    }

	@Override
    public void endDocument() throws SAXException {
        if (medCount > 0)
        	avgMedPrice = (double)medPriceSum / medCount;
        System.out.println("Average price of medication: " + avgMedPrice + " ");
        System.out.println();
        
        System.out.println("Three most frequent surnames: ");
        for (int i = 0; i < 3; i++) {
	        Map.Entry<String, Integer> maxEntry = null;
	        for (Map.Entry<String, Integer> entry : surnames.entrySet()) {
	            if (maxEntry == null || entry.getValue() > maxEntry.getValue())
	                maxEntry = entry;
	        }
	        if (maxEntry != null) {
	        	mostFrequentSurnames.add(maxEntry.getKey());
	        	surnames.remove(maxEntry.getKey());
	        	System.out.println(mostFrequentSurnames.get(i) + " ");
	        }
		}
        System.out.println();
        System.out.println("Number of employes over 60, but not on vacation: " + employeOverSixtyNotOnVacationCount + " ");
    }

	@Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		if (qName.equals("medication")) {
			String tmpMedCount = attributes.getValue("price");
			if (tmpMedCount != null) {
				medPriceSum += Integer.parseInt(tmpMedCount);
				medCount++;
			}
		}
		if (qName.equals("employe"))
			bEmploye = true;
		if (qName.equals("surname"))
			bSurname = true;
		if (qName.equals("age"))
			bAge = true;
		if (qName.equals("on_vacation"))
			bOnVacation = true;
    }

	@Override
    public void endElement(String uri, String localName, String qName)
    throws SAXException {
		if (qName.equals("employe")) {
			bEmploye = false;
			if (overSixty && !onVacation)
				employeOverSixtyNotOnVacationCount++;
			overSixty = false;
			onVacation = false;
		}
		if (qName.equals("surname"))
			bSurname = false;
		if (qName.equals("age"))
			bAge = false;
		if (qName.equals("on_vacation"))
			bOnVacation = false;
    }

	@Override
    public void characters(char ch[], int start, int length)
    throws SAXException {
		if (bEmploye) {
			if (bSurname) {
				String surname = new String (ch, start, length);
				int surnameCount = 0;
				if (surnames.containsKey(surname))
						surnameCount = surnames.get(surname);
				surnames.put(surname, surnameCount + 1);
			}
			if (bAge) {
				String tmpAge = new String (ch, start, length);
				int age = Integer.parseInt(tmpAge);
				if (age > 60) overSixty = true;
			}
			if (bOnVacation) {
				String txt = new String (ch, start, length);
				if (new String("yes").equals(txt))
					onVacation = true;
				if (new String("no").equals(txt))
					onVacation = false;
			}
		}
    }

 
}