package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer {
	
	public static final String NODE_EMPLOYES = "employes";
	public static final String NODE_EMPLOYE = "employe";
	public static final String NODE_SALARY = "salary";
	public static final int MIN_SALARY = 2000;
	
	private void processNode (Document xmlDocument, Node node) {
		NodeList list = node.getChildNodes();
		
		if (NODE_EMPLOYES.equals(node.getNodeName()))
			node.appendChild(createEmploye(xmlDocument));
		
		for (int i=0; i<list.getLength(); i++) {
			Node childNode = list.item(i);
			if (NODE_EMPLOYE.equals(childNode.getNodeName())) {
				processEmployeNode(childNode);
				continue;
			}			
			processNode (xmlDocument, childNode);
			//System.out.println(childNode.getNodeName());
		}
	}
	
	private void processEmployeNode(Node node) {
		NodeList list = node.getChildNodes();
		for (int i=0; i<list.getLength(); i++) {
			Node childNode = list.item(i);
			if (NODE_SALARY.equals(childNode.getNodeName())) {
				if (Integer.parseInt(childNode.getTextContent()) < MIN_SALARY) {
					node.getParentNode().removeChild(node);
					return;
				}
			}
		}
				
	}
	
	public Element createEmploye (Document xmlDocument) {
		Element newEmploye = xmlDocument.createElement(NODE_EMPLOYE);
		Element firstName = xmlDocument.createElement("firstName");
		Element surname = xmlDocument.createElement("surname");
		Element age = xmlDocument.createElement("age");
		Element onVacation = xmlDocument.createElement("on_vacation");
		Element salary = xmlDocument.createElement("salary");
		
		firstName.setTextContent("Name5");
		surname.setTextContent("SurName5");
		age.setTextContent("45");
		onVacation.setTextContent("no");
		salary.setTextContent("6000");
		
		newEmploye.appendChild(firstName);
		newEmploye.appendChild(surname);
		newEmploye.appendChild(age);
		newEmploye.appendChild(onVacation);
		newEmploye.appendChild(salary);
		return newEmploye;
	}
	
	public void transform (Document xmlDocument) { 
		Element mainElement = xmlDocument.getDocumentElement();
		processNode (xmlDocument, mainElement);
	} 
}