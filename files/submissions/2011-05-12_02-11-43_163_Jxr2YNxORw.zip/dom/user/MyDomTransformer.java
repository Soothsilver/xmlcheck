package user;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer {

    /**
     * Zpracuje DOM strom
     */
    public void transform (Document doc) 
    {
        NodeList spolecnosti = doc.getElementsByTagName("Spolecnost");

        for (int i = 0; i < spolecnosti.getLength(); i++)
        {
            Element spolecnost = (Element) spolecnosti.item(i);

            PresunKontaktyVeSpolecnosti(spolecnost);
        }
    }

    private static void PresunKontaktyVeSpolecnosti(Element spolecnost)
    {
        Element kontakty = null;
        NodeList deti = spolecnost.getChildNodes();
        for (int i = 0; i < deti.getLength(); i++)
        {
            Node dite = deti.item(i);
            if (dite.getNodeName().equalsIgnoreCase("Kontakty"))
            {
                kontakty = (Element) dite;
                break;
            }
        }
        // Kontakty nejsou primo ve spolecnosti, musime je zalozit..
        if (kontakty == null)
        {
            Document doc = spolecnost.getOwnerDocument();
            kontakty = doc.createElement("Kontakty");
            spolecnost.appendChild(kontakty);
        }

        PresunVsechnyVnoreneKontaktyDoKontaktu("Telefon", "Telefony", kontakty,
                spolecnost);
        PresunVsechnyVnoreneKontaktyDoKontaktu("Email", "Emaily", kontakty,
                spolecnost);
        PresunVsechnyVnoreneKontaktyDoKontaktu("Ucet", "Ucty", kontakty,
                spolecnost);
        PresunVsechnyVnoreneKontaktyDoKontaktu("Adresa", "Adresy", kontakty,
                spolecnost);
        SmazOddeleniAOsoby(spolecnost);
    }

    private static void SmazOddeleniAOsoby(Element spolecnost)
    {
        NodeList seznamOddeleniList = spolecnost.getElementsByTagName("SeznamOddeleni");
        //rozhrani jinak neumoznuje vratit jeden node.. ale nemusi by zadny tak osetreno cyklem.. 
        for (int i =0 ; i < seznamOddeleniList.getLength(); i++)
        {
            Element seznamOddeleni = (Element)seznamOddeleniList.item(i);
            spolecnost.removeChild(seznamOddeleni);
        }
        
        NodeList kontaktniOsobyList = spolecnost.getElementsByTagName("KontaktniOsoby");
        //rozhrani jinak neumoznuje vratit jeden node.. ale nemusi by zadny tak osetreno cyklem.. 
        for (int i =0 ; i < kontaktniOsobyList.getLength(); i++)
        {
            Element kontaktniOsoby = (Element)kontaktniOsobyList.item(i);
            spolecnost.removeChild(kontaktniOsoby);
        }
    }

    private static void PresunVsechnyVnoreneKontaktyDoKontaktu(
            String nazevElementuKPresunu, String nazevCilovehoElementu,
            Element ciloveKontakty, Element spolecnost)
    {
        NodeList vnoreneElementy = spolecnost
                .getElementsByTagName(nazevElementuKPresunu);

        if (vnoreneElementy.getLength() > 0)
        {
            Element cilovyElement = null;
            NodeList detiKontaktu = ciloveKontakty.getChildNodes();
            for (int i = 0; i < detiKontaktu.getLength(); i++)
            {
                Node dite = detiKontaktu.item(i);
                if (dite.getNodeName().equalsIgnoreCase(nazevCilovehoElementu))
                {
                    cilovyElement = (Element)dite;
                }
            }
            if (cilovyElement == null)
            {
                Document doc = ciloveKontakty.getOwnerDocument();
                cilovyElement = doc.createElement(nazevCilovehoElementu);
                ciloveKontakty.appendChild(cilovyElement);
            }
            
            for (int i = 0; i < vnoreneElementy.getLength(); i++)
            {   
                Element presouvanyElement = (Element)vnoreneElementy.item(i);
                if (presouvanyElement.getParentNode() != cilovyElement)
                {
                    cilovyElement.appendChild(presouvanyElement);
                    //z neznameho duvodu se meni po operaci appendchild seznam vnorene elementy a tak musim snizit index.. 
                    i--;
                }
            }
        }

    }
}
