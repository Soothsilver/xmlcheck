package user;

import java.util.LinkedList;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler
{

    class spolecnost
    {
        int pocetKontaktu = 0;
        int pocetEmailu = 0;
        int pocetAdres = 0;
        int pocetTelefonu = 0;
        int pocetUctu = 0;
    }

    LinkedList<spolecnost> spolecnosti = new LinkedList<spolecnost>();
    spolecnost aktSpol = null;

    Locator locator;

    public void setDocumentLocator(Locator locator)
    {
        this.locator = locator;
    }

    public void startDocument() throws SAXException
    {

        // ...

    }
    
    public void endDocument() throws SAXException
    {

        int celkovyPocetEmailu = 0;
        int celkovyPocetTelefonu = 0;
        int celkovyPocetAdres = 0;
        int celkovyPocetUctu = 0;
        int celkovyPocetKontaktu = 0;

        for (spolecnost s : spolecnosti)
        {
            celkovyPocetEmailu += s.pocetEmailu;
            celkovyPocetTelefonu += s.pocetTelefonu;
            celkovyPocetAdres += s.pocetAdres;
            celkovyPocetUctu += s.pocetUctu;
            celkovyPocetKontaktu += s.pocetKontaktu;
        }

        int prumernyPocetEmailu = celkovyPocetEmailu / spolecnosti.size();
        int prumernyPocetTelefonu = celkovyPocetTelefonu / spolecnosti.size();
        int prumernyPocetAdres = celkovyPocetAdres / spolecnosti.size();
        int prumernyPocetUctu = celkovyPocetUctu / spolecnosti.size();
        int prumernyPocetKontaktu = celkovyPocetKontaktu / spolecnosti.size();

        System.out
                .println("celkovy pocet spolecnosti je " + spolecnosti.size());
        System.out
                .println("===================================================");
        System.out.println("celkovy pocet emailovych kontaktu je "
                + celkovyPocetEmailu);
        System.out.println("celkovy pocet telefonnich kontaktu je "
                + celkovyPocetTelefonu);
        System.out.println("celkovy pocet adresnich kontaktu je "
                + celkovyPocetAdres);
        System.out.println("celkovy pocet uctu mezi kontakty je "
                + celkovyPocetUctu);
        System.out
                .println("===================================================");
        System.out
                .println("prumerny pocet emailovych kontaktu ve spolecnosti je "
                        + prumernyPocetEmailu);
        System.out
                .println("prumerny pocet telefonnich kontaktu ve spolecnosti je "
                        + prumernyPocetTelefonu);
        System.out
                .println("prumerny pocet adresnich kontaktu ve spolecnosti je "
                        + prumernyPocetAdres);
        System.out.println("prumerny pocet uctu ve spolecnosti je "
                + prumernyPocetUctu);
        System.out.println("prumerny pocet kontaktu ve spolecnosti je "
                + prumernyPocetKontaktu);
        System.out
                .println("===================================================");
        // ...
    }

    public void startElement(String uri, String localName, String qName,
            Attributes atts) throws SAXException
    {

        if (localName.equalsIgnoreCase("spolecnost"))
        {
            aktSpol = new spolecnost();
        }

        if (aktSpol != null)
        {
            if (localName.equalsIgnoreCase("telefon"))
            {
                aktSpol.pocetTelefonu++;
            }
            if (localName.equalsIgnoreCase("email"))
            {
                aktSpol.pocetEmailu++;
            }
            if (localName.equalsIgnoreCase("adresa"))
            {
                aktSpol.pocetAdres++;
            }
            if (localName.equalsIgnoreCase("ucet"))
            {
                aktSpol.pocetUctu++;
            }
        }
    }

    public void endElement(String uri, String localName, String qName)
            throws SAXException
    {
        if (localName.equalsIgnoreCase("spolecnost") && aktSpol != null)
        {
            aktSpol.pocetKontaktu = aktSpol.pocetTelefonu + aktSpol.pocetEmailu
                    + aktSpol.pocetAdres + aktSpol.pocetUctu;
            spolecnosti.add(aktSpol);
            aktSpol = null;
        }

    }

    public void characters(char[] ch, int start, int length)
            throws SAXException
    {

        // ...

    }

    public void startPrefixMapping(String prefix, String uri)
            throws SAXException
    {

        // ...

    }

    public void endPrefixMapping(String prefix) throws SAXException
    {

        // ...

    }

    public void ignorableWhitespace(char[] ch, int start, int length)
            throws SAXException
    {

        // ...

    }
    
    public void processingInstruction(String target, String data)
            throws SAXException
    {

        // ...

    }

    public void skippedEntity(String name) throws SAXException
    {

        // ...

    }
}