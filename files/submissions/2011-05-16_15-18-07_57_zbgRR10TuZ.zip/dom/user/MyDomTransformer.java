package user;
import java.io.File;
import org.w3c.dom.Attr;
import org.w3c.dom.Document; 
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
/**
 *
 * @author Marek Linka
 */
public class MyDomTransformer
{
    
    public static void transform (Document xmlDocument)  {
        // code transforming xmlDocument object // (method works on the object itself - no return value)
        MyTrans(xmlDocument, xmlDocument.getDocumentElement());
    } 
    
//    public static void main(String[] args) {
//        try {
//            
//            //DocumentBuilderFactory vytváří DOM parsery
//            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
//
//            //nebudeme validovat
//            dbf.setValidating(false);
//
//            //vytvoříme si DOM parser
//            DocumentBuilder builder = dbf.newDocumentBuilder();
//
//            //parser zpracuje vstupní soubor a vytvoří z něj strom DOM objektů
//            Document doc = builder.parse("c:\\users\\marek linka\\documents\\xml\\data.xml");
//
//            //zpracujeme DOM strom
//            transform(doc);
//
//            //TransformerFactory vytváří serializátory DOM stromů
//            TransformerFactory tf = TransformerFactory.newInstance();
//
//            //Transformer serializuje DOM stromy
//            Transformer writer = tf.newTransformer();
//            
//            //nastavíme kodování
//            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
//            DOMSource ds = new DOMSource(doc); 
//
//            //spustíme transformaci DOM stromu do XML dokumentu
//            writer.transform(ds, new StreamResult(new File("data2.xml")));
//
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
    
    private static void MyTrans(Document doc, org.w3c.dom.Element element)
    {
        NamedNodeMap attrs = element.getAttributes();
        
        while (element.getAttributes().getLength() > 0)
        {
            Attr attribute = (Attr)attrs.item(0);
            element.removeAttributeNode(attribute);
            
            Element e = doc.createElement(attribute.getName());
            e.appendChild(doc.createTextNode(attribute.getValue()));
            element.appendChild(e);   
        }
        
        for (int j = 0; j < element.getChildNodes().getLength() - 1; j++)
        {
            org.w3c.dom.Node n = element.getChildNodes().item(j); 
            if (n instanceof org.w3c.dom.Element)
            {
                MyTrans(doc, (Element)element.getChildNodes().item(j));
            }
            
        }
    }
}
