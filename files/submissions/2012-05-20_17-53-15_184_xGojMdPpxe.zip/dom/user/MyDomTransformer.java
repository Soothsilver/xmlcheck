/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package user;

/**
 *
 * @author Oskar Hollmann hollmosk@fel.cvut.cz
 * Ve vstupnim souboru ma element <umelec> 3 ruzne vyznamy (solovy umelec, kapela, clen kapely).
 *      1. Pomoci rozhrani DOM prevedeme element <umelec> podle kontextu na <solovy>, <clen> a <kapela>.
 * 
 *      2. Nove elementy budou mit jediny atribut idumelce, z ostatnich se stanou detske elementy
 *         a nebo zmizi, pokud nemaji pro dany element smysl (pohlavi pro element kapela).
 *      
 *      3. Clenove kapely se presunou a budou primymi potomky prislusne kapely.
 */
import org.w3c.dom.*;

public class MyDomTransformer {
    public static void transform (Document xmlDocument) { 
    
        NodeList umelci = xmlDocument.getElementsByTagName("umelec");
        int pocetUmelcu = xmlDocument.getElementsByTagName("umelec").getLength();
        Node u;
        for (int i = 0; i < pocetUmelcu; i++) {
            u = umelci.item(0);
            NamedNodeMap atts = u.getAttributes();
            String pohlavi;
            String kapelaref;
            if (atts.getNamedItem("pohlavi") != null) {
                pohlavi = atts.getNamedItem("pohlavi").getTextContent();
            }
            else { 
                pohlavi = "";
            }
            if (atts.getNamedItem("kapelaref") != null) {
                kapelaref = atts.getNamedItem("kapelaref").getTextContent();
            }
            else { 
                kapelaref = "";
                
            } 
            
            if ( (pohlavi.equals("muz") | pohlavi.equals("zena")) & !kapelaref.equals("") ) { // je to clen kapely
                Element poh = xmlDocument.createElement("pohlavi");
                poh.setTextContent(pohlavi);
                u.appendChild(poh);
                //u.getAttributes().removeNamedItem("pohlavi");
                
                Element kref = xmlDocument.createElement("kapelaref");
                kref.setTextContent(kapelaref);
                u.appendChild(kref);
                //u.getAttributes().removeNamedItem("kapelaref");
                
                
                xmlDocument.renameNode(u, "", "clen");
                //System.out.println("clen kapely");
            }
                      
           
            if ( (pohlavi.equals("muz") | pohlavi.equals("zena")) & kapelaref.equals("") ) { // je to solovy umelec
                Element poh = xmlDocument.createElement("pohlavi");
                
                poh.setTextContent(pohlavi);
                u.appendChild(poh);
                //u.getAttributes().removeNamedItem("pohlavi");
                
                xmlDocument.renameNode(u, "", "solovy");
                //System.out.println("solovy umelec");
            }
            
            if ( pohlavi.equals("nedefinovano") & kapelaref.equals("") ) { // je to kapela
                //u.getAttributes().removeNamedItem("pohlavi");
                
                xmlDocument.renameNode(u, "", "kapela");
                //System.out.println("kapela");
            }
            
            
        }
        
        // Clenove budou detske elementy prislusne kapely
        NodeList kapely = xmlDocument.getElementsByTagName("kapela");
        
        for (int i = 0; i < kapely.getLength(); i++) {
            Node k = kapely.item(i);
            String id = k.getAttributes().getNamedItem("idumelce").getTextContent();
            NodeList clenove = xmlDocument.getElementsByTagName("clen");
            Node c;
            for (int j = 0; j < clenove.getLength(); j++) {
                c = clenove.item(j);
                Node kapelaref = c.getLastChild();
                if (kapelaref.getTextContent().equals(id)) {
                    k.appendChild(c);
                    c.removeChild(c.getLastChild());
                }
            }
        }
        
        // Element se seznamem referenci na cleny jiz neni potreba
        NodeList clenovetags = xmlDocument.getElementsByTagName("clenove");
        int clenovecount = clenovetags.getLength();
        for (int i = 0; i < clenovecount; i++) {
            Node cl = clenovetags.item(0);
            cl.getParentNode().removeChild(cl);
        }
        // Reference na kapelu u elementu jiz neni potreba, pohlavi take ne
        NodeList art = xmlDocument.getElementsByTagName("clen");
        for (int i = 0; i < art.getLength(); i++) {
            Node cl = art.item(i);
            cl.getAttributes().removeNamedItem("pohlavi");
            cl.getAttributes().removeNamedItem("kapelaref");
        }
        art = xmlDocument.getElementsByTagName("kapela");
        for (int i = 0; i < art.getLength(); i++) {
            Node cl = art.item(i);
            cl.getAttributes().removeNamedItem("pohlavi");
        }
        art = xmlDocument.getElementsByTagName("solovy");
        for (int i = 0; i < art.getLength(); i++) {
            Node cl = art.item(i);
            cl.getAttributes().removeNamedItem("pohlavi");
        }
    } 
}