package user;

import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import java.util.ArrayList;
import org.xml.sax.helpers.DefaultHandler;

/**
 *  @author Oskar Hollmann hollmosk@fel.cvut.cz
 * 
 * Vytvori HTML fragment se statistikami o umelcich.
 * Pri pruchodu stomem si uklada informace do vlastnich trid (Artist)
 * Pri udalosti endDocument() vypise informace o vsech umelcich, ktere nasel.
 */ 

abstract class Artist {
    String id;
    int albumcount = 0;
    int year;
}
class SoloArtist extends Artist {
    String firstname;
    String surname;
    SoloArtist (String id) {
        this.id = id;
    }
}
class Group extends Artist {
    String name;
    Group (String id) {
        this.id = id;
    }
}
public class MySaxHandler extends DefaultHandler  {
   
    Locator locator;
    ArrayList <Artist>umelci = new ArrayList();
    boolean newName = false;
    boolean newSurname = false;
    boolean newYear = false;
    boolean newGroupName = false;
    boolean artistAdded = false;
    String lastAlbumRef;

    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    @Override
    public void startDocument() throws SAXException {
    }   
    @Override
    public void endDocument() throws SAXException {
        System.out.println("<ul>");
        for (Artist a : umelci) {
            if (a instanceof SoloArtist) {
                SoloArtist sa = (SoloArtist) a;
                System.out.println("<li>" + sa.firstname + " " + sa.surname +
                        "\n\t<ul>" + 
                            "\n\t    <li>Rok narozeni: " + sa.year + "</li>" +
                            "\n\t    <li>Pocet alb ve sbirce: " + sa.albumcount + "</li>" +
                        "\n\t</ul>\n</li>");
            }
            else {
                Group g = (Group) a;
                System.out.println("<li>" + g.name + 
                        "\n\t<ul>" + 
                            "\n\t    <li>Rok zalozeni: " + g.year + "</li>" +
                            "\n\t    <li>Pocet alb ve sbirce: " + g.albumcount + "</li>" +
                        "\n\t</ul>\n</li>");
            }
        }
        System.out.println("</li>");
    }
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if (localName.equals("umelec"))  {
            if (atts.getValue("kapelaref") == null && !(atts.getValue("pohlavi").equals("muz") || atts.getValue("pohlavi").equals("zena"))) {
                umelci.add(new Group(atts.getValue("idumelce")));
                artistAdded = true;
            }            
            else if (atts.getValue("kapelaref") == null && (atts.getValue("pohlavi").equals("muz") || atts.getValue("pohlavi").equals("zena"))) {
                umelci.add(new SoloArtist(atts.getValue("idumelce")));
                artistAdded = true;
            }
            else {
                artistAdded = false;
            }
        }
        if (artistAdded) {
            if (localName.equals("jmeno"))  {
            newName = true;
            }
            if (localName.equals("prijmeni"))  {
            newSurname = true;
            }
            if (localName.equals("jmenokapely"))  {
             newGroupName = true;
            }
            if (localName.equals("roknarozeni") || localName.equals("rokzalozeni"))  {
            newYear = true;
            }
        }
        if (localName.equals("album")) {
            String umelecref = atts.getValue("umelecref");
            for (Artist a : umelci) {
                if (a.id.equals(atts.getValue("umelecref"))) {
                    a.albumcount++;
                }
            }
        }
    }
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (localName.equals("umelec"))  {
            artistAdded = false;
        }
    }
             
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        if (newName) {
            StringBuilder sb = new StringBuilder();
            sb.append(ch, start, length);
            ((SoloArtist)umelci.get(umelci.size()-1)).firstname = sb.toString();
            newName = false;
        }
        if (newSurname) {
            StringBuilder sb = new StringBuilder();
            sb.append(ch, start, length);
            ((SoloArtist)umelci.get(umelci.size()-1)).surname = sb.toString();
            newSurname = false;
        }
        if (newGroupName) {
            StringBuilder sb = new StringBuilder();
            sb.append(ch, start, length);
            ((Group)umelci.get(umelci.size()-1)).name = sb.toString();
            newGroupName = false;
        }
        if (newYear) {
            StringBuilder sb = new StringBuilder();
            sb.append(ch, start, length);
            umelci.get(umelci.size()-1).year = Integer.valueOf(sb.toString());
            newYear = false;
        }
    }
      
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
        // ...
        
    }
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
    
        // ...
    
    }  
    @Override
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
        // ...
        
    }       
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
      
      // ...
            
    }     
    @Override
    public void skippedEntity(String name) throws SAXException {
    
      // ...
    
    }
}
