package user; 

import org.xml.sax.*; 
import org.xml.sax.helpers.DefaultHandler; 

/**
 * Vypisuje informace o vozech vlaku ve tvaru:
 * 	id vlaku, pocet lokomotiv, pocet vagonu, razeni vozu
 */
public class MySaxHandler extends DefaultHandler { 

	int pocet_lokomotiv, pocet_vagonu;
	StringBuffer razeni_vozu;

	/**
	 * Vraci index prislusny poradi vozu k zapisu do stringu
	 * @param atts Atributy elementu vlak_*
	 */
	private int razeni_getIndex(Attributes atts) {

		int poradi = Integer.parseInt(atts.getValue(atts.getIndex("poradi")));
		if(poradi > razeni_vozu.length())
			razeni_vozu.setLength(poradi);
		return poradi - 1;
	}

	/**
	* Obsluha udalosti "zacatek elementu" ve forme ukladani uzitecnych dat.
	* @param uri URI jmenneho prostoru elementu (prazdne, pokud element neni v zadnem jmennem prostoru)
	* @param localName Lokalni jmeno elementu (vzdy neprazdne)
	* @param qName Kvalifikovane jmeno (tj. prefix-uri + ':' + localName, pokud je element v nejakem jmennem prostoru, nebo localName, pokud element neni v zadnem jmennem prostoru)
	* @param atts Atributy elementu     
	*/     
	public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

		if("vlak".equals(localName)) {
			pocet_lokomotiv = pocet_vagonu = 0;
			razeni_vozu = new StringBuffer();
			System.out.printf("id vlaku: %s, ", atts.getValue(atts.getIndex("vlak_id")));
		}
		else if("vlak_lokomotiva".equals(localName)) {
			++pocet_lokomotiv;
			razeni_vozu.setCharAt(razeni_getIndex(atts), 'L');
		}
		else if("vlak_vagon".equals(localName))	{
			++pocet_vagonu;
			razeni_vozu.setCharAt(razeni_getIndex(atts), 'V');
		}
	}

	/**
	* Obsluha udalosti "konec elementu" ve forme vypisu dat
	* Parametry maji stejny vyznam jako u @see startElement     
	*/
	public void endElement(String uri, String localName, String qName) throws SAXException {

		if("vlak".equals(localName))
		        System.out.printf("pocet lokomotiv: %d, pocet vagonu: %d, razeni_vozu: %s\n", pocet_lokomotiv, pocet_vagonu, razeni_vozu);
	}
}
