package user; 

import javax.xml.parsers.*;
import javax.xml.transform.*;
import org.w3c.dom.*;
import org.w3c.dom.Document;

public class MyDomTransformer {

 Element vuz;
 int pocet_vozu;
 String[] razeni_vozu;

 /**
 * Zaradi hodnotu atributu *_ref na spravnou pozici v ramci pole razeni_vozu
 */
 private void setRef(String ref_name) {
	
	int poradi = Integer.parseInt(vuz.getAttribute("poradi"));
	razeni_vozu[poradi - 1] = vuz.getAttribute(ref_name);
	++pocet_vozu;
 }

 /**
 * Zpracuje DOM strom
 * 	transformuje XML element vlak ze tvaru:
 *
 * 		<vlak>
 * 			<vlak_lokomotiva lokomotiva_ref="lx" poradi="1" />
 * 			<vlak_vagon vagon_ref="vx" poradi="2" />
 * 		</vlak>
 *
 * 	na tvar:
 *
 * 		<vlak razeni_vozu="lx vx" />
 */
 public void transform (Document xmlDocument) { 
 // code transforming xmlDocument object 
 // (method works on the object itself - no return value)

	NodeList vlaky = xmlDocument.getElementsByTagName("vlak");
	
	for(int i = 0; i < vlaky.getLength(); ++i) {

		Element vlak = (Element) vlaky.item(i);
		Node child;
		String ref_name;
		StringBuffer razeni_val = new StringBuffer();
		razeni_vozu = new String[vlak.getChildNodes().getLength()];
		pocet_vozu = 0;

		while((child = vlak.getFirstChild()) != null) {
			if(child instanceof Element) {
				vuz = (Element) child;
		
				if("vlak_lokomotiva".equals(vuz.getTagName()))
					setRef("lokomotiva_ref");
				else if("vlak_vagon".equals(vuz.getTagName()))
					setRef("vagon_ref");
			}

			vlak.removeChild(child);
		}

		if(pocet_vozu > 0)
			razeni_val.append(razeni_vozu[0]);

		for(int j = 1; j < pocet_vozu; ++j) {
			razeni_val.append(" ");
			razeni_val.append(razeni_vozu[j]);
		}

		vlak.setAttribute("razeni_vozu", razeni_val.toString());
	}
    }
}
