//Pridani nove budovy... odebrani jin budovy
package user;
import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

public class MyDomTransformer {
    
public void transform (Document xmlDocument) {
createNewHouse(xmlDocument);
       removeOldHouse(xmlDocument); 
  }

    static void removeOldHouse(Document doc){
       NodeList dite = doc.getElementsByTagName("budova");
        for (int i = dite.getLength() - 1; i >= 0; --i)
        {
            Element kid = (Element) dite.item(i);
            Element count = (Element) kid.getElementsByTagName("kapacita").item(0);
            int cnt = Integer.parseInt(count.getTextContent());
            if (cnt > 5)
            {
                kid.getParentNode().removeChild(kid);
            }
        }
    }
    
    
    static void createNewHouse(Document doc){
            Element item = doc.createElement("budova");
        item.appendChild(doc.createElement("cislo")).setTextContent("3");
        Element tmp=doc.createElement("typ");tmp.setAttribute("type", "drevo");item.appendChild(tmp);
        item.appendChild(doc.createElement("kapacita")).setTextContent("7");
        tmp=doc.createElement("kuchynka");tmp.setAttribute("kuch", "ne");item.appendChild(tmp);
        tmp=doc.createElement("umisteni");tmp.setAttribute("place", "hriste");item.appendChild(tmp);


        NodeList eq = doc.getElementsByTagName("tabor");
        Element equipment;
        if (eq.getLength() == 0)
        {
            equipment = doc.createElement("tabor");
            doc.getFirstChild().appendChild(equipment);
        }else{
            equipment = (Element)eq.item(0);
        }

        equipment.appendChild(item);
    }
}