

/*
-Zjistim najmensi a nejvetsi kapacity chatek
-zjistim pocet naplavcu mezi detmy a vratim kolik to je procent ze vsech deti
-zjistim jake deti jsou vegetariani a zjistim jejich prumernou vysku

*/

package user;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.helpers.DefaultHandler;
import org.w3c.dom.Document;


public class MySaxHandler extends DefaultHandler {
  int tempCapacity;
    int minCapacity=-1;
    int maxCapacity;
    int neplavcu = 0;
    int sumOfChildren = 0;
    int sumOfVegetarians = 0;
    int sumOfHeight = 0;
    String lastString;
    

    // Helper variable to store location of the handled event
    Locator locator;


    /**
     * Sets the locator
     *
     * @param Locator locator location in the file
     */
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Method to handle "document start"
     *
     * @throws SAXException
     */
    @Override
    public void startDocument() throws SAXException {
        // ...
    }

    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
//ELEM max/min kapacita chatek
        if (minCapacity < 0) {
            System.out.println("V tabore nejsou zadne chatky");
        } else {
            System.out.println("Kapacita chatek: MIN:" + minCapacity + " MAX:" + maxCapacity);
        }
        //ATTR procentualni pocet neplavcu mezi detmi
        if (sumOfChildren == 0) {
            System.out.println("Na tabor najsou zatim prihlaseny zadne deti");
        } else {//(neplavcu / sumOfChildren) * 100
            System.out.println("Na Tabore je " + sumOfChildren + " z toho " + ((double)neplavcu / sumOfChildren) * 100 + "% je neplavcu");
        }
//CONTENT prumerna vyska vegetarianu
        if (sumOfVegetarians == 0) {
            System.out.println("Na tabor najsou zadny vegetariani");
        } else {
            System.out.println("Prumerna vyska vegetarianu na tabore je " + (double)sumOfHeight / sumOfChildren + "cm");
        }

    }

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
            if (localName.equals("dite")) {
            sumOfChildren++;//spocitani deti na tabore
        }
            if(localName.equals("plavec")){
            for (int j = 0; j < atts.getLength(); j++) {
               if(atts.getLocalName(j).equals("plave") && atts.getValue(j).equals("ne")) neplavcu++;
            }
            }
                    if(localName.equals("vegetarian")){
            for (int j = 0; j < atts.getLength(); j++) {
               if(atts.getLocalName(j).equals("veget") && atts.getValue(j).equals("ano")) sumOfVegetarians++;
            }
            }
        }
    

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
if(localName.equals("vyska"))sumOfHeight+= Integer.parseInt(lastString);
    
   if(localName.equals("kapacita")){tempCapacity= Integer.parseInt(lastString);
   if(minCapacity<0){
minCapacity=tempCapacity;
maxCapacity=tempCapacity;
   }else{
   if(tempCapacity<minCapacity)minCapacity=tempCapacity;
       if(tempCapacity>maxCapacity)maxCapacity=tempCapacity;
   }
   }

        
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        boolean allWhitespace = true;
        for (int i = start; i < start + length; i++) {
            if (!Character.isWhitespace(chars[i])) {
                allWhitespace = false;
            }
        }
        if (allWhitespace) {
            return;
        }

        lastString = "";
        for (int j = start; j < start + length; j++) {
            lastString = lastString + chars[j];
        }

    }

    /**
     * Method to handle " start of namespace declaration"
     *
     * @param prefix Prefix of the namespace
     * @param uri URI of the namespace
     * @throws SAXException
     */
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    /**
     * Method to handle "end of namespace declaration"
     *
     * @param prefix
     * @throws SAXException
     */
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    /**
     * Method to handle "ignoring of whitespaces" Text is in array 'chars' from
     * position ('start') to ('start' + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     * @throws SAXException
     */
    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
        // ...
    }

    /**
     * Method to handle "processing instructions"
     *
     * @param target The processing instruction target
     * @param data The processing instruction data
     * @throws SAXException
     */
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

    /**
     * Method to handle "unprocessed entity"
     *
     * @param name
     * @throws SAXException
     */
    @Override
    public void skippedEntity(String name) throws SAXException {
        // ...
    }
}

