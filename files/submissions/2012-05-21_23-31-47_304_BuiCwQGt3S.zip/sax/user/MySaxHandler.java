/*
 * created by: Michal Svacha @CTU
 * twitter:    @Miguelitinho
 * mail:       michal.svacha@casablanca.cz
 */
package user;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * @author michalsvacha
 */
public class MySaxHandler extends DefaultHandler {
    int numberOfAdmins;
    int numberOfPlayers;
    
    // number of occurences of tags
    HashMap<String, Integer> tags;
    
    // length of attributes
    HashMap<String, Integer> atributes;
    
    // nesting status of every element
    int nestingStatus = 0;
    HashMap<String, Integer> nesting;
    
    // hierarchy of every tag
    ArrayList<String> tagHierarchyList;
    HashMap<String, ArrayList<String>> tagHierarchyMap;
    
    // length of text in tag
    ArrayList<Integer> charLength;
    
    public MySaxHandler() {
        tags = new HashMap<String, Integer>();
        atributes = new HashMap<String, Integer>();
        nesting = new HashMap<String, Integer>();
        tagHierarchyList = new ArrayList<String>();
        tagHierarchyMap = new HashMap<String, ArrayList<String>>();
        charLength = new ArrayList<Integer>();
    }

    @Override
    public void startDocument() throws SAXException {
        System.out.println("Starting parsing");
    }

    @Override
    public void endDocument() throws SAXException {
        int tmp = 0;
        int max = -1;
        Iterator it = tags.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pairs = (Map.Entry)it.next();
            if((Integer)pairs.getValue() > max) max = (Integer)pairs.getValue();
            tmp += (Integer)pairs.getValue();
        }
        System.out.println("Average occurences of tags: " + tmp/tags.size());
        System.out.println("Max occurence is: " + max);
        
        tmp = 0;
        max = -1;
        for (int a : charLength) {
            if(a > max) max = a;
            tmp += a;
        }
        System.out.println("Average length of text inside element: " + tmp/charLength.size() + " characters");
        System.out.println("Max length is: " + max + " characters");
        
        tmp = 0;
        max = -1;
        it = atributes.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pairs = (Map.Entry)it.next();
            if((Integer)pairs.getValue() > max) max = (Integer)pairs.getValue();
            tmp += (Integer)pairs.getValue();
        }
        System.out.println("Average number of attributes: " + tmp/atributes.size());
        System.out.println("Max number of attributes: " + max);
        
        tmp = 0;
        max = -1;
        String nestingMax = null;
        it = nesting.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pairs = (Map.Entry)it.next();
            if((Integer)pairs.getValue() > max) {
                max = (Integer)pairs.getValue();
                nestingMax = (String)pairs.getKey();
            }
            tmp += (Integer)pairs.getValue();
        }
        System.out.println("Average number fan out: " + tmp/nesting.size());
        System.out.println("Max number of fan out: " + max);
        System.out.println("Max fan out tag: " + nestingMax);
        System.out.println(tagHierarchyMap.get(nestingMax));
        
        System.out.println("Endind parsing");
    }

    @Override
    public void startElement(String string, String string1, String string2, Attributes atrbts) throws SAXException {
        nestingStatus++;
        tagHierarchyList.add(string2);
        
        if(!tags.containsKey(string2)) {
            tags.put(string2, 1);
        } else {
            int tmp = tags.get(string2);
            tmp++;
            tags.put(string2, tmp);
        }
        if(!atributes.containsKey(string2)) {
            if(atrbts.getLength() != 0) atributes.put(string2, atrbts.getLength());
        } else {
            if(atributes.get(string2) < atrbts.getLength()) atributes.put(string2, atrbts.getLength());
        }
    }

    @Override
    public void endElement(String string, String string1, String string2) throws SAXException {
        if(!tagHierarchyMap.containsKey(string2)) {
            tagHierarchyMap.put(string2, new ArrayList<String>(tagHierarchyList));
            // System.out.println(tagHierarchyList);
        } else {
            if(tagHierarchyList.size() > tagHierarchyMap.get(string2).size()) tagHierarchyMap.put(string2, new ArrayList<String>(tagHierarchyList));
        }
        tagHierarchyList.remove(string2);
        
        if(!nesting.containsKey(string2)) {
            nesting.put(string2, nestingStatus);
        } else {
            if(nesting.get(string2) < nestingStatus) nesting.put(string2, nestingStatus);
        }
        nestingStatus--;
    }

    @Override
    public void characters(char[] chars, int i, int i1) throws SAXException {
        charLength.add(i1);
    }

    public static void main(String[] args) {
        SAXParserFactory factory = SAXParserFactory.newInstance();
        try {
            SAXParser saxParser = factory.newSAXParser();
            MySaxHandler handler = new MySaxHandler();
            saxParser.parse("data.xml", handler);
        } catch (Exception ex) {
            System.err.println(ex.getMessage());
        }
    }
}