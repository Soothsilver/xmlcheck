/*
 * created by: Michal Svacha @CTU
 * twitter:    @Miguelitinho
 * mail:       michal.svacha@casablanca.cz
 */
package user;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

/**
 *
 * @author michalsvacha
 */
public class MyDomTransformer {

    static Document doc;

    public MyDomTransformer() {
        /*
        File fXmlFile = new File("data.xml");
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        dbFactory.setValidating(false);
        DocumentBuilder dBuilder;
        try {
            dBuilder = dbFactory.newDocumentBuilder();
            doc = dBuilder.parse(fXmlFile);
        } catch (ParserConfigurationException ex) {
            System.err.println(ex.getMessage());
        } catch (SAXException ex) {
            System.err.println(ex.getMessage());
        } catch (IOException ex) {
            System.err.println(ex.getMessage());
        }
        */
    }

    public void transform(Document doc) {
        doc.getDocumentElement().normalize();

        /*
        System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
        NodeList nList = doc.getElementsByTagName("player");
        System.out.println("-----------------------");

        for (int temp = 0; temp < nList.getLength(); temp++) {
            Node nNode = nList.item(temp);
            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                Element eElement = (Element) nNode;
                System.out.println("First Name : " + getTagValue("first_name", eElement));
                System.out.println("Last Name : " + getTagValue("last_name", eElement));
                System.out.println("Nick Name : " + getTagValue("nickname", eElement));
                System.out.println("E-mail : " + getTagValue("email", eElement));
                System.out.println("_____________");
            }
        }
        *
        */

        // sets the root node
        Element root = doc.getDocumentElement();
        
        // gets comment at the beginning of the xml
        String comment = root.getFirstChild().getNextSibling().getTextContent();
        comment = comment.replaceAll(">", "").replaceAll("<", "");
        
        // removes it and sets it as an attribute
        root.removeChild(root.getFirstChild().getNextSibling());
        root.setAttribute("info", comment);
        
        // Asks for all administrators
        NodeList admin = root.getElementsByTagName("administrator");
        for (int i = 0; i < admin.getLength(); i++) {
            Element t = (Element) admin.item(i);

            // get the name node, which contains first and last name
            Element nameNode = (Element) t.getFirstChild().getNextSibling();
            
            // gets first name and trasforms it from tag to attribute
            Element firstName = (Element) nameNode.getFirstChild().getNextSibling();
            String nameString = ((Text) firstName.getFirstChild()).getNodeValue();
            nameNode.setAttribute("first_name", nameString);
            nameNode.removeChild(firstName);

            // gets last name and transforms it from tag to attribute
            Element lastName = (Element) nameNode.getFirstChild().getNextSibling().getNextSibling();
            nameString = ((Text) lastName.getFirstChild()).getNodeValue();
            nameNode.setAttribute("last_name", nameString);
            nameNode.removeChild(lastName);

            // gets admin's nickname and transforms it from attribute to tag
            String _nickname = t.getAttribute("nickname");
            Element nickname = doc.createElement("adm_nickname");
            Text nicknameText = doc.createTextNode(_nickname);
            nickname.appendChild(nicknameText);
            t.insertBefore(nickname, t.getFirstChild());
            
            // removes any social network info
            t.removeChild(t.getLastChild().getPreviousSibling());
        }
        // creates map for storing all IDs
        HashMap<String,String> map = new HashMap<String, String>();
        
        // gets all players
        NodeList players = root.getElementsByTagName("player");
        // saves ID and name to the map
        for (int i = 0; i < players.getLength(); i++) {
            Element t = (Element) players.item(i);
            // System.out.println(t + " " + i);
            
            String id = t.getAttribute("id");
            StringBuffer buf = new StringBuffer();
            buf.append(getTagValue("first_name", t)).append(" ").append(getTagValue("last_name", t));
            map.put(id, buf.toString());
            
            // removes any social network info
            (t.getLastChild().getPreviousSibling().getPreviousSibling().getPreviousSibling())
                    .removeChild(t.getLastChild().getPreviousSibling().getPreviousSibling().getPreviousSibling().getLastChild().getPreviousSibling());
        }
        
        // links target_player to the map and puts in another tag with name
        for (int j = 0; j < players.getLength(); j++) {
            Element t = (Element) players.item(j);
            Element prey = (Element) t.getLastChild().getPreviousSibling();
            String preyID = prey.getAttribute("id_ref");
            
            Element target_player = doc.createElement("tp_name");
            Text nicknameText = doc.createTextNode(map.get(preyID));
            target_player.appendChild(nicknameText);
            prey.appendChild(target_player);
            
            // if address tags are empty, it removes them
            Element address = (Element) t.getElementsByTagName("address").item(0);
            if(address.getFirstChild().getNextSibling().getTextContent().equals("")) {
                address.removeChild(address.getFirstChild().getNextSibling());
            }
            
            if(address.getFirstChild().getNextSibling().getNextSibling().getTextContent().equals("")) {
                address.removeChild(address.getFirstChild().getNextSibling().getNextSibling());
            }
            
            if(address.getFirstChild().getNextSibling().getNextSibling().getNextSibling().getTextContent().equals("")) {
                address.removeChild(address.getFirstChild().getNextSibling().getNextSibling().getNextSibling());
            }    
        }
        
        // saves to file
        String outfile = "data.out.xml";
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer writer;
        try {
            writer = tf.newTransformer();
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            writer.transform(new DOMSource(doc), new StreamResult(new File(outfile)));
        } catch (TransformerException ex) {
            System.err.println(ex.getMessage());
        }
    }

    private static String getTagValue(String sTag, Element eElement) {
        NodeList nlList = eElement.getElementsByTagName(sTag).item(0).getChildNodes();
        Node nValue = (Node) nlList.item(0);
        return nValue.getNodeValue();
    }

    public static void main(String[] args) {
        //MyDomTransformer m = new MyDomTransformer();
        //m.transform(doc);
    }
}