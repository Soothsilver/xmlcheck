package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class MyDomTransformer {
	public void transform (Document xmlDocument) {
		// Insert
		int max_id = 0;
		Element people = (Element) xmlDocument.getElementsByTagName("people").item(0);
		
		NodeList personList = people.getElementsByTagName("person");
		for (int i = 0; i < personList.getLength(); ++i) {
			Element p = (Element) personList.item(i);
			String id = p.getAttribute("id");
			int iid = Integer.parseInt(id.substring(id.indexOf('_') + 1));
			if (iid > max_id) max_id = iid;
		}
		
		Element person = xmlDocument.createElement("person");
		person.appendChild(xmlDocument.createElement("name")).setTextContent("Pavel");
		person.appendChild(xmlDocument.createElement("surname")).setTextContent("Hora");
		person.setAttribute("id", "prsn_" + (max_id+1));
		people.appendChild(person);
		
		// Delete
		NodeList teams = xmlDocument.getElementsByTagName("team");
		for (int i = 0; i < teams.getLength(); ++i) {
			Element t = (Element) teams.item(i);
			Element m = (Element) t.getElementsByTagName("members").item(0);
			if (m.getElementsByTagName("person-ref").getLength() == 0)
				t.getParentNode().removeChild(t);
		}
	}
}