package user;

import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
	private int max_person_id = 0;

	private int notes_cnt = 0;
	private int notes_chars_cnt = 0;
	private boolean is_note = false;
	
	private String cur_team = "";
	private int team_name_length = 0;
	private int team_members_cnt = 0;
	private boolean is_team_name = false;
	
    public void startElement(String uri, String localName, String qName, Attributes atts) {
    	// Attribute - max person id
        if (localName.equals("person")) {
	        String id = atts.getValue("id");
	        id = id.substring(id.indexOf('_') + 1);
	        int p = Integer.parseInt(id);
	        if (p > max_person_id) max_person_id = p;
        }
        
        // Element content - average note length
        if (localName.equals("note")) {
        	++notes_cnt;
        	is_note = true;
        }
        
        // Context - teams without members and their name has 3 or more characters
        if (localName.equals("team")) {
        	cur_team = atts.getValue("id");
        	team_name_length = 0;
        	team_members_cnt = 0;
        }
        if (!cur_team.isEmpty() && localName.equals("name")) is_team_name = true;
        if (!cur_team.isEmpty() && localName.equals("person-ref")) ++team_members_cnt;
    }
    
    public void endElement(String uri, String localName, String qName) {
    	if (localName.equals("note")) is_note = false;
    	
    	if (localName.equals("team")) {
    		if (team_name_length >= 3 && team_members_cnt == 0) {
    			System.out.println("Empty team: " + cur_team);
    		}
    		cur_team = "";
    	}
    	if (!cur_team.isEmpty() && localName.equals("name")) is_team_name = false;
    }
    
    public void characters(char[] chars, int start, int length) {
        if (is_note) notes_chars_cnt += length;
        
        if (is_team_name) team_name_length += length;
    }
    
    public void endDocument() {
        System.out.println("Max person id: prsn_" + max_person_id);
        System.out.println("Average note length: " + (notes_chars_cnt / notes_cnt));
    }
}