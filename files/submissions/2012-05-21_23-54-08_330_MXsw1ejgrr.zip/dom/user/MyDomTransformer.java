/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

/**
 *
 * @author Peta
 */
public class MyDomTransformer {
    public void transform (Document xmlDocument) {
        // exclude unimportant info - set catalogue as document root
        Element e = (Element)xmlDocument.getElementsByTagName("catalogue").item(0);
        xmlDocument.removeChild(xmlDocument.getDocumentElement());
        xmlDocument.appendChild(e);
        
        // extract products
        NodeList products = e.getElementsByTagName("product");
        for (int i = products.getLength()-1; i >= 0 ; i--) {
            transformProduct((Element)products.item(i), xmlDocument);
            e.appendChild(products.item(i));
        }
        
        // delete categories
        NodeList categories = e.getElementsByTagName("category");
        for (int i = categories.getLength()-1; i >= 0; i--) {
            categories.item(i).getParentNode().removeChild(categories.item(i));
        }
    }
    
    protected void transformProduct(Element product, Document doc) {
        // attribute to element
        Element id = doc.createElement("id");
        Text idText = doc.createTextNode(product.getAttribute("id"));
        id.appendChild(idText);
        product.insertBefore(id,product.getFirstChild());
        product.removeAttribute("id");
        
        // element to attribute
        Attr img = doc.createAttribute("img_url");
        NodeList url = product.getElementsByTagName("img_url");
        img.setValue(url.item(0).getTextContent());
        product.setAttributeNode(img);
        product.removeChild(url.item(0));
    }
    
    public static void main(String[] args) {
        String filename = "data.xml";
		String outfile = "data.out.xml";
        
		try {
            
            //DocumentBuilderFactory vytvori DOM parsery
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            //vypne validaci
            dbf.setValidating(false);

            //vytvori si DOM parser
            DocumentBuilder builder = dbf.newDocumentBuilder();

            //parser zpracuje vstupni soubor a vytvori z nej strom DOM objektu           
            Document doc = builder.parse(filename);

            //zpracuje DOM strom
            MyDomTransformer mdt = new MyDomTransformer();
            mdt.transform(doc);

            TransformerFactory tf = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer = tf.newTransformer();

            //nastaveni kodovani
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spusti transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(new File(outfile)));


        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
