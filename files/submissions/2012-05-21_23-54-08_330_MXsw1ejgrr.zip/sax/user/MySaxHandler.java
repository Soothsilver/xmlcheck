/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.util.HashMap;
import java.util.Map;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * @author Peta
 */
public class MySaxHandler extends DefaultHandler {
    int elementCnt = 0;
	int attributeCnt = 0;
    int depth = 0;
    int depthMax = 0;
    String depthMaxName = "-";
    double depthTotal = 0;
    Map<String,Integer> elements;
    int elemsWithText = 0;
    int elemsWithAttr = 0;
    Map<String,Integer> attributes;
    boolean textContent = false;
    
    @Override
    public void startDocument() throws SAXException {
        elements = new HashMap<String, Integer>();
        attributes = new HashMap<String, Integer>();
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        elementCnt++;
        attributeCnt += attributes.getLength();
        depthTotal += depth;
        if (depthMax < depth) {
            depthMax = depth;
            depthMaxName = qName;
        }
        depth++;
        
        if (attributes.getLength() > 0) {
            elemsWithAttr++;
        }
        
        Integer count = this.elements.get(qName);
        if(count == null) count = 0;
        count++;
        this.elements.put(qName,count);
        
        String attrName;
        for(int i = 0; i < attributes.getLength(); i++){
        	attrName = attributes.getLocalName(i);  
        	count = this.attributes.get(attributes.getLocalName(i));
        	if(count == null) count = 0;
        	count++;
        	this.attributes.put(attrName,count);
        }
        
        textContent = true;
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        depth--;
        textContent = false;
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        if ((new String(ch, start, length)).trim().length() > 0 && textContent) {
            elemsWithText++;
            textContent = false;
        }
    }
    

    @Override
    public void endDocument() throws SAXException {
        // elements
        System.out.println("-- Elements --");
        System.out.println("Total count: " + elementCnt);
        System.out.println("With text count: "+elemsWithText);
        System.out.println("With attributes count: "+elemsWithAttr);
        Integer elemMaxCount = 0;
        String elem = "-";
        Integer elemCount = 0;
        for (String key : this.elements.keySet()){
        	elemCount = this.elements.get(key);
        	if(elemCount > elemMaxCount){
        		elem = key;
        		elemMaxCount = elemCount;
        	}
        }
        System.out.println("Most frequent: "+elem+" ("+elemCount+')');
        
        // attributes
        System.out.println();
        System.out.println("-- Attributes --");
        System.out.println("Attribute count: " + attributeCnt);
        Integer attrMaxCount = 0;
        String attr = "-";
        Integer attrCount = 0;
        for (String key : this.attributes.keySet()){
        	attrCount = this.attributes.get(key);
        	if(attrCount > attrMaxCount){
        		attr = key;
        		attrMaxCount = attrCount;
        	}
        }
        System.out.println("Most frequent: "+attr+" ("+attrCount+')');
        
        // depth
        System.out.println();
        System.out.println("-- Depth --");
        System.out.println("Average: " + (depthTotal/elementCnt));
        System.out.println("Maximal: "+depthMax+" ("+depthMaxName+')');
    }
    
    public static void main(String[] args) {
        String filename = "data.xml";
        
        try {            
            SAXParserFactory spfactory = SAXParserFactory.newInstance();
            spfactory.setValidating(false);
            
            SAXParser saxparser = spfactory.newSAXParser();
            
            XMLReader xmlreader = saxparser.getXMLReader();
            
            xmlreader.setContentHandler(new MySaxHandler());
            xmlreader.setErrorHandler(new MySaxHandler());
            
            InputSource source = new InputSource(filename);
            xmlreader.parse(source);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}
