package user;

import org.w3c.dom.*;

public class MyDomTransformer{
    public static void transform(Document doc) {
        Element pivo=doc.createElement("pivo");
        Attr pid=doc.createAttribute("pid");
        pid.setValue("ctyry");
        pivo.setAttributeNode(pid);
        Element nazev=doc.createElement("nazev");
        Element popis=doc.createElement("popis");
        Element skladem=doc.createElement("skladem");
        Element sudu=doc.createElement("lahvi");
        Element lahvi=doc.createElement("sudu");
        nazev.appendChild(doc.createTextNode("Svetla 11�"));
        popis.appendChild(doc.createTextNode("Nove pivo, ktere se jeste ani nevari"));
        skladem.appendChild(doc.createTextNode("Celkem 0 litru"));
        sudu.appendChild(doc.createTextNode("0"));
        lahvi.appendChild(doc.createTextNode("0"));
        pivo.appendChild(nazev);
        pivo.appendChild(popis);
        pivo.appendChild(skladem);
        skladem.appendChild(sudu);
        skladem.appendChild(lahvi);
        doc.getElementsByTagName("produkty").item(0).appendChild(pivo);
        //konec pridani piva
        //druha uprava
        //smazani vsech obednavek, kde je datum mensi jak 2005
        NodeList zakaznici=doc.getElementsByTagName("zakaznik");
        for (int i = 0; i < zakaznici.getLength(); i++) {
            NodeList objednavky=zakaznici.item(i).getChildNodes();
            for (int j = 0; j < objednavky.getLength(); j++) {
                if(objednavky.item(j) instanceof Element){
                    NamedNodeMap atributy = objednavky.item(j).getAttributes();
                    String datum = atributy.getNamedItem("datum").getNodeValue();
                    int rok=Integer.parseInt(datum.substring(datum.length()-4));
                    if(rok<2005) //ondstranime polozku ze seznamu objednavek
                    {
                        zakaznici.item(i).removeChild(objednavky.item(j));
                    }
                }
            }
        }
    }
}
