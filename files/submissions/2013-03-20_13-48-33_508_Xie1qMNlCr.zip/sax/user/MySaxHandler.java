package user;

import java.util.HashMap;
import java.util.Set;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;


public class MySaxHandler extends DefaultHandler {
    //hodnota atributu: prumerny pocet objednavek v lahvi (jakehokoli piva)
    //obsah elementu: nejcastejsi primeni
    //kontext: pocet zamestnancu co sice bydlej v praze, ale ne na praze 1

    
    private int pocet_objednavek; //celkovy pocet obednavek, kde se obednavali lahve
    private int suma; //suma lahvi
    private int pocet_zam;
    private boolean primeni, praha, mesto,cast;
    private HashMap<String, Integer> cetnost;

    @SuppressWarnings("empty-statement")
    private String find_max() {
        //vrati nejcastejsi primeni
        String s = "";
        int max = 0;
        Set<String> ss = cetnost.keySet();
        for (String sm : ss) {
            if (cetnost.get(sm) > max) {
                max = cetnost.get(sm);
                s = sm;
            }
        }
        return s;
    }

    @Override
    public void startDocument() throws SAXException {
        pocet_objednavek = 0;
        suma = 0;
        pocet_zam = 0;
        primeni = false;
        cetnost = new HashMap<String, Integer>();
        mesto=false;
        praha=false;
        cast=false;
        pocet_zam=0;
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        if (localName.equals("objednavka")) {
            if (attributes.getValue("preprava").equals("lahve")) {
                pocet_objednavek++;
                suma += Integer.parseInt(attributes.getValue("pocet"));
            }
        }
        if (localName.equals("primeni")) {
            primeni = true;
        }
        if (localName.equals("mesto")) {
            mesto = true;
        }
        
        if (localName.equals("cast")) {
            cast = true;
        }
    }

    @Override
    public void endDocument() throws SAXException {
        //vystup
        System.out.println("Prumerny pocet obednanych lahvi v jedne obednavce je:" + suma / pocet_objednavek + " lahvi");
        System.out.println("Nejcastejsi primeni je: " + find_max());
        System.out.println("Pocet prazanu, co nebydli na Praze 1 je: "+pocet_zam);
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (localName.equals("primeni")) {
            primeni = false;
        }
        if (localName.equals("mesto")) {
            mesto = false;
            praha = false;
        }
        
        if (localName.equals("cast")) {
            cast = false;
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        if (primeni) {
            String s = "";
            for (int i = start; i - start < length; i++) {
                s += ch[i];
            }
            s = s.replaceAll("\t", ""); //odstraneni tabulatoru ze vstupu
            s = s.replaceAll("\n", "");
            if (cetnost.containsKey(s)) {
                cetnost.put(s, cetnost.get(s) + 1);
            } else {
                cetnost.put(s, 1);
            }
        }
        if (mesto && !praha) {
            String s = "";
            for (int i = start; i - start < length; i++) {
                s += ch[i];
            }
            s = s.replaceAll("\t", "");
            s = s.replaceAll("\n", "");
            if(s.equals("Praha")){
                praha=true;
            }
        }
        if(cast && praha){
            String s = "";
            for (int i = start; i - start < length; i++) {
                s += ch[i];
            }
            s = s.replaceAll("\t", "");
            s = s.replaceAll("\n", "");
            if(!s.equals("Praha 1")){
                pocet_zam++;
            }
        }

    }

}
