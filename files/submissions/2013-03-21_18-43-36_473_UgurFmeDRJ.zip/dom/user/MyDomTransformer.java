package user; 

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;


/*
 * Prvni cast odstrani elementy tykajici se otviraci doby
 * Druha cast na stejne misto vrati elementy s standartizovanou dobou
 * Treti cast vyzobe vsechny objednane zbrane, seradi je podle ceny a vrati
 */
public class MyDomTransformer {
    
        
    String[] days = {"pondeli","utery","streda","ctvrtek","patek","sobota","nedele"};
    public void transform (Document xmlDocument) {
        
        // odstrani elementy tykajici se otviraci doby
        NodeList activeNodeList = xmlDocument.getElementsByTagName("otviraci-den");
        for (int i = activeNodeList.getLength()-1; i >= 0; i--) 
            activeNodeList.item(i).getParentNode().removeChild(activeNodeList.item(i));
        
        // vlozi standartni otviraci dobu
        activeNodeList = xmlDocument.getElementsByTagName("otevreno");
        for (int i=0;i<days.length;i++)
            activeNodeList.item(0).appendChild(xmlDocument.createElement("otviraci-den"));

        activeNodeList = xmlDocument.getElementsByTagName("otviraci-den");
        for (int i = activeNodeList.getLength()-1; i >= 0; i--) 
        {
            Element e = (Element)activeNodeList.item(i);
            e.setAttribute("den", days[i]);
            Element elow = (Element)e.appendChild(xmlDocument.createElement("otviraci-doba"));
            elow.setAttribute("od", "8:00");
            elow.setAttribute("do", "20:00");
        }
        
        //vyzobe vsechny objednane zbrane, seradi je sestupne podle ceny a vrati
        ArrayList<Weapon> weapons = new ArrayList<Weapon>();
        activeNodeList = xmlDocument.getElementsByTagName("objednane-zbrane");
        
        for (int i = activeNodeList.getLength()-1; i >= 0; i--) 
        {
            Element temp = (Element)activeNodeList.item(i);
            NodeList weaponList = temp.getElementsByTagName("objednana-zbran");
            for (int j = weaponList.getLength()-1; j >=0; j--) {
                Weapon w = new Weapon();
                Element e = (Element)weaponList.item(j);
                w.id = e.getAttribute("id");
                w.date = ((Element)e.getElementsByTagName("datum-planovaneho-prichodu").item(0)).getTextContent();
                w.price = Integer.parseInt(((Element)e.getElementsByTagName("cena").item(0)).getTextContent());
                weapons.add(w);
                activeNodeList.item(i).removeChild(e);
            }
            
            Collections.sort(weapons);
            
            for (int t=0;t<weapons.size();t++)
                activeNodeList.item(i).appendChild(xmlDocument.createElement("objednana-zbran"));
            
            weaponList = temp.getElementsByTagName("objednana-zbran");
            for (int j = 0; j <weaponList.getLength(); j++)
            {
                Element e = (Element)weaponList.item(j);
                ((Element)e.appendChild(xmlDocument.createElement("datum-planovaneho-prichodu"))).setTextContent(weapons.get(j).date);
                ((Element)e.appendChild(xmlDocument.createElement("cena"))).setTextContent(String.valueOf(weapons.get(j).price));
                e.setAttribute("id", weapons.get(j).id);
            }
            weapons.clear();
        }

    }
 }



class Weapon implements java.lang.Comparable<Weapon>
{
    public String id;
    public String date;
    public int price;

    public int compareTo(Weapon o) {
        return (int)Math.signum(o.price-price);
    }

    @Override
    public String toString() {
        return "id: "+id+" date: "+date+" price: "+price;
    }
}