package user; 
import org.xml.sax.helpers.DefaultHandler; 
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.helpers.DefaultHandler;

/**
 * @author moravm13
 * Vypocte prumernou vahu majitelu.
 * Zjisti nejcetnejsi prijmeni v dokumentu.
 * Vypise identifikacni cisla zbrani, ktere maji pujcovny objednane a ktere prijdou po roce 2014 a nestoji vice nez 30000kc.
 */
public class MySaxHandler extends DefaultHandler {

    ArrayList<Integer> weight = new ArrayList<Integer>();
    OccuranceMap<String> name = new OccuranceMap<String>();
    ArrayList<String> weaponsId = new ArrayList<String>();
    
    public void endDocument() throws SAXException {
        
        int temp = 0;
        for (Integer i : weight) temp+=i.intValue();
        System.out.println("Prumerna hmotnost majitelu je " + (temp/weight.size()) + "kg.");
        System.out.print("Nejcetnejsi prijmeni v dokumentu: ");
        name.printMax();
        
        System.out.print("Id objednanych zbrani, ktere prijdou po roce 2014 ale nestaly vice nez 30000kc: ");
        for (String s : weaponsId) System.out.print(s+", ");
        System.out.println("");
    }
    
    boolean bPrijmeni=false;
    String orderedWeaponId=null;
    boolean bOrderedWeaponDate=false;
    boolean bOrderedWeaponPrice=false;
    public void startElement(String uri, String localName, String tag, Attributes atts) throws SAXException {

        if (localName.equals("majitel"))
        {
            for (int i = 0; i < atts.getLength(); i++) {
                if (atts.getLocalName(i).equals("vaha"))
                    weight.add(Integer.parseInt(atts.getValue(i)));
            }
        }
        
        if (localName.equals("objednana-zbran"))
        {
            for (int i = 0; i < atts.getLength(); i++) {
                if (atts.getLocalName(i).equals("id"))
                    orderedWeaponId = atts.getValue(i);
            }
        }
        
        bOrderedWeaponDate = localName.equals("datum-planovaneho-prichodu") && orderedWeaponId!=null;
        bOrderedWeaponPrice = localName.equals("cena") && orderedWeaponId!=null;
        bPrijmeni = localName.equals("prijmeni");
    }

    public void endElement(String uri, String localName, String tag) throws SAXException {

        if (localName.equals("objednana-zbran") && orderedWeaponId!=null)
        {
            weaponsId.add(orderedWeaponId);
            orderedWeaponId=null;
        }
    }
   
    public void characters(char[] ch, int start, int lenght) throws SAXException {
        
        String temp="";
        for (int i=start;i<lenght+start;i++)
            temp+=ch[i];
        
        if (bOrderedWeaponPrice && Integer.parseInt(temp)>=30000)
                orderedWeaponId=null;
        
        if (bOrderedWeaponDate)
        {
            String[] date = temp.split("\\.");
            if (Integer.parseInt(date[2])<2014)
                orderedWeaponId=null;
        }
        
        if (bPrijmeni) name.put(temp);
    }
}



class OccuranceMap<T> extends HashMap<T,Integer>
{
    public void put(T key) {
        if (containsKey(key))
        {
            Integer temp = get(key);
            put(key, temp+1);
        }
        else put(key, 1); 
    }
    public int getOccurance(T key){
        return get(key);
    }
    public void printMax(){
        T key = null;
        int max=0;
        for (Map.Entry<T,Integer> e : entrySet())
        {
            if (max<e.getValue()) 
            {
                max=e.getValue();
                key=e.getKey();
            }
        }
        System.out.println(key.toString()+" "+max+"x");
    }
}