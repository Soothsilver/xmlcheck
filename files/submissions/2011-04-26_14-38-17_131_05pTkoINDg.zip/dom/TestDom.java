import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

import cz.XmlTester.*;


public class TestDom extends TestJava {
    private static final String VSTUPNI_SOUBOR = "../data.xml";
    private static final String VYSTUPNI_SOUBOR = "../data-output.xml";

    public void run() {

        try {

            //DocumentBuilderFactory vytv��� DOM parsery
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            //nebudeme validovat
            dbf.setValidating(false);

            //vytvo��me si DOM parser
            DocumentBuilder builder = dbf.newDocumentBuilder();

            //parser zpracuje vstupn� soubor a vytvo�� z n�j strom DOM objekt�
            Document doc = builder.parse(VSTUPNI_SOUBOR);

            //zisk�me hlavni element
            Node mainNode = doc.getDocumentElement();

            //zpracujeme DOM strom
            processNode(mainNode);

            //TransformerFactory vytv��� serializ�tory DOM strom�
            TransformerFactory tf = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer = tf.newTransformer();

            //nastav�me kodov�n�
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spust�me transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


        } catch (Exception e) {

            e.printStackTrace();

        }
    }

    /**
     * Zpracuje DOM strom
     */
    private void processNode(Node node) {
        if (node == null)
            return;

        if (node.getNodeType() == Node.TEXT_NODE)
        {
            String value = node.getNodeValue().trim();
            if (value.isEmpty())
                return;

            Node parent = node.getParentNode();
            if (parent == null || parent.getNodeType() != Node.ELEMENT_NODE)
                return;

            ((Element)parent).setAttribute("TextValue", value);
            parent.removeChild(node);
        }

        NodeList children = node.getChildNodes();
        for (int i = 0; i < children.getLength(); ++i)
            processNode(children.item(i));
    }
}
