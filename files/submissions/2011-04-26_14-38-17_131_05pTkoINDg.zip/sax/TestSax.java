import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;

import java.util.Stack;

import cz.XmlTester.*;


public class TestSax extends TestJava {
    public void run() {

        // Cesta ke zdrojov�mu XML dokumentu
        String sourcePath = "../data.xml";

        try {

            // Vytvo��me instanci parseru.
            XMLReader parser = XMLReaderFactory.createXMLReader();

            // Vytvo��me vstupn� proud XML dat.
            InputSource source = new InputSource(sourcePath);

            // Nastav�me n� vlastn� content handler pro obsluhu SAX ud�lost�.
            MyContentHandler handler = new MyContentHandler();
            parser.setContentHandler(handler);

            // Zpracujeme vstupn� proud XML dat.
            parser.parse(source);

            // Zobraz�me v�lsedky.
            System.out.printf("Element count %d, maximal element deep %d, average element deep %d.\n", handler.GetElementCount(), handler.GetMaxElementDeep(), handler.GetAvgElementDeep());

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

}

class MyContentHandler implements ContentHandler {

    Locator locator;

    // M�sto Stack element� by �lo pou�it jen int s aktualn� hloubkou.
    Stack<String> elementStack = new Stack<String>();
    
    int elementCount = 0;
    int maxElementDeep = 0;
    int sumElementDeeps = 0;
    int countElementDeeps = 0;
    boolean open = false;

    public int GetElementCount() {
        return elementCount;
    }

    public int GetMaxElementDeep() {
        return maxElementDeep;
    }

    public int GetAvgElementDeep() {
        return (sumElementDeeps / countElementDeeps);
    }

    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    public void startDocument() throws SAXException {

        // ...

    }
    public void endDocument() throws SAXException {

        // ...

    }

    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        // ...
        elementStack.add(qName);
        
        ++elementCount;
        open = true;
        if (elementStack.size() > maxElementDeep)
            maxElementDeep = elementStack.size();
    }
    public void endElement(String uri, String localName, String qName) throws SAXException {

        // ...
        if (!elementStack.peek().equals(qName))
            System.out.printf("ERROR: element name missmatch opened = %s, closing = %s.\n", elementStack.peek(), qName);

        if (open)
        {
            sumElementDeeps += elementStack.size();
            ++countElementDeeps;
        }

        elementStack.pop();
        open = false;
    }

    public void characters(char[] ch, int start, int length) throws SAXException {

        // ...

    }

    public void startPrefixMapping(String prefix, String uri) throws SAXException {

        // ...

    }

    public void endPrefixMapping(String prefix) throws SAXException {

        // ...

    }

    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {

        // ...

    }

    public void processingInstruction(String target, String data) throws SAXException {

      // ...

    }

    public void skippedEntity(String name) throws SAXException {

      // ...

    }
}
