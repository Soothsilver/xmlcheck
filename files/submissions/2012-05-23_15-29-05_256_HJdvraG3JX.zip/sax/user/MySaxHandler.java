/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.util.HashMap;
import java.util.Map;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {

    // Umoľ�?uje zacílit místo v dokumentu, kde vznikla aktualní událost
    Locator locator;
    int pocetElementu = 0;
    int pocetAttributu = 0;
    int maxDeep = 0;
    int deep = 0;
    int count = 0;
    int countE = 0;
    int maxCountA = 0;
    int maxCountE = 0;
    int underE = 0;
    int countU = 0;
    int lastE = 0;
    int countEnd = 0;
    boolean noted = false;
    String attrib = "";
    String element = "";
    Map<String, Integer> attributy;
    Map<String, Integer> elementy;
    int maxFanOut = 0;
    int fanOut = 0;
    Map<Integer, Integer> lastFanOut;

    /**
     * Nastaví locator
     */
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Obsluha události "začátek dokumentu"
     */
    public void startDocument() throws SAXException {
        attributy = new HashMap<String, Integer>();
        elementy = new HashMap<String, Integer>();
        lastFanOut = new HashMap<Integer, Integer>();
    }

    /**
     * Obsluha události "konec dokumentu"
     */
    public void endDocument() throws SAXException {
        System.out.println("Statistika: ");
        System.out.println("Pocet elementu: " + pocetElementu);
        System.out.println("Pocet attributu: " + pocetAttributu);




        for (String key : attributy.keySet()) {
            count = attributy.get(key);
            if (count > maxCountA) {
                attrib = key;
                maxCountA = count;
            }
        }

        for (String key : elementy.keySet()) {
            countE = elementy.get(key);
            if (countE > maxCountE) {
                element = key;
                maxCountE = countE;
            }
        }

        System.out.println("Pocet ruznych attributu: " + attributy.size());
        System.out.println("Pocet ruznych elementu: " + elementy.size());
        System.out.println("Pocet elementu s podelementy: " + countU);
        System.out.println("Nejcastejsi je attribut '" + attrib + "', ktery se v dokumentu vyskytuje " + maxCountA + "x");
        System.out.println("Nejcastejsi je element '" + element + "', ktery se v dokumentu vyskytuje " + maxCountE + "x");
        System.out.println("Maximalni hloubka dokumentu: " + maxDeep);
        System.out.println("Maximalni fan-out dokumentu: " + maxFanOut);
    }

    /**
     * Obsluha události "začátek elementu".
     * @param uri URI jmenného prostoru elementu (prázdné, pokud element není v ľádném jmenném prostoru)
     * @param localName Lokální jméno elementu (vľdy neprázdné)
     * @param qName Kvalifikované jméno (tj. prefix-uri + ':' + localName, pokud je element v nějakém jmenném prostoru, nebo localName, pokud element není v ľádném jmenném prostoru)
     * @param atts Atributy elementu     
     */
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        countEnd = 0;
        deep++;
        pocetElementu++;
        
        if(lastFanOut.containsKey(deep)){
        fanOut=lastFanOut.get(deep);
        }
        

        if (maxFanOut < fanOut) {
            maxFanOut = fanOut;
        }

        if (lastE != underE) {            
            
            lastFanOut.put(deep, fanOut);
            fanOut = 0;
            countU++;
        }
        fanOut++;
        lastFanOut.put(deep, fanOut);        

        lastE = underE;
        underE++;




        pocetAttributu += atts.getLength();
        Integer count = 0;
        String aName = "";
        if (elementy.containsKey(localName)) {
            countE = elementy.get(localName);
            elementy.put(localName, ++countE);

        } else {
            elementy.put(localName, 1);
        }
        for (int i = 0; i < atts.getLength(); i++) {
            aName = atts.getLocalName(i);
            count = attributy.get(atts.getLocalName(i));
            if (count == null) {
                count = 0;
            }
            count++;
            attributy.put(aName, count);
        }
    }

    /**
     * Obsluha události "konec elementu"
     * Parametry mají stejný význam jako u @see startElement     
     */
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (countEnd > 0) {            
            underE++;
           
        }
        countEnd++;

        underE--;

        if (deep > maxDeep) {
            maxDeep = deep;
        }
        deep--;
        
        if (maxFanOut < fanOut) {
            maxFanOut = fanOut;
        }
    }

    /**
     * Obsluha události "znaková data".
     * SAX parser muµe znaková data dávkovat jak chce. Nelze tedy počítat s tím, ľe je celý text dorucen v rámci jednoho volání.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakovými daty
     * @param start Index zacátku úseku platných znakových dat v poli.
     * @param length Délka úseku platných znakových dat v poli.
     */
    public void characters(char[] ch, int start, int length) throws SAXException {
        // ...
    }

    /**
     * Obsluha události "deklarace jmenného prostoru".
     * @param prefix Prefix prirazený jmennému prostoru.
     * @param uri URI jmenného prostoru.
     */
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    /**
     * Obsluha události "konec platnosti deklarace jmenného prostoru".
     */
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    /**
     * Obsluha události "ignorované bílé znaky".
     * Stejné chování a parametry jako @see characters     
     */
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        // ...
    }

    /**
     * Obsluha události "instrukce pro zpracování".
     */
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

    /**
     * Obsluha události "nezpracovaná entita"
     */
    public void skippedEntity(String name) throws SAXException {
        // ...
    }
}