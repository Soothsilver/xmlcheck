package user;

import org.xml.sax.helpers.DefaultHandler;
import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.Attributes;

/**
 * Náš vlastní content handler pro obsluhu SAX událostí.
 * Implementuje metody interface ContentHandler. 
 */ 
public class MySaxHandler extends DefaultHandler {

	// Umožnuje zacílit místo v dokumentu, kde vznikla aktualní událost
    Locator locator;
	Vector ages = new Vector(); 
	Hashtable ht = new Hashtable();
	Hashtable serialy = new Hashtable();
	Boolean vek = false;
	Boolean oblib_serial = false;
	Boolean hodnoceni = false;
	Boolean serial = false;
	Boolean nazev = false;
	Boolean hlavni_postavy = false;
	String jmeno_oblib_serialu;
	String nazev_serialu;

	//pro spočtení průměrů
	private Double CountAverage(Vector v) {
		Double average = 0d;
		
		for (int i = 0; i < v.size(); i++)
		{
			average += (Integer)v.get(i);
		}
		return average / v.size();
	}
    
    /**
     * Nastaví locator
     */     
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Obsluha události "začátek dokumentu"
     */     
    public void startDocument() throws SAXException {
        
        // ...
        
    }
    /**
     * Obsluha události "konec dokumentu"
     */     
    public void endDocument() throws SAXException {
        
        Double averageAge = this.CountAverage(ages);
		System.out.println("Prumerny vek divaku je " + averageAge + " let.");
		System.out.println();
		
		Enumeration fav_shows = ht.keys();
		while (fav_shows.hasMoreElements())
		{
			String name = (String)fav_shows.nextElement();
			Double averageRating = this.CountAverage((Vector)ht.get(name));
			System.out.println("Serial " + name + " ma prumerne hodnoceni " + averageRating + "/10");
		}
		System.out.println();
		
		Enumeration shows = serialy.keys();
		while (shows.hasMoreElements())
		{
			String name = (String)shows.nextElement();
			System.out.println("Serial " + name + " ma " + serialy.get(name) + " hlavnich hercu.");
		}
    }
    
    /**
     * Obsluha události "začátek elementu".
     * @param uri URI jmenného prostoru elementu (prázdné, pokud element není v žádném jmenném prostoru)
     * @param localName Lokální jméno elementu (vždy neprázdné)
     * @param qName Kvalifikované jméno (tj. prefix-uri + ':' + localName, pokud je element v nějakém jmenném prostoru, nebo localName, pokud element není v žádném jmenném prostoru)
     * @param atts Atributy elementu     
     */     	
	
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        if (localName.equals("vek")) {
			vek = true;
		} else if (localName.equals("oblib_serial")) {
			oblib_serial = true;
		} else if (localName.equals("hodnoceni")) {
			hodnoceni = true;
		} else if (localName.equals("serial")) {
			serial = true;
		} else if (localName.equals("nazev") && serial) {
			nazev = true;
		} else if (localName.equals("hlavni_postavy") && serial) {
			hlavni_postavy = true;
		} else if (localName.equals("postava") && hlavni_postavy) {
			Integer i = (Integer)serialy.get(nazev_serialu);
			serialy.put(nazev_serialu, i+1);
		}
		

    }
    /**
     * Obsluha události "konec elementu"
     * Parametry mají stejný význam jako u @see startElement     
     */     
    public void endElement(String uri, String localName, String qName) throws SAXException {

        if (localName.equals("vek")) {
			vek = false;
		} else if (localName.equals("oblib_serial")) {
			oblib_serial = false;
		} else if (localName.equals("hodnoceni")) {
			hodnoceni = false;
		} else if (localName.equals("serial")) {
			serial = false;
		} else if (localName.equals("nazev")) {
			nazev = false;
		} else if (localName.equals("hlavni_postavy")) {
			hlavni_postavy = false;
		}  
    }
    
    /**
     * Obsluha události "znaková data".
     * SAX parser muľe znaková data dávkovat jak chce. Nelze tedy počítat s tím, že je celý text dorucen v rámci jednoho volání.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakovými daty
     * @param start Index zacátku úseku platných znakových dat v poli.
     * @param length Délka úseku platných znakových dat v poli.
     */               
    public void characters(char[] ch, int start, int length) throws SAXException {
		
		String s = new String(ch, start, length).trim();
		
        if (vek) {
			ages.add(Integer.parseInt(s));
		} 
		
		if (oblib_serial && !s.isEmpty())
		{
			if (!hodnoceni)
			{
				jmeno_oblib_serialu = s;
				if (!ht.containsKey(jmeno_oblib_serialu)) {
					ht.put(jmeno_oblib_serialu, new Vector());
				}
			}
			else
			{
				Vector v = (Vector)ht.get(jmeno_oblib_serialu);
				v.add(Integer.parseInt(s.substring(0, s.indexOf("/"))));
			}
		}
		
		if (nazev)
		{
			nazev_serialu = s;
			serialy.put(nazev_serialu, new Integer(0));
		}
        
    }
    
    /**
     * Obsluha události "deklarace jmenného prostoru".
     * @param prefix Prefix prirazený jmennému prostoru.
     * @param uri URI jmenného prostoru.
     */     
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha události "konec platnosti deklarace jmenného prostoru".
     */     
    public void endPrefixMapping(String prefix) throws SAXException {
    
        // ...
    
    }

    /**
     * Obsluha události "ignorované bílé znaky".
     * Stejné chování a parametry jako @see characters     
     */     
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha události "instrukce pro zpracování".
     */         
    public void processingInstruction(String target, String data) throws SAXException {
      
      // ...
            
    }

    /**
     * Obsluha události "nezpracovaná entita"
     */         
    public void skippedEntity(String name) throws SAXException {
    
      // ...
    
    }
}