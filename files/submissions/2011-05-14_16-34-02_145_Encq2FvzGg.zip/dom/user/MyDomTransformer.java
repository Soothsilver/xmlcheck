package user;

import java.io.File;
import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

public class MyDomTransformer {

    private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "data.out.xml";
	
	private static Hashtable ht = new Hashtable();
	private static String s_id;

    /*public static void main(String[] args) {
        
        try {
            
            //DocumentBuilderFactory vytváří DOM parsery
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            //nebudeme validovat
            dbf.setValidating(false);

            //vytvoříme si DOM parser
            DocumentBuilder builder = dbf.newDocumentBuilder();

            //parser zpracuje vstupní soubor a vytvoří z něj strom DOM objektů
            Document doc = builder.parse(VSTUPNI_SOUBOR);

            //zpracujeme DOM strom
            transform(doc);

            //TransformerFactory vytváří serializátory DOM stromů
            TransformerFactory tf = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer = tf.newTransformer();

            //nastavíme kodování
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spustíme transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


        } catch (Exception e) {
            
            e.printStackTrace();
            
        }
    }*/

    /**
     * Zpracuje DOM strom
	 * 1) Veškeré atributy převede na elementy s textovým obsahem
	 * 2) Ke všem seriálům přidá elementy "hodnoceni" podle nějakých ohodnocení od uživatelů
     */
    public static void transform (Document doc) {
		DFS(doc, doc);
	
	}
	
	private static void DFS (Node n, Document doc) {
	
		//transforming atributes to elements + deleting attributes
		if (n.hasAttributes())
		{
			NamedNodeMap atts = n.getAttributes();
			
			while (atts.getLength() > 0)
			{
				Node attribute = atts.item(0);
				
				if (attribute.getNodeName().equals("ref_id")) {
					s_id = attribute.getTextContent();
					
					if (!ht.containsKey(s_id)) {
						ht.put(s_id, new Vector());
					}
				}
				
				Element e = doc.createElement(attribute.getNodeName());
				e.setTextContent(attribute.getNodeValue());
				n.appendChild(e);
				((Element)n).removeAttribute(attribute.getNodeName());
			}
		}		
		
		//Save "hodnoceni" to Hash table
		if (n.getNodeName().equals("hodnoceni") && !s_id.isEmpty()) 
		{
			Element e = doc.createElement("hodnoceni");
			e.setTextContent(n.getTextContent());			
			Vector v = (Vector)ht.get(s_id);
			v.add(e);
			s_id = "";
		}
		
		//for shows id in hash table write their rating
		if (n.getNodeName().equals("id"))
		{
			if (ht.containsKey(n.getTextContent()))
			{
				Vector v = (Vector)ht.get(n.getTextContent());
				for (int i = 0; i < v.size(); i++)
				{
					n.getParentNode().appendChild((Element)v.get(i));
				}
			}
		}
		
		//continue DFS
		Node siblings = n.getFirstChild();
		while (siblings != null) {
			DFS(siblings, doc);
			siblings = siblings.getNextSibling();
		}
	}
}
