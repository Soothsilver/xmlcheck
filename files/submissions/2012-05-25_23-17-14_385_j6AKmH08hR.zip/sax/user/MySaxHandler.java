/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;


import java.util.HashMap;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler; 


/* Pocitam: 
 * pro elementy i atributy jejich prumernou a maximalni delku,
 * a pocet vyskytu obecne plus kolik ruznych elementu a atributu v souboru je
 * A nejvetsi hloubku zanoreni
 */
public class MySaxHandler extends DefaultHandler 
{    
     // Umožňuje zacílit místo v dokumentu, kde vznikla aktualní událost
    Locator locator;
    
    /**
     * Nastaví locator
     */     
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    
    
    /**
     * Obsluha události "konec dokumentu"
     */     
    @Override
    public void endDocument() throws SAXException {
        System.out.println("<stats>");
        System.out.println("    <elementy>");
        System.out.println("        <delka>");
        int max = 0;
        int avg = 0;
        for (String key : elementinazvy.keySet()) {
            avg += key.length();
            if (key.length() > max) {
                max = key.length();
            }
        } 
        if (elementinazvy.size() > 0)
        {
        avg = avg / elementinazvy.size();
        }
        System.out.println("            <max>"+max+"</max>");
        System.out.println("            <avg>"+avg+"</avg>");
        System.out.println("        </delka>");
        System.out.println("        <pocet>");
        System.out.println("            <celkem>"+pocetElementu+"</celkem>");
        System.out.println("            <ruznych>"+elementinazvy.size()+"</ruznych>");
        System.out.println("        </pocet>");
        System.out.println("    </elementy>");
        System.out.println("    <atributy>");
        System.out.println("        <delka>");
        for (String key : atributinazvy.keySet()) {
            avg += key.length();
            if (key.length() > max) {
                max = key.length();
            }
        }       
        if (atributinazvy.size() > 0)
        {
        avg = avg / atributinazvy.size();
        }
        System.out.println("            <max>"+max+"</max>");
        System.out.println("            <avg>"+avg+"</avg>");
        System.out.println("        </delka>");
        System.out.println("        <pocet>");
        System.out.println("            <celkem>"+pocetAtributu+"</celkem>");
        System.out.println("            <ruznych>"+atributinazvy.size()+"</ruznych>");
        System.out.println("        </pocet>");        
        System.out.println("    </atributy>");
        System.out.println("    <maxhloubka>"+maxhloubka+"</maxhloubka>");
        System.out.println("</stats>");
    }
    
    int pocetElementu = 0;
    HashMap<String, Integer> elementinazvy = new HashMap<String, Integer>();
    int pocetAtributu = 0;
    HashMap<String, Integer> atributinazvy = new HashMap<String, Integer>();
    int hloubka;
    int maxhloubka;
    
    /**
     * Obsluha události "začátek elementu".
     * @param uri URI jmenného prostoru elementu (prázdné, pokud element není v žádném jmenném prostoru)
     * @param localName Lokální jméno elementu (vždy neprázdné)
     * @param qName Kvalifikované jméno (tj. prefix-uri + ':' + localName, pokud je element v nějakém jmenném prostoru, nebo localName, pokud element není v žádném jmenném prostoru)
     * @param atts Atributy elementu     
     */     
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        hloubka++;
        if (hloubka > maxhloubka) {
            maxhloubka = hloubka;
        }
        pocetElementu++;
        if (elementinazvy.containsKey(localName)) {
            int cislo = elementinazvy.get(localName) + 1;
            elementinazvy.put(localName, cislo);
        }     
        else
        {
        elementinazvy.put(localName, 1);
        }
        for (int i = 0; i < atts.getLength() ; i++) {
            pocetAtributu++;
            if (atributinazvy.containsKey(atts.getLocalName(i))) {
                int cislo = atributinazvy.get(atts.getLocalName(i)) + 1;
                atributinazvy.put(atts.getLocalName(i), cislo);
            }
            else
            {
                atributinazvy.put(localName, 1);
            }
        }              
    }
    /**
     * Obsluha události "konec elementu"
     * Parametry mají stejný význam jako u @see startElement     
     */     
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
       hloubka--;
    }        
    
      
}