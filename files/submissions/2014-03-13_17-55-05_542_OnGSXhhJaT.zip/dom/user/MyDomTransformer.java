package user;

import org.w3c.dom.*;

public class MyDomTransformer
{
	
	public void transform (Document xmlDocument)
	{
		//pridat book do books
		NodeList bo = xmlDocument.getElementsByTagName("books");
    	Node books = null;
    	
    	if (bo.getLength() == 0)
    	{
    		books = xmlDocument.createElement("books");
    		xmlDocument.getDocumentElement().appendChild(books);
    	}
    	else
    	{
    		books = bo.item(0);
    	}
    	
    	//kvuli id knihy, predpokladame, ze id je podle poctu knih
    	int num = xmlDocument.getElementsByTagName("book").getLength();
    	num++;
    	
    	Element newBook = xmlDocument.createElement("book");
    	newBook.setAttribute("id", ("b" + num));
    	newBook.setAttribute("damaged", "no");
    	
    	newBook.appendChild(xmlDocument.createElement("title")).setTextContent("Rozmarn� l�to");
    	newBook.appendChild(xmlDocument.createElement("author")).setTextContent("Van�ura");
    	newBook.appendChild(xmlDocument.createElement("pages")).setTextContent("100");
    	newBook.appendChild(xmlDocument.createElement("available"));
    	
    	books.appendChild(newBook);
    	
    	
    	//odstranit knizky s atributtem damaged = "heavily"
    	NodeList book = xmlDocument.getElementsByTagName("book");
    	
    	if (book.getLength() != 0)
    	{
    		for (int i = book.getLength() - 1; i >= 0; --i)
    		{
    			NamedNodeMap attributes = book.item(i).getAttributes();
    			
    			//atributy nemusi byt v poradi jakem bych cekal, tak je radsi projdu vsechny
    			//damaged muze take uplne chybet
    			for (int a = 0; a < attributes.getLength(); a++)
    			{
    				if (attributes.item(a).getNodeName().equals("damaged") && attributes.item(a).getNodeValue().equals("heavily"))
    				{
    					book.item(i).getParentNode().removeChild(book.item(i));
    					break;
    				}
    			}
    		}
    	}
	}
}
