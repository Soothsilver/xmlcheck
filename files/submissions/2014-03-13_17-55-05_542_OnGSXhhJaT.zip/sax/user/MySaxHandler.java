package user;

import java.io.IOException;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

/////////////////
// zadani:
// 1. prumerny pocet stranek knihy z elementu <pages>nnn</pages>
// 2. nejcastejsi stav knizek z atributu damaged="no" / "slightly" / "heavily"
// 3. pocet studentu, kteri jsou zabanovani a maji vypujcenou alespon jednu knizku
/////////////////

public class MySaxHandler extends DefaultHandler{
	
	int total_pages;
	int books;
	boolean in_pages;
	
	int no;
	int slightly;
	int heavily;
	
	boolean in_banned_student;
	int nr_banned_student;

	@Override
	public void characters(char[] ch, int start, int length)
			throws SAXException {
		
		if (in_pages)
		{
			total_pages += Integer.parseInt(new String(ch, start, length));
			in_pages = false;
		}
		
		super.characters(ch, start, length);
	}

	@Override
	public void endDocument() throws SAXException {
		
		if (books != 0)
		{
			System.out.println("Prumerny pocet stranek: " + total_pages/books);
		}
		else
		{
			System.out.println("Prumerny pocet stranek: " + 0);
		}
		
		
		int max = Math.max(Math.max(no, slightly), heavily);
		
		System.out.print("Nejcastejsi stav knizek: ");
		
		if (max == no)
			System.out.print("no - " + no + " ");
		if (max == slightly)
			System.out.print("slightly - " + slightly + " ");
		if (max == heavily)
			System.out.print("heavily - " + heavily + " ");
		System.out.println();
		
		
		System.out.println("Pocet zabanovanych studentu s vypujcenou knihou: " + nr_banned_student);
		
		super.endDocument();
	}

	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		
		if (qName.equals("student"))
		{
			in_banned_student = false;
		}
		
		
		super.endElement(uri, localName, qName);
	}

	@Override
	public void endPrefixMapping(String prefix) throws SAXException {
		// TODO Auto-generated method stub
		super.endPrefixMapping(prefix);
	}

	@Override
	public void error(SAXParseException e) throws SAXException {
		// TODO Auto-generated method stub
		super.error(e);
	}

	@Override
	public void fatalError(SAXParseException e) throws SAXException {
		// TODO Auto-generated method stub
		super.fatalError(e);
	}

	@Override
	public void ignorableWhitespace(char[] ch, int start, int length)
			throws SAXException {
		// TODO Auto-generated method stub
		super.ignorableWhitespace(ch, start, length);
	}

	@Override
	public void notationDecl(String name, String publicId, String systemId)
			throws SAXException {
		// TODO Auto-generated method stub
		super.notationDecl(name, publicId, systemId);
	}

	@Override
	public void processingInstruction(String target, String data)
			throws SAXException {
		// TODO Auto-generated method stub
		super.processingInstruction(target, data);
	}

	@Override
	public InputSource resolveEntity(String publicId, String systemId)
			throws IOException, SAXException {
		// TODO Auto-generated method stub
		return super.resolveEntity(publicId, systemId);
	}

	@Override
	public void setDocumentLocator(Locator locator) {
		// TODO Auto-generated method stub
		super.setDocumentLocator(locator);
	}

	@Override
	public void skippedEntity(String name) throws SAXException {
		// TODO Auto-generated method stub
		super.skippedEntity(name);
	}

	@Override
	public void startDocument() throws SAXException {

		total_pages = 0;
		books = 0;	
		in_pages = false;
		
		no = 0;
		slightly = 0;
		heavily = 0;
		
		in_banned_student = false;
		nr_banned_student = 0;
		
		super.startDocument();
	}

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {
		
		if (qName.equals("pages"))
		{
			in_pages = true;
			books++;
		}
		
		
		for (int i = 0; i < attributes.getLength(); i++)
		{
			if (attributes.getQName(i).equals("damaged"))
			{
				if (attributes.getValue(i).equals("no"))
					no++;
				if (attributes.getValue(i).equals("heavily"))
					heavily++;
				if (attributes.getValue(i).equals("slightly"))
					slightly++;
			}
		}
		
		
		if (qName.equals("student"))
		{
			for (int i = 0; i < attributes.getLength(); i++)
			{
				if (attributes.getQName(i).equals("banned") && attributes.getValue(i).equals("yes"))
				{
					in_banned_student = true;
				}
			}
		}
		
		if (qName.equals("borrow") && in_banned_student)
		{
			nr_banned_student++;
		}

		super.startElement(uri, localName, qName, attributes);
	}

	@Override
	public void startPrefixMapping(String prefix, String uri)
			throws SAXException {
		// TODO Auto-generated method stub
		super.startPrefixMapping(prefix, uri);
	}

	@Override
	public void unparsedEntityDecl(String name, String publicId,
			String systemId, String notationName) throws SAXException {
		// TODO Auto-generated method stub
		super.unparsedEntityDecl(name, publicId, systemId, notationName);
	}

	@Override
	public void warning(SAXParseException e) throws SAXException {
		// TODO Auto-generated method stub
		super.warning(e);
	}

}
