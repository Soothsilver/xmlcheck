package user;

import java.util.Calendar;
import java.util.Date;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * ASSIGNMENT: Update document to be able to transform input XML document to
 * output document by actions mentioned in comments of processTree method.
 */
public class MyDomTransformer {  
   
    public static void transform(Document doc) {
        deleteRecords(doc);
        addRecord(doc, "r5", "s0", "8.8.8.8", "STEAM_0:1:12345678", "DeiForm", "0", new Date(2013, 7, 15, 18, 48, 0), "Cheating", "S1mon");
    }
	
    private static void deleteRecords(Document doc){
        NodeList records = doc.getElementsByTagName("record");
        for (int i = 0; i < records.getLength(); i++) {
            Node record = records.item(i);
            Node releasedateNode = ((Element)record).getElementsByTagName("release_date").item(0);

            NodeList dates = releasedateNode.getChildNodes();
            String year = "",
                    month = "",
                    day = "",
                    hour = "",
                    minute = "",
                    second = "";
            for (int j = 0; j < dates.getLength(); j++) {
                Node node = dates.item(j);
                if(node.getNodeName().equals("year"))
                    year = node.getFirstChild().getNodeValue();
                else if(node.getNodeName().equals("month"))
                    month = node.getFirstChild().getNodeValue();
                else if(node.getNodeName().equals("day"))
                    day = node.getFirstChild().getNodeValue();
                else if(node.getNodeName().equals("hour"))
                    hour = node.getFirstChild().getNodeValue();
                else if(node.getNodeName().equals("minute"))
                    minute = node.getFirstChild().getNodeValue();
                else if(node.getNodeName().equals("second"))
                    second = node.getFirstChild().getNodeValue();
            }

            Date DateRelease = new Date(Integer.parseInt(year),
                    Integer.parseInt(month),
                    Integer.parseInt(day),
                    Integer.parseInt(hour),
                    Integer.parseInt(minute),
                    Integer.parseInt(second));
            Date DateNow = new Date();

            if(DateRelease.after(DateNow))
            {
                Node parent = record.getParentNode();
                parent.removeChild(record);
                i--;
            }
        }
    }
    
    private static void addRecord(Document doc, String id, String server_id, String ip, String sid, String nickname, String total_bans, Date release, String reason, String admin)
    {
        Element eip = doc.createElement("ip");
        eip.appendChild(doc.createTextNode(ip));
        
        Element esid = doc.createElement("sid");
        esid.appendChild(doc.createTextNode(sid));
        
        Element enickname = doc.createElement("nickname");
        enickname.appendChild(doc.createTextNode(nickname));
        
        Element etotal_bans = doc.createElement("total_bans");
        etotal_bans.appendChild(doc.createTextNode(total_bans));
        
        Element player = doc.createElement("player");
        player.appendChild(eip);
        player.appendChild(esid);
        player.appendChild(enickname);
        player.appendChild(etotal_bans);
        
        Calendar cal = Calendar.getInstance();
        
        Element day = doc.createElement("day");
        day.appendChild(doc.createTextNode(((Integer)cal.get(Calendar.DAY_OF_MONTH)).toString()));
        
        Element month = doc.createElement("month");
        month.appendChild(doc.createTextNode(((Integer)cal.get(Calendar.MONTH)).toString()));
        
        Element year = doc.createElement("year");
        year.appendChild(doc.createTextNode(((Integer)cal.get(Calendar.YEAR)).toString()));
        
        Element hour = doc.createElement("hour");
        hour.appendChild(doc.createTextNode(((Integer)cal.get(Calendar.HOUR_OF_DAY)).toString()));
        
        Element minute = doc.createElement("minute");
        minute.appendChild(doc.createTextNode(((Integer)cal.get(Calendar.MINUTE)).toString()));
        
        Element second = doc.createElement("second");
        second.appendChild(doc.createTextNode(((Integer)cal.get(Calendar.SECOND)).toString()));
        
        Element ban_date = doc.createElement("ban_date");
        ban_date.appendChild(day);
        ban_date.appendChild(month);
        ban_date.appendChild(year);
        ban_date.appendChild(hour);
        ban_date.appendChild(minute);
        ban_date.appendChild(second);
        
        cal.setTime(release);
        
        Element rday = doc.createElement("day");
        day.appendChild(doc.createTextNode(((Integer)cal.get(Calendar.DAY_OF_MONTH)).toString()));
        
        Element rmonth = doc.createElement("month");
        month.appendChild(doc.createTextNode(((Integer)cal.get(Calendar.MONTH)).toString()));
        
        Element ryear = doc.createElement("year");
        year.appendChild(doc.createTextNode(((Integer)cal.get(Calendar.YEAR)).toString()));
        
        Element rhour = doc.createElement("hour");
        hour.appendChild(doc.createTextNode(((Integer)cal.get(Calendar.HOUR_OF_DAY)).toString()));
        
        Element rminute = doc.createElement("minute");
        minute.appendChild(doc.createTextNode(((Integer)cal.get(Calendar.MINUTE)).toString()));
        
        Element rsecond = doc.createElement("second");
        second.appendChild(doc.createTextNode(((Integer)cal.get(Calendar.SECOND)).toString()));
        
        Element release_date = doc.createElement("release_date");
        release_date.appendChild(rday);
        release_date.appendChild(rmonth);
        release_date.appendChild(ryear);
        release_date.appendChild(rhour);
        release_date.appendChild(rminute);
        release_date.appendChild(rsecond);
        
        Element ereason = doc.createElement("reason");
        ereason.appendChild(doc.createTextNode(reason));
        
        Element eadmin = doc.createElement("admin_nickname");
        eadmin.appendChild(doc.createTextNode(admin));
        
        Element type = doc.createElement("type");
        
        Attr idattr = doc.createAttribute("id");
        idattr.setValue(id);
        
        Attr serveridattr = doc.createAttribute("server_id");
        serveridattr.setValue(server_id);
        
        Element record = doc.createElement("record");
        record.setAttributeNode(idattr);
        record.setAttributeNode(serveridattr);
        record.appendChild(player);
        record.appendChild(ban_date);
        record.appendChild(release_date);
        record.appendChild(ereason);
        record.appendChild(eadmin);
        record.appendChild(type);
        
        Node parent = doc.getElementsByTagName("banlist").item(0);
        parent.appendChild(record);
    }
    }
