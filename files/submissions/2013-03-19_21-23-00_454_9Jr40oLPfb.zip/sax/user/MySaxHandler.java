package user;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;


public class MySaxHandler extends DefaultHandler {
    
    private static final String INPUT_FILE = "data.xml";
    private HashMap<String, Integer> swmb; //server with most bans
    private HashMap<String, String> serverNames;
    private HashMap<String, Integer> serverActuals;
    private boolean actual, maximal;
    private int sum_actual, sum_maximal, count;
    private String server_hw_name;
    private String server_id;
    
    // Helper variable to store location of the handled event
    Locator locator;

    /**
     * Sets the locator
     *
     * @param Locator locator location in the file
     */
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Method to handle "document start"
     *
     * @throws SAXException
     */
    @Override
    public void startDocument() throws SAXException {
		swmb = new HashMap<String, Integer>(); 
		serverNames = new HashMap<String, String>();
		serverActuals = new HashMap<String, Integer>();
		actual = false;
		maximal = false;
		sum_actual = 0;
		sum_maximal = 0;
		count = 0;
		server_hw_name = "";
		server_id = "";
	}

    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
        
        //Getting maximal value from swmb and its servername
        Object[] server_ids = swmb.keySet().toArray();
        int max = 0;
        String name = new String();
        for (int i = 0; i < server_ids.length ; i++)
            if(max < swmb.get((String)server_ids[i]))
            {
                max = swmb.get((String)server_ids[i]);
                name = (String)server_ids[i];
            }
        System.out.println("Server with most bans is " + serverNames.get(name));
        
        //Getting summs of players and average
        System.out.println("Summary player stats for " + count + " servers: " +
                sum_actual + "/" + sum_maximal + " average: " +
                (sum_actual/count) + "/" + (sum_maximal / count));
        
        //Getting 3 top played servers on hw "Anicka" right know.
        Map.Entry<String, Integer>[] array = serverActuals.entrySet().toArray(new Map.Entry[serverActuals.size()]);
        Arrays.sort(array, new Comparator<Map.Entry<String, Integer>>() 
        {
            public int compare(Map.Entry<String, Integer> e1, Map.Entry<String, Integer> e2) 
            {
                return -e1.getValue().compareTo(e2.getValue());
            }
        });
        
        System.out.println("3 top played servers on hw 'Anicka' are: ");
        System.out.println(serverNames.get(array[0].getKey()));
        System.out.println(serverNames.get(array[1].getKey()));
        System.out.println(serverNames.get(array[2].getKey()));
    }

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        //Getting map of server names with keys as id of server
        //Setting actual server id and hw_name 
        if(localName.equals("server"))
        {
            serverNames.put(atts.getValue("id"), atts.getValue("name"));
            server_id = atts.getValue("id");
            server_hw_name = atts.getValue("server_hw");
        }
        //Counting acumulators for bans on each server
        else if(localName.equals("record"))
        {
            String id = atts.getValue("server_id");
            if(swmb.containsKey(id))
                swmb.put(id, swmb.get(id) + 1);
            else
                swmb.put(id, 1);
        }
        //Setting indicators for actual and maximal players
        else if(localName.equals("actual"))
        {
            actual = true;
        }
        else if(localName.equals("maximal"))
            maximal = true;
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        //UnSetting actual server id and hw_name 
        if(localName.equals("server"))
        {
            server_id = "";
            server_hw_name = "";
        }
        //UnSetting indicators for actual and maximal players
        else if(localName.equals("actual"))
            actual = false;
        else if(localName.equals("maximal"))
            maximal = false;
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        //Counting summs of actual players
        //Putting numbers of actual players in HashMap with server id that runs on server "Anicka"
        if(actual)
        {
            String tmp = new String(chars, start, length);
            if(!tmp.isEmpty())
            {
                sum_actual += Integer.parseInt(tmp);
                count++;
                if(!server_hw_name.isEmpty() && server_hw_name.equals("Anicka"))
                    serverActuals.put(server_id, Integer.parseInt(tmp));
            }
        }
        //Counting summs of maximal players
        else if(maximal)
        {
            String tmp = new String(chars, start, length);
            if(!tmp.isEmpty())
            {
                sum_maximal += Integer.parseInt(tmp);
            }
        }
        
    }

    /**
     * Method to handle " start of namespace declaration"
     *
     * @param prefix Prefix of the namespace
     * @param uri URI of the namespace
     * @throws SAXException
     */
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    /**
     * Method to handle "end of namespace declaration"
     *
     * @param prefix
     * @throws SAXException
     */
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    /**
     * Method to handle "ignoring of whitespaces" Text is in array 'chars' from
     * position ('start') to ('start' + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     * @throws SAXException
     */
    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
        // ...
    }

    /**
     * Method to handle "processing instructions"
     *
     * @param target The processing instruction target
     * @param data  The processing instruction data
     * @throws SAXException
     */
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

    /**
     * Method to handle "unprocessed entity"
     *
     * @param name
     * @throws SAXException
     */
    @Override
    public void skippedEntity(String name) throws SAXException {
        // ...
    }
}