/*
* Torzo pro DOM
*/

import cz.XmlTester.TestJava;

public class TestDom extends TestJava {
	
	/**
	* main funkce
	*/
	public void run() {
		
		final String filename = "../data.xml";
		final String outFilename = "../data.out.xml";
		
		// tady zavolat vse, co je potreba pro demonstraci funkcnosti
		
	}
	
}

