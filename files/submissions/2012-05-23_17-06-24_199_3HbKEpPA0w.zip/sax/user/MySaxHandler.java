package user;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 * Trida vypisuje statistiky o dokumentu s databazi her.
 * Pocita celkovy pocet her, minimalni a maximalni a prumernou
 * delku nazvu hry. Take vypise maximalne tri nejcastejsi 
 * herni platformy a zanry serazeny sestupne ve forme jejich nazvu
 * a poctu vyskytu u her.
 *
 * @author Jirka Uher uherjir2<at>fel.cvut.cz
 */
public class MySaxHandler extends DefaultHandler {

    // Pocet her v db
    int gameCount;
    // Minimalni delka nazvu hry
    int minGameLength;
    // Maximalni delka nazvu hry
    int maxGameLength;
    // Celkova delka nazvu her
    int totalGameNameLength;
    // Mapa nazvu platforem s poctem vyskytu
    Map<String, Integer> platforms;
    // Mapa nazvu zanru her s poctem vyskytu
    Map<String, Integer> genres;

    /**
     * Vlastni trida comparator, umoznuje setridit sestupne mapu podle
     * value a ne podle klice.
     */
    private class MyMapComparator implements Comparator {

        public int compare(Object o1, Object o2) {
            Map.Entry e1 = (Map.Entry) o1;
            Map.Entry e2 = (Map.Entry) o2;
            Integer first = (Integer) e1.getValue();
            Integer second = (Integer) e2.getValue();
            return -first.compareTo(second);
        }
    }

    /**
     * Pri zacatku parsovani dokumentu nastavim statistiky na pozadovane hodnoty
     * a inicializuji mapy.
     */
    public void startDocument() throws SAXException {
        gameCount = 0;
        totalGameNameLength = 0;
        minGameLength = Integer.MAX_VALUE;
        maxGameLength = Integer.MIN_VALUE;
        platforms = new HashMap<String, Integer>();
        genres = new HashMap<String, Integer>();
    }

    /**
     * Vypocet statistik a jejich vypis pri ukonceni parsovani dokumentu.
     */
    public void endDocument() throws SAXException {
        // prumerna delka nazvu hry
        float avgLength = 0;

        if (gameCount > 0) {
            avgLength = 1.0f * totalGameNameLength / gameCount;
        }

        // vypocet tri nejcastejsich platforem a priprava vypisu
        String platformsStat = "";
        if (platforms.size() > 0) {
            // prevod entry set na list
            ArrayList<Entry> list = new ArrayList(platforms.entrySet());
            // serazeni listu pomoci meho comparatoru
            Collections.sort(list, new MyMapComparator());

            // tvorba stringu z maximalne tri nejcasteji pouzitych platforem
            for (int i = 0; i < list.size() && i < 3; i++) {
                platformsStat += "\n   " + list.get(i).getKey() + " - " + list.get(i).getValue() + "x";
            }
        }
        // vypocet tri nejcastejsich zanru a priprava vypisu
        String genresStat = "";
        if (genres.size() > 0) {
            // prevod entry set na list
            ArrayList<Entry> list = new ArrayList(genres.entrySet());
            // serazeni listu pomoci meho comparatoru
            Collections.sort(list, new MyMapComparator());
            // tvorba stringu z maximalne tri nejcasteji pouzitych zanru
            for (int i = 0; i < list.size() && i < 3; i++) {
                genresStat += "\n   " + list.get(i).getKey() + " - " + list.get(i).getValue() + "x";
            }
        }


        // vypis statistik
        System.out.println("Statistiky:");
        System.out.println("Pocet her: " + gameCount);
        System.out.println("Minimalni delka nazvu hry: " + minGameLength);
        System.out.println("Maximalni delka nazvu hry: " + maxGameLength);
        System.out.println("Prumerna delka nazvu hry: " + avgLength);
        System.out.println("Nejcastejsi herni platformy: " + platformsStat);
        System.out.println("Nejcastejsi herni zanry: " + genresStat);
    }

    /**
     * Vlastni sber statistik pri navstiveni elementu.
     */
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        // pokud jsem navstivil element game, inkrementuji pocitadlo her
        // a z atributu name ziskam jeho hodnotu
        // jeji delku pouziji pro vypocet minimalni, maximalni a celkove
        // delky nazvu her
        if (localName.equals("game")) {
            gameCount++;
            String name = atts.getValue("name");
            if (name != null) {
                int len = name.trim().length();
                if (len > maxGameLength) {
                    maxGameLength = len;
                }
                if (len < minGameLength) {
                    minGameLength = len;
                }
                totalGameNameLength += len;
            }

        } else if (localName.equals("platform")) {
            // pokud jsem navstivil element platform, z atributu name ziskam
            // hodnotu nazvu platformy a inkrementuji pocitadlo v mape platforms
            String name = atts.getValue("name");
            if (name != null) {
                Integer count = platforms.get(name);
                if (count == null) {
                    count = 0;
                }
                platforms.put(name, ++count);
            }
        } else if (localName.equals("genre")) {
            // pokud jsem navstivil element genre, z atributu name ziskam
            // hodnotu nazvu zanru a inkrementuji pocitadlo v mape genres
            String name = atts.getValue("name");
            if (name != null) {
                Integer count = genres.get(name);
                if (count == null) {
                    count = 0;
                }
                genres.put(name, ++count);
            }
        }
    }
    /*
    public static void main(String[] args) {

    // Cesta ke zdrojovému XML dokumentu
    String sourcePath = "data.xml";

    try {

    // Vytvoríme instanci parseru.
    XMLReader parser = XMLReaderFactory.createXMLReader();

    // Vytvoríme vstupní proud XML dat.
    InputSource source = new InputSource(sourcePath);

    // Nastavíme náą vlastní content handler pro obsluhu SAX událostí.
    parser.setContentHandler(new MySaxHandler());

    // Zpracujeme vstupní proud XML dat.
    parser.parse(source);

    } catch (Exception e) {

    e.printStackTrace();

    }

    }
     */
}
