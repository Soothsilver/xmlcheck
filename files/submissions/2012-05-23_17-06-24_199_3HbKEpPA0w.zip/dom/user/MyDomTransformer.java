package user;

import java.io.File;
import java.util.Arrays;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Trida upravi dokument s databazi her. 
 * U kazde hry zameni elementy, ktery obsahuji reference na skupinu vyvojaru a
 * vydavatelu, za novy element, ktery bude obsahovat textovy seznam jmen techto
 * vyvojaru a vydavatelu. Nakonec smaze jiz nepotrebny seznam vyvojaru a vydavatelu.
 *
 * @author Jirka Uher uherjir2<at>fel.cvut.cz
 */
public class MyDomTransformer {

    public void transform(Document doc) {

        // seznam hernich vyvojaru
        NodeList developers = doc.getElementsByTagName("developer");
        // seznam hernich vydavatelu
        NodeList publishers = doc.getElementsByTagName("publisher");

        // skoncim pokud nemam kym nahrazovat
        if (publishers == null || developers == null ||
                developers.getLength() == 0 || publishers.getLength() == 0) {
            return;
        }

        // retezec pro ulozeni jmena vyvojare/vydavatele
        String name = null;
        // seznam id referenci na vyvojare/vydavatele
        String ids = null;
        // vystupni retezec do elementu
        String output = null;
        // docasne pole rozdelenych id referenci
        String[] parts = null;
        // odkaz na uzel
        Node node = null;
        // odkaz na seznam atributu
        NamedNodeMap attrs = null;

        // nahrazuji elementy developed-by s referencemi v atributu dev_refs
        // za novy element developer-list s carkou oddelenymi jmeny vyvojaru
        NodeList developedBy = doc.getElementsByTagName("developed-by");
        if (developedBy != null) {

            for (int i = 0; i < developedBy.getLength(); i++) {
                output = "";
                node = developedBy.item(i);
                attrs = node.getAttributes();
                // pokud nejsou zadne atributy, dalsi iterace
                if (attrs == null) {
                    continue;
                }
                node = attrs.getNamedItem("dev_refs");
                // pokud neexistuje atribut dev_refs, dalsi iterace
                if (node == null) {
                    continue;
                }
                // rozdelim mezerou oddelene id reference na pole
                ids = node.getNodeValue().trim();
                parts = ids.split(" ");
                //System.out.println(Arrays.toString(parts));
                for (int j = 0; j < parts.length; j++) {
                    // nadu jmeno vyvojare na zaklade id
                    name = getDeveloperNameById(developers, parts[j]);
                    output += name;
                    if (j < parts.length - 1) {
                        output += ", ";
                    }
                }
                // misto elementu developed-by vytvorim novy element developer-list
                // co obsahuje rovnou jmena vyvojaru
                node = developedBy.item(i);
                node.getParentNode().appendChild(createElement("developer-list", output, doc));
                //System.out.println(output);
                //node.getParentNode().removeChild(node);

            }
        }



        // nahrazuji elementy published-by s referencemi v atributu pub_refs
        // za novy element publisher-list s carkou oddelenymi jmeny vydavatelu
        NodeList publishedBy = doc.getElementsByTagName("published-by");
        if (publishedBy != null) {

            for (int i = 0; i < publishedBy.getLength(); i++) {
                output = "";
                node = publishedBy.item(i);
                attrs = node.getAttributes();
                // pokud nejsou zadne atributy, dalsi iterace
                if (attrs == null) {
                    continue;
                }
                node = attrs.getNamedItem("pub_refs");
                // pokud neexistuje atribut pub_refs, dalsi iterace
                if (node == null) {
                    continue;
                }
                // rozdelim mezerou oddelene id reference na pole
                ids = node.getNodeValue().trim();
                parts = ids.split(" ");
                //System.out.println(Arrays.toString(parts));
                for (int j = 0; j < parts.length; j++) {
                    // nadu jmeno vydavatele na zaklade id
                    name = getPublisherNameById(publishers, parts[j]);
                    output += name;
                    if (j < parts.length - 1) {
                        output += ", ";
                    }
                }
                // misto elementu published-by vytvorim novy element publisher-list
                // co obsahuje rovnou jmena vydavatelu
                node = publishedBy.item(i);
                node.getParentNode().appendChild(createElement("publisher-list", output, doc));
                //node.getParentNode().removeChild(node);
                //System.out.println(output);

            }
        }

        // nakonec smazu vsechny vydavatele a vyvojare, uz nejsou potreba
        developers = doc.getElementsByTagName("developers");
        if (developers != null) {
            developers.item(0).getParentNode().removeChild(developers.item(0));
        }

        publishers = doc.getElementsByTagName("publishers");
        if (publishers != null) {
            publishers.item(0).getParentNode().removeChild(publishers.item(0));
        }

        publishedBy = doc.getElementsByTagName("published-by");
        if (publishedBy != null) {
            for (int i = 0; i < publishedBy.getLength(); i++) {
                node = publishedBy.item(i);
                node.getParentNode().removeChild(node);
            }
        }

        developedBy = doc.getElementsByTagName("developed-by");
        if (developedBy != null) {
            for (int i = 0; i < developedBy.getLength(); i++) {
                node = developedBy.item(i);
                node.getParentNode().removeChild(node);
            }
        }


    }

    /**
     * Metoda vytvori element s nazvem name a obsahjici textovy element
     * s hodnotou text.
     */
    private Node createElement(String name, String text, Document doc) {
        Element elem = null;

        elem = doc.createElement(name);
        elem.appendChild(doc.createTextNode(text));

        System.out.println("Creating element <" + name + ">" + text + "</" + name + ">");
        return elem;
    }

    /**
     * Metoda vraci jmeno vydavatele podle jeho id.
     */
    private String getPublisherNameById(NodeList publishers, String id) {
        Node node = null;
        String name = null;
        NamedNodeMap attrs = null;

        for (int i = 0; i < publishers.getLength(); i++) {
            node = publishers.item(i);
            attrs = node.getAttributes();
            if (attrs == null) {
                continue;
            }
            node = attrs.getNamedItem("pub_id");
            if (node == null) {
                continue;
            }
            if (node.getNodeValue().equals(id)) {
                node = attrs.getNamedItem("name");
                if (node != null) {
                    return node.getNodeValue();
                }
            }
        }

        return name;
    }

    /**
     * Metoda vraci jmeno vyvojare podle jeho id.
     */
    private String getDeveloperNameById(NodeList developers, String id) {
        Node node = null;
        String name = null;
        NamedNodeMap attrs = null;

        for (int i = 0; i < developers.getLength(); i++) {
            node = developers.item(i);
            attrs = node.getAttributes();
            if (attrs == null) {
                continue;
            }
            node = attrs.getNamedItem("dev_id");
            if (node == null) {
                continue;
            }
            if (node.getNodeValue().equals(id)) {
                node = attrs.getNamedItem("name");
                if (node != null) {
                    return node.getNodeValue();
                }
            }
        }

        return name;
    }

    /*
    public static void main(String[] args) {

    try {

    //DocumentBuilderFactory vytváří DOM parsery
    DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

    //nebudeme validovat
    dbf.setValidating(false);

    //vytvoříme si DOM parser
    DocumentBuilder builder = dbf.newDocumentBuilder();

    //parser zpracuje vstupní soubor a vytvoří z něj strom DOM objektů
    Document doc = builder.parse("data.xml");

    //zpracujeme DOM strom
    new MyDomTransformer().transform(doc);

    //TransformerFactory vytváří serializátory DOM stromů
    TransformerFactory tf = TransformerFactory.newInstance();

    //Transformer serializuje DOM stromy
    Transformer writer = tf.newTransformer();

    //nastavíme kodování
    writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");


    //spustíme transformaci DOM stromu do XML dokumentu
    writer.transform(new DOMSource(doc), new StreamResult(new File("data.out.xml")));


    } catch (Exception e) {

    e.printStackTrace();

    }
    }
     */
} 
