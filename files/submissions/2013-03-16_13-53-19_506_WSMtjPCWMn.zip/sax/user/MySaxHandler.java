/*Ukol SAX polozka elements (prochazi elementy)
 *				vypocita prumernou cenu knihy 
 *		   atributes (prochazi atributy)
 *		   		zkontroluje jestli ma uzivatel alespon jednu adresu v CR a pokud ne, tak na nej upozorni
 *		   context (?asi kontextovy dotaz?)
 *		   		vypise dvojici kniha - uzivatel, splnujici: kniha je starsi 20 let a je momentalne vypujcena uzivatel
 */

package user;

import java.util.*;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

public class MySaxHandler extends DefaultHandler {

    // Helper variable to store location of the handled event
    Locator locator;
    /* Elements */
    int sum_price,
        book_count,
        cur_price;
    boolean in_book,
            in_price;
    /* /Elements */
    /* Atributes*/
    int adress_num,
    	cur_u_locator;
    boolean in_user,
    	    has_czech_adr;
    String err_string;
    /* /Atributes */
    /* Context */
    List<String> c_u_id,
                 c_u_name,
    	         c_b_id,
                 c_b_name;
    boolean c_in_book_name, c_in_book, c_old,
   	    c_in_user,c_in_user_name, c_in_year;
    String c_id, c_name, loan_table;
    /* /Context */

    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    @Override
    public void startDocument() throws SAXException {
	/* Elements */
	book_count=0;
	sum_price=0;
	in_book=false;
	in_price=false;
	/* /Elements */
	/* Atributes*/
 	adress_num=0;
	cur_u_locator=0;
	in_user=false;
	has_czech_adr=false;
	err_string="";
	/* /Atributes */
    	/* Context */
        c_u_id = new ArrayList<String>();
        c_u_name = new ArrayList<String>();
        c_b_id = new ArrayList<String>();
        c_b_name = new ArrayList<String>();
	c_in_book_name = false;
 	c_in_book = false;
   	c_in_user = false;
	c_in_user_name = false;
	c_in_year = false;
	c_old = false;
    	c_id = "";
	c_name = "";
	loan_table = "";
	/* /Context */
    }

    @Override
    public void endDocument() throws SAXException {
	/* Elements */
	System.out.println("----Elements----\nAverage price per book in our library is: " + sum_price/book_count);
	/* /Elements */
	/* Atributes*/
 	System.out.println("----Attributes----\nPlease check adresses of those users(at least 1 has to in be CR): " + err_string);
	/* /Atributes */
	/* Context */
	System.out.println("----Context----\nLent books older 20 years:" + loan_table);
	/* /Context */
    }
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
	/* Elements */
	/* zjistuji jestli jsem v cene za knihu */
	if (in_book && localName.equals("price")){
		in_price=true;
	}
	if (localName.equals("book")){
		in_book=true;
	}
	/* /Elements */
	/* Atributes*/
 	if (localName.equals("user")){
		in_user=true;
		cur_u_locator=locator.getLineNumber();
	}
	if (in_user && !has_czech_adr && localName.equals("adress")){
		if (atts.getValue("state") != null && atts.getValue("state").equals("CR")){
			has_czech_adr = true;
		}	
	}
	/* /Atributes */
    	/* Context */
 	if (localName.equals("user")){
		c_in_user = true;
		c_id = atts.getValue("u_id");
	}
	if (c_in_user && localName.equals("name")){
		c_in_user_name = true;
	}
	if (localName.equals("book")){
		c_in_book = true;
		c_id = atts.getValue("b_id");
	}
	if (c_in_book && localName.equals("title")){
		c_in_book_name = true;
	}
	if (c_in_book && localName.equals("year")){
		c_in_year = true;
	}
	if (localName.equals("loan")){
		int bbb = c_b_id.indexOf(atts.getValue("b_id"));
		if (bbb != -1)
			loan_table += "\nKnihu " + c_b_name.get(bbb) + " ma vypujcenu uzivatel " + c_u_name.get(c_u_id.indexOf(atts.getValue("u_id")));
	}
	/* /Context */
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
	/* Elements */
	/* uzavirani kontextu */
	if (localName.equals("book")){
		in_book=false;
	}
	if (in_book && localName.equals("price")){
		++book_count;
		sum_price+=cur_price;
	}
	/* /Elements */
	/* Atributes*/
 	if (localName.equals("user")){
		in_user=false;
		if (!has_czech_adr){
			err_string += '\n' + "User on lines: " + cur_u_locator + " -- " + locator.getLineNumber() + ".";
		}
		has_czech_adr = false;
	}
	/* /Atributes */
    	/* Context */
 	if (localName.equals("user")){
		if (!c_name.equals("")){
			c_u_id.add(c_id);
			c_u_name.add(c_name);
		}
		c_name="";
		c_in_user = false;
	}
	if (localName.equals("book")){
		if (!c_name.equals("") && c_old){
			c_b_id.add(c_id);
			c_b_name.add(c_name);
		}
		c_name = "";
		c_old = false;
		c_in_book = false;
	}
	/* /Context */
    }


    int charWhitespacesToInt(char[] chars, int length){
	int returnInt = 0;
	for (int i = 0; i < length; ++i){
		if (chars[i] >= '0' && chars[i] <='9'){
			returnInt = returnInt *10 + (chars[i]-'0');
		}
	}
	return returnInt;
    }
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
	/* Elements */
	/* prevedeme cenu z char[] na Int
 	   kvuli bilym znakum konvertuji takto hloupe */
	if (in_book && in_price){
		cur_price = charWhitespacesToInt(chars, length);
		in_price=false;
	}
	/* /Elements */
    	/* Context */
	if (c_in_user_name || c_in_book_name){
		int j = 0, k=length-1;
		while (Character.isWhitespace(chars[j])) ++j;
		while (Character.isWhitespace(chars[k])) --k;
		c_name = new String(chars, j, k-j+1);
		c_in_user_name = false;
		c_in_book_name = false;
	}
	if (c_in_year) {
		c_old = (2013-charWhitespacesToInt(chars, length) >= 20);
		c_in_year = false;
	}
	/* /Context */
    }
}
