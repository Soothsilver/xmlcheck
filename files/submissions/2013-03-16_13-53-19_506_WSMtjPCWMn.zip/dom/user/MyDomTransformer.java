/* Ukol DOM
 *  pridame knihu do sekce scifi s danyma atributama a elementama(dokonce by to melo byt validni vzhledem k dtd)
 *
 *  seradime knihy podle autora a roku vydani
 *
 *
 *  v obou pripadech pocitam s existenci polozky books
 */
package user;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

/**
 * ASSIGNMENT: Update document to be able to transform input XML document to
 * output document by actions mentioned in comments of processTree method.
 */
public class MyDomTransformer{
    public void transform(Document doc) {
        /*  prvni cast ukolu, pridam knihu do sekce scifi s unikatnim id */
	NodeList tmpList = doc.getElementsByTagName("book");
	int maxint = 0;
	String s_id = "";
	//tento forcyklus je pro zjisteni id, ktere dostane nova kniha
	for (int i = 0; i < tmpList.getLength(); ++i){
		if (tmpList.item(i) instanceof Element){
			Element tmpNode = (Element)tmpList.item(i);
			String cur_id = tmpNode.getAttributes().getNamedItem("b_id").getNodeValue();
			int cur_int = Integer.parseInt(cur_id.substring(2));
			maxint = maxint > cur_int ? maxint : cur_int;
		}
	}
	tmpList = doc.getElementsByTagName("section");
	//a zde zjistujeme s_id sekce se jmenem sci-fi
	for (int i = 0; i < tmpList.getLength(); ++i){
		if (tmpList.item(i) instanceof Element){
			Element tmpNode = (Element)tmpList.item(i);
			String tmp_name = tmpNode.getAttributes().getNamedItem("name").getNodeValue();
			if (tmp_name.equals("sci-fi")){
				s_id = tmpNode.getAttributes().getNamedItem("s_id").getNodeValue();
			}

		}
	}
	//a uz jen nejake to nastaveni atributu a podelemntu a vlozeni prvku do books(pocitam s jeho existenci)
	Element book = doc.createElement("book");
	Attr b_id_att = doc.createAttribute("b_id");
	b_id_att.setValue("b_" + (++maxint));
	book.setAttributeNode(b_id_att);
	Attr s_id_att = doc.createAttribute("s_id");
	s_id_att.setValue(s_id);
	book.setAttributeNode(s_id_att);
	book.appendChild(doc.createElement("title").appendChild(doc.createTextNode("Logika - neuplnost, slozitost a nutnost")).getParentNode());
	book.appendChild(doc.createElement("author").appendChild(doc.createTextNode("Svejdar, Vitezslav")).getParentNode());
	book.appendChild(doc.createElement("year").appendChild(doc.createTextNode("2002")).getParentNode());
	book.appendChild(doc.createElement("price").appendChild(doc.createTextNode("314")).getParentNode());
	doc.getElementsByTagName("books").item(0).appendChild(book);
	/* konec prvni casti*/
	/* druha operace seradi knihy primarne podle autora a sekundarne podle roku vydani, je pouzit jen bubblesort*/
	tmpList = doc.getElementsByTagName("book");
	Node books = doc.getElementsByTagName("books").item(0);
	for (int i = 0; i < tmpList.getLength()-1; ++i){
		for (int j = 0; j < tmpList.getLength()-1; ++j){
			if(compareE((Element)tmpList.item(j), (Element)tmpList.item(j+1))){
				books.insertBefore(tmpList.item(j+1), tmpList.item(j));
			}
		}
    	}
	/* serazeno*/
    }
    
    private static boolean compareE(Element e1, Element e2){
	int result = e1.getElementsByTagName("author").item(0).getTextContent().replaceAll("\\s","").compareToIgnoreCase(e2.getElementsByTagName("author").item(0).getTextContent().replaceAll("\\s",""));
	if (result == 0){
		result = Integer.parseInt(e1.getElementsByTagName("year").item(0).getTextContent().replaceAll("\\s","")) - Integer.parseInt(e2.getElementsByTagName("year").item(0).getTextContent().replaceAll("\\s",""));
	}
	return (result > 0);
    }
}
