package user;


import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Autor: Luis Moreno, 2. domaci ukol z predmetu A7B36XML
 * 
 *
 */

/**
* Out custom content handler for managing SAX events Implements methods of the
* abstract class ContentHandler.
*/
public class MySaxHandler extends  DefaultHandler {
   
   String currentElementName = "";
   
   /* avg age calculation*/
   double ageSum = 0;
   int refereeCounter = 0;
   
   /* most expensive prix - cup */
   int maxPrice = 0;
   boolean inPrix = false;
   String prixType = "";
   
   /* number of referees, that are older than 30, and have a higher rank than 50*/
   int refCounter = 0;
   boolean inRef = false;
   boolean isOldRef = false;

   /**
    * Method to handle "begin element"
    *
    * @param uri URI of the element namespace (empty if element is no
    * namespace)
    * @param localName local name of the element (never empty)
    * @param qName qualified name (prefix-URI + ':' + localName, if the element
    * is in some namespace or localName otherwise)
    * @param atts Element's attributes
    * @throws SAXException
    */
   @Override
   public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
       
       if(localName.equalsIgnoreCase("prix")){
           inPrix = true;
       }
       
       if(localName.equalsIgnoreCase("referee")){
           inRef = true;
           
           int atsLength = atts.getLength();
           for (int i = 0; i < atsLength; i++) {
               
               if(atts.getLocalName(i).equalsIgnoreCase("age")){
                   if((Integer.parseInt(atts.getValue(i)) > 30)){
                       isOldRef = true;
                   }
               }
           }
       }
           
       avgRefereeAge(localName, atts);

       currentElementName = localName;
    }

   /**
    * Method to handle "element end"
    *
    * @param uri URI of the element namespace (empty if element is no
    * namespace)
    * @param localName local name of the element (never empty)
    * @param qName qualified name (prefix-URI + ':' + localName, if the element
    * is in some namespace or localName otherwise)
    * @param atts Element's attributes
    * @throws SAXException
    */
   @Override
   public void endElement(String uri, String localName, String qName) throws SAXException {
       
       if(localName.equalsIgnoreCase("prix")){
           inPrix = false;
       }
       
       if(localName.equalsIgnoreCase("referee")){
           inRef = false;
           isOldRef = false;
       }
   }

   /**
    * Method to handle "character data" SAX parser can process data in various
    * batches. so we can't rely that whole text content will be delivered
    * in one call Text is in array 'chars' from position ('start') to ('start'
    * + 'length' - 1)
    *
    * @param chars Array with char data
    * @param start Index of the begin of valid data
    * @param length Length of the valid data
    * @throws SAXException
    */
   @Override
   public void characters(char[] chars, int start, int length) throws SAXException {
       
    /**************************************************************************/
       /*searching the price, which is a cup and has the maximum value*/
       if(currentElementName.equalsIgnoreCase("type") && inPrix){
           prixType = new String(chars, start, length);
       }
       
       if ( currentElementName.equalsIgnoreCase("value") && inPrix ){
           int actualPrice = Integer.parseInt(new String(chars, start, length));
           if ( prixType.equalsIgnoreCase("cup") && actualPrice > maxPrice ) maxPrice = actualPrice;
       }       
    /**************************************************************************/
       
       /* number of referees, that are older than 30, and have a higher rank than 50*/
       /* loads only inside >30 referee elements  */
       if(currentElementName.equalsIgnoreCase("rank") && inRef && isOldRef){
           if(Integer.parseInt(new String(chars, start, length)) > 50){
               refCounter++;
           }
       }
      
    }
   
   // collects data from element "referee" (for average age calculation)
   public void avgRefereeAge(String localName, Attributes atts){
       
       if(localName.equalsIgnoreCase("referee")){
           
           refereeCounter++;
           
           int attsLength = atts.getLength();
           for (int i = 0; i < attsLength; i++) {
               
               if(atts.getLocalName(i).equalsIgnoreCase("age")){
                   
                   ageSum += Integer.parseInt(atts.getValue(i));
               }
           } 
       }    
   }
   /**
    * Method to handle "document end"
    *
    * @throws SAXException
    */
   @Override
   public void endDocument() throws SAXException {
       // ...
       
       System.out.println("refs:" + refereeCounter);
       System.out.println("avgAge: " + ageSum / refereeCounter);
       
       System.out.println("biggest cup price: " + maxPrice);
       System.out.println("number of referees, that are older than 30, and have a higher rank than 50 :" + refCounter);
       System.out.println("");
       
   }   
      
   
   /**
    * Sets the locator
    *
    * @param Locator locator location in the file
    */
   @Override
   public void setDocumentLocator(Locator locator) {
       this.locator = locator;
   }   

   /**
    * Method to handle "document start"
    *
    * @throws SAXException
    */
   @Override
   public void startDocument() throws SAXException {
       // ...
   }


   /**
    * Method to handle " start of namespace declaration"
    *
    * @param prefix Prefix of the namespace
    * @param uri URI of the namespace
    * @throws SAXException
    */
   @Override
   public void startPrefixMapping(String prefix, String uri) throws SAXException {
       // ...
   }

   /**
    * Method to handle "end of namespace declaration"
    *
    * @param prefix
    * @throws SAXException
    */
   @Override
   public void endPrefixMapping(String prefix) throws SAXException {
       // ...
   }

   /**
    * Method to handle "ignoring of whitespaces" Text is in array 'chars' from
    * position ('start') to ('start' + 'length' - 1)
    *
    * @param chars Array with char data
    * @param start Index of the begin of valid data
    * @param length Length of the valid data
    * @throws SAXException
    * @throws SAXException
    */
   @Override
   public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
       // ...
   }

   /**
    * Method to handle "processing instructions"
    *
    * @param target The processing instruction target
    * @param data  The processing instruction data
    * @throws SAXException
    */
   @Override
   public void processingInstruction(String target, String data) throws SAXException {
       // ...
   }

   /**
    * Method to handle "unprocessed entity"
    *
    * @param name
    * @throws SAXException
    */
   @Override
   public void skippedEntity(String name) throws SAXException {
       // ...
   }
   
  // Helper variable to store location of the handled event
   Locator locator;   
    private static final String INPUT_FILE = "data.xml";
    
//    public static void main(String[] args) {
//       try {
//
//           // Create parser instance
//           XMLReader parser = XMLReaderFactory.createXMLReader();
//
//           // Create input stream from source XML document
//           InputSource source = new InputSource(INPUT_FILE);
//
//           // Set our custom content handler for handling SAX events (it must implements ContentHandler interface)
//           parser.setContentHandler(new MySaxHandler());
//
//           // Process input data
//           parser.parse(source);
//
//       } catch (Exception e) {
//           e.printStackTrace();
//       }        
//        
//    }   
  
}

