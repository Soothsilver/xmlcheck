/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author me
 */
public class MyDomTransformer {
    
//    public MyDomTransformer(){
//        
//       try {
//
//         //Create instance of DocumentBuilderFactory
//          DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
//          //Get the DocumentBuilder
//          DocumentBuilder docBuilder = factory.newDocumentBuilder();
//          //Create blank DOM Document
//          Document doc = docBuilder.parse("data.xml");
//          delYoungRefs(doc);
//          addNewReferee(doc);
//          TransformerFactory tranFactory = TransformerFactory.newInstance(); 
//           Transformer aTransformer = tranFactory.newTransformer();
//           Source src = new DOMSource(doc); 
//           Result dest = new StreamResult(System.out); 
//           aTransformer.transform(src, dest); 
//
//       } catch (TransformerException | ParserConfigurationException | SAXException | IOException ex) {
//           System.out.println(ex.getMessage());
//       }        
//        
//    }
    public void transform (Document xmlDocument) {
    
        delYoungRefs(xmlDocument);
        addNewReferee(xmlDocument);
    }
    
    
    /*Deletes all the referees that are younger than 30*/   
    private static void delYoungRefs(Document doc) {
        
        NodeList nodes = doc.getElementsByTagName("referee");
        for(int i=nodes.getLength()-1; i>=0; i--){
            Element ref = (Element)nodes.item(i);
            int age = Integer.parseInt(ref.getAttribute("age"));
            if(age <= 30){
                ref.getParentNode().removeChild(ref);
            }
        }
    }    
    
    /*adds a new Referee to the Document */    
    private static void addNewReferee(Document doc){
        
        Element newRef = doc.createElement("referee");
        newRef.setAttribute("id", "RTE-1847");
        newRef.setAttribute("age", "47");
        newRef.appendChild(doc.createElement("name")).setTextContent("Petr");
        newRef.appendChild(doc.createElement("surname")).setTextContent("Jasny");
        newRef.appendChild(doc.createElement("rank")).setTextContent("52");
        newRef.appendChild(doc.createElement("tel")).setTextContent("+420 733 988 921");
        
        doc.getElementsByTagName("gameInfo").item(0).appendChild(newRef);
    }

    
}
