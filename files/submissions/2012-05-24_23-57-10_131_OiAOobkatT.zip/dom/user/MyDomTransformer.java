package user;

import org.w3c.dom.*;


public class MyDomTransformer {

    public void transform (Document xmlDocument) {

        try {

            //ziskame hlavni element
            Node mainNode = xmlDocument.getDocumentElement();

            //zpracujeme DOM strom
            processNode(mainNode);


        } catch (Exception e) {

            e.printStackTrace();

        }
    }

    /**
     * Zpracuje DOM strom
     */
    private void processNode(Node node) {
        if (node == null)
            return;

        if (node.getNodeType() == Node.TEXT_NODE)
        {
            String value = node.getNodeValue().trim();
            if (value.isEmpty())
                return;

            Node parent = node.getParentNode();
            if (parent == null || parent.getNodeType() != Node.ELEMENT_NODE)
                return;

            ((Element)parent).setAttribute("TextValue", value);
            parent.removeChild(node);
        }

        NodeList children = node.getChildNodes();
        for (int i = 0; i < children.getLength(); ++i)
            processNode(children.item(i));
    }
}
