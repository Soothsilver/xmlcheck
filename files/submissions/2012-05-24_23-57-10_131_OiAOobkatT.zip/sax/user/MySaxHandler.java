package user;

import java.util.Stack;

import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {

    Locator locator;

    // Misto Stack elementu by slo pouzit jen int s aktualni hloubkou.
    Stack<String> elementStack = new Stack<String>();
    
    int elementCount = 0;
    int maxElementDeep = 0;
    int sumElementDeeps = 0;
    int countElementDeeps = 0;
    boolean open = false;

    public int GetElementCount() {
        return elementCount;
    }

    public int GetMaxElementDeep() {
        return maxElementDeep;
    }

    public int GetAvgElementDeep() {
        return (sumElementDeeps / countElementDeeps);
    }

    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    public void startDocument() throws SAXException {

        // ...

    }
    public void endDocument() throws SAXException {

        // ...

    }

    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        // ...
        elementStack.add(qName);
        
        ++elementCount;
        open = true;
        if (elementStack.size() > maxElementDeep)
            maxElementDeep = elementStack.size();
    }
    public void endElement(String uri, String localName, String qName) throws SAXException {

        // ...
        if (!elementStack.peek().equals(qName))
            System.out.printf("ERROR: element name missmatch opened = %s, closing = %s.\n", elementStack.peek(), qName);

        if (open)
        {
            sumElementDeeps += elementStack.size();
            ++countElementDeeps;
        }

        elementStack.pop();
        open = false;
    }

    public void characters(char[] ch, int start, int length) throws SAXException {

        // ...

    }

    public void startPrefixMapping(String prefix, String uri) throws SAXException {

        // ...

    }

    public void endPrefixMapping(String prefix) throws SAXException {

        // ...

    }

    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {

        // ...

    }

    public void processingInstruction(String target, String data) throws SAXException {

      // ...

    }

    public void skippedEntity(String name) throws SAXException {

      // ...

    }
}
