package user;

import org.w3c.dom.*;
import org.w3c.dom.Document;


public class MyDomTransformer {
    
    private static void transform(Document xmlDocument) {
        processSamec(xmlDocument.getDocumentElement());
        processSort(xmlDocument.getDocumentElement(), xmlDocument);
    }
    
    //smaze vechny samce ze zoo
    private static void processSamec(Element elmnt)
    {
        NodeList list = elmnt.getChildNodes();
        for (int i = 0; i < list.getLength(); i++) {
            if (list.item(i).getNodeName().equals("zvire"))
                if (jeSamec(list.item(i))) {
                    elmnt.removeChild(list.item(i));
                }
        }
    }
    
    private static boolean jeSamec(Node node)
    {
        NodeList list = node.getChildNodes();
        for (int i = 0; i < list.getLength(); i++) {
            if (list.item(i).getNodeName().equals("pohlavi"))
                if (list.item(i).getAttributes().getNamedItem("pohlavi").getNodeValue().equals("samec")) {
                    return true;
                }
        }
        return false;
    }
    
    //Seradi zvirata podle osloveni.
    //Nepouzivam zadne slozite trideni. Je tedy pekne neefektivni.
    private static void processSort(Element elmnt, Document doc)
    {
        NodeList list = elmnt.getChildNodes();
        int pocetZvirat = 0;
        for (int i = 0; i < list.getLength(); i++)
            if (list.item(i).getNodeName().equals("zvire"))
                pocetZvirat++;
        Node zvirata[] = new Node[pocetZvirat];
        int t = 0;
        for (int i = 0; i < list.getLength(); i++)
            if (list.item(i).getNodeName().equals("zvire")) {
                zvirata[t] = list.item(i);
                t++;
            }
        for (int i = 0; i < pocetZvirat - 1; i++)
            for (int j = 0; j < (pocetZvirat - i -1); j++) {
                if (jmenoZvirete(zvirata[j]).compareTo(jmenoZvirete(zvirata[j+1])) > 0) {
                    Node tmp = zvirata[j];
                    zvirata[j] = zvirata[j+1];
                    zvirata[j+1] = tmp;
                    tmp = doc.createElement("tmp");
                    elmnt.replaceChild(tmp, zvirata[j]);
                    elmnt.replaceChild(zvirata[j],zvirata[j+1]);
                    elmnt.replaceChild(zvirata[j+1], tmp);
                }
            }
    }
    
    private static String jmenoZvirete(Node node)
    {
        NodeList list = node.getChildNodes();
        for (int i = 0; i < list.getLength(); i++) {
            if (list.item(i).getNodeName().equals("osloveni"))
                return list.item(i).getTextContent();
        }     
        return "";
    }
}
