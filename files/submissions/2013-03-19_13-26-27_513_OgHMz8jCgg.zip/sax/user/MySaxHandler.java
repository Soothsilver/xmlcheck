package usrer;

import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;

//Handler spocte pocet savcu, prumernou vahu vesh jedincu
// a zjisti, ktere zcire je nejstarsi.
//Pocet savcu je po skonceni ulozen v promenne savic.
//Prumerna vaha se nachazi v promenne prumVaha.
//Osloveni pro nejstarsi zvire se nachazi v promenne nejstarsi
// a datum narozeni v promennych rok, mesic, den.
public class MySaxHandler extends DefaultHandler {
    
    int savci;
    
    boolean inVaha;
    int pocetVaha;
    int sumVaha;
    int prumVaha;
    
    String vysetrovane;
    String nejstarsi;
    int rok;
    int mesic;
    int den;
    int vrok;
    int vmesic;
    int vden;
    boolean inRok;
    boolean inMesic;
    boolean inDen;
    boolean inOsloveni;

    // Helper variable to store location of the handled event
    Locator locator;


    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    @Override
    public void startDocument() throws SAXException {       
        savci = 0;
        
        pocetVaha = 0;
        sumVaha = 0;
        
        vysetrovane = "";
        nejstarsi = "";
        rok = Integer.MAX_VALUE;
        mesic = Integer.MAX_VALUE;
        den = Integer.MAX_VALUE;
    }


    @Override
    public void endDocument() throws SAXException {
        System.out.print("Pocet savcu je ");
        System.out.println(savci);
        
        prumVaha = sumVaha / pocetVaha;
        
        System.out.print("Prumerna vaha je ");
        System.out.println(prumVaha);
        
        System.out.println("Nejstarsi zvire je " + nejstarsi);
    }


    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {       
        if (localName.equals("trida"))
            for (int i = 0; i < atts.getLength(); i++) 
                if (atts.getQName(i).equals("nazev"))
                    if (atts.getValue(i).equals("savci"))
                        savci++;
        
        if (localName.equals("vaha"))
            inVaha = true;
        
        if (localName.equals("osloveni"))
            inOsloveni = true;
        if (localName.equals("rok"))
            inRok = true;
        if (localName.equals("mesic"))
            inMesic = true;
        if (localName.equals("den"))
            inDen = true;
    }


    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {       
        if (localName.equals("vaha"))
            inVaha = false;
        
        if (localName.equals("osloveni"))
            inOsloveni = false;
        if (localName.equals("rok"))
            inRok = false;
        if (localName.equals("mesic"))
            inMesic = false;
        if (localName.equals("den"))
            inDen = false;
        
        if (localName.equals("zvire"))
            vysetri();

    }


    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        String chrs ="";
        for (int i = start; i < start + length; i++) {
            if (ch[i] == ' ')
                break;
            chrs = chrs + ch[i];
        }
        if (inVaha) {
            int tmpVaha = Integer.parseInt(chrs);
            pocetVaha++;
            sumVaha += tmpVaha;
        }
        
        if (inOsloveni)
            vysetrovane = chrs;
        if (inRok)
            vrok = Integer.parseInt(chrs);
        if (inMesic)
            vmesic = Integer.parseInt(chrs);
        if (inDen)
            vden = Integer.parseInt(chrs);
    }

    
    public void vysetri()
    {
        if (vrok > rok)
            return;
        if (vrok == rok && vmesic > mesic)
            return;
        if (vrok == rok && vmesic == mesic && vden > den )
            return;
        rok = vrok;
        mesic = vmesic;
        den = vden;
        nejstarsi = vysetrovane;
    }
}