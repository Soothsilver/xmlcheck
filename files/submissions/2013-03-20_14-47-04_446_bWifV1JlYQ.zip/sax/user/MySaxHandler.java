package user;

import java.util.HashMap;
import java.util.Map.Entry;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 * XML - SAX Handler
 * @author Michal Vlcek <vlcekmi3@fel.cvut.cz>
 */
public class MySaxHandler extends DefaultHandler {
    private static final String INPUT_FILE = "data.xml";
    private String currentElementName;
    // 1
    private int movieCount = 0;
    private int showCount = 0;
    // 2
    private HashMap<String,Integer> nationality = new HashMap<String,Integer>();
    private String higherNationality = "";
    private int nationalityCount = 0;
    // 3
    private String bestMovie = "";
    private int bestRating = 0;
    private int tmpYear = 0;
    private String tmpMovie = "";
    private int tmpRating = 0;

    public static void main(String[] args) {
        try {
            XMLReader parser = XMLReaderFactory.createXMLReader();
            InputSource source = new InputSource(INPUT_FILE);
            parser.setContentHandler(new MySaxHandler());
            parser.parse(source);
        } catch (Exception e) {
            System.err.println(e.getMessage());

        }
    }

    @Override
    public void setDocumentLocator(Locator locator) {
    }
  
    @Override
    public void startDocument() throws SAXException {
    }
    
    @Override
    public void endDocument() throws SAXException {
        // 1
        System.out.format("V databazi je %d filmu a %d serialu.%n", movieCount, showCount);
        // 2
        getMostcountedNationality(nationality);
        System.out.format("Nejvice tvurcu je z %s (%d).%n", higherNationality, nationalityCount);
        // 3
        System.out.format("Film s nejvetsim hodnocenim z roku 2012 je %s.%n", bestMovie);
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        // 1
        for(int i = 0 ; i < atts.getLength() ; i++) {
            if( qName.equals("film") && atts.getQName(i).equals("typ") ) {
                if( atts.getValue(i).equals("film") ) {
                    movieCount++;
                } else {
                    showCount++;
                }
            }
        }
        currentElementName = qName;
    }
 
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
    }
                
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        // 2
        if(currentElementName.equals("narodnost") && length > 0) {
            StringBuilder country = readElement(start, length, ch);
            if(!nationality.containsKey(country.toString())) {
                nationality.put(country.toString(), 1);
            } else {
                int count = nationality.remove(country.toString());
                nationality.put(country.toString(), ++count);
            }
        }
        // 3
        if(currentElementName.equals("nazev") && length > 0) {
            StringBuilder title = readElement(start, length, ch);
            tmpMovie = title.toString();
        }
        if(currentElementName.equals("rok") && length > 0) {
            StringBuilder year = readElement(start, length, ch);
            tmpYear = Integer.valueOf(year.toString());
        }
        if(currentElementName.equals("hodnoceni") && length > 0) {
            StringBuilder rating = readElement(start, length, ch);
            tmpRating = Integer.valueOf(rating.toString());
        }
        if(tmpRating > bestRating && tmpYear == 2012) {
            bestRating = tmpRating;
            bestMovie = tmpMovie;
        }

    }
    
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
    }
   
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
    }
 
    @Override
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
    }
       
    @Override
    public void processingInstruction(String target, String data) throws SAXException { 
    }
    
    @Override
    public void skippedEntity(String name) throws SAXException {
    }

    private StringBuilder readElement(int start, int length, char[] ch) {
        StringBuilder builder = new StringBuilder();
        for (int i = start; i < start+length; i++) {
            builder.append(ch[i]);
        }
        return builder;
    }

    private void getMostcountedNationality(HashMap<String,Integer> nationality) {
        for (Entry<String, Integer> i : nationality.entrySet()){
            if(nationalityCount < i.getValue()) {
                higherNationality = i.getKey();
                nationalityCount = i.getValue();
            }
        }
    }
    
}