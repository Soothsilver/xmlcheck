package user;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * XML - DOM Transformer
 * TASKS:
 * 1. Add new movie
 * 2. Delete all shows
 * 3. Sort "tvurce" alphabetically by "prijmeni"
 * @author Michal Vlcek <vlcekmi3@fel.cvut.cz>
 */
public class MyDomTransformer {
    
    private static final String INPUT_FILE = "data.xml";
    
     public static void main(String[] args) {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setValidating(false);
            DocumentBuilder builder = dbf.newDocumentBuilder();
            Document doc = builder.parse(INPUT_FILE);
            transform(doc);
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer writer = tf.newTransformer();
            writer.setOutputProperty(OutputKeys.INDENT, "yes");
            writer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            StreamResult resultCnsl = new StreamResult(System.out);
            writer.transform(new DOMSource(doc), resultCnsl);
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }
    
    public static void transform (Document xmlDocument) {
        // 1
        Element newFilm = createMovie(xmlDocument);
        NodeList movies = xmlDocument.getElementsByTagName("filmy");
        movies.item(0).appendChild(newFilm);
        // 2
        NodeList movie = xmlDocument.getElementsByTagName("film");
        for (int i = 0; i < movie.getLength(); i++) {
            if(movie.item(i).getAttributes().getNamedItem("typ").getTextContent().equals("serial")) {
                movie.item(i).getParentNode().removeChild(movie.item(i));
            }
        }
        // 3
        NodeList actors = xmlDocument.getElementsByTagName("tvurce");
        sort(actors);
    }
    
    // 1
    private static Element createMovie(Document xmlDocument) throws DOMException {
        Element newElement = xmlDocument.createElement("film");
        Element titleCz = xmlDocument.createElement("nazev");
        titleCz.setTextContent("Ctihodny Obcan");
        Element titleOrig = xmlDocument.createElement("nazev");
        titleOrig.setTextContent("The Law Abiding Citizen");
        Element genre = xmlDocument.createElement("zanr");
        genre.setTextContent("Krimi,Drama,Thriller");
        Element year = xmlDocument.createElement("rok");
        year.setTextContent("2009");
        Element length = xmlDocument.createElement("delka");
        length.setTextContent("109");
        Element director = xmlDocument.createElement("reziser");
        director.setAttribute("id", "_t3");
        Element description = xmlDocument.createElement("popis");
        description.setTextContent("Ctihodný občan je dramatický thriller o muži..");
        Element rating = xmlDocument.createElement("hodnoceni");
        rating.setTextContent("78");
        Element actors = xmlDocument.createElement("herci");
        Element actor = xmlDocument.createElement("herec");
        actor.setAttribute("id", "_t7");
        Element name = xmlDocument.createElement("celejmeno");
        name.setTextContent("Gerard Butler");
        actor.appendChild(name);
        actors.appendChild(actor);
        
        newElement.setAttribute("id", "_f5");
        newElement.setAttribute("typ", "film");
        newElement.appendChild(titleCz);
        newElement.appendChild(titleOrig);
        newElement.appendChild(genre);
        newElement.appendChild(year);
        newElement.appendChild(length);
        newElement.appendChild(director);
        newElement.appendChild(description);
        newElement.appendChild(rating);
        newElement.appendChild(actors);
        return newElement;
    }
    //3
    private static void sort(NodeList nodes) {
        for (int i = 0; i < nodes.getLength(); i++) {
            for (int j = 0; j < (nodes.getLength() - 1 - i); j++) {
                if (getActorsName(nodes.item(j)).compareTo(getActorsName(nodes.item(j+1)))> 0) {
                    nodes.item(j).getParentNode().insertBefore(nodes.item(j+1), nodes.item(j));
                }
            }
        }
    }
    
    public static String getActorsName(Node element) {
        NodeList kids = element.getChildNodes();
        return kids.item(3).getTextContent();
    }
}