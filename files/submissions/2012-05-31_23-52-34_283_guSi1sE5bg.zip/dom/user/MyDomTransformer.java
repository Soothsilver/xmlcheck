package user;
import org.w3c.dom.*;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.LinkedList;

public class MyDomTransformer {
    public void transform (Document xmlDocument) {
        Element root = xmlDocument.getDocumentElement();
        NodeList li = root.getElementsByTagName("model");
        Node model = li.item(0);
        li = ((Element) model).getElementsByTagName("entities");
        Node entities = li.item(0);
        li = ((Element) entities).getElementsByTagName("entity");
        
        Element html = xmlDocument.createElement("html");
        Element head = xmlDocument.createElement("head");
        Element title = xmlDocument.createElement("title");
        Element body = xmlDocument.createElement("body");
        title.appendChild(xmlDocument.createTextNode("Sprava ciselniku"));
        head.appendChild(title);
        html.appendChild(head);
        
        Element table, th, td, tr;
        
        for (int i = 0; i < li.getLength() ; ++i) {
            Node item = li.item(i);
            String tableName =((Element) item).getAttribute("id");
            
            table = xmlDocument.createElement("table");
            tr = xmlDocument.createElement("tr");
            
            NodeList attrs =((Element) item).getElementsByTagName("attributes");
            attrs = attrs.item(0).getChildNodes();
            
            Hashtable<String, String> entityData = new Hashtable<String, String>();
            Hashtable<String, Boolean> isReference = new Hashtable<String, Boolean>();
            LinkedList<String> attNames = new LinkedList<String>();
            String keyAttribute = "";
            
            for (int j = 0; j < attrs.getLength(); ++j) {
                if (attrs.item(j).getNodeType() != Node.ELEMENT_NODE) continue;
                th = xmlDocument.createElement("th");
                th.appendChild(xmlDocument.createTextNode( ((Element) attrs.item(j)).getAttribute("name") ));
                entityData.put(((Element) attrs.item(j)).getAttribute("name"), "");
                attNames.add(((Element) attrs.item(j)).getAttribute("name"));
                tr.appendChild(th);
                if (attrs.item(j).getNodeName().equalsIgnoreCase("keyAttribute")) {
                    keyAttribute = ((Element) attrs.item(j)).getAttribute("name");
                }
                isReference.put(((Element) attrs.item(j)).getAttribute("name"), ((Element) attrs.item(j)).getAttribute("displayType").equalsIgnoreCase("reference"));
                //System.out.println(item.getNodeName());
            }
            table.appendChild(tr);
            
            Node recs = root.getElementsByTagName("data").item(0);
            NodeList records = recs.getChildNodes();
            
            for (int j = 0; j < records.getLength(); ++j) {
                if (records.item(j).getNodeType() != Node.ELEMENT_NODE) continue;
                if (! tableName.equalsIgnoreCase(((Element) records.item(j)).getAttribute("type"))) continue;
                
                NodeList attributes = records.item(j).getChildNodes();
                
                for (int k = 0; k < attributes.getLength(); ++k) {
                    if (attributes.item(k).getNodeType() != Node.ELEMENT_NODE) continue;
                    Node attr = attributes.item(k);
                    String nm =((Element) attr).getAttribute("name");
                    String val = "";
                    NodeList vals = attr.getChildNodes();
                    if(vals.getLength() > 0) val = vals.item(0).getNodeValue();
                    entityData.put(nm, val);
                }
                // vypis atributu
                

                    tr = xmlDocument.createElement("tr");
                    for( String current : attNames ) {
                        td = xmlDocument.createElement("td");
                        if (current.equalsIgnoreCase(keyAttribute)) {
                            Element anchor = xmlDocument.createElement("a");
                            anchor.setAttribute("name", current + "_" + entityData.get(current));
                            anchor.appendChild(xmlDocument.createTextNode(entityData.get(current)));
                            td.appendChild(anchor);
                        } else if (isReference.get(current)) {
                            Element anchor = xmlDocument.createElement("a");
                            anchor.setAttribute("href", "#" + current + "_" + entityData.get(current));
                            anchor.appendChild(xmlDocument.createTextNode(entityData.get(current)));
                            td.appendChild(anchor);
                        } else {
                            td.appendChild(xmlDocument.createTextNode(entityData.get(current)));
                        }
                        entityData.put(current, "");
                        tr.appendChild(td);
                    }
                    table.appendChild(tr);
                    
//                System.out.println(item.getNodeName());
            }
            Element h1 = xmlDocument.createElement("h1");
            h1.appendChild(xmlDocument.createTextNode(tableName));
            body.appendChild(h1);
            body.appendChild(table);
        }
        xmlDocument.removeChild(xmlDocument.getFirstChild());


        html.appendChild(body);
        xmlDocument.appendChild(html);
     //   System.out.println(xmlDocument.);
    // code transforming xmlDocument object
    // (method works on the object itself - no return value)
    }
}