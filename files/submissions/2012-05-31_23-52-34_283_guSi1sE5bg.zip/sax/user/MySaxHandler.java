package user;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;
import java.util.Hashtable;
import java.util.Enumeration;

enum Status { START, ENTITY, RECORD, VALUE }

class Entity {
 // public String name;
  public String keyAttribute;
  public Hashtable<String, Integer> attributes;
  public Hashtable<String, String> types;
}

public class MySaxHandler extends DefaultHandler {
    protected Status st = Status.START;
    protected Hashtable<String, Entity> entities;
    protected String current;
    protected int len;
    protected String attName;
  
  public void startDocument() {
    entities = new Hashtable<String, Entity>();
  }
  
  public void startElement(String uri, String localName, String qName, Attributes atts) {
    Entity e;
    if (st == Status.START) {
        if (localName.equalsIgnoreCase("entity")) {
            st = Status.ENTITY;
            current = atts.getValue("id");
            e = new Entity();
            e.attributes = new Hashtable<String, Integer>();
            e.types = new Hashtable<String, String>();
            entities.put(current, e);
        }
        if (localName.equalsIgnoreCase("record")) {
            st = Status.RECORD;
            current = atts.getValue("type");
        }
    } else if (st == Status.ENTITY) {
        if (localName.equalsIgnoreCase("keyAttribute")) {
            // pridat key attribute
            e = entities.get(current);
            e.keyAttribute = atts.getValue("name");
            e.attributes.put(atts.getValue("name"), 0);
            e.types.put(atts.getValue("name"), atts.getValue("dataType"));
            
            // System.out.println(localName);
        } else if (localName.equalsIgnoreCase("attribute")) {
            e = entities.get(current);
            e.attributes.put(atts.getValue("name"), 0);
            e.types.put(atts.getValue("name"), atts.getValue("dataType"));
        }
    } else if (st == Status.RECORD) {
        if (localName.equalsIgnoreCase("attr")) {
            st = Status.VALUE;
            attName =  atts.getValue("name");
            len = 0;
        }
    }
  }
  
  public void characters(char[] ch, int start, int length) {
    len += length;
  }
  
  public void endElement(String uri, String localName, String qName) {
    Entity e;
    if (st == Status.ENTITY) {
        if (localName.equalsIgnoreCase("entity")) {
            st = Status.START;
        }
    } else if (st == Status.RECORD) {
        if (localName.equalsIgnoreCase("record")) {
            st = Status.START;
        }
    } else if (st == Status.VALUE) {
        if (localName.equalsIgnoreCase("attr")) {
            e = entities.get(current);
            st = Status.RECORD;
            if (len > e.attributes.get(attName)) {
                e.attributes.put(attName, len);
            }
        }
    }
  }
  
  public void endDocument() {
    Enumeration<String> en = entities.keys();
    Enumeration<String> at;
    Entity e;

    while(en.hasMoreElements()) {
        current = en.nextElement();
        e = entities.get(current);
        System.out.println("CREATE TABLE " + current + " (");
        at = e.attributes.keys();
        
        while(at.hasMoreElements()) {
            attName = at.nextElement();
            System.out.print("\"" + attName + "\" " + getType(e.types.get(attName), e.attributes.get(attName)));
            if (attName.equalsIgnoreCase(e.keyAttribute)) {
                System.out.print(" not null");
            }
            if (at.hasMoreElements()) System.out.println(",");
        }
        if(e.keyAttribute != null) {
            System.out.println(",");
            System.out.println("CONSTRAINT pk_" + current + " PRIMARY KEY (" + e.keyAttribute + ")");
        } else {
            System.out.println();
        }
        System.out.println(");");
    }
  }
  
  public String getType(String typename, Integer maxLength) {
    String res = "";
    int[] stringLimits = {5, 15, 40, 80, 150};
    String[] stringSizes = {"10", "20", "50", "100", "200", "4000"};
    int[] intLimits = {5, 10, 15, 20};
    String[] intSizes = {"10", "15", "20", "25", "30", "39"};
    int i;

    if (typename.equalsIgnoreCase("string")) {
        i = 0;
        while (i < stringLimits.length && stringLimits[i] < maxLength) ++i;
        res = "VARCHAR2(" + stringSizes[i] + ")";
    } else if (typename.equalsIgnoreCase("text")) {
        res = "CLOB";
    } else if (typename.equalsIgnoreCase("integer")) {
        i = 0;
        while (i < intLimits.length && intLimits[i] < maxLength) ++i;
        res = "NUMBER(" + intSizes[i] + ")";
    }
    
    return res;
  }
}