/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.NamedNodeMap;

import java.util.List;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Collections;


/**
 * Pro elementy Knowledge prida pro podznalosti novy otcovsky uzel (Knowledge/Application ->
 * Knowledge/ApplicationKnowledge/Application), stejne pro Language a pro ProgrammingLanguage.
 * Pro hry, ktere nemaji uveden engine, se vytvori novy defaultni uzel
 * (<engine>Proprietary engine</engine>).
 * Vsechny atributy prevede na elementy. Elementy setridi podle abecedy.
 * Odstrani nektere instrukce pro zpracovani a nektere komentare (zachovava komentar
 * a instrukci pro zpracovani pred korenovym elementem).
 * @author Lukáš Asník
 */
public class MyDomTransformer {
    
    /**
     * Comparator for comparing Nodes.
     */
    NodeNameComparator nodeComparator = new NodeNameComparator();
    
    /**
     * Document to process.
     */
    Document document;
    
    /**
     * Compares two Nodes.
     */
    static class NodeNameComparator implements Comparator<Node>
    {

        public int compare(Node o1, Node o2) {
            //get the node names
            String firstName = o1.getNodeName();
            String secondName = o2.getNodeName();
            
            return firstName.compareTo(secondName);
        }
        
    }
    
    
    /**
     * Transforms given XML document.
     * @param xmlDocument XML document to transform.
     */
    public void transform (Document xmlDocument) {
       document = xmlDocument;
        
       changeKnowledge(document);
       
       addProprietaryEngine(document);
       
       Element documentElement = xmlDocument.getDocumentElement();
       
       processAllNodes(documentElement);
        
  }
    
    /**
     * Processes all nodes. Attributes transforms to elements. Orders elements
     * by name.
     * @param n Node to process.
     */
    private void processAllNodes(Node n)
    {
        
        //list of all elements
        List<Node> elements = new ArrayList<Node>();
        
        //first, get attributes
        NamedNodeMap attributes =  n.getAttributes();
        
        //list of attribute names
        List<String> attrNames = new ArrayList<String>();
        
        for(int i = 0; i < attributes.getLength(); ++i)
        {
            Node atr = attributes.item(i);
            //create element and add to the list of all elements
            
            Element e = document.createElement(atr.getNodeName());
            e.appendChild(document.createTextNode(atr.getNodeValue()));
            
            elements.add(e);
            attrNames.add(atr.getNodeName());
        }
        
        //removes all attributes
        for(String str : attrNames)
        {
            attributes.removeNamedItem(str);
        }
        
        NodeList childNodes = n.getChildNodes();
       
        List<Node> commentsAndProcessingInstructions = new ArrayList<Node>();
        //filter nodes, get elements, remove comments
        for(int i = 0; i < childNodes.getLength(); ++i)
        {
            Node curNode = childNodes.item(i);
            
            if(curNode.getNodeType() == Node.ELEMENT_NODE)
            {
                elements.add(curNode);
            }else if(curNode.getNodeType() == Node.COMMENT_NODE || curNode.getNodeType() == Node.PROCESSING_INSTRUCTION_NODE)
            {
                commentsAndProcessingInstructions.add(curNode);
            }
        }
        
        //romeve comments and processing instructions
        for(Node node : commentsAndProcessingInstructions)
        {
            n.removeChild(node);
        }
        
        //Sort the elements by their name
        Collections.sort(elements, nodeComparator);
        
        //process child elements and append the elements in correct order, they are deleted automatically
        for(int i = 0; i < elements.size(); ++i)
       {
           Node element = elements.get(i);
           n.appendChild(element);
           if(element.hasChildNodes() || element.hasAttributes())
           {
                processAllNodes(element);
           }
       }
    }
    
    /**
     * Adds ApplicationKnowledge element if there are any Application elements,
     * same with Language and ProgrammingLanguage.
     * @param doc 
     */
    private void changeKnowledge(Document doc)
    {
        NodeList knowledgeList = doc.getElementsByTagName("Knowledge");
        
        for(int i = 0; i < knowledgeList.getLength(); ++i)
        {
            Node node = knowledgeList.item(i);
            addSpecificKnowledgeNode(node, "Application", "ApplicationKnowledge");
            addSpecificKnowledgeNode(node, "Language", "LanguageKnowledge");
            addSpecificKnowledgeNode(node, "ProgrammingLanguage", "ProgrammingLanguageKnowledge");
        }
    }
    
    private void addSpecificKnowledgeNode(Node knowledgeNode, String knowledgeType, String newKnowledgeTag)
    {
        NodeList children = knowledgeNode.getChildNodes();
        
        List<Node> specificChildren = new ArrayList<Node>();
        for(int i = 0; i < children.getLength(); ++i)
        {
            Node node = children.item(i);
            if(node.getNodeType() == Node.ELEMENT_NODE && node.getNodeName() == knowledgeType)
            {
                specificChildren.add(node);
            }
        }
        
        if(specificChildren.size()>0)
        {
            //delete the nodes from this parent
            for(Node n : specificChildren)
            {
                knowledgeNode.removeChild(n);
            }
            
            //create the new parent node
            Element parentNode = document.createElement(newKnowledgeTag);
            //add children
            for(Node n : specificChildren)
            {
                parentNode.appendChild(n);
            }
            
            //add new node as child to Knowledge node
            knowledgeNode.appendChild(parentNode);
        }
        
        
    }
    
    private void addProprietaryEngine(Document doc)
    {
        NodeList games = doc.getElementsByTagName("Game");
        
        outercycle:for(int i = 0; i<games.getLength(); ++i)
        {
            Node node = games.item(i);
            
            //go through children, if has engine node -> do nothing
            NodeList gameChildren = node.getChildNodes();
            for(int j = 0; j < gameChildren.getLength(); ++j)
            {
                Node gameChildNode = gameChildren.item(j);
                
                if(gameChildNode.getNodeType() == Node.ELEMENT_NODE && gameChildNode.getNodeName().equals("Engine"))
                {
                    continue outercycle;
                }
            }
            
            //does not have engine -> create
            Element engine = doc.createElement("Engine");
            engine.appendChild(doc.createTextNode("Proprietary engine"));
            
            //add to current node
            node.appendChild(engine);
        }
    }
}
