﻿/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package user;
import org.w3c.dom.Document;
import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

public class MyDomTransformer {
public static void transform (Document xmlDocument) {
    // Pridani materialu - nastrojove oceli
    NodeList materialy = xmlDocument.getElementsByTagName("materialy");
    Element material = xmlDocument.createElement("material");
    material.setAttribute("id", "ocel10");
    material.setAttribute("non-ferrit", "no");
    Element oznaceni = xmlDocument.createElement("oznaceni");
    Element oznaceniCSN = xmlDocument.createElement("oznaceni-CSN");
    oznaceniCSN.setTextContent("19 855");
    Element oznaceniEN = xmlDocument.createElement("oznaceni-EN");
    oznaceniEN.setTextContent("");
    oznaceni.appendChild(oznaceniCSN);
    oznaceni.appendChild(oznaceniEN);
    material.appendChild(oznaceni);
    Element chemickeVlastnosti = xmlDocument.createElement("chemicke-vlastnosti");
    Element obsahUhliku = xmlDocument.createElement("obsah-uhliku");
    obsahUhliku.setTextContent("0.7");
    Element jednotkaProcento = xmlDocument.createElement("jednotka");
    jednotkaProcento.setTextContent("%");
    obsahUhliku.appendChild(jednotkaProcento);
    Element obsahZeleza = xmlDocument.createElement("obsah-zeleza");
    obsahZeleza.setTextContent("");
    Element jednotkaPrazdna = xmlDocument.createElement("jednotka");
    jednotkaPrazdna.setTextContent("");
    obsahZeleza.appendChild(jednotkaPrazdna);
    Element obsahSiry = xmlDocument.createElement("obsah-siry");
    obsahSiry.setTextContent("0.035");
    obsahSiry.appendChild(jednotkaProcento);
    Element obsahLegujicichPrvku = xmlDocument.createElement("obsah-legujicich-prvku");
    obsahLegujicichPrvku.setTextContent("");
    Element wolfram = xmlDocument.createElement("wolfram");
    wolfram.setTextContent("18");
    wolfram.appendChild(jednotkaProcento);
    Element chrom = xmlDocument.createElement("chrom");
    chrom.setTextContent("4.2");
    chrom.appendChild(jednotkaProcento);
    obsahLegujicichPrvku.appendChild(wolfram);
    obsahLegujicichPrvku.appendChild(chrom);
    chemickeVlastnosti.appendChild(obsahUhliku);
    chemickeVlastnosti.appendChild(obsahZeleza);
    chemickeVlastnosti.appendChild(obsahSiry);
    chemickeVlastnosti.appendChild(obsahLegujicichPrvku);
    material.appendChild(chemickeVlastnosti);
    Element mechanickeVlastnosti = xmlDocument.createElement("mechanicke-vlastnosti");
    Element mezPevnostiVTahu = xmlDocument.createElement("mez-pevnosti-v-tahu");
    Element jednotkaMPa = xmlDocument.createElement("jednotka");
    jednotkaMPa.setTextContent("MPa");
    Element mezKluzuVTahu = xmlDocument.createElement("mez-kluzu-v-tahu");
    Element mezUnavyVOhybu = xmlDocument.createElement("mez-unavy-v-ohybu");
    Element mezUnavyVKrutu = xmlDocument.createElement("mez-unavy-v-krutu");
    mezPevnostiVTahu.setTextContent("");
    mezPevnostiVTahu.appendChild(jednotkaMPa);
    mezKluzuVTahu.setTextContent("");
    mezKluzuVTahu.appendChild(jednotkaMPa);
    mezUnavyVOhybu.setTextContent("");
    mezUnavyVOhybu.appendChild(jednotkaMPa);
    mezUnavyVKrutu.setTextContent("");
    mezUnavyVKrutu.appendChild(jednotkaMPa);
    Element dovolenaNapeti = xmlDocument.createElement("dovolena-napeti");
    Element tah = xmlDocument.createElement("tah");
    Element statickyTah = xmlDocument.createElement("staticky");
    Element mijivyTah = xmlDocument.createElement("mijivy");
    Element stridavyTah = xmlDocument.createElement("stridavy");
    statickyTah.setAttribute("low", "");
    statickyTah.setAttribute("high", "");
    mijivyTah.setAttribute("low", "");
    mijivyTah.setAttribute("high", "");
    stridavyTah.setAttribute("low", "");
    stridavyTah.setAttribute("high", "");
    tah.appendChild(statickyTah);
    tah.appendChild(mijivyTah);
    tah.appendChild(stridavyTah);
    Element tlak = xmlDocument.createElement("tlak");
    Element statickyTlak = xmlDocument.createElement("staticky");
    Element mijivyTlak = xmlDocument.createElement("mijivy");
    Element stridavyTlak = xmlDocument.createElement("stridavy");
    statickyTlak.setAttribute("low", "");
    statickyTlak.setAttribute("high", "");
    mijivyTlak.setAttribute("low", "");
    mijivyTlak.setAttribute("high", "");
    stridavyTlak.setAttribute("low", "");
    stridavyTlak.setAttribute("high", "");
    tlak.appendChild(statickyTlak);
    tlak.appendChild(mijivyTlak);
    tlak.appendChild(stridavyTlak);
    Element ohyb = xmlDocument.createElement("ohyb");
    Element statickyOhyb = xmlDocument.createElement("staticky");
    Element mijivyOhyb = xmlDocument.createElement("mijivy");
    Element stridavyOhyb = xmlDocument.createElement("stridavy");
    statickyOhyb.setAttribute("low", "");
    statickyOhyb.setAttribute("high", "");
    mijivyOhyb.setAttribute("low", "");
    mijivyOhyb.setAttribute("high", "");
    stridavyOhyb.setAttribute("low", "");
    stridavyOhyb.setAttribute("high", "");
    ohyb.appendChild(statickyOhyb);
    ohyb.appendChild(mijivyOhyb);
    ohyb.appendChild(stridavyOhyb);
    Element krutSmyk = xmlDocument.createElement("krut-smyk");
    Element statickyKrut = xmlDocument.createElement("staticky");
    Element mijivyKrut = xmlDocument.createElement("mijivy");
    Element stridavyKrut = xmlDocument.createElement("stridavy");
    statickyKrut.setAttribute("low", "");
    statickyKrut.setAttribute("high", "");
    mijivyKrut.setAttribute("low", "");
    mijivyKrut.setAttribute("high", "");
    stridavyKrut.setAttribute("low", "");
    stridavyKrut.setAttribute("high", "");
    krutSmyk.appendChild(statickyKrut);
    krutSmyk.appendChild(mijivyKrut);
    krutSmyk.appendChild(stridavyKrut);
    dovolenaNapeti.appendChild(tah);
    dovolenaNapeti.appendChild(tlak);
    dovolenaNapeti.appendChild(ohyb);
    dovolenaNapeti.appendChild(krutSmyk);
    Element modulPruznosti = xmlDocument.createElement("modul-pruznosti");
    Element modulPruznostiVeSmyku = xmlDocument.createElement("modul-pruznosti-ve-smyku");
    Element poissonovoCislo = xmlDocument.createElement("poissonovo-cislo");
    Element hustota = xmlDocument.createElement("hustota");
    Element mernaTepelnaKapacita = xmlDocument.createElement("merna-tepelna-kapacita");
    Element teplotaTani = xmlDocument.createElement("teplota-tání");
    Element jednotkaHustota = xmlDocument.createElement("jednotka");
    Element jednotkaTeplotaTani = xmlDocument.createElement("jednotka");
    jednotkaHustota.setTextContent("kg/m^3");
    modulPruznosti.appendChild(jednotkaMPa);
    modulPruznostiVeSmyku.appendChild(jednotkaMPa);
    hustota.appendChild(jednotkaHustota);
    Element jednotkaMernaTepelnaKapacita = xmlDocument.createElement("jednotka");
    jednotkaMernaTepelnaKapacita.setTextContent("J*kg^-1*K^-1");
    mernaTepelnaKapacita.appendChild(jednotkaMernaTepelnaKapacita);
    jednotkaTeplotaTani.setTextContent("C");
    teplotaTani.appendChild(jednotkaTeplotaTani);
    mechanickeVlastnosti.appendChild(mezPevnostiVTahu);
    mechanickeVlastnosti.appendChild(mezKluzuVTahu);
    mechanickeVlastnosti.appendChild(mezUnavyVOhybu);
    mechanickeVlastnosti.appendChild(mezUnavyVKrutu);
    mechanickeVlastnosti.appendChild(dovolenaNapeti);
    mechanickeVlastnosti.appendChild(modulPruznosti);
    mechanickeVlastnosti.appendChild(modulPruznostiVeSmyku);
    mechanickeVlastnosti.appendChild(poissonovoCislo);
    mechanickeVlastnosti.appendChild(hustota);
    mechanickeVlastnosti.appendChild(mernaTepelnaKapacita);
    mechanickeVlastnosti.appendChild(teplotaTani);
    Element popis = xmlDocument.createElement("popis");
    popis.setTextContent("Nástrojová ocel odolná vůči popuštění.");
    material.appendChild(mechanickeVlastnosti);
    material.appendChild(popis);
    Element materials;
    if (materialy.getLength() == 0){
            materials = xmlDocument.createElement("materialy");
            xmlDocument.getFirstChild().appendChild(materials);
        }else{
            materials = (Element)materialy.item(0);
        }
    materials.appendChild(material);
    
    // Mazani elementu s id ocel4
    
    NodeList materialy2 = xmlDocument.getElementsByTagName("material");
    Element material2;
    for(int i = materialy2.getLength()-1; i >= 0; --i){
        material2 = (Element) materialy2.item(i);
        if(material2.getAttribute("id").equals("ocel4")){
            material2.getParentNode().removeChild(material2);
        }
    }
    
  }

}