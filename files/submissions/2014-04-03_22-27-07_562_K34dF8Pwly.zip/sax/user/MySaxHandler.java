/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package user;

/**
 *
 * @author Josef Kiefmann
 */
import java.util.ArrayList;
import java.util.HashMap;
import org.xml.sax.*;
import org.xml.sax.ContentHandler;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;
public class MySaxHandler extends DefaultHandler{
    

    String jmenoMaterialu;
    Double min;
    Double max;
    
    ArrayList<String> nazvyOceli = new ArrayList<String>();
    ArrayList<Double> avgDovoleneNapetiVTahu = new ArrayList<Double>();
    
    int pocetOceli = 0;
    
    Double pevnostiSum = new Double(0);
    
    Double prumernaPevnostVTahu;
    
    boolean nazevOceli = false;
    boolean dovoleneNapeti = false;
    boolean mezPevnostiVTahu = false;
    boolean obsahUhliku = false;
    
    int pocetOceliMajicichViceUhliku = 0;
    
    private static final String INPUT_FILE = "data.xml";
    
    public static void main(String[] args) {

        try {
            XMLReader parser = XMLReaderFactory.createXMLReader();
            InputSource source = new InputSource(INPUT_FILE);
            parser.setContentHandler(new MySaxHandler());
            parser.parse(source);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException{
        if(nazevOceli == true){
            String nazev = new String("");
            int i;
            for(i = start; i < start+length; i++){
                nazev += chars[i];
            }
            nazvyOceli.add(nazev);
            nazevOceli = false;
        }
        if(mezPevnostiVTahu == true){
            String teplota = new String("");
            for(int i = start; i < start+length; i++){
                teplota += chars[i];
            }
            if(!teplota.equals("MPa")){
            pevnostiSum += Double.parseDouble(teplota);
            pocetOceli++;
            }
        }
        if(obsahUhliku == true){
            String uhlik = new String("");
            for(int i = start; i < start+length; i++){
                uhlik += chars[i];
            }
            if(!uhlik.equals("%") && !uhlik.isEmpty()){
                double nruhliku = Double.parseDouble(uhlik);
                if(nruhliku > 0.3){
                    pocetOceliMajicichViceUhliku++;
                }
            }
        }
    }
    
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException{
        if(localName.equals("oznaceni-CSN")) nazevOceli = true;
        if(localName.equals("tah")){
            dovoleneNapeti = true;
        }
        if(localName.equals("mez-pevnosti-v-tahu")){
            mezPevnostiVTahu = true;
        }
        if(localName.equals("staticky") & dovoleneNapeti == true){
            min = Double.parseDouble(atts.getValue("low"));
            max = Double.parseDouble(atts.getValue("high"));
            avgDovoleneNapetiVTahu.add((min+max)/2);
        }
        if(localName.equals("obsah-uhliku")){
            obsahUhliku = true;
        }
    }
    
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if(localName.equals("oznaceni-CSN")) nazevOceli = false;
        if(localName.equals("tah")) dovoleneNapeti = false;
        if(localName.equals("mez-pevnosti-v-tahu")) mezPevnostiVTahu = false;
        if(localName.equals("obsah-uhliku")) obsahUhliku = false;
    }
    
    @Override
    public void endDocument() throws SAXException{
        System.out.println("Stredni dovolena napeti v tahu u oceli");
        System.out.println("======================================");
        System.out.println("Oznaceni oceli            Hodnota[MPa]");
        System.out.println("--------------------------------------");
        for(int i = 0; i < nazvyOceli.size() && i < avgDovoleneNapetiVTahu.size(); i++){
            System.out.print(nazvyOceli.get(i));
            System.out.print("                    ");
            System.out.println(avgDovoleneNapetiVTahu.get(i));
        }
        System.out.println("======================================");
        System.out.println("======================================");
        prumernaPevnostVTahu = pevnostiSum/pocetOceli;
        System.out.println("Prumerna pevnost v tahu oceli: "+prumernaPevnostVTahu+" MPa");
        System.out.println("======================================");
        System.out.println("======================================");
        System.out.println("Pocet oceli majicich v�ce, jak 0.3% uhliku: "+pocetOceliMajicichViceUhliku);
        
    }
}