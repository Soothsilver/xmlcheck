package user;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;


public class MyDomTransformer {

    private static final String INPUT_FILE = "data.xml";
    private static final String OUTPUT_FILE = "data.out.xml";


    public void transform(Document doc) {
       //pridani dalsiho zakaznika
       NodeList customers = doc.getElementsByTagName("customers");
       Element cust =  doc.createElement("customer");
       cust.setAttribute("clientID", "_C212");
       Element fN = doc.createElement("firstName");
       fN.setTextContent("Karel");
       Element lN = doc.createElement("lastName");
       lN.setTextContent("Vomacka");
        Element dob = doc.createElement("dateOfBirth");
       dob.setAttribute("day", "9");
       dob.setAttribute("month", "6");
       dob.setAttribute("year", "1756");
      
       Element tn = doc.createElement("telephoneNumber");
       tn.setTextContent("6451561561564");
      
       Element email = doc.createElement("email");
       email.setTextContent("vomacka@tatarska.UHO");
       
        cust.appendChild(fN);
        cust.appendChild(lN);
        cust.appendChild(dob);
         cust.appendChild(tn);
       cust.appendChild(email);
       customers.item(0).appendChild(cust);
       
       //smazani filmu ktere nepodporuji 3d
       
       NodeList films = doc.getElementsByTagName("film");
       for (int i=0; i<films.getLength(); ++i)
       {           
           Boolean mazu = false;
           Node film = films.item(i);
           NodeList par =  film.getChildNodes();
           for (int k = 0; k<par.getLength();++k)
           {
               if (par.item(k).getNodeName().equals("sup3D"))
                   if (par.item(k).getAttributes().getLength()>=1 &&
                       par.item(k).getAttributes().item(0).getNodeValue().equals("false"))
                        mazu=true;
           }
           Node parent = film.getParentNode();
           if (mazu) parent.removeChild(film);
       }
       
    }
}
