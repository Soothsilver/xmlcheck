package user;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;


public class MySaxHandler extends DefaultHandler {

    // Helper variable to store location of the handled event
    Locator locator;
    int prumernaDelkaFilmu=0;
    int pocet = 0;
    int nejvetsiRating=0;
     int nejvetsiRating3D=0;
    String jmenoNejoblibenejsiho3DFilmu="";
    Boolean nacitamJmeno = false;
    Boolean sup3d = false;
    String Jmeno;
    int aktualniRating;
    
    

  
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    @Override
    public void startDocument() throws SAXException {
        // tady nic nehodlam delat protoze jsem lina
    }

    @Override
    public void endDocument() throws SAXException {
        // TODO zde vypisovat
        System.out.println("Prumerna delka filmu je "+Integer.toString(prumernaDelkaFilmu/pocet));
        System.out.println("Nejvetsi rating filmu je "+Integer.toString(nejvetsiRating));
        System.out.println("Film s podporou 3D s nejvetsim ratingem "+Integer.toString(nejvetsiRating3D)+ " je "+jmenoNejoblibenejsiho3DFilmu);
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if (localName.equals("film"))
        {
            Jmeno = "";
            nacitamJmeno = false;
            sup3d = false;
        }
        if (localName.equals("length"))
        {
            pocet++;
            prumernaDelkaFilmu += Integer.parseInt(atts.getValue("min"));
        }
        if (localName.equals("customersRating"))
        {
            aktualniRating = Integer.parseInt(atts.getValue("rating"));
            if (aktualniRating>nejvetsiRating) nejvetsiRating = aktualniRating;
        }
        if (localName.equals("name"))
        {
            Jmeno = "";
            nacitamJmeno = true;
        }
        if (localName.equals("sup3D"))
        {
             if (atts.getValue("support").equals("true")) sup3d = true;
             else sup3d = false;
        }
    }

   
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (localName.equals("name"))
        {
            nacitamJmeno = false;
        }
        if (localName.equals("film"))
        {
            if ((aktualniRating>nejvetsiRating3D) && sup3d)
            {
                nejvetsiRating3D=aktualniRating;
                jmenoNejoblibenejsiho3DFilmu = Jmeno;
            }
        }
    }

   
    
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        if (nacitamJmeno)
        {
            String pom = new String(chars);
            Jmeno = pom.substring(start,start+length);
        }
    }

    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

 
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

 
    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
        // ...
    }

   
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

   
  
    @Override
    public void skippedEntity(String name) throws SAXException {
        // ...
    }
}
