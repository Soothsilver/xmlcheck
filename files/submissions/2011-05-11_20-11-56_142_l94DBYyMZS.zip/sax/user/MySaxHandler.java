package user;

import java.util.Hashtable;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/*
*Zad�n�: Na konzoli vypsat seznam zam�stnanc� a ke ka�d�mu celkovou dobu, kterou vys�l�.
*Nejprve se do slovn�ku ulo�� postupn� seznam v�ech zam�stnanc� indexovyn�ch jejich id
*V�dy kdy� se pot� na�te id ve vys�l�n�, do pomocn�ch prom�nn�ch se ulo�� �asy startu a konce vys�l�n� a id vys�laj�c�ho
*Pomoc� pomocn�ch prom�nn�ch se do slovn�ku p�i�te doba vys�l�n� spr�vn�mu zam�stnanci
*Pop�e�ten� dokumentu se slovn�k vyp�e na konzoli
*/
public class MySaxHandler extends DefaultHandler {

    
    Locator locator;
    //Akumul�tor pro �ten� textu
    StringBuffer accumulator = new StringBuffer();
    //T��da reprezentuj�c� zam�stnance
    class zamestnanec
    {
    	String jmeno;
    	Integer pocet_hodin = 0;
    	Integer pocet_minut = 0;
    }
    //Pomocn� prom�nn� nesouc� aktu�ln� �daje
    String actId = null;
    String actName = null;
    String actStart = null;
    Hashtable slovnik = new Hashtable();
    
    
    
   
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    
    public void startDocument() throws SAXException {
       
    }
    
    public void endDocument() throws SAXException {
       //Vyps�n� v�ech z�znam� ze slovn�ku 
       for(int i=0;i<slovnik.size();i++)
       {
    	   String a = (String) slovnik.keySet().toArray()[i];
    	   String name = ((zamestnanec)slovnik.get(a)).jmeno;
    	   String time = ((zamestnanec)slovnik.get(a)).pocet_hodin.toString();
    	   time = time + "h ";
    	   time = time + ((zamestnanec)slovnik.get(a)).pocet_minut.toString();
    	   System.out.println(name +" "+ time+"min");
       }        
    }
    
    
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException 
    {
    	//Po��te�n� elementy
        if(localName.equals("zamestnanec")|| localName.equals("vysilani") )
        {
        	String id = atts.getValue(0);
        	actId = id;       	
        }
        if(localName.equals("jmeno") || localName.equals("prijmeni")|| localName.equals("od")|| localName.equals("do"))
        {
        	accumulator.setLength(0);        	
        }       

    }
    
    public void endElement(String uri, String localName, String qName) throws SAXException 
    {
    	if(localName.equals("jmeno"))
    	{
    		actName = accumulator.toString().trim();    		
    	}
    	else if(localName.equals("prijmeni"))
    	{
    		zamestnanec novacek = new zamestnanec();
    		novacek.jmeno = actName + " " + accumulator.toString().trim();
    		slovnik.put(actId, novacek);
    	}
    	else if(localName.equals("od"))
    	{
    		actStart = accumulator.toString().trim();    	
    	}
    	//V�po�et �asu, kter� vys�l�n� zabere, Po��t� se i s p�esahem(do 23h) do dal��ho dne
    	else if(localName.equals("do"))
    	{
    		String start = actStart;
    		String end = accumulator.toString().trim();
    		Integer start_hour = new Integer(start.split(":")[0]);
    		Integer start_minute = new Integer(start.split(":")[1]);
    		Integer end_hour = new Integer(end.split(":")[0]);
    		Integer end_minute = new Integer(end.split(":")[1]);
    		if(start_hour > end_hour)
    		{    			
    			start_hour -= 24;
    		}
    		Integer hours = end_hour - start_hour;
    		if(start_minute > end_minute)
    		{
    			end_minute += 60;
    			hours -=1;
    		}
    		Integer minutes = end_minute-start_minute;
    		((zamestnanec)slovnik.get(actId)).pocet_hodin += hours;
    		((zamestnanec)slovnik.get(actId)).pocet_minut += minutes;
    	}

    }
    
    
    public void characters(char[] ch, int start, int length) throws SAXException {
    	//Na�ten� textu
    	accumulator.append(ch, start, length);        
    }
    
    
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
    }

    
    public void endPrefixMapping(String prefix) throws SAXException {
    
    }

    
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
    }

   
    public void processingInstruction(String target, String data) throws SAXException {
         
    }

      
    public void skippedEntity(String name) throws SAXException {
    
    }
}