package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
/*Zad�n�: pomoc� rozhran� DOM transformovat dokument tak, �e element fotka bude nahrazen atributem u zam�stnance
 *Je pot�eba br�t v potaz, �e se jedn� i o atribut i o hodnotu elementu 
 *Nejprve je z�sk�n seznam zam�stnac� a pro ka�d�ho z nich je zkontrolov�n posledn� element
 *Pokud element nen� fotka, znamen� to �e nen� zad�na
 *D�le se ulo�� hodnoty cesty(z atributu) a stavu(z hodnoty) a jsou n�sledn� p�id�ny jako nov� atributy
 *Pokud nejsou nalezeny jsou nahrazeny explicitn�mi 
 */

public class MyDomTransformer 
{
	public void transform (Document xmlDocument) 
	{
		String actFotoPath;
		String actFotoState;
		//Na�ten� zam�stnanc�
		NodeList zamestnanci = xmlDocument.getElementsByTagName("zamestnanec");
		for(int i=0;i<zamestnanci.getLength();i++)
		{
			Node zamestnanec = zamestnanci.item(i);
			NodeList potomci = zamestnanec.getChildNodes();
			//Vybr�n� posledn�ho podelementu
			Node posledni = potomci.item(potomci.getLength()-2);			
			//Element je fotka
			if(posledni.getNodeName().equals("fotka"))
			{
				//Kontrola atributu
				if(posledni.getAttributes().getLength() == 1)
				{
					actFotoPath = posledni.getAttributes().item(0).getNodeValue();
				}
				else
				{
					actFotoPath = "nezad�na";					
				}
				//Kontrola hodnoty
				if(!posledni.getTextContent().equals(""))
				{					
					actFotoState = posledni.getTextContent();
				}
				else
				{
					actFotoState = "nezad�n";				
				}
				zamestnanec.removeChild(posledni);
				}
			else
			{
				actFotoPath = "nezad�na";
				actFotoState = "nezad�n";
			}
			Element a =(Element)zamestnanec;
			a.setAttribute("fotka_zdroj", actFotoPath);
			a.setAttribute("fotka_stav", actFotoState);
		}
	}
}