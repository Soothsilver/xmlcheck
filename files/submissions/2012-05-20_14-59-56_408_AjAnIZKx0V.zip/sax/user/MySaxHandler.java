/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;


import java.util.Set;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 *
 * @author Tuan Anh
 * 
 */


/*
 *Moje tema  je ze program  vypise  nazev filmy a pocet elementu a atributu 
 */
public class MySaxHandler extends DefaultHandler {

    public static void main(String[] args) {
        String sourcePath = "data.xml";
        try {
            XMLReader parser = XMLReaderFactory.createXMLReader();


            InputSource source = new InputSource(sourcePath);


            parser.setContentHandler(new MujContentHandler());

            parser.parse(source);

        } catch (Exception e) {
        }
    }
}

class MujContentHandler implements ContentHandler {

    Locator locator;
    int pocetElementu;
    int pocetAtributu;
    Set nazevFilmu;
    Set counterNazevFilmu;
    int pocetFilmu;
   

    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Obsluha udĂˇlosti "zaÄŤĂˇtek dokumentu"
     */
    public void startDocument() throws SAXException {
        System.out.println("--------------------------------------");
        System.out.println("---------------SAX--------------------");
        System.out.println("--------------filmy-------------------");
    }

    /**
     * Obsluha udĂˇlosti "konec dokumentu"
     */
    public void endDocument() throws SAXException {
        System.out.println("--------------------------------------");
        System.out.println("pocet elementu " + pocetElementu);
        System.out.println("pocet atributu " + pocetAtributu);



    }

    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        pocetElementu++;
        pocetAtributu += atts.getLength();
    
//        if (localName.equals("film")) {
//            int attrIndex = atts.getIndex("idFilm");
//            String nazev = atts.getValue(attrIndex);
//            if (!nazevFilmu.add(nazev)) {
//                if (counterNazevFilmu.add(nazev)) {
//
//                    pocetFilmu++;
//                }
//
//            }
//
//        }


        for (int i = 0; i < atts.getLength(); i++) {
           
            System.out.println(atts.getQName(i) + ": " + atts.getValue(i));
            
        }

    }

    public void endElement(String uri, String localName, String qName) throws SAXException {
    }

    public void characters(char[] ch, int start, int length) throws SAXException {
    }

    public void startPrefixMapping(String prefix, String uri) throws SAXException {
    }

    public void endPrefixMapping(String prefix) throws SAXException {
    }

    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
    }

    public void processingInstruction(String target, String data) throws SAXException {
    }

    public void skippedEntity(String name) throws SAXException {
    }
}