/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

/**
 * moje tema ,ze smaze cely obsah filmu a prida kazde filmu element rok k tomu
 * prida zakaznikovi rodne cislo
 *
 * @author Tuan Anh
 */
public class MyDomTransformer {

    private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "data.out.xml";

    public static void main(String[] args) {

        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setValidating(false);
            DocumentBuilder builder = dbf.newDocumentBuilder();
            Document doc = builder.parse(VSTUPNI_SOUBOR);
            MyDomTransformer mdt = new MyDomTransformer();
            mdt.transform(doc);
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer writer = tf.newTransformer();
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


        } catch (Exception e) {

            e.printStackTrace();

        }
    }

    public void transform(Document doc) {

        //smaze cele obsahu filmy   
        NodeList obsah = doc.getElementsByTagName("film");
        for (int i = 0; i < obsah.getLength(); i++) {
            Element k = (Element) obsah.item(i);

            k.removeChild(k.getElementsByTagName("obsah").item(0));
        }

        //prida element rok do kazdeho filmu
        NodeList pridatRok = doc.getElementsByTagName("film");
        for (int i = 0; i < pridatRok.getLength(); i++) {
            Element film = (Element) pridatRok.item(i);

            Element name = doc.createElement("rok");
            film.appendChild(name);

        }
        //pridat ke kazdem zakazniku rodne cislo
        NodeList zakaznik = doc.getElementsByTagName("zakaznik");
        for (int i = 0; i < zakaznik.getLength(); i++) {
            Element zakaz = (Element) zakaznik.item(i);
            zakaz.setAttribute("rodne_cislo", "234" + i);

        }





    }
}
