   package user;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

 class Movie {
       private String name;
       private int year;
       private int price;
       private String id;

       public Movie() {
       }

       public Movie(String name, int year, int price, String id) {
              this.name = name;
              this.year = year;
              this.price = price;
              this.id = id;
       }
       /* name */
      public String getName() {
              return name;
       }
       public void setName(String name) {
              this.name = name;
       }
        /* year */
       public int getYear() {
              return year;
       }
       public void setYear(int year) {
              this.year = year;
       }
        /* price */
       public int getPrice() {
              return price;
       }
       public void setPrice(int price) {
              this.price = price;
       }
       /* id */
       public String getId() {
              return id;
       }
       public void setId(String id) {
              this.id = id;
       }
      void setId(int parseInt) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }    

       public String toString() {
              StringBuffer sb = new StringBuffer();
              sb.append("Movie Details - ");
              sb.append("Name:" + getName());
              sb.append(", ");
              sb.append("Year:" + getYear());
              sb.append(", ");
              sb.append("Price:" + getPrice());
              sb.append(", ");
              sb.append("Id:" + getId());
              sb.append(".");

              return sb.toString();
       }
}

public class MySaxHandler extends DefaultHandler
{
       private Movie mov;
       private String temp;
       private ArrayList<Movie> movList = new ArrayList<Movie>();
       private int Prices = 0;
       private int Expensive = 0;
       private int aPrice;
       private int Count = 0;

       /** The main method sets things up for parsing */
       public static void main(String[] args) throws IOException, SAXException,
                     ParserConfigurationException {
             
              SAXParserFactory spfac = SAXParserFactory.newInstance();

              SAXParser sp = spfac.newSAXParser();

              MySaxHandler handler = new MySaxHandler();

              sp.parse("data.xml", handler);
             
              handler.readList();

       }


 
       public void characters(char[] buffer, int start, int length) {
              temp = new String(buffer, start, length);
       }
      
       public void startElement(String uri, String localName,
                     String qName, Attributes attributes) throws SAXException {
              temp = "";
              if (qName.equalsIgnoreCase("Movie")) {
                     mov = new Movie();
                     mov.setId(attributes.getValue("id"));
                     Count += 1; // scitam filmy
              }
       }   
      
       public void endElement(String uri, String localName, String qName)
                     throws SAXException {

              if (qName.equalsIgnoreCase("Movie")) {             
                     movList.add(mov);     // pridavam do pole         
              }
              else if (qName.equalsIgnoreCase("Name")) {
                     mov.setName(temp);
              } 
              else if (qName.equalsIgnoreCase("Id")) {
                     mov.setId(Integer.parseInt(temp));
              } 
              else if (qName.equalsIgnoreCase("Price")) {
               int price = Integer.parseInt(temp);
               Prices += price;  // kolik stoji vsechny filmy dohromady
               if(price > 120)
               {
                Expensive += 1; // scitam pocet filmu s cenou nad 120,-
               }             
              mov.setPrice(price);
              }
               else if (qName.equalsIgnoreCase("Year")) {
               int year = Integer.parseInt(temp);
               mov.setYear(year);
              }       
       }

       private void readList() {
              aPrice = Prices / Count; // spocitam prumernou cenu za film
              
              System.out.println();
              System.out.println("Pocet vsech filmu v databazi: " + movList.size()  + "Ks..");
              System.out.println("Pocet vsech filmu s cenou nad 120 Kč: " + Expensive  + "Ks..");
              System.out.println("Celkova cena za filmy: " + Prices  + "Kč.");
              System.out.println("Prumerna cena za 1 film: " + aPrice  + "Kč.");

              System.out.println("Cely seznam filmu jejich atributu:"); // vypisu jednotlive filmy
              Iterator<Movie> it = movList.iterator();
              while (it.hasNext()) {
                     System.out.println(it.next().toString());
              }
       }
      
}
