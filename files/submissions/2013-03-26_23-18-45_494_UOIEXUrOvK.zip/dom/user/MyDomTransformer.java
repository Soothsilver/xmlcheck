package user;

import org.w3c.dom.Document;

/***/
import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;




/**
 * ASSIGNMENT: Update document to be able to transform input XML document to
 * output document by actions mentioned in comments of processTree method.
 */
public class MyDomTransformer {

    private static final String INPUT_FILE = "data.xml";
    private static final String OUTPUT_FILE = "data.out.xml";

    /**
     * Main method
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {

        try {

            // DocumentBuilderFactory creates DOM parsers
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            // We don't want to validate file
            dbf.setValidating(false);

            // Creating of DOM parser instance
            DocumentBuilder builder = dbf.newDocumentBuilder();

            // Parser processes input file and creates a DOM tree of objects
            Document doc = builder.parse(INPUT_FILE);

            // DOM tree processing
            processTree(doc);

            // TransformerFactory creates an object for DOM serialization
            TransformerFactory tf = TransformerFactory.newInstance();

            // Transformer serializes DOM tree
            Transformer writer = tf.newTransformer();

            // Setting of output file encoding
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            // Run transformation of DOM tree to XML document
            writer.transform(new DOMSource(doc), new StreamResult(new File(OUTPUT_FILE)));


        } catch (Exception e) {

            e.printStackTrace();

        }
    }

    /**
     * Process document tree
     *
     * @param doc Document to be parsed
     */
    private static void processTree(Document doc) {
    
        //presouvam element length do atributu
  NodeList length = doc.getElementsByTagName("length");
  
for (int i=0; i <length.getLength(); ++i){
    Node item = length.item(i);
    Element movie = (Element)item.getParentNode();
    Attr a = doc.createAttribute(item.getNodeName());
    a.setValue(item.getTextContent()); 
    movie.setAttributeNode(a);  
    movie.removeChild(item);
    i--;
    }
     //presouvam element category do atributu
 NodeList category = doc.getElementsByTagName("category");
 
for (int i=0; i <category.getLength(); ++i){
    Node item = category.item(i);
    Element movie = (Element)item.getParentNode();
    Attr a = doc.createAttribute(item.getNodeName());
    a.setValue(item.getTextContent());
    movie.setAttributeNode(a);
    movie.removeChild(item);
    i--;
    }
    // mazu vsechny filmy s cenou pod 100,-
 NodeList price = doc.getElementsByTagName("price");
 
for (int i=0; i <price.getLength(); ++i){        
    Node priceitem = price.item(i);
    Element movie = (Element)priceitem.getParentNode();  
      int priceint = Integer.parseInt(priceitem.getTextContent());
         if (priceint < 100)
    {
       doc.removeChild(movie);
    }
    } 
  }
    
}
    
