/*
 * Lukas Dolezal
 * 
 * Aktivity se presunou do svych kategorii do podelementu aktivoty.
 * Aktivitam se prida ID jako atribut aktivitaId
 * V casovych oknech se seznam kategorii nahradi seznamem aktivit. Pokud je referencovana kateogrie
 * pouzita pouze v tom jednom okne, prenesou se kompletni definice aktivit a kategorie se smaze.
 * okna, obsahujici referenci na okna. ktera ma
 * Pravidla datumu v ramci okna budou prevedena na seznam jednotlivych dnu
spadajicich maximalne pod aktualni rok. 
 * 
 */
package user;

/**
 *
 * @author dolezal3
 */
import java.util.ArrayList;
import org.w3c.dom.*;
public class MyDomTransformer { 

    public void transform (Document xmlDocument) {
        
        // nejprve oIDckovt aktivity
        // a presunout pod kategorie
        presunoutAktivityPodKategorieAPridatId(xmlDocument);
        
        // odstranit element aktivtity - vsechny jsou presunute v kategoriich (jinak by nejaka musela odporovat
        // schematu a nemit validni referenci )
        odstranitAktivityElement(xmlDocument);
        
        // pretransformovat reference na kategorii v oknech na reference na aktivity
        transformaceOken(xmlDocument);
        
        
        
    } 
    
    /**
     * Odstrani cely element /rozrazovani/aktivity
     * @param doc 
     */
    private void odstranitAktivityElement(Document doc)
    {
        NodeList aktivity = doc.getElementsByTagName("aktivity");
        for (int i = 0; i < aktivity.getLength(); i++) {
            if (aktivity.item(i).getParentNode().getNodeName().equals("rozvrhovani")) {
                
                aktivity.item(i).getParentNode().removeChild(aktivity.item(i));
                return;
            }
                
        }
    }
    
    /**
     * Prida ID podle poradi aktivitam ve tvaru "aktivita-##".
     * Aktivity presune pod element "aktivity" do prislusnych elementu kategorii
     * @param xmlDocument 
     */
    private void presunoutAktivityPodKategorieAPridatId(Document xmlDocument) {
        NodeList aktivity = xmlDocument.getElementsByTagName("aktivita");
        int aktivitaId = 0; // nemohu pouzit i ve foru, protoze tam testuji jeste jestli je to ten spravny element
        for (int i = 0; i < aktivity.getLength(); i++) {
            if (aktivity.item(i).getParentNode().getNodeName().equals("aktivity"))
            {
                ((Element)aktivity.item(i)).setAttribute("aktivitaId", "aktivita-" + String.valueOf(aktivitaId++));
            
                // prehodit rovnou do prislusne kategorie podelementu aktivity
                // zjistit ID kategorie
                presunoutAktivituPodAktivityKategorie((Element)aktivity.item(i));
            }
        }        
    }
    
    /**
     * Presune element aktivita pod element aktivity kategorie s id, ktere je v aktivite
     * @param aktivita 
     */
    private void presunoutAktivituPodAktivityKategorie(Element aktivita)
    {
        NodeList kategorieAktivity = (aktivita).getElementsByTagName("kategorie");
        if (kategorieAktivity.getLength() > 0) {
            Element katElAktivity = (Element)kategorieAktivity.item(0);

            Element aktivityKategorie =
                    aktivityKategorieId(aktivita.getOwnerDocument(), katElAktivity.getAttribute("kategorieId"));

            if (aktivityKategorie != null)
            {
                // presunout aktivitu pod aktivity kategorie
                // smazat element kategorie
                katElAktivity.getParentNode().removeChild(katElAktivity);

                // zkopirovat do aktivit kategorie
                Node kopieAktivity = aktivita.cloneNode(true);
                aktivityKategorie.appendChild(kopieAktivity);

                // smazat puvodni
                aktivita.getParentNode().removeChild(aktivita);
            }
        }
    }

    private void oknoTransformKategorieNaAktivity(ArrayList<InfoKategorie> kategorieOkna, Element aktivity) {
        
        // najde kategorie, ktere patri do okna
        // pokud je kategorie jen v tomto okne, prenese aktivity a kategorii smaze
        // pokud neni, prenese reference na aktivity v kategorii
        
        // vyhodit atribut mode
        aktivity.removeAttribute("mode");
        
        // vyhodit obsah referenci
        aktivity.setTextContent("");
        
        for (int i = 0; i < kategorieOkna.size(); i++) {
            InfoKategorie info = kategorieOkna.get(i);
            
            if (info.patriDoOkna(((Element)aktivity.getParentNode()).getAttribute("id")))
            {
                // projit aktivity v referencni kategorie a bud premistit nebo vytvorit referenci
                
                Element kategorieAktivity = (Element)info.node.getElementsByTagName("aktivity").item(0);
                NodeList listAktivitKategorie = kategorieAktivity.getElementsByTagName("aktivita");

                for (int j = 0; j < listAktivitKategorie.getLength(); j++) {
                    
                     // je kategorie pouze v tomto okne nebo i jinde
                    if (info.oknaId.size() == 1)
                    {
                        // presunout aktivitu
                        Element aktivita = (Element)listAktivitKategorie.item(j);
                       
                        // vlozit do aktivit okna
                        aktivity.appendChild(aktivita.cloneNode(true));
                    }
                    else {
                        // vytvorit referenci na aktivity uvnitr kategorie
                    
                        String aktivitaId = ((Element)listAktivitKategorie.item(j)).getAttribute("aktivitaId");

                        Element refAktivita = aktivity.getOwnerDocument().createElement("aktivita");
                        refAktivita.setAttribute("aktivitaId", aktivitaId);

                        aktivity.appendChild(refAktivita);
                    }
                }
                
                if (info.oknaId.size() == 1)
                {
                    // smazat celou kategorii, aktivity jsou presunuty
                    info.node.getParentNode().removeChild(info.node);
                }
            }
                
            
        } // foreach kategorie info
        
    }

    
    
    private void oknoTransformPravidlaNaDny(Element pravidla) {
        // osekavaci metoda - vytvori seznam vsech dnu, pak nacita
        // pravidla a odebira podle pravidel
        
        
        ArrayList<String> data = new ArrayList<String>();
        
        // TODO vytvorit seznam datumu celeho roku a orezavat podle pravidel
        
        
        // vytvorit element datumu
        Element dnyEl =  pravidla.getOwnerDocument().createElement("dny");
        for (int i = 0; i < data.size(); i++) {
            Element den = pravidla.getOwnerDocument().createElement("den");
            den.setTextContent(data.get(i));
            
            dnyEl.appendChild(den);
        }
        
        // vlozit dny
        pravidla.getParentNode().insertBefore(dnyEl, pravidla);
        
        // odstranit puvodni pravidla
        pravidla.getParentNode().removeChild(pravidla);
        
    }
    
    
    
    class InfoKategorie {
        public String id;
        public Element node;
        public ArrayList<String> oknaId = new ArrayList<String>();
        
        public boolean patriDoOkna(String idOkna) {
            
            return oknaId.contains(idOkna);
        }
    }
    
    
    private ArrayList<InfoKategorie> nacistPrislusnostKategoriiDoOken(Document doc)
    {
        ArrayList<InfoKategorie> kategorieOkna = new ArrayList<InfoKategorie>();
        
        // nacist vsechny kategorie
         NodeList kategorie = doc.getElementsByTagName("kategorie");
         for (int i = 0; i < kategorie.getLength(); i++) {
            if (kategorie.item(i).getParentNode().getNodeName().equals("kategorieAktivit"))
            {
                InfoKategorie k = new InfoKategorie();
                k.id = ((Element)kategorie.item(i)).getAttribute("id");
                k.node  = (Element)kategorie.item(i);
                kategorieOkna.add(k);
            }
        }
         
         // projit okna a naplnit info o oknech v kategoriich
         NodeList aktivityOkna = doc.getElementsByTagName("aktivity");
         for (int i = 0; i < aktivityOkna.getLength(); i++) {
            if (aktivityOkna.item(i).getParentNode().getNodeName().equals("okno"))
            {
                Element aktivityOknaEl = (Element)aktivityOkna.item(i);
                
                 // projit seznam referenci na kategorii id a pridat okno do relevantnich kategorii v informacnim listu
                NodeList aktivityKategorie = aktivityOknaEl.getElementsByTagName("kategorie");
                
                ArrayList<String> referenceKategorii = new ArrayList<String>();
                
                for (int j = 0; j < aktivityKategorie.getLength(); j++) {
                     
                    String kategorieId = ((Element)aktivityKategorie.item(j)).getAttribute("kategorieId");
                    referenceKategorii.add(kategorieId);

                } // forach reference kategorie v okne
                
                for (int k = 0; k < kategorieOkna.size(); k++) {
                    if ((aktivityOknaEl.getAttribute("mode").equals("including")
                            && referenceKategorii.contains(kategorieOkna.get(k).id)) || 
                        (aktivityOknaEl.getAttribute("mode").equals("excluding")
                            && !referenceKategorii.contains(kategorieOkna.get(k).id)))
                    {
                        // pridat okno ke kategorii
                        kategorieOkna.get(k).oknaId.add(
                                ((Element)aktivityOknaEl.getParentNode()).getAttribute("id"));
                    } // if kategorie sedi
                } // foreach kategorie
            } // foreach okna/aktivity
        }
         
         return kategorieOkna;
        
    }
    
    /**
     * Vrati element aktivit pod kategorii daneho id. pokud element neexistuje, vytvori ho
     * @param idKategorie
     * @return Element aktivit pod kategorii, null, pokud id kategorie neexisutju
     */
    private Element aktivityKategorieId(Document doc, String idKategorie)
    {
         NodeList kategorie = doc.getElementsByTagName("kategorie");
         for (int i = 0; i < kategorie.getLength(); i++) {
            if (kategorie.item(i).getParentNode().getNodeName().equals("kategorieAktivit"))
            {
                if (((Element)kategorie.item(i)).getAttribute("id").equals(idKategorie))
                {
                    // mame pozadovanou kateogorii
                    Element kat = (Element)kategorie.item(i);
                    
                    NodeList aktivity = kat.getElementsByTagName("aktivity");
                    // vytvorit aktivity, pokud nejsou
                    if (aktivity.getLength() > 0)
                    {
                        return (Element)aktivity.item(0);
                    }
                    else 
                    {
                        Element akt = doc.createElement("aktivity");
                        kat.appendChild(akt);
                        return akt;
                    }
                    
                }
            }
         }
         // kategorie s danym id neexisutje
         return null;
    }

    /**
     * Transformuje okna - kategorie na aktivity a pravidla na seznam datumu
     * 
     * @param xmlDocument 
     */
    private void transformaceOken(Document xmlDocument) {
        
        // potreba pro transformaci aktivit uvnitr okna.
        // but je okno jedine pro danou kategorii, pak se prenese kompletni aktivity a kategorie se smaze
        // nebo neni jedine a tak se necha jen reference
        ArrayList<InfoKategorie> kategorieOkna = nacistPrislusnostKategoriiDoOken(xmlDocument);
        
        // pro kazde okno
        NodeList oknaParent = xmlDocument.getElementsByTagName("casovaokna");
        if (oknaParent.getLength() > 0){
            Element oknaEl = (Element)oknaParent.item(0);
            
            NodeList okna = oknaEl.getElementsByTagName("okno");
            for (int i = 0; i < okna.getLength(); i++) {
                
                Element oknoEl = (Element)okna.item(i);
                
                // je lepsi osetrovat ze neni, kdyz je schema povine, ze je? asi lepsi vyhodit vyjimku nez ignorovat a tvarit se ok...
                Element aktivity = (Element)oknoEl.getElementsByTagName("aktivity").item(0);
                oknoTransformKategorieNaAktivity(kategorieOkna, aktivity);

                Element pravidla = (Element)oknoEl.getElementsByTagName("pravidla").item(0);
                oknoTransformPravidlaNaDny(pravidla);
                
            }
        }
            
    }
} 