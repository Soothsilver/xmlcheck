package user;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

/**
 * 
 * @author Filip
 * Ukolem tohoto SAXu je ze zadaneho XML dokumentu vytvorit statistiku.
 * Zeznamenanymi udaji necht jsou: Celkovy pocet elementu, celkovy pocet attributu,
 * maximalni delka jmena elementu (a jeho vypsani), prumerna delka jmena atributu
 * a maximalni delka dokumentu. Plus vypis nejhloubeji polozeneho elementu(v pripade shody,vypise posledni nalezeny)
 */
public class MySaxHandler extends DefaultHandler {


	private int pocetElementu;
	private int pocetAttributu;
	private int nameTotal;
	private String maxName;
	private int maxNameLen;
	private int depth;
	private int maxDepth;
	private String deepestElement;

	public MySaxHandler(){
		try {
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
	}

	@Override
	public void startDocument() throws SAXException {
		System.out.println("==STATISTIKA PRO ZADANY DOKUMENT==");
	}
	

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {
		if(++depth>maxDepth){
			maxDepth=depth;
			deepestElement=qName;
		}
		nameTotal+=qName.length();
		if(qName.length()>maxNameLen){
			maxNameLen=qName.length();
			maxName=qName;
		}
		pocetElementu++;
        pocetAttributu += attributes.getLength();
	}
	
	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		depth--;
	}
	
	

	@Override
	public void endDocument() throws SAXException {
		System.out.println("Pocet elementu:"+pocetElementu);
		System.out.println("Pocet atributu:"+pocetAttributu);
		System.out.println("Maxilani delka jmena elementu: "+maxNameLen+"("+maxName+")");
		int prumer=nameTotal/pocetElementu;
		System.out.println("Prumerna delka jmena elementu: "+prumer);
		System.out.println("Maximalni hloubka(zanorenost) dokumentu je: "+maxDepth
				+"   a nejhlubsim elementem je: "+deepestElement);
		
	}

	
	
	public static void main(String[] args) {
        
        String filename = "data.xml";
        
        try {            
            SAXParserFactory spfactory = SAXParserFactory.newInstance();
            spfactory.setValidating(false);
            
            SAXParser saxparser = spfactory.newSAXParser();
            
            XMLReader xmlreader = saxparser.getXMLReader();
            
            xmlreader.setContentHandler(new MySaxHandler());
            xmlreader.setErrorHandler(new MySaxHandler());
            
            InputSource source = new InputSource(filename);
            xmlreader.parse(source);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

	
}

