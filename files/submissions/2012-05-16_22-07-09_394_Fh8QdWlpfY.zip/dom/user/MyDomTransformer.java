package user;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.NodeList;

/**
 * @author Filip
 * DOM provede nasledujici zmeny v XML dokumentu: U vsech uvedenych hercu smaze jeji atribut pohlavi.
 * Nasledne vytvori element pohlavi a do nej vsune hodnotu ze stareho elementu.
 * Dale predpokladejme, ze v souboru jiz nechceme vest detailnejsi informace o reziserech. DOM je najde
 * a smaze vsechny jejich podelementy.
 * A nakonec u vsech filmu, ktere nemaji uveden rozpocet,vytvori tento element a naplni ho hodnotou "hodnota
 * neni znama"
 */
public class MyDomTransformer {
	
	private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "data.out.xml";

    public static void main(String[] args) {
        
    try{
    	DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setValidating(false);
        DocumentBuilder builder = dbf.newDocumentBuilder();
        Document doc = builder.parse(VSTUPNI_SOUBOR);
        MyDomTransformer mdt = new MyDomTransformer();
        mdt.transform(doc);
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer writer = tf.newTransformer();
        writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
        writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


    } catch (Exception e) {
        System.out.println("ERROR!");
        e.printStackTrace();
            
        }
    }
	
	public void transform(Document doc) {
		NodeList herci = doc.getElementsByTagName("herec");
		for (int i = 0; i < herci.getLength(); i++) {
			Element herec = (Element) herci.item(i);

			//Smaze atribut pohlavi a ulozi si jeho hodnotu
			NamedNodeMap atts = herec.getAttributes();
			String pohlavi=atts.getNamedItem("pohlavi").getNodeValue();
			herec.removeAttribute("pohlavi");
			
			//Vytvori element pohlavi, nastavi hodnotu a prilepi k herci
			Element pohlaviEl=doc.createElement("pohlavi");
			pohlaviEl.appendChild(doc.createTextNode(pohlavi));
			herec.appendChild(pohlaviEl);
			
			//Smaze vsechny podelementy(detske elementy)elementu reziser
			NodeList reziseri = doc.getElementsByTagName("reziser");
			for (int j = 0; j < reziseri.getLength(); j++) {
				Element reziser = (Element) reziseri.item(j);
			NodeList deti=reziser.getChildNodes();
			for(int k=0; k < deti.getLength(); k++){
				reziser.removeChild(deti.item(k));
			}
			
			//Najde filmy, u kterych nebyl uveden element rozpocet, vytvori ho a napni hodnotou "hodnota neni znama"
			NodeList filmy=doc.getElementsByTagName("film");
			for (int b = 0; b < filmy.getLength(); b++) {
				Element film=(Element)filmy.item(b);
				NodeList rozpocty=film.getElementsByTagName("rozpocet");
				if(rozpocty.getLength()==0){
					Element rozpocet=doc.createElement("rozpocet");
					rozpocet.appendChild(doc.createTextNode("hodnota neni znama"));
					film.appendChild(rozpocet);
				}
			}
		}
		
	}

	}
}