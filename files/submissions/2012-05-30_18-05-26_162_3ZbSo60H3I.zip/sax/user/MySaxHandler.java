/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;
import java.util.ArrayList;
/**
 * Vypise celkovy pocet elementu dokument, pocet ruznych elementu (tj. kolik existuje ruznych tagu) a maximalni hloubku dokumentu.
 * @author jan.tichy
 */
public class MySaxHandler extends DefaultHandler {
    
    int level = 0;
    int maxLevel = Integer.MIN_VALUE;
    int countElement = 0; 
    ArrayList<String> elementList = new ArrayList<String>();
    
    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) 
    {
        
        level++;
        if(maxLevel < level) maxLevel = level;
        countElement++;   
        if(!elementList.contains(localName))
        {
            elementList.add(localName);
        }
    }
    @Override
    public void endElement(String uri, String localName, String qName)
    {
        level--;
    }
    @Override
    public void endDocument() 
    {
        System.out.println("Celkovy pocet elementu : " + countElement);
        System.out.println("Pocet ruznych elementu : " + elementList.size());
        System.out.println("Maximalni hloubka dokumentu : " + maxLevel);
    }
}
