/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
/**
 *
 * @author jan.tichy
 */
public class MyDomTransformer {
    /*
     * Elementy, ktere jsou ve vetsi hloubce nez 2 vymaze.
     * U kazdeho elementu prevrati poradi jeho deti.
     */
    public void transform (Document xmlDocument) {
        processTree(xmlDocument);
    }
    
    private void runChildrenCutter(Node node, int depth, int cutDepth)
    {
         
        NodeList nodeList = node.getChildNodes();        
        for(int i = 0; i < nodeList.getLength(); i++)
        {
            runChildrenCutter(nodeList.item(i), depth + 1, cutDepth);
        }
        if(depth > cutDepth)
        {
            while(node.hasChildNodes())
                node.removeChild(node.getFirstChild());
        }
    }
    
    private void cutter(Document doc, int cutDepth)
    {
        NodeList nodeList = doc.getChildNodes();
        for(int i = 0; i < nodeList.getLength(); i++)
        {
            runChildrenCutter(nodeList.item(i), 1, 2);
        }
    }
    
    private void runChildrenReverser(Node node)
    {
        
        Node[] array = new Node[node.getChildNodes().getLength()];
        int i = 0;
        while(node.hasChildNodes())
        {            
            array[i] = node.getLastChild();
            node.removeChild(array[i]);
            i++;
        }
        for(int j = 0; j < i; j++)
            node.appendChild(array[j]);
        
        for(int j = 0; j < i; j++)
            runChildrenReverser(array[j]);
        
        
    }
    
    private void reverser(Document doc)
    {
        NodeList nodeList = doc.getChildNodes();
        for(int i = 0; i < nodeList.getLength(); i++)
        {
            runChildrenReverser(nodeList.item(i));
        }
    }
    
    
    private void processTree(Document doc) {
        cutter(doc, 2);
        reverser(doc);
    }
}
