package user;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.w3c.dom.*; 

public class MyDomTransformer { 
	public void transform (Document doc) { 
		
		// 1. add new movie
		Element movie = doc.createElement("movie");
		movie.setAttribute("id", "mid_4");
		
		add(doc, movie, "movieName", "Inception");
		add(doc, movie, "year", "2010");
		add(doc, movie, "genre", "Mystery");
		add(doc, movie, "country", "USA/Great Britain");
		add(doc, movie, "length", "148");
		
		Element al = doc.createElement("actorsList");
		al.setAttribute("actors", "aid_9");
		movie.appendChild(al);
		
		Element dl = doc.createElement("directorsList");
		dl.setAttribute("directors", "did_4");
		movie.appendChild(dl);
		
		add(doc, movie, "description", "Cool");
		add(doc, movie, "ranking", "5");
		
		Element reviews = doc.createElement("reviews");
		Element review = doc.createElement("review");
		review.setAttribute("ranking", "5");
		add(doc, review, "comment", "Best!");
		reviews.appendChild(review);
		
		movie.appendChild(reviews);
		
		NodeList mvs = doc.getElementsByTagName("movies");
		((Element) mvs.item(0)).appendChild(movie);
		
		// 2. order actors
		Element actors = (Element) doc.getElementsByTagName("actors").item(0);
		NodeList acl = actors.getElementsByTagName("actor");
		ArrayList<Element> al2 = new ArrayList<Element>();
		
		while (acl.getLength() > 0)
			al2.add((Element)actors.removeChild(acl.item(0)));
		
		sortActors(al2);
		
		for (Element e : al2)
			actors.appendChild(e);
	}

	private static void add(Document doc, Element parent, String name, String value) {
  	Element e = doc.createElement(name);
  	e.appendChild(doc.createTextNode(value));
  	parent.appendChild(e);
  }
	
	private static void sortActors(List<Element> elems) {
		Collections.sort(elems, new Comparator<Element>() {
			
			public int compare(Element a, Element b) {
				String alast = a.getElementsByTagName("last").item(0).getTextContent();
				String blast = b.getElementsByTagName("last").item(0).getTextContent();
				
				return alast.compareTo(blast);
			}
		});
	}
}