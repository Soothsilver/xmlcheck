package user;

import java.util.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.HashMap;

import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

 
public class MySaxHandler extends DefaultHandler {

  Locator locator;
  
  // output flag
  private static final boolean outputAllowed = false;
  
  // helpers
  String currentMovie, currentActorFirst, currentActorLast, qName;
  
  // flags
  boolean inActor, inBirth, isDeath;
  
  // 1. Average movie ranking
  HashMap<String, Double> rankings = new HashMap<String, Double>();
  ArrayList<Integer> ranking = new ArrayList<Integer>();
  
  // 2. Movies by countries
  HashMap<String, Integer> originCounts = new HashMap<String, Integer>();
  
  // 3. Oldest living actor
  String oldestActor;
  Date actualBirth, oldestBirth;
  DateFormat dateFormat = new SimpleDateFormat("dd. mm. yyyy");
  
  public void setDocumentLocator(Locator locator) {
      this.locator = locator;
  }

  public void startDocument() throws SAXException {
  }

  public void endDocument() throws SAXException {
  	// ad 1) write average rankings (not sorted)
  	print("Average rankings:");
  	for (Entry<String, Double> e : rankings.entrySet()) {
  		print(e.getKey() + ": " + e.getValue());
  	}
  	print();
  	
  	// ad 2) write countries sorted by movies count
  	print("Countries by number of movies:");
  	for (Entry<String, Integer> e : sortByValues(originCounts).entrySet()) {
  		print(e.getKey() + ": " + e.getValue());
  	}
  	print();
  	
  	// ad 3) write oldest living actor
  	Calendar birth = Calendar.getInstance();
  	birth.setTime(oldestBirth);
  	int age = Calendar.getInstance().get(Calendar.YEAR) - birth.get(Calendar.YEAR); 
  	print("Oldest living actor is " + oldestActor + " (age " + age + ")");
  }

  public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
      this.qName = qName;
      
      if (qName == "actor")
      	inActor = true;
      if (qName == "birth")
      	inBirth = true;
      if (qName == "death")
      	isDeath = true;
      
      // ad 1) parse rankings of movie
      if(qName == "review") {
      	ranking.add(Integer.parseInt(atts.getValue("ranking")));
      }
  }

  public void endElement(String uri, String localName, String qName) throws SAXException {
  	if (qName == "actor")
    	inActor = false;
  	if (qName == "birth")
  		inBirth = false;
  	
  	// ad 1) compute average ranking from all collected
  	if (qName == "reviews") {
  		double sum = sum(ranking);
  		rankings.put(currentMovie, sum / ranking.size());
  		
  		// clear for next movie
  		ranking.clear();
  	}
  	
  	// ad 3) compare actual actor with oldest known
  	if (qName == "actor" && actualBirth != null) {
  		if (isDeath) {
  			// don't count death
  			isDeath = false;
  		}
  		else if (oldestBirth == null || actualBirth.before(oldestBirth)) {
  			oldestBirth = actualBirth;
  			oldestActor = currentActorFirst + " " + currentActorLast;
  		}
  		actualBirth = null;
  	}
  }

  public void characters(char[] chars, int start, int length) throws SAXException {
  	String s = new String(chars, start, length).trim();
  
  	if (qName == "movieName") 
  		currentMovie = s;
  	
  	if (inActor) {
  		if (qName == "first")
  			currentActorFirst = s;
  		if (qName == "last")
  			currentActorLast = s;
  	}
  	
  	// ad 2) increment origin count
  	if (qName == "country") {
  		if (!originCounts.containsKey(s))
  			originCounts.put(s, 1);
  		else
  			originCounts.put(s, originCounts.get(s) + 1);
  	}
  	
  	// ad 3) parse date
  	if (inBirth && qName == "date") {
  		try {
  			actualBirth = dateFormat.parse(s);
  		} catch (ParseException e) {
  		}
  	}
  }

  public void startPrefixMapping(String prefix, String uri) throws SAXException {
  }

  public void endPrefixMapping(String prefix) throws SAXException {
  }

  public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
  }

  public void processingInstruction(String target, String data) throws SAXException {
  }

  public void skippedEntity(String name) throws SAXException {
  }
  
  public int sum(ArrayList<Integer> list) {
  	int sum = 0;
  	for (Integer i : list)
  		sum += i;
  	return sum;
  }
  
  public static <K extends Comparable,V extends Comparable> Map<K,V> sortByValues(Map<K,V> map) {
    List<Map.Entry<K,V>> entries = new LinkedList<Map.Entry<K,V>>(map.entrySet());
  
    Collections.sort(entries, new Comparator<Map.Entry<K,V>>() {

        public int compare(Entry<K, V> o1, Entry<K, V> o2) {
            // return o1.getValue().compareTo(o2.getValue());
        	return o2.getValue().compareTo(o1.getValue());
        }
    });
  
    Map<K,V> sortedMap = new LinkedHashMap<K,V>();
  
    for(Map.Entry<K,V> entry: entries){
        sortedMap.put(entry.getKey(), entry.getValue());
    }
  
    return sortedMap;
  }

  
  public void print() {
  	if (outputAllowed)
  		System.out.println();
  }
  public void print(String s) {
  	if (outputAllowed)
  		System.out.println(s);
  }
}

