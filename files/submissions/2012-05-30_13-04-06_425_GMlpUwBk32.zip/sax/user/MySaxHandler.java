package user;
import java.util.ArrayList;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;


/**
 * Spocita delku nejdelsiho nazvu elementu
 * Celkovy pocet elementu
 * Pocty elementu v jednotlivych hloubkach
 * prumerne delky nazvu elementu v jednotlivych hloubkach
 * @author scarface
 */
public class MySaxHandler extends DefaultHandler{
	ArrayList<Integer> delkyNazvu;
	ArrayList<Integer> poctyEl;
	int curLevel;
	String longest;
	int attsTotal;
	
	@Override
	public void startDocument(){
		 delkyNazvu = new ArrayList<Integer>();
		 poctyEl = new ArrayList<Integer>();
		 curLevel = 0;
		 longest = "";
		 attsTotal = 0;
	}
	
	@Override
	public void startElement(String uri, String localName, String qName, Attributes atts){
		if(curLevel == 0 || delkyNazvu.size() <= curLevel){
			delkyNazvu.add(new Integer(0));
			poctyEl.add(new Integer(0));
		}
		Integer d = delkyNazvu.get(curLevel);
		Integer p = poctyEl.get(curLevel);
		p++;
		d += localName.length();
		
		poctyEl.set(curLevel, p);
		delkyNazvu.set(curLevel, d);
		attsTotal += atts.getLength();
		
		if(longest.length() < localName.length())longest = localName;
		
		curLevel++;
	}
	
	@Override
	public void endDocument(){
		System.out.println("Delka nejdelsich elementu: " + longest.length());
		System.out.println("Celkem atributu: " + attsTotal);
		
		for(int i = 0; i < poctyEl.size(); i++){
			System.out.println("HLOUBKA: " + i);
			System.out.println("Elementu: " + poctyEl.get(i).toString());
			System.out.println("Prumerna delka nazvu el.: " + ((delkyNazvu.get(i) *1.0)/poctyEl.get(i) ));
			System.out.println("=================================");
		}
		
	}
	
	@Override
	public void endElement(String uri, String localName, String qName){
		
		
		curLevel--;
	}
	
}
