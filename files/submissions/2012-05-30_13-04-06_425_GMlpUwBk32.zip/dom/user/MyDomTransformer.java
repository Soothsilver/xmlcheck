package user;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Vsem atributum signatura prida predponu "sig-" , z ostatnich atributu udela elementy
 * hodnota atributu je textovym obsahem nove vytvoreneho elementu
 * Pokud titul nema uvedeneho zadneho autora, je pridan element autor s obsahem "neznámý"
 * @author Martin Patera
 */
public class MyDomTransformer {
	
	/*private static final String VSTUPNI_SOUBOR = "library.xml";
    private static final String VYSTUPNI_SOUBOR = "library.out.xml";*/
	
	private Document xmldoc;
	
	public void transform(Document xmlDocument){
		xmldoc = xmlDocument;
		NodeList nodes = xmlDocument.getChildNodes();
		for(int i = 0; i < nodes.getLength();i++){
			Node nn = transformN(nodes.item(i));
		}
	}
	
	private Node transformN(Node item) {
		NamedNodeMap attr = item.getAttributes();
		if(attr != null){
			for(int i = 0; i < attr.getLength(); i++){
				String name = attr.item(i).getNodeName();
				String val  = attr.item(i).getNodeValue();
				if(name.equals("signatura")){attr.item(i).setNodeValue("sig-"+val);continue;}
				//Node n = new org.w3c.dom.
				Element n = xmldoc.createElement(name);
				n.setTextContent(val);
				item.appendChild(n);
				
			}
			String[] names = new String[attr.getLength()];
			int c = 0;
			for (int i=0; i<names.length; i++) {
				if(!attr.item(i).getNodeName().equals("signatura")){
					names[c++] = attr.item(i).getNodeName();
					
				}
				
				
			}
			for (int i=0; i<c; i++) {
				attr.removeNamedItem(names[i]);
			}
		}
		NodeList nodes = item.getChildNodes();
		boolean auth = false;
		for(int i = 0; i < nodes.getLength();i++){
			Node nn = transformN(nodes.item(i));
			if(nn.getNodeName().equals("autor"))auth = true;
		}
		if(item.getNodeName().equals("titul") && (!auth)){
			Element n = xmldoc.createElement("autor");
			n.setTextContent("neznámý");
			item.appendChild(n);
		}
		
		return (Node) item;
	}
	
	/*public static void main(String[] args){
		try {
            XMLReader parser = XMLReaderFactory.createXMLReader();
            InputSource source = new InputSource(VSTUPNI_SOUBOR);
            parser.setContentHandler(new MySaxHandler());
            parser.parse(source);
            
        } catch (Exception e) {
        
            e.printStackTrace();
            
        }
		
		
		try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setValidating(false);
            DocumentBuilder builder = dbf.newDocumentBuilder();
            Document doc = builder.parse(VSTUPNI_SOUBOR);
			xmldoc = doc;
            transform(doc);
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer writer = tf.newTransformer();
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));

        } catch (Exception e) {
            
            e.printStackTrace();
            
        }
	}*/

	
}
