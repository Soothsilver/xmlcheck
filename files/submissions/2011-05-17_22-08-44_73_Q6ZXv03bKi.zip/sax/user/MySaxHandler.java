package user;
import org.xml.sax.helpers.DefaultHandler;

import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;

public class MySaxHandler extends DefaultHandler {
    
    protected int hloubka_max = 0;

    protected int strany_pocet = 0;

    protected int autori_pocet = 0;

    protected int knihy_pocet = 0;

    protected int hloubka = 0;

    protected int priznak = 0;


    public void startDocument() throws SAXException {
    }

    public void endDocument() throws SAXException {
        
        
        System.out.println("Statistiky dokumentu:");
        System.out.print("Pocet autoru: "); System.out.println(this.autori_pocet);
        System.out.print("Pocet knih: "); System.out.println(this.knihy_pocet);
        System.out.print("Pocet stran: "); System.out.println(this.strany_pocet);
        System.out.print("maximalni hloubka: "); System.out.println(this.hloubka_max);
    }

    
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        this.hloubka++;
     
        if(this.hloubka > this.hloubka_max)
        {
            this.hloubka_max = hloubka;
        }

        if(localName.equalsIgnoreCase("kniha"))
        {
            this.knihy_pocet++;
        }
        else if(localName.equalsIgnoreCase("autor"))
        {
            this.autori_pocet++;
        }
        else if(localName.equalsIgnoreCase("pocetStran"))
        {
            this.priznak = 1;
        }
		
    }
        public void endElement(String uri, String localName, String qName) throws SAXException {
                this.hloubka--;
    }


    public void characters(char[] ch, int start, int length) throws SAXException {
        if(this.priznak != 0)
        {
            String temp = "";
            for(int i = start; i < start + length; i++)
            {
                temp += ch[i];
            }
            this.strany_pocet = strany_pocet + Integer.valueOf(temp);
            this.priznak = 0;
        }
    }

    public void startPrefixMapping(String prefix, String uri) throws SAXException {
    }

    
    public void endPrefixMapping(String prefix) throws SAXException {
    }
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
    }

    
    public void processingInstruction(String target, String data) throws SAXException {
    }


    public void skippedEntity(String name) throws SAXException {
    }
}

