package user;

import java.io.Console;
import java.io.File;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

public class MyDomTransformer {
    private static final String VSTUPNI_SOUBOR = "../data.xml";
    private static final String VYSTUPNI_SOUBOR = "../data.out.xml";

    private static Element createAutorInfo(Document doc, Node autor)
    {
        NodeList nodes = autor.getChildNodes();
        Element autor_info = doc.createElement("autor");

        for(int i = 0; i < nodes.getLength(); i++) {      
            if (nodes.item(i).getNodeType() == Node.ELEMENT_NODE) {
                Element elm = (Element)nodes.item(i);
                if (elm.getTagName().equalsIgnoreCase("jmeno")) {
                    autor_info.appendChild(elm.cloneNode(true));
                }
                else if (elm.getTagName().equalsIgnoreCase("prijmeni")) {
                    autor_info.appendChild(elm.cloneNode(true));
                }
            }
        }        
        return autor_info;
    }
    
    public void transform (Document xmlDocument) {
        NodeList nodes_autors = null;
        NodeList nodes_books = null;

        Element knihy = xmlDocument.createElement("knihy");
        nodes_autors = xmlDocument.getElementsByTagName("autor");
        
        for(int i = 0; i < nodes_autors.getLength(); i++) {
            if (nodes_autors.item(i).getNodeType() == Node.ELEMENT_NODE) {
                
                Element autor_info = createAutorInfo(xmlDocument, nodes_autors.item(i));
               
                Element elm = (Element)nodes_autors.item(i);
                nodes_books = elm.getElementsByTagName("kniha");
                for(int j = 0; j < nodes_books.getLength(); j++) {
                    if (nodes_books.item(j).getNodeType() == Node.ELEMENT_NODE) {                        
                        nodes_books.item(j).insertBefore(
                                autor_info.cloneNode(true), 
                                nodes_books.item(j).getFirstChild());
                        knihy.appendChild(nodes_books.item(j));
                    }
                }
            }
        }        
        xmlDocument.replaceChild(knihy, xmlDocument.getDocumentElement());
    }
}
