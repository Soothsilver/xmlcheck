package user;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 * vypise:
 * 1. seznam ID autoru, kteri jsou po smrti
 * 2. prijmeni autoru bey biografie
 * 3. Jmena autoru, jejichz knihu ma nekdo pujcenou 
 */
public class MySaxHandler extends DefaultHandler
{
    public static void main(String[] args)
    {
        String sourcePath = "data\\data.xml";
        try
        {
            XMLReader parser = XMLReaderFactory.createXMLReader();
            InputSource source = new InputSource(sourcePath);
            parser.setContentHandler(new MySaxHandler());
            parser.parse(source);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    boolean withinAuthor;
    String currID;
    boolean withinSurName;
    String currSurName;
    boolean withinMidName;
    String currMidName;
    boolean withinFirstName;
    String currFirstName;

    // ID - Name
    Map<String, String> authors;

    boolean diedAuthor;
    List<String> deadAuthors;

    boolean hasBiography;
    List<String> wBioAuthors;

    // ID - authorID
    Map<String, String> books;
    // ID - bookID
    Map<String, String> bookitems;
    // bookItemID
    Set<String> loans;

    public void startDocument() throws SAXException
    {
        withinAuthor = false;
        currID = "";
        withinSurName = false;
        currSurName = "";
        withinMidName = false;
        currMidName = "";
        withinFirstName = false;
        currFirstName = "";

        authors = new HashMap<String, String>();

        diedAuthor = false;;
        deadAuthors = new ArrayList<String>();

        hasBiography = false;
        wBioAuthors = new ArrayList<String>();

        books = new HashMap<String, String>();
        bookitems = new HashMap<String, String>();
        loans = new HashSet<String>();
    }

    public void endDocument() throws SAXException
    {
        // mrtvi autori
        // xpath /library/authors/author[died]
        System.out.println("ID autoru, kteri zemreli");
        for (String s : deadAuthors)
        {
            System.out.println("   " + s);
        }
        deadAuthors.clear();

        // autori bez biografie
        // xpath /descendant::author[not(biography)]/name/surName
        System.out.println("Prijmeni autoru bez biografie");
        for (String s : wBioAuthors)
        {
            System.out.println("   " + s);
        }
        wBioAuthors.clear();

        // Jmena autoru, jejichz knihaje vypujcena 
        // xpath  /library/authors/author[@authorID=/library/books/book[@bookID=/library/bookitems/bookitem[@bookitemID=/library/loans/loan/@bookItem]/@book]/@author]
        Set<String> loanedBooks = new HashSet<String>();
        for (Map.Entry<String, String> bi : bookitems.entrySet())
        {
            if (loans.contains(bi.getKey()))
            {
                loanedBooks.add(bi.getValue());
            }
        }
        Set<String> loanedAuthors = new HashSet<String>();
        for (Map.Entry<String, String> book : books.entrySet())
        {
            if (loanedBooks.contains(book.getKey()))
            {
                loanedAuthors.add(book.getValue());
            }
        }
        
        System.out.println("Autori, jejichz knihu ma nekdo vypujcenou");
        for (Map.Entry<String, String> e : authors.entrySet())
        {
            if (loanedAuthors.contains(e.getKey()))
            {
                System.out.println("   " + e.getValue());
            }
        }
        books.clear();
        bookitems.clear();
        loans.clear();
        authors.clear();

    }

    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
    {
        if (withinAuthor)
        {
            if (localName.equals("died"))
            {
                diedAuthor = true;
            }

            if (localName.equals("biography"))
            {
                hasBiography = true;
            }

            if (localName.equals("firstName"))
            {
                withinFirstName = true;
            }

            if (localName.equals("middleName"))
            {
                withinMidName = true;
            }

            if (localName.equals("surName"))
            {
                withinSurName = true;
            }
        }

        if (localName.equals("author"))
        {
            withinAuthor = true;
            for (int i = 0; i < atts.getLength(); ++i)
            {
                if (atts.getLocalName(i).equals("authorID"))
                {
                    currID = atts.getValue(i);
                    break;
                }
            }
        }
        else if (localName.equals("book"))
        {
            String bookID = null;
            String authorID = null;
            for (int i = 0; i < atts.getLength(); ++i)
            {
                if (atts.getLocalName(i).equals("author"))
                {
                    authorID = atts.getValue(i);
                }
                else if (atts.getLocalName(i).equals("bookID"))
                {
                    bookID = atts.getValue(i);
                }
            }
            books.put(bookID, authorID);
        }
        else if (localName.equals("bookitem"))
        {
            String bookItemID = null;
            String bookID = null;
            for (int i = 0; i < atts.getLength(); ++i)
            {
                if (atts.getLocalName(i).equals("book"))
                {
                    bookID = atts.getValue(i);
                }
                else if (atts.getLocalName(i).equals("bookitemID"))
                {
                    bookItemID = atts.getValue(i);
                }
            }
            bookitems.put(bookItemID, bookID);
        }
        else if (localName.equals("loan"))
        {
            for (int i = 0; i < atts.getLength(); ++i)
            {
                if (atts.getLocalName(i).equals("bookItem"))
                {
                    loans.add(atts.getValue(i));
                }
            }
        }
    }

    public void endElement(String uri, String localName, String qName) throws SAXException
    {
        if (withinAuthor)
        {
            if (localName.equals("author"))
            {
                if (diedAuthor)
                {
                    deadAuthors.add(currID);
                }
                diedAuthor = false;

                if (!hasBiography)
                {
                    wBioAuthors.add(currSurName);
                }
                hasBiography = false;

                String currName = currFirstName + " ";
                if (!currMidName.equals(""))
                {
                    currName += currMidName + " ";
                }
                currName += currSurName;

                authors.put(currID, currName);

                currID = "";
                currSurName = "";
                currMidName = "";
                currFirstName = "";
            }
            else if (localName.equals("firstName"))
            {
                withinFirstName = false;
            }
            else if (localName.equals("middleName"))
            {
                withinMidName = false;
            }
            else if (localName.equals("surName"))
            {
                withinSurName = false;
            }
        }
    }

    public void characters(char[] ch, int start, int length) throws SAXException
    {
        if (withinFirstName)
        {
            currFirstName += new String(ch, start, length);
        }
        else if (withinMidName)
        {
            currMidName += new String(ch, start, length);
        }
        else if (withinSurName)
        {
            currSurName += new String(ch, start, length);
        }
    }
}
