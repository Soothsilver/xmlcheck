package user;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Nahradi v dokumentu vsechny reference (IDREF) celym elementem
 */
public class MyDomTransformer
{
    private static final String VSTUPNI_SOUBOR = "data\\data.xml";
    private static final String VYSTUPNI_SOUBOR = "data.out.xml";

    public static void main(String[] args) {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setValidating(false);
            DocumentBuilder builder = dbf.newDocumentBuilder();
            Document doc = builder.parse(VSTUPNI_SOUBOR);
            transform(doc);
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer writer = tf.newTransformer();
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            writer.transform(new DOMSource(doc), new StreamResult(new File(
                    VYSTUPNI_SOUBOR)));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Nahradi vsechny reference (IDREF) v dokumentu referovanymi objekty
     * @param xmlDocument
     */
    public static void transform(Document xmlDocument)
    {
        replaceUserRefs(xmlDocument);
        replaceAuthorRefs(xmlDocument);
        replaceBookRefs(xmlDocument);
        replaceBookItemRefs(xmlDocument);
    }
    
    private static void replaceUserRefs(Document doc)
    {
        Map<String, Node> users = new HashMap<String, Node>();
        NodeList userNodes = doc.getElementsByTagName("user");
        for (int i = 0; i < userNodes.getLength(); ++i)
        {
            Node user = userNodes.item(i).cloneNode(true);
            String userID = user.getAttributes().removeNamedItem("userID").getNodeValue();
            users.put(userID, user);
        }
        
        NodeList loans = doc.getElementsByTagName("loan");
        for (int i = 0; i < loans.getLength(); ++i)
        {
            Node loan = loans.item(i);
            String userID = loan.getAttributes().removeNamedItem("user").getNodeValue();
            loan.appendChild(users.get(userID).cloneNode(true));
        }
    }
    
    private static void replaceAuthorRefs(Document doc)
    {
        Map<String, Node> authors = new HashMap<String, Node>();
        NodeList authorNodes = doc.getElementsByTagName("author");
        for (int i = 0; i < authorNodes.getLength(); ++i)
        {
            Node author = authorNodes.item(i).cloneNode(true);
            String authorID = author.getAttributes().removeNamedItem("authorID").getNodeValue();
            authors.put(authorID, author);
        }
        
        NodeList books = doc.getElementsByTagName("book");
        for (int i = 0; i < books.getLength(); ++i)
        {
            Node book = books.item(i);
            String authorID = book.getAttributes().removeNamedItem("author").getNodeValue();
            book.appendChild(authors.get(authorID));
        }
        
        NodeList authorRefs = doc.getElementsByTagName("authorRef");
        for (int i = 0; i < authorRefs.getLength(); ++i)
        {
            Node authorRef = authorRefs.item(i);
            String authorID = authorRef.getAttributes().removeNamedItem("authorID").getNodeValue();
            authorRef.appendChild(authors.get(authorID).cloneNode(true));
        }
    }

    private static void replaceBookRefs(Document doc)
    {
        Map<String, Node> books = new HashMap<String, Node>();
        NodeList bookNodes = doc.getElementsByTagName("book");
        for (int i = 0; i < bookNodes.getLength(); ++i)
        {
            Node book = bookNodes.item(i).cloneNode(true);
            String bookID = book.getAttributes().removeNamedItem("bookID").getNodeValue();
            books.put(bookID, book);
        }
        
        NodeList bookItems = doc.getElementsByTagName("bookitem");
        for (int i = 0; i < bookItems.getLength(); ++i)
        {
            Node book = bookItems.item(i);
            String bookID = book.getAttributes().removeNamedItem("book").getNodeValue();
            book.appendChild(books.get(bookID).cloneNode(true));
        }
    }
    
    private static void replaceBookItemRefs(Document doc)
    {
        Map<String, Node> bookItemss = new HashMap<String, Node>();
        NodeList bookItemNodes = doc.getElementsByTagName("bookitem");
        for (int i = 0; i < bookItemNodes.getLength(); ++i)
        {
            Node bookItem = bookItemNodes.item(i).cloneNode(true);
            String bookItemID = bookItem.getAttributes().removeNamedItem("bookitemID").getNodeValue();
            bookItemss.put(bookItemID, bookItem);
        }
        
        NodeList loans = doc.getElementsByTagName("loan");
        for (int i = 0; i < loans.getLength(); ++i)
        {
            Node book = loans.item(i);
            String bookItemID = book.getAttributes().removeNamedItem("bookItem").getNodeValue();
            book.appendChild(bookItemss.get(bookItemID).cloneNode(true));
        }
    }
}
