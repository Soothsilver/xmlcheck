package user;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

public class MyDomTransformer {
	static final String INPUT = "data.xml";
        private static final String OUTPUT = "data.out.xml";

	/*
         * Process DOM tree
         */
        public void transform(Document doc) {
                Element root = doc.getDocumentElement();
                processChildNodes(root);
        }

        private static void processChildNodes(Node current)
        {
                //go through all child nodes and call itself on all children
                for (Node child = current.getFirstChild();
                        child != null;
                        child = child.getNextSibling()) {
                                processChildNodes(child);
                }

                //test if current node has attributes
                if (current.hasAttributes()) {
                        changeAttributesToElements(current);
                }
        }

        private static void changeAttributesToElements(Node current)
        {
                Document document = current.getOwnerDocument();
                NamedNodeMap attrs = current.getAttributes();

		for (int i = 0; i < attrs.getLength(); i++) {
                        Node node = attrs.item(i);

                        String name = node.getNodeName();
                        String value = node.getNodeValue();

                        Element e = document.createElement(name);
                        e.appendChild(document.createTextNode(value));
                        current.appendChild(e);
                }

                while (attrs.getLength() > 0) {
                        Node node = attrs.item(0);

                        /*
                         * I had to change DTD, because removeNamedItem()
                         * automatically inserts attributes with default
                         * values even while they are removed and even if
                         * validation is turned off.
                         */
                        attrs.removeNamedItem(node.getNodeName());
                }
        }
}
