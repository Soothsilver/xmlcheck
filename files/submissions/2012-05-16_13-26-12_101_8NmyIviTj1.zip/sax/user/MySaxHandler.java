package user;

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.*;
import java.util.*;

public class MySaxHandler extends DefaultHandler
{
        int maxLength = 0;

        public MySaxHandler()
        {
                try {
                }
                catch (Exception e) {
                        e.printStackTrace();
                        System.exit(1);
                }
        }

        public void startElement(String namespaceURI, String localName, String qName, Attributes atts) throws SAXException
        {
                int length = localName.length();
                if (maxLength < length)
                        maxLength = length;

        }

        public void endDocument() throws SAXException
        {
                System.out.println("Maximal length of element is " +maxLength);
        }

	public void error (SAXParseException e)
        {
                System.out.println("SAXParseException: error");
                e.printStackTrace();
        }

        public void warning (SAXParseException e)
        {
                System.out.println("SAXParseException: warning");
                e.printStackTrace();
        }

        public void fatalError (SAXParseException e)
        {
                System.out.println("SAXParseException: fatal error");
                System.exit(1);
        }
}

