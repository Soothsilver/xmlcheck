/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

/**
 *
 * @author DiNeRo
 */

//zvolene upravy dokumentu:
//1) pridani noveho videa (puvodne jsem chtel pridavat uzivatele, ale ten ma 
//   malo atributu a podelementu (konkretne 1 od kazdeho)
//2) smazani vsech videi, ktere nejsou public, tzn video, ktere jsou "private" nebo "unlisted"

import java.io.File;
import java.util.LinkedList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

public class MyDomTransformer {    
    private static final String INPUT_FILE = "data.xml";
    private static final String OUTPUT_FILE = "data.out.xml";

    /**
     * Main method
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        try {

            // DocumentBuilderFactory creates DOM parsers
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            // We don't want to validate file
            dbf.setValidating(false);

            // Creating of DOM parser instance
            DocumentBuilder builder = dbf.newDocumentBuilder();

            // Parser processes input file and creates a DOM tree of objects
            Document doc = builder.parse(INPUT_FILE);

            // DOM tree processing
            new MyDomTransformer().transform(doc);

            // TransformerFactory creates an object for DOM serialization
            TransformerFactory tf = TransformerFactory.newInstance();

            // Transformer serializes DOM tree
            Transformer writer = tf.newTransformer();

            // Setting of output file encoding
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            // Run transformation of DOM tree to XML document
            writer.setOutputProperty(OutputKeys.INDENT, "yes");
            writer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            writer.transform(new DOMSource(doc), new StreamResult(new File(OUTPUT_FILE)));


        } catch (Exception e) {

            e.printStackTrace();

        }
    }

    /**
     * Process document tree
     *
     * @param doc Document to be parsed
     */
    public void transform(Document doc) {
        //nejdriv budeme pridavat uzivatele
        List<String> categories=new LinkedList();
        categories.add("music");
        categories.add("rock");
        categories.add("alternative_rock");
        List<String> tags=new LinkedList();
        tags.add("new");
        tags.add("song");
        tags.add("indie");
        addVideo(doc,"v_05","u_01","public","This is my new song!",
                "Check out my new song! Used instruments: guitar, drum set, bass",
                categories,tags,"20.3.2013");
        
        //a ted teda budeme mazat ty videa
        NodeList videos=doc.getElementsByTagName("video");
        for(int i=videos.getLength()-1;i>=0;i--){
            Element video=(Element) videos.item(i);
            if(video.getAttribute("visibility").equalsIgnoreCase("private") ||
                    video.getAttribute("visibility").equalsIgnoreCase("unlisted")){
                video.getParentNode().removeChild(video);
            }
        }
    }
    
    private void addVideo(Document doc,String vid,String uid,String visibility,
            String title,String description,List<String> categories,List<String> tags,
            String date){
        Element videolist=null;
        if(doc.getElementsByTagName("videolist").getLength()==0){
            Element videoportal=(Element)doc.getElementsByTagName("videoportal").item(0);
            videolist=doc.createElement("videolist");
            doc.appendChild(videolist);
        }
        if(videolist==null){
            videolist=(Element)doc.getElementsByTagName("videolist").item(0);
        }
        
        Element newVideo=doc.createElement("video");
        newVideo.setAttribute("vid", vid);
        newVideo.setAttribute("uid", uid);
        newVideo.setAttribute("visibility", visibility);
        
        Element e=doc.createElement("title");
        e.setTextContent(title);
        newVideo.appendChild(e);
        
        e=doc.createElement("description");
        e.setTextContent(description);
        newVideo.appendChild(e);
        
        for(String cat:categories){
            e=doc.createElement("cat");
            e.setAttribute("cid",cat);
            newVideo.appendChild(e);
        }
        
        for(String tag:tags){
            e=doc.createElement("tag");
            e.setTextContent(tag);
            newVideo.appendChild(e);
        }
        
        e=doc.createElement("date");
        e.setTextContent(date);
        newVideo.appendChild(e);
        
        videolist.appendChild(newVideo);
    }
}