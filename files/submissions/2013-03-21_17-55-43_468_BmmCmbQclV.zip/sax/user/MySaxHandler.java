/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

/**
 *
 * @author DiNeRo
 */

//pocitane charakteristiky:
//atributy: nejcastejsi vyskytujici se kategorie videa
//elementy: datum nejnovejsiho videa
//kontext : pocet podkategorii rocku, ktere nemaji v nazvu "rock" 

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.Locale;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

public class MySaxHandler extends DefaultHandler {
    

    // Helper variable to store location of the handled event
    Locator locator;
    
    LinkedList<String> usedCats=new LinkedList();
    LinkedList<Integer> catCount=new LinkedList();
    
    Date newestVideo;
    boolean inDate=false;
    String currDate="";
    
    int numNonRockInRock=0;
    boolean inRock=false;
    int rockIndent=0;

    /**
     * Sets the locator
     *
     * @param Locator locator location in the file
     */
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Method to handle "document start"
     *
     * @throws SAXException
     */
    @Override
    public void startDocument() throws SAXException {
        // ...
    }

    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
        int max=catCount.get(0);
        String mostUsedCat=usedCats.get(0);
        for(int i=0;i<catCount.size();i++){
            if(catCount.get(i)>max){
                max=catCount.get(i);
                mostUsedCat=usedCats.get(i);
            }
        }
        
        System.out.println("The most used category in videos is: "+mostUsedCat+" used "+max+" times");
        System.out.println("The newest video was on: "+newestVideo.getDate()+"."+(newestVideo.getMonth()+1)+
                "."+(newestVideo.getYear()+1900));
        System.out.println("Number of rock subelements not containing 'rock': "+numNonRockInRock);
    }

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if(localName.equalsIgnoreCase("cat")){
            String cat=atts.getValue("cid");
            if(usedCats.contains(cat)){
                int i=usedCats.indexOf(cat);
                catCount.set(i, catCount.get(i)+1);
            } else {
                usedCats.add(cat);
                catCount.add(1);
            }
            return;
        }
        
        if(localName.equalsIgnoreCase("date")){
            inDate=true;
            return;
        }
        
        if(localName.equalsIgnoreCase("category")){
            if("rock".equalsIgnoreCase(atts.getValue("cid"))){
                inRock=true;
            }
            
            if(inRock){
                rockIndent++;
                if(!atts.getValue("cid").contains("rock")){
                    numNonRockInRock++;
                }
            }
        }                
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if(localName.equalsIgnoreCase("date")){
            inDate=false;
            try {
                Date d=new SimpleDateFormat("d.M.yyyy",Locale.ENGLISH).parse(currDate);
                if(newestVideo==null){
                    newestVideo=d;
                } else {
                    if(d.after(newestVideo)){
                        newestVideo=d;
                    }
                }
            } catch (ParseException ex) {
                System.err.println(ex.getMessage());
            }
            
            currDate="";
            return;
        }
        
        if(localName.equalsIgnoreCase("category")){
            if(inRock){
                if(rockIndent==0){
                    inRock=false;
                    return;
                }
                rockIndent--;
            }
        }
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        if(inDate){
            for(int i=start;i<start+length;i++){
                currDate+=chars[i];
            }
        }
    }

    /**
     * Method to handle " start of namespace declaration"
     *
     * @param prefix Prefix of the namespace
     * @param uri URI of the namespace
     * @throws SAXException
     */
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    /**
     * Method to handle "end of namespace declaration"
     *
     * @param prefix
     * @throws SAXException
     */
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    /**
     * Method to handle "ignoring of whitespaces" Text is in array 'chars' from
     * position ('start') to ('start' + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     * @throws SAXException
     */
    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
        // ...
    }

    /**
     * Method to handle "processing instructions"
     *
     * @param target The processing instruction target
     * @param data  The processing instruction data
     * @throws SAXException
     */
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

    /**
     * Method to handle "unprocessed entity"
     *
     * @param name
     * @throws SAXException
     */
    @Override
    public void skippedEntity(String name) throws SAXException {
        // ...
    }
}

