package user;

import java.io.File;
import java.io.StringWriter;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Comment;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

/*
 *  Autor: Tomáš Malich
 *  
 *  Čtyři metody, které transformují xml dokument.
 *  addComment() - pridava komentar k elementu s urcitym nazvem
 *  transformAttributesToElements() - transformuje vsechny atributy na elementy
 *  transformElementsToAttributes() - transformuje vsechny elementy na atributy
 *  renameRoot(String name) - zmeni jmeno root elementu
 * 
 */

public class MyDomTransformer {
    
    private Document document;
 
    public void transform (Document xmlDocument) throws TransformerConfigurationException, TransformerException, ParserConfigurationException, Exception {
        this.document = xmlDocument;
        Element documentElement = this.document.getDocumentElement();
        NodeList elementsByTagName = documentElement.getElementsByTagName("*");
        transformAttributesToElements(elementsByTagName);
        transformElementsToAttributes(elementsByTagName);  
        renameRoot("newrpg");
        addComment();       
        saveToFile(document);
    }
    
    public void renameRoot(String name) throws ParserConfigurationException, Exception {
        document.renameNode(document.getDocumentElement(), document.getDocumentElement().getNodeName(), name);
    }
    
    public void addComment() {
        NodeList list = document.getElementsByTagName("creep");
        for (int i=0; i<list.getLength(); i++) {
            Element element = (Element)list.item(i);
            Comment comment = document.createComment("Ja jsem creep");
            element.insertBefore(comment, element.getFirstChild());
            element.getParentNode().insertBefore(comment, element.getNextSibling());
        }
        
        NodeList list2 = document.getElementsByTagName("item");
        for (int i=0; i<list2.getLength(); i++) {
            Element element = (Element)list2.item(i);
            Comment comment = document.createComment("Ja jsem item");
            element.insertBefore(comment, element.getFirstChild());
            element.getParentNode().insertBefore(comment, element.getNextSibling());
        }
        
        
    }
    
    public void transformAttributesToElements(NodeList elements) {          
        for(int i = 0; i < elements.getLength(); i++) {
            NamedNodeMap attributes = elements.item(i).getAttributes();
            if (attributes.getLength() != 0) {
                for (int y = 0; y < attributes.getLength(); y++) {                   
                    Element createElement = document.createElement(attributes.item(y).getNodeName());
                    createElement.setTextContent(attributes.item(y).getNodeValue());                    
                    elements.item(i).appendChild(createElement);                     
                }     
                
                while (attributes.getLength() != 0) {
                    Element e = (Element)elements.item(i);
                    e.removeAttribute(attributes.item(0).getNodeName());
                }
            }            
        }        
    }
    
    public void transformElementsToAttributes(NodeList elements) {
        for(int i = 0; i < elements.getLength(); i++) {
            Node item = elements.item(i);
            if (item.getChildNodes().getLength() == 1) {
                Element e = (Element)item;
                e.setAttribute(item.getNodeName(), item.getTextContent());  
                e.setTextContent(null);
            }
        }
    }
    
    synchronized public void saveToFile(Document doc) throws TransformerConfigurationException, TransformerException {
        javax.xml.transform.TransformerFactory.newInstance().newTransformer().
        transform(new javax.xml.transform.dom.DOMSource(doc), new javax.xml.
        transform.stream.StreamResult(new File("data-transform.xml")));        
    }
    
 }