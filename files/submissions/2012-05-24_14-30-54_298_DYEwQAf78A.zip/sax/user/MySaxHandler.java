package user;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

/*
 * Spocita charakteristiku dokumentu
 * Vypocte:
 *  - pocet elementu
 *  - pocet atributu
 *  - hloubku nejhlubsiho elementu
 *  - prumernou hloubku elementu
 *  - prumernou delku nazvu elementu
 *  - prumernou delku nazvu atributu
 *  - nejcasteji vyskytovany element
 *  - nejcasteji vyskytovany atribut
 * 
 */

public class MySaxHandler extends DefaultHandler {
    
    private int elementsCount = 0;
    private int attributesCount = 0;
    private int deep = 0;
    private int maxDeep = 0;
    private List<Integer> deepList = new LinkedList();
    private int avgDeep = 0;
    private List<Integer> nameLengthList = new LinkedList();
    private int avgNameLength = 0;
    private List<Integer> attLengthList = new LinkedList();
    private int avgAttLength = 0;
    private List<ElementName> elements = new LinkedList();
    private List<ElementName> attributes = new LinkedList();
    
    @Override
    public void startDocument() throws SAXException { 
         
    }
    
    @Override
    public void startElement(String uri, String localName, 
        String qName, Attributes attributes) throws SAXException { 
        
        elementsCount++;
        int a = attributes.getLength();
        attributesCount = attributesCount + a;
        
        deep--;
        deepList.add(deep);        
        nameLengthList.add(qName.length());
        
        if (attributes.getLength() != 0) {
            for (int i = 0; i <attributes.getLength(); i++) {
                attLengthList.add(attributes.getQName(i).length());
                addAttribute(attributes.getQName(i));
            }
        }
        
        addElement(qName);        
    } 
    
    public void addElement(String element) {        
        boolean found = false;
        for (int i = 0; i < elements.size(); i++) {
            String a = elements.get(i).name;
            if (a.equals(element)) { 
                ElementName en = elements.get(i);
                en.count++;
                elements.set(i, en);
                found = true;
            }        
        }
        if (found == false) {
            elements.add(new ElementName(element));
        }
    }
    
    public void addAttribute(String attribute) {         
        
        for (int i = 0; i < attributes.size(); i++) {            
            String a = attributes.get(i).name;
            if (a.equals(attribute)) {
                ElementName en = attributes.get(i);
                en.count++;
                attributes.set(i, en);
                return;
            }
        }        
            
            attributes.add(new ElementName(attribute));
        
    }
        
    @Override
    public void endElement(String uri, String localName, 
        String qName) throws SAXException {           
         if (maxDeep > deep) maxDeep = deep;
         deep++;
    } 
     
    @Override
    public void characters(char[] ch, int start, int length) 
        throws SAXException  { 

    } 

    @Override
    public void endDocument() { 
        System.out.println("Pocet elementu: "+elementsCount);
        System.out.println("Pocet atributu: "+attributesCount);
        System.out.println("Nejhlubsi element je v hloubce: "+maxDeep*-1);
                
        int a = 0;
        for (int i = 0; i < deepList.size(); i++) {
            a = a + deepList.get(i);
        }
        avgDeep = a / deepList.size();
        System.out.println("Prumerna hloubka: "+avgDeep*-1);
        
        
        int b = 0;
        for (int i = 0; i < nameLengthList.size(); i++) {
            b = b + nameLengthList.get(i);
        }
        avgNameLength = b / nameLengthList.size();
        System.out.println("Prumerna delka nazvu elementu: "+avgNameLength);
       
        int c = 0;
        for (int i = 0; i < attLengthList.size(); i++) {
            c = c + attLengthList.get(i);
        }
        avgAttLength = c / attLengthList.size();
        System.out.println("Prumerna delka nazvu atributu: "+avgAttLength);
        
        System.out.println("Nejcastejsi element je: "+getMostUsualElement());        
        System.out.println("Nejcastejsi atribute je: "+getAttributeM());
    } 
    
    public String getMostUsualElement() {
        if (elements.size() == 0) return "V celem dokumentu nejsou elementy";
        ElementName en = null;
        for (int i = 0; i < elements.size(); i++) {
            ElementName a = elements.get(i);
            if (en == null) en = a;
            if (en.count < a.count) {
                en = a;
            }
        }
        return en.name;
    }
    
    public String getAttributeM() {
        if (attributes.size() == 0) return "V celem dokumentu nejsou atributy";
        ElementName a = null;
        for (int i = 0; i < attributes.size(); i++) {
            ElementName b = attributes.get(i);
            if (a == null) a = b;
            if (a.count < b.count) {
                a = b;
            }
        }
        return a.name;
    }
     
    @Override
    public void error(SAXParseException e) { 
        System.out.println(e.getMessage()); 
    } 

    @Override
    public void warning(SAXParseException e) { 
        System.out.println(e.getMessage()); 
    } 

    @Override
    public void fatalError(SAXParseException e) { 
        System.out.println(e.getMessage()); 
    } 
    
    class ElementName {        
        public String name;
        public int count = 1;
        public ElementName(String name) {
            this.name = name;
        }
    }
} 
   
