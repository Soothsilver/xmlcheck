package xml_sax_dom;

import com.sun.org.apache.xerces.internal.dom.NodeImpl;
import java.io.File;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

/**
 * ASSIGNMENT: Update document to be able to transform input XML document to
 * output document by actions mentioned in comments of processTree method.
 */
public class DOMSupport {
    
    private static final String INPUT_FILE = "data.xml";
    private static final String OUTPUT_FILE = "data.out.xml";

    /**
     * Main method
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        try {
            // DocumentBuilderFactory creates DOM parsers
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            // We don't want to validate file
            dbf.setValidating(false);
            // Creating of DOM parser instance
            DocumentBuilder builder = dbf.newDocumentBuilder();
            // Parser processes input file and creates a DOM tree of objects
            Document doc = builder.parse(INPUT_FILE);
            // DOM tree processing
            processTree(doc);
            // TransformerFactory creates an object for DOM serialization
            TransformerFactory tf = TransformerFactory.newInstance();
            // Transformer serializes DOM tree
            Transformer writer = tf.newTransformer();
            // Setting of output file encoding
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            // Run transformation of DOM tree to XML document
            writer.transform(new DOMSource(doc), new StreamResult(new File(OUTPUT_FILE)));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Process document tree
     *
     * @param doc Document to be parsed
     */
    private static void processTree(Document doc) {
        // add new category to user by name
        NodeList todoLists = doc.getElementsByTagName("todo_list");
        for (int i = 0; i < todoLists.getLength(); i++) {
            Element todoList = (Element) todoLists.item(i);
            if (todoList != null) {
                Attr attr = doc.createAttribute("name");
                attr.setNodeValue("Domácí práce");
                Element category = doc.createElement("category");
                category.setAttributeNode(attr);
                todoList.appendChild(category);
            }
        }
        // delete assignment with state "done"
        NodeList states = doc.getElementsByTagName("state");
        for (int i = 0; i < states.getLength(); i++) {
            Element state = (Element) states.item(i);
            String status = state.getAttribute("status");
            if (status.equals("done")) {
                state.getParentNode().getParentNode().removeChild(state.getParentNode());
            }
        }
    }
}
