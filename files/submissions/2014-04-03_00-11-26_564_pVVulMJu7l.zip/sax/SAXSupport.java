package xml_sax_dom;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 * Main class for SAX parsing
 *
 * @author XML Technologies
 */
public class SAXSupport {

    // Path to input file
    private static final String INPUT_FILE = "data.xml";

    /**
     * Main method
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        try {

            // Create parser instance
            XMLReader parser = XMLReaderFactory.createXMLReader();

            // Create input stream from source XML document
            InputSource source = new InputSource(INPUT_FILE);

            // Set our custom content handler for handling SAX events (it must implements ContentHandler interface)
            parser.setContentHandler(new CustomContentHandler());

            // Process input data
            parser.parse(source);
            parser.getContentHandler().startDocument();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

/**
 * Out custom content handler for managing SAX events Implements methods of the
 * abstract class ContentHandler.
 *
 * @see
 * http://www.saxproject.org/apidoc/org/xml/sax/ContentHandler.html#processingInstruction%28java.lang.String,%20java.lang.String%29
 */
class CustomContentHandler implements ContentHandler {

    // Helper variable to store location of the handled event
    Locator locator;

    HashSet<String> nameSet = new HashSet<>();
    boolean nameFlag = false;
    HashSet<String> idList = new HashSet<>();
    ArrayList<Assignment> assignmentList = new ArrayList<>();
    Assignment assignment = new Assignment();
    boolean subjectFlag = false;
    boolean toFlag = false;
    HashMap<String, Integer> mapCategory = new HashMap<>();

    /**
     * Sets the locator
     *
     * @param Locator locator location in the file
     */
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Method to handle "document start"
     *
     * @throws SAXException
     */
    @Override
    public void startDocument() throws SAXException {
        // ...
    }

    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
        printNames();
        printAllIds();
        printTheMostCommonCategory();
        printFleshedAssignment();
    }

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if (atts.getValue("id") != null) {
            idList.add(atts.getValue("id"));
        }
        if (qName.equals("last_name")) {
            nameFlag = true;
        } else if (qName.equals("subject")) {
            subjectFlag = true;
        } else if (qName.equals("to")) {
            toFlag = true;
        } else if (qName.equals("category")) {
            if (mapCategory.containsKey(atts.getValue("name"))) {
                mapCategory.put(atts.getValue("name"), mapCategory.remove(atts.getValue("name")) + 1);
            } else {
                mapCategory.put(atts.getValue("name"), 1);
            }
        } else if (qName.equals("date") && toFlag) {
            assignment = new Assignment();
            String date = "";
            for (int i = 0; i < atts.getLength(); i++) {
                date += atts.getValue(i) + "-";
            }
            assignment.setDate(date.substring(0, date.length() - 2));
            toFlag = false;
        } else if (qName.equals("state")) {
            if (atts.getValue("status").equals("fleshed")) {
                assignmentList.add(assignment);
            }
        }

    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        if (nameFlag) {
            nameSet.add(String.copyValueOf(chars, start, length));
            nameFlag = false;
        } else if (subjectFlag) {
            assignment.setSubject(String.copyValueOf(chars, start, length));
            subjectFlag = false;
        }
    }

    /**
     * Method to handle " start of namespace declaration"
     *
     * @param prefix Prefix of the namespace
     * @param uri URI of the namespace
     * @throws SAXException
     */
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    /**
     * Method to handle "end of namespace declaration"
     *
     * @param prefix
     * @throws SAXException
     */
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    /**
     * Method to handle "ignoring of whitespaces" Text is in array 'chars' from
     * position ('start') to ('start' + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     * @throws SAXException
     */
    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {

    }

    /**
     * Method to handle "processing instructions"
     *
     * @param target The processing instruction target
     * @param data The processing instruction data
     * @throws SAXException
     */
    @Override
    public void processingInstruction(String target, String data) throws SAXException {

    }

    /**
     * Method to handle "unprocessed entity"
     *
     * @param name
     * @throws SAXException
     */
    @Override
    public void skippedEntity(String name) throws SAXException {

    }

    // print all names of user in data.xml
    public void printNames() {
        System.out.println("Last_name:");
        for (String name : nameSet) {
            System.out.println(name);
        }
        System.out.println("");
    }

    // print all ids in data.xml 
    public void printAllIds() {
        System.out.println("Id:");
        for (String id : idList) {
            System.out.println(id);
        }
        System.out.println("");
    }

    // print the most common category
    public void printTheMostCommonCategory() {
        System.out.println("The most common category:");
        String category = "";
        int number = 0;
        for (Map.Entry<String, Integer> entry : mapCategory.entrySet()) {
            if (entry.getValue() > number) {
                number = entry.getValue();
                category = entry.getKey();
            }
        }
        System.out.println(category);
        System.out.println("");
    }

    // print assignemnt in todo which state is fleshed
    public void printFleshedAssignment() {
        System.out.println("Fleshed assignment");
        for (Assignment asignment : assignmentList) {
            System.out.println(asignment.toString());
        }
    }
}

class Assignment {

    String date;
    String subject;
    String status;

    public Assignment() {
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "to: " + this.date + "  subject: " + this.subject;
    }
}
