package user;

import org.w3c.dom.Element;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Trnasformacia vsetkych atributov na elementy
 */
public class MyDomTransformer{
    
	private static final String BEGIN_ELEMENT = "serials";
	
	private Document currentDoc;
	
	
	private void createElementsFromAttributes(Node element){
		/**
		 * Rekurzivne prechadzat DOM strom 
		 */
		NodeList children = element.getChildNodes();
		for (int i=0;i<children.getLength();i++){
    		Node child = children.item(i);
    		if (child.getNodeType()==Node.ELEMENT_NODE){
        		createElementsFromAttributes(children.item(i));
	    	}
		}
    	
    	/**
    	 * Prechadzat zoznam odzadu aby sme mazali prvky zoznamu ktore uz nepotrebujeme
    	 * Vzdy vytvorime novy element tak aby sme nahradili atribut ktory nasledne zmazeme 
    	 */
    	NamedNodeMap attributes = element.getAttributes();
    	for (int i = attributes.getLength();i>=0;i--){
    		if (attributes.item(i)!=null){
	    		String name = attributes.item(i).getNodeName();
	    		String value = attributes.item(i).getNodeValue();
	    		Element newElement = currentDoc.createElement(name);
	    		newElement.setTextContent(value);
	    		element.appendChild(newElement);
	    		attributes.removeNamedItem(name);
    		}
    	}
    }

	/**
     * Zpracujeme DOM strom tak ze vsetky atributy pretransformujeme na elementy
     */
    public void transform(Document doc) {
    	
    	currentDoc=doc;
    	
    	NodeList children = doc.getChildNodes();
    	for (int i=0;i<children.getLength();i++){
    		Node child = children.item(i);
    		if (child.getNodeType()==Node.ELEMENT_NODE){
    			/**
    			 * Element v ktorom zaciname transformaciu
    			 */
    			if (child.getNodeName().equals(BEGIN_ELEMENT)){
    				createElementsFromAttributes(children.item(i));
    			}
    		}
    	}
    }
	
}
