package user;

import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Vypisanie niektorych statistiky ohladom vstupneho suboru
 */ 
public class MySaxHandler extends DefaultHandler {

	static private String PART_ELEMENT="diel";
	static private String PART_ELEMENT_ATTRIBUTE_NAME="nazov";
	
	private Integer deep;
	private Integer maxDeep;
    private Integer sumDeep;
    private Integer countElement;
    private Integer countAttributes;
    private Integer maxAttributes;
    private String  maxAttributesElement;
    private Integer maxAttributesLine;
    private Integer countPart;
    private Integer maxLenghtPart;
    private Integer sumLenghtPart;
    
	
    Locator locator;
    
    public MySaxHandler(){
    }
    
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    public void startDocument() throws SAXException {
    	deep=0;
		maxDeep=0;
		sumDeep=0;
		countElement=0;
		countAttributes=0;
		maxAttributes=0;
		maxAttributesElement="";
		maxAttributesLine=0;
		countPart=0;
		maxLenghtPart=0;
		sumLenghtPart=0;
		
    }
    
    public void endDocument() throws SAXException {
		  System.out.print("Pocet elementov v xml        : "+countElement+"\n");
		  System.out.print("Pocet atributov v elementoch : "+countAttributes+"\n");
		  System.out.print("Hlbka maximalneho zanorenia  : "+maxDeep+"\n");
	    System.out.print("Hlbka priemerneho zanorenia  : "+sumDeep/countElement+"\n");
	    
	    System.out.print("Maximalny pocet atributou    : "+maxAttributes+"\n");
	    System.out.print("      Prvy vyskyt v elemente : "+maxAttributesElement+"\n");
	    System.out.print("      na riadku              : "+maxAttributesLine+"\n");
	    
	    System.out.print("Pocet dielov                 : "+countPart+"\n");
	    System.out.print("Maximalna dlzka nazvu dielu  : "+maxLenghtPart+"\n");
	    if (countPart>0){
    	System.out.print("Priemerna dlzka nazvu dielu  : "+sumLenghtPart/countPart+"\n");
	    }
	    
    }

    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
    	deep++;
    	countElement++;
    	if (deep>maxDeep){
    		maxDeep = deep;
    	}
    	countAttributes+=atts.getLength();
    	if (atts.getLength()>maxAttributes){
    		maxAttributes = atts.getLength();
    		maxAttributesElement=localName;
    		maxAttributesLine=locator.getLineNumber();
    	}
    	if (localName.equals(PART_ELEMENT)){
    		countPart++;
			for (int i=0; i<atts.getLength();i++){
    			if (atts.getQName(i).equals(PART_ELEMENT_ATTRIBUTE_NAME)){
    				String name = atts.getValue(i);
    				sumLenghtPart+=name.length();
    				if (name.length()>maxLenghtPart){
    					maxLenghtPart=name.length();
    				}
    			}
    	    			
    		}
    	}
    }

    public void endElement(String uri, String localName, String qName) throws SAXException {
    	deep--;
    	sumDeep+=deep;
    }

    public void characters(char[] ch, int start, int length) throws SAXException {

        // ...
        
    }
    
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
        // ...
        
    }

    public void endPrefixMapping(String prefix) throws SAXException {
    
        // ...
    
    }

    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
        // ...
        
    }

    public void processingInstruction(String target, String data) throws SAXException {
      
      // ...
            
    }

    public void skippedEntity(String name) throws SAXException {
    
      // ...
    
    }
}

