package dom.user;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;


public class MyDomTransformer {
    public void transform(Document xmlDocument)
    {
       // 1. sprav pridaj element TRANSAKCIA
       // vytvorim novu transakciu + spravim atributy
       Element newTransakcia = xmlDocument.createElement("transakcia");
       newTransakcia.setAttribute("id-transakcie", "t_001245");
       newTransakcia.setAttribute("cislo-uctu", "cu_001245");
       newTransakcia.setAttribute("protiucet", "3001245");
       
       // vytvorim podelementy a dam im hodnotu
       Element newObnos = xmlDocument.createElement("obnos");
       Element newUnixTime = xmlDocument.createElement("unixovy-cas");
       newObnos.setTextContent("4800");
       newUnixTime.setTextContent("21212334547");
                 
       // strcim ich pod newTransakcia 
       newTransakcia.appendChild(newObnos);
       newTransakcia.appendChild(newUnixTime);
       
       NodeList transakcieNodeList = xmlDocument.getElementsByTagName("transakcie");
       transakcieNodeList.item(0).appendChild(newTransakcia);
       
       // 2. vsetkym transakciam, ktore mali vacsi obnos ako MAX_OBNOS,
       //    nastavim, ze sa moze jednat o podozrivu transakciu
       //    a pridam poznamku o pocte takychto transakcii
       int MAX_OBNOS = 10000;
       int pocetFlagov = 0;
       NodeList nlTransakcie = xmlDocument.getElementsByTagName("transakcie");
       Element elTransakcie = (Element)nlTransakcie.item(0);
       
       NodeList transakcie = elTransakcie.getChildNodes();
       for (int i = 0; i < transakcie.getLength(); ++i)
       {
           // len pokial je to ten child, odfiltruje text nodes a comment nodes etc...
           if (transakcie.item(i).getNodeName().equals("transakcia"))
           {
               Element transakcia = (Element) transakcie.item(i);
               
               NodeList transakciaChildren = transakcia.getChildNodes();
               for (int j = 0; j < transakciaChildren.getLength(); ++j)
               {
                   
                   //NodeList nObnos = transakciaChildren.item(j);
                   if (transakciaChildren.item(j).getNodeName().equals("obnos"))
                   {
                       Element eObnos = (Element)transakciaChildren.item(j);
                       int iObnos = Integer.parseInt(eObnos.getTextContent().trim());
                       
                       if (iObnos > MAX_OBNOS) 
                       {
                           Element newFlag = xmlDocument.createElement("pozor");
                           transakciaChildren.item(j).getParentNode().appendChild(newFlag);
                           ++pocetFlagov;
                       }
                   }
               }
               
           }
           
       }
       xmlDocument.getElementsByTagName("poznamka").item(0).appendChild(
        xmlDocument.createTextNode("Pocet podozrivych transakcii " + pocetFlagov + ".\n")
               );
       
      
    }
    
            
}
