package sax.user;

import java.util.List;
import java.util.ArrayList;
import java.lang.Math;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

// zisti mi sucet penazi na vsetkych uctoch
// potom mi zisti najvyssie IDcko uzivatela
public class MySaxHandler extends DefaultHandler {

    public List<Integer> UserIDs = new ArrayList<Integer>();
    public List<Integer> Money = new ArrayList<Integer>();
    public int nthUser = -1;
    public int maxUser = 0;
    public boolean citamZostatok = false;
    
    @Override
    public void startDocument() throws SAXException {
       
    }

    @Override
    public void endDocument() throws SAXException {
       System.out.println("Najvyssie ID uzivatela " + maxUser);
        for (int i = 0; i < UserIDs.size(); i++) {
            System.out.println("User s ID " + UserIDs.get(i) + " ma na vsetkych uctoch dokopy " + Money.get(i) + " eur");
        }
    }    

    
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
       if (citamZostatok) {
           // len indexujem
           if(Money.size()- 1 == nthUser) {
               Money.set(nthUser, Money.get(nthUser)+Integer.parseInt(new String(ch, start, length)));
           } else {
               Money.add(Integer.parseInt(new String(ch, start, length)));
           }
       }
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {

        if (qName.equals("uzivatel")) {
            ++nthUser;
            UserIDs.add(Integer.parseInt(attributes.getValue(0).substring(3))); 
            maxUser = Math.max(Integer.parseInt(attributes.getValue(0).substring(3)), maxUser);
        }
        if (qName.equals("zostatok")) {
            citamZostatok = true;
        }
    } 
    
    
    
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (qName.equals("zostatok")){
            citamZostatok = false;
        }
    }

}
