package user;

/**
 * Created by Michal on 2.4.14.
 */
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MyDomTransformer {

    private static final String INPUT_FILE = "data.xml";
    private static final String OUTPUT_FILE = "data.out.xml";

    public void transform (Document xmlDocument) {

        /* PRIDANI NOVEHO shoppingCartItem */

        NodeList shoppingCartList = xmlDocument.getElementsByTagName("shoppingCart");
        // vytahnu tag shoppingCart
        Node first = shoppingCartList.item(0);

        // udelam novej shoppingCartItem
        Element newShoppingCartItem = xmlDocument.createElement("shoppingCartItem");
        // pridam do nej novej course
        Element newCourse = this.createNewCourse(xmlDocument, newShoppingCartItem);
        newCourse.appendChild(xmlDocument.createElement("name")).setTextContent("softskills");
        newCourse.appendChild(this.createNewLecturer(xmlDocument, newCourse));
        newCourse.appendChild(xmlDocument.createElement("category")).setTextContent("zamestnanec");
        newCourse.appendChild(xmlDocument.createElement("dateStart")).setTextContent("5.11.2014");
        newCourse.appendChild(xmlDocument.createElement("dateEnd")).setTextContent("12.11.2014");
        newCourse.appendChild(xmlDocument.createElement("freePlaces")).setTextContent("5");
        newCourse.appendChild(xmlDocument.createElement("totalFreePlaces")).setTextContent("10");
        newCourse.appendChild(xmlDocument.createElement("rating")).setTextContent("4");
        newCourse.appendChild(this.createNewPrice(xmlDocument, newCourse, "30500"));
        newCourse.appendChild(xmlDocument.createElement("description")).setTextContent("Nejhorsi kurz ever");

        Element newKeyWords = xmlDocument.createElement("keywords");
        newKeyWords.appendChild(xmlDocument.createElement("keyword")).setTextContent("java vyvoj");
        newKeyWords.appendChild(xmlDocument.createElement("keyword")).setTextContent("databaze");

        newCourse.appendChild(newKeyWords);

        newShoppingCartItem.appendChild(newCourse);
        first.appendChild(newShoppingCartItem);


        /*
        ITEM NO 2
         */
        // udelam novej shoppingCartItem
        Element newShoppingCartItem2 = xmlDocument.createElement("shoppingCartItem");
        // pridam do nej novej course
        Element newCourse2 = this.createNewCourse(xmlDocument, newShoppingCartItem2);
        newCourse2.appendChild(xmlDocument.createElement("name")).setTextContent("softskills");
        newCourse2.appendChild(this.createNewLecturer(xmlDocument, newCourse2));
        newCourse2.appendChild(xmlDocument.createElement("category")).setTextContent("zamestnanec");
        newCourse2.appendChild(xmlDocument.createElement("dateStart")).setTextContent("5.11.2014");
        newCourse2.appendChild(xmlDocument.createElement("dateEnd")).setTextContent("12.11.2014");
        newCourse2.appendChild(xmlDocument.createElement("freePlaces")).setTextContent("5");
        newCourse2.appendChild(xmlDocument.createElement("totalFreePlaces")).setTextContent("10");
        newCourse2.appendChild(xmlDocument.createElement("rating")).setTextContent("4");
        newCourse2.appendChild(this.createNewPrice(xmlDocument, newCourse2, "80000"));
        newCourse2.appendChild(xmlDocument.createElement("description")).setTextContent("Nejhorsi kurz ever");

        Element newKeyWords2 = xmlDocument.createElement("keywords");
        newKeyWords2.appendChild(xmlDocument.createElement("keyword")).setTextContent("java vyvoj");
        newKeyWords2.appendChild(xmlDocument.createElement("keyword")).setTextContent("databaze");

        newCourse2.appendChild(newKeyWords2);

        newShoppingCartItem2.appendChild(newCourse2);
        first.appendChild(newShoppingCartItem2);


        /* SERAZENI DLE CENY */
        NodeList shoppingCartItems = xmlDocument.getElementsByTagName("shoppingCartItem");
        // nejprve vsechny presypu do listu
        List<Node> cartItems = new ArrayList<Node>();
        for (int i = 0 ; i < shoppingCartItems.getLength() ; i++) {
            cartItems.add(shoppingCartItems.item(i));
        }
        int index = 0;

        Collections.sort(cartItems, new Comparator<Node>() {
            public int compare(Node node, Node node2) {
                if (getPrice(node2) == getPrice(node)) {
                    return 0;
                }
                if (getPrice(node) > getPrice(node2)) {
                    return 1;
                }
                else {
                    return -1;
                }
            }
        });

        for (int i = 0 ; i < cartItems.size() ; i++) {
            System.out.println(getPrice(cartItems.get(i)));
        }

        for (int i = 0 ; i < first.getChildNodes().getLength() ; i++) {
            if (first.getChildNodes().item(i).getNodeName().equals("shoppingCartItem")) {
                //System.out.println("Replacing: " + )
                first.replaceChild(cartItems.get(index), first.getChildNodes().item(i));
                index++;
            }
        }
    }

    private int getPrice(Node shoppingCartItem) {
        NodeList courses = shoppingCartItem.getChildNodes();
        Node course = courses.item(0);
        if (course.getNodeName().equals("course")) {
            for (int j = 0 ; j < course.getChildNodes().getLength() ; j++) {
                Node node = course.getChildNodes().item(j);
                if (node.getNodeName().equals("price")) {
                    return Integer.parseInt(node.getTextContent());
                }
            }
        }
        return 0;
    }

    private Element createNewCourse(Document xmlDocument, Element shoppingCartItem) {
        Element newCourse = xmlDocument.createElement("course");
        newCourse.setAttribute("id", "2");
        return newCourse;
    }

    private Element createNewLecturer(Document xmlDocument, Element course) {
        Element newLecturer = xmlDocument.createElement("lecturer");
        newLecturer.setAttribute("refId", "id_3");
        return newLecturer;
    }

    private Element createNewPrice(Document xmlDocument, Element course, String price) {
        Element newPrice = xmlDocument.createElement("price");
        newPrice.setAttribute("currency", "CZK");
        newPrice.setTextContent(price);
        return newPrice;
    }

    public static void main(String[] args) throws ParserConfigurationException, IOException, SAXException, TransformerException {
        // DocumentBuilderFactory creates DOM parsers
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        // We don't want to validate file
        dbf.setValidating(false);

        // Creating of DOM parser instance
        DocumentBuilder builder = dbf.newDocumentBuilder();

        // Parser processes input file and creates a DOM tree of objects
        Document doc = builder.parse(INPUT_FILE);

        MyDomTransformer transformer = new MyDomTransformer();
        transformer.transform(doc);

        // TransformerFactory creates an object for DOM serialization
        TransformerFactory tf = TransformerFactory.newInstance();

        // Transformer serializes DOM tree
        Transformer writer = tf.newTransformer();

        // Setting of output file encoding
        writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

        // Run transformation of DOM tree to XML document
        writer.transform(new DOMSource(doc), new StreamResult(new File(OUTPUT_FILE)));

    }
}