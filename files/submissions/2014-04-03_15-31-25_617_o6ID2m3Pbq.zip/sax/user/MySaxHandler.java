package user;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MySaxHandler extends DefaultHandler {

    private Map<String, Integer> lecturers = new HashMap<>();
    private List<String> emails = new ArrayList<>();

    private boolean isLecturer;
    private boolean isName;

    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {

        /* 1. - kolikrat je ktery lecturer u kurzu */
        if (qName.equals("lecturer")) {
            this.isLecturer = true;
            if (lecturers.containsKey(attributes.getValue("refId"))) {
                int count = lecturers.get(attributes.getValue("refId")).intValue() + 1;
                lecturers.put(attributes.getValue("refId"), count);
            }
            else {
                lecturers.put(attributes.getValue("refId"), 1);
            }
            System.out.println(lecturers);
        }

        if (qName.equals("email") && this.isLecturer) {
            this.isName = true;
        }

    }

    public void characters(char ch[], int start, int length) throws SAXException {
        /* 2. vsechny maily */
        if (this.isName && this.isLecturer) {
            String names = new String(ch, start, length);
            emails.add(names);
        }
        System.out.println(this.emails);
    }

    public void endElement(String uri, String localName,
                           String qName) throws SAXException {
        if (qName.equals("lecturer")) {
            this.isLecturer = false;
        }
        if (qName.equals("email") && this.isLecturer) {
            this.isName = false;
        }
    }

    public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
        SAXParserFactory factory = SAXParserFactory.newInstance();
        SAXParser saxParser = factory.newSAXParser();

        DefaultHandler handler = new MySaxHandler();
        saxParser.parse("data.xml", handler);
    }
}