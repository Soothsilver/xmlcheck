package user;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {

	private String text = "";

	private Map<String, Integer> tarifCounts = new HashMap<String, Integer>();

	private boolean readTicketPrice = false;
	private List<Integer> ticketPrices = new ArrayList<Integer>();

	private boolean readUserContext = false;
	private boolean readCity = false;
	private boolean readSex = false;
	private User user;

	private List<User> users = new ArrayList<User>();

	/**
	 * Method to handle "document start"
	 * 
	 * @throws SAXException
	 */
	@Override
	public void startDocument() throws SAXException {
		text += "Vypis statistik\n\n";
	}

	/**
	 * Method to handle "document end"
	 * 
	 * @throws SAXException
	 */
	@Override
	public void endDocument() throws SAXException {

		// max tarif - attribute values
		int maxCount = 0;
		String maxCountTar = null;
		for (Map.Entry<String, Integer> entry : tarifCounts.entrySet()) {
			if (entry.getValue() > maxCount) {
				maxCountTar = entry.getKey();
				maxCount = entry.getValue();
			}
		}

		text += "Tarif nejvicekrat zakoupeny (v seatReservations): "
				+ maxCountTar + "\n";

		// average ticket price - element values
		int sum = 0;
		for (Integer price : ticketPrices) {
			sum += price;
		}

		text += "Prumerna cena jizdenky: " + (double) sum / ticketPrices.size()
				+ "\n";

		// count men from prague
		int count = 0;
		boolean menChecked;
		boolean cityChecked;
		for (User us : users) {
			menChecked = false;
			cityChecked = false;

			if (us.getSex().equals("M")) {
				menChecked = true;
			}

			for (String cit : us.getCities()) {
				if (cit.toLowerCase().equals("praha")) {
					cityChecked = true;
					break;
				}
			}

			if (menChecked && cityChecked) {
				count += 1;
			}
		}

		text += "Pocet muzu, kteri maji adresu v Praze: " + count + "\n";

		text += "\n---END---\n";
		System.out.print(text);
	}

	/**
	 * Method to handle "begin element"
	 * 
	 * @param uri
	 *            URI of the element namespace (empty if element is no
	 *            namespace)
	 * @param localName
	 *            local name of the element (never empty)
	 * @param qName
	 *            qualified name (prefix-URI + ':' + localName, if the element
	 *            is in some namespace or localName otherwise)
	 * @param atts
	 *            Element's attributes
	 * @throws SAXException
	 */
	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes atts) throws SAXException {

		// najčastější tarif v seatreservations
		if (localName.equals("rideRate")) {
			for (int i = 0; i < atts.getLength(); i++) {
				if (atts.getLocalName(i).equals("ref")) {
					if (tarifCounts.containsKey(atts.getValue(i))) {
						tarifCounts.put(atts.getValue(i),
								tarifCounts.get(atts.getValue(i)) + 1);
					} else {
						tarifCounts.put(atts.getValue(i), 1);
					}
				}
			}
		}

		// průměrná cena jízdenky
		if (localName.equals("ticketAmount")) {
			readTicketPrice = true;
		}

		// počet mužů z Prahy
		if (localName.equals("user")) {
			readUserContext = true;
			user = new User();
		}

		if (readUserContext && localName.equals("city")) {
			readCity = true;
		}

		if (readUserContext && localName.equals("sex")) {
			for (int i = 0; i < atts.getLength(); i++) {
				if (atts.getLocalName(i).equals("type")) {
					user.setSex(atts.getValue(i));
				}
			}

		}

	}

	/**
	 * Method to handle "element end"
	 * 
	 * @param uri
	 *            URI of the element namespace (empty if element is no
	 *            namespace)
	 * @param localName
	 *            local name of the element (never empty)
	 * @param qName
	 *            qualified name (prefix-URI + ':' + localName, if the element
	 *            is in some namespace or localName otherwise)
	 * @param atts
	 *            Element's attributes
	 * @throws SAXException
	 */
	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		// průměrná cena jízdenky
		if (localName.equals("ticketAmount")) {
			readTicketPrice = false;
		}

		// počet mužů z Prahy
		if (localName.equals("user")) {
			readUserContext = false;
			users.add(user);
		}

		if (readUserContext && localName.equals("city")) {
			readCity = false;
		}

	}

	/**
	 * Method to handle "character data" SAX parser can process data in various
	 * batches. so we can't rely that whole whole text content will be delivered
	 * in one call Text is in array 'chars' from position ('start') to ('start'
	 * + 'length' - 1)
	 * 
	 * @param chars
	 *            Array with char data
	 * @param start
	 *            Index of the begin of valid data
	 * @param length
	 *            Length of the valid data
	 * @throws SAXException
	 */
	@Override
	public void characters(char[] chars, int start, int length)
			throws SAXException {

		if (this.readTicketPrice) {
			String priceString = "";
			for (int i = start; i < (start + length); i++) {
				priceString += chars[i];
			}

			ticketPrices.add(Integer.parseInt(priceString));
		}

		if (this.readCity) {
			String city = "";
			for (int i = start; i < (start + length); i++) {
				city += chars[i];
			}

			user.addCity(city);
		}

		if (this.readSex) {
			String sex = "";
			for (int i = start; i < (start + length); i++) {
				sex += chars[i];
			}

			user.setSex(sex);
		}
	}

}

/**
 * 
 * @author jakubchalupa 
 * pomocná třída pro ukládání informací o userech
 * 
 */
class User {
	private String sex;
	private List<String> cities;

	public User() {
		this.cities = new ArrayList<String>();
	}

	public void addCity(String city) {
		this.cities.add(city);
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public List<String> getCities() {
		return this.cities;
	}

	public String getSex() {
		return this.sex;
	}
}