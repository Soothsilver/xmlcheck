/**
 * Vypise statistiku dokumentu pro pocet elemetu nejvetsi hloubku v dokumentu a jednotlive pocty vyskytu elementu a attributu
 */
package user;


import java.util.HashMap;
import java.util.jar.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {

    int maxDepth = Integer.MIN_VALUE;
    int depth = 0;
    HashMap<String, Integer> elements = new HashMap<String, Integer>();
    HashMap<String, Integer> attributes = new HashMap<String, Integer>();
    
    int totalElements = 0;
    int totalAttributes = 0;

    /**
     * Obsluha události "začátek dokumentu"
     */
    @Override
    public void startDocument() throws SAXException {
        System.out.println("Zacal dokument");
    }

    /**
     * Obsluha události "konec dokumentu"
     */
    @Override
    public void endDocument() throws SAXException {
        System.out.println("Celkem elementů " + totalElements);
        System.out.println("Celkem atributů " + totalAttributes);
        System.out.println("Největší hloubka " + maxDepth);
        System.out.println("Statistika jednotlivých elementů:");
        for(String key : elements.keySet()) {
            System.out.println(key + " výskytů " + elements.get(key));
        }
        System.out.println("Statistika jednotlivých attributů:");
        for(String key : attributes.keySet()) {
            System.out.println(key + " výskytů " + attributes.get(key));
        }
    }

    /**
     * Obsluha události "začátek elementu".
     *
     * @param uri URI jmenného prostoru elementu (prázdné, pokud element není v
     * žádném jmenném prostoru)
     * @param localName Lokální jméno elementu (vždy neprázdné)
     * @param qName Kvalifikované jméno (tj. prefix-uri + ':' + localName, pokud
     * je element v nějakém jmenném prostoru, nebo localName, pokud element není
     * v žádném jmenném prostoru)
     * @param atts Atributy elementu
     */
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        depth++;
        totalElements++;
        maxDepth = maxDepth < depth ? depth : maxDepth;
        if (elements.containsKey(localName)) {
            int k = elements.get(localName);
            k++;
            elements.put(localName, k);
        } else {
            elements.put(localName, 1);
        }

        for (Object k : atts.keySet()) {
            if (k.getClass().isInstance(String.class)) {
                totalAttributes++;
                String att = (String) k;
                if (attributes.containsKey(att)) {
                    int v = attributes.get(att);
                    v++;
                    attributes.put(att, v);
                } else {
                    attributes.put(att, 1);
                }
            }
        }
    }

    /**
     * Obsluha události "konec elementu" Parametry mají stejný význam jako u
     *
     * @see startElement
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        depth--;
        // ...
    }
}
