/*
 * Vymaze vsechny vypujcky ktere jsou vracene a jsou starsi alespon 5 let
 */
package user;

import java.util.Date;
import org.w3c.dom.*;

public class MyDomTransformer {

    public void transform(Document xmlDocument) {
        NodeList zakaznici = xmlDocument.getElementsByTagName("zakaznik");
        NodeList pujcky = xmlDocument.getElementsByTagName("pujcka");
        for (int i = 0; i < zakaznici.getLength(); i++) {
            Node z = zakaznici.item(i);
            if (z.getAttributes().getNamedItem("id") != null) {
                String id = z.getAttributes().getNamedItem("id").getNodeValue();
                for (int j = 0; j < pujcky.getLength(); j++) {
                    Node p = pujcky.item(j);
                    String vypujcil = getVypujcil(p);
                    if (vypujcil.equals(id)) {
                        String vypujceno = getVypujceno(p);
                        if (vypujceno != null) {
                            String[] vypArr = vypujceno.split("\\.");
                            if (vypArr.length == 3) {
                                int top = 2007;
                                try {
                                    int year = Integer.parseInt(vypArr[2]);
                                    if (year <= top) {
                                        if (getVraceno(p) != null) {
                                            p.getParentNode().removeChild(p);
                                        } else {
                                            Element ztraceno = xmlDocument.createElement("ztraceno");
                                            p.appendChild(ztraceno);
                                           
                                        }
                                    }
                                } catch (NumberFormatException e) {
                                }

                            }
                        }
                    }
                }
            }
        }
    }

    protected String getAttributeValue(Node n, String name) {
        if (n.hasAttributes()) {
            return n.getAttributes().getNamedItem(name).getNodeValue();
        }
        return null;
    }

    protected Node getChildNodeByTagName(NodeList k, String tag) {
        for (int i = 0; i < k.getLength(); i++) {
            Node z = k.item(i);
            if (z.getNodeName().equals(tag)) {
                return z;
            }
        }
        return null;
    }

    protected String getVypujcil(Node k) {
        Node v = getChildNodeByTagName(k.getChildNodes(), "vypujcil");
        if (v != null) {
            String r = getAttributeValue(v, "ref");
            return r;
        }
        return null;
    }

    protected String getVypujceno(Node k) {
        Node v = getChildNodeByTagName(k.getChildNodes(), "vypujceno");
        if (v != null) {
            String d = getAttributeValue(v, "datum");
            return d;
        }
        return null;

    }

    protected String getVraceno(Node k) {
        Node v = getChildNodeByTagName(k.getChildNodes(), "vraceno");
        if (v != null) {
            String d = getAttributeValue(v, "datum");
            return d;
        }
        return null;
    }
}
