package user; 
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Stack;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler; 
import org.xml.sax.helpers.XMLReaderFactory;
/**
 * calculates the average depth of the input document
 * @author xxxxx
 */
public class MySaxHandler extends DefaultHandler {
    
    ArrayList<Integer> array = new ArrayList<Integer>();
    boolean increase = true;
    int depth= 0;
    
 
    
    
    /**
     * zacatek elementu
     */
    @Override
    public void startElement(String namespaceURI, String localName, String qName, Attributes atts) throws SAXException {
            ++depth;
            if(!increase)
                increase = true;
    }
    
    @Override
    public void endElement(String uri, String localName, String qName) 
    {
        if(increase)
        {
            array.add(depth);
            increase = false;
        }
        --depth;
    }
    
    /**
     * konec dokumentu
     */
    public void endDocument() throws SAXException { 
        Integer sum = 0;
        for (int i = 0; i < array.size(); i++) {
            sum += array.get(i);
        }
        System.out.println("Average document length: " + (double)sum/array.size());
            
   }
        
    
    
    /**
     * chyba
     */
    public void error (SAXParseException e) {
        System.out.println("SAXParseException: error");
        e.printStackTrace();
   }

    /**
     * varovani
     */
    @Override
   public void warning (SAXParseException e) {
        System.out.println("SAXParseException: warning");
        e.printStackTrace();
   }

    /**
     * selhani
     */
    @Override
   public void fatalError (SAXParseException e) {
        System.out.println("SAXParseException: fatal error");
        System.exit(1);
   }
   
    public static void main(String[] args) throws SAXException, IOException
    {
        // Vytvorime instanci parseru
        XMLReader parser = XMLReaderFactory.createXMLReader ();
        // Vytvorime vstupni proud XML dat
        InputSource source = new InputSource ("C:/Users/xxxxx/Documents/Altova/XMLSpy2012/Examples/data.xml");
        // Nastavime vlastni content handler pro obsluhu udalosti
        parser.setContentHandler (new MySaxHandler ());
        // Zpracujeme vstupni proud XML dat
        parser.parse (source);
    }
}