package user;

import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;

public class MySaxHandler extends DefaultHandler {

    public static void main(String[] args) {
        String sourcePath = "src/data.xml";

        try {

            XMLReader parser = XMLReaderFactory.createXMLReader();

            InputSource source = new InputSource(new FileInputStream(new File(sourcePath)));
            calculateDepth(parser, source);


        } catch (Exception e) {

            e.printStackTrace();

        }
    }

    private static void calculateDepth(XMLReader parser, InputSource source) throws IOException, SAXException {
        MySaxHandler msh = new MySaxHandler();
        parser.setContentHandler(msh);
        parser.parse(source);



    }

    private void output() {
        List<ElementHolder> ehl = getElementHolders();

        int maxDepth = 0;
        int totalDepth = 0;
        int maxElNameLength = 0;
        int totalElNameLength = 0;
        int elementsWithAttribute = 0;
        int elementsWithText = 0;
        int elementsWitSubElement = 0;
        int maxChildrenCount = 0;
        int totalNumberOfChild = 0;

        for (ElementHolder eh : ehl) {
            totalElNameLength += eh.getNameLength();
            maxElNameLength = setMaximalElementNameLength(maxElNameLength, eh);
            totalDepth += eh.getDepth();
            maxDepth = setMaximalElementDepth(maxDepth, eh);
            elementsWithAttribute = incrementElementWithAttribute(elementsWithAttribute, eh);
            elementsWithText = incrementElementsWithText(elementsWithText, eh);
            elementsWitSubElement = incrementElementsWithSubElements(elementsWitSubElement, eh);
            totalNumberOfChild += getChildrenCount(eh);
            maxChildrenCount = setMaximalElementFanout(maxChildrenCount, eh);
        }

        int atCount = getAttributes().size();
        int maxAttNameLength = 0;
        int totalAttNameLength = 0;


        for (String at : getAttributes()) {
            maxAttNameLength = maximalAttributeNameLength(maxAttNameLength, at);
            totalAttNameLength += at.length();
        }


        System.out.println("pocet elementu = " + ehl.size());
        System.out.println("pocet unikatnich elementu = " + getElements().size());
        System.out.println("----------------------------------------");
        System.out.println("maximalni hloubka elementu = " + maxDepth);
        System.out.println("prumerna hloubka elementu = " + (double) totalDepth / ehl.size());
        System.out.println("----------------------------------------");
        System.out.println("maximalni delka nazvu elementu = " + maxElNameLength);
        System.out.println("prumerna delka nazvu elementu = " + (double) totalElNameLength / ehl.size());
        System.out.println("----------------------------------------");
        System.out.println("pocet elementu s atributy = " + elementsWithAttribute);
        System.out.println("pocet elementu s textem = " + elementsWithText);
        System.out.println("pocet elementu s podelementy = " + elementsWitSubElement);
        System.out.println("----------------------------------------");
        System.out.println("maximalni fanout = " + maxChildrenCount);
        System.out.println("prumerny fanout = " + (double)totalNumberOfChild/elementsWithSubElements);
        System.out.println("----------------------------------------");
        System.out.println("pocet unikatnich atributu = " + atCount);
        System.out.println("maximalni delka nazvu atributu = " + maxAttNameLength);
        System.out.println("prumerna delka nazvu atributu = " + (double)totalAttNameLength/atCount);
    }

    private static int maximalAttributeNameLength(int maxAttNameLength, String at) {
        if(at.length() > maxAttNameLength){
            maxAttNameLength = at.length();
        }
        return maxAttNameLength;
    }

    private static int elementsWithSubElements;

    private static int setMaximalElementFanout(int maxChildrenCount, ElementHolder eh) {
        if (eh.getCountOfSubelements() > maxChildrenCount) {
            maxChildrenCount = eh.getCountOfSubelements();
        }
        return maxChildrenCount;
    }

    private static int incrementElementsWithSubElements(int elementsWitSubElement, ElementHolder eh) {
        if (eh.isSubElements()) {
            elementsWitSubElement++;
        }
        return elementsWitSubElement;
    }

    private static int getChildrenCount(ElementHolder element) {
        if(element.getCountOfSubelements() > 0){
            elementsWithSubElements++;
        }
        return element.getCountOfSubelements();
    }

    private static int incrementElementsWithText(int elementsWithText, ElementHolder eh) {
        if (eh.isText()) {
            elementsWithText++;
        }
        return elementsWithText;
    }

    private static int incrementElementWithAttribute(int withAttributes, ElementHolder eh) {
        if (eh.isAttributes())
            withAttributes++;
        return withAttributes;
    }

    private static int setMaximalElementDepth(int maxDepth, ElementHolder eh) {
        if (eh.getDepth() > maxDepth) {
            maxDepth = eh.getDepth();
        }
        return maxDepth;
    }

    private static int setMaximalElementNameLength(int maxElNameLength, ElementHolder eh) {
        if (eh.getNameLength() > maxElNameLength) {
            maxElNameLength = eh.getNameLength();
        }
        return maxElNameLength;
    }




    private int depth;
    private Set<String> attributes = new HashSet<String>();
    private Set<String> elements = new HashSet<String>();
    private int maximalCountOfSubelements;

    private ElementHolder actualElement;

    private List<ElementHolder> elementHolders = new LinkedList<ElementHolder>();

    public Set<String> getAttributes() {
        return attributes;
    }

    public Set<String> getElements() {
        return elements;
    }

    public List<ElementHolder> getElementHolders() {
        return elementHolders;
    }

    @Override
    public void endDocument() throws SAXException {
        for (ElementHolder eh : elementHolders) {
            addChildern(eh);
        }

        output();
    }

    private void addChildern(ElementHolder eh) {
        int size = eh.getChildren().size();
        if(size > 0){
            eh.setCountOfSubelements(size);
            eh.setSubElements(true);
            if(size > maximalCountOfSubelements){
                maximalCountOfSubelements = size;
            }
        }
        for (ElementHolder elementHolder : eh.getChildren()) {
            addChildern(elementHolder);
        }
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {


        ElementHolder oldElement = actualElement;
        actualElement = new ElementHolder(qName, ++depth);

        hasElementSubElement(oldElement);
        addElementToSet(qName);
        addAttributesToList(atts);
        hasElementAttribute(atts);
        addElementToList();


    }

    private void hasElementSubElement(ElementHolder oldElement) {

        if (oldElement != null) {
            oldElement.addChild(actualElement);
        }
        actualElement.setParent(oldElement);


    }

    private void hasElementAttribute(Attributes atts) {
        if (atts.getLength() != 0) {
            actualElement.setAttributes(true);
        }
    }

    private void addElementToList() {
        elementHolders.add(actualElement);
    }

    private void addElementToSet(String qName) {
        elements.add(qName);
    }

    private void addAttributesToList(Attributes atts) {
        for (int i = 0; i < atts.getLength(); i++) {
            attributes.add(atts.getQName(i));
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        depth--;
        actualElement = actualElement.getParent();
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        hasElementText(String.copyValueOf(ch, start, length).trim().length());
    }



    private void hasElementText(int length) {
        if (length > 0)
            actualElement.setText(true);
    }

    class ElementHolder {

        private String name;
        private int depth;
        private boolean subElements;
        private int countOfSubelements;

        private boolean attributes;

        private boolean text;
        private ElementHolder parent;
        private List<ElementHolder> children = new ArrayList<ElementHolder>();

        public ElementHolder getParent() {
            return parent;
        }

        public void setCountOfSubelements(int countOfSubelements) {
            this.countOfSubelements = countOfSubelements;
        }

        public int getCountOfSubelements() {
            return countOfSubelements;
        }

        public void setParent(ElementHolder parent) {
            this.parent = parent;
        }

        public List<ElementHolder> getChildren() {
            return children;
        }

        public void setChildren(List<ElementHolder> children) {
            this.children = children;
        }

        public void addChild(ElementHolder child){
            children.add(child);
        }

        public ElementHolder(String name, int depth) {
            this.name = name;
            this.depth = depth;
        }

        public boolean isSubElements() {
            return subElements;
        }

        public void setSubElements(boolean subElements) {
            this.subElements = subElements;
        }

        public boolean isAttributes() {
            return attributes;
        }

        public void setAttributes(boolean attributes) {
            this.attributes = attributes;
        }

        public boolean isText() {
            return text;
        }

        public void setText(boolean text) {
            this.text = text;
        }

        public String getName() {
            return name;
        }

        public int getDepth() {
            return depth;
        }

        public int getNameLength(){
            return name.length();
        }

        @Override
        public String toString() {
            return name;
        }
    }

}


