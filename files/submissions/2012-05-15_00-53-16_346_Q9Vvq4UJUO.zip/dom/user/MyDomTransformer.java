package user;

import org.w3c.dom.Document;
import org.w3c.dom.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MyDomTransformer {
    private static final String VSTUPNI_SOUBOR = "src/data.xml";
    private static final String VYSTUPNI_SOUBOR = "library.out.xml";

    public static void main(String[] args) {

        try {

            //DocumentBuilderFactory vytv��� DOM parsery
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            //nebudeme validovat
            dbf.setValidating(false);

            //vytvo��me si DOM parser
            DocumentBuilder builder = dbf.newDocumentBuilder();

            //parser zpracuje vstupn� soubor a vytvo�� z n�j strom DOM objekt�
            Document doc = builder.parse(VSTUPNI_SOUBOR);

            //zpracujeme DOM strom
            new MyDomTransformer().transform(doc);

            //TransformerFactory vytv��� serializ�tory DOM strom�
            TransformerFactory tf = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer = tf.newTransformer();

            //nastav�me kodov�n�
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spust�me transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


        } catch (Exception e) {

            e.printStackTrace();

        }
    }

    /**
     * Zpracuje DOM strom
     */
    public void transform(Document xmlDocument) {
        changeElementsPosition(xmlDocument);     // prohodi poradi elementu "jmeno" a "prijmeni"
        convertAttributesToElements(xmlDocument);   // prevede atributy elementu "titul" na elementy
        convertElementsToAttributes(xmlDocument);   // prevede elementy "stran" na atribut predka
        removeChildrenWithFanout(xmlDocument); // vymaze potomky uzlu ktery ma fanout vetsi nez je zadano
        addMinimalDepth(xmlDocument);   // prida elementy na pozadovanou hloubku
        addMinimalFanout(xmlDocument);  // prida elementy na pozadovany fanout


    }

    private void addMinimalFanout(Document doc) {
        goThroughChildren(doc, doc.getElementsByTagName("knihovna").item(0), Work.MIN_FANOUT, 0);
    }

    private void addMinimalDepth(Document doc) {
        goThroughChildren(doc, doc.getElementsByTagName("knihovna").item(0), Work.MIN_DEPTH, 0);
    }

    private void removeChildrenWithFanout(Document doc) {
        goThroughChildren(doc, doc.getElementsByTagName("knihovna").item(0), Work.FANOUT, 0);
    }

    // prevede element "stran" na atribut rodice
    private void convertElementsToAttributes(Document doc) {
        NodeList nl = doc.getElementsByTagName("stran");

        if (nl != null) {
            for (int i = 0; i < nl.getLength(); i++) {
                Node element = nl.item(i);
                Attr attr = doc.createAttribute(element.getNodeName());
                attr.setValue(element.getTextContent().trim());
                element.getParentNode().getAttributes().setNamedItem(attr);

            }

            Node element = nl.item(0);
            do {
                element.getParentNode().removeChild(element);
                element = nl.item(0);
            } while (element != null);

        }
    }

    // prevede atributy elementu(mimo elementu titul) na elementy
    private void convertAttributesToElements(Document doc) {
        goThroughChildren(doc, doc.getElementsByTagName("knihovna").item(0), Work.ATTR, 0);
    }

    private void goThroughChildren(Document doc, Node node, Work work, int depth) {
        goThroughNodes(doc, node, work, depth);

        NodeList childNodes = node.getChildNodes();
        for (int i = 0; i < childNodes.getLength(); i++) {
            goThroughChildren(doc, childNodes.item(i), work, depth + 1);
        }

    }

    private void goThroughNodes(Document doc, Node node, Work work, int depth) {
        switch (work) {
            case ATTR:
                attributesWork(doc, node);
                break;
            case FANOUT:
                fanoutWork(node, work.getValue());
                break;
            case MIN_DEPTH:
                addDepth(doc, node, depth, Work.MIN_DEPTH.getValue() - depth);
                break;
            case MIN_FANOUT:
                addFanout(doc, node, Work.MIN_FANOUT.getValue());
                break;
        }
    }

    private void addFanout(Document doc, Node node, int minFanout) {
        int count = countElement(node.getChildNodes());
        if (count < minFanout && !node.getNodeName().trim().contains("#text") && !node.getNodeName().trim().contains("new_fanout")) {
            for (int i = 1; i <= (minFanout - count); i++) {
                Node newNode = doc.createElement("new_fanout_" + i);
                node.appendChild(newNode);
            }
        }
    }

    private void addDepth(Document doc, Node node, int actualDepth, int addNodes) {
        Node actualNode = node;
        if (!node.getNodeName().trim().equals("#text") && addNodes > 0 && !hasChildren(node.getChildNodes())) {
            for (int i = 0; i < addNodes; i++) {
                Node newNode = doc.createElement("pridana_hloubka_" + (actualDepth + i + 1));
                actualNode.appendChild(newNode);
                actualNode = newNode;
            }
        }
    }

    private int countElement(NodeList childNodes) {
        int length = childNodes.getLength();
        int length2 = 0;
        for (int i = 0; i < length; i++) {
            if (!childNodes.item(i).getNodeName().trim().contains("#text"))
                length2++;
        }
        return length2;
    }

    private boolean hasChildren(NodeList childNodes) {
        return (countElement(childNodes) > 0) ? true : false;
    }

    private void fanoutWork(Node node, int fanout) {
        NodeList nl = node.getChildNodes();
        int length = nl.getLength();
        int length2 = 0;
        for (int i = 0; i < length; i++) {
            if (!nl.item(i).getNodeName().trim().equals("#text"))
                length2++;
        }
        if (nl != null && length2 > fanout) {
            for (int i = 0; i < length; i++) {
                node.removeChild(nl.item(0));
            }
        }
    }

    private void attributesWork(Document doc, Node node) {
        NamedNodeMap attributes = node.getAttributes();
        if (attributes != null && !node.getNodeName().equals("titul")) {
            List<String> names = new ArrayList<String>();
            for (int i = 0; i < attributes.getLength(); i++) {
                String name = attributes.item(i).getNodeName();
                names.add(name);
                String value = attributes.item(i).getNodeValue();
                Node attNode = doc.createElement(name);
//                attNode.setNodeValue(value);
                attNode.setTextContent(value);
                node.appendChild(attNode);
            }
            for (String name : names) {
                attributes.removeNamedItem(name);
            }
        }
    }

    // prohodi jmena a prijmeni
    private void changeElementsPosition(Document doc) {
        NodeList names = doc.getElementsByTagName("jmeno");

        for (int i = 0; i < names.getLength(); i++) {
            Node nameNode = names.item(i);
            Node surnameNode = nameNode.getParentNode().getLastChild().getPreviousSibling();
            swapNodes(nameNode, surnameNode);
        }
    }


    private void swapNodes(Node a, Node b) {
        Node cloneA = a.cloneNode(true);
        Node cloneB = b.cloneNode(true);
        a.getParentNode().insertBefore(cloneB, a);
        b.getParentNode().insertBefore(cloneA, b);
        a.getParentNode().removeChild(a);
        b.getParentNode().removeChild(b);
    }

}
enum Work {
    ATTR, FANOUT(4), MIN_DEPTH(4), MIN_FANOUT(2);


    private int value;

    Work(int value) {
        this.value = value;
    }

    Work() {
    }


    public int getValue() {
        return value;
    }
}
