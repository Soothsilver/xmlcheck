package user; 

import org.w3c.dom.Document; 
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.*;

public class MyDomTransformer { 
	public void transform (Document xmlDocument) 
	{ 
	        
    	NodeList PersonalInfo = xmlDocument.getElementsByTagName("personal-info");
        for ( int i = 0; i < PersonalInfo.getLength(); i++ )  
        {
            Element info = (Element) PersonalInfo.item(i);
            Element parent = (Element)info.getParentNode();
            
            //if the parent is coach element, then switch name and surname elements
            if(parent.getTagName().equals("coach"))
            {
            	
            	NodeList infoNodes = info.getChildNodes();
            	Element name = (Element)infoNodes.item(1);
            	Element surname = (Element)(infoNodes.item(3));
            	
            	info.removeChild(surname);
            	info.insertBefore(surname, name);
            	
            	
            }
        }    
        
    }
}