package user; 

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler; 

public class MySaxHandler extends DefaultHandler 
{ // overrides of DefaultHandler methods     
    
     
    public void endDocument() throws SAXException {
        
        System.out.println("Count of activities with kilometers record: " + counter);
        System.out.println(letters);
        System.out.println("Average lenght description of an activity that contains kilometers record: " + letters/counter);
        
    }
    
    private int counter = 0;
    private boolean activityWithKM = false;
    private int letters = 0;
    
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        if(localName.equals("activity"))
        {
        	int kmIndex = atts.getIndex("km");
        	if(atts.getValue(kmIndex).equals("ano"))
        	{
        		counter++;
        		activityWithKM = true;
        	}
        }

    }
    
    public void endElement(String uri, String localName, String qName) throws SAXException {

        if(localName.equals("activity") && activityWithKM)
        {
        	activityWithKM = false;
        }
        	

    }
    
              
    public void characters(char[] ch, int start, int length) throws SAXException {

        if(activityWithKM)
        {
        	letters += length;
        }
        
    }
    
}
