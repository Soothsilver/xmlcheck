/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.io.File;
import java.util.HashMap;
import java.util.TreeMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;
import sun.org.mozilla.javascript.internal.ast.CatchClause;


public class MyDomTransformer {

    private void transform(Document doc) {
       
        /**
         * seřadí zaměstnance podle abecedy a přidá jim atribut id a do něj nastaví email
         */
        TreeMap<String, Element> zamestnanci = new TreeMap<String, Element>();
        NodeList z = doc.getElementsByTagName("zamestnanec");
        for (int i = 0; i < z.getLength(); i++) {
            String email = z.item(i).getChildNodes().item(7).getTextContent();
            ((Element)z.item(i)).setAttribute("id", email);
            
            zamestnanci.put(z.item(i).getChildNodes().item(1).getChildNodes().item(3).getTextContent(), (Element)z.item(i)) ;

        }
        NodeList osoby = doc.getElementsByTagName("osoby");
        int size = zamestnanci.size();
        for (int i = 0; i < size; i++) {
            String a =zamestnanci.firstKey();
           osoby.item(0).appendChild(zamestnanci.remove(a));
        }

        /**
         * Převede atribut název u elementu fitma na element název
         */
        NodeList firma = doc.getElementsByTagName("firma");
        for (int i = 0; i < firma.getLength(); i++) {
            
            Element signat = doc.createElement("nazev");
            signat.setTextContent(firma.item(i).getAttributes().item(0).getTextContent());
            firma.item(i).appendChild(signat);
            firma.item(i).getAttributes().removeNamedItem("nazev");
        }
        
        /**
         * Odstraní telefnoy které nepodporují mp3
         */
        NodeList mp3 = doc.getElementsByTagName("mp3");
        for (int i = 0; i < mp3.getLength(); i++) {
          if("false".equals(mp3.item(i).getTextContent())){
              Node telefon = mp3.item(i).getParentNode();
              Node znacka = telefon.getParentNode();
              znacka.removeChild(telefon);
          }
        }

    }
}
