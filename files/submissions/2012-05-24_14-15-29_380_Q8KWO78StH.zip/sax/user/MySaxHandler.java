package user;

import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;


public class MySaxHandler extends DefaultHandler{

    
    Locator locator;
    int posun;
    int pocetElementu = 0;
    int pocetAtr = 0;
    int pocetZnakuDoc = 0;
    boolean plat = false;
    int pocetPlatu = 0;
    int sumaPlatu = 0;
    int nejvissiPlat = 0;
    double prumPlat = 0;
    boolean pobocka = false;
    boolean nazev = false;
    boolean kontaktB = false;
    String[] nazevPobocky = new String[20];
    int[] pocetTelefonu = new int[20];
    int pocetPobocek = 0;
    String[] kontakt = new String[20];

    public void PrumPlat(int plat) {
        pocetPlatu++;
        sumaPlatu += plat;
        if (nejvissiPlat < plat) {
            nejvissiPlat = plat;
        }
        prumPlat = sumaPlatu / pocetPlatu;
    }

    public String posun(int a) {
        String b = "";
        for (int i = 0; i < a; i++) {
            b += " ";
        }
        return b;
    }

    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    @Override
    public void startDocument() throws SAXException {
        System.out.println("----------------------------------------------------");
        System.out.println("Vojtěch Hlavačka - Domácí úkol SAX");
        System.out.println("Výsledky jsou na konci výpisu.");
        System.out.println("----------------------------------------------------");
    }

    @Override
    public void endDocument() throws SAXException {
        System.out.println("----------------------------------------------------");
        System.out.println("Vojtěch Hlavačka - Domácí úkol SAX");
        System.out.println(" - Atributy jsem převedl na Elementy ");
        System.out.println(" - obsah elementu jsem převedl na velká písmena");
        System.out.println(" - Document jsem vypsal s znázorněním zanoření");
        System.out.println(" - Dále jsem vypsal názvy všech poboček kontakt na ně a ke každé jsem spočítal kolik vlastní telefonů");
        System.out.println(" - dále pak pocet zamestnanců nejvižší, průměrný plat a sumu platů");
        System.out.println(" - na konec jsem uved pocti znaků atributů a elementů");
        System.out.println("----------------------------------------------------");
        for (int i = 0; i < pocetPobocek; i++) {
            System.out.println("Nazev pobocky: " + nazevPobocky[i]);
            System.out.println("  -  Kontakt na pobocku: " + kontakt[i]);
            System.out.println("  -  Pocet telefonu ktere se na pobocce vyskytuji: " + pocetTelefonu[i]);
        }
        System.out.println("----------------------------------------------------");
        System.out.println("Pocet zamestnanců: " + pocetPlatu);
        System.out.println("Prumerný plat všech zamestnanců: " + prumPlat);
        System.out.println("Nejvissi plat ze zamestnanců: " + nejvissiPlat);
        System.out.println("Suma platu všech zamestnanců: " + sumaPlatu);
        System.out.println("----------------------------------------------------");
        System.out.println("Pocet Elementu: " + pocetElementu);
        System.out.println("Pocet attributu: " + pocetAtr);
        System.out.println("Pocet znaku XML dokumentu: " + pocetZnakuDoc);
        System.out.println("----------------------------------------------------");
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        System.out.println(posun(posun) + "<" + localName + ">");
        posun += 2;
        for (int i = 0; i < atts.getLength(); i++) {
            System.out.println(posun(posun) + "<" + atts.getLocalName(i) + ">" + atts.getValue(i) + "</" + atts.getLocalName(i) + ">");
            pocetAtr++;
        }
        pocetElementu++;
        if (localName == "plat") {
            plat = true;
        }
        if (localName == "pobocka") {
            pobocka = true;
            pocetPobocek++;
        }
        if (localName == "kontakt") {
            kontaktB = true;
        }
        if (localName == "telefon" && pobocka) {
            pocetTelefonu[pocetPobocek - 1] += 1;
        }
        if (localName == "nazev") {
            nazev = true;
        }

    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        posun -= 2;
        System.out.println(posun(posun) + "</" + qName + ">");
        if (localName == "plat") {
            plat = false;
        }
        if (localName == "pobocka") {
            pobocka = false;
        }
        if (localName == "kontakt") {
            kontaktB = false;
        }
        if (localName == "nazev") {
            nazev = false;
        }

    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        String s = "";
        for (int i = start; i < start + length; i++) {
            if (ch[i] == ' ' || ch[i] == '\n' || ch[i] == '	') {
            } else {
                s += ch[i];
            }
        }
        if (!s.equals("")) {
            s = s.toUpperCase();
            System.out.println(posun(posun) + s);
            if (plat == true) {
                PrumPlat(Integer.parseInt(s));
            }
            if (pobocka == true) {
                if (kontaktB) {
                    kontakt[pocetPobocek - 1] = s;
                } else if (nazev) {
                    nazevPobocky[pocetPobocek - 1] = s;
                }
            }

        }
        pocetZnakuDoc = ch.length;
        // ...

    }

    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    @Override
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        // ...
    }

    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

    @Override
    public void skippedEntity(String name) throws SAXException {
        // ...
    }
}