/*
 * Schvalene zadani: "pripravim transformaci, ktera zalozi novy stitek a priradi
 * jej ke vsem fotografiim z vybrane galerie".
 */

package user;

import org.w3c.dom.*;
import java.util.*;

public class MyDomTransformer
{
    
    public void transform(Document document)
    {
        Element souborstitku = getChild(document.getDocumentElement(), "soubor-stitku");
        List<Element> stitky = getChilds(souborstitku, "stitek");
        
        int maxid = 0;
        for (Element stitek : stitky)
        {
            String str = stitek.getAttributes().getNamedItem("id").getNodeValue();
            int val = Integer.parseInt(str.substring(1, str.length() - 1));
            maxid = Math.max(maxid, val);
        }

        Element novystitek = document.createElement("stitek");
        novystitek.setAttribute("id", String.format("s%ds", maxid + 1));
        novystitek.setAttribute("jmeno", "Nový štítek");
     
        souborstitku.appendChild(novystitek);
        
        Element galerie = document.getElementById("g1g");
        
        for (Element fotografie : getChilds(galerie, "fotografie"))
        {
            fotografie.setAttribute("stitky",
                    fotografie.getAttribute("stitky").concat(" " + novystitek.getAttribute("id")));
        }
        
        return;
    }
        
    private static Element getChild(Element parent, String name)
    {
        for (Node child = parent.getFirstChild(); child != null; child = child.getNextSibling())
            if ((child instanceof Element) && name.equals(child.getNodeName()))
                return ((Element) child);

        return null;
    }
    
    private static List<Element> getChilds(Element parent, String name)
    {
        List<Element> list = new ArrayList<Element>();
        
        for (Node child = parent.getFirstChild(); child != null; child = child.getNextSibling())
            if ((child instanceof Element) && name.equals(child.getNodeName()))
                list.add((Element) child);
        
        return list;
    }
    
}
