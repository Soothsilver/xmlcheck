/*
 * Schvalene zadani: "pripravim handler, ktery zjisti celkovy pocet slov ve
 * vsech textovych uzlech a vsech atributech".
 */

package user;

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

public class MySaxHandler extends DefaultHandler
{
    private enum State { A, B }
    private State state = State.A;
    private int letterCounter = 0;
    private int wordCounter = 0;
            
    public void startDocument() throws SAXException
    {
        return;
    }
    
    public void endDocument() throws SAXException
    {   
        System.out.println("XML document statistics:");
        System.out.println("************************");
        System.out.println();
        
        System.out.printf("\t- Number of letters:\t%d\n", letterCounter);
        System.out.printf("\t- Number of words:\t%d\n", wordCounter);
        System.out.printf("\t- Average word length:\t%.3f\n", ((float) letterCounter / wordCounter));
        System.out.println();
        
        return;
    }
    
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException
    {
        runFiniteStateMachine(' ');
        
        for (int i = 0, count = attributes.getLength(); i < count; ++i)
        {
            for (char c : attributes.getValue(i).toCharArray())
                runFiniteStateMachine(c);
            
            runFiniteStateMachine(' ');
        }
                    
        return;
    }
    
    public void endElement(String uri, String localName, String qName) throws SAXException
    {
        runFiniteStateMachine(' ');
        
        return;
    }
    
    public void characters(char[] text, int start, int length)
    {
        for (int i = start, end = (start + length); i < end; ++i)
            runFiniteStateMachine(text[i]);
        
        return;
    }
        
    private void runFiniteStateMachine(char c)
    {
        switch (state)
        {
            case A:
                if (Character.isLetterOrDigit(c))
                {
                    state = State.B;
                    ++letterCounter;
                    ++wordCounter;
                }
                break;
                
            case B:
                if (Character.isLetterOrDigit(c))
                    ++letterCounter;
                else
                    state = State.A;
                break;
                
            default:
                System.err.println("The finite state machine has reached an undefined state.");
                System.exit(1);
                break;
        }
        
        return;
    }
    
}
