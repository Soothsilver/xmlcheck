package user;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
// Following source will take care of materials
// that are exceeding value of 1.0 in any of the
// channels. Value for given channel is specified
// by sum in given channel across diffuse, specular
// and transmissive colour of the given material.

// Taking care means reseting value to 0.0 in given
// channel for diffuse, specular and transmissive
// component of the given material.

// If such situation occured, values had been reseted,
// then info comment is added above problematic material.


import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

public class MyDomTransformer
{
	public void transform (Document xmlDocument)
	{
		NodeList materials = xmlDocument.getElementsByTagName("material");
		for(int i = 0; i < materials.getLength(); ++i)
		{
			// Information comment is inserted if material element has been changed.
			if (transformMaterialNode(materials.item(i)))
			{
				Node infoComment = xmlDocument.createComment("Colour of following material element has been reseted to zero in some channel/s.");
				materials.item(i).getParentNode().insertBefore(infoComment, materials.item(i));
			}
		}
	}

	/**
     * Check whether the sum of child elements of material element
	 * is exceeding value of 1.0 in any channel or not. If yes,
	 * values of diffuse, transmissive and specular child elements
	 * are reseted to zero value in problematic channel.
     * @param material Node containing material element.
     */ 
	private Boolean transformMaterialNode (Node material)
	{
		double sumRed = 0.0;
		double sumGreen = 0.0;
		double sumBlue = 0.0;

		for (Node childNode = material.getFirstChild(); childNode != null; childNode = childNode.getNextSibling())
		{
			if (childNode.getNodeName() != "diffuse" &&
				childNode.getNodeName() != "specular" &&
				childNode.getNodeName() != "transmissive")
				continue;

			NamedNodeMap attributes = childNode.getAttributes();
			sumRed += Double.parseDouble(attributes.getNamedItem("r").getNodeValue());
			sumGreen += Double.parseDouble(attributes.getNamedItem("g").getNodeValue());
			sumBlue += Double.parseDouble(attributes.getNamedItem("b").getNodeValue());
		}

		Boolean resetRed = sumRed > 1.0;
		Boolean resetGreen = sumGreen > 1.0;
		Boolean resetBlue = sumBlue > 1.0;
		if (resetRed || resetGreen || resetBlue)
		{
			for (Node childNode = material.getFirstChild(); childNode != null; childNode = childNode.getNextSibling())
			{
			if (childNode.getNodeName() != "diffuse" &&
				childNode.getNodeName() != "specular" &&
				childNode.getNodeName() != "transmissive")
				continue;

				NamedNodeMap attributes = childNode.getAttributes();
				if (resetRed)
					attributes.getNamedItem("r").setNodeValue("0.0");
				if (resetGreen)
					attributes.getNamedItem("g").setNodeValue("0.0");
				if (resetBlue)
					attributes.getNamedItem("b").setNodeValue("0.0");
			}
			return true;
		}
		return false;
	}
}