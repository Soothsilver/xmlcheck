// Following source will print on standard output
// how much of the materials in input file has
// non zero diffuse "red" component of colour.

package user;

import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;

import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler
{
	private Boolean insideOfMaterialElement = false;
	private int countOfDiffuselyRedMaterials = 0;

	public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
	{
		if (localName == "material")
		{
			insideOfMaterialElement = true;
			return;
		}

		if (insideOfMaterialElement &&
			localName == "diffuse")
		{
			int indexOfRedAttribute = atts.getIndex("r");
			String stringValue = atts.getValue(indexOfRedAttribute);
			double doubleValue = Double.parseDouble(stringValue);

			if (doubleValue > 0.0)
			{
				++countOfDiffuselyRedMaterials;
			}
		}
    }

	public void endElement(String uri, String localName, String qName, Attributes atts) throws SAXException
	{
		if (localName == "material")
		{
			insideOfMaterialElement = false;
		}
    }

	public void endDocument() throws SAXException
	{
		System.out.println("The number of materials with non zero diffuse \"red\" component of colour in input file is " + countOfDiffuselyRedMaterials + ".");
    }
}