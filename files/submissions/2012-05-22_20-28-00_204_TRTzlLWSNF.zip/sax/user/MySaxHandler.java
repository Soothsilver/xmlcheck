package sax.user;

import java.util.HashMap;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Handler pro udalosti vyvolane behem parsovani XML dokumentu
 * @author bauermi2
 */
public class MySaxHandler extends DefaultHandler {

	private Document domDocument; 
	private DocumentBuilderFactory dbf;
	private Node current;
	private String content;
        private HashMap<String,Integer> histogram;
        
	/**
	 * @return strom XML dokumentu v DOM
	 */
	public Document getDomDocument() {
		return domDocument;
	}
        
        public HashMap<String,Integer> getDocStats() {
            return histogram;
        }
	
	public MySaxHandler() {
		dbf = DocumentBuilderFactory.newInstance();
                histogram = new HashMap<String,Integer>();
        }
	
	@Override
	public void characters(char[] arg0, int arg1, int arg2) throws SAXException {
		//elementContent.append(new String(arg0, arg1, arg2));
		content = new String(arg0, arg1, arg2);
	}

	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		current.appendChild(domDocument.createTextNode(content));
		current = current.getParentNode();
	}

	@Override
	public void startDocument() throws SAXException {
		try {
			DocumentBuilder builder = dbf.newDocumentBuilder();
			domDocument = builder.newDocument();
			domDocument.setXmlStandalone(true);
			domDocument.setXmlVersion("1.1");
			current = null;
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {
		Element el = domDocument.createElement(qName);
                if(histogram.containsKey(qName)) {
                    Integer cnt = histogram.get(qName);
                    cnt += 1;
                    histogram.remove(qName);
                    histogram.put(qName, cnt);
                }
                else {
                    histogram.put(qName, 1);
                }
		for (int i = 0; i <attributes.getLength(); i++) {
			el.setAttribute(attributes.getQName(i), attributes.getValue(i));
		}
		if(current != null)
			current.appendChild(el);
		else
			domDocument.appendChild(el);
		current = el;
		content = "";
	}
}
