/*
* Martin Lacina
* 
* p�id� do ka�d� kategorie jeden nov� pr�zdn� z�znam s unik�tn�m kl��em
*/

package user; 

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer {

	private Document doc;
  /**
   * Zpracuje DOM strom
   * Rozsiri strom do maximalnich moznych rozmeru nepovinnych elementu
   */
  public void transform (Document doc) {
    this.doc = doc;
	//overi nebo vytvori zakladni strukturu (bez poradi)
    Element root = CheckElementExistence(doc,"app-cestovni-prikazy");
    CheckCategories(root);
    
    //spocita hodnoty pro nova ID
    CountIDs(doc);
    
    
    //vytvori novy prazdny cestovni prikaz
    root.getElementsByTagName("klienti").item(0).appendChild(klientST());
    root.getElementsByTagName("pohonne-hmoty").item(0).appendChild(pohonnaHmotaST());
    root.getElementsByTagName("vozidla").item(0).appendChild(vozidloST());
    root.getElementsByTagName("cestovni-prikazy").item(0).appendChild(cestovniPrikazST());    
  }
  
  
  private Element CheckElementExistence(Node parrent, String Name){
      org.w3c.dom.NodeList list;
      list = parrent.getChildNodes();
      if (list.getLength() == 0){//pokud opravdu neexistuje rovnou pridat
        Element elem;
        elem = BaseElement(Name);
        parrent.appendChild(elem);
        return elem;
      }
      else {
        //check
        for(int i= 0; i < list.getLength(); ++i){
          if ((list.item(i).getNodeType() == Element.ELEMENT_NODE ) && (((Element)list.item(i)).getTagName() == Name ) ){
            return (Element)list.item(i);
          } 
        }
        //vytvorime novy a vlozime jej
        Element insert = doc.createElement(Name);
        parrent.appendChild(insert);                
        return insert;
      }
  }
  
  private void CheckCategories(Element root){
      CheckElementExistence(root, "klienti");
      CheckElementExistence(root, "pohonne-hmoty");
      CheckElementExistence(root, "vozidla");
      CheckElementExistence(root, "cestovni-prikazy");
      CheckElementExistence(root, "intrukce");
  }
  
  private int klientID = 0;
  private int phmID = 0;
  private int vozidlaID = 0;
  private int cestovniPrikazyID = 0;
  
  private String KlientID (){ return "o"+FormatToLength( ++klientID);};
  private String PhmID (){ return "p"+FormatToLength( ++phmID);};
  private String VozidlaID (){ return "v"+FormatToLength( ++vozidlaID);};
  private String CestovniPrikazyID (){ return "cp"+FormatToLength( ++cestovniPrikazyID);};

  private String FormatToLength(int value){
    String base = ""+value;
    for (int i = 4 - base.length(); i > 0; --i){
      base = "0"+base;
    }
    return base;
  }

  private void CountIDs(Document doc){
    klientID = GetHighestID(doc.getElementsByTagName("klient"),1);
    phmID = GetHighestID(doc.getElementsByTagName("pohonna-hmota"),1);
    vozidlaID = GetHighestID(doc.getElementsByTagName("vozidlo"),1);
    cestovniPrikazyID = GetHighestID(doc.getElementsByTagName("cestovni-prikaz"),2);
  }

  private int GetHighestID(NodeList list, int prefix){
    int ID = 0;
    for (int i = 0; i < list.getLength() ; ++i){
      try
          {
      String id = ((Element)list.item(i)).getAttribute("id");
      id = id.substring(prefix);
      int current = Integer.parseInt(id);
      if (current > ID)
        ID = current;
        } catch (Exception e){}
    }
    return ID;
  }
   /*ID noveho zaznamu bych si mohl spocitat! */
  private Element BaseElement(String Name){
    Element result = doc.createElement(Name);
    return result;
  }
  /*Klienti*/
  private Element klientST(){
    Element result = doc.createElement("klient");
    // pridat atribut id 
    result.setAttribute("id",KlientID());
    result.appendChild(osobniInformaceST());
    result.appendChild(kontaktniInformaceST());
    result.appendChild(ostatniInformaceST());
    return result;
  }
  private Element osobniInformaceST(){
    Element result = doc.createElement("osobni-informace");
    result.appendChild(jmenoST());
    return result;
  }
  private Element jmenoST(){
    Element result = doc.createElement("jmeno");
    // pridat atributy jmeno, krestni, krestni2, prijmeni, titul-pred-jmenem, titul-uprostred, titul-za-jmenem 
    result.setAttribute("jmeno","");
    result.setAttribute("krestni","");
    result.setAttribute("krestni2","");
    result.setAttribute("prijmeni","");
    result.setAttribute("titul-pred-jmenem","");
    result.setAttribute("titul-uprostred","");
    result.setAttribute("titul-za-jmenem","");
    return result;
  }
  private Element kontaktniInformaceST(){
    Element result = doc.createElement("kontaktni-informace");
    result.appendChild(adresyST());
    result.appendChild(telefonyST());
    return result;
  }
  private Element adresyST(){
    Element result = doc.createElement("adresy");
    result.appendChild(adresaST());
    return result;
  }
  private Element adresaST(){
    Element result = doc.createElement("adresa");
    // pridat atributy adresa, ulice, cp, mesto, psc, stat 
    result.setAttribute("adresa","");
    result.setAttribute("ulice","");
    result.setAttribute("cp","");
    result.setAttribute("psc","");
    result.setAttribute("stat","");
    return result;
  }
  private Element telefonyST(){
    Element result = doc.createElement("telefony");
    result.appendChild(telefonST());
    return result;
  }
  private Element telefonST(){
    Element result = doc.createElement("telefon");
    result.setAttribute("mezinarodni-predvolba","");
    result.setAttribute("telefonni-cislo","");
    result.setAttribute("linka","");
    return result;
  }
  private Element ostatniInformaceST(){
    Element result = doc.createElement("ostatni-informace");
    result.appendChild(cislaUctuST());
    result.appendChild(pracovniDobaST());
    result.appendChild(poznamkaST());
    return result;
  }
  private Element cislaUctuST(){
    Element result = doc.createElement("cisla-uctu");
    result.appendChild(cisloUctuST());
    return result;
  }
  private Element cisloUctuST(){
    Element result = doc.createElement("cislo-uctu");
    result.setAttribute("ucet","");
    result.setAttribute("kod-banky","");
    return result;
  }
  private Element pracovniDobaST(){
    Element result = doc.createElement("pracovni-doba");
    result.appendChild(odST());
    result.appendChild(doST());
    return result;
  }
  private Element doST(){
    Element result = doc.createElement("od");
    result.appendChild(timeST());
    return result;
  }
  private Element odST(){
    Element result = doc.createElement("od");
    result.appendChild(timeST());
    return result;
  }
  /*PHM*/
  private Element pohonnaHmotaST(){
    Element result = doc.createElement("pohonna-hmota");
    result.appendChild(nazevPhmST());
    result.appendChild(rocniVyhlaskaST());
    result.setAttribute("id",PhmID());
    return result;
  }
  private Element nazevPhmST(){
    return GenericTextST("nazev-phm");
  }
  private Element rocniVyhlaskaST(){
    Element result = doc.createElement("rocni-vyhlaska");
    result.appendChild(platnostOdST());
    result.appendChild(platnostDoST());
    result.appendChild(jednotkovaCenaST());
    return result;
  }
  private Element platnostOdST(){
    Element result = doc.createElement("platnost-od");
    result.appendChild(dateST());
    return result;
  }
  private Element platnostDoST(){
    Element result = doc.createElement("platnost-do");
    result.appendChild(dateST());
    return result;
  }
  private Element jednotkovaCenaST(){
    return GenericTextST("jednotkova-cena");
  }
  /*Vozidla*/
  private Element vozidloST(){
    Element result = doc.createElement("vozidlo");
    // pridat id atribut s prazdnou hodnotou nebo s v0000, coz upresni format 
    result.setAttribute("id",VozidlaID());
    // pridat typ-phm atribut s prazdnou hodnotou nebo s p0000, coz upresni format pro DTD 
    result.setAttribute("typ-phm","p0000");
    result.appendChild(spzST());
    result.appendChild(typST());
    result.appendChild(cisloTpST());
    result.appendChild(majitelST());
    result.appendChild(prumernaSpotrebaST());
    result.appendChild(poznamkaST());
    return result;
  }
  private Element spzST(){
    return GenericTextST("typ");
  }
  private Element typST(){
    return GenericTextST("typ");
  }
  private Element cisloTpST(){
    return GenericTextST("cislo-tp");
  }
  private Element majitelST(){
    Element result = doc.createElement("majitel");
    result.appendChild(textST());
    return result;
  }
  private Element prumernaSpotrebaST(){
    return GenericTextST("prumernaSpotreba");
  }
  /*Cestovni prikaz*/
  private Element cestovniPrikazST(){
    Element result = doc.createElement("cestovni-prikaz");
    // pridat id atribut s prazdnou hodnotou nebo s cp0000, coz upresni format 
    result.setAttribute("id", CestovniPrikazyID());
    // pridat klient atribut s prazdnou hodnotou nebo s o0000, coz upresni format pro DTD 
    result.setAttribute("klient","o0000");
    result.appendChild(prikazST());
    result.appendChild(vyuctovaniST());
    result.appendChild(poznamkaST());
    return result;
  }
  private Element prikazST(){
    Element result = doc.createElement("prikaz");
    result.appendChild(datumVytvoreniPrikazuST());
    result.appendChild(datumSouhlasuZamestnanceSCestouST());
    result.appendChild(urcenyDopravniProstredekST());
    result.appendChild(predpokladanaCastkaVydajuST());
    result.appendChild(zalohaST());
    result.appendChild(datumPovoleniCestyST());
    result.appendChild(povolilST());
    result.appendChild(predepsaneCestyST());
    return result;
  }
  private Element datumVytvoreniPrikazuST(){
    Element result = doc.createElement("datum-vytvoreni-prikazu");
    result.appendChild(datetimeST());
    return result;
  }
  private Element datumSouhlasuZamestnanceSCestouST(){
    Element result = doc.createElement("datum-souhlasu-zamestnance-s-cestou");
    result.appendChild(dateST());
    return result;
  }
  private Element predpokladanaCastkaVydajuST(){
    return GenericTextST("predpokladana-castka-vydaju");
  }
  private Element zalohaST(){
    Element result = doc.createElement("zaloha");
    result.appendChild(datumVydaniZalohyST());
    result.appendChild(obnosST());
    result.appendChild(cisloPokladnihoDokladuST());
    return result;
  }
  private Element datumVydaniZalohyST(){
    Element result = doc.createElement("datum-vydani-zalohy");
    result.appendChild(dateST());
    return result;
  }
  private Element obnosST(){
    return GenericTextST("obnos");
  }
  private Element cisloPokladnihoDokladuST(){
    return GenericTextST("cislo-pokladniho-dokladu");
  }
  private Element datumPovoleniCestyST(){
    Element result = doc.createElement("datum-povoleni-cesty");
    result.appendChild(dateST());
    return result;
  }
  private Element povolilST(){
    Element result = doc.createElement("povolil");
    result.appendChild(textST());
    return result;
  }
  
  private Element predepsaneCestyST(){
    Element result = doc.createElement("predepsane-cesty");
    //prida jednu predepsanou cestu
    result.appendChild(predepsanaCestaST());
    return result;
  }
  private Element predepsanaCestaST(){
    Element result = doc.createElement("predepsana-cesta");
    result.appendChild(pocatekCestyST());
    result.appendChild(mistoJednaniST());
    result.appendChild(ucelCestyST());
    result.appendChild(dobaTrvaniST());
    result.appendChild(konecCestyST());
    return result;
  }
  private Element pocatekCestyST(){
    Element result = doc.createElement("pocatek-cesty");
    result.appendChild(mistoST());
    result.appendChild(dateST());
    result.appendChild(timeST());
    return result;
  }
  private Element mistoJednaniST(){
    return GenericTextST("misto-jednani");
  }
  private Element ucelCestyST(){
    return GenericTextST("ucel-cesty");
  }
  private Element dobaTrvaniST(){
    return GenericTextST("doba-trvani");
  }
  private Element konecCestyST(){
    Element result = doc.createElement("konec-cesty");
    result.appendChild(mistoST());
    result.appendChild(dateST());
    return result;
  }
  private Element vyuctovaniST(){
    Element result = doc.createElement("vyuctovani");
    result.appendChild(datumPodaniVyuctovaniST());
    result.appendChild(uctovaneCestyST());
    result.setAttribute("bezplatne-stravovani","ne");
    result.setAttribute("bezplatne-ubytovani","ne");
    result.setAttribute("volna-zlevnena-jizdenka","ne");
    result.setAttribute("odlucne","ne");
    return result;
  }
  private Element datumPodaniVyuctovaniST(){
    Element result = doc.createElement("datum-podani-vyuctovani");
    result.appendChild( dateST() );
    return result;
  }
  private Element uctovaneCestyST(){
    Element result = doc.createElement("uctovane-cesty");
    //vygeneruje jednu prazdnou uctovanou cestu autobusem
    result.appendChild(uctovanaCestaST());
    return result;
  }
  private Element urcenyDopravniProstredekST(){
    Element result = doc.createElement("urceny-dopravni-prostredek");
    //necht se vzdy cestuje autobusem
    result.appendChild(doc.createElement("typ_A"));
    return result;
  }
  private Element uctovanaCestaST(){
    Element result = doc.createElement("uctovana-cesta");
    result.appendChild( datumCestyST() );
    result.appendChild( odjezdZST() );
    result.appendChild( prijezdDoST() );
    result.appendChild( odjezdZHodST() );
    result.appendChild( prijezdDoHodST() );
    result.appendChild( urcenyDopravniProstredekST() );
    result.appendChild( vzdalenostST() );
    result.appendChild( jizdneST() );
    result.appendChild( stravneST() );
    result.appendChild( noclezneST() );
    result.appendChild( vedlejsiVydajeST() );
    result.appendChild( poznamkaST() );
    return result;
  }
  private Element datumCestyST(){
    Element result = doc.createElement("datum-cesty");
    result.appendChild( dateST() );
    return result;
  }
  private Element odjezdZST(){
    Element result = doc.createElement("odjezd-z");
    result.appendChild( mistoST() );
    return result;
  }
  private Element prijezdDoST(){
    Element result = doc.createElement("prijezd-do");
    result.appendChild( mistoST() );
    return result;
  }
  private Element prijezdDoHodST(){
    Element result = doc.createElement("prijezd-do-hod");
    result.appendChild( timeST() );
    return result;
  }
  private Element odjezdZHodST(){
    Element result = doc.createElement("odjezd-z-hod");
    result.appendChild( timeST() );
    return result;
  }
  private Element vzdalenostST(){
    return GenericTextST("vzdalenost");
  }
  private Element jizdneST(){
    return GenericTextST("jizdne");
  }
  private Element stravneST(){
    return GenericTextST("stravne");
  }
  private Element noclezneST(){
    return GenericTextST("noclezne");
  }
  private Element vedlejsiVydajeST(){
    return GenericTextST("vedlejsi-vydaje");
  }
  private Element poznamkaST(){
    return GenericTextST("poznamka");
  }
  private Element datetimeST(){
    Element result = doc.createElement("datetime");
    result.appendChild( dateST() );
    result.appendChild( timeST() );      
    return result;
  }
  private Element dateST(){
    return GenericTextST("date");
  }
  private Element timeST(){
    return GenericTextST("time");
  }
  private Element mistoST(){
    return GenericTextST("misto");
  }
  private Element textST(){
    return GenericTextST("text");
  }
  private Element GenericTextST(String elemName){
    Element result = doc.createElement(elemName); 
    // pridat mezeru do textu
    result.appendChild(doc.createTextNode(" "));       
    return result;
  }
}

