/*
* Martin Lacina
* 
* pro XML dokument spo�te n�sleduj�c� charakteristiku:
* Nejvetsi pocet predepsanych cest na jednom cestovnim prikazu
* 
* */
package user;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

	
public class MySaxHandler extends DefaultHandler {
    //predpona t_ u prommenne znaci pomocnou promennou pro aktualni uroven
    //pocet cest cetovniho prikazu
    //cest v cestovnim prikazu
    int t_pocetCestA = 0; 
    int pocetCestA = 0; // cest celkem
    int pocetCestAMax = 0;
               
    /**
     * Obsluha ud�losti "konec dokumentu" - vytiskneme vysledek.
     */
    @Override
    public void endDocument() throws SAXException {
        printStatistics();
    }
    

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        // predepsane cesty
        // inicializace vypoctu
        if (qName.equals("predepsane-cesty")){
            t_pocetCestA = 0;
        }
        //pricteni nove predepsane cesty
        if (qName.equals("predepsana-cesta")){
            ++t_pocetCestA;
        }
            
    }
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        
        // cesty typu A, tj. predepsane
        // inicializace vypoctu
        if (qName.equals("predepsane-cesty")){
            pocetCestA += t_pocetCestA;
            if (t_pocetCestA > pocetCestAMax)
              pocetCestAMax = t_pocetCestA;
        }
            
    }
    
    private void printStatistics() {
      System.out.println("Nejvetsi pocet predepsanych cest na jednom cestovnim prikazu: " + pocetCestAMax );
    }    
}
