package user;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/* 
 * SAX default handler 
 * 
 * Counts number of elements and attributes
 */
public class MySaxHandler extends DefaultHandler 
{
    private Integer m_elementCount;
    private Integer m_attributeCount;
    
    public void startDocument() throws SAXException
    {
        this.m_elementCount = 0;
        this.m_attributeCount = 0;
    }
    
    public void endDocument() throws SAXException
    {
        System.out.printf("Element count: %d\n", this.m_elementCount);
        System.out.printf("Attribute count: %d\n", this.m_attributeCount);
    }
  
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException 
    {
        this.m_elementCount++;
        this.m_attributeCount += atts.getLength();
    }
}
