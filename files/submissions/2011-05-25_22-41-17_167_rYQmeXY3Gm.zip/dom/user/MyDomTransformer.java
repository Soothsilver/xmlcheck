package user;

import java.util.ArrayList;
import java.util.Iterator;
import org.w3c.dom.*;

/*
 * DOM transformation 
 * 
 * Converts attributes to child text elements. 
 * @note: If DTD specifies attribute as set of values, than it will be set to default.
 */
public class MyDomTransformer {
    
    private Document m_xmlDocument;

    public void transform (Document xmlDocument) 
    {
        // save document
        this.m_xmlDocument = xmlDocument;
        
        // Root elememnt
        Element rootElement = xmlDocument.getDocumentElement();
        
        // examine whole tree
        this.examineNode(rootElement);
    }
    
    private void examineNode (Element xmlNode)
    {
        // create new elemenet
        ArrayList<Element> newElements = new ArrayList<Element>();
        NamedNodeMap atts = xmlNode.getAttributes();
        
        // get throught all attributes
        for (int i = 0; i < atts.getLength(); i++) {
            
            // get attribute
            String name = atts.item(i).getNodeName();
            Attr attribute = xmlNode.getAttributeNode(name);
            
            // create new element
            Element element = m_xmlDocument.createElement(attribute.getName());
            element.setTextContent(attribute.getValue());
            
            // save new element
            newElements.add(element);
        }

        // get all child elements
        NodeList childList = xmlNode.getChildNodes();
        for (int i = 0; i < childList.getLength(); i++) {
            if (xmlNode.ELEMENT_NODE == childList.item(i).getNodeType())
            {
                examineNode((Element)childList.item(i));
            }
        }
        
        // append new elements & remove corresponding attribute
        Node firstChild = xmlNode.getFirstChild();
        for (Iterator<Element> it = newElements.iterator(); it.hasNext();) 
        {
            // get element & append to node
            Element element = it.next();
            
            // append element
            if (null == firstChild) { xmlNode.appendChild(element); } else { xmlNode.insertBefore(element, firstChild); }
            
            // remove attribute
            xmlNode.removeAttribute(element.getNodeName());
        }
    }
}