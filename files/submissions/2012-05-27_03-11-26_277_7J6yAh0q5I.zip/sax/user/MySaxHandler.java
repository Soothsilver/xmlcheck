package user;

import java.util.LinkedList;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {

	static int depth = 0;
	static int subElementCount = 0;
	static LinkedList<Integer> attCountList = new LinkedList<Integer>();
	static LinkedList<Integer> elemNameLenthList = new LinkedList<Integer>();
	static LinkedList<Integer> deepList = new LinkedList<Integer>();
	static LinkedList<Integer> deepList2 = new LinkedList<Integer>();
	static int count;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.xml.sax.helpers.DefaultHandler#endDocument()
	 */
	@Override
	public void endDocument() throws SAXException {
		// TODO Auto-generated method stub
		super.endDocument();

		System.out.println("Number of elements is " + count);

		float avg = 0;
		for (int i : deepList) {
			avg += i;
		}
		avg /= deepList.size();
		System.out.println("Average deep of elements is " + avg);

		avg = 0;
		for (int i : attCountList) {
			avg += i;
		}
		avg /= attCountList.size();
		System.out.println("Average count of element attributes is " + avg);

		count = 0;
		for (int i : elemNameLenthList) {
			if (i > count) {
				count = i;
			}
		}
		System.out.println("Maximum length of element name is " + count);

		count = 0;
		for (int i : attCountList) {
			if (i == 0) {
				count++;
			}
		}
		System.out.println("Number of elements without attributes is " + count);

		count = 0;
		depth = 0;
		for (int i : deepList2) {
			if (i > depth) {
				count++;
			}
			depth = i;
		}
		System.out.println("Number of elements which have subelement is " + count);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.xml.sax.helpers.DefaultHandler#startElement(java.lang.String,
	 * java.lang.String, java.lang.String, org.xml.sax.Attributes)
	 */
	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		// TODO Auto-generated method stub
		super.startElement(uri, localName, qName, attributes);
		attCountList.add(attributes.getLength());
		elemNameLenthList.add(localName.length());

		depth++;
		count++;
		deepList.add(depth);
		deepList2.add(depth);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.xml.sax.helpers.DefaultHandler#endElement(java.lang.String,
	 * java.lang.String, java.lang.String)
	 */
	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		// TODO Auto-generated method stub
		super.endElement(uri, localName, qName);
		deepList2.add(depth);
		depth--;
	}

	// override metod DefaultHandleru

	// public static void main(String[] args) {
	// try {
	// XMLReader xreader = XMLReaderFactory.createXMLReader();
	// InputSource source = new InputSource("D:/library.xml");
	// xreader.setContentHandler(new MySaxHandler());
	//
	// xreader.parse(source);
	//
	// } catch (Exception e) {
	// // TODO: handle exception
	// }
	// }

}