package user;

import java.io.FileInputStream;
import java.io.StringWriter;
import java.util.LinkedList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

public class MyDomTransformer {

	public static LinkedList<String> list = new LinkedList<String>();

	public static void transform(Document xmlDocument1) {
		xmlDocument1 = transform1(xmlDocument1);

//		TransformerFactory transformerFactory = TransformerFactory.newInstance();
//		Transformer transformer = null;
//		try {
//			transformer = transformerFactory.newTransformer();
//		} catch (TransformerConfigurationException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
//		DOMSource source = new DOMSource(xmlDocument1);
//
//		StringWriter sw = new StringWriter();
//		StreamResult result = new StreamResult(sw);
//		try {
//			transformer.transform(source, result);
//		} catch (TransformerException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//		System.out.println(sw.toString());

	}

	public static Document transform1(Document xmlDocument) {
		// libovolne transformace objektu 'xmlDocument'
		// (metoda pracuje primo na objektu, nic nevraci)

		recursive((org.w3c.dom.Node) xmlDocument.getDocumentElement());

		// for (String str : list) {
		// System.out.println(str);
		// }

		try {
			// xmlDocument =
			// DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
			xmlDocument.removeChild(xmlDocument.getFirstChild());
			Element root = xmlDocument.createElement("AllNames");
			xmlDocument.appendChild(root);

			for (String str : list) {
				Element name = xmlDocument.createElement("Name");
				Text text = xmlDocument.createTextNode(str);
				name.appendChild(text);
				root.appendChild(name);
			}

		} catch (Exception e) {

		}

		return xmlDocument;

	}

	public static void recursive(org.w3c.dom.Node n) {
		for (int i = 0; i < n.getChildNodes().getLength(); i++) {
			org.w3c.dom.Node node = n.getChildNodes().item(i);
			chroustej(node);
			recursive(n.getChildNodes().item(i));
		}

	}

	public static void chroustej(org.w3c.dom.Node e) {
		String meno, priezvisko;
		org.w3c.dom.Node n;
		if (e.getNodeName().equals("jmeno")) {
			meno = e.getTextContent();
			n = e;
			while (true) {
				if (n == null)
					break;
				if (n.getNodeName().equals("prijmeni")) {
					priezvisko = n.getTextContent();
					list.add(meno + " " + priezvisko);
					break;
				}
				n = n.getNextSibling();

			}
		}
	}
//
//	public static void main(String[] args) {
//		try {
//
//			DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
//
//			FileInputStream is = new FileInputStream("D:/library.xml");
//			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
//			DocumentBuilder db = dbf.newDocumentBuilder();
//			Document xml = db.parse(is);
//			transform(xml);
//
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
}