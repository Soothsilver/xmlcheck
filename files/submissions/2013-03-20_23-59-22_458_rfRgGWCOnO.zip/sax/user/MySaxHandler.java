package user;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
/**
 * 1. najde serial s nejdelsim jmenem
 * 2. najde serial s nejvice regexy
 * 3. najde vsechny seraily, ktere maji atribut nameFormat
 * @author SB
 */
class MySaxHandler extends DefaultHandler {

	String currentSerialName = null;
	boolean inSerial = false;
	int nodesWithNF = 0;
	int serialMaxNameLength = 0;
	boolean inNameNode = false;
	boolean inRegexsNode = false;
	int numOfRegex = 0;
	String serailWithmostRegexs = null;
	int maxNumOfRegex = 0;


	/**
	 * Method to handle "document start"
	 *
	 * @throws SAXException
	 */
	@Override
	public void startDocument() throws SAXException {
		// ...
	}

	/**
	 * Method to handle "document end"
	 *
	 * @throws SAXException
	 */
	@Override
	public void endDocument() throws SAXException {
		// ...
	}

	/**
	 * Method to handle "begin element"
	 *
	 * @param uri URI of the element namespace (empty if element is no
	 * namespace)
	 * @param localName local name of the element (never empty)
	 * @param qName qualified name (prefix-URI + ':' + localName, if the element
	 * is in some namespace or localName otherwise)
	 * @param atts Element's attributes
	 * @throws SAXException
	 */
	@Override
	public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

		if (localName.equals("serial")) {
			//this.currentSerialName = localName;
			this.inSerial = true;
			String nf = atts.getValue("nameFormat");

			if (nf != null) {
				this.nodesWithNF++;
			}
		}

		if (localName.equals("name") && this.inSerial) {
			this.inNameNode = true;
		}

		if (localName.equals("regexs") && this.inSerial) {
			this.inRegexsNode = true;
		}

		if (localName.equals("regex") && this.inRegexsNode) {
			this.numOfRegex++;
		}
	}

	/**
	 * Method to handle "element end"
	 *
	 * @param uri URI of the element namespace (empty if element is no
	 * namespace)
	 * @param localName local name of the element (never empty)
	 * @param qName qualified name (prefix-URI + ':' + localName, if the element
	 * is in some namespace or localName otherwise)
	 * @param atts Element's attributes
	 * @throws SAXException
	 */
	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		if (localName.equals("serial")) {
			this.inSerial = false;
		}

		if (localName.equals("name")) {
			this.inNameNode = false;
		}

		if (localName.equals("regexs")) {
			this.inRegexsNode = false;
			if (this.numOfRegex > this.maxNumOfRegex) {
				this.serailWithmostRegexs = this.currentSerialName;
				this.maxNumOfRegex = this.numOfRegex;
			}

			this.numOfRegex = 0;
		}

	}

	/**
	 * Method to handle "character data" SAX parser can process data in various
	 * batches. so we can't rely that whole whole text content will be delivered
	 * in one call Text is in array 'chars' from position ('start') to ('start'
	 * + 'length' - 1)
	 *
	 * @param chars Array with char data
	 * @param start Index of the begin of valid data
	 * @param length Length of the valid data
	 * @throws SAXException
	 */
	@Override
	public void characters(char[] chars, int start, int length) throws SAXException {
		if (this.inSerial && this.inNameNode) {
			if (length > this.serialMaxNameLength) {
				this.serialMaxNameLength = length;

			}

			String name = "";
			for (int i = start; i < start + length; i++) {
				name += chars[i];
			}

			this.currentSerialName = name;
		}

	}

	/**
	 * Method to handle " start of namespace declaration"
	 *
	 * @param prefix Prefix of the namespace
	 * @param uri URI of the namespace
	 * @throws SAXException
	 */
	@Override
	public void startPrefixMapping(String prefix, String uri) throws SAXException {
		// ...
	}

	/**
	 * Method to handle "end of namespace declaration"
	 *
	 * @param prefix
	 * @throws SAXException
	 */
	@Override
	public void endPrefixMapping(String prefix) throws SAXException {
		// ...
	}

	/**
	 * Method to handle "ignoring of whitespaces" Text is in array 'chars' from
	 * position ('start') to ('start' + 'length' - 1)
	 *
	 * @param chars Array with char data
	 * @param start Index of the begin of valid data
	 * @param length Length of the valid data
	 * @throws SAXException
	 * @throws SAXException
	 */
	@Override
	public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
		// ...
	}

	/**
	 * Method to handle "processing instructions"
	 *
	 * @param target The processing instruction target
	 * @param data The processing instruction data
	 * @throws SAXException
	 */
	@Override
	public void processingInstruction(String target, String data) throws SAXException {
		// ...
	}

	/**
	 * Method to handle "unprocessed entity"
	 *
	 * @param name
	 * @throws SAXException
	 */
	@Override
	public void skippedEntity(String name) throws SAXException {
		// ...
	}
}