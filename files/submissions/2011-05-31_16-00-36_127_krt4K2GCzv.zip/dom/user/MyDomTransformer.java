package user;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer {
	
	/**
	 * Serazeni prestupku podle poctu bodu.
	 * 
	 * Pokud nejaky prestupek neni ohodnocen body, tak je jeho hodnota 
	 * povazovana za nula bodu.
	 * 
	 * @param n Uzel s prestupky.
	 */
	private void sortPrestupky(Node n) {
		List<Node> childNodes = new ArrayList<Node>();
		NodeList children = n.getChildNodes();
		
		// Prekopirovani prestupku pro razeni
		for (int i = 0; i < children.getLength(); i++) {
			Node child = children.item(i);
			// Berou se pouze elementy
			if (child.getNodeType() == Node.ELEMENT_NODE) {
				childNodes.add(children.item(i));
			}
		}
		
		// Serazeni prestupky podle bodu
		Collections.sort(childNodes, new Comparator<Node>() {

			public int compare(Node o1, Node o2) {
				// Ziskani atributu body, muze se stat, ze nebude nalezen
				Node o1b = o1.getAttributes().getNamedItem("body");
				Node o2b = o2.getAttributes().getNamedItem("body");
				
				// Prestupky bez bodu budeme povazovat za prestupky s 0 body
				int o1body = 0;
				int o2body = 0;
				
				// Parsovani poctu bodu
				if (o1b != null) {
					o1body = Integer.parseInt(o1b.getTextContent());
				}
				if (o2b != null) {
					o2body = Integer.parseInt(o2b.getTextContent());
				}
				
				// Vratime patricnou hodnotu podle toho, ktery prestupek ma 
				// vice bodu
				return o1body - o2body;
			}
			
		});
		
		// Aktualizace uzlu ve stromu. Pri appendu se uzly odeberou a znova 
		// pridaji v takovem poradi, v jakem jsou serazeny
		for (Node node : childNodes) {
			n.appendChild(node);
		}
	}
	
	/**
	 * Transformace dokumentu.
	 * 
	 * Dojde k serazeni prestupku podle prirazenych poctu bodu
	 * 
	 * @param xmlDocument Dokument, ktery bude modifikovan
	 */
	public void transform(Document xmlDocument) {
		// Nalezneme vsechny prestupky
		NodeList nl = xmlDocument.getElementsByTagName("prestupky");
		for (int i = 0; i < nl.getLength(); i++) {
			Node n = nl.item(i);
			// Seradime prestupky
			sortPrestupky(n);
		}
	}
}
