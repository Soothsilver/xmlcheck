package user;

import java.util.LinkedList;
import java.util.List;

import javax.print.attribute.standard.PresentationDirection;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Vypocitani prumerneho poctu prestupku na ridice a take prumerneho poctu 
 * bodu za prestupek. 
 *
 */
public class MySaxHandler extends DefaultHandler {
	
	// Seznam poctu prestupku pro jednotlive ridice
	private List<Integer> poctyPrestupku;
	// Citac prestupku pro aktualniho ridice
	private int pocetPrestupkuRidice;
	
	// Seznam bodu za vsechny 
	private List<Integer> body;
	
	/**
	 * Zpracovani zacatku dokumentu.
	 * 
	 * Probehne inicializace potrebnych promennych.
	 */
	@Override
	public void startDocument() throws SAXException {
		poctyPrestupku = new LinkedList<Integer>();
		body = new LinkedList<Integer>();
	}
	
	/**
	 * Konec dokumentu.
	 * 
	 * Budou spocitany charakteristiky dokumentu, prumerny pocet prestupku na 
	 * ridice a prumerny pocet bodu za prestupek. Pro prumer bodu za prestupek 
	 * se vynechavaji neobodovane prestupky.
	 */
	@Override
	public void endDocument() throws SAXException {
		int sum = 0;
		// Secteni vsech prestupku
		for (Integer i : poctyPrestupku) {
			sum += i;
		}
		
		// Zprumerovani poctu prestupku
		double prumer = (double) sum / poctyPrestupku.size();
		System.out.printf("Průměrný počet přestupků na řidiče je %.1f.\n", prumer);
		
		sum = 0;
		// Secteni vsech bodu
		for (Integer i : body) {
			sum += i;
		}
		
		// Zprumerovani bodu za prestupek
		prumer = (double) sum / body.size();
		System.out.printf("Průměrné bodové ohodnocení přestupku je %.1f bodů.\n", prumer);
	}
	
	/**
	 * Zpracovani zacatku elementu.
	 * 
	 * Pokud jde o noveho ridice, tak se musi inicializovat pocet jeho 
	 * prestupku na 0. Pokud jde o novy prestupek, tak se musi pridat k 
	 * aktualnimu ridici a pridat body.
	 */
	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {
		// Zpracovani noveho ridice
		if (qName.equals("ridic")) {
			pocetPrestupkuRidice = 0;
		// Zpracovani noveho prestupku
		} else if (qName.equals("prestupek")) {
			pocetPrestupkuRidice += 1;
			// Parsovani a ulozeni bodu za dany prestupek
			String bodyPrestupku = attributes.getValue("body");
			if (bodyPrestupku != null) {
				body.add(Integer.parseInt(bodyPrestupku));
			}
		}
	}
	
	/**
	 * Zpracovani konce elementu.
	 * 
	 * Pro ridice dojde k ulozeni poctu jeho prestupku.
	 */
	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		if (qName.equals("ridic")) {
			poctyPrestupku.add(pocetPrestupkuRidice);
		}
	}
}
