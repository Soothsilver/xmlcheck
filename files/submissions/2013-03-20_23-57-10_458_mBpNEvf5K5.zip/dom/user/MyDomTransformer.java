
package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * 1. prida novy serial
 * 2. odstrani serial, ktery je popsany pomoci nejvice regexu
 * @author SB
 */
public class MyDomTransformer {
	public void transform(Document dom){
		NodeList serialsNodeList = dom.getElementsByTagName("series");
		Node serials = serialsNodeList.item(0);
		
		serials.appendChild(this.createSerialNode(dom));
		System.out.println(DOMSupport.toString(dom));
		this.removeSerialWithMostRegexes(dom);
		
	}
	
	//vytvori novy serailNode
	private Node createSerialNode(Document dom){
		Node serial = dom.createElement("serial");
		
		Element name = (Element)dom.createElement("name");
		name.setTextContent("Simspons");
		
		Element regexs = (Element)dom.createElement("regexs");
		
		Element regex = (Element)dom.createElement("regex");
		regex.setTextContent(".*simpsons.*");
		regexs.appendChild(regex);
		
		Element folder = (Element)dom.createElement("folder");
		folder.setTextContent("Simpsons");
		
		serial.appendChild(name);
		serial.appendChild(folder);
		serial.appendChild(regexs);
		return serial;
	}
	
	private void removeSerialWithMostRegexes(Document dom){
		
		int maxRegexes = 0;
		Node serialWithMostREgexes = null;
		
		NodeList serialsNodeList = dom.getElementsByTagName("serial");
		//Node serials = serialsNodeList.item(0);
		//NodeList serialsChildren = serials.getChildNodes();
		System.out.println(serialsNodeList.getLength());
		for(int i = 0; i < serialsNodeList.getLength(); i++){
			
			Element serial = (Element)serialsNodeList.item(i);
			Element serialRegexes = (Element)serial.getElementsByTagName("regexs").item(0);
			if(serialRegexes.getChildNodes().getLength() > maxRegexes){
				maxRegexes = serialRegexes.getChildNodes().getLength();
				serialWithMostREgexes = serial;
			}
			
		}
		
		serialWithMostREgexes.getParentNode().removeChild(serialWithMostREgexes);
	}
}
