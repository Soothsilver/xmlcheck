package dom.user;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;
import sax.user.MySaxHandler;

/**
 * Poskytuje parsovani XML souboru pomoci SAX do DOM,
 * dale pak prevod dokumentu do html formatu se zvyraznenim syntaxe.
 * @author bauermi2
 */
public class MyDomTransformer{
	
	//Definice barev 
	private final String brace_col = "#1B0773";
	private List<String> elem_cols = null;
	private final String attr_col = "#F80012";
	private final String val_col = "#466FD5";
	private String doc = null;
        private HashMap<String,Integer> stats = null;
        private static String dataPath = "data.xml";
        
        public MyDomTransformer() {
            elem_cols = new ArrayList<String>();
            elem_cols.add("#0F2600");
            elem_cols.add("#225900");
            elem_cols.add("#318000");
            elem_cols.add("#48B802");
            elem_cols.add("#54DB00");
            elem_cols.add("#62FF00");
        }
        
        public MyDomTransformer(String filepath) {
            this();
            dataPath = filepath;
        }      
	/**
	 * Parsuje XML soubor do DOM, za vyuziti SAXu
	 * @param vstup cesta k souboru
	 * @return strom dokumentu
	 */
	public Document parse(String vstup) {
		MySaxHandler hndl = new MySaxHandler();
		SAXParserFactory spf = SAXParserFactory.newInstance();
		SAXParser parser;
		try {
			parser = spf.newSAXParser();
			parser.parse(new File(vstup), hndl);
		} catch (ParserConfigurationException e) {
                    e.printStackTrace();
		} catch (SAXException ex) {
                    ex.printStackTrace();
                } catch (IOException exx) {
                    exx.printStackTrace();
                }
                stats = hndl.getDocStats();
		return hndl.getDomDocument();
	}
	/**
	 * Prevede dokument do HTML se zvyraznenou syntaxi
	 * @param docu strom dokumentu v DOM
	 * @return HTML reprezentace dokumentu
	 */
	public String highlight(Document docu) {
		Node root = docu.getFirstChild();
		String html = "<ul style=\"list-style-type:none\">\n";
		html += highlightElementChildren(root);
		html += "</ul>";
		return html;
	}
	/**
	 * Prevede XML soubor do HTML se zvyraznenou syntaxi
	 * @param vstup cesta k souboru
	 * @return HTML reprezentace dokumentu
	 */
	public void transform(Document xmlDocument) {
            doc = highlight(xmlDocument);
	}
	
        private Integer getOccurColorIdx(Node c) {
            Integer occur = (int)Math.floor(stats.get(c.getNodeName()) / 1);
            if(occur > 5) occur = 5;
            return occur;
        }
        
	/** Vytvori HTML kod pro uzel c a jeho prime potomky */
	private String highlightElementChildren(Node c) {
		String out = "";	
		//Pokud je uzel textovy, vypiseme rovnou obsah
		if(c.getNodeName().equals("#text")) {
			return c.getTextContent();
		}
		//Pokud ma pouze textoveho potomka, vypiseme cele rovnou bez odsazeni
		else if(c.getFirstChild().getNodeName().equals("#text") && 
				c.getChildNodes().getLength() == 1) {
			
			out += highlightElement(c) + c.getFirstChild().getTextContent() + 
					String.format("<span style=\"color:%1$s\">&lt;/<span style=\"color:%2$s\">%3$s" +
					"</span>&gt;</span>", brace_col, elem_cols.get(getOccurColorIdx(c)), c.getNodeName());
			return out;
		}
		//Vypis pocatecniho tagu elementu c
		out += highlightElement(c) + "\n";
		//Pokud ma c potomky, vypiseme je do podseznamu
		if(c.hasChildNodes()) {
			Node current = c.getFirstChild();
			out += "<ul style=\"list-style-type:none\">\n";
			
			for(int j = 0; j < c.getChildNodes().getLength(); j++) {
				//Rekurze, vypis potomku potomka
				out += highlightElementChildren(current);
				current = current.getNextSibling();
				out += "</li>\n"; 
			}
			out += "</ul>\n";
		}				
		//Uzaviraci tag elementu
		out += String.format("<li><span style=\"color:%1$s\">&lt;/<span style=\"color:%2$s\">%3$s" +
			"</span>&gt;</span></li>\n", brace_col, elem_cols.get(getOccurColorIdx(c)), c.getNodeName());
		return out;
	}
	
	/** Vytvori HTML kod se zvyraznenim syntaxe pro pocatecni tag elementu*/
	private String highlightElement(Node e) {
		String out = "";
		
		//Nazev elementu
		out += String.format("<li><span style=\"color:%1$s\">&lt;<span style=\"color:%2$s\">%3$s</span>",
				brace_col, elem_cols.get(getOccurColorIdx(e)), e.getNodeName().trim());
		//Vypis pripadnych atributu
		if(e.hasAttributes()) 
		{
			for(int i = 0; i< e.getAttributes().getLength(); i++)
			{
				Attr a = (Attr) e.getAttributes().item(i);
				//Nazev atributu
				out += String.format(" <span style=\"color:%1$s\">%2$s</span>", 
						attr_col, a.getNodeName());
				//Hodnota atributu
				out += String.format("=<span style=\"color:%1$s\">\"%2$s\"</span>",val_col,a.getValue());
			}
		}
		out += String.format("&gt;</span>");
		return out;
	}
	
        public String toString() {
            return doc;
        }
        
	public static void main(String[] args) {
                MyDomTransformer mt = null;
                mt = new MyDomTransformer();
		mt.transform(mt.parse(dataPath));
//                try {
//                    BufferedWriter wrt = new BufferedWriter(new FileWriter("output.html"));
//                    wrt.write(mt.toString());
//                    wrt.close();
//
//                    System.out.println("Soubor byl uspesne zpracovan, vysledek byl zapsan do souboru:\n"+
//                            new File("").getAbsolutePath() + "/output.html");
//                    
//		} catch (IOException e) {
//                    e.printStackTrace();
//		}
	}

}