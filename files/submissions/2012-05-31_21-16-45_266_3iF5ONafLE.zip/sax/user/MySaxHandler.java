package user; 

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.*;
import java.util.*;

public class MySaxHandler extends DefaultHandler
{
 /* 
 	public static void main(String[] args)
 	{
         String sourcePath = "../data.xml";
 
         try
 		{
             XMLReader parser = XMLReaderFactory.createXMLReader();
             InputSource source = new InputSource(sourcePath);
             parser.setContentHandler(new MySaxHandler());
             parser.parse(source);
         }
 		catch (Exception e) 
 		{
             e.printStackTrace();
         }
     }
	/* */

 	private StringBuilder sb;
 	private Map<String, Integer> counts = new HashMap<String, Integer>();
 	private double avgElemNameLenght = 0;
	private int elemsWithAttsCount= 0;
	private int depth = 0;
	private int invoicesCount = 0;
	private double averageInvoicePrice = 0;
	private double averageInvoiceItems = 0;
	private int elementsCount = 0;
	private int maxDepth = 0;
	private double avgDepth = 0;
	private int branchesCount = 0;
	private int notPaidInCount = 0;
	private int notPaidOutCount = 0;
	private int paidInCount = 0;
	private int paidOutCount = 0;
	
	private double notPaidInPrice = 0;
	private double notPaidOutPrice = 0;
	private double paidInPrice = 0;
	private double paidOutPrice = 0;

	private double invoicePrice = 0;
	private String currentBranch;
	private Boolean isPaid;

	public MySaxHandler()
	{
		sb = new StringBuilder();
	}
    
    // public void startDocument() throws SAXException {}
    

	// vypis statistiky
    public void endDocument() throws SAXException 
	{
    	// vypocet prumeru
    	avgDepth /= elementsCount;
		avgElemNameLenght /= elementsCount;
		
		averageInvoicePrice /= invoicesCount;
		averageInvoiceItems /= invoicesCount;

		System.out.println("Dokument");
        System.out.println(" - pocet elementu v dokumentu: " + elementsCount);
        System.out.println(" - maximalni hloubka elementu: " + maxDepth);
        System.out.println(" - prumerna hloubka elementu: " + avgDepth);
        System.out.println(" - prumerna delka jmena elementu: " + avgElemNameLenght);
        System.out.println(" - pocet elementu s atributy: " + elemsWithAttsCount);
        System.out.println();

        System.out.println("Pocet faktur: " + invoicesCount);
        System.out.println(" - vydanych: " + (paidOutCount + notPaidOutCount));
        System.out.println("   - z toho zaplacenych: " + paidOutCount);
        System.out.println("     - v cene : " + paidOutPrice + " Kc");
        System.out.println("   - z toho nezaplacenych: " + notPaidOutCount);
        System.out.println("     - v cene : " + notPaidOutPrice + " Kc");
        System.out.println(" - prijatych: " + (paidInCount + notPaidInCount));
        System.out.println("   - z toho zaplacenych: " + paidInCount);
        System.out.println("     - v cene : " + paidInPrice + " Kc");
        System.out.println("   - z toho nezaplacenych: " + notPaidInCount);
        System.out.println("     - v cene : " + notPaidInPrice + " Kc");

        System.out.println("  - prumerna cena faktury: " + averageInvoicePrice + " Kc");
        System.out.println("  - prumerne polozek na fakture: " + averageInvoiceItems);
        
        System.out.println();
        System.out.println("Pobocek: " + branchesCount);
        
        Set<String> keys = counts.keySet();
        
        for(String branch : keys )
        {
        	   System.out.println(" - " + branch + " ma faktur: " + counts.get(branch));
        }
   
    }
    
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException 
	{
		sb.setLength(0);

		// pocitani hloubky, elementu a nazvu elementu
		depth++;
		if (maxDepth < depth)
		{
			maxDepth = depth;
		}

		avgDepth += depth;
		elementsCount++;
		avgElemNameLenght += qName.length();
		
		//	pocitani elementu s atributy
		if(atts.getLength() > 0)
		{
			elemsWithAttsCount++;
		}
		
		if(qName.equals("Pobocka"))
		{
			currentBranch = atts.getValue("Jmeno");
			branchesCount++;
		}
		
		if(qName.equals("VydanaFaktura") || qName.equals("PrijataFaktura"))
		{
			invoicesCount++;
			
			if(counts.containsKey(currentBranch))
			{
				int count = counts.get(currentBranch) + 1;
				counts.put(currentBranch, count);
			}
			else
			{
				counts.put(currentBranch, 1);
			}
		}
		
		if(qName.equals("VydanaFaktura"))
		{
			if(atts.getValue("Stav") != null && atts.getValue("Stav").equals("Zaplacena"))
			{
				paidOutCount++;
				isPaid = true;
			}
			else
			{
				notPaidOutCount++;
				isPaid = false;
			}
		}

		if(qName.equals("PrijataFaktura"))
		{
			if(atts.getValue("Stav") != null && atts.getValue("Stav").equals("Zaplacena"))
			{
				paidInCount++;
				isPaid = true;
			}
			else
			{
				paidInCount++;
				isPaid = false;
			}
		}

		if(qName.equals("Polozky"))
		{
			invoicePrice = 0;
			itemsCnt = 0;
		}
		
		if(qName.equals("Polozka"))
		{
			itemPrice = 0;
			itemsCnt++;
		}
    }

    private double amount, price, dph, itemPrice;
    private int itemsCnt;
    
    private double getDph(String relative)
    {
    	if(relative.equals("dph-zakladni"))
    	{
    		return 1.2;
    	}
    	
    	if(relative.equals("dph-snizene"))
    	{
    		return 1.14;
    	}
    	
    	// defaultne zadne
    	return 1;
    }
    
    public void endElement(String uri, String localName, String qName) throws SAXException 
	{
    	// pocitani hloubky
		depth--;

		if(qName.equals("Cena"))
		{
			try
			{
				price = Double.parseDouble(sb.toString().trim());
			}
			catch(NumberFormatException e)
			{			}
		}
		
		if(qName.equals("Mnozstvi"))
		{
			try
			{
				amount = Double.parseDouble(sb.toString().trim());
			}
			catch(NumberFormatException e)
			{			}
		}
		
		if(qName.equals("Dph"))
		{
			dph = getDph(sb.toString().trim());
		}
		
		if(qName.equals("Polozka"))
		{
			itemPrice = dph * amount * price;
			invoicePrice += itemPrice;
		}
		
		if(qName.equals("Polozky"))
		{
			averageInvoicePrice += invoicePrice;
			averageInvoiceItems += itemsCnt;
		}
		
		if(qName.equals("VydanaFaktura"))
		{
			if(isPaid)
			{
				paidOutPrice += invoicePrice;
			}
			else
			{
				notPaidOutPrice += invoicePrice;
			}
		}

		if(qName.equals("PrijataFaktura"))
		{
			if(isPaid)
			{
				paidInPrice += invoicePrice;
			}
			else
			{
				paidInPrice += invoicePrice;
			}
		}
    }
    
    public void characters(char[] ch, int start, int length) throws SAXException 
	{
    	// nacitani textu uzlu (pouzite pro prevody cisel u pocitani ceny)
		sb.append(ch, start, length);
    }
    
    // public void startPrefixMapping(String prefix, String uri) throws SAXException {}

    // public void endPrefixMapping(String prefix) throws SAXException {}
     
    // public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {}
         
    // public void processingInstruction(String target, String data) throws SAXException {}
         
    // public void skippedEntity(String name) throws SAXException {}
}


