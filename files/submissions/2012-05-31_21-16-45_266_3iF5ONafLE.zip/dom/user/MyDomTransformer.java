package user;

import org.w3c.dom.*;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class MyDomTransformer
{
	/* *
 	public static void main(String[] args) {
         
 		String VSTUPNI_SOUBOR = "../data.xml";
 		String VYSTUPNI_SOUBOR = "../data.out.xml";
 
         try {
             DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
             dbf.setValidating(false);
             DocumentBuilder builder = dbf.newDocumentBuilder();
             Document doc = builder.parse(VSTUPNI_SOUBOR);
             (new MyDomTransformer()).transform(doc);
             TransformerFactory tf = TransformerFactory.newInstance();
             Transformer writer = tf.newTransformer();
 //             writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
             writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));
         } catch (Exception e) {
             e.printStackTrace();
         }
 	}
	/* */

 /*
  * 1. odstrani elementy s datumy a prevede je naatributy elementu hlavicka [metoda addInvoiceNoToParentAndDatesToHeader]
  * 2. odstrani faktury, ktere nejsou zkontrolovany [metoda removeNotCheckedInvoices]
  * 3. u elementu polozka prida atribut cena, kde spocita cenu dane polozky (dle dph, a mnozstvi) [element countItemPrices]
  * 4. cislo faktury zaroven zkopiruje jako atribut korenove faktury z elementu Hlavicka [element addInvoiceNoToParentAndDatesToHeader]
  * 5. spocita cenu kazde faktury a vlozi to jako novy element [metoda countInvoicePrices]
  * 6. pro kazdou pobocku vytvori element s vyctem nezaplacenych faktur, ktere uz jsou po splatnosti [metoda insertNotPaidSummary]
  * */
 	
	public void transform (Document xmlDocument)
	{
		addInvoiceNoToParentAndDatesToHeader(xmlDocument);
		
		countItemPrices(xmlDocument);
		countInvoicePrices(xmlDocument);
		
		removeNotCheckedInvoices(xmlDocument, "VydanaFaktura");
		removeNotCheckedInvoices(xmlDocument, "PrijataFaktura");

		insertNotPaidSummary(xmlDocument);
	}

	private void insertNotPaidSummary(Document doc)
	{
		NodeList nl = doc.getElementsByTagName("Pobocka");
		for( int i = 0; i < nl.getLength(); i++)
		{
			Element pobocka = (Element)nl.item(i);
			
			NodeList faktury = pobocka.getChildNodes(); 
			
			int cnt = 0;
			Element notPaidElement = doc.createElement("Nezaplacene");
			
			for(int j = 0; j < faktury.getLength(); j++)
			{
				if(faktury.item(j).getNodeName().equals("VydanaFaktura") || 
						faktury.item(j).getNodeName().equals("PrijataFaktura"))
				{
					Element faktura = (Element)faktury.item(j);
					
					Date now = new Date();
					Date splatnost = getDatumSplatnosti(faktura); 
					
					if(faktura.hasAttribute("Stav") && 
							faktura.getAttribute("Stav") != "Zaplacena" &&
							splatnost.before(now))
					{
						Element inv = doc.createElement("Faktura");
						inv.setAttribute("Typ", faktura.getNodeName());
						inv.setTextContent(faktura.getAttribute("Cislo"));
						
						notPaidElement.appendChild(inv);
						cnt++;
					}
				}
			}
			
			if(cnt > 0)
			{
				pobocka.appendChild(notPaidElement);
			}
		}
	}
	
	private Date getDatumSplatnosti(Element faktura)
	{
		NodeList nl = faktura.getChildNodes();
		
		for( int i = 0; i < nl.getLength(); i++)
		{
			if(nl.item(i).getNodeName() == "Hlavicka")
			{
				Element hlavicka = (Element)nl.item(i);
	
				if(hlavicka.hasAttribute("DatumSplatnosti"))
				{
					SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
					try 
					{
						return formatter.parse(hlavicka.getAttribute("DatumSplatnosti"));
					}
					catch (Exception e) { }
				}
			}
		}
		
		return new Date();
	}
	
	// spocita cenu faktury a vlozi to jako novy element
	private void countInvoicePrices(Document doc)
	{
		NodeList nl = doc.getElementsByTagName("Polozky");
		for( int i = 0; i < nl.getLength(); i++)
		{
			Element elem = (Element)nl.item(i);
			NodeList polozky = elem.getChildNodes(); 
			
			double price = 0;
			
			for(int j = 0; j < polozky.getLength(); j++)
			{
				if(polozky.item(j).getNodeName().equals("Polozka"))
				{
					Element polozka = (Element)polozky.item(j);
					double invoicePrice = Double.parseDouble(polozka.getAttribute("Cena"));
					
					price += invoicePrice;
				}
			}
			
			Element priceNode = doc.createElement("Cena");
			priceNode.setTextContent(Double.toString(price));
			
			Node invoice = elem.getParentNode();
			invoice.appendChild(priceNode);
		}
	}
	
	private void countItemPrices(Document doc)
	{
		NodeList nl = doc.getElementsByTagName("Polozka");
		for( int i = 0; i < nl.getLength(); i++)
		{
			Element polozka = (Element)nl.item(i);
			NodeList udaje = polozka.getChildNodes(); 
			
			double price = 0;
			double dph = 1;
			double amount = 0;
			
			for(int j = 0; j < udaje.getLength(); j++)
			{
				if(udaje.item(j).getNodeName().equals("Mnozstvi"))
				{
					amount = Double.parseDouble(udaje.item(j).getTextContent());
				}
				
				if(udaje.item(j).getNodeName().equals("Cena"))
				{
					price = Double.parseDouble(udaje.item(j).getTextContent());
				}
				
				if(udaje.item(j).getNodeName().equals("Dph"))
				{
					dph = getDph(udaje.item(j).getTextContent());
				}
			}
			
			double cena = (amount * price * dph);
			polozka.setAttribute("Cena", Double.toString(cena));
		}
	}
	
    private double getDph(String relative)
    {
    	if(relative.equals("dph-zakladni"))
    	{
    		return 1.2;
    	}
    	
    	if(relative.equals("dph-snizene"))
    	{
    		return 1.14;
    	}
    	
    	// defaultne zadne
    	return 1;
    }
	
	/**
	 * prehodi cislo do atributu faktury a zmeny datumy (bod 1 a 4)
	 */
	private void addInvoiceNoToParentAndDatesToHeader(Document doc)
	{
		NodeList nl = doc.getElementsByTagName("Hlavicka");
		
		for( int i = 0; i < nl.getLength(); i++)
		{
			Element hlavicka = (Element)nl.item(i);
			NodeList hlavicky = hlavicka.getChildNodes(); 

			for(int j = 0; j < hlavicky.getLength(); j++)
			{
				// duplikace cisla faktury
				if(hlavicky.item(j).getNodeName().equals("Cislo"))
				{
					Element invoice = (Element)hlavicka.getParentNode();
					invoice.setAttribute("Cislo", hlavicky.item(j).getTextContent());
				}
				
				// prehozeni datumu a jejich smazani
				if(hlavicky.item(j).getNodeName().equals("DatumSplatnosti") ||
						hlavicky.item(j).getNodeName().equals("DatumVytvoreni") ||
						hlavicky.item(j).getNodeName().equals("DatumVytvoreni")
						)
				{
					hlavicka.setAttribute(hlavicky.item(j).getNodeName(), hlavicky.item(j).getTextContent());
					hlavicka.removeChild(hlavicky.item(j));
				}
			}
		}
	}
	
	private void removeNotCheckedInvoices(Document doc, String tagName)
	{
		NodeList nl = doc.getElementsByTagName(tagName);
		
		for( int i = 0; i < nl.getLength(); i++)
		{
			Element invoice = (Element)nl.item(i);
			
			if(invoice.getAttribute("Zkontrolovana") != null && 
					invoice.getAttribute("Zkontrolovana").equals("false"))
			{
				Node parent = invoice.getParentNode();
				parent.removeChild(invoice);
			}
		}
	}
}

