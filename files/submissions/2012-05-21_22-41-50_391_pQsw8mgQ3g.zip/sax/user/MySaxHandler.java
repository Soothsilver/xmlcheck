package user;

// Program spocita knihy v jednotlivych knihovnach ( celkem a elektronicke ) a nakonec vypise i celkovy pocet knih
// ve vsech knihovnach.
/** Vystup tedy vypada takto
Knihovna A
	Celkovy pocet knih v knihovne je: 11
	Z toho elektronickych: 3
Knihovna B
	Celkovy pocet knih v knihovne je: 2
	Z toho elektronickych: 2
Celkove je v knihovnach knih: 13
Z toho elektronickych: 5
*/
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * @author Jaroslav Medek
 */


//public class SAX {
//
//	public static void main(String[] args) {
//		String sourcePath = "data.xml";
//
//		try {
//
//			XMLReader parser = XMLReaderFactory.createXMLReader();
//
//			InputSource source = new InputSource(sourcePath);
//
//			parser.setContentHandler(new MySaxHandler());
//
//			parser.parse(source);
//
//		} catch (SAXException | IOException e) {
//			System.out.println(e);
//		}
//	}
//}

public class MySaxHandler extends DefaultHandler{

	Locator locator;
	int bookCount;
	int eleBookCount;
	int prevBookCount;
	int prevEleBookCount;
	private boolean vNazvu;

	@Override
	public void setDocumentLocator(Locator arg0) {
		this.locator = arg0;
	}

	@Override
	public void startDocument() throws SAXException { //na zacatku vse pro jistotu vynuluji
		bookCount = 0;
		eleBookCount = 0;
		prevBookCount = 0;
		prevEleBookCount = 0;
		vNazvu = false;
	}

	@Override
	public void endDocument() throws SAXException { //na konci vypisu finalni hodnoty
		System.out.println("Celkove je v knihovnach knih: " + bookCount);
		System.out.println("Z toho elektronickych: " + eleBookCount);
	}

	@Override
	public void startPrefixMapping(String arg0, String arg1) throws SAXException {
//		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void endPrefixMapping(String arg0) throws SAXException {
//		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void startElement(String arg0, String arg1, String arg2, Attributes arg3) throws SAXException {
		if (arg1.equals("kniha")) { //pocitani vyskytu elemntu kniha
			bookCount++;
			if (arg3.getValue("elektronicky").equals("ano")) { // pocitani elektronickych knih podle attributu
				eleBookCount++;
			}
		}
		if (arg1.equals("nazev")) { //boolean pro vypis nazvu knihovny
			vNazvu = true;
		}
	}

	@Override
	public void endElement(String arg0, String arg1, String arg2) throws SAXException {
		if (arg1.equals("knihovna")) { //kdyz dojdu na koncovy element knihovna, vypisu pocty knih v dane knihovne
			if (prevBookCount == 0 && prevEleBookCount == 0) {
				System.out.println("\t" + "Celkovy pocet knih v knihovne je: " + bookCount);
				System.out.println("\t" + "Z toho elektronickych: " + eleBookCount);
				prevBookCount += bookCount; //zde si pouze uchovavam pocty knih v predeslych knihovnach
				prevEleBookCount += eleBookCount;
				return;
			}
			System.out.println("\t" + "Celkovy pocet knih v knihovne je: " + (bookCount - prevBookCount));
			System.out.println("\t" + "Z toho elektronickych: " + (eleBookCount - prevEleBookCount));
			prevBookCount += bookCount;
			prevEleBookCount += eleBookCount;
		}
	}

	@Override
	public void characters(char[] arg0, int arg1, int arg2) throws SAXException {
		if (vNazvu) { //pokud jsem byl zrovna v elementu nazev, tak vypisu jeho textovou hodnotu.
			String nazev = "";
			nazev = new StringBuilder().append(arg0, arg1, arg2).toString();
			System.out.println(nazev);
		}
		vNazvu = false; //prenastavim promenou, aby dalsi zavolani metody opet nevypsalo nejaky jiny obsah jineho elementu
	}

	@Override
	public void ignorableWhitespace(char[] arg0, int arg1, int arg2) throws SAXException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void processingInstruction(String arg0, String arg1) throws SAXException {
//		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void skippedEntity(String arg0) throws SAXException {
//		throw new UnsupportedOperationException("Not supported yet.");
	}
}
