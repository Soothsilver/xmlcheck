package user;

/**
 * Program vezme XML dokument a predela atribute u elementu "kniha" na element.
 * 
 * 
 */

import java.io.File;
import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;

/**
 *
 * @author Jaroslav Medek
 */
public class MyDomTransformer {

	private static final String VSTUPNI_SOUBOR = "data.xml";
	private static final String VYSTUPNI_SOUBOR = "data.out.xml";

	public static void main(String[] args) {

		try {

			
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

			
			dbf.setValidating(false);

			DocumentBuilder builder = dbf.newDocumentBuilder();

			Document doc = builder.parse(VSTUPNI_SOUBOR);

			transform(doc);

			TransformerFactory tf = TransformerFactory.newInstance();

			Transformer writer = tf.newTransformer();

			writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

			writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


		} catch (Exception e) {
		}
	}

	/**
	 * Zpracuje DOM strom
	 */
	public static void transform(Document doc) {
		NodeList knihy = doc.getElementsByTagName("kniha"); //vezmu vsechny elementy kniha
		for (int i = 0; i < knihy.getLength(); i++) { //postupne vsechny projizdim
			Element kniha = (Element) knihy.item(i);
			if(kniha.hasAttribute("elektronicky")){ //pokud kniha ma attribut "elektronicky" ...
				String attrib = kniha.getAttribute("elektronicky").toString(); //...ulozim si jeho hodnotu
				kniha.removeAttribute("elektronicky"); // pote attribute odeberu
				
				Element element = doc.createElement("elektronicky"); //a vytvorim novy element
				Text text = doc.createTextNode(attrib); // nastavim mu puvodni hodnotu
				element.appendChild(text); //a pridam ho tam, kam patri.
				kniha.appendChild(element);
			}
		}
	}
}
