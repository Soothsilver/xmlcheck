package user;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
//import org.xml.sax.helpers.XMLReaderFactory;
//import org.xml.sax.XMLReader;
//import org.xml.sax.InputSource;

/**
 * Vypisi informaci o videopujcovne a zakaznicich + zjistim statistiky o souboru + 
 * spočítám zákazníky, vypíši kolik z nich je častých zákazníků, se zlatou kartou.. (to mám v atibutech)
 * jak dlouho má ještě platnost členství (v dokumentu je do kdy), počet starých i 
 * aktuálních výpůjček a na jak dlouho má aktuální výpujčky půjčené, u nových mám elementy od, do. 
 * @author Rozenberg David
 * 19.5.2012
 */
public class MySaxHandler extends DefaultHandler {

    String lastElement;
    boolean text = false;
    String udaje;
    String att[] = new String[4];
    int pocetElementu = 0;
    int maxHloubka = 1;
    int aktualniHloubka = -1;
    int pocetAtributu = 0;
    int delkaElementu = 0;
    int pocetTextovychElementu = 0;
    int pocetZakazniku = 0;
    int seZlatouKartou = 0;
    int pocetCastychZakazniku = 0;
    int zamestnancu = 0;
    boolean nove = true;
    int pocetNovych = 0;
    int pocetStarych = 0;
    Date odD = null;
    Date doD = null;

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        // maximalni hloubka dokumentu
        aktualniHloubka++;
        if (aktualniHloubka > maxHloubka) {
            maxHloubka = aktualniHloubka;
        }

        // posledni element
        lastElement = localName;

        // pocetAtributu
        for (int i = 0; i < attributes.getLength(); i++) {
            pocetAtributu++;
            att[i] = attributes.getValue(i);
        }

        //pocet zakazniku
        if (lastElement.equals("zakaznik")) {
            pocetZakazniku++;

            for (int i = 0; i < attributes.getLength(); i++) {
                //se zlatou kartou
                if (attributes.getQName(i).equals("zlataKarta")) {
                    if (attributes.getValue(i).equals("ano")) {
                        seZlatouKartou++;
                    }
                }
                // castych zakazniku
                if (attributes.getQName(i).equals("castyZakaznik")) {
                    if (attributes.getValue(i).equals("ano")) {
                        pocetCastychZakazniku++;
                    }
                }
                // zamestnancu
                if (attributes.getQName(i).equals("zamestnanec")) {
                    if (attributes.getValue(i).equals("ano")) {
                        zamestnancu++;
                    }
                }
            }
        }

        // pocitam nove nebo stare?
        if (lastElement.equals("vypujcky")) {
            nove = true;
            pocetNovych = 0;
        }
        if (lastElement.equals("stareVypujcky")) {
            nove = false;
            pocetStarych = 0;
        }
        if (lastElement.equals("vypujcka")) {
            if (nove) {
                pocetNovych++;
            } else {
                pocetStarych++;
            }
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        // pocet elementu
        pocetElementu++;
        // snizeni hloubkz odkumentu
        aktualniHloubka--;
        // delka elementu
        delkaElementu += localName.length();

        // pokud posledni element ma hned zaviraci element je textovy
        if (lastElement.equals(localName)) {
            pocetTextovychElementu++;
            text = true;
            // tyto elementy vypisovat nebudu
            if (localName.equals("info") || localName.equals("cislo") || localName.equals("popis") || localName.equals("odkaz")) {
                text = false;
                return;
            }
            // pred kazdym zakaznikem novy radek
            if (localName.equals("jmeno")) {
                System.out.println("");
            }
            // nazev elementu + v characters k tomu text
            System.out.print(localName + " : ");
        }

        // konec elementu zakaznik, vypisi jeho vypujcky
        if (localName.equals("zakaznik")) {
            System.out.println("Celkem vypujcek : " + (pocetStarych + pocetNovych) + " z toho pocet novych: " + pocetNovych + " a pocet starych : " + pocetStarych);
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {

        // textovy element
        if (text) {
            
            // pokud je prazdny = 0
            if (udaje.trim().isEmpty()) {
                System.out.print("0");
            } else {
                // jinak vypisu
                System.out.print(udaje);
                // u jmena vypisu jake vlastnosti ma zakaznik
                if (lastElement.equals("jmeno")) {
                    System.out.print("(Zlata karta : " + att[1]
                            + ", Zamestnanec : " + att[2] + ", "
                            + "Casty zakaznik : " + att[3] + ")");
                }
                // u cisla disku jestli je to DVD, CD...
                if (lastElement.equals("cisloDisku")) {
                    System.out.print(" (" + att[0] + ")");
                }
                // u elementu platnost clenstvi do vypocitam kolik zbyva dnu
                if (lastElement.equals("platnostClenstviDo")) {
                    Calendar c = Calendar.getInstance();
                    SimpleDateFormat dateFormat = new SimpleDateFormat("d.M.yyyy");
                    Date time = c.getTime();
                    Date startDat = null;
                    try {
                        startDat = dateFormat.parse(udaje);
                    } catch (ParseException ex) {
                        Logger.getLogger(MySaxHandler.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    int dnu = dnuMezi(time, startDat);
                    System.out.print(" (zbyva " + dnu + " dnu)");
                }
                // ulozim si od kdy do kdy mam vypujcku a nasledne vypocitam rozdil = na jak dlouho mam pujceno
                if (lastElement.equals("od")) {
                    SimpleDateFormat dateFormat = new SimpleDateFormat("d.M.yyyy");
                    try {
                        odD = dateFormat.parse(udaje);
                    } catch (ParseException ex) {
                        Logger.getLogger(MySaxHandler.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                if (lastElement.equals("do")) {
                    SimpleDateFormat dateFormat = new SimpleDateFormat("d.M.yyyy");
                    try {
                        doD = dateFormat.parse(udaje);
                    } catch (ParseException ex) {
                        Logger.getLogger(MySaxHandler.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    System.out.println("");
                    System.out.print("Celkova doba vypujcky : " + dnuMezi(odD, doD) + " dnu");
                }
            }
            System.out.println("");
        }
        // ulozim si do stringu text z dokumentu
        udaje = new String(ch, start, length);
        text = false;
    }

    
    /**
     * Na konci dokumentu vse vypisi
     */
    @Override
    public void endDocument() throws SAXException {
        System.out.println("---------");
        System.out.println("Pocet zakazniku : " + pocetZakazniku);
        System.out.println("Pocet zakazniku se zlatou kartou : " + seZlatouKartou);
        System.out.println("Pocet castych zakazniku: " + pocetCastychZakazniku);
        System.out.println("Pocet zakazniku, kteri jsou zamestnanci : " + zamestnancu);
        System.out.println("---------");
        System.out.println("Pocet elementu : " + pocetElementu);
        System.out.println("Pocet textovych elementu : " + pocetTextovychElementu);
        System.out.println("Maximalni hloubka : " + maxHloubka);
        System.out.println("Pocet atributu : " + pocetAtributu);
        float prumernaDelkaElementu = (float) delkaElementu / pocetElementu;
        System.out.println("Prumerna delka elementu : " + prumernaDelkaElementu);

    }

    // zjisti rozdil dnu mezi dvema daty
    private int dnuMezi(Date time, Date startDat) {
        int dnu = (int) ((time.getTime() - startDat.getTime()) / (1000 * 60 * 60 * 24));
        return Math.abs(dnu);
    }
}

//class SAX_podpora {
//
//    public static void main(String[] args) {
//
//        // Cesta ke zdrojovĂ©mu XML dokumentu  
//        String sourcePath = "data.xml";
//
//        try {
//
//            // VytvorĂ­me instanci parseru.
//            XMLReader parser = XMLReaderFactory.createXMLReader();
//
//            // VytvorĂ­me vstupnĂ­ proud XML dat.
//            InputSource source = new InputSource(sourcePath);
//
//            // NastavĂ­me nĂˇÄ… vlastnĂ­ content handler pro obsluhu SAX udĂˇlostĂ­.
//            parser.setContentHandler(new MySaxHandler());
//
//            // Zpracujeme vstupnĂ­ proud XML dat.
//            parser.parse(source);
//
//        } catch (Exception e) {
//
//            e.printStackTrace();
//
//        }
//
//    }
//}
