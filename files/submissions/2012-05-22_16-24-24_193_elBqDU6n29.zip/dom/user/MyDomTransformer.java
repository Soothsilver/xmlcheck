package user;

//import java.io.File;
//import javax.xml.parsers.DocumentBuilder;
//import javax.xml.parsers.DocumentBuilderFactory;
//import javax.xml.transform.OutputKeys;
//import javax.xml.transform.Transformer;
//import javax.xml.transform.TransformerFactory;
//import javax.xml.transform.dom.DOMSource;
//import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


/**
 * menim veskere info v prvni polovine xml o videopujcovne, vsem zakaznikum vymazu stare vypujcky a nove prevedu do starych.
 * @author Rozenberg David
 * 19.5.2012
 */
public class MyDomTransformer {
    Document d;

    public void transform(Document xmlDocument) {
        d = xmlDocument;        
        upravInfo();        
        vymazStare();
        vymazNove();
        upravStare();
    }

    
    /**
     * vymaze stare vypujcky
     */
    private void vymazStare() {
        NodeList elementsByTagName = d.getElementsByTagName("zakaznik");
        for (int i = 0; i < elementsByTagName.getLength(); i++) {
            Element e = (Element) elementsByTagName.item(i);
            NodeList elementsByTagName1 = e.getElementsByTagName("stareVypujcky");
            e.replaceChild(d.createElement("stareVypujcky"), elementsByTagName1.item(0));
        }
        
        
    }

    // prevede vypujcky ze starych do novych, vyhledam je a pomoci metody pridejDoStarych() je presunu
    private void vymazNove() {
        NodeList vypujckyV = d.getElementsByTagName("vypujcky");
        for (int i = 0; i < vypujckyV.getLength(); i++) {
           Element vypujcky = (Element) vypujckyV.item(i);
            NodeList vypujckaList = vypujcky.getElementsByTagName("vypujcka");
            for (int j = 0; j < vypujckaList.getLength(); j = 0) {
                 Node vypujcka = vypujckaList.item(j);
                 pridejDoStarych(vypujcka, i);
            }
            
        }
    }
    
    // prida vypujcku do starych
    private void pridejDoStarych(Node vypujcka, int poradi) {
        NodeList elementsByTagName = d.getElementsByTagName("stareVypujcky");
        Element stareVyp = (Element) elementsByTagName.item(poradi);
        stareVyp.appendChild(vypujcka);
    }

    // stare vypujcky maji jinou strukturu nez nove, proto je musim upravit. Vymazu element od, a element do prejmenuju na vraceno
    private void upravStare() {
        NodeList vypujckaList =  d.getElementsByTagName("vypujcka");
        for (int i = 0; i < vypujckaList.getLength(); i++) {
            Element vypujcka = (Element) vypujckaList.item(i);
            Node item = vypujcka.getElementsByTagName("od").item(0);
            vypujcka.removeChild(item);
            Element item2 = (Element) vypujcka.getElementsByTagName("do").item(0);
            d.renameNode(item2, item2.getNamespaceURI(), "vraceno");
        }
        
    }

    // upravim info v prvni polovine XML dokumentu
    private void upravInfo() {
        Node nazev = d.getElementsByTagName("nazev").item(0);
        nazev.setTextContent("Stara pujcovna");
        
        Node adresa = d.getElementsByTagName("adresa").item(0);
        NodeList adresaChildNodes = adresa.getChildNodes();
        for (int i = 0; i < adresaChildNodes.getLength(); i++) {
            if("ulice".equals(adresaChildNodes.item(i).getNodeName())) {
                adresaChildNodes.item(i).setTextContent("Petrzelova");
            } 
            if("mesto".equals(adresaChildNodes.item(i).getNodeName())) {
                adresaChildNodes.item(i).setTextContent("Ostrava");
            }
            if("psc".equals(adresaChildNodes.item(i).getNodeName())) {
                adresaChildNodes.item(i).setTextContent("159 00");
            }
        }
        
        Node telefon = d.getElementsByTagName("telefon").item(0);
        telefon.setTextContent("639 785 325");
        telefon = d.getElementsByTagName("telefon").item(1);
        telefon.getParentNode().removeChild(telefon);
        
        Node email = d.getElementsByTagName("email").item(0);
        email.setTextContent("staraPujcovna@google.cz");
        
        Node www = d.getElementsByTagName("www").item(0);
        www.setTextContent("www.staraPujcovna.cz");
    }
}
//class DOM_podpora {
//
//    private static final String VSTUPNI_SOUBOR = "data.xml";
//    private static final String VYSTUPNI_SOUBOR = "data.out.xml";
//
//    public static void main(String[] args) {
//        
//        try {
//            
//            //DocumentBuilderFactory vytvĂˇĹ™Ă­ DOM parsery
//            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
//
//            //nebudeme validovat
//            dbf.setValidating(false);
//
//            //vytvoĹ™Ă­me si DOM parser
//            DocumentBuilder builder = dbf.newDocumentBuilder();
//
//            //parser zpracuje vstupnĂ­ soubor a vytvoĹ™Ă­ z nÄ›j strom DOM objektĹŻ
//            Document doc = builder.parse(VSTUPNI_SOUBOR);
//
//            MyDomTransformer my = new MyDomTransformer();
//            
//            //zpracujeme DOM strom
//            my.transform(doc);          
//            
//
//            //TransformerFactory vytvĂˇĹ™Ă­ serializĂˇtory DOM stromĹŻ
//            TransformerFactory tf = TransformerFactory.newInstance();
//
//            //Transformer serializuje DOM stromy
//            Transformer writer = tf.newTransformer();
//
//            //nastavĂ­me kodovĂˇnĂ­
//            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
//
//            //spustĂ­me transformaci DOM stromu do XML dokumentu
//            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));
//
//
//        } catch (Exception e) {
//            
//            e.printStackTrace();
//            
//        }
//    }
//    
//
//}
