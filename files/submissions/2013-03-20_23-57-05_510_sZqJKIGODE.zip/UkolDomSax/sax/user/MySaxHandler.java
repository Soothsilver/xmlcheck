package user;

import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;


/**
 * Out custom content handler for managing SAX events Implements methods of the
 * abstract class ContentHandler.
 * 
 * @see http://www.saxproject.org/apidoc/org/xml/sax/ContentHandler.html#
 *      processingInstruction%28java.lang.String,%20java.lang.String%29
 */
class MySaxHandler implements DefaultHandler {

	// Helper variable to store location of the handled event
	Locator locator;

	
	// Get emails for sending newsletters variables
	// List of emails that wants newsletters
	ArrayList<String> nlemails = new ArrayList<>();
	boolean addEmail;
	
	int screeningCount;
	int totalProjections;

	HashMap<String, String> users = new HashMap<>();
	boolean isInUserElement;
	String user;
	String firstName;
	String lastName;
	
	
	HashMap<String, Integer> genresNumbers = new HashMap<>();
	
	String time;
	String date;
	String filmId;
	String roomId;

	String filmRef;
	String roomRef;

	PrintStream ps;

	ElementType element=ElementType.Other;

	enum ElementType {
		FirstName, LastName, Genre, Other
	}

	/**
	 * Sets the locator
	 * 
	 * @param Locator
	 *            locator location in the file
	 */
	@Override
	public void setDocumentLocator(Locator locator) {
		this.locator = locator;
	}

	/**
	 * Method to handle "document start"
	 * 
	 * @throws SAXException
	 */
	@Override
	public void startDocument() throws SAXException {
		try {
			ps = new PrintStream("projections.html");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/**
	 * Method to handle "document end"
	 * 
	 * @throws SAXException
	 */
	@Override
	public void endDocument() throws SAXException {
		System.out.println("E-mails for newsletter sending:");
		for(String email:nlemails){
			System.out.println(email);
		}
		
		System.out.println();
		System.out.println("Names of users that have not ever borrow a book:");
		
		for(String user:users.values()){
			System.out.println(user);
		}
	
		
		System.out.println();
		System.out.println("Book genre with the most occurence:");
		
		String topGenre="Nothing";
		int count=0;
		for(Entry<String,Integer> e:genresNumbers.entrySet()){
			if(e.getValue()>count){
				count = e.getValue();
				topGenre = e.getKey();
			}
			
		}
		System.out.println(topGenre + " " + count);
	
	}

	/**
	 * Method to handle "begin element"
	 * 
	 * @param uri
	 *            URI of the element namespace (empty if element is no
	 *            namespace)
	 * @param localName
	 *            local name of the element (never empty)
	 * @param qName
	 *            qualified name (prefix-URI + ':' + localName, if the element
	 *            is in some namespace or localName otherwise)
	 * @param atts
	 *            Element's attributes
	 * @throws SAXException
	 */
	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes atts) throws SAXException {
		
		switch(localName){
		case "email":
			if("true".equals(atts.getValue("sendNewsletter"))){
				addEmail=true;
				
			}	
			return;
		
		case "user": 
			isInUserElement=true;
			user = atts.getValue("id");
			return;
		
		case "firstname": 
			element=ElementType.FirstName;
			return;
		
		case "lastname": 
			element=ElementType.LastName;
			return;
		
		case "loan": 
			String userId = atts.getValue("user");
			if(userId != null && users.containsKey(userId)){
				users.remove(userId);
			}
			return;
		
		case "genre": 
			element=ElementType.Genre;
			return;
		}
	}

	/**
	 * Method to handle "element end"
	 * 
	 * @param uri
	 *            URI of the element namespace (empty if element is no
	 *            namespace)
	 * @param localName
	 *            local name of the element (never empty)
	 * @param qName
	 *            qualified name (prefix-URI + ':' + localName, if the element
	 *            is in some namespace or localName otherwise)
	 * @param atts
	 *            Element's attributes
	 * @throws SAXException
	 */
	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		addEmail=false;
		element=ElementType.Other;
		
		if("user".equals(localName)){
			users.put(user, firstName + " " + lastName);
			isInUserElement=false;
			user=null;
			firstName=null;
			lastName=null;
		}
	}

	
	/**
	 * Method to handle "character data" SAX parser can process data in various
	 * batches. so we can't rely that whole whole text content will be delivered
	 * in one call Text is in array 'chars' from position ('start') to ('start'
	 * + 'length' - 1)
	 * 
	 * @param chars
	 *            Array with char data
	 * @param start
	 *            Index of the begin of valid data
	 * @param length
	 *            Length of the valid data
	 * @throws SAXException
	 */
	@SuppressWarnings("incomplete-switch")
	@Override
	public void characters(char[] chars, int start, int length)
			throws SAXException {
		
		String value = new String(chars, start, length).trim();
		if(addEmail){
			nlemails.add(value);
		}
		switch (element) {

		case FirstName:
			firstName=value;
			break;
		case LastName:
			lastName=value;
			break;
		case Genre:
			if(genresNumbers.containsKey(value)){
				int count = genresNumbers.get(value);
				count++;
				genresNumbers.put(value, count);
			}else{
				genresNumbers.put(value, 1);
			}
			break;
		

		}
	}

	/**
	 * Method to handle " start of namespace declaration"
	 * 
	 * @param prefix
	 *            Prefix of the namespace
	 * @param uri
	 *            URI of the namespace
	 * @throws SAXException
	 */
	@Override
	public void startPrefixMapping(String prefix, String uri)
			throws SAXException {
		// ...
	}

	/**
	 * Method to handle "end of namespace declaration"
	 * 
	 * @param prefix
	 * @throws SAXException
	 */
	@Override
	public void endPrefixMapping(String prefix) throws SAXException {
		// ...
	}

	/**
	 * Method to handle "ignoring of whitespaces" Text is in array 'chars' from
	 * position ('start') to ('start' + 'length' - 1)
	 * 
	 * @param chars
	 *            Array with char data
	 * @param start
	 *            Index of the begin of valid data
	 * @param length
	 *            Length of the valid data
	 * @throws SAXException
	 * @throws SAXException
	 */
	@Override
	public void ignorableWhitespace(char[] chars, int start, int length)
			throws SAXException {
		// ...
	}

	/**
	 * Method to handle "processing instructions"
	 * 
	 * @param target
	 *            The processing instruction target
	 * @param data
	 *            The processing instruction data
	 * @throws SAXException
	 */
	@Override
	public void processingInstruction(String target, String data)
			throws SAXException {
		// ...
	}

	/**
	 * Method to handle "unprocessed entity"
	 * 
	 * @param name
	 * @throws SAXException
	 */
	@Override
	public void skippedEntity(String name) throws SAXException {
		// ...
	}
}
