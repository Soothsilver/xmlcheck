/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

/**
 *
 * @author uNitrogenius
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler; 
public class MySaxHandler extends DefaultHandler{
    enum StavovyProstor{ UcetnictviPrijmy, UcetnictviVydaje, Nedefinovany, Produkty};
    static class MyLong{ long l = 0; }
    
    /**
     * Soucet faktur pres kusy a ceny ve vydajich - attributy, kontext
     * @return
     */
    public long GetPrijmy(){return Prijmy.l;}
    
    /**
     * Soucet faktur pres kusy a ceny ve vydajich - attributy, kontext
     * @return
     */
    public long GetVydaje(){return Vydaje.l;}
    
    /**
     * Soucet pres elementy, podle toho maji-li obsah - obsah elementu
     * @return
     */
    public long GetPocetProduktuBezPopisu(){return PocetProduktuBezPopisu.l;}
    
    /**
     * Nejcestejsi slovo v nazvech produktu - attribut
     * @return
     */
    public String GetNejcastejsiJmenoProduktu()
    {
        String s = null; 
        int i = -1;
        for( Map.Entry<String, Integer> kv :NejcastejsiJmenoProduktu.entrySet()){
            if(i < kv.getValue()){
                s = kv.getKey();
                i = kv.getValue();
            }
        }
        return s;
    }
    /**
     * Jmena vsech produktu se znackou Sony
     * @return
     */
    public String[] GetProduktyOdSony()
    {
        String [] s = new String[ProduktyOdSony.size()];
        ProduktyOdSony.toArray(s);
        return s;
    }
    
    
    
    
    
    
    
    
    
    private StavovyProstor Status;
    private MyLong Prijmy;
    private MyLong Vydaje;
    private MyLong PocetProduktuBezPopisu;
    private Map<String, Integer> NejcastejsiJmenoProduktu = new HashMap<>();
    private List<String> ProduktyOdSony = new ArrayList<>();
    private void SetInStatus(String ElementName)
    {
        switch(ElementName)
        {
            case "Vydej": Status = StavovyProstor.UcetnictviVydaje ;break;
            case "Prijem": Status = StavovyProstor.UcetnictviPrijmy;break;
            case "Produkty": Status = StavovyProstor.Produkty;break;    
        }
    }
    private void SetOutStatus(String ElementName)
    {
        switch(ElementName)
        {
            case "Vydej": Status = StavovyProstor.Nedefinovany;break;
            case "Prijem": Status = StavovyProstor.Nedefinovany;break;
            case "Produkty": Status = StavovyProstor.Nedefinovany;break;    
        }
    }
    private void zpracujFakturu(String uri, String localName, String qName, Attributes attributes, MyLong zaklad)
    {
        if(localName.equals("FakturacniPolozka"))
        {
            Long ks = Long.parseLong( attributes.getValue("pocetKusu") );
            Long cena = Long.parseLong( attributes.getValue("cena") );
            zaklad.l += (ks*cena);
        }
    }
    private void zpracujProdukt(String uri, String localName, String qName, Attributes attributes)
    {
        if(localName.equals("Produkt"))
        {
            /// scitani produktu s popisem
            PocetProduktuBezPopisu.l++;
            
            ///produkty od sony
            if(attributes.getValue("znacka").equals("Sony"))
            {
                ProduktyOdSony.add(attributes.getValue("jmeno"));
            }
            
            ///scitani slov
            for(String s : attributes.getValue("jmeno").split("\\s"))
            {
                if(NejcastejsiJmenoProduktu.containsKey(s)) {
                    NejcastejsiJmenoProduktu.put(s, NejcastejsiJmenoProduktu.get(s)+ 1);
                }else NejcastejsiJmenoProduktu.put(s, 1);
            }
        }
    }
    public void characters(char[] ch, int start, int length) throws SAXException {
        super.characters(ch, start, length); //To change body of generated methods, choose Tools | Templates.
        if(Status == StavovyProstor.Produkty) 
        {
            String s = new String(ch, start, length);
            String [] s2 = s.split("\\s");
            if(s2.length > 0) PocetProduktuBezPopisu.l--;
        }
    }
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        super.startElement(uri, localName, qName, attributes); //To change body of generated methods, choose Tools | Templates.
        switch(this.Status)
        {
            case Nedefinovany: SetInStatus(localName); break;
            ///Prijmy do ucetnictvi jsou vydaje a naopak
            case UcetnictviPrijmy : zpracujFakturu(uri, localName, qName, attributes, Vydaje);break;
            case UcetnictviVydaje : zpracujFakturu(uri, localName, qName, attributes, Prijmy);break;
            case Produkty: zpracujProdukt(uri, localName, qName, attributes); break;
        }
    }

    public void endElement(String uri, String localName, String qName) throws SAXException {
        super.endElement(uri, localName, qName); //To change body of generated methods, choose Tools | Templates.
        if(Status != StavovyProstor.Nedefinovany) SetOutStatus(localName);
    }
    public MySaxHandler()
    {
        Prijmy = new MyLong();
        Vydaje = new MyLong();
        Status = StavovyProstor.Nedefinovany;
        PocetProduktuBezPopisu = new MyLong();
    }
}
    
  
