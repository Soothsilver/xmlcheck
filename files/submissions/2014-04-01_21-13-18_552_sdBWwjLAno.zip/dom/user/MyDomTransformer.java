/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;


import org.w3c.dom.Attr;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.TypeInfo;
import org.w3c.dom.UserDataHandler;
/**
 *
 * @author uNitrogenius
 */

public class MyDomTransformer {
    private Integer IdCounter = 0;
    public String GetId(String prefix, Document XML)
    {
        IdCounter++;
        while(true)
        {
            try{
                 XML.getElementById(prefix + IdCounter.toString()).getAttributes();
            }catch(NullPointerException ex){
                break;
            }
            IdCounter++;
        }
        
        return prefix+IdCounter.toString();
    }
    public void NovyZamestnanec(String Jmeno, String CisloOP, Document XML)
    {
        Element element = XML.createElement("Zamestnanec");
        element.setAttribute("jmeno", Jmeno);
        element.setAttribute("cisloOP", CisloOP);
        element.setAttribute("id", GetId("c", XML));
        element.setAttribute("stalyPracovniPomer", "true");
        XML.getElementsByTagName("Zamestnanci").item(0)
            .appendChild(element);
        
    }
    public void SmazatSkladouvouPolozku(String IdProduktu, Document XML)
    {
        NodeList nl =  XML.getElementsByTagName("SkladovaPolozka");
        for(int i = nl.getLength() - 1; i >= 0 ; --i)
        {
            NamedNodeMap att = nl.item(i).getAttributes();
            if(att.getNamedItem("produktId").getNodeValue().equals(IdProduktu)){
                nl.item(i).getParentNode().removeChild(nl.item(i));
            }
        }
    }
    public void SmazatFakturacniPolozku(String IdProduktu, Document XML)
    {
        NodeList nl =  XML.getElementsByTagName("FakturacniPolozka");
        for(int i = nl.getLength() - 1; i >= 0 ; --i)
        {
            NamedNodeMap att = nl.item(i).getAttributes();
            if(att.getNamedItem("produktId").getNodeValue().equals(IdProduktu)){
                nl.item(i).getParentNode().removeChild(nl.item(i));
            }
        }
    }
    public void SmazatZnacku(String Znacka, Document XML)
    {
        NodeList nl =  XML.getElementsByTagName("Produkt");
        for(int i = nl.getLength() - 1; i >= 0 ; --i)
        {
            NamedNodeMap att = nl.item(i).getAttributes();
            if(att.getNamedItem("znacka").getNodeValue().equals(Znacka)){
                SmazatSkladouvouPolozku(att.getNamedItem("id").getNodeValue(), XML);
                SmazatFakturacniPolozku(att.getNamedItem("id").getNodeValue(), XML);
                nl.item(i).getParentNode().removeChild(nl.item(i));
            }//*/
             
        }
    }
public void transform (Document xmlDocument) {
    // libovolne transformace objektu 'xmlDocument'
    // (metoda pracuje primo na objektu, nic nevraci)
    
    /// Pridani zamestnance
    NovyZamestnanec("Evžen Liška", "6459741313", xmlDocument);
    NovyZamestnanec("Ella Antonie Lišková", "1465974154", xmlDocument);
    NovyZamestnanec("Alfred Ostrouch", "2743559716", xmlDocument);
    
    ///Smazani znacky a jejich skladovych polozek a faktur
    /// Nebezpecna operace - maze vsechny reference
    SmazatZnacku("Sony", xmlDocument); 
            
  }
}