
package user;

import java.util.ArrayList;
import java.util.List;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;


public class MySaxHandler extends DefaultHandler {
    Locator locator;
    boolean ovoce = false;
    boolean barva = false;
    boolean jakost3 = false;
    boolean mesic = false;
    int celkovaCenaOvoce = 0;
    int pocetOvoce = 0;
    List<String> barvyOvoce = new ArrayList<String>();
    List<Integer> poctybarevOvoce = new ArrayList<Integer>();
    int pocetOvoceKtereProjdeVDubnuAMaJakost3 = 0;
    

    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    @Override
    public void startDocument() throws SAXException {
    }

    @Override
    public void endDocument() throws SAXException {   
        System.out.println("Prumerna cena ovoce: " + (float)celkovaCenaOvoce/pocetOvoce);
        System.out.println("Nejcastejsi barva ovoce: " + nejcastejsiBarva());
        System.out.println("Pocet ovoce, ktere projde v dubnu a ma jakost 3: " + pocetOvoceKtereProjdeVDubnuAMaJakost3);
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if ( localName.equals("ovoce") ) ovoce = true;
        if ( (ovoce) && (localName.equals("barva")) ) barva = true;
        if ( (ovoce) && (localName.equals("cena")) ) {
            int cena = Integer.parseInt(atts.getValue(0));
            celkovaCenaOvoce += cena;
            pocetOvoce++;
        }
        if ( (ovoce) && (localName.equals("jakost")) ) {
            int jakost = Integer.parseInt(atts.getValue(0));
            if ( jakost == 3 ) jakost3 = true;
        }
        if ( (ovoce) && (localName.equals("mesic")) ) mesic = true;
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if ( localName.equals("ovoce") ) ovoce = false;
        if ( localName.equals("barva") ) barva = false;
        if ( localName.equals("druh") ) jakost3 = false;
        if ( localName.equals("mesic") ) mesic = false;
    }

    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        if ( barva ) {
            String b = new String(chars).substring(start, start+length).trim();
            boolean nalezeno = false;
            for (int i = 0; i < barvyOvoce.size(); i++) {
                if ( barvyOvoce.get(i).equals(b) ) {
                    poctybarevOvoce.set(i, poctybarevOvoce.get(i) + 1);
                    nalezeno = true;
                }
            }
            if( !nalezeno ) {
                barvyOvoce.add(b);
                poctybarevOvoce.add(1);
            }
        }
        if ( jakost3 && mesic ) {
            int mesic2 = Integer.parseInt(new String(chars).substring(start, start+length).trim());
            if ( mesic2 == 4 ) pocetOvoceKtereProjdeVDubnuAMaJakost3++;
        }
    }
    
    public String nejcastejsiBarva(){
        int max = 0;
        int poziceMax = 0;
        for (int i = 0; i < barvyOvoce.size(); i++) {
            if( max < poctybarevOvoce.get(i) ) {
                max = poctybarevOvoce.get(i);
                poziceMax = i;
            }
        }
        return barvyOvoce.get(poziceMax);
    }
}