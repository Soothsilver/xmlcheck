
package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class MyDomTransformer {
    
    public void transform (Document xmlDocument) {
        // pridam novy druh ovoce - jahodu
        Element jahoda = xmlDocument.createElement("druh");
        jahoda.setAttribute("value", "jahoda");
        Element jakost = xmlDocument.createElement("jakost");
        jakost.setAttribute("value", "1");
        jahoda.appendChild(jakost);
        jahoda.appendChild(xmlDocument.createElement("barva")).setTextContent("cervena");
        Element cena = xmlDocument.createElement("cena");
        cena.setAttribute("value", "42");
        jahoda.appendChild(cena);
        Element trvanlivost = xmlDocument.createElement("trvanlivost");
        trvanlivost.appendChild(xmlDocument.createElement("rok")).setTextContent("2014");
        trvanlivost.appendChild(xmlDocument.createElement("mesic")).setTextContent("6");
        trvanlivost.appendChild(xmlDocument.createElement("den")).setTextContent("8");
        jahoda.appendChild(trvanlivost);
        
        NodeList list = xmlDocument.getElementsByTagName("ovoce");
        Element ovoce = (Element)list.item(0);
        ovoce.appendChild(jahoda);
        
        // smazu ovoce, ktere neni zelene a ma jakost 3
        NodeList druhy = ovoce.getElementsByTagName("druh");
        for (int i = 0; i < druhy.getLength(); i++) {
            Element druh = (Element)druhy.item(i);
            String txt = druh.getElementsByTagName("jakost").item(0).getAttributes().item(0).getTextContent();
            int jakost2 = Integer.parseInt(txt);
            String barva2 = druh.getElementsByTagName("barva").item(0).getTextContent();
            if ( ( jakost2 == 3 ) && !( barva2.equals("zelena") ) ) {
                druh.getParentNode().removeChild(druh);
            }
        }
                
    }
}