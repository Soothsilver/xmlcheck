package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer {

    // 1) smazani vsech  autoru, kteri nejsou nazivu
    // 2) pridani noveho autora
    
    public void transform(Document doc) { // code transforming doc object // (method works on the object itself - no return value)

        // 1)
        NodeList autori = doc.getElementsByTagName("autor");

        for (int i = autori.getLength() - 1; i >= 0; --i) {
            Node autor = autori.item(i);
            NodeList nl = autor.getChildNodes();
            boolean nazivu = false;
            if (nl != null) {
                for (int j = nl.getLength() - 1; j >= 0; --j) {
                    if (nl != null && nl.item(j) != null && nl.item(j).getLocalName().equals("nazivu")) {  // XMLChecker na tomto radku hlasi null pointer exception
                        nazivu = true;
                        break;
                    }
                }
            }

            if (!nazivu) {
                Node parent = autor.getParentNode();
                parent.removeChild(autor);
            }

        }
        
        
        // 2)
        if (doc.getElementsByTagName("autori").getLength() <= 0) {
            doc.appendChild(doc.createElement("autori"));
        }
        
        Node autori2 = doc.getElementsByTagName("autori").item(0);

        Element novyAutor = doc.createElement("autor");

        int i = 0;
        String id = "aid_" + i;
        while (doc.getElementById(id) != null) {
            ++i;
            id = "aid_" + i;
        }

        novyAutor.setAttribute("id", id);
        novyAutor.appendChild(doc.createElement("jmeno")).setTextContent("Marek");
        novyAutor.appendChild(doc.createElement("prijmeni")).setTextContent("Korek");
        novyAutor.appendChild(doc.createElement("popis")).setTextContent("110");
        novyAutor.appendChild(doc.createElement("pohlavi")).setTextContent("muz");
        novyAutor.appendChild(doc.createElement("nazivu"));
        novyAutor.appendChild(doc.createElement("narodnost")).setTextContent("SVK");
        novyAutor.appendChild(doc.createElement("zamestnani")).setTextContent("Obchodnik s destem a potrebami pro koupelnu");
        novyAutor.appendChild(doc.createElement("vtipnost")).setTextContent("4");
        
        
        autori2.appendChild(novyAutor);
    }

}
