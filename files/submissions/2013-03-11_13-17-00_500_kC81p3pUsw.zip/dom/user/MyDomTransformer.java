package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author Chmirko
 */
public class MyDomTransformer
{
   public void transform(Document xmlDocument)
   {
      // DOM tree processing
      processTree(xmlDocument);
   }

   /**
    * Process document tree
    *
    * @param doc Document to be parsed
    */
   private static void processTree(Document doc)
   {
      // FIND FREE ID
      int freeId = 0;
      NodeList nodes = doc.getChildNodes();
      for (int i = 0; i < nodes.getLength(); ++i)
      {
         if (nodes.item(i).getNodeType() == Node.ELEMENT_NODE && "finswimming".equals(nodes.item(i).getNodeName()))
         {
            nodes = nodes.item(i).getChildNodes();
            for (int j = 0; j < nodes.getLength(); ++j)
            {
               if ("people".equals(nodes.item(j).getNodeName()))
               {
                  nodes = nodes.item(j).getChildNodes();
                  for (int k = 0; k < nodes.getLength(); ++k)
                  {
                     if ("person".equals(nodes.item(k).getNodeName()))
                     {
                        String perId = nodes.item(k).getAttributes().getNamedItem("id").getTextContent();
                        int num = Integer.parseInt(perId.substring(3));
                        if (num >= freeId)
                        {
                           freeId = num + 1;
                        }
                     }
                  }
                  break;
               }
            }
            break;
         }
      }

      // CREATE PERSON
      Element person = doc.createElement("person");
      person.setAttribute("id", "per" + freeId);
      person.setAttribute("name", "Miroslav");
      person.setAttribute("surname", "Chomut");

      Element address = doc.createElement("address");
      Element street = doc.createElement("street");
      street.setTextContent("Doma");
      Element city = doc.createElement("city");
      city.setTextContent("Zvolen");
      Element state = doc.createElement("state");
      state.setTextContent("Slovakia");
      Element inspection = doc.createElement("inspection");
      inspection.setAttribute("year", "2012");
      address.appendChild(street);
      address.appendChild(city);
      address.appendChild(state);
      address.appendChild(inspection);

      Element bio = doc.createElement("biometrics");
      Element height = doc.createElement("height");
      Element siMeter = doc.createElement("SI_Meter");
      siMeter.setTextContent("1");
      Element siCentiMeter = doc.createElement("SI_centimeter");
      siCentiMeter.setTextContent("74");
      height.appendChild(siMeter);
      height.appendChild(siCentiMeter);
      Element weight = doc.createElement("weight");
      Element siKilogram = doc.createElement("SI_kilogram");
      siKilogram.setTextContent("57");
      weight.appendChild(siKilogram);
      bio.appendChild(height);
      bio.appendChild(weight);

      Element sign = doc.createElement("HTMLSignatue");
      sign.setTextContent("<![CDATA[\n<b>Hello</b> <h2>WORLD</h2>\n]]>");

      Element anySign = doc.createElement("ANYSignatue");
      anySign.setTextContent("chmirko");

      person.appendChild(address);
      person.appendChild(bio);
      person.appendChild(sign);
      person.appendChild(anySign);

      // INSERT PERSON
      nodes = doc.getChildNodes();
      for (int i = 0; i < nodes.getLength(); ++i)
      {
         if (nodes.item(i).getNodeType() == Node.ELEMENT_NODE && "finswimming".equals(nodes.item(i).getNodeName()))
         {
            nodes = nodes.item(i).getChildNodes();
            for (int j = 0; j < nodes.getLength(); ++j)
            {
               if ("people".equals(nodes.item(j).getNodeName()))
               {
                  nodes.item(j).appendChild(person);
                  break;
               }
            }
            break;
         }
      }

      // Eliminate old licences
      nodes = doc.getChildNodes();
      for (int h = 0; h < nodes.getLength(); ++h)
      {
         if (nodes.item(h).getNodeType() == Node.ELEMENT_NODE && "finswimming".equals(nodes.item(h).getNodeName()))
         {
            nodes = nodes.item(h).getChildNodes();
            for (int i = 0; i < nodes.getLength(); ++i)
            {
               if ("CMAS".equals(nodes.item(i).getNodeName()))
               {
                  NodeList oldNodes_i = nodes;
                  nodes = nodes.item(i).getChildNodes();
                  for (int j = 0; j < nodes.getLength(); ++j)
                  {
                     if ("CMAS_Competitors".equals(nodes.item(j).getNodeName()))
                     {
                        nodes = nodes.item(j).getChildNodes();
                        for (int k = 0; k < nodes.getLength(); ++k)
                        {
                           if ("CMAS_Competitor".equals(nodes.item(k).getNodeName()))
                           {
                              NodeList oldNodes_k = nodes;
                              nodes = nodes.item(k).getChildNodes();
                              for (int l = 0; l < nodes.getLength(); ++l)
                              {
                                 if ("CMAS_PP".equals(nodes.item(l).getNodeName()) || "CMAS_OP".equals(nodes.item(l).getNodeName()) || "CMAS_DPP".equals(nodes.item(l).getNodeName()))
                                 {
                                    NodeList oldNodes_l = nodes;
                                    nodes = nodes.item(l).getChildNodes();
                                    for (int m = 0; m < nodes.getLength(); ++m)
                                    {
                                       if ("Licence".equals(nodes.item(m).getNodeName()))
                                       {
                                          if (Integer.parseInt(nodes.item(m).getAttributes().getNamedItem("year").getTextContent()) <= 2010)
                                          {
                                             oldNodes_l.item(l).removeChild(nodes.item(m));
                                          }
                                          // NO BREAK LICENCE
                                       }
                                    }
                                    nodes = oldNodes_l;
                                    // NO BREAK PP/OP/DPP
                                 }
                              }
                              nodes = oldNodes_k;
                              // NO BREAK CMAS COMPETITOR
                           }
                        }
                        break;
                     }
                  }
                  nodes = oldNodes_i;
                  // NO BREAK after CMAS
               }
               else if ("national".equals(nodes.item(i).getNodeName()))
               {
                  nodes = nodes.item(i).getChildNodes();
                  for (int j = 0; j < nodes.getLength(); ++j)
                  {
                     if ("nation".equals(nodes.item(j).getNodeName()))
                     {
                        NodeList oldNodes_j = nodes;
                        nodes = nodes.item(j).getChildNodes();
                        for (int k = 0; k < nodes.getLength(); ++k)
                        {
                           if ("competitors".equals(nodes.item(k).getNodeName()))
                           {
                              nodes = nodes.item(k).getChildNodes();
                              for (int l = 0; l < nodes.getLength(); ++l)
                              {
                                 if ("competitor".equals(nodes.item(l).getNodeName()))
                                 {
                                    NodeList oldNodes_l = nodes;
                                    nodes = nodes.item(l).getChildNodes();
                                    for (int m = 0; m < nodes.getLength(); ++m)
                                    {
                                       if ("Licence".equals(nodes.item(m).getNodeName()))
                                       {
                                          if (Integer.parseInt(nodes.item(m).getAttributes().getNamedItem("year").getTextContent()) <= 2010)
                                          {
                                             oldNodes_l.item(l).removeChild(nodes.item(m));
                                          }
                                          // NO BREAK LICENCE
                                       }
                                    }
                                    nodes = oldNodes_l;
                                    // NO BREAK COMPETITOR
                                 }
                              }
                              break;
                           }
                        }
                        nodes = oldNodes_j;
                        // NO BREAK after nation
                     }
                  }
                  break;
               }
            }
            break;
         }
      } // EOF ELIMINATING LOOP
   }
}
