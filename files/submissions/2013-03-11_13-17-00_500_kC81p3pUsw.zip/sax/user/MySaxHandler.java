/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.util.LinkedList;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * @author Chmirko
 */
public class MySaxHandler extends DefaultHandler
{
   /**
    * Class for year count storage
    *
    * @author Chmirko
    */
   class YearCount
   {
      public int year;
      public int count;

      public YearCount(int year)
      {
         this.year = year;
         count = 1;
      }
   }

   class Swimmer
   {
      public String id;
      public long totalTimeSwam;
      public String name;
      public String surname;
      public boolean active2012 = false;

      public Swimmer(String id, String name, String surname)
      {
         this.id = id;
         this.name = name;
         this.surname = surname;
         totalTimeSwam = 0;
      }
   }

   // Helper variable to store location of the handled event
   Locator locator;
   // All years and their licences
   LinkedList<YearCount> licenceYears = new LinkedList<YearCount>();
   // Swimmers collected data
   LinkedList<Swimmer> swimmers = new LinkedList<Swimmer>();
   // Total time swum by all competitors on all championships
   long totalTimeSwam = 0;
   // Person ID used on various places
   String curPersonId;
   // Navigator
   boolean inCMAS;
   boolean inCMAS_Competitors;
   boolean inCMAS_Competitor;
   boolean inPeople = false;
   boolean inResults = false;
   boolean inChampResults = false;
   boolean inChampResult = false;
   boolean inResTime = false;

   /**
    * Sets the locator
    *
    * @param Locator locator location in the file
    */
   @Override
   public void setDocumentLocator(Locator locator)
   {
      this.locator = locator;
   }

   /**
    * Method to handle "document start"
    *
    * @throws SAXException
    */
   @Override
   public void startDocument() throws SAXException
   {
      // ...
   }

   /**
    * Method to handle "document end"
    *
    * @throws SAXException
    */
   @Override
   public void endDocument() throws SAXException
   {
      // document finished, time to write results

      // TOTAL TIME SWUM
      long timeHuns = totalTimeSwam % 100;
      totalTimeSwam -= timeHuns;
      totalTimeSwam /= 100;
      long timeSec = totalTimeSwam % 60;
      totalTimeSwam -= timeSec;
      totalTimeSwam /= 60;
      long timeMins = totalTimeSwam;
      System.out.format("Total time swum: %d:%02d,%02d", timeMins, timeSec, timeHuns);

      // LICENCES BY YEAR
      System.out.println();
      System.out.println("Licensed swimmers by year (DPP, OP and PP counted separately)");
      for (YearCount curCount : licenceYears)
      {
         System.out.println(curCount.year + " -> " + curCount.count);
      }

      // MOST ACTIVE CMAS SWIMMER 2012
      System.out.println();
      System.out.println("Swimmer with most time swimmed CMAS active in 2012");
      Swimmer best = null;
      for (Swimmer swimmer : swimmers)
      {
         if (swimmer.active2012 && (best == null || best.totalTimeSwam < swimmer.totalTimeSwam))
         {
            best = swimmer;
         }
      }
      timeHuns = best.totalTimeSwam % 100;
      best.totalTimeSwam -= timeHuns;
      best.totalTimeSwam /= 100;
      timeSec = best.totalTimeSwam % 60;
      best.totalTimeSwam -= timeSec;
      best.totalTimeSwam /= 60;
      timeMins = best.totalTimeSwam;
      System.out.format(best.name + " " + best.surname + " time swum: %d:%02d,%02d", timeMins, timeSec, timeHuns);
   }

   /**
    * Method to handle "begin element"
    *
    * @param uri URI of the element namespace (empty if element is no
    * namespace)
    * @param localName local name of the element (never empty)
    * @param qName qualified name (prefix-URI + ':' + localName, if the element
    * is in some namespace or localName otherwise)
    * @param atts Element's attributes
    * @throws SAXException
    */
   @Override
   public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
   {
      // Navigation control
      if (localName.equals("CMAS"))
      {
         inCMAS = true;
      }
      if (localName.equals("CMAS_Competitor"))
      {
         inCMAS_Competitor = true;
      }
      if (localName.equals("CMAS_Competitors"))
      {
         inCMAS_Competitors = true;
      }
      if (localName.equals("people"))
      {
         inPeople = true;
      }
      if (localName.equals("results"))
      {
         inResults = true;
      }
      if (localName.equals("champResults"))
      {
         inChampResults = true;
      }
      if (localName.equals("champResult"))
      {
         inChampResult = true;
      }
      if (localName.equals("resTime"))
      {
         inResTime = true;
      }

      // Acquire person ID
      if (inResults && inChampResults && localName.equals("champResult"))
      {
         curPersonId = atts.getValue("swimmer");
      }
      if (inCMAS && inCMAS_Competitors && localName.equals("CMAS_Competitor"))
      {
         curPersonId = atts.getValue("person");
      }

      // Harvest swimmers
      if (inPeople && localName.equals("person"))
      {
         swimmers.add(new Swimmer(atts.getValue("id"), atts.getValue("name"), atts.getValue("surname")));
      }

      // Harvest years for licences
      if (localName.equals("Licence"))
      {
         String yearExtracted = atts.getValue("year");
         int yearParsed = Integer.parseInt(yearExtracted);

         // Year have allready been seen
         for (YearCount curCount : licenceYears)
         {
            if (curCount.year == yearParsed)
            {
               ++curCount.count;
               yearParsed = -1;
               break;
            }
         }
         // year seen for the first time
         if (yearParsed != -1)
         {
            licenceYears.add(new YearCount(yearParsed));
         }

         // CMAS Licence seen for year 2012
         if (yearParsed == 2012 && inCMAS && inCMAS_Competitors && inCMAS_Competitor)
         {
            for (Swimmer swimmer : swimmers)
            {
               if (swimmer.id.equals(curPersonId))
               {
                  swimmer.active2012 = true;
                  break;
               }
            }
         }
      }
   }

   /**
    * Method to handle "element end"
    *
    * @param uri URI of the element namespace (empty if element is no
    * namespace)
    * @param localName local name of the element (never empty)
    * @param qName qualified name (prefix-URI + ':' + localName, if the element
    * is in some namespace or localName otherwise)
    * @param atts Element's attributes
    * @throws SAXException
    */
   @Override
   public void endElement(String uri, String localName, String qName) throws SAXException
   {
      // Navigation control
      if (localName.equals("CMAS"))
      {
         inCMAS = true;
      }
      if (localName.equals("CMAS_Competitor"))
      {
         inCMAS_Competitor = true;
      }
      if (localName.equals("CMAS_Competitors"))
      {
         inCMAS_Competitors = true;
      }
      if (localName.equals("people"))
      {
         inPeople = false;
      }
      if (localName.equals("results"))
      {
         inResults = false;
      }
      if (localName.equals("champResults"))
      {
         inChampResults = false;
      }
      if (localName.equals("champResult"))
      {
         inChampResult = false;
      }
      if (localName.equals("resTime"))
      {
         inResTime = false;
      }
   }

   /**
    * Method to handle "character data" SAX parser can process data in various
    * batches. so we can't rely that whole whole text content will be delivered
    * in one call Text is in array 'chars' from position ('start') to ('start'
    * + 'length' - 1)
    *
    * @param chars Array with char data
    * @param start Index of the begin of valid data
    * @param length Length of the valid data
    * @throws SAXException
    */
   @Override
   public void characters(char[] chars, int start, int length) throws SAXException
   {
      // Tima addition
      if (inResTime && inChampResult && inChampResults && inResults)
      {
         // Extract text
         String txt = "";
         for (int i = start; i < start + length; ++i)
         {
            txt += chars[i];
         }

         // Sum time into allSum
         totalTimeSwam += Integer.parseInt(txt.substring(0, 2)) * 6000;
         totalTimeSwam += Integer.parseInt(txt.substring(3, 5)) * 100;
         totalTimeSwam += Integer.parseInt(txt.substring(6, 8));

         // Also add to designated swimmer
         for (Swimmer swimmer : swimmers)
         {
            if (swimmer.id.equals(curPersonId))
            {
               swimmer.totalTimeSwam += Integer.parseInt(txt.substring(0, 2)) * 6000;
               swimmer.totalTimeSwam += Integer.parseInt(txt.substring(3, 5)) * 100;
               swimmer.totalTimeSwam += Integer.parseInt(txt.substring(6, 8));
            }
         }
      }
   }

   /**
    * Method to handle " start of namespace declaration"
    *
    * @param prefix Prefix of the namespace
    * @param uri URI of the namespace
    * @throws SAXException
    */
   @Override
   public void startPrefixMapping(String prefix, String uri) throws SAXException
   {
      // ...
   }

   /**
    * Method to handle "end of namespace declaration"
    *
    * @param prefix
    * @throws SAXException
    */
   @Override
   public void endPrefixMapping(String prefix) throws SAXException
   {
      // ...
   }

   /**
    * Method to handle "ignoring of whitespaces" Text is in array 'chars' from
    * position ('start') to ('start' + 'length' - 1)
    *
    * @param chars Array with char data
    * @param start Index of the begin of valid data
    * @param length Length of the valid data
    * @throws SAXException
    * @throws SAXException
    */
   @Override
   public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException
   {
      // ...
   }

   /**
    * Method to handle "processing instructions"
    *
    * @param target The processing instruction target
    * @param data The processing instruction data
    * @throws SAXException
    */
   @Override
   public void processingInstruction(String target, String data) throws SAXException
   {
      // ...
   }

   /**
    * Method to handle "unprocessed entity"
    *
    * @param name
    * @throws SAXException
    */
   @Override
   public void skippedEntity(String name) throws SAXException
   {
      // ...
   }
}
