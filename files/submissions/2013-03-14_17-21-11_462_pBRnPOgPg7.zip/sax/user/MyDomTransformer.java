package user;
import org.w3c.dom.Document;
public class MyDomTransformer {
public void transform (Document xmlDocument) {
    // libovolne transformace objektu 'xmlDocument'
    // (metoda pracuje primo na objektu, nic nevraci)
  }
}
