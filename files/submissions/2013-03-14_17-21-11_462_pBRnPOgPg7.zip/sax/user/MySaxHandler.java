package user;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
	
	private final double sunMass=1.9891e30;
	
	private double averageMass;
	private int massCount;
	private double averageCompositeAmount;
	private int compositeAmountCount;
	private int planetsWithSatelliteCount;
	
	boolean inMass;
	boolean canCountSatellite;
	StringBuilder sb = new StringBuilder();
	
	
    /**
     * Method to handle "document start"
     *
     * @throws SAXException
     */
    @Override
    public void startDocument() throws SAXException {
        averageMass=0;
        massCount=0;
        averageCompositeAmount=0;
        compositeAmountCount=0;
        planetsWithSatelliteCount=0;
        sb.delete(0, sb.length());
        inMass=false;
        canCountSatellite=false;
    }

    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
    	System.out.println("Average mass:"+averageMass+" Mo");
    	System.out.println("Average composite amount:"+averageCompositeAmount+"%");
    	System.out.println("Planets with satellite count:"+planetsWithSatelliteCount);
    }

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if(localName.equals("mass")){
        	inMass=true;
        }else if(localName.equals("composite")){
        	double amount = Double.parseDouble(atts.getValue("amount").replaceAll("%", ""));
        	averageCompositeAmount = (averageCompositeAmount*compositeAmountCount+amount)/++compositeAmountCount;
        }else if(localName.equals("planet")){
        	canCountSatellite=true;
        }else if(localName.equals("satellite") && canCountSatellite){
        	canCountSatellite=false;
        	planetsWithSatelliteCount++;
        }
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if(localName.equals("mass")){
        	inMass=false;
        	String value = sb.toString();
        	double mass;
        	if(value.matches("[0-9\\.,e]* kg")){
        		double dv = Double.parseDouble(value.substring(0, value.length()-2).replaceAll(" ", ""));
        		mass = dv/sunMass;
        	}else if(value.matches("[0-9\\.,e]* sun mass")){
        		mass = Double.parseDouble(value.replaceAll("sun mass", "").trim());
        	}else
        		throw new SAXException("Incorrect mass format");
        	averageMass = (averageMass*massCount+mass)/++massCount;
        	//System.out.println(mass);
        }else if(localName.equals("planet")){
        	canCountSatellite=false;
        }
    	sb.delete(0, sb.length());
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
    	if(inMass)
    		sb.append(chars, start, length);
    }
}
