package user;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer {
  
  public void transform (Document xmlDocument) {
		addMars(xmlDocument);
		sortComposites(xmlDocument);
  }        

	private void sortComposites(Document xmlDocument) {
		Comparator<Element> comp = new Comparator<Element>() {
			public int compare(Element o1, Element o2) {
				double amounta = Double.parseDouble(o1
						.getAttribute("amount").replaceAll("%", "")
						.trim());
				double amountb = Double.parseDouble(o2
						.getAttribute("amount").replaceAll("%", "")
						.trim());
				return -Double.compare(amounta, amountb);
			}
		};
		NodeList nl = xmlDocument.getElementsByTagName("composition");
		int index = 0;
		Node current = null;
		while ((current = nl.item(index++)) != null) {
			if (current.getNodeType() == Node.ELEMENT_NODE) {
				Element composition = (Element) current;
				NodeList cl = composition.getChildNodes();
				int jindex = 0;
				Node currentChild = null;
				ArrayList<Element> composites = new ArrayList<Element>();
				while ((currentChild = cl.item(jindex++)) != null) {
					if (currentChild.getNodeType() == Node.ELEMENT_NODE) {
						Element child = (Element) currentChild;
						composites.add(child);
					}
				}
				Collections.sort(composites, comp);
				removeChildren(current);
				for(Element e : composites){
					current.appendChild(e);
				}
			}
		}
	}

	private void removeChildren(Node node) {
	    NodeList childNodes = node.getChildNodes();
	    int length = childNodes.getLength();
	    for (int i = 0; i < length; i++) {
	        Node childNode = childNodes.item(i);
	        if(childNode instanceof Element) {
	            if(childNode.hasChildNodes()) {
	            	removeChildren(childNode);                
	            }        
	            node.removeChild(childNode);  
	        }
	    }
	}

	private void addMars(Document xmlDocument) {
		Element planet = xmlDocument.createElement("planet");
		planet.setAttribute("id", "PLA_9");
		Element temp;
		temp = xmlDocument.createElement("name");
		temp.setTextContent("Mars");
		planet.appendChild(temp);
		temp = xmlDocument.createElement("volume");
		temp.setTextContent("1.6318e11 km3");
		planet.appendChild(temp);
		temp = xmlDocument.createElement("mass");
		temp.setTextContent("6.4185e23 kg");
		planet.appendChild(temp);
		temp = xmlDocument.createElement("orbitalPeriod");
		temp.setTextContent("686.971 day");
		planet.appendChild(temp);
		temp = xmlDocument.createElement("escapeVelocity");
		temp.setTextContent("5.027 km/s");
		planet.appendChild(temp);
		temp = xmlDocument.createElement("equatorialRadius");
		temp.setTextContent("3396.2 km");
		planet.appendChild(temp);
		temp = xmlDocument.createElement("equatorialGravity");
		temp.setTextContent("3.711 m/s2");
		planet.appendChild(temp);
		Element orbit = xmlDocument.createElement("orbit");
		temp = xmlDocument.createElement("aphelion");
		temp.setTextContent("1.665 AU");
		orbit.appendChild(temp);
		temp = xmlDocument.createElement("perihelion");
		temp.setTextContent("1.381 AU");
		orbit.appendChild(temp);
		planet.appendChild(orbit);
		Element satellites = xmlDocument.createElement("satellites");
		temp = xmlDocument.createElement("satellite");
		temp.setAttribute("name", "Phobos");
		temp.setAttribute("type", "moon");
		satellites.appendChild(temp);
		temp = xmlDocument.createElement("satellite");
		temp.setAttribute("name", "Deimos");
		temp.setAttribute("type", "moon");
		satellites.appendChild(temp);
		planet.appendChild(satellites);
		Element composition = xmlDocument.createElement("composition");
		temp = xmlDocument.createElement("composite");
		temp.setAttribute("amount", "95.32%");
		temp.setAttribute("name", "carbon dioxide");
		composition.appendChild(temp);
		temp = xmlDocument.createElement("composite");
		temp.setAttribute("amount", "2.7%");
		temp.setAttribute("name", "nitrogen");
		composition.appendChild(temp);
		temp = xmlDocument.createElement("composite");
		temp.setAttribute("amount", "1.6%");
		temp.setAttribute("name", "argon");
		composition.appendChild(temp);
		temp = xmlDocument.createElement("composite");
		temp.setAttribute("amount", "0.13%");
		temp.setAttribute("name", "oxygen");
		composition.appendChild(temp);
		planet.appendChild(composition);

		xmlDocument.getElementById("SOL_1").appendChild(planet);
	}
}
