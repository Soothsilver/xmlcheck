package user;
import org.xml.sax.helpers.DefaultHandler;
public class MySaxHandler extends DefaultHandler {
  // override metod DefaultHandleru
}
