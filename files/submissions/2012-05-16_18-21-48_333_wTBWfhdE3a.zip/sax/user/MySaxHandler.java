package user;

import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler; 
public class MySaxHandler extends DefaultHandler {
	
    Locator locator;
    private int elementCount;
    
    public MySaxHandler()
    {
    	this.elementCount = 0;
    }
    
    /**
     * Nastavi locator
     */     
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

        
    /**
     * Obsluha udalosti zaciatok elementu
     * @param uri URI jmenn�ho prostoru elementu (pr�zdn�, pokud element nen� v ��dn�m jmenn�m prostoru)
     * @param localName Lok�ln� jm�no elementu (v�dy nepr�zdn�)
     * @param qName Kvalifikovan� jm�no (tj. prefix-uri + ':' + localName, pokud je element v n�jak�m jmenn�m prostoru, nebo localName, pokud element nen� v ��dn�m jmenn�m prostoru)
     * @param atts Atributy elementu     
     */     
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
    	this.elementCount++;
    }

    
    /**
     * Obsluha udalosti "konec dokumentu"
     */     
    public void endDocument() throws SAXException {
        //vypise pocet elementov
    	System.out.println(String.format("Pocet elementov v dokumente : %d", this.elementCount));
    }
    
    
}