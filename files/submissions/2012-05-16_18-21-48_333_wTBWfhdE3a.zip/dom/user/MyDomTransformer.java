package user;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
public class MyDomTransformer 
{ 
	
	public void transform (Document xmlDocument) { 
		/*DFS prehladavanie dokumentu, ked narazime na element s atributami
		ziskame atributy a pre kazdy vytvorime element*/
		
		//ziskame root element
		Node rootNode = xmlDocument.getDocumentElement();
		dfs(xmlDocument, rootNode);
	}
	
	//search tree
	private void dfs(Document doc, Node rootNode)	{
		//pre kazdeho syna rootNode
		NodeList rootChilds = rootNode.getChildNodes();
		int len = rootChilds.getLength();
		for (int i = 0; i < len; i++)
		{
			//ziskanie konkretneho syna
			Node child = rootChilds.item(i);
			
			//spracovanie syna
			try
			{
				NamedNodeMap atts = ((Element) child).getAttributes();
			
				//ak ma element nejake atributy, prevedieme ich na elementy
				for (int j = 0; j < atts.getLength(); j++)
				{
					Node attribute = atts.item(j);
					//ziskame nazov atributu a hodnotu
					String name = attribute.getNodeName();
					String value = attribute.getNodeValue();
					//vytvorime novy element
					Node newChild = doc.createElement(name);
					//pridame element
					newChild.setTextContent(value);
					child.appendChild(newChild);
					//odstranime atribut
					((Element) child).removeAttribute(name);
				}
			
				//rekurzivne volanie
				dfs(doc, child);
			}catch (ClassCastException e)
			{
				//node is not valid element
				continue;
			}
		}
	}


}

