/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * @author Dominik
 */
public class MySaxHandler extends DefaultHandler {
    
    private int lengthSum = 0, elementCount = 0;
    public double average = 0;
    
    @Override
    public void startElement (String uri, String localName,String qName, Attributes attributes) throws SAXException
    {
        lengthSum += qName.length();
        elementCount++;
    }
    
    @Override
    public void endElement (String uri, String localName, String qName)
        throws SAXException
    {
        // no op
    }

    @Override
    public void endDocument ()
        throws SAXException
    {
        average = (double) lengthSum / (double) elementCount;
        System.out.println("Length: "+lengthSum);
        System.out.println("Count: "+elementCount);
        System.out.println("Average: "+average);
    }    
    
}