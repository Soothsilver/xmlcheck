/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.io.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

/**
 *
 * @author Dominik
 */
public class MyDomTransformer {
    
    public void transform(Document doc) throws Exception{
        Element e = doc.getDocumentElement();        
        searchElement(e, doc);
        print(doc);
    }
    
    private void searchElement(Element e, Document doc){
        Node aux;
        Element newNode;
        NodeList nl = e.getChildNodes();
        boolean textContent = false;
        for(int i=0; i<nl.getLength(); i++){
            aux = nl.item(i);
            if(aux.getNodeType()==Node.TEXT_NODE) textContent = true;
            if(aux.getNodeType()!=Node.ELEMENT_NODE) continue;
            searchElement((Element)aux, doc);
        }
        if(textContent) return;
        NamedNodeMap nnm = e.getAttributes();
        for(int i=0; i<nnm.getLength(); i++){
            aux = nnm.item(i);
            newNode = doc.createElement(aux.getNodeName());
            newNode.setTextContent(aux.getTextContent());
            nnm.removeNamedItem(aux.getNodeName());
            e.appendChild(newNode);
            //System.out.println(e.getTagName()+"["+aux.getNodeName()+": "+aux.getTextContent()+"]");
        }
        
    }
 
    
    public void print(Document xmlDocument) throws Exception{
        StreamResult r=new StreamResult(new BufferedOutputStream(new FileOutputStream(new File("temp.xml"))));
        Transformer T=TransformerFactory.newInstance().newTransformer();
        T.transform(new DOMSource(xmlDocument), r);    
    }
}
