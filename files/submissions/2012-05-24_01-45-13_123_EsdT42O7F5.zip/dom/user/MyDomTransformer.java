package user;

import java.util.Stack;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

public class MyDomTransformer {
  /**
   * Vsechny atributy nahradi clenskym elementem.
   */
  public static void transform(Document document) {
    Stack<Node> elements = new Stack<Node>();
    elements.push(document.getDocumentElement());

    while (!elements.empty()) {
      Node e = elements.pop();
      NamedNodeMap attrs = e.getAttributes();

      if (attrs != null) {
        while (attrs.getLength() > 0) {
          Node a = attrs.item(0);

          Node newElem = document.createElement(a.getNodeName());
          newElem.appendChild(document.createTextNode(a.getNodeValue()));

          e.insertBefore(newElem, e.getFirstChild());

          attrs.removeNamedItem(a.getNodeName());
        }
      }

      Node child = e.getFirstChild();
      while (child != null) {
        elements.push(child);
        child = child.getNextSibling();
      }
    }
  }
}

