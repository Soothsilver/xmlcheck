package user;

import java.util.Stack;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
  private int elemCount = 0;
  private int empty = 0;
  private int withText = 0;
  private int withSubelems = 0;
  private int mixed = 0;

  private static class ElemRecord {
    public boolean seenSubelem = false;
    public boolean seenText = false;
  }

  private Stack<ElemRecord> elems = new Stack<ElemRecord>();

  public void startElement(String uri, String localName, String qName,
                           Attributes attributes) {
    ++elemCount;

    if (!elems.empty()) {
      ElemRecord parent = elems.peek();
      if (!parent.seenSubelem) {
        ++withSubelems;

        if (parent.seenText)
          ++mixed;
      }

      parent.seenSubelem = true;
    }

    elems.push(new ElemRecord());
  }

  public void characters(char[] ch, int start, int length) {
    assert !elems.empty();
    ElemRecord parent = elems.peek();

    for (int i = 0; i < length; ++i) {
      if (!Character.isWhitespace(ch[start + i])) {
        if (!parent.seenText) {
          ++withText;

          if (parent.seenSubelem)
            ++mixed;
        }

        parent.seenText = true;
        break;
      }
    }
  }

  public void endElement(String uri, String localName, String qName) {
    assert !elems.empty();
    ElemRecord parent = elems.peek();

    if (!parent.seenSubelem && !parent.seenText)
      ++empty;

    elems.pop();
  }

  public void endDocument() {
    System.out.println("Dokument ma " + elemCount + " elementu. Z toho:");
    System.out.println("  -- " + empty + " je prazdnych");
    System.out.println("  -- " + withText + " obsahuje text");
    System.out.println("  -- " + withSubelems + " obsahuje podelementy");
    System.out.println("  -- " + mixed + " obsahuje text i podelementy.");
  }
}
