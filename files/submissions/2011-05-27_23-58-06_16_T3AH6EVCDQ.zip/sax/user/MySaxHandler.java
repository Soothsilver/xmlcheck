/**
 * @author simon
 */
package user;
import java.util.ArrayList;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;



public class MySaxHandler extends DefaultHandler {

    ArrayList<Integer> attrLength;

    @Override
    public void startDocument() throws SAXException {
        attrLength = new ArrayList<Integer>();
    }

    @Override
    public void endDocument() throws SAXException {

        Integer lengthSum = 0, lengthMax = 0;
        for ( Integer length : attrLength ) {
            lengthSum += length;
            if ( length > lengthMax ) {
                lengthMax = length;
            }
        }
        System.out.print("Pocet atributu: " + attrLength.size() + "\n");
        System.out.print("Maximalni delka atributu: " + lengthMax + "\n");
        System.out.print("Prumerna delka atributu: " + ( lengthSum / attrLength.size() ) + "\n");
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        for ( int i=0; i < atts.getLength(); i++ ) {
            attrLength.add(atts.getValue(i).length());
        }
    }

    /*
    public static void main(String[] args) {
        try {
            XMLReader parser = XMLReaderFactory.createXMLReader();
            InputSource source = new InputSource("data.xml");
            parser.setContentHandler(new MySaxHandler());
            parser.parse(source);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    */
}