/**
 * @author kvass5am
 */
package user;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Element;

public class MyDomTransformer {
    
    private static void attrToElem (Element node, Document doc) {
        NamedNodeMap attrs = node.getAttributes();
        if ( attrs != null ) {
            int size = attrs.getLength();
            for ( int i=0; i < size; i++ ) {
                Attr a = (Attr) attrs.item(i);
                
                Element aElem;
                if ( a.getNamespaceURI() == null ) {
                    aElem = doc.createElement(a.getNodeName());
                } else {
                    aElem = doc.createElementNS(a.getNamespaceURI(), a.getLocalName());
                }
                aElem.setTextContent(a.getValue());
                node.insertBefore(aElem, node.getFirstChild());
            }
            while ( node.hasAttributes() ) {
                node.removeAttributeNode((Attr)attrs.item(0));
            }


        }
        NodeList children = node.getChildNodes();
        if ( children.getLength() != 0 ) {
            for ( int i=0; i < children.getLength(); i++ ) {
                if ( children.item(i).getNodeType() == Node.ELEMENT_NODE ) {
                    attrToElem((Element)children.item(i), doc);
                }
            }
        }
    }

    public static void transform (Document doc) {
        attrToElem(doc.getDocumentElement(), doc);
        
    }
        /*
    public static void main(String[] args) {

        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setValidating(false);
            DocumentBuilder builder = dbf.newDocumentBuilder();
            Document doc = builder.parse("data.xml");
            transform(doc);
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer writer = tf.newTransformer();
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            writer.transform(new DOMSource(doc), new StreamResult(new File("out.xml")));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }*/
}