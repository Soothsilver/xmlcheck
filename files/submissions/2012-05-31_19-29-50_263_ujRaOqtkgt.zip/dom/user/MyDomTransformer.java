package user;

import org.w3c.dom.*;
import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class MyDomTransformer
{

 	public static void main(String[] args) {
         
 		String IN = "../data.xml";
 		String OUT = "../data.out.xml";
 
         try {
             
             // Vytvori DOM parsery
             DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
 
             // Zakaz validace
             dbf.setValidating(false);
 
             // Vytvori DOM parser
             DocumentBuilder builder = dbf.newDocumentBuilder();
 
             // parser zpracuje vstupni soubor IN a ze nej vytvori DOM strom objektu
             Document doc = builder.parse(IN);
 
             // zpracuje DOM strom
             (new MyDomTransformer()).transform(doc);
 
             // Vytvari serializatory DOM stromu
             TransformerFactory tf = TransformerFactory.newInstance();
 
             // serializuje DOM stromy
             Transformer writer = tf.newTransformer();
 
             // Spusti transformaci DOM stromu do XML dokumentu
             writer.transform(new DOMSource(doc), new StreamResult(new File(OUT)));
 
 
         } catch (Exception e) {
             
             e.printStackTrace();
             
         }
 	}


	public void transform (Document xmlDocument)
	{

		// promenne
		String person_id;
		NodeList nn = xmlDocument.getElementsByTagName("pacient");
		Node dat_narozeni = null;
		

		// pro kazdy uzel pacient
		for( int i = 0; i < nn.getLength(); i++)
		{
			Node pacient = nn.item(i);
			NodeList pacient_childs = pacient.getChildNodes(); 

			// nalezne potrebne potomky
			for(int j = 0; j < pacient_childs.getLength(); j++)
			{
				if(pacient_childs.item(j).getNodeName().equals("dat_narozeni"))
					dat_narozeni = pacient_childs.item(j);
			}

			//uzel --> atributy
			transform_datum(dat_narozeni);
			
			//atribut --> uzel
			person_id = ((Element)pacient).getAttributeNode("person_id").getNodeValue();
			((Element)pacient).removeAttribute("person_id");
			Node n_person_id = xmlDocument.createElement("person_id");
			n_person_id.appendChild(xmlDocument.createTextNode(person_id));
			pacient.appendChild(n_person_id);

		}
	}

	// funkce prevadejici poduzel datum --> atribut
	private void transform_datum(Node old_datum)
	{
		int den = 0;
		int mesic = 0;
		int rok = 0;
		
		NodeList datum = old_datum.getChildNodes();
		Node denx = null;
		Node mesicx = null;
		Node rokx = null;

		//cyklus pres potomky uzlu datum (den, mesic, rok). Nalezne hodnoty.
		for(int j = 0; j < datum.getLength(); j++)
		{
			if(datum.item(j).getNodeName().equals("den"))
			{
				try
				{
					den = Integer.parseInt(datum.item(j).getChildNodes().item(0).getNodeValue());
				}
				catch(NumberFormatException e)
				{
					den = 0;
				}
				denx = datum.item(j);
			}
			if(datum.item(j).getNodeName().equals("mesic"))
			{
				try
				{
					mesic = Integer.parseInt(datum.item(j).getChildNodes().item(0).getNodeValue());
				}
				catch(NumberFormatException e)
				{
					mesic = 0;
				}
				mesicx = datum.item(j);
			}
			if(datum.item(j).getNodeName().equals("rok"))
			{
				try
				{
					rok = Integer.parseInt(datum.item(j).getChildNodes().item(0).getNodeValue());
				}
				catch(NumberFormatException e)
				{
					rok = 0;
				}
				rokx = datum.item(j);
			}
		}

		//odstrani podulzlu datum (den, mesic, rok)
			if(denx != null)
				old_datum.removeChild(denx);
			if(mesicx != null)
				old_datum.removeChild(mesicx);
			if(rokx != null)
				old_datum.removeChild(rokx);

			//prida atributu den, mesic a rok k datumu
			if(den != 0)
				((Element)old_datum).setAttribute("den", String.valueOf(den));
			if(mesic != 0)
				((Element)old_datum).setAttribute("mesic", String.valueOf(mesic));
			if(rok != 0)
				((Element)old_datum).setAttribute("rok", String.valueOf(rok));
	}
}
