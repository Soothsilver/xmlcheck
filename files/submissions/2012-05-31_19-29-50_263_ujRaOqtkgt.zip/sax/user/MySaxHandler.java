package user;

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.*;

public class MySaxHandler extends DefaultHandler
{

 	public static void main(String[] args)
 	{
         String sourcePath = "../data.xml";

         try
 		{
             XMLReader parser = XMLReaderFactory.createXMLReader();
             InputSource source = new InputSource(sourcePath);
             parser.setContentHandler(new MySaxHandler());            
             parser.parse(source);
         }
             catch (Exception e) 
 		 {
             e.printStackTrace();
         }
     }


//promenne
	private int pocet_elementu, max_hloubka, prum_hloubka, prum_delka_nazvu, pocet_elem_atrib, pocet_osob,  pocet_muzu, pocet_zen, hloubka;
	private StringBuilder sb;
	
	
	// inicializace promennych
	public MySaxHandler()
	{
		pocet_elementu = 0;
		pocet_osob = 0;
		max_hloubka = 0;
		prum_hloubka = 0;
		prum_delka_nazvu = 0;
		pocet_elem_atrib = 0;
		pocet_muzu = 0;
		pocet_zen = 0;

		hloubka = 0;
		sb = new StringBuilder();
	}
    
    // public void startDocument() throws SAXException {}
    

// Vypise vysledky
    public void endDocument() throws SAXException 
	{

// vypocet prumeru
		prum_hloubka /= pocet_elementu;
		prum_delka_nazvu /= pocet_elementu;


        System.out.println("Pocet elementu v dokumentu:\t" + pocet_elementu);
        System.out.println("Maximalni hloubka elementu:\t" + max_hloubka);
        System.out.println("Prumerna hloubka elementu:\t" + prum_hloubka);
        System.out.println("Prumerna delka jmena elementu:\t" + prum_delka_nazvu);
        System.out.println("Pocet elementu s atributy:\t" + pocet_elem_atrib);
        System.out.println();

        System.out.println("Cukrovka - pacienti");
        System.out.println("Celkovy pocet pacientu je:\t" + pocet_osob);
        if (pocet_muzu > pocet_zen){
        	System.out.println("Vice trpi cukrovkou muzi. Celkovy pocet nemocnych muzu je:\t" + pocet_muzu);
        }
        else if(pocet_muzu == pocet_zen){
        	System.out.println("Zeny i muzi trpi cukrovkou stejne.");
        }
        else {
        	System.out.println("Vice trpi cukrovkou zeny. Celkovy pocet nemocnych zen je:\t" + pocet_zen);
        }
    }
    
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException 
	{
		sb.setLength(0);

		// Vypocet hloubky, elementu a nazvu elementu
		hloubka++;
		if( max_hloubka < hloubka)
			max_hloubka = hloubka;
		prum_hloubka += hloubka;
		pocet_elementu++;
		prum_delka_nazvu += qName.length();
		
		// Vypocet, kolik elementu ma nejake atributy
		if(atts.getLength() > 0)
			pocet_elem_atrib++;

		// Vypocet poctu muzu, zen
		if(qName.equals("pohlavi"))
		{
			pocet_osob++;
			if(atts.getValue("typ").equals("muz"))
				pocet_muzu++;
			else
				pocet_zen++;
		}
	}
}

 