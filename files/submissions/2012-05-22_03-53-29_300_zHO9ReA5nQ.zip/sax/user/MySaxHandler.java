
package user;


import java.util.*;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;


public class MySaxHandler extends DefaultHandler {
    
    public static void main(String[] args) { 
        String sourcePath = "data.xml";
        try {
            XMLReader parser = XMLReaderFactory.createXMLReader();
            InputSource source = new InputSource(sourcePath);
            parser.setContentHandler(new MyContentHandler());
            parser.parse(source);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

class MyContentHandler implements ContentHandler {

    Locator locator;
    
    //maximalni hloubka
    private int maxDepth = 0;
    //pomocni stack pro vypocitani maximalni hloubky
    private Stack<String> forMaxDepth = new Stack<String>();
    
    //pocet atributu
    private int attCount = 0;
    //velikost listu je pocet ruznych atributu
    private List<String> distinctAtts = new ArrayList<String>();
    
    //pocet elementu
    private int elemCount = 0;
    //velikost listu je pocet ruznych elementu
    private List<String> distinctElems = new ArrayList<String>();
    
    //prumerna delka nazvu elementu
    private double avarageElementNameLength = 0;
    //prumerna delka nazvu atributu
    private double avarageAttributeNameLength = 0;
    
    //maximalni delka nazvu atributu
    private int maxAttributeNameLength = 0;
    //maximalni delka nazvu elementu
    private int maxElementNameLength = 0;
    
    //pocet koncovych tagu
    private int endElements = 0;
    //pocet elementu s atributem
    private int elementsWithAtts = 0;
    
    //mapovani element -> aktualni hloubka
    private Map<String, Integer> m = new HashMap<String, Integer>();
    //aktualni hloubka v dokumentu
    private int actualDepth = 0;
    
    //stack pro vypocitani koncovych tagu
    private Stack<String> forEndElements = new Stack<String>();

    
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    public void startDocument() throws SAXException {
        System.out.println("ZACATEK DOKUMENTU");
    }

    public void endDocument() throws SAXException {
        System.out.println("Maximalni hloubka: " + maxDepth);
        System.out.println("");
        System.out.println("ATRIBUTY");
        System.out.println("Pocet vsech atributu: " + attCount);
        System.out.println("Pocet ruznych atributu(distinct): " + distinctAtts.size());
        String tmp = "";
        for (String s : distinctAtts){
            System.out.println("    Nazev atributu: " + s);
            avarageAttributeNameLength += s.length();
            maxAttributeNameLength = maxAttributeNameLength > s.length() ? maxAttributeNameLength : s.length();
            if(maxAttributeNameLength == s.length()) tmp = s;
        }
        System.out.println("Maximalni delka nazvu atributu: " + maxAttributeNameLength + "(" + tmp + ")");
        System.out.println("Prumerna delka nazvu atributu: " + avarageAttributeNameLength / distinctAtts.size());
        System.out.println("");
        System.out.println("ELEMENTY");
        System.out.println("Pocet vsech elementu: " + elemCount);
        System.out.println("Pocet ruznych elementu(distinct): " + distinctElems.size());
        String tmp2 = "";
        for (String s : distinctElems){
            System.out.println("    Nazev elementu: " + s + ", hloubka = " + m.get(s));
            avarageElementNameLength += s.length();
            maxElementNameLength = maxElementNameLength > s.length() ? maxElementNameLength : s.length();
            if(maxElementNameLength == s.length()) tmp2 = s;
        }
        System.out.println("Maximalni delka nazvu elementu: " + maxElementNameLength + "(" + tmp2 + ")");
        System.out.println("Prumerna delka nazvu elementu: " + avarageElementNameLength / distinctElems.size());
        System.out.println("Pocet elementu s atributem: " + elementsWithAtts);
        System.out.println("Pocet elementu s elementovym obsahem: " + (elemCount - endElements));
        System.out.println("Pocet elementu s textovym nebo s prazdnym obsahem: " + endElements);
        System.out.println("");
        System.out.println("KONEC DOKUMENTU");
    }

    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        actualDepth++;
        forMaxDepth.push(qName);
        attCount += atts.getLength();
        elemCount++;
        for (int i = 0; i < atts.getLength(); i++) {
            if(!distinctAtts.contains(atts.getQName(i))) distinctAtts.add(atts.getQName(i));
        }
        if(!distinctElems.contains(qName)){
            distinctElems.add(qName);
            m.put(qName, actualDepth);
        }
        if(atts.getLength() > 0) elementsWithAtts++;
        forEndElements.push(qName);
    }
  
    public void endElement(String uri, String localName, String qName) throws SAXException {
        String tmp = forMaxDepth.peek();
        if(qName.equals(tmp)){
            maxDepth = maxDepth > forMaxDepth.size() ? maxDepth : forMaxDepth.size();
            forMaxDepth.pop();
        }
        String tmp2 = "";
        if(!forEndElements.empty()) tmp2 = forEndElements.peek();
        if(qName.equals(tmp2)){
            endElements++;
            forEndElements.clear();
        }
        actualDepth--;
        
    }
            
    public void characters(char[] ch, int start, int length) throws SAXException {
        
    }

    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
    }

    public void endPrefixMapping(String prefix) throws SAXException {
        
    }
   
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
    }
     
    public void processingInstruction(String target, String data) throws SAXException {
        
    }
      
    public void skippedEntity(String name) throws SAXException {
        
    }
}


