
package user;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;


public class MyDomTransformer {
    
    private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "data.out.xml";

    public static void main(String[] args) {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setValidating(false);
            DocumentBuilder builder = dbf.newDocumentBuilder();
            Document doc = builder.parse(VSTUPNI_SOUBOR);
            processTree(doc);
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer writer = tf.newTransformer();
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));
        } catch (Exception e) {  
            e.printStackTrace();
        }
    }

    private static void processTree(Document doc) {
        
        //odstrani element stat z adresy
        NodeList addresses = doc.getElementsByTagName("adresa");
        for (int i = 0; i < addresses.getLength(); i++){
            Element e = (Element) addresses.item(i);
            e.removeChild(e.getElementsByTagName("stat").item(0));
        }
        
        //vyroby element z atributu typ
        NodeList products = doc.getElementsByTagName("produkt");
        for (int i = 0; i < products.getLength(); i++) {
            Element e = (Element) products.item(i);
            String attr = e.getAttribute("typ");
            e.removeAttribute("typ");
            Element a = doc.createElement("typ");
            a.setTextContent(attr);
            e.appendChild(a);
        }
        
        //vyroby atribut z elementu prace/datum
        NodeList works = doc.getElementsByTagName("prace");
        for (int i = 0; i < works.getLength(); i++) {
            Element e = (Element) works.item(i);
            Element date = (Element) e.getElementsByTagName("datum").item(0);
            e.removeChild(date);
            e.setAttribute("datum", date.getTextContent());
        }
        
        //prida c_jmeno zamestnanca k praci
        for (int i = 0; i < works.getLength(); i++) {
            Element work = (Element) works.item(i);
            String idref = work.getAttribute("zid_ref");
            NodeList employees = doc.getElementsByTagName("zamestnanec");
            for (int j = 0; j < employees.getLength(); j++) {
                Element employee = (Element) employees.item(j);
                String id = employee.getAttribute("zid");
                if(id.equals(idref)){
                    Element name = (Element) employee.getElementsByTagName("c_jmeno").item(0);
                    Element firstname = doc.createElement("jmeno");
                    firstname.setTextContent(name.getElementsByTagName("jmeno").item(0).getTextContent());
                    Element surname = doc.createElement("prijmeni");
                    surname.setTextContent(name.getElementsByTagName("prijmeni").item(0).getTextContent());
                    Element wholeName = doc.createElement("c_jmeno");
                    wholeName.appendChild(firstname);
                    wholeName.appendChild(surname);
                    work.appendChild(wholeName);
                }
            }
        }
    }
}
