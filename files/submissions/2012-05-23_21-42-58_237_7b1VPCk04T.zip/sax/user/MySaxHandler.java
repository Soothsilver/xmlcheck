package user;
import java.util.ArrayList;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;


public class MySaxHandler extends DefaultHandler { 
class VizualizeElement
{
    public int pocetAttr;
    public VizualizeElement(int i)
    {
    pocetAttr = i;
    }
    public void print()
    {
        if (pocetAttr > 9) {
            System.out.print("(" + pocetAttr + ")");
        }
        else {
            System.out.print(pocetAttr);
        }
    }
}

class Characteristics
{
    
    ArrayList<ArrayList<VizualizeElement>> l = new ArrayList<ArrayList<VizualizeElement>>();
    
    int maxPocetNaVrstve = 0;
    int maxPocetJeNaVrstve = 0;
    
    
    public void AddElementToDepth(int depth, int attributeCount)
    {
        if (depth + 1 > l.size()) {l.add(new ArrayList() ); }
        l.get(depth).add(new VizualizeElement(attributeCount) );
        
        if (l.get(depth).size() > maxPocetNaVrstve ) { maxPocetNaVrstve = l.get(depth).size(); maxPocetJeNaVrstve = depth; } 
    }
    
    public void print()
    {
        System.out.println("");
        System.out.println("");
        System.out.println("Rozložení grafu na jednotlivé vrstvy ... jednotlivá čísla symbolizují počet atrributů tohoto elementu");
        
        for (ArrayList<VizualizeElement> list : l) {
                for (int i = 0; i < (maxPocetNaVrstve - list.size()) / 2; i++) {
                     System.out.print(" ");
                }
                for (VizualizeElement element : list) {
                
                    element.print();
                }
            System.out.println("");
            
        }
        
        System.out.println("");
        System.out.println("Maximální hloubka je " + l.size());
        System.out.println("Nejvíce elementů ("+ maxPocetNaVrstve + ") je v hloubce " + (maxPocetJeNaVrstve +1) );
    }
    
}
    Locator locator;
    public static final String regexpik = "^[\\w\\-]+(\\.[\\w\\-]+)*@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}$";
    public int hloubka = 0;
    public int sirkaVrstvy = 0;
    
    Characteristics ch = new Characteristics();
    
    
    
    /**
     * Nastaví locator
     */     
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Obsluha události "začátek dokumentu"
     */     
    public void startDocument() throws SAXException {
        
        // ...
        
    }
    /**
     * Obsluha události "konec dokumentu"
     */     
    public void endDocument() throws SAXException {
     
       ch.print();
    }
    
    /**
     * Obsluha události "začátek elementu".
     * @param uri URI jmenného prostoru elementu (prázdné, pokud element není v žádném jmenném prostoru)
     * @param localName Lokální jméno elementu (vždy neprázdné)
     * @param qName Kvalifikované jméno (tj. prefix-uri + ':' + localName, pokud je element v nějakém jmenném prostoru, nebo localName, pokud element není v žádném jmenném prostoru)
     * @param atts Atributy elementu     
     */     
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
          
        for (int i = 0; i < atts.getLength(); i++) {
           String obsah = atts.getValue(i);
           if (obsah.matches(regexpik))
           {
               System.out.println("Nalezen email, jmeno tagu: " + qName + " a adresa : " + obsah  );
           }
            
        }
        
        
        ch.AddElementToDepth(hloubka, atts.getLength());
        
        hloubka++;
       
    }
    /**
     * Obsluha události "konec elementu"
     * Parametry mají stejný význam jako u @see startElement     
     */     
    public void endElement(String uri, String localName, String qName) throws SAXException {

        // ...
        hloubka--;
         
         
    }
    
    /**
     * Obsluha události "znaková data".
     * SAX parser muľe znaková data dávkovat jak chce. Nelze tedy počítat s tím, že je celý text dorucen v rámci jednoho volání.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakovými daty
     * @param start Index zacátku úseku platných znakových dat v poli.
     * @param length Délka úseku platných znakových dat v poli.
     */               
    public void characters(char[] ch, int start, int length) throws SAXException {

        // ...
        
    }
    
    /**
     * Obsluha události "deklarace jmenného prostoru".
     * @param prefix Prefix prirazený jmennému prostoru.
     * @param uri URI jmenného prostoru.
     */     
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha události "konec platnosti deklarace jmenného prostoru".
     */     
    public void endPrefixMapping(String prefix) throws SAXException {
    
        // ...
    
    }

    /**
     * Obsluha události "ignorované bílé znaky".
     * Stejné chování a parametry jako @see characters     
     */     
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha události "instrukce pro zpracování".
     */         
    public void processingInstruction(String target, String data) throws SAXException {
      
      // ...
            
    }

    /**
     * Obsluha události "nezpracovaná entita"
     */         
    public void skippedEntity(String name) throws SAXException {
    
      // ...
    
    }
    
}


