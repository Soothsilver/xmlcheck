package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


 public class MyDomTransformer { 
   public void transform (Document xmlDocument) { 
  NormalizujTelefony(xmlDocument);
   OpravDatumy(xmlDocument);
    pridejSlevu(xmlDocument, "id_3", 12, true);
  
  /*     
       
  */
       
       
   }
   /**
    * Predela system ukladani telefonnich cisel, prvni ulozi do atributu primary a druhy (pokud existuje) do atributu secundary
    * @param xmldoc XML Document
    */
   private void NormalizujTelefony(Document xmldoc)
   {
        NodeList l =   xmldoc.getElementsByTagName("kontakt");
   
       for (int i = 0; i < l.getLength(); i++) {
           
           NodeList childs = l.item(i).getChildNodes();
           int NumberCount = 0; 
           for (int j = 0; j < childs.getLength(); j++) {
              
               if ("telefon".equals(childs.item(j).getNodeName()))
               {
                 NumberCount++;
                 if (NumberCount == 1) {
                   ((Element) l.item(i)).setAttribute("primary",childs.item(j).getAttributes().getNamedItem("number").getNodeValue());
                   
                 }
                 if (NumberCount == 2) {
                   ((Element) l.item(i)).setAttribute("secondary",childs.item(j).getAttributes().getNamedItem("number").getNodeValue());
                 }
              
                 
                  l.item(i).removeChild(childs.item(j));
               }
               
              
               
            
               
           }
           
           
           
           
           
       }
   }
   /**
    * Změní datumy do čitelnější podoby ve formátu dd.mm.yyyy
    * @param xmldoc XML Document
    */
   private void OpravDatumy(Document xmldoc)
   {
       NodeList l =   xmldoc.getElementsByTagName("date");
 
       for (int i = 0; i < l.getLength(); i++) {
           Element el = (Element) l.item(i);
         
           String rok = el.getElementsByTagName("rok").item(0).getAttributes().getNamedItem("value").getNodeValue();
           String mesic = el.getElementsByTagName("mesic").item(0).getAttributes().getNamedItem("value").getNodeValue();
           String den =  el.getElementsByTagName("day").item(0).getAttributes().getNamedItem("value").getNodeValue();
  
                String datum = den + "."+ mesic + "." + rok; 
               
             
               l.item(i).setTextContent(datum);
          
       }
     
       
       
   
   
   }
   /**
    * Přidá (případně změní pokud existovala) procentuelní slevu k danému výrobku. V případě úspěchu tzn zboží existuje a procenta jsou zadaná ve správném rozmezí vrací true.
    * @param xmldoc  XML Document
    * @param IDvyrobku ID výrobku, ke kterému chceme dát slevu
    * @param slevaProcent Procenta v rozmezí (0,100)
    * @param neomezeno  Nastaví atrribut, zda je výdej zboží neomezen
    * @return Při chybě vrací false.
    */
   private boolean pridejSlevu(Document xmldoc,  String IDvyrobku, int slevaProcent, boolean neomezeno)
   {
      
       if (!(slevaProcent > 0 && slevaProcent < 100)) return false;
       int cena = -1;
       NodeList vyr = xmldoc.getElementsByTagName("polozka");
       
       for (int i = 0; i < vyr.getLength(); i++) {
           
           if(IDvyrobku != null && IDvyrobku.equals(vyr.item(i).getAttributes().getNamedItem("pid").getNodeValue()))
            {
                try {
                cena = Integer.parseInt(vyr.item(i).getAttributes().getNamedItem("cena").getNodeValue());
                    }
                catch(Exception e)
                {
                   cena = -1;
                }
            }
           
       }
    
       if (cena == -1) return false;
       
       int akcniCena = (int) ((int) cena - (cena * slevaProcent/(double)100));
       
       
       
       
       NodeList n = xmldoc.getElementsByTagName("sleva");
       
       for (int i = 0; i < n.getLength(); i++) {
           
          String id = n.item(i).getAttributes().getNamedItem("ref_pid").getNodeValue();
          
          
         if (id.equals(IDvyrobku)) { 
         
            Element el = (Element) n.item(i);
            
            el.setAttribute("akcnicena", Integer.toString(akcniCena));
            
            if (neomezeno) {  el.setAttribute("neomezeno", "ANO");}
            else {el.setAttribute("neomezeno", "NE");}
            return true;
         
         }
           
       }
       
       
      Element sleva = xmldoc.createElement("sleva"); 
      sleva.setAttribute("ref_pid", IDvyrobku);
       sleva.setAttribute("akcnicena", Integer.toString(akcniCena));
      
       if(neomezeno) { sleva.setAttribute("neomezeno", "ANO"); }
       else { 
       sleva.setAttribute("neomezeno", "NE");
       }
       
       xmldoc.getElementsByTagName("zlevnene").item(0).appendChild(sleva);
       
       
      
       
       
       return true;
   }
}
