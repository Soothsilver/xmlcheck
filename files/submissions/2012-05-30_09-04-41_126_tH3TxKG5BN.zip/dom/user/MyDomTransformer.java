package user;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.NamedNodeMap;

public class MyDomTransformer {
	public void transform(Document xmlDocument) {
		// libovolne transformace objektu 'xmlDocument'
		// (metoda pracuje primo na objektu, nic nevraci)

		NodeList bookList = xmlDocument.getElementsByTagName("book");
		NodeList priceList = xmlDocument.getElementsByTagName("price");
		
		//book
		Element currentBook;
		for(int index = 0; index < bookList.getLength(); index++)
		{
			// isbn
			currentBook = (Element) bookList.item(index);
			String isbn = currentBook.getAttribute("isbn");
			removeAttribute(currentBook, "isbn");

			Element isbnElement = xmlDocument.createElement("isbn");
			isbnElement.setTextContent(isbn);
			currentBook.appendChild(isbnElement);
			
			// instock
			String instock = currentBook.getAttribute("instock");
			removeAttribute(currentBook, "instock");

			Element instockElement = xmlDocument.createElement("instock");
			instockElement.setTextContent(instock);
			currentBook.appendChild(instockElement);
		}
		
		// price
		Element currentPrice;
		for(int index = 0; index < priceList.getLength(); index++)
		{
			currentPrice = (Element) priceList.item(index);
			String amount = currentPrice.getAttribute("amount");
			removeAttribute(currentPrice, "amount");
			currentPrice.setTextContent(amount + " " + currentPrice.getTextContent());
		}
	}
		
	private static void removeAttribute(Node node, String attName) {
	    NamedNodeMap attributes = node.getAttributes();
	    attributes.removeNamedItem(attName);
	}	
}
