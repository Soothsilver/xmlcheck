package user;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
	// override metod DefaultHandleru

	int sumElementNameLength = 0;
	int elements = 0;

	// zvysuje pocitadla
	public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
		sumElementNameLength = sumElementNameLength + localName.length();
		elements++;
	}

	// vypise vysledok
	public void endDocument() throws SAXException {
		System.out.println("Average length of the element name: " + sumElementNameLength/(float)elements);
	}
}