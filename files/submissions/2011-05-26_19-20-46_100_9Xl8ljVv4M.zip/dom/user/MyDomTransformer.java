package user;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

/**
 * ZADANI:
 * Upravte program tak, aby transformoval vstupn� XML dokument na v�stupn� pomoc� akc�
 * uveden�ch v koment�r�ch metody processTree(doc).
 */
public class MyDomTransformer {

    private static final String VSTUPNI_SOUBOR = "../../data.xml";
    private static final String VYSTUPNI_SOUBOR = "../../data.html";

    public static void main(String[] args) {
        
        try {
            
            //DocumentBuilderFactory vytv�r� DOM parsery
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            //nebudeme validovat
            dbf.setValidating(false);

            //vytvor�me si DOM parser
            DocumentBuilder builder = dbf.newDocumentBuilder();

            //parser zpracuje vstupn� soubor a vytvor� z nej strom DOM objektu
            Document doc = builder.parse(VSTUPNI_SOUBOR);

            MyDomTransformer domTransformer = new MyDomTransformer();
            //zpracujeme DOM strom
            domTransformer.transform(doc);

            //TransformerFactory vytv�r� serializ�tory DOM stromu
            TransformerFactory tf = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer = tf.newTransformer();

            //nastav�me kodov�n�
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spust�me transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


        } catch (Exception e) {
            
            e.printStackTrace();
            
        }
    }

    /**
     * Zpracuje DOM strom
     */
    public void transform (Document xmlDocument) {
        
            	/* build html header */

    	
    	String styleSheet ="<!--  \n" +
    	"body { background-color: #EEEEEE; }\n" +
    	".indent { margin-left: 20px; }\n"+
    	".element { margin-top: 2px;\n"+
    	"           margin-bottom: 2px;\n"+
        "           margin-right: 0px; }\n"+
    	".elementHeader { margin: 2px;\n"+
    	"                 background-color: #C3D9FF;\n" +
    	"                 border: 1px solid #36393D; }\n" + 
    	".elementHeader h1 { font-size: 14pt;\n" +
    	"                    display: inline;\n" +
    	"                    margin-right: 10px; }\n"+
    	"-->";    	
    	
    	
    	Node html = xmlDocument.createElement("html");
    	Node head = xmlDocument.createElement("head");
    	Node title = xmlDocument.createElement("title");
    	Element style = xmlDocument.createElement("style");
    	style.setAttribute("type", "text/css");
    	style.setAttribute("media", "screen");
    	style.appendChild(xmlDocument.createTextNode(styleSheet));
    	
    	
    	title.appendChild(xmlDocument.createTextNode("XML to HTML"));
    	head.appendChild(title);
    	head.appendChild(style);
    	html.appendChild(head);
    	Node body = xmlDocument.createElement("body");
    	html.appendChild(body);
    	
    	Node root = processElement(xmlDocument, xmlDocument.getDocumentElement());
    	body.appendChild(root);
    	xmlDocument.getDocumentElement().getParentNode().replaceChild(html,  xmlDocument.getDocumentElement());
 
    }
    
        private static Node processElement(Document doc, Node node) {
    	if (node.getNodeType() == Node.ELEMENT_NODE) {
    		Element element = (Element)node;
    		Element div = doc.createElement("div");
    		Element div2= doc.createElement("div");
    		div.setAttribute("class", "element indent");
    		div2.setAttribute("class", "elementheader");
    		Element h1 = doc.createElement("h1");
    		h1.appendChild(doc.createTextNode(element.getNodeName()));
    		div2.appendChild(h1);
    		div.appendChild(div2);
        	NodeList nodes = node.getChildNodes();
        	String attrs = "";
        	for (int i = 0; i < element.getAttributes().getLength(); ++i) {
        		Node attr = element.getAttributes().item(i);
        		attrs += attr.getNodeName() + "=\"" + attr.getNodeValue() + "\" ";
        	}
        	div2.appendChild(doc.createTextNode(attrs));
        	
        	for (int i = 0; i < nodes.getLength(); ++i) {
        		Node childNode = nodes.item(i);
        		Node newChildNode = processElement(doc, childNode);
        		div.appendChild(newChildNode);
        	}
        	
        	return div;
    	} else if (node.getNodeType() == Node.TEXT_NODE) {
    		Node text = node.cloneNode(false);
    		
        	if (!node.getNodeValue().trim().isEmpty()) {
        		Element div = doc.createElement("div");
        		div.setAttribute("class", "text indent");
        		div.appendChild(text);
        		return div;
        		
        	}     	
    		return text;
    	}
    	return node;    	
    }

}
