package user;

import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;

class TestSax {

    public static void main(String[] args) {

        // Cesta ke zdrojov�mu XML dokumentu  
        String sourcePath = "../../data.xml";

        try {
            
            // Vytvor�me instanci parseru.
            XMLReader parser = XMLReaderFactory.createXMLReader();
            
            // Vytvor�me vstupn� proud XML dat.
            InputSource source = new InputSource(sourcePath);
            
            // Nastav�me n�a vlastn� content handler pro obsluhu SAX ud�lost�.
            parser.setContentHandler(new MySaxHandler());
            
            // Zpracujeme vstupn� proud XML dat.
            parser.parse(source);
            
        } catch (Exception e) {
        }
        
    }
    
}

/**
 * N� vlastn� content handler pro obsluhu SAX ud�lost�.
 */ 
public class MySaxHandler extends DefaultHandler {

    // Umo�nuje zac�lit m�sto v dokumentu, kde vznikla aktualn� ud�lost
    Locator locator;
    
    /**
     * Nastav� locator
     */     
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Obsluha ud�losti "zac�tek dokumentu"
     */     
    @Override
    public void startDocument() throws SAXException {
        
        // ...
        
    }
    /**
     * Obsluha ud�losti "konec dokumentu"
     */     
    @Override
    public void endDocument() throws SAXException {
        
        System.out.printf("Maximalni hloubka: %d\n", maxDepth);
    	System.out.printf("Prumerna hloubka: %f\n", (double)sumDepth / elementCount);
    	System.out.printf("Pocet elementu: %d\n", elementCount);
    	System.out.printf("Pocet atributu: %d\n", attributeCount);
    }
    
    /**
     * Obsluha ud�losti "zac�tek elementu".
     * @param uri URI jmenn�ho prostoru elementu (pr�zdn�, pokud element nen� v ��dn�m jmenn�m prostoru)
     * @param localName Lok�ln� jm�no elementu (v�dy nepr�zdn�)
     * @param qName Kvalifikovan� jm�no (tj. prefix-uri + ':' + localName, pokud je element v nejak�m jmenn�m prostoru, nebo localName, pokud element nen� v ��dn�m jmenn�m prostoru)
     * @param atts Atributy elementu     
     */     
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        currDepth++;
        sumDepth += currDepth;
        if (currDepth > maxDepth)
        	maxDepth = currDepth;
    	elementCount++;
        attributeCount += atts.getLength();
    }
    /**
     * Obsluha ud�losti "konec elementu"
     * Parametry maj� stejn� v�znam jako u @see startElement     
     */     
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {

        currDepth--;

    }
    
    /**
     * Obsluha ud�losti "znakov� data".
     * SAX parser mule znakov� data d�vkovat jak chce. Nelze tedy poc�tat s t�m, �e je cel� text dorucen v r�mci jednoho vol�n�.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakov�mi daty
     * @param start Index zac�tku �seku platn�ch znakov�ch dat v poli.
     * @param length D�lka �seku platn�ch znakov�ch dat v poli.
     */               
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {

        // ...
        
    }
    
    /**
     * Obsluha ud�losti "deklarace jmenn�ho prostoru".
     * @param prefix Prefix prirazen� jmenn�mu prostoru.
     * @param uri URI jmenn�ho prostoru.
     */     
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha ud�losti "konec platnosti deklarace jmenn�ho prostoru".
     */     
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
    
        // ...
    
    }

    /**
     * Obsluha ud�losti "ignorovan� b�l� znaky".
     * Stejn� chov�n� a parametry jako @see characters     
     */     
    @Override
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha ud�losti "instrukce pro zpracov�n�".
     */         
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
      
      // ...
            
    }

    /**
     * Obsluha ud�losti "nezpracovan� entita"
     */         
    @Override
    public void skippedEntity(String name) throws SAXException {
    
      // ...
    
    }
    
    private int elementCount = 0;
    private int attributeCount = 0;
    private int currDepth = 0;
    private int sumDepth = 0;
    private int maxDepth = 0;
}