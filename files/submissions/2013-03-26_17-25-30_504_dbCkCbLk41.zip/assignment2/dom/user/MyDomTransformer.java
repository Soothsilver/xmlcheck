/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import org.w3c.dom.Document;
/**
 *
 * @author Julien
 */
public class MyDomTransformer {

    public void transform (Document xmlDocument) { // code transforming xmlDocument object // (method works on the object itself - no return value) 

                // create the associated CEO
        Element ceo = xmlDocument.createElement("CEO");
        Text ceotxt = xmlDocument.createTextNode("Luc Legrand");
        ceo.appendChild(ceotxt);
            // create its description
        Element desc = xmlDocument.createElement("description");
        Attr turnover = xmlDocument.createAttribute("turnover");
        turnover.setValue("150000");
        Attr startyear = xmlDocument.createAttribute("startYear");
        startyear.setValue("2008");
        desc.getAttributes().setNamedItem(turnover);
        desc.getAttributes().setNamedItem(startyear);    
        desc.appendChild(ceo);
        // create one company
        Element company = xmlDocument.createElement("company");
        Attr name = xmlDocument.createAttribute("name");
        name.setValue("AddedCompany");
        company.getAttributes().setNamedItem(name);
        company.appendChild(desc);
        
        // add the whole
        xmlDocument.getDocumentElement().appendChild(company);
        
        // next modification consists in deleting the companies having subcontractors
        NodeList nl = xmlDocument.getDocumentElement().getElementsByTagName("company");
        int n = nl.getLength()-1;
        for (int i = n; i >= 0; i--){
            for (Node nd = nl.item(i).getFirstChild();
                    nd != null; nd = nd.getNextSibling())
                if (nd.getNodeName().equals("subcontractor")){
                    xmlDocument.getDocumentElement().removeChild(nd.getParentNode());
                    break;
                }
        }
    }
}
