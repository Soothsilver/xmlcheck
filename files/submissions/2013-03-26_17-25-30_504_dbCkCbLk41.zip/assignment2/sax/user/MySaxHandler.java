/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.util.ArrayList;
import java.util.List;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
/**
 *
 * @author Julien
 */
public class MySaxHandler extends DefaultHandler {

    // Q1 - Atts    - average of distributors turnovers
    // Q2 - Content - names of CEO starting with M
    // Q3 - Context - deliveries ordered to Ostrava with at least 550 units
    
    Integer avgNum; // help to compute the average of Q1
    Integer avgTurnover;     // result for Q1
    List startMCEO;          // result for Q2
    Integer deliveriesCount; // result for Q3
    
    Boolean isDistributor; // for Q1
    Boolean isCEO; // for Q2
    Boolean isOstravaSite; // for Q3
    
    @Override
    public void startDocument() throws SAXException {
        // initialization
        this.avgTurnover = 0;
        this.avgNum = 0;
        this.startMCEO = new ArrayList();
        this.deliveriesCount = 0;
        
        this.isCEO = false;
        this.isDistributor = false;
        this.isOstravaSite = false;
    }

    @Override
    public void endDocument() throws SAXException {
        System.out.println("Average Turnover = " + (this.avgNum > 0 ? avgTurnover / this.avgNum : "Null"));
        System.out.print("CEO Names starting with the letter M :");
        for (int i = 0; i < this.startMCEO.size(); i++)
            System.out.print(" " + this.startMCEO.get(i) + ".");
        System.out.print("\n");
        System.out.println("Deliveries ordered to Ostrava with at least 550 units = " + this.deliveriesCount);
    }
    
    

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if (this.isDistributor && localName.equals("description")){
            String value = atts.getValue("turnover");
            Integer turnover = Integer.valueOf(value);
            this.avgTurnover += turnover;
            this.avgNum++;
        }else if (localName.equals("site") && atts.getValue("town") != null && atts.getValue("town").equals("Ostrava")){
            this.isOstravaSite = true;
        }else if (this.isOstravaSite && localName.equals("delivery") && Integer.valueOf(atts.getValue("units")) >= 550){
            this.deliveriesCount++;
        }else {
            this.isCEO = localName.equals("CEO");
            this.isDistributor = (localName.equals("company") && atts.getValue("name").contains("Distributor"));
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (localName.equals("site"))
            this.isOstravaSite = false;
    }
    

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        if (this.isCEO && ch[start] == 'M'){
            this.startMCEO.add(String.copyValueOf(ch, start, length));
        }
    }
    
}
