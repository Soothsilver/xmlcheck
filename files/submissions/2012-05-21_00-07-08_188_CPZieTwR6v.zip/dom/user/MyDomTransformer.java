package user;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

public class MyDomTransformer {
    
    private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "data.out.xml";
    
    public static void main(String[] args) {
        
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setValidating(false);
            DocumentBuilder builder = dbf.newDocumentBuilder();
            Document doc = builder.parse(VSTUPNI_SOUBOR);
            MyDomTransformer mdt = new MyDomTransformer();
            mdt.transform(doc);
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer writer = tf.newTransformer();
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));
            
            
        } catch (Exception e) {
            System.out.println("ERROR!");
            e.printStackTrace();
            
        }
    }

    // Odstrani element s timto jmenem vcetne jeho potomku
    void odstran(Node node, String jmeno) {
        if (jmeno == null || node.getNodeName().equals(jmeno)) {
            node.getParentNode().removeChild(node);
        } else {
            // Visit the children
            NodeList list = node.getChildNodes();
            for (int i = 0; i < list.getLength(); i++) {
                odstran(list.item(i), jmeno);
            }
        }
    }

    //Jakmile to najde element s urcenym jmenem tak to jeho potomky prenda na jeho otce
    void predani(Node node, String jmeno) {
        if ((node.getNodeType() == Node.ELEMENT_NODE) && (jmeno == null || node.getNodeName().equals(jmeno))) {
            NodeList nodes = node.getChildNodes();
            for (int i = 0; i < nodes.getLength(); i++) {
                if (!nodes.item(i).getNodeName().equals("#text")) {
                    node.getParentNode().appendChild(nodes.item(i));
                }
            }
        } else {
            NodeList list = node.getChildNodes();
            for (int i = 0; i < list.getLength(); i++) {
                predani(list.item(i), jmeno);
            }
        }
    }

    //hleda elementy a nasledne je to prejmenovava 
    void prejmenuj(Document doc, Node node, String jmeno, String noveJmeno) {
        if ((node.getNodeType() == Node.ELEMENT_NODE) && (jmeno == null || node.getNodeName().equals(jmeno))) {
            doc.renameNode(node, "", noveJmeno);
            NodeList list = node.getChildNodes();
            for (int i = 0; i < list.getLength(); i++) {
                prejmenuj(doc, list.item(i), jmeno, noveJmeno);
            }
        } else {
            NodeList list = node.getChildNodes();
            for (int i = 0; i < list.getLength(); i++) {
                prejmenuj(doc, list.item(i), jmeno, noveJmeno);
            }
        }
    }

    //Hleda to element a nasledne to tomu elementu prida verzi
    void pridejAtribut(Node node, String jmeno, int verze) {
        if ((node.getNodeType() == Node.ELEMENT_NODE) && (jmeno == null || node.getNodeName().equals(jmeno))) {
            Element el = (Element) node;
            el.setAttribute("verze", Long.toString(verze));
            NodeList list = node.getChildNodes();
            for (int i = 0; i < list.getLength(); i++) {
                pridejAtribut(list.item(i), jmeno, verze);
            }
        } else {
            NodeList list = node.getChildNodes();
            for (int i = 0; i < list.getLength(); i++) {
                pridejAtribut(list.item(i), jmeno, verze);
            }
        }
    }
    
    //Vyhleda element a prida k nemu potomka s urcitym nazvem a obsahem
    void vytvorElement(Document doc, String jmenoHledany, String jmenoNovy, String obsah) {
        NodeList list = doc.getElementsByTagName(jmenoHledany);
        for (int i = 0; i < list.getLength(); i++) {
            Element el = (Element) list.item(i);
            el.appendChild(doc.createElement(jmenoNovy));
            el.getElementsByTagName(jmenoNovy).item(0).setTextContent(obsah);
        }
    }
    
    public void transform(Document doc) {
        
        
        odstran(doc, "type");
        odstran(doc, "short_name");
        predani(doc, "address_component");
        odstran(doc, "address_component");
        predani(doc, "GeocodeResponse");
        odstran(doc, "GeocodeResponse");
        odstran(doc, "status");
        vytvorElement(doc, "result","cas","20.5.2012"); 
        prejmenuj(doc, doc, "long_name", "inf");
        pridejAtribut(doc, "result", 11);
        
    }
}
