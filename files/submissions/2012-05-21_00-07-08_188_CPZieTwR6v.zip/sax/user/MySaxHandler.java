package user;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;


//Vetsina veci je delana dle api saxu. 
public class MySaxHandler extends DefaultHandler {
	
	
	public static void main(String[] args) {
        String zdrojak = "data.xml";

        try {
            XMLReader parser = XMLReaderFactory.createXMLReader();
            InputSource zdroj = new InputSource(zdrojak);
            parser.setContentHandler(new MySaxHandler());
            parser.parse(zdroj);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	int soucasnaHloubka;
	int maximalniHloubka;
	int pocetAtributu;
	int pocetElementu;
	int pocetTextovychElementu;
	int nejvicePouzivan = 0;
	String nejvicePouzivaneJmeno;
	
        List seznam = new ArrayList<Elementy>();
        
        
	
	String soucasneJmeno;
        Locator locator;
    
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    @Override
    public void startDocument() throws SAXException {
        System.out.println("Pruchod data.xml zahajen");
    }
 
    @Override
    public void endDocument() throws SAXException {
    	System.out.println("Hloubka xml dokumentu:\t\t"+maximalniHloubka);
    	System.out.println("Pocet elementu:\t\t"+pocetElementu);
    	System.out.println("Pocet textovych elementu:\t"+pocetTextovychElementu);
    	System.out.println("Pocet atributu:\t\t"+pocetAtributu);
        
        Iterator it = seznam.iterator();
        
        while(it.hasNext()){
            Elementy e = (Elementy)it.next();
            if(nejvicePouzivan < e.getPocet()){
                nejvicePouzivan = e.getPocet();
                nejvicePouzivaneJmeno = e.getJmeno();
            }
      
        }      
        
    	System.out.println("Pocet nejpouzivanejsiho elementu:\t"+nejvicePouzivan);
    	System.out.println("Jmeno nejpouzivanejsiho elementu:\t"+nejvicePouzivaneJmeno);
    	System.out.println("Pruchod ukoncen");
    }
    
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
    	this.pocetElementu++;
    	this.pocetAtributu+=atts.getLength();
    	if(++soucasnaHloubka>maximalniHloubka){
    		maximalniHloubka = soucasnaHloubka;
    	}
    	soucasneJmeno = qName;
        boolean ulozeno = false;
        
        Iterator it = seznam.iterator();
        
        while(it.hasNext()){
            Elementy e = (Elementy)it.next();
            
            if(e.getJmeno().equals(localName)){
                e.zvedniPocet();
                ulozeno = true;
                break;
            }        
        }
        if(!ulozeno){
            seznam.add(new Elementy(localName,1));
        }
    	
    }
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
    	soucasnaHloubka--;
    }
    
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        String string = new String(ch, start, length);
        if (string.trim().length()> 0) {
            this.pocetTextovychElementu++;
        }
    }
    
    class Elementy{
        String jmeno = "";
        int pocet = 0;
        
        public Elementy(String j, int p){
            jmeno = j;
            pocet = p;
        }
        
        public void zvedniPocet(){
            pocet++;
        }

        public String getJmeno() {
            return jmeno;
        }

        public void setJmeno(String jmeno) {
            this.jmeno = jmeno;
        }

        public int getPocet() {
            return pocet;
        }

        public void setPocet(int pocet) {
            this.pocet = pocet;
        }
        
    }
}