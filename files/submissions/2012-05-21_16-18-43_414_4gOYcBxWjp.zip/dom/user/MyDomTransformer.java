/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

/**
 *
 * @author andrei
 */
import java.io.File;

//import javax.lang.model.element.Element;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


public class MyDomTransformer {

    public static void main(String[] args) {
        String filename = "data.xml";
        String output = "output.xml";

        try {

            //DocumentBuilderFactory vytváří DOM parsery
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            //nebudeme validovat
            dbf.setValidating(false);

            //vytvoříme si DOM parser
            DocumentBuilder builder = dbf.newDocumentBuilder();

            //parser zpracuje vstupní soubor a vytvoří z něj strom DOM objektů
            Document doc = builder.parse(filename);

            //zpracujeme DOM strom
            transform(doc);
            //transform2(doc);

            //TransformerFactory vytváří serializátory DOM stromů
            TransformerFactory tf = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer = tf.newTransformer();

            //nastavíme kodování
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spustíme transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(new File(output)));


        } catch (Exception e) {

            e.printStackTrace();

        }
    }

    //remove reservation from March month 
    public static void transform(Document xmlDocument) {
        NodeList list = xmlDocument.getElementsByTagName("reservation");
        String toDelete = "2012-03";
        for (int i = 0; i < list.getLength(); i++) {
            Element dates = (Element) list.item(i);
            if (containsDate(toDelete, dates)) {
            //    System.out.println("founded res: " + dates.getAttribute("resId"));
            //    System.out.println(dates.getAttribute("passIdref"));
            //    System.out.println();
                Node date = dates.getParentNode();
                date.removeChild(dates);
            }
        }
        transform2(xmlDocument);
    }

    
    /*
    add new element(priority) in info_guests
    @param Document  
     */

    public static void transform2(Document doc) {
       NodeList guestss = doc.getElementsByTagName("info_guests");
        for (int j = 0; j < guestss.getLength(); j++) {
            Element priorities = (Element) guestss.item(j);
            Element priority = doc.createElement("priority");
            priorities.appendChild(priority);
        }
        

    }

    private static boolean name(Element e) {
        NodeList names = e.getElementsByTagName("name");
        for (int i = 0; i < names.getLength(); i++) {
            //  Element name = (Element) names.item(1);
            //  NodeList namess = name.getElementsByTagName("name");
            if (names.item(0).hasAttributes()) {
                System.out.println("true");
                return true;
            }
            System.out.println("false");
        }
        return false;
    }

    private static boolean containsDate(String s, Element e) {
        NodeList dates = e.getElementsByTagName("check-out");
        for (int i = 0; i < dates.getLength(); i++) {
            if (dates.item(0).getTextContent().startsWith(s)) {
                return true;
            }
        }
        return false;
    }
}
