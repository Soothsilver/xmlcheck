/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

/**
 *
 * @author andrei
 */

import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

public class MySaxHandler extends DefaultHandler {

    public static void main(String[] args) {
        String sourcePath = "data.xml";
        try {
            XMLReader parser = XMLReaderFactory.createXMLReader();


            InputSource source = new InputSource(sourcePath);


            parser.setContentHandler(new MujContentHandler());

            parser.parse(source);

        } catch (Exception e) {
        }
    }
}

class MujContentHandler implements ContentHandler {

    Locator locator;
    int countElement;
    int countAtt;
    public String s1 = "price";
    public String s2 = "card_info";
    public String s3 = "reservation";
    public String s4 = "beds";
    public String s5 = "services";
    
    public StringBuffer buffer = new StringBuffer(100000);
    
    private boolean inElement;
    
    public int countReservations = 0;
    public int childBed = 0;
    public int countMasters = 0;
    public int priceTotal = 0;
    public int minibar = 0;

    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Document start
     */
    public void startDocument() throws SAXException {
        buffer = new StringBuffer(100000);

        System.out.println("*************************************");
        System.out.println("_______________Hotel_________________");
        System.out.println("**********attributes list************");
    }

    /**
     * Document end
     */
    public void endDocument() throws SAXException {
        System.out.println("***********************************" + "\n");
        System.out.println("count elements " + countElement);
        System.out.println("count attributes " + countAtt);
        System.out.println("total payed " + priceTotal + " Kč");
        System.out.println("payed with master card " + countMasters);
        System.out.println("total reservations " + countReservations);
        System.out.println("rooms with beds for children " + childBed);
        System.out.println("rooms with minibars " + minibar + "\n");
        System.out.println(".................END.................");


    }

    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if (qName.equals(s1) == true) {
            buffer.setLength(0);
            inElement = true;
        }
        if (qName.equals(s2) == true) {
            buffer.setLength(0);
            inElement = true;
        }
        if (qName.equals(s4) == true) {
            buffer.setLength(0);
            inElement = true;
        }
        if (qName.equals(s5) == true) {
            buffer.setLength(0);
            inElement = true;
        }

        countElement++;
        countAtt += atts.getLength();

        for (int i = 0; i < atts.getLength(); i++) {
            if (atts.getQName(i).equals("passId")) {
                return; // passId and passIdref has same values, print just once.
            }
            System.out.println(atts.getQName(i) + ": " + atts.getValue(i));
        }

    }

    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (qName.equals(s1)) {//Total payed
            inElement = false;
            priceTotal += Integer.parseInt(buffer.toString());

        } else if (qName.equals(s2)) {// payed with masterCard
            inElement = false;
            if (buffer.toString().equals(" master ")) {
                countMasters++;
            }
        } else if (qName.equals(s3)) {// total reservation

            inElement = false;
            countReservations++;

        } else if (qName.equals(s4)) {// beds for children
            inElement = false;
            if (buffer.toString().equals("child")) {
                childBed++;
            }

        } else if (qName.equals(s5)) {// rooms with minibars
            inElement = false;
            if (buffer.toString().contains("minibar")) {
                minibar++;
            }
        }
    }

    public void characters(char[] ch, int start, int length) {
        if (inElement == true) {
            buffer.append(ch, start, length);
        }
    }

    public void startPrefixMapping(String prefix, String uri) throws SAXException {
    }

    public void endPrefixMapping(String prefix) throws SAXException {
    }

    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
    }

    public void processingInstruction(String target, String data) throws SAXException {
    }

    public void skippedEntity(String name) throws SAXException {
    }
}