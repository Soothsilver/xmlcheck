//package mysaxhandler;
package user;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 * XML úkol SAX
 *
 * 1) Průměrný plat z obsahu elementu plat 2) Počet volných pozic z atributu
 * volne-misto elementu prace 3) Počet prací, které jsou volné (volne-misto) a
 * jejich plat je větší než MIN_PLAT
 *
 * @author miraz
 */
public class MySaxHandler extends DefaultHandler implements ContentHandler {

//    public static void main(String[] args) {
//        SAXSupport s = new SAXSupport();
//
//    }

    StringBuffer platContent = new StringBuffer();

    // Prumerny plat - uvnitr tagu
    boolean platFlag = false;
    int platyCelkem = 0;
    int pocetPraci = 0;
    // Pocet volnych pozic
    int pocetVolnych = 0;
    boolean volneMisto = false;
    // Pocet volnych mist s platem > MIN_PLAT
    final int MIN_PLAT = 190;
    int pocetVolnychSPlatem = 0;

    // overrides of DefaultHandler methods
    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {

        if (qName.equals("plat")) {
            platFlag = true;
        }

        if (qName.equals("prace")) {
            if (attributes.getValue("volne-misto").equals("ano")) {
                volneMisto = true;
                pocetVolnych++;
            }
        }

    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {

        if (platFlag) {
            platContent.append(ch, start, length);
        }

    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (qName.equals("plat")) {
            platFlag = false;
            pocetPraci++;
            int posledniPlat = Integer.parseInt(platContent.toString());
            platyCelkem += posledniPlat;

            if ((volneMisto) && (posledniPlat > MIN_PLAT)) {
                pocetVolnychSPlatem++;
            }
            volneMisto = false;
            
            // Clear buffer
            platContent = new StringBuffer();
        }
    }

    @Override
    public void endDocument() throws SAXException {
        System.out.println("Průměrný plat nabídek: " + prumernyPlat());
        System.out.println("Počet volných pozic: " + pocetVolnychPozic());
        System.out.println("Volných pozic s platem alespoň " + MIN_PLAT + ": " + pocetVolnychPozisSMinPlatem());
    }

    /**
     * Vrací průměrný plat všech prácí.
     *
     * @return Průměrný plat
     */
    public float prumernyPlat() {
        return platyCelkem / pocetPraci;
    }

    /**
     * Vrací počet volných pozic.
     *
     * @return početVolných
     */
    public int pocetVolnychPozic() {
        return pocetVolnych;
    }

    /**
     * Vrací počet volných pozic s platem větěím než MIN_PLAT.
     *
     * @return pocetVolnychSPlatem
     */
    public int pocetVolnychPozisSMinPlatem() {
        return pocetVolnychSPlatem;
    }

}

//class SAXSupport {
//
//    // Path to input file
//    private static final String INPUT_FILE = "data.xml";
//
//    /**
//     * Constructor.
//     *
//     */
//    public SAXSupport() {
//
//        try {
//
//            // Create parser instance
//            XMLReader parser = XMLReaderFactory.createXMLReader();
//
//            // Create input stream from source XML document
//            InputSource source = new InputSource(INPUT_FILE);
//
//            // Set our custom content handler for handling SAX events (it must implements ContentHandler interface)
//            parser.setContentHandler(new MySaxHandler());
//
//            // Process input data
//            parser.parse(source);
//
//        } catch (Exception e) {
//
//            e.printStackTrace();
//
//        }
//
//    }
//}
