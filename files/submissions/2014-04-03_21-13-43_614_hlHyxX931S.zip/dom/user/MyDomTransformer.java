//package mydomtransformer;
package user; 

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * 1) Přidání nového zájemce o práce. 2) Odstranění prací které již nejsou
 * volné. (Atribut volne-misto)
 *
 *
 * @author miraz
 */
public class MyDomTransformer {
    
//    private static final String INPUT_FILE = "data.xml";
//    private static final String OUTPUT_FILE = "data.out.xml";
//
//    /**
//     * @param args the command line arguments
//     */
//    public static void main(String[] args) {
//        try {
//
//            // DocumentBuilderFactory creates DOM parsers
//            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
//
//            // We don't want to validate file
//            dbf.setValidating(false);
//
//            // Creating of DOM parser instance
//            DocumentBuilder builder = dbf.newDocumentBuilder();
//
//            // Parser processes input file and creates a DOM tree of objects
//            Document doc = builder.parse(INPUT_FILE);
//
//            // DOM tree processing
//            processTree(doc);
//
//            // TransformerFactory creates an object for DOM serialization
//            TransformerFactory tf = TransformerFactory.newInstance();
//
//            // Transformer serializes DOM tree
//            Transformer writer = tf.newTransformer();
//
//            // Setting of output file encoding
//            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
//
//            // Run transformation of DOM tree to XML document
//            writer.transform(new DOMSource(doc), new StreamResult(new File(OUTPUT_FILE)));
//
//        } catch (Exception e) {
//
//            e.printStackTrace();
//
//        }
//    }
//
//    /**
//     * Process document tree
//     *
//     * @param doc Document to be parsed
//     */
//    private static void processTree(Document doc) {
//
//        // 1 - novy zajemce
//        Element item = doc.createElement("zajemce");
//
//        Element oPraci = doc.createElement("o-praci");
//        oPraci.setAttribute("id", "prace3");
//        item.appendChild(oPraci);
//
//        item.appendChild(doc.createElement("jmeno")).setTextContent("Jaroslav");
//        item.appendChild(doc.createElement("prijmeni")).setTextContent("Vytočil");
//        item.appendChild(doc.createElement("email")).setTextContent("vyskoc@centrum.cz");
//        item.appendChild(doc.createElement("telefon")).setTextContent("+420 773 023 939");
//        item.appendChild(doc.createElement("text-zpravy")).setTextContent("Dobrý den, líbí se mi Vaše nabídka a mám o ni veliký zájem.");
//
//        NodeList eq = doc.getElementsByTagName("jobs");
//        Element jobs;
//        if (eq.getLength() == 0) {
//            jobs = doc.createElement("jobs");
//            doc.getFirstChild().appendChild(jobs);
//        } else {
//            jobs = (Element) eq.item(0);
//        }
//
//        jobs.appendChild(item);
//
//        // 2 - odstraneni praci, ktere jiz nejsou volne
//        NodeList prace = doc.getElementsByTagName("prace");
//
//        for (int i = 0; i < prace.getLength(); i++) {
//            if (prace.item(i).getAttributes().getNamedItem("volne-misto").getNodeValue().equals("ne")) {
//                Node parent = prace.item(i).getParentNode();
//                parent.removeChild(prace.item(i));
//            }
//        }
//    }

    public void transform(Document xmlDocument) {
// 1 - novy zajemce
        Element item = xmlDocument.createElement("zajemce");

        Element oPraci = xmlDocument.createElement("o-praci");
        oPraci.setAttribute("id", "prace3");
        item.appendChild(oPraci);

        item.appendChild(xmlDocument.createElement("jmeno")).setTextContent("Jaroslav");
        item.appendChild(xmlDocument.createElement("prijmeni")).setTextContent("Vytočil");
        item.appendChild(xmlDocument.createElement("email")).setTextContent("vyskoc@centrum.cz");
        item.appendChild(xmlDocument.createElement("telefon")).setTextContent("+420 773 023 939");
        item.appendChild(xmlDocument.createElement("text-zpravy")).setTextContent("Dobrý den, líbí se mi Vaše nabídka a mám o ni veliký zájem.");

        NodeList eq = xmlDocument.getElementsByTagName("jobs");
        Element jobs;
        if (eq.getLength() == 0) {
            jobs = xmlDocument.createElement("jobs");
            xmlDocument.getFirstChild().appendChild(jobs);
        } else {
            jobs = (Element) eq.item(0);
        }

        jobs.appendChild(item);

        // 2 - odstraneni praci, ktere jiz nejsou volne
        NodeList prace = xmlDocument.getElementsByTagName("prace");

        for (int i = 0; i < prace.getLength(); i++) {
            if (prace.item(i).getAttributes().getNamedItem("volne-misto").getNodeValue().equals("ne")) {
                Node parent = prace.item(i).getParentNode();
                parent.removeChild(prace.item(i));
            }
        }
    }

}
