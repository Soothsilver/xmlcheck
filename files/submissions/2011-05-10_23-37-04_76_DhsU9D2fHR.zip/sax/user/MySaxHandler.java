
package user;

import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler
{
	// Spocita, kolik jezdcu startujicich v sezone 2010 ma nemeckou narodnost
	
	public int numberOfGermans; // pocet Nemcu
	private boolean inSeason; // interni flag indikujici, zda se parser nachazi uvnitr elementu "season"
	private boolean inNationality; // interni flag indikujici, zda se parser nachazi uvnitr elementu "nationality"
	private String tmpString; // string, do ktereho se uklada textovy obsah elementu "nationality"
	
	public void startDocument()
	{
		numberOfGermans = 0;
		inSeason = false;
		inNationality = false;
		tmpString = "";
	}
	
	public void startElement(String uri, String localName, String qName, Attributes atts)
	{
		if (inSeason)
		{
			if (qName.equals("nationality"))
				inNationality = true;
		}
		else if (qName.equals("season") && atts.getValue(0).equals("2010"))
			inSeason = true;
	}
	
	public void characters(char[] ch, int start, int length)
	{
		if (inSeason && inNationality)
			for (int i = start; i < start+length; ++i)
				tmpString+= ch[i];
	}
	
	public void endElement(String uri, String localName, String qName)
	{
		if (qName.equals("nationality"))
		{
			if (tmpString.equals("Germany"))
				++numberOfGermans;				

			tmpString = "";	
			inNationality = false;
		}
		else if (qName.equals("season"))
			inSeason = false;
	}
	
	public void endDocument()
	{
		System.out.println("Pocet Nemcu ve startovnim poli: "+numberOfGermans);
	}
}
