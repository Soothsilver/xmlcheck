
package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer
{
	private Document document;
	
	/*
	 *  Provadena transformace: Zaznamy o zavodnich pilotech se presunou pod zavodni tymy, pro
	 *  ktere jednotlivi piloti zavodi - tzn. polozky "race_driver" se objevi pod elementy
	 *  "race_teams", vcetne podelementu "name", "driver_no" a "nationality" (puvodni element
	 *  "team_id" pozbyva smyslu), cela sekce "race_drivers" se nasledne smaze.
	 */	
	public void transform (Document xmlDocument)
	{
		document = xmlDocument;
		
		// Najde uzly, se kterymi chceme pracovat
		NodeList raceDriversNode = xmlDocument.getElementsByTagName("race_drivers");
		NodeList raceTeamsNode = xmlDocument.getElementsByTagName("race_teams");
		
		for (int i = 0; i < raceTeamsNode.getLength(); ++i)
		{
			// Pripoji piloty pod prislusne tymy
			mergeDriversTeams(raceDriversNode.item(i), raceTeamsNode.item(i));

			// Odstrani element race_drivers a jeho syny
			raceDriversNode.item(i).getParentNode().removeChild(raceDriversNode.item(i));
		}
	}
	
	/*
	 *  Pripoji elementy "race_driver" pod prislusne elementy "race_team" - podelementy
	 *  race_driver zustavaji stale "name", "driver_no" a "nationality" ("team_id" je vypusten)
	 */
	private void mergeDriversTeams(Node driversNode, Node teamsNode)
	{
		NodeList driversList = driversNode.getChildNodes();
		NodeList teamsList = teamsNode.getChildNodes();
	
		int j = 0; // index pro driversList
		
		for (int i = 1; i < teamsList.getLength(); ++i)
		{
			// Preskakuj textove uzly v seznamu tymu
			if (teamsList.item(i).getNodeType() == 3)
				continue;

			// Preskoc pripadny textovy uzel v seznamu pilotu
			if (driversList.item(j).getNodeType() == 3)
				++j;
			
			// Pridej prvniho pilota pod element race_team
			teamsList.item(i).appendChild(buildNewDriverElement(driversList.item(j)));
			
			// Dej mi druheho pilota
			++j;
			
			// Preskoc pripadny textovy uzel v seznamu pilotu
			if (driversList.item(j).getNodeType() == 3)
				++j;
			
			// Pridej druheho pilota pod element race_team
			teamsList.item(i).appendChild(buildNewDriverElement(driversList.item(j)));
				
			++j;			
		}
	}
	
	/*
	 *  Pro daneho jezdce vytvori novy uzel
	 */
	private Element buildNewDriverElement(Node driver)
	{
		String d_name = driver.getChildNodes().item(1).getChildNodes().item(0).getNodeValue();
		String d_number = driver.getChildNodes().item(3).getChildNodes().item(0).getNodeValue();
		String d_nationality = driver.getChildNodes().item(5).getChildNodes().item(0).getNodeValue();
			
		Element new_driver = document.createElement("race_driver");
		
		Element name = document.createElement("name");
		name.appendChild(document.createTextNode(d_name));
		new_driver.appendChild(name);
		
		Element driver_number = document.createElement("driver_no");
		driver_number.appendChild(document.createTextNode(d_number));
		new_driver.appendChild(driver_number);
		
		Element nationality = document.createElement("nationality");
		nationality.appendChild(document.createTextNode(d_nationality));
		new_driver.appendChild(nationality);
		
		return new_driver;
	}
}