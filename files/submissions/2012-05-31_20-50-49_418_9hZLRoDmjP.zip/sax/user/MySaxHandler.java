package user;

import java.util.*;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Zadani ukolu pro SAX. Prumerny pocet najmu moviteho majetku na jednu osobu,
 * ktera ale v obci za nic nezodpovida, za predchazejici rok. Jinymi slovy,
 * kolikrat si tak bezny obcan neangazujici se ve vedeni obce vypujci veci za
 * rok.
 *
 * @author radimbufka@gmail.com
 */
public class MySaxHandler extends DefaultHandler {

    Set<String> obcaneIds = new TreeSet<String>();
    Set<String> movitostiIds = new TreeSet<String>();
    int pocetPronajmu = 0;
    State currentState;
    final String OSOBY = "zodpovedne-osoby";
    final String MOVITY = "movity";
    final String PRONAJMY = "pronajmy";

    public MySaxHandler() {
    }
    // overrides of DefaultHandler methods

    // @Override
    public void startDocument() throws SAXException {
        currentState = new RootState();
    }

    // @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        if (localName == null || localName.isEmpty()) {
            localName = qName;
        }
        currentState = currentState.startElement(uri, localName, qName, attributes);
    }

    // @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (localName == null || localName.isEmpty()) {
            localName = qName;
        }
        currentState = currentState.endElement(uri, localName, qName);
    }

    // @Override
    public void endDocument() throws SAXException {
        if (obcaneIds.isEmpty()) {
            System.out.println(0);
        } else {
            System.out.println(pocetPronajmu / (float) obcaneIds.size());
        }
    }

    /**
     * Pocatecni stav cteciho automatu.
     */
    class RootState implements State {

        // @Override
        public State startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
            if (localName.equals(OSOBY)) {
                return new ObcaneState(this);
            } else if (localName.equals(MOVITY)) {
                return new MovitostiState(this);
            } else if (localName.equals(PRONAJMY)) {
                return new PronajmyState(this);
            } else {
                return this;
            }
        }

        // @Override
        public State endElement(String uri, String localName, String qName) throws SAXException {
            return this;
        }
    }

    /**
     * Stav pro sekci s osobami.
     */
    class ObcaneState implements State {

        private State returnState;
        private String proposal;

        public ObcaneState(State returnState) {
            this.returnState = returnState;
        }

        // @Override
        public State startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
            if (localName.equals("fo") || localName.equals("po")) {
                String id = atts.getValue(uri, "id");
                // navrhni obcana, jako neangazujiciho se
                propose(id);
            } else if (localName.equals("odpovednost")) {
                if (atts.getLength() == 0) {
                    commit();
                } else {
                    String attVal = atts.getValue(uri, "ref");
                    if (attVal == null || attVal.isEmpty()) {
                        commit();
                    } else {
                        rollback();
                    }
                }
            }
            return this;
        }

        // @Override
        public State endElement(String uri, String localName, String qName) throws SAXException {
            if (localName.equals(OSOBY)) {
                return returnState;
            } else {
                return this;
            }
        }

        private void propose(String id) {
            proposal = id;
        }

        private void commit() {
            obcaneIds.add(proposal);
            proposal = null;
        }

        private void rollback() {
            proposal = null;
        }
    }
    
    /**
     * Stav pro sekci s movitym majetkem.
     */
    class MovitostiState implements State {

        private State returnState;

        public MovitostiState(State returnState) {
            this.returnState = returnState;
        }

        // @Override
        public State startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
            if (localName.equals("movitost")) {
                String id = atts.getValue(uri, "id");
                movitostiIds.add(id);
            }
            return this;
        }

        // @Override
        public State endElement(String uri, String localName, String qName) throws SAXException {
            if (localName.equals(MOVITY)) {
                return returnState;
            } else {
                return this;
            }
        }
    }
    
    /**
     * Stav pro sekci s pronajmy.
     */
    class PronajmyState implements State {

        private State returnState;

        public PronajmyState(State returnState) {
            this.returnState = returnState;
        }

        // @Override
        public State startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
            if (localName.equals("pronajem")) {
                String idPredmetu = atts.getValue(uri, "predmet");
                String idNajemnika = atts.getValue(uri, "najemnik");
                int rokVypujceni = Integer.parseInt(atts.getValue(uri, "od").substring(0, 4));
                int rokVraceni = Integer.parseInt(atts.getValue(uri, "do").substring(0, 4));
                // cz v locale bohuzel nemam, ale kalendar (i cas) mame stejny
                int lonskyRok = new GregorianCalendar(Locale.GERMANY).get(Calendar.YEAR) - 1;
                //System.out.println(lonskyRok);
                //lonskyRok = 2011;
                if (obcaneIds.contains(idNajemnika)
                        && movitostiIds.contains(idPredmetu)
                        && rokVypujceni <= lonskyRok
                        && rokVraceni >= lonskyRok) {
                    pocetPronajmu++;
                }
            }

            return this;
        }

        // @Override
        public State endElement(String uri, String localName, String qName) throws SAXException {
            if (localName.equals(PRONAJMY)) {
                return returnState;
            } else {
                return this;
            }
        }
    }

    interface State {

        public State startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException;

        public State endElement(String uri, String localName, String qName) throws SAXException;
    }
}