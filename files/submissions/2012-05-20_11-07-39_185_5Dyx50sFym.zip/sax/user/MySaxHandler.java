/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.util.ArrayList;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * @author PaHorPC32
 */
public class MySaxHandler extends DefaultHandler{
    
    private class Ucitel{
    
    public String jmeno;
    public String prijmeni;
    
    public int plat2009;
    public int plat2010;
    public int plat2011;
    public int plat2012;
    
    public String neucil = "";        
}
    
    
    ArrayList<Ucitel> list = new ArrayList<Ucitel>();
        
    Locator locator;    
        
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }
    
    @Override
    public void startDocument() throws SAXException {
    }
        
    @Override
    public void endDocument() throws SAXException {
        for (Ucitel ucitel : list) {
            if (ucitel.neucil.contains("2010"))
                continue;
            if ((double)(ucitel.plat2010 + ucitel.plat2011 + ucitel.plat2012) / 3D > 17000)
                System.out.println(ucitel.jmeno + " " + ucitel.prijmeni);
        }
        
        System.out.println("KONEC");            
    }
    
    boolean jmenoUc, prijmeniUc, r2009, r2010, r2011, r2012;
    
    
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if (localName == null || "".equals(localName))
            throw new SAXException();       
        if (qName.equals("Ucitel")){
            list.add(new Ucitel());
        } else if (qName.equals("JmenoUc")){
            jmenoUc = true;
        } else if (qName.equals("PrijmeniUc")){
            prijmeniUc = true;
        } else if (qName.equals("r2009")){
            r2009 = true;
        } else if (qName.equals("r2010")){
            r2010 = true;
        } else if (qName.equals("r2011")){
            r2011 = true;
        } else if (qName.equals("r2012")){
            r2012 = true;
        } else if (qName.equals("n2009")){
            list.get(list.size()-1).neucil += "n2009 ";
        } else if (qName.equals("n2010")){
            list.get(list.size()-1).neucil += "n2010 ";
        } else if (qName.equals("n2011")){
            list.get(list.size()-1).neucil += "n2011 ";
        } else if (qName.equals("n2012")){
            list.get(list.size()-1).neucil += "n2012 ";
        }
    }
      
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {     
       
    }
    
               
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {                      
       
       StringBuilder sb = new StringBuilder();
       for (int i = start; i < start + length; i++) {
           if (ch[i] == '\n') continue; 
           sb.append(ch[i]);          
        }         
        try {
             if (jmenoUc){
                list.get(list.size()-1).jmeno = sb.toString();
                jmenoUc = false;
            } else if (prijmeniUc){
                list.get(list.size()-1).prijmeni = sb.toString();
                prijmeniUc = false;
            } else if (r2009){
                list.get(list.size()-1).plat2009 = Integer.parseInt(sb.toString());
                r2009 = false;
            } else if (r2010){
                list.get(list.size()-1).plat2010 = Integer.parseInt(sb.toString());
                r2010 = false;
            } else if (r2011){
                list.get(list.size()-1).plat2011 = Integer.parseInt(sb.toString());
                r2011 = false;
            } else if (r2012){
                list.get(list.size()-1).plat2012 = Integer.parseInt(sb.toString());
                r2012 = false;
            }
        } catch (Exception e) {
            jmenoUc = prijmeniUc = r2009 = r2010 = r2011 = r2012 = false;
        }
       
    }
    
     
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
        // ...
        
    }

     
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
    
        // ...
    
    }

     
    @Override
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
        // ...
        
    }
      
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
      
      // ...
            
    }
      
    @Override
    public void skippedEntity(String name) throws SAXException {
    
      // ...
    
    }
}
