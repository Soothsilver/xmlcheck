<?php

require_once 'TestXmlDtd.php';

/**
 * @ingroup plugins
 * @projectname plugin for checking XML-DTD homework of XML Technologies lecture.
 * Requires solutions to contain source files @c "data.xml" and @c "data.dtd".
 * Uses TestXmlSchema to perform checking.
 */
class XmlDtdChecker extends \asm\plugin\SingleTestPlugin
{
	/**
	 * @copybrief asm::plugin::SingleTestPlugin::setUp()
	 *
	 * @param array $params uses following arguments:
	 * @li minimum XML depth
	 * @li minimum XML fan-out
	 */
	protected function setUp ($params)
	{
		$this->setTest(new TestXmlDtd(), array(
				TestXmlDtd::sourceXml => 'data.xml',
				TestXmlDtd::sourceDtd => 'data.dtd',
			),	array(
				TestXmlDtd::xmlDepth => isset($params[0]) ? $params[0] : 5,
				TestXmlDtd::xmlFanOut => isset($params[1]) ? $params[1] : 10,
			));
	}
}

?>