<?php

use asm\utils\StringUtils,
	asm\plugin\CountedRequirements,
	asm\plugin\XmlRegex;

require_once 'XML/DTD.php';

/**
 * @ingroup plugins
 * Test for checking XML-DTD homework of XML Technologies lecture.
 * Accepted parameters are defined as class constants (and documented in-place).
 */
class TestXmlDtd extends \asm\plugin\XmlTest
{
	/// @name Names of accepted test parameters
	//@{
	const sourceXml = 'xml';	///< path of source XML file
	const sourceDtd = 'dtd';	///< path of source DTD file

	const dtdEmptyElements = 1;	///< minimum number of empty element definitions in DTD
	const dtdTextElements = 2;	///< minimum number of text element definitions in DTD
	const dtdModeledElements = 3;	///< minimum number of modeled element definitions in DTD
	/// minimum number of element occurence limitations used in DTD
	const dtdLimitedOccurenceElements = 4;
	const dtdAttributes = 5;	///< minimum number of attributes defined in DTD
	/// minimum number of attribute occurence limitations used in DTD
	const dtdLimitedOccurenceAttributes = 6;
	const dtdTextDataTypes = 7;	///< minimum number of text data types used in DTD
	const dtdEnumDataTypes = 8;	///< minimum number of enum data types used in DTD
	const dtdIdKeys = 9;	///< minimum number of ID keys used in DTD
	const dtdIdRefs = 10;	///< minimum number of ID references used in DTD
	const dtdOperators = 11;	///< minimum number of operators used in DTD

	const xmlElements = 12;	///< minimum number of elements in XML
	const xmlAttributes = 13;	///< minimum number of attributes in XML
	const xmlKeys = 14;	///< minimum number of ID keys used in XML
	const xmlReferences = 15;	///< minimum number of ID references used in XML
	const xmlTextContent = 16;	///< minimum number of elements with text content in XML
	const xmlMixedContent = 17;	///< minimum number of elements with mixed content in XML
	const xmlDepth = 18;	///< minimum depth of XML document
	const xmlFanOut = 19;	///< minimum fan-out of XML document

	const specialEntities = 20;	///< minimum number of entities in XML or DTD
	const specialInstructions = 21;	///< minimum number of processing instructions in XML or DTD
	const specialCdata = 22;	///< minimum number of CDATA sections in XML or DTD
	const specialComments = 23;	///< minimum number of comments in XML or DTD
	//@}

	/// @name Goal IDs
	//@{
	const goalValidDtd = 'validDtd';	///< DTD is valid
	const goalWellFormedXml = 'wellFormedXml';	///< XML is well-formed
	const goalValidXml = 'validXml';	///< XML is valid
	const goalCoveredDtd = 'coveredDtd';	///< DTD contains required constructs
	const goalCoveredXml = 'coveredXml';	///< XML contains required constructs
	const goalCoveredSpecials = 'coveredSpecials';	///< sources contain required special constructs
	//@}

	protected $xmlAttrIDs = array();		///< index of ID keys
	protected $xmlAttrIDRefs = array();	///< index of ID references

	/**
	 * Validates DTD document
	 * @param string $dtdString source DTD
	 * @param[out] XML_DTD_Tree $dtdDoc parsed DTD
	 * @return bool true on success
	 */
	protected function checkDTDValidity ($dtdString, &$dtdDoc)
	{
		$dtdParser = new XML_DTD_Parser;
		$this->startErrorBasedSection();
		$dtdDoc = $dtdParser->parse($dtdString, false);
		$this->endErrorBasedSection();

		// h4ck: fix incorrect entity parsing
		foreach ($this->getTriggeredErrors(false) as $key => $val)
		{
			if (preg_match("/^Entity (<!ENTITY\s+[^>]+\s*>) not supported$/s", $val['error'], $matches))
			{
				$xmlRegex = XmlRegex::getInstance(XmlRegex::WRAP_PERL);
				if (preg_match($xmlRegex->EntityDecl, $matches[1])) // '/^([a-zA-Z0-9.\-]+)\s+(["\'])(.*)\2\s*$/s'
				{
					$this->removeTriggeredError($key);
				}
			}
		}

		return $this->reachGoalErrorBased(self::goalValidDtd, self::sourceDtd);
	}

	/**
	 * Validates XML document.
	 * @param DOMDocument $xmlDom source XML
	 * @return bool true on success
	 */
	protected function checkXMLValidity ($xmlDom)
	{
		$this->useLibxmlErrors();
		$xmlDom->validate();

		return $this->reachGoalOnNoLibxmlErrors(self::goalValidXml, self::sourceXml);
	}

	/**
	 * Searches for occurences of required DTD constructs and marks them in supplied
	 * index.
	 * @param XML_DTD_Tree $dtdDoc source DTD
	 * @param CountedRequirements $reqs occurence index
	 */
	protected function markDTDConstructOccurences ($dtdDoc, $reqs)
	{
		$limitedElems = array();
		$operatorCounts = array(',' => 0, '|' => 0, '?' => 0, '+' => 0, '*' => 0);
		$operators = array_keys($operatorCounts);
		
		foreach ($dtdDoc->dtd['elements'] as $tagName => $properties)
		{
			switch ($properties['content'])
			{
				case 'EMPTY':
					$reqs->addOccurence(self::dtdEmptyElements);
					break;
				case '#PCDATA':
					$reqs->addOccurence(self::dtdTextElements);
					break;
			}

			if (isset($properties['child_validation_dtd_regex']) && $properties['child_validation_dtd_regex'])
			{
				$reqs->addOccurence(self::dtdModeledElements);
				
				foreach ($operators as $operator)
				{
					$operatorCounts[$operator] += substr_count($properties['child_validation_dtd_regex'], $operator);
				}
			}
			
			foreach ($properties['children'] as $childName)
			{
				if (!isset($limitedElems[$childName]))
				{
					$limitedElems[$childName] = false;
				}
			}
			
			foreach ($limitedElems as $name => $isLimited)
			{
				if (!$isLimited && !in_array($name, $properties['children']))
				{
					$limitedElems[$name] = true;
					$reqs->addOccurence(self::dtdLimitedOccurenceElements);
				}
			}
			
			if (isset($properties['attributes']))
			{
				$reqs->addOccurences(self::dtdAttributes, count($properties['attributes']));

				foreach ($properties['attributes'] as $attrName => $attrData)
				{
					if ($attrData['defaults'] == '#REQUIRED')
					{
						$reqs->addOccurence(self::dtdLimitedOccurenceAttributes);
					}
					
					if (is_array($attrData['opts']))
					{
						$reqs->addOccurence(self::dtdEnumDataTypes);
					}
					else if ($attrData['opts'] == 'CDATA')
					{
						$reqs->addOccurence(self::dtdTextDataTypes);
					}
					else if ($attrData['opts'] == 'ID')
					{
						$reqs->addOccurence(self::dtdIdKeys);
						$this->xmlAttrIDs[] = "$tagName>$attrName";
					}
					else if ($attrData['opts'] == 'IDREF')
					{
						$reqs->addOccurence(self::dtdIdRefs);
						$this->xmlAttrIDRefs[] = "$tagName>$attrName";
					}
				}
			}
		}
		
		sort($operatorCounts);
		$reqs->addOccurences(self::dtdOperators, $operatorCounts[count($operatorCounts) - 1]);
	}

	/**
	 * Checks coverage of required DTD constructs.
	 * @param XML_DTD_Tree $dtdDoc source DTD
	 * @return bool true on success
	 */
	protected function checkDTDConstructCoverage ($dtdDoc)
	{
		$reqs = new CountedRequirements(array(
			'data' => array(
				self::dtdEmptyElements => 'empty elements',
				self::dtdTextElements => 'elements with text content',
				self::dtdModeledElements => 'elements with modeled content',
				self::dtdLimitedOccurenceElements => 'elements with occurence limitations',
				self::dtdAttributes => 'attributes',
				self::dtdLimitedOccurenceAttributes => 'attributes with occurence limitations',
				self::dtdTextDataTypes => 'text data types',
				self::dtdEnumDataTypes => 'enumerated data types',
				self::dtdIdKeys => 'id keys',
				self::dtdIdRefs => 'id references',
				self::dtdOperators => 'operators',
			),
			'counts' => array(),
		));
		$this->markDTDConstructOccurences($dtdDoc, $reqs);
		return $this->resolveCountedRequirements($reqs, self::goalCoveredDtd);
	}

	/**
	 * Manages ID reference index.
	 * @param string $id ID value
	 * @param bool $isRef true if current entity is ID reference (otherwise it's
	 *		an ID key)
	 * @param array $ids ID reference index
	 * @return mixed true if value of @a $id has just been found both as ID key and
	 *		ID reference attribute value, false if it has been found just as one of
	 *		those so far, null if it @c true has been returned for this value already
	 */
	protected function manageIdReferences ($id, $isRef, &$ids)
	{
		if (!isset($ids[$id]))
		{
			$ids[$id] = $isRef;
			return false;
		}
		elseif ($ids[$id] !== null)
		{
			if ($ids[$id] != $isRef)
			{
				$ids[$id] = null;
				return true;
			}
		}
		return null;
	}

	/**
	 * Searches for required construct occurences in XML and marks found occurences
	 * in occurence index.
	 * @param SimpleXMLElement $xmlEl source XML
	 * @param CountedRequirements $reqs occurence index
	 * @param array $internal internal index of this method (<b>DO NOT use this
	 *		argument from other methods.</b>)
	 */
	protected function markXMLConstructOccurences ($xmlEl, $reqs,
		&$internal = array('elements' => array(), 'attributes' => array(), 'ids' => array(), 'level' => 0))
	{
		$elName = $xmlEl->getName();
		if (!isset($internal['elements'][$elName]))
		{
			$internal['elements'][$elName] = true;
			$reqs->addOccurence(self::xmlElements);
		}
		
		foreach ($xmlEl->attributes() as $attrName => $attrVal)
		{
			$internalAttrName = "$elName>$attrName";
			if (!isset($internal['attributes'][$internalAttrName]))
			{
				$internal['attributes'][$internalAttrName] = true;
				$reqs->addOccurence(self::xmlAttributes);
			}
			
			$isRef = null;
			if (in_array($internalAttrName, $this->xmlAttrIDs))
			{
				$isRef = false;
			}
			if (in_array($internalAttrName, $this->xmlAttrIDRefs))
			{
				$isRef = true;
			}
			
			if ($isRef !== null)
			{
				if (($refUsed = $this->manageIdReferences((string)$attrVal, $isRef, $internal['ids'])) !== null)
				{
					$reqs->addOccurence(self::xmlKeys);
					if ($refUsed) $reqs->addOccurence(self::xmlReferences);
				}
			}
		}
		
		$children = $xmlEl->children();
		$numChildren = count($children);
		$level = $internal['level'];
		$reqs->tryRaiseCount(self::xmlDepth, $level);
		$reqs->tryRaiseCount(self::xmlFanOut, $numChildren);
		
		if ($numChildren > 0)
		{
			++$level;
			foreach ($children as $child)
			{
				$internal['level'] = $level;
				$this->markXMLConstructOccurences($child, $reqs, $internal);
			}
		}
		else
		{
			$reqs->addOccurence(((string)$xmlEl != '') ? self::xmlTextContent : self::xmlMixedContent);
		}
	}

	/**
	 * Checks XML for occurence of required constructs.
	 * @param SimpleXMLElement $xml source XML
	 * @return bool true on success
	 */
	protected function checkXMLConstructCoverage (SimpleXMLElement $xml)
	{
		$reqs = new CountedRequirements(array(
			'data' => array(
				self::xmlElements => 'used elements',
				self::xmlAttributes => 'used attributes',
				self::xmlKeys => 'used keys',
				self::xmlReferences => 'used key references',
				self::xmlTextContent => 'elements with text content',
				self::xmlMixedContent => 'elements with mixed content',
				self::xmlDepth => 'maximum depth of',
				self::xmlFanOut => 'maximum fan-out of',
			),
			'counts' => $this->params,
		));

		$this->markXMLConstructOccurences($xml, $reqs);
		return $this->resolveCountedRequirements($reqs, self::goalCoveredXml);
	}

	/**
	 * Checks XML and DTD documents for occurences of required special constructs.
	 * @param string $xmlString source XML
	 * @param string $dtdString source DTD
	 * @return bool true on success
	 */
	protected function checkSpecialConstructCoverage ($xmlString, $dtdString)
	{
		$xmlRegex = XmlRegex::getInstance(XmlRegex::WRAP_PERL);
		$reqs = new CountedRequirements(array(
			'data' => array(
				self::specialEntities => array('entities', $xmlRegex->PEReference, $xmlRegex->Reference),
				self::specialInstructions => array('processing instructions', // $xmlRegex->PI), // < hangs PHP on preg_match (PHP bug)
						$xmlRegex->wrap('.{7}\<\?', null, XmlRegex::DOT_MATCH_ALL)), // < fixme (temporary hack because of PHP bug ^)
				self::specialCdata => array('CDATA sections', $xmlRegex->CDSect),
				self::specialComments => array('comments', $xmlRegex->Comment),
			),
			'counts' => $this->params,
			'extras' => array('dtdRegex', 'xmlRegex'),
		));

		foreach ($reqs->getNames() as $name)
		{
			$matches = preg_match_all($reqs->getExtra('dtdRegex', $name), $dtdString, $dummy)
				+ preg_match_all($reqs->getExtra('xmlRegex', $name), $xmlString, $dummy);
			$reqs->addOccurences($name, $matches);
		}
		return $this->resolveCountedRequirements($reqs, self::goalCoveredSpecials);
	}
	
	protected function main ()
	{
		$this->addGoals(array(
			self::goalValidDtd => 'DTD is valid',
			self::goalWellFormedXml => 'XML is well-formed',
			self::goalValidXml => 'XML is valid to supplied DTD',
			self::goalCoveredDtd => 'DTD document contains required constructs',
			self::goalCoveredXml => 'XML document contains required constructs',
			self::goalCoveredSpecials => 'Documents contain required special constructs',
		));

		if (!$this->checkSources(self::sourceXml, self::sourceDtd))
			return;

		StringUtils::removeBomFromFile($this->paths[self::sourceDtd]);
		$dtdString = file_get_contents($this->paths[self::sourceDtd]);

		if ($this->checkDTDValidity($dtdString, $dtdDoc))
		{
			$this->checkDTDConstructCoverage($dtdDoc);
		}
		else
		{
			$this->failGoal(self::goalCoveredDtd, 'Document is not valid DTD');
		}

		if ($this->loadXml($this->paths[self::sourceXml], $xmlDom, $error))
		{
			$this->reachGoal(self::goalWellFormedXml);
			$this->checkXMLValidity($xmlDom);
			$this->checkXMLConstructCoverage(simplexml_import_dom($xmlDom));
			$this->checkSpecialConstructCoverage(file_get_contents($this->paths[self::sourceXml]), $dtdString);
		}
		else
		{
			$this->failGoals(array(self::goalWellFormedXml, self::goalValidXml,
					self::goalCoveredXml, self::goalCoveredSpecials), $error);
		}
	}
}

?>