/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * @author Jakub Stasta
 */
public class MySaxHandler extends DefaultHandler {
  
  String meshName;
  int totalVertices=0;
  double x=0,y=0,z=0;
  boolean inCamera=false;
  String camName;
  String camName2;
  int fovVal;
  boolean fov;
  boolean cam_name;
  int objects=0;
  boolean hasTriangle;
  
  
  @Override
  public void startDocument() throws SAXException {
    //System.out.println("Zacatek dokumentu");
  }

  @Override
  public void startElement(String uri, String localName,String qName, Attributes attributes) throws SAXException {
    if(qName.equals("vertex")){
      attributes(attributes);
      totalVertices++;
    }
    else if(qName.equals("cam_name") && inCamera){
      cam_name=true;
    }
    else if(qName.equals("fov") && inCamera){
      fov=true;
    }
    else if(qName.equals("triangle")){
      hasTriangle=true;
    }
    
    
    if(qName.equals("mesh"))
      meshName=attributes.getValue(1);
    else if(qName.equals("camera"))
      inCamera=true;
    //System.out.println("<" + qName + attributes(attributes) + ">");
  }

  private void attributes(Attributes attributes) {
    x+=Double.parseDouble(attributes.getValue(1));
    y+=Double.parseDouble(attributes.getValue(2));
    z+=Double.parseDouble(attributes.getValue(3));
    /*StringBuffer buffer = new StringBuffer();
    for (int i = 0; i < attributes.getLength(); i++) {
      buffer.append(" ");
      buffer.append(attributes.getQName(i));
      buffer.append("=\"");
      buffer.append(attributes.getValue(i));
      buffer.append("\"");
    }
    return buffer.toString();*/
  }

  @Override
  public void endElement(String uri, String localName,String qName) throws SAXException {
    if(qName.equals("mesh")){
      System.out.println("Center of gravity of mesh \""+meshName+"\" is in x="+(x/totalVertices)+" ,y="+(y/totalVertices)+",z="+(z/totalVertices));
      
      x=0;
      y=0;
      z=0;
      
      if(totalVertices>2 && hasTriangle){
        objects++;
      }
      totalVertices=0;
      hasTriangle=false;
    }
    else if(qName.equals("camera")){
      inCamera=false;
    }
    else if(qName.equals("cam_name") && inCamera){
      cam_name=false;
    }
    else if(qName.equals("fov") && inCamera){
      fov=false;
    }
    //System.out.print("</" + qName + ">");
  }

  @Override
  public void characters(char[] ch, int start, int length)
          throws SAXException {
    if(cam_name)
      camName2=new String(ch, start, length);
    
    
    if(fov){
      int tmp=Integer.parseInt(new String(ch, start, length));
      if(tmp>fovVal){
        fovVal=tmp;
        camName=camName2;
      }
    }
    
  }

  @Override
  public void endDocument() {
    System.out.println("The camera with the biggest field of view is: "+camName+" with FOV="+fovVal);
    System.out.println("Number of valid(has at least one triangle and at least 3 vertices) meshes is "+objects+". ");
  }

  @Override
  public void error(SAXParseException e) {
    //System.out.println(e.getMessage());
  }

  @Override
  public void warning(SAXParseException e) {
    //System.out.println(e.getMessage());
  }

  @Override
  public void fatalError(SAXParseException e) {
    //System.out.println(e.getMessage());
  }
}
