/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.util.LinkedList;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer {
  public void transform (Document xmlDocument) {
    OptimizeMesh(xmlDocument);
    AddLight(xmlDocument,"Ambient Light",0.1d,0,0,0,"black");
  }
  
  private void OptimizeMesh(Document xmlDocument){
    EraseUnusedVertices(xmlDocument);
    EraseInvalidTriangles(xmlDocument);
  }
  
  /**
   * Vymaze nepouzite vrcholy - ty, ktere neobsahuje zadny trojuhelnik.
   * @param xmlDocument 
   */
  private void EraseUnusedVertices(Document xmlDocument) {
    NodeList l =   xmlDocument.getElementsByTagName("triangle");
    LinkedList<String> ids=new LinkedList();
    for (int i = 0; i < l.getLength(); i++) {
      NamedNodeMap att=l.item(i).getAttributes();
      ids.add(att.item(0).getNodeValue());
      ids.add(att.item(1).getNodeValue());
      ids.add(att.item(2).getNodeValue());
    }
    //System.err.println(ids);
    
    NodeList k =xmlDocument.getElementsByTagName("vertex");
    for (int i = 0; i < k.getLength(); i++) {
      String val=k.item(i).getAttributes().item(0).getNodeValue();
      
      if(! ids.contains(val)){
        Node parent=k.item(i).getParentNode();
        parent.removeChild(k.item(i));
        //System.err.println(val);
      }
    }
  } 
  
  /**
   * Vymaze trojuhelniky, ktere maji alespon 2 vrcholy totozne.
   * 
   * @param xmlDocument 
   */
  private void EraseInvalidTriangles(Document xmlDocument){
    NodeList l =   xmlDocument.getElementsByTagName("triangle");
    for (int i = 0; i < l.getLength(); i++) {
       NamedNodeMap att=l.item(i).getAttributes();
       //System.err.println(att.item(0).getNodeValue() +" "+att.item(1)+" "+att.item(2));
       
       if(att.item(0).getNodeValue().equals(att.item(1).getNodeValue()) || 
               att.item(1).getNodeValue().equals(att.item(2).getNodeValue()) || att.item(0).getNodeValue().equals(att.item(2).getNodeValue()))
       {
         Node parent=l.item(i).getParentNode();
         parent.removeChild(l.item(i));
       }
    }
  }
  
  private void AddLight(Document xmlDoc,String name,double intensity,int x,int y,int z,String color){
    NodeList l=xmlDoc.getElementsByTagName("lights");
    Node n=l.item(0);
    
    Element light=xmlDoc.createElement("light");
    
    Element clr=xmlDoc.createElement("clr");
    clr.setAttribute("col", color);
    Element intens=xmlDoc.createElement("intensity");
    intens.setTextContent(intensity+"");
    Element l_name=xmlDoc.createElement("l_name");
    l_name.setTextContent(name);
    Element l_position=xmlDoc.createElement("l_position");
    Element l_x=xmlDoc.createElement("l_x");
    l_x.setAttribute("value", x+"");
    Element l_y=xmlDoc.createElement("l_y");
    l_y.setAttribute("value", y+"");
    Element l_z=xmlDoc.createElement("l_z");
    l_z.setAttribute("value", z+"");
    
    l_position.appendChild(l_x);
    l_position.appendChild(l_y);
    l_position.appendChild(l_z);
    
    
    light.appendChild(l_name);
    light.appendChild(intens);
    light.appendChild(l_position);
    light.appendChild(clr);
    
    n.appendChild(light);
  }
}

