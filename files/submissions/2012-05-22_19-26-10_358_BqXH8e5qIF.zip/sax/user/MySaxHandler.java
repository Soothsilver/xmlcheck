package user;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
/**
 * 
 * @author peter.zvirinsky
 * SaxHandler ktory vypise na standartny vystup:
 *  - pocet elementov v dokumente
 *  - priemerna dlzka nazvu elementu v dokumente
 *  - pocet atributov v dokumente
 *  - priemerna dlzka nazvu atributu v dokumente
 * 
 */
public class MySaxHandler extends DefaultHandler {

//	public static void main(String[] args) {
//
//		String sourcePath = "data.xml";
//		try {
//			XMLReader parser = XMLReaderFactory.createXMLReader();
//			InputSource source = new InputSource(sourcePath);
//			parser.setContentHandler(new MySaxHandler());
//			parser.parse(source);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}

	private int elementLengthAcumulator = 0;
	private int elementCount = 0;
	private int attributeLengthAcumulator = 0;
	private int attributeCount = 0;

	@Override
	public void startDocument() throws SAXException {
		// TODO Auto-generated method stub
		super.startDocument();
	}

	@Override
	public void endDocument() throws SAXException {
		System.out.println("Pocet elementov v dokumente: "+elementCount);
		System.out.println("Priemerna dlzka nazvu elementu v dokumente: "+elementLengthAcumulator/((double)elementCount));
		System.out.println("Pocet atributov v dokumente: "+attributeCount);
		System.out.println("Priemerna dlzka nazvu atributu v dokumente: "+attributeLengthAcumulator/((double)attributeCount));
	}

	@Override
	public void startPrefixMapping(String prefix, String uri) throws SAXException {
		attributeCount += ("xmlns:"+prefix).length(); // zapocitame aj xlmns s prefixom
	}

	@Override
	public void endPrefixMapping(String prefix) throws SAXException {
		
	}

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		elementCount++;
		elementLengthAcumulator += localName.length(); // pocitame bez prefixu
		
		attributeCount += attributes.getLength();
		for (int i = 0; i < attributes.getLength(); ++i) {
			attributeLengthAcumulator += attributes.getLocalName(i).length();
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		
	}

	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		
	}
}
