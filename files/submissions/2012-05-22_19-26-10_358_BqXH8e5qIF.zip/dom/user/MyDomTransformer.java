package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * 
 * @author Peter Zvirinsky DomTransformer, ktory skonvertuje vsetky atributy na
 *         elementov
 */
public class MyDomTransformer {

	private Document xmlDocument;

//	private static final String VSTUPNI_SOUBOR = "data.xml";
//	private static final String VYSTUPNI_SOUBOR = "data.out.xml";
//	public static void main(String[] args) {
//
//		try {
//			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
//			dbf.setValidating(false);
//			DocumentBuilder builder = dbf.newDocumentBuilder();
//			Document doc = builder.parse(VSTUPNI_SOUBOR);
//
//			new MyDomTransformer().transform(doc);
//
//			TransformerFactory tf = TransformerFactory.newInstance();
//			Transformer writer = tf.newTransformer();
//			writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
//			writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}

	public void transform(Document xmlDocument) {
		this.xmlDocument = xmlDocument;
		convertAttributesToElements(xmlDocument);
	}

	private void convertAttributesToElements(Node item) {
		NodeList childNodes = item.getChildNodes();
		if (childNodes != null) {
			for (int i = 0; i < childNodes.getLength(); ++i) {
				convertAttributesToElements(childNodes.item(i));
			}
		}
		
		NamedNodeMap attributes = item.getAttributes();
		if (item.hasAttributes()) {
			for (int i = 0; i < attributes.getLength(); ++i) {
				convertAttributeToElement(item, attributes.item(i));
			}
			removeAttributes(item, attributes);
		}
	}

	private void removeAttributes(Node item, NamedNodeMap attributes) {
		int length = attributes.getLength();
		String[] attributeNames = new String[length];
		// Je potrebne na dvakrat, aby som si to nemazal pod rukami
		for (int i = 0; i < length; ++i) {
			attributeNames[i] = attributes.item(i).getNodeName();
		}
		for (int i = 0; i < length; ++i) {
			((Element) item).removeAttribute(attributeNames[i]);
		}
	}

	private void convertAttributeToElement(Node item, Node attribute) {
		Element element = xmlDocument.createElement(attribute.getNodeName());
		element.appendChild(xmlDocument.createTextNode(attribute.getNodeValue()));
		// strcime element stale na zaciatok
		item.insertBefore(element, item.getFirstChild());
	}
}
