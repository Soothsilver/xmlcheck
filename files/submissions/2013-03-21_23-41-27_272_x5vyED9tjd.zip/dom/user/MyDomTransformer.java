package user;

import org.w3c.dom.Document;

public class MyDomTransformer {

    public void transform(Document xmlDocument) {
        // code transforming xmlDocument object 
        // (method works on the object itself - no return value) 
    }
}
