package user;

import java.io.File;
import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class MyDomTransformer
{
    public void transform(Document xmlDocument)
    { 
        NodeList list = xmlDocument.getElementsByTagName("stage");  // get stage
        Node stagen = list.item(list.getLength()-1);                 // last stage
        //NamedNodeMap nnm =  stage.getAttributes();                  
        stagen.getParentNode().removeChild(stagen);                   // rem last stage
        
        Node root = xmlDocument.getElementsByTagName("checklist").item(0);   // get root
        Element stage = xmlDocument.createElement("stage");                 // new stage
        stage.setAttribute("UID", "stage-3");                               // set attr
        
        Element hold = xmlDocument.createElement("hold");           // a stejným postupem přidat všechno ostatní...
        stage.appendChild(hold);
        
        Element time = xmlDocument.createElement("time");
        time.setAttribute("seconds-to-hold", "8500");
        
        hold.appendChild(time);

        root.appendChild(stage);                                        // add to the end
    }
    /*
    public static void main(String args[]) throws SAXException, IOException, ParserConfigurationException, TransformerConfigurationException, TransformerException
    {
        DocumentBuilderFactory docfac= DocumentBuilderFactory.newInstance();
        DocumentBuilder db = docfac.newDocumentBuilder();
        Document d = db.parse(new File("data.xml"));
        transform(d);
        Source src = new DOMSource(d);
        File out = new File("dataout.xml");
        Result res = new StreamResult(out);
        Transformer tr = TransformerFactory.newInstance().newTransformer();
        tr.transform(src, res);
    }*/
}