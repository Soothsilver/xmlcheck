package user;

import java.io.IOException;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

public class MySaxHandler extends DefaultHandler
{
    boolean count = false;
    int totalTime = 0;  
    int checks = 0;
    int holds = 0;
    boolean launch = false;
    
    boolean locking = false;
    boolean person = false;
    
    @Override
    public void startDocument() throws SAXException
    {
        super.startDocument(); //To change body of generated methods, choose Tools | Templates.
        totalTime = 0;
    }

    @Override
    public void endDocument() throws SAXException
    {
        super.endDocument(); //To change body of generated methods, choose Tools | Templates.
        System.out.println("Total time: " + totalTime);
        System.out.println("Checks: " + checks);
        System.out.println("Holds: " + holds);
        System.out.println("Launch " + (launch ? "achieved" : "not achieved"));
    }

    
    
    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException
    {
        if (localName == "expected-time")
        {
            count = true;
        }
        if (localName == "time")
        {
            totalTime += Integer.parseInt(attributes.getValue("seconds-to-hold"));
        }
        if (localName == "check")
        {
            checks++;
        }
        if (localName == "hold")
        {
            holds++;
        }
        if (localName == "launch")
        {
            launch = true;
        }
        if (localName == "locking")
        {
            if (attributes.getValue("value").equals("true"))
            {
                locking = true;
            }
        }
        if (localName == "person")
        {
            person = true;
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException
    {
        StringBuilder sb = new StringBuilder();
        sb.append(ch, start, length);
        String input = sb.toString();
        
        if (count)
        {
            totalTime += Integer.parseInt(input);
        }
        if (locking && person)  // if locking operation and processing person then print out pid
        {
            System.out.println("Locking person's pid: " + input);
        }
    }
   
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException
    {
        count = false;
        if (localName == "protocol")
        {
            locking = false;
        }
        person = false;
    }

  /*  public static void main(String args[]) throws SAXException, IOException
    {
        XMLReader parser = XMLReaderFactory.createXMLReader();
        InputSource source = new InputSource("data.xml");
        parser.setContentHandler(new MySaxHandler());
        parser.parse(source);
    }*/
}