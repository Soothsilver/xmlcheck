/*
 * Copyright (C) 2014 Martin Indra <martin.indra at mgn.cz>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package user;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 *
 * @author Martin Indra <martin.indra at mgn.cz>
 */
public class MySaxHandler {

// Path to input file
    private static final String INPUT_FILE = "/home/indy/School/git/school/" + "data.xml";

    /**
     * Main method
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        try {
            // Create parser instance
            XMLReader parser = XMLReaderFactory.createXMLReader();

            // Create input stream from source XML document
            InputSource source = new InputSource(INPUT_FILE);

            // Set our custom content handler for handling SAX events (it must implements ContentHandler interface)
            parser.setContentHandler((ContentHandler) new CustomContentHandler());

            // Process input data
            parser.parse(source);
        } catch (IOException ex) {
            Logger.getLogger(MySaxHandler.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SAXException ex) {
            Logger.getLogger(MySaxHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

/**
 * Out custom content handler for managing SAX events Implements methods of the abstract
 * class ContentHandler.
 *
 * @see
 * http://www.saxproject.org/apidoc/org/xml/sax/ContentHandler.html#processingInstruction%28java.lang.String,%20java.lang.String%29
 */
class CustomContentHandler implements ContentHandler {

    // constants
    protected static final String ELEMENT_PHOTOS = "photos";
    protected static final String ELEMENT_PHOTO = "photo";
    protected static final String ELEMENT_NAME = "name";
    protected static final String ELEMENT_PHOTO_ATTR_SIZE = "size";
    protected static final String ELEMENT_PHOTO_ATTR_AUTHOR = "author";
    protected static final String ELEMENT_DESCRIPTION = "description";
    // collected values
    protected int totalSize = 0;
    protected int photosCount = 0;
    protected int photosWithDescriptionWithoutAuthor = 0;
    /**
     * Word occurrence counts
     */
    protected TreeMap<String, Integer> words = new TreeMap<String, Integer>();
    // Helper variable to store location of the handled event
    Locator locator;
    protected ArrayList<Nest> nesting = new ArrayList<Nest>();
    protected String currentText = null;

    /**
     * Nests parse one element deeper.
     *
     * @param name element name
     */
    protected void nest(String name, String uri, Attributes atts) {
        TreeMap<String, String> attributes = new TreeMap<String, String>();

        for (int i = 0; i < atts.getLength(); i++) {
            attributes.put(atts.getLocalName(i), atts.getValue(i));
        }

        nesting.add(new Nest(name, uri, attributes));
    }

    /**
     * Jumps one level back to the root.
     */
    protected void unnest() {
        nesting.remove(nesting.size() - 1);
        currentText = null;
    }

    /**
     * Get ancestor certain number of generations back.
     *
     * @param level number of generations. E.g. 1 is parent
     * @return ancestor's name or null
     */
    protected String getAncestor(int level) {
        Nest ancestor = getAncestorNest(level);
        return ancestor != null ? ancestor.getName() : null;
    }

    protected Nest getAncestorNest(int level) {
        return nesting.size() > level ? nesting.get(nesting.size() - level - 1) : null;
    }

    /**
     * Returns parent of currently the element the parser is currently in.
     */
    protected String getParent() {
        return getAncestor(1);
    }

    /**
     * Returns lastly loaded, not closed element if there is any.
     */
    protected String getCurrent() {
        return getAncestor(0);
    }

    protected void processText() {
        String current = getCurrent();
        String parent = getParent();
        String grandparent = getAncestor(2);

        if (currentText != null && ELEMENT_PHOTOS.equals(grandparent)
                && ELEMENT_PHOTO.equals(parent) && ELEMENT_NAME.equals(current)) {
            String[] wordsOfCurrent = currentText.split(" ");
            for (int i = 0; i < wordsOfCurrent.length; i++) {
                String word = wordsOfCurrent[i].trim().toLowerCase();

                if (word.length() > 0) {
                    int count = words.containsKey(word) ? words.get(word) + 1 : 1;
                    words.put(word, count);
                }
            }
        }
    }

    /**
     * Sets the locator
     *
     * @param Locator locator location in the file
     */
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Method to handle "document start"
     *
     * @throws SAXException
     */
    @Override
    public void startDocument() throws SAXException {
        // ...
    }

    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
        int averageSize = 0;
        if (photosCount > 0) {
            averageSize = totalSize / photosCount;
        }
        int pcv = (photosWithDescriptionWithoutAuthor * 100) / photosCount;

        System.out.println("Average photo size: " + averageSize);

        System.out.println("Words frequency:");
        for (String word : words.keySet()) {
            System.out.println("" + words.get(word) + "x " + word);
        }

        System.out.println("" + pcv + "% of photos have description but haven't author.");
    }

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element is in
     * some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        nest(localName, uri, atts);

        String grandparent = getAncestor(2);
        String parent = getParent();
        String current = getCurrent();

        if (ELEMENT_PHOTOS.equals(parent)) {
            // in the photos element
            if (ELEMENT_PHOTO.equals(current)) {
                photosCount++;

                String size = atts.getValue(uri, ELEMENT_PHOTO_ATTR_SIZE);
                if (size != null) {
                    totalSize += Integer.parseInt(size);
                }
            }
        }

        if (ELEMENT_PHOTOS.equals(grandparent) && ELEMENT_PHOTO.equals(parent)
                && ELEMENT_DESCRIPTION.equals(current)) {
            Nest photoNest = getAncestorNest(1);
            String author = photoNest.getAttributes().get(ELEMENT_PHOTO_ATTR_AUTHOR);
            if (author == null) {
                photosWithDescriptionWithoutAuthor++;
            }
        }
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element is in
     * some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        processText();
        unnest();
    }

    /**
     * Method to handle "character data" SAX parser can process data in various batches.
     * so we can't rely that whole whole text content will be delivered in one call Text
     * is in array 'chars' from position ('start') to ('start' + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        if (currentText == null) {
            currentText = "";
        }

        for (int i = start; i < (start + length); i++) {
            currentText += chars[i];
        }
    }

    /**
     * Method to handle " start of namespace declaration"
     *
     * @param prefix Prefix of the namespace
     * @param uri URI of the namespace
     * @throws SAXException
     */
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    /**
     * Method to handle "end of namespace declaration"
     *
     * @param prefix
     * @throws SAXException
     */
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    /**
     * Method to handle "ignoring of whitespaces" Text is in array 'chars' from position
     * ('start') to ('start' + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     * @throws SAXException
     */
    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
        // ...
    }

    /**
     * Method to handle "processing instructions"
     *
     * @param target The processing instruction target
     * @param data The processing instruction data
     * @throws SAXException
     */
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

    /**
     * Method to handle "unprocessed entity"
     *
     * @param name
     * @throws SAXException
     */
    @Override
    public void skippedEntity(String name) throws SAXException {
        // ...
    }

    private static class Nest {

        protected String name = "";
        protected String uri = "";
        protected TreeMap<String, String> attributes;

        public Nest(String name, String uri, TreeMap<String, String> attributes) {
            this.name = name;
            this.attributes = attributes;
        }

        public String getName() {
            return name;
        }

        public String getUri() {
            return uri;
        }

        public TreeMap<String, String> getAttributes() {
            return attributes;
        }
    }
}
