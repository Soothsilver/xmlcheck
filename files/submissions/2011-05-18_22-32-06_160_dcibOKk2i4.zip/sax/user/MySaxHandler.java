package user;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {

    int actualNumberOfCharacters = 0;
    int maximalNumberOfCharacters = 0;

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if ("postava".equals(localName)) {
            actualNumberOfCharacters++;
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if ("postavy".equals(localName)) {
            if (actualNumberOfCharacters > maximalNumberOfCharacters) {
                maximalNumberOfCharacters = actualNumberOfCharacters;
                actualNumberOfCharacters = 0;
            }
        }
    }

    @Override
    public void endDocument() throws SAXException {
        System.out.println("Maximální počet postav je: " + maximalNumberOfCharacters);
    }
}