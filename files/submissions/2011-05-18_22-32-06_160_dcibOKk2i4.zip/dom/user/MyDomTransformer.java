package user;

import java.util.ArrayList;
import java.util.Iterator;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer {

    public void transform(Document xmlDocument) {
        NodeList characters = xmlDocument.getElementsByTagName("postava");
        ArrayList<Node> nodesToRemove = new ArrayList<Node>();

        for (int i = 0; i < characters.getLength(); i++) {
            Element actualCharacter = (Element) characters.item(i); // Actual character

            for (Node charactersElement = actualCharacter.getFirstChild(); charactersElement != null; charactersElement = charactersElement.getNextSibling()) {

                if ("pohlavi".equals(charactersElement.getNodeName())) {
                    Attr gender = xmlDocument.createAttribute("pohlavi");
                    gender.setValue(charactersElement.getFirstChild().getNodeValue());
                    actualCharacter.setAttributeNode(gender);
                    nodesToRemove.add(charactersElement);
                } else if ("vek".equals(charactersElement.getNodeName())) {
                    Attr age = xmlDocument.createAttribute("vek");
                    age.setValue(charactersElement.getFirstChild().getNodeValue());
                    actualCharacter.setAttributeNode(age);
                    nodesToRemove.add(charactersElement);
                }
            }

            for (Iterator<Node> it = nodesToRemove.iterator(); it.hasNext();) {
                Node node = it.next();

                if (node != null) {
                    actualCharacter.removeChild(node);
                    
                }
            }

            nodesToRemove.clear();
        }
    }
}