import com.sun.org.apache.xerces.internal.dom.ChildNode;
import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

public class MyDomTransformer {

    private static final String INPUT = "data.xml";
    private static final String OUTPUT = "data.out.xml";

    public static void main(String[] args) {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setValidating(false);
            DocumentBuilder builder = dbf.newDocumentBuilder();
            Document doc = builder.parse(INPUT);
            processTree(doc);
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer writer = tf.newTransformer();
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            writer.transform(new DOMSource(doc), new StreamResult(new File(OUTPUT)));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     *  Vymaze elementy "telefon", "fax", "email".
     *  Zmeni atributy na elementy a povedne atributy zmaze.
     */
    private static void processTree(Document doc) throws ParserConfigurationException {
        NodeList list = doc.getElementsByTagName("ulica");
        for ( int i = 0; i < list.getLength(); i++ ) {
            Element element = (Element) list.item(i);
            Node parent = element.getParentNode();
            parent.removeChild(element);
        }
        list = doc.getElementsByTagName("psc");
        for ( int i = 0; i < list.getLength(); i++ ) {
            Element element = (Element) list.item(i);
            Node parent = element.getParentNode();
            parent.removeChild(element);
        }
        list = doc.getElementsByTagName("cislo");
        for ( int i = 0; i < list.getLength(); i++ ) {
            Element element = (Element) list.item(i);
            Node parent = element.getParentNode();
            parent.removeChild(element);
        }
        // Zmeni atributy na elementy a povodne atributy zmaze.
        list = doc.getElementsByTagName("*");
        for (int i= 0; i < list.getLength(); i++) {
            if (list.item(i).hasAttributes()==true) {
                for (int j = 0; j < list.item(i).getAttributes().getLength(); j++) {
                    System.out.println(list.item(i).getAttributes().item(j).getNodeName());
                    Element element = doc.createElement(list.item(i).getAttributes().item(j).getNodeName());
                    element.appendChild(doc.createTextNode(list.item(i).getAttributes().item(j).getNodeValue()));
                    doc.getElementsByTagName("*").item(i).appendChild(element);
                }
            }
        }
        list = doc.getElementsByTagName("*");
        for (int i= 0; i < list.getLength(); i++) {
            if (list.item(i).hasAttributes()==true) {
                for (int j = list.item(i).getAttributes().getLength()-1; j > -1; j--) {
                    doc.getElementsByTagName("*").item(i).getAttributes().removeNamedItem(list.item(i).getAttributes().item(j).getNodeName());
                }
            }
        }
    }
}
