/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class MyDomTransformer {

    public void transform(Document xmlDocument) {
        // Vsem notam v tracku s nazvem Synth pad zvysit delku o 0.5
        NodeList tracks = xmlDocument.getElementsByTagName("track");

        for (int i = tracks.getLength() - 1; i >= 0; --i) {
            Element track = (Element) tracks.item(i);
            // predpokladam, ze xml je validni podle dtd - obsahuje element name
            String trackName = track.getElementsByTagName("name").item(0).getTextContent();
            if ("Synth pad".equals(trackName)) {

                NodeList notes = track.getElementsByTagName("note");

                for (int j = notes.getLength() - 1; j >= 0; --j) {
                    Element note = (Element) notes.item(j);

                    float new_length = (float) (Float.parseFloat(note.getAttribute("length")) + 0.5);

                    note.setAttribute("length", Float.toString(new_length));

                }

            }
        }

        // "Rozbila se klavesa" - smazat ze vsech tracku odkazujicich se na nastroj "GrandPiano" noty vysky F1
        for (int i = tracks.getLength() - 1; i >= 0; --i) {
            Element track = (Element) tracks.item(i);
            // predpokladam, ze xml je validni podle dtd - obsahuje element name
            String instrumentId = ((Element) track.getElementsByTagName("instrument_ref").item(0)).getAttribute("instrument_id");
            if ("GrandPiano".equals(instrumentId)) {

                NodeList notes = track.getElementsByTagName("note");

                if (notes.getLength() > 0) {
                    Element notesParent = (Element) notes.item(0).getParentNode();

                    for (int j = notes.getLength() - 1; j >= 0; --j) {
                        Element note = (Element) notes.item(j);

                        if ("F1".equals(note.getAttribute("tone"))) {
                            notesParent.removeChild(note);
                        }

                    }
                }
            }
        }

        // Pridat na konec zvuk cinelu (do noveho tracku)
        // "importovat" zvuk cinelu
        Element instruments = (Element) xmlDocument.getElementsByTagName("instruments").item(0);

        Element new_instrument = xmlDocument.createElement("instrument");
        new_instrument.setAttribute("id", "DrumKit");
        new_instrument.setAttribute("type", "wave_instrument");

        Element new_recordings = xmlDocument.createElement("recordings");
        new_recordings.setAttribute("base_path", "global/drumkits/1");

        Element new_recording1 = xmlDocument.createElement("recording");
        new_recording1.setAttribute("id", "cymbals");
        new_recording1.setAttribute("file", "badum-tss.wav");

        new_recordings.appendChild(new_recording1);
        new_instrument.appendChild(new_recordings);
        instruments.appendChild(new_instrument);

        // pouzit zvuk cinelu
        Element track_container = (Element) xmlDocument.getElementsByTagName("tracks").item(0);
        
        Element cymbal_track = xmlDocument.createElement("track");
        Element parameters = xmlDocument.createElement("parameters");
        Element name = xmlDocument.createElement("name");
        name.setTextContent("Cymbals");
        Element instrument_ref = xmlDocument.createElement("instrument_ref");
        instrument_ref.setAttribute("instrument_id", "DrumKit");
        Element volume = xmlDocument.createElement("volume");
        volume.setTextContent("50");
        
        Element recording_regions = xmlDocument.createElement("recording_regions");
        Element recording_region = xmlDocument.createElement("recording_region");
        recording_region.setAttribute("recording_ref", "cymbals");
        recording_region.setAttribute("start", "26");
        recording_region.setAttribute("length", "2");
        
        recording_regions.appendChild(recording_region);
        
        parameters.appendChild(name);
        parameters.appendChild(instrument_ref);
        parameters.appendChild(volume);
        cymbal_track.appendChild(parameters);
        
        cymbal_track.appendChild(recording_regions);
        
        track_container.appendChild(cymbal_track);
    }
}
