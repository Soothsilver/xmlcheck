/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {

    // "attributes statistics"
    double totalNoteLength = 0;
    int noteCount = 0;

    float longestNoteLength = -1;
    float longestNoteStart = -1;
    String longestNoteName = "";

    // "character data statistics"
    //String lastElementStarted = "";
    ArrayList trackNames = new ArrayList();

    // "context statistics"
    String loudestTrackName = "";
    float loudestTrackLoudness = 0;
    int longAndLateNoteCount = 0; // pocet not po 10. dobe s delkou alespon 1 v aktualnim tracku
    
    int insideName = 0;
    int insideVolume = 0;
    String lastTrackName = "";
    float lastTrackLoudness = 0;
    int longAndLateNoteCountForLoudestTrack = 0; //pocet not po 10. dobe s delkou alespon 1 v nejhlasitejsim tracku
    
    
    @Override
    public void startDocument()
            throws SAXException {
        // no op
    }

    @Override
    public void endDocument()
            throws SAXException {

        System.out.println("Statistics:");
        if (longestNoteLength == -1) {
            System.out.println("The file does not contain any notes.");
        } else {
            System.out.println("Total note length is " + totalNoteLength
                    + ", average note length is " + totalNoteLength / noteCount + ".");

            System.out.println("The longest note " + longestNoteName
                    + " of length " + longestNoteLength
                    + " starts at time " + longestNoteStart + ".");
        }
        
        Object[] tracks = trackNames.toArray();
        Arrays.sort(tracks);
        
        System.out.println();
        
        System.out.println("There are " + tracks.length + " tracks in the project (names in alphabetical order):");
        for (Object trackName : tracks) {
             System.out.println(" - " + trackName);
        }
        
        System.out.println();
        
        System.out.println("The loudest track is: " + loudestTrackName +
                ". There are " + longAndLateNoteCountForLoudestTrack +
                " notes of length at least 1 after 10th beat in that track.");

    }

    @Override
    public void startElement(String uri, String localName,
            String qName, Attributes attributes)
            throws SAXException {
        //System.out.println(qName);
        //lastElementStarted = localName;

        if ("note".equals(localName)) {
            ++noteCount;
            float noteLength = Float.parseFloat(attributes.getValue("length"));
            float noteStart = Float.parseFloat(attributes.getValue("start"));
            totalNoteLength += noteLength;
            if (noteLength > longestNoteLength) {
                longestNoteLength = noteLength;
                longestNoteName = attributes.getValue("tone");
                longestNoteStart = noteStart;
            }
            
            
            if (noteStart > 10 && noteLength >= 1) {
                ++longAndLateNoteCount;
            }
            
        } else if ("name".equals(localName)) {
            insideName = 1;
        } else if ("volume".equals(localName)) {
            insideVolume = 1;
        } else if ("track".equals(localName)) {
            longAndLateNoteCount = 0;
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName)
            throws SAXException {
        if ("name".equals(localName)) {
            insideName = 0;
        } else if ("volume".equals(localName)) {
            insideVolume = 0;
        } else if ("track".equals(localName)) {
            if (lastTrackLoudness > loudestTrackLoudness) {
                loudestTrackLoudness = lastTrackLoudness;
                loudestTrackName = lastTrackName;
                longAndLateNoteCountForLoudestTrack = longAndLateNoteCount;
            }
        }
    }

    @Override
    public void characters(char ch[], int start, int length)
            throws SAXException {
        String characterData = new String(ch, start, length);
        if (insideName == 1) {
            // characterData is inside <name>...</name>
            trackNames.add(characterData);
            
            lastTrackName = characterData;
            
            //System.out.println(s);
        }
        
        if (insideVolume == 1) {
            lastTrackLoudness = Float.parseFloat(characterData);
        }

    }

    @Override
    public void ignorableWhitespace(char ch[], int start, int length)
            throws SAXException {
        // no op
    }

    @Override
    public void processingInstruction(String target, String data)
            throws SAXException {
        // no op
    }

}
