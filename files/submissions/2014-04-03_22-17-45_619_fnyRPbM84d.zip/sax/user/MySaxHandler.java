package user;

import java.util.HashMap;
import java.util.Map;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/*
 * Otazky: 
 * 	Je vice cestujicich se zavadazli nebo bez?
 * 	Nejcastejsi jmeno, ne prijmeni, cestujiciho? (Bohuzel toho moc v elementech nemam takze znova to beru z atributu)
 * 	Pocet "Davidu" letajicich s Boing 747 se zavazadly?
 * */


public class MySaxHandler extends DefaultHandler {
	
	private int zavazadla;
	
	private Map<String, Integer> jmenoMap;
	
	private int davidPocet;
	
	private boolean inBoing;
	private int maxJmenoPocet;
	
	// overrides of DefaultHandler methods
	
	@Override
	public void startDocument () throws SAXException
	{
		zavazadla = 0;
		jmenoMap = new HashMap<String, Integer>();
		davidPocet = 0;
		inBoing = false;
		maxJmenoPocet = 0;
	}
	
	@Override
	public void startElement (String uri, String localName,
            String qName, Attributes attributes) throws SAXException
	{
		if (localName.equals("letadlo") && attributes.getValue("", "typ").equals("Boing 747"))
			inBoing = true;
		
		if (localName.equals("pasazer"))
		{	
			// Pocitani zavazadel
			String value = attributes.getValue("", "zavazadlo");
			if (value.equals("ANO")) 
				zavazadla++;
			else
				zavazadla--;
			
			// Pocitani nejcastejsiho jmena
			String jmeno = attributes.getValue("", "jmeno").split(" ")[0];
			Integer pocet = jmenoMap.get(jmeno);
			if (pocet == null)
				pocet = 0;
			pocet++;
			jmenoMap.put(jmeno, pocet);
			if (maxJmenoPocet < pocet)
				maxJmenoPocet = pocet;
			
			// Pocet Davidu v Boingu 747 se zavazadli
			if (inBoing && value.equals("ANO"))
			{
				boolean david = jmeno.equals("David");
				if (david)
					davidPocet++;
			}
		}
	}
	
	@Override
	public void endElement (String uri, String localName, String qName) throws SAXException
	{
		if (localName.equals("pridlet"))
			inBoing = false;
    }   
	
	@Override
	public void endDocument () throws SAXException
	{
        // Vypis 1. otazka
		System.out.print("Je vice cestujicich se zavazadli? : ");
        if (zavazadla <= 0)
        	System.out.println("NE");
        else
        	System.out.println("ANO");
        
        // Vypis 2. otazka
        System.out.print("Nejcastejsi jmena jsou: ");
        for (String key : jmenoMap.keySet())
        {
        	if (maxJmenoPocet == jmenoMap.get(key))
        		System.out.print(key + " ");
        }
        System.out.println("");
        
        // Vypis 3. otazka
        System.out.println("Pocet Davidu leticich v Boingu 747 a maji zavazadla: " + davidPocet);
    }
}
