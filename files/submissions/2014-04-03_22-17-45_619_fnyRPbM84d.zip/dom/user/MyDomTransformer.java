package user;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/*
 * Zmeny:
 * 	Pridat pridlet do terminalu 2
 * 	Smazat vsechny pridlety starsi 2 tydny
 * */

public class MyDomTransformer {
	
	
	public void transform (Document xmlDocument) 
	{ 
		// Pridani noveho odletu do terminalu 2
		this.createPridletToSecondTerminal(xmlDocument);
		
		// Smazani vsech letu starsich 14 dnu
		try 
		{
			this.deleteAllPridletsOlder14Days(xmlDocument);
		}
		catch (ParseException e)
		{
			e.printStackTrace();
		}
	}
	
	private void deleteAllPridletsOlder14Days(Document xmlDocument) throws ParseException
	{
		NodeList pridlety = xmlDocument.getElementsByTagName("pridlet");
		
		for (int i = pridlety.getLength()-1; i >= 0; i--)
		{
			Node pridlet = pridlety.item(i);
			String datum = pridlet.getAttributes().getNamedItem("datum").getTextContent();
			Date date = new SimpleDateFormat("dd.MM.yyyy").parse(datum);
			Date now = new Date();
			
			if (now.getTime() - date.getTime() > 1206000000)
				pridlet.getParentNode().removeChild(pridlet);
		}
	}
	
	private void createPridletToSecondTerminal(Document xmlDocument)
	{
		NodeList pridletyList = xmlDocument.getElementsByTagName("pridlety");
		
		int i = 0;
		while (i< pridletyList.getLength() && !pridletyList.item(i).getParentNode().getAttributes().getNamedItem("cislo").getTextContent().equals("_2"))
			i++;
		
		Node pridlety = pridletyList.item(i);
		
		Element newPridlet = xmlDocument.createElement("pridlet");
		newPridlet.setAttribute("cas", "13:42:00");
		newPridlet.setAttribute("cisloLetu", "IOS7354");
		newPridlet.setAttribute("datum", "3.4.2014");
		newPridlet.setAttribute("destinace", "Olomouc");
		newPridlet.setAttribute("prilet", "NE");
		newPridlet.setAttribute("spozdeni", "0");
		newPridlet.setAttribute("terminal", "_2");
		
		pridlety.appendChild(newPridlet);
		
		Element newLetadlo = xmlDocument.createElement("letadlo");
		newLetadlo.setAttribute("cislo", "BAR7611");
		newLetadlo.setAttribute("kodPosadky", "63725");
		newLetadlo.setAttribute("typ", "Boing 747");
		
		newPridlet.appendChild(newLetadlo);
		
		Element newPasazeri = xmlDocument.createElement("pasazeri");
		
		String[] pJmena = new String[]{"Pavel Lukas", "David Jirasek", "Nikol Hornikova", "Anicka Rychnovska", "Pavlina Sedmikova", "Nina Fantomova"};
		String[] pZavazadlo = new String[]{"ANO", "NE", "NE", "NE", "ANO", "ANO"};
		
		for (int j = 0; j < pJmena.length; j++)
		{
			Element newPasazer = xmlDocument.createElement("pasazer");
			newPasazer.setAttribute("jmeno", pJmena[j]);
			newPasazer.setAttribute("zavazadlo", pZavazadlo[j]);
			newPasazeri.appendChild(newPasazer);
		}
		
		newPridlet.appendChild(newPasazeri);
	}
}
