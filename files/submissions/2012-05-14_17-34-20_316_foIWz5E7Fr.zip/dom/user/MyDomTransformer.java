/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

//Test class
/**
 * Update the new payment for advertisements by ID of the payment
 * Add the new article
 * @author Ekaterina Znatkova
 * @version 14.05.2012
 */
public class MyDomTransformer {

    public void transform(Document xmlDocument) {

        String id = "521111";
        Element root = xmlDocument.getDocumentElement();
        NodeList payments = root.getElementsByTagName("payment");
        for (int i = 0; i < payments.getLength(); i++) {
            Element t = (Element) payments.item(i);
            updatePayment("21", "august", "2013", "45000", id, t, xmlDocument);

        }
        String test = "Some new article";
        String authorId = "A2";
        addNewArticle(test, authorId, xmlDocument, "15", "may", "2012", "sport", "Europe");
    }

    private void addNewArticle(String test, String authorID, Document doc, String day, String month, String year,
            String subject, String region) {
        Element author = findElement(authorID, doc);
        Element root = doc.getDocumentElement();
        Element advs = (Element) root.getElementsByTagName("articles").item(0);

        Element content = doc.createElement("content");
        Element article = doc.createElement("article");

        
       
        Element newDate = doc.createElement("date");
        newDate.setAttribute("day", day);
        newDate.setAttribute("month", month);
        newDate.setAttribute("year", year);
        
        //Create new category
        Element category=doc.createElement("category");
        category.setAttribute("subject", subject);
        category.setAttribute("region", region);



        content.setTextContent(test);
        article.appendChild(content);
        article.appendChild(author);
        article.appendChild(newDate);
        article.appendChild(category);
        advs.appendChild(article);

    }

    //Will change the attributes and elements
    private void updatePayment(String day, String month, String year, String newAmount, String id, Element payment, Document doc) {
        Element idItem = (Element) payment.getElementsByTagName("id").item(0);
        if (idItem.getTextContent().equals(id)) {

            Element newDate = doc.createElement("date");
            Element newPayment = doc.createElement("payment");
            Element newAmountElement = doc.createElement("howMuch");
            Element newID = doc.createElement("id");


            newDate.setAttribute("day", day);
            newDate.setAttribute("month", month);
            newDate.setAttribute("year", year);
            newAmountElement.setTextContent(newAmount);

            newID.setTextContent(id);


            newPayment.appendChild(newID);
            newPayment.appendChild(newDate);
            newPayment.appendChild(newAmountElement);

            Element adv = (Element) payment.getParentNode();
            adv.replaceChild(newPayment, payment);

        } else {
            return;
        }


    }

    //Only for my own test   
    public void run() {
        String filename = "data.xml";
        String outfile = "data22.xml";
        try {

            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            dbf.setValidating(false);

            DocumentBuilder builder = dbf.newDocumentBuilder();

            Document doc = builder.parse(filename);
            //Parsing the document
            transform(doc);

            TransformerFactory tf = TransformerFactory.newInstance();

            Transformer writer = tf.newTransformer();

            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            writer.transform(new DOMSource(doc), new StreamResult(new File(outfile)));


        } catch (Exception e) {

            e.printStackTrace();

        }
    }
    //Find the author by his ID
    private Element findElement(String authorID, Document doc) {
        Element root = doc.getDocumentElement();
        Element listauthors = (Element) root.getElementsByTagName("listauthors").item(0);
        NodeList authors = listauthors.getElementsByTagName("author");
        for (int i = 0; i < authors.getLength(); i++) {
            Element author = (Element) authors.item(i);
            if (author.getAttribute("widref").equals(authorID)) {
                return author;
            }
        }


        return null;
    }
}

class Start {

    public static void main(String[] args) {
        MyDomTransformer tr = new MyDomTransformer();
        tr.run();
    }
}