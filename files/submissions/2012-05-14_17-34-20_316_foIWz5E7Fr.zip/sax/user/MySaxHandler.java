
package user;

import java.util.HashMap;
import java.util.Map;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;


/**
 * The MySaxHandler will find the amount of the different elements,
 * the longest attribute, the list of all different e-mails, the amount of elements with text
 * @author Ekaterina Znatkova
 * @version 08.05.2012
 */
public class MySaxHandler extends DefaultHandler {

    private int amountElement;
    private int amountWithText;
    private int maxLengthAttName;
    private String email = "email";
    private String attribute="";
    private Map<String,String> emails=new HashMap();
    private boolean isEmail=false;
    private Map<String,String> elements=new HashMap();
    
    //Will find the valid text inside of elements
    //After will find exactly emails and put them into the hashmap
    @Override
    public void characters(char[] chars, int i, int i1) throws SAXException {
        
        
        String str = "";
        for (int j = i; j < i + i1; j++) {
            str += chars[j];
        }

        str.replaceAll(" ", str);
        str.replaceAll("\r", str);
        str.replaceAll("\n", str);
        boolean valid = false;
        for (int j = 0; j < str.length(); j++) {
            if (str.charAt(j) >= 'a' && str.charAt(j) <= 'z') {
                valid = true;
                break;
            }
        }
        
        

        if (valid) {
          if (isEmail){ 
            String result=emails.get(str);
            if (result==null){
                emails.put(str, str);
            }
          }
           amountWithText++; 
        }
    }
   //Writes the result
    @Override
    public void endDocument() throws SAXException {
        System.out.println("Emails: " + emails.size());
        System.out.println("emails: ");
        for (String i:emails.values()) {
            System.out.println(i);
        }
        System.out.println("Different elements: "+ amountElement);
        System.out.println("Elements: ");
        for (String i:elements.values()){
            System.out.print(i+" ");
        }
        System.out.println("");
        System.out.println("The max length of the attributes is " + maxLengthAttName+ " "+ attribute);
         System.out.println("Elements with text " + amountWithText);
    }

    @Override
    public void endElement(String string, String string1, String string2) throws SAXException {

        String result=elements.get(string2);
        if (result==null){
            amountElement++;
            elements.put(string2,string2);
        }

    }

   

    @Override
    public void startDocument() throws SAXException {
        System.out.println("Starting parsing a document");
    }

    @Override
    public void startElement(String string, String string1, String string2, Attributes atrbts) throws SAXException {
        //Skip the first element because of the XML attribute inside

        if (string2.equals("magazine")) return;
        if (string2.equals(email)) isEmail=true;
        else isEmail=false;
        //Result is Wernerova street
        for (int i = 0; i < atrbts.getLength(); i++) {
            String value=atrbts.getValue(i);
            if (maxLengthAttName<value.length()){
                maxLengthAttName=value.length();
                attribute=value;
            }
        }
    }

}
class Test {

    public static void main(String[] args) {
        // TODO code application logic here


        String filename = "data.xml";

        try {
            SAXParserFactory spfactory = SAXParserFactory.newInstance();
            spfactory.setValidating(false);

            SAXParser saxparser = spfactory.newSAXParser();

            XMLReader xmlreader = saxparser.getXMLReader();

            xmlreader.setContentHandler(new MySaxHandler());
            xmlreader.setErrorHandler(new MySaxHandler());

            InputSource source = new InputSource(filename);
            xmlreader.parse(source);

        } catch (Exception e) {
            //do nothing
        }
    }
}
