package user;

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import java.util.*;

public class MySaxHandler extends DefaultHandler {

    List years = new ArrayList();
    TreeMap<String, Integer> counter = new TreeMap<String, Integer>();
    boolean inAlbumYear = false;
    StringBuffer albumYear;
    int artistNoDsc = 0;
    boolean searchForDescription = false;

    /**
     * Pomocny komparator pro razeni poctu vyskytu danych zanru na vystup
     */
    static <K, V extends Comparable<? super V>> SortedSet<Map.Entry<K, V>> entriesSortedByValues(Map<K, V> map) {
        SortedSet<Map.Entry<K, V>> sortedEntries = new TreeSet<Map.Entry<K, V>>(
                new Comparator<Map.Entry<K, V>>() {
            public int compare(Map.Entry<K, V> e1, Map.Entry<K, V> e2) {
                int res = e2.getValue().compareTo(e1.getValue());
                return res != 0 ? res : 1; // Special fix to preserve items with equal values
            }
        });
        sortedEntries.addAll(map.entrySet());
        return sortedEntries;
    }

    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
        System.out.println("Nejcastejsi zanry:");
        for (Map.Entry<String, Integer> entry : entriesSortedByValues(counter)) {
            System.out.println(entry.getKey());
        }

        int sum = 0, count = 0;
        for (int i = 0; i < years.size(); i++) {
            sum = sum + Integer.parseInt(years.get(i).toString());
            count++;
        }
        System.out.println("Prumerny rok alba: " + sum / count);

        System.out.println("Pocet interpretu bez vyplnene description: " + artistNoDsc);
    }

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if (qName == "album-year") {
            inAlbumYear = true;
            albumYear = new StringBuffer();
        } else if (qName == "artist") {
            searchForDescription = true;
        } else if (qName == "artist-description") {
            if (searchForDescription) {
                searchForDescription = false;
            }
        } else if (qName == "artist") {
            for (int i = 0; i < atts.getLength(); i++) {
                if (atts.getQName(i) == "artist-genre") {
                    String[] genres = atts.getValue(i).split("\\s");
                    for (int j = 0, l = genres.length; i <= l; ++i) {
                        Integer currValue = counter.get(genres[j]);
                        if (currValue == null) {
                            counter.put(genres[j], 1);
                        } else {
                            counter.put(genres[j], currValue + 1);
                        }
                    }
                }
            }
        }
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (qName == "album-year") {
            inAlbumYear = false;
            years.add(albumYear.toString());
        } else if (qName == "artist" && searchForDescription) {
            artistNoDsc++;
            searchForDescription = false;
        }
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        if (inAlbumYear) {
            albumYear.append(chars, start, length);
        }
    }
}
