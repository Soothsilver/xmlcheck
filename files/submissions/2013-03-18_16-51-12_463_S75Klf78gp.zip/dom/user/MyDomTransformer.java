package user;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Document;

public class MyDomTransformer {

    public void transform(Document xmlDocument) {
            // add Alvin Lee to artists
            Node artists = xmlDocument.getElementsByTagName("artists").item(0);

            Element artist = xmlDocument.createElement("artist");
            Element artistName = xmlDocument.createElement("artist-name");
            artistName.appendChild(xmlDocument.createTextNode("Alvin Lee"));
            Element artistBorn = xmlDocument.createElement("artist-born");
            artistBorn.appendChild(xmlDocument.createTextNode("1944"));
            artist.appendChild(artistName);
            artist.appendChild(artistBorn);
            artist.setAttribute("artist-id", "a-12");
            artists.appendChild(artist);

            //remove album-new tag
            Node albums = xmlDocument.getElementsByTagName("albums").item(0);
            NodeList list = albums.getChildNodes();
            for (int i = 0; i < list.getLength(); i++) {
                Node node = list.item(i);

                NodeList albumList = node.getChildNodes();
                for (int j = 0; j < albumList.getLength(); j++) {
                    Node nodeInner = albumList.item(j);
                    if ("album-new".equals(nodeInner.getNodeName())) {
                        node.removeChild(nodeInner);
                    }
                }
            }
    }
}