/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
/**
 *
 * @author Vavat
 */
public class MyDomTransformer {
    public void transform (Document xmlDocument) {
        // Najdu vsechny elementy Cas
        NodeList casy = xmlDocument.getElementsByTagName("Cas");
        // Jednotlive porjdu vsechny elementy Cas
        for (int i = 0; i < casy.getLength(); i++) {
            // Najdu vsechny potomky elementu Cas
            NodeList cas = casy.item(i).getChildNodes();
            // Ulozim si cas tak jak ho chci mit
            String time = cas.item(1).getTextContent()+":"+cas.item(3).getTextContent()+":"+cas.item(5).getTextContent();
            //Smazu vsechny potomky elementu Cas
            casy.item(i).removeChild(cas.item(1));
            casy.item(i).removeChild(cas.item(2));
            casy.item(i).removeChild(cas.item(3));
            // ulozim svoji verzi casu do elementu Cas jako text;
            casy.item(i).setTextContent(time);            
        }
    } 
}
