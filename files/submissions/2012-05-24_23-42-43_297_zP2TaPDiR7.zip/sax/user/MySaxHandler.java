/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;
import java.util.HashMap;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
/**
 *
 * @author Vavat
 */
public class MySaxHandler extends DefaultHandler {
    Locator locator;
    int pocetSifZprav = 0; // pocet sifrovanych zprav
    int pocetElem = 0;     // pocet elementu v xml                
    int level;             // pomaha pocitat v jakem jsem hloubce 
    int max;               // ulozim nejvetsi hloubku 
    HashMap<Integer, Integer> hloubky; //ukladam pocet kolikrat se vyskytuje dana hloubka
    
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }
    
    @Override
    public void endDocument() throws SAXException {
        int a = 0;
        int b = 0;
        int res = 0;
        for (int i = 1; i <= hloubky.size(); i++) {
            b = b + (int)hloubky.get(i);
            a = a + ((int)hloubky.get(i) * i);            
        }
        res = a/b;
        System.out.println("Pocet zprav s sifrovanim: "+pocetSifZprav);
        System.out.println("Pocet elementu: "+pocetElem);
        System.out.println("Max. hloubka: "+max);
        System.out.println("Prumerna hloubka: "+res);
        System.out.println("End...");
    }

    
    @Override
    public void startDocument() throws SAXException {
        System.out.println("Starting...");
        level = 0;
        max = 0;
        hloubky = new HashMap<Integer, Integer>();
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        pocetElem++;
        level++;
        if(hloubky.containsKey(level)){
            int a = (int) hloubky.get(level);
            a++;
            hloubky.remove(level);
            hloubky.put(level, a);            
        } else {
            hloubky.put(level, 1);
        }
        if (localName.equals("Zprava")) {
           String n = atts.getValue("", "sifrovani");
           if(n.equals("true")){
               pocetSifZprav++;
           }
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if(level > max){
            max = level;
        }
        level--;
    }
        
}
