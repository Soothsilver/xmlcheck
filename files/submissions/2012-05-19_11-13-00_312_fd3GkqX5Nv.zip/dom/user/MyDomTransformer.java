package dom.user;

import java.util.ArrayList;
import java.util.List;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer {
    
    private NodeList studentList,teacherList;
    
    public void transform(Document xmlDocument) {
        NodeList refList=xmlDocument.getElementsByTagName("personRef");        
        
        List<Element> newElements=new ArrayList<Element>();
        List<Element> removeElements=new ArrayList<Element>();
        List<Element> parents=new ArrayList<Element>();
        
        for (int i=0;i<refList.getLength();i++) {
            Element element=(Element)refList.item(i);                        
            Element newElement=xmlDocument.createElement("person");
            newElement.setTextContent(getNameOf(xmlDocument,element));
            
            removeElements.add(element);
            newElements.add(newElement);
            parents.add((Element)element.getParentNode());
        }
        
        for (int i=0;i<newElements.size();i++) {
            parents.get(i).replaceChild(newElements.get(i),removeElements.get(i));
        }
        
    }

    private String getNameOf(Document document,Element element) {
        String id=element.getAttribute("refid");
        
        if (studentList==null) {
            studentList=document.getElementsByTagName("student");
            teacherList=document.getElementsByTagName("teacher");        
        }
        
        Element found=lookup(studentList, id);
        if (found==null)
            found=lookup(teacherList, id);
            
        if (found!=null) {
            String firstName=found.getElementsByTagName("name").item(0).getTextContent();
            String surname=found.getElementsByTagName("surname").item(0).getTextContent();

            return firstName+" "+surname;
        } else return null;
    }
    
    private Element lookup(NodeList list,String id) {
        for (int i=0;i<list.getLength();i++) {
            Element el=(Element)list.item(i);
            if (el.getAttribute("id").equals(id)) 
                return el;            
        }
        return null;
    }
            
}
