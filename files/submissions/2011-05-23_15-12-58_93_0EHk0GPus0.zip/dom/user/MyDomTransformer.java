package user;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;


public class MyDomTransformer {
	private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "dataout.xml";

    public static void main(String[] args) {
        
        try {
            
            //DocumentBuilderFactory vytv��� DOM parsery
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            //nebudeme validovat
            dbf.setValidating(false);

            //vytvo��me si DOM parser
            DocumentBuilder builder = dbf.newDocumentBuilder();

            //parser zpracuje vstupn� soubor a vytvo�� z n�j strom DOM objekt�
            Document doc = builder.parse(VSTUPNI_SOUBOR);

            //zpracujeme DOM strom
            new MyDomTransformer().transform(doc);

            //TransformerFactory vytv��� serializ�tory DOM strom�
            TransformerFactory tf = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer = tf.newTransformer();

            //nastav�me kodov�n�
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spust�me transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


        } catch (Exception e) {
            
            e.printStackTrace();
            
        }
     
    }
    public void transform (Document xmlDocument) {
		NodeList vypozicky=xmlDocument.getElementsByTagName("vypozicka");
		NodeList citatelia=xmlDocument.getElementsByTagName("citatel");
		for(int i=0;i<vypozicky.getLength();i++)
		{
			
			
			Node v=vypozicky.item(i);
			Element kniha=(Element) v.getParentNode().getParentNode();
				
			Element meno_knihy=(Element) kniha.getElementsByTagName("nazov").item(0);
			String nazov=meno_knihy.getTextContent();
			
			Element e=(Element)v; 
			String id=e.getAttribute("citatel");
			for(int j=0;j<vypozicky.getLength();j++)
			{
				Node c=citatelia.item(j);
				Element e1=(Element)c; 
				String cislo=e1.getAttribute("cislo");
				if(cislo.equals(id))
				{
					Element meno=(Element)(e1.getElementsByTagName("meno").item(0));
					String m=meno.getTextContent();
					Node n=xmlDocument.createElement("meno_citatela");
					n.setTextContent(m);
					e.appendChild(n);
					
					Node n1=xmlDocument.createElement("vypozicana_kniha");
					n1.setTextContent(nazov);
				
					meno.getParentNode().appendChild(n1);
					break;
				}
			}
		}
	}
}











