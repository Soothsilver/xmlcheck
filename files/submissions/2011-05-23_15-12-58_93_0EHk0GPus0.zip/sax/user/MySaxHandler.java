package user;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

import org.xml.sax.helpers.DefaultHandler;

import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;

public class MySaxHandler extends DefaultHandler {
	int pocet_pokut=0;
	boolean pokuta=false;
	String tmp=null;
	int suma=0;
	boolean jazyk=false;
	HashMap<String,Integer> jaz=new HashMap<String,Integer>();
	public static void main(String[] argv)
	{
		
        // Cesta ke zdrojov�mu XML dokumentu  
        String sourcePath = "data.xml";

        try {
            
            // Vytvor�me instanci parseru.
            XMLReader parser = XMLReaderFactory.createXMLReader();
            
            // Vytvor�me vstupn� proud XML dat.
            InputSource source = new InputSource(sourcePath);
            
            // Nastav�me n� vlastn� content handler pro obsluhu SAX ud�lost�.
            parser.setContentHandler(new MySaxHandler());
            
            // Zpracujeme vstupn� proud XML dat.
            parser.parse(source);
            
        } catch (Exception e) {
        
            e.printStackTrace();
            
        }
		
	}


    
    public void startDocument() throws SAXException {
        // ...
    }

    
    public void endDocument() throws SAXException {
    	System.out.println("zisk z pokut "+suma);
    	System.out.println("pocet pokut "+pocet_pokut);
    	double priemer=0;
    	if(pocet_pokut>0)
    		priemer=(double)suma/pocet_pokut;
    	priemer=Math.round(priemer);
    	System.out.println("priemerna pokuta "+priemer);
    	System.out.println("Histogram knih");
    	Set<Entry<String,Integer>> set=jaz.entrySet();
  
    	for (Entry<String, Integer>p:set) {
    	    String key = p.getKey();
    	    int value = p.getValue();
    	    System.out.println(key+":"+value);
    	}
    	
    	System.out.println("----");
    }

    
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if(qName.equals("pokuta"))
        {
        	pocet_pokut++;
        	pokuta=true;
        }
        if(qName.equals("jazyk"))
        {
        	jazyk=true;
        }
    }
    
    public void endElement(String uri, String localName, String qName) throws SAXException {
    	 if(qName.equals("pokuta"))
         {
    		int a=0;
    		a=Integer.parseInt(tmp);
    		suma+=a;
         	tmp=null;
         	pokuta=false;
         }
    	 if(qName.equals("jazyk"))
         {
    		 if(jaz.containsKey(tmp))
    			 jaz.put(tmp, jaz.get(tmp)+1);
    		 else
    		 jaz.put(tmp, 1);
    		tmp=null;
         	jazyk=false;
         }
    }

    
    public void characters(char[] ch, int start, int length) throws SAXException {
    	if(pokuta || jazyk)
    	{
    		if(tmp==null)
    		tmp=new String(ch,start,length);
    		else
    			tmp=tmp+new String(ch,start,length);
    	}
    }

    
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
    }

    
    public void endPrefixMapping(String prefix) throws SAXException {
    }

    
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
    }

    
    public void processingInstruction(String target, String data) throws SAXException {
    }

    
    public void skippedEntity(String name) throws SAXException {
    }
}
