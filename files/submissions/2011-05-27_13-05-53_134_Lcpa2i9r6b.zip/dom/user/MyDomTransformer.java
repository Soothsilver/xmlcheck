package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer
{
	
	/**
	 * Zjednodussi strukturu u battle
	 * prevede data u enemy-ship na atributy
	 * stejne tak data u date
	 * @param doc
	 */
	public void transform(Document doc)
	{
		Element battles = (Element)doc.getElementsByTagName("battles").item(0); //vime ze battles je jen jednou
		
		NodeList battle_list = battles.getElementsByTagName("battle");
		
		for ( int i=0; i < battle_list.getLength(); ++i )
		{
			Element battle = (Element)battle_list.item(i);
			//battle je friendlies/enemies/date
			//Element enemies = b
			
			Element date = (Element)battle.getElementsByTagName("date").item(0);	
			
			//pretransformujeme date na empty s atributy
			while ( date.hasChildNodes() )
			{						
				Node child = date.getFirstChild();
				if ( child.getNodeType() == Node.ELEMENT_NODE )
				{
					//element, pretransformujeme do atributu
					String name =  child.getNodeName();
					String value = child.getTextContent();
					System.out.println("Name : " + name + "; value : " + value );
					date.setAttribute(name, value);
				}
				date.removeChild( child );
			}
			
			NodeList enemy_ships = battle.getElementsByTagName("enemy-ship");
			for ( int j = 0; j < enemy_ships.getLength(); ++j)
			{
				Element enemy_ship = (Element)enemy_ships.item(j);
				
				while ( enemy_ship.hasChildNodes() )
				{						
					Node child = enemy_ship.getFirstChild();
					
					if ( child.getNodeType() == Node.ELEMENT_NODE )
					{
						String name =  child.getNodeName();
						String value;
						if ( name.equals("status"))
						{
							value = ((Element)child).getAttribute("value");
						}
						else
						{
							value = child.getTextContent();
						}
						System.out.println("Name : " + name + "; value : " + value );
						enemy_ship.setAttribute(name, value);
					}						
					
					enemy_ship.removeChild( child );
				}
			}
			
		}
		
	}
}
