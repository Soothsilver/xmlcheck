/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package user;

import java.io.File;
import java.io.FileWriter;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;
import org.xml.sax.SAXException;
/**
 *
 * @author Tanika
 */
public class MyDomTransformer {

    /**
     * @param args the command line arguments
     */
    
    private static final String INPUT_FILE = "dom/user/data.xml";
    private static final String OUTPUT_FILE1 = "dom/user/data_out1.xml";
    private static final String OUTPUT_FILE2 = "dom/user/data_out2.xml";
    private static final String OUTPUT_FILE3 = "dom/user/data_out3.xml";
    private static final String OUTPUT_FILE4 = "dom/user/data_out4.xml";


    //kopie souboru data.xml
    static Document doc1;
    static Document doc2;
    static Document doc3;
    static Document doc4;
    
    public static void displayDocument(String uri) 
    {
        try
        {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = null;
            try
            {
                db = dbf.newDocumentBuilder();
            }
            catch (ParserConfigurationException pce) {}
            
            //doc1 = db.parse(uri);
            //display(doc1,"");
            
            doc1= db.parse(uri);
             //zpracujeme DOM strom
            processTree(doc1);
            
            //document1 = db.parse(uri);
            
            //TransformerFactory vytvĂˇĹ™Ă­ serializĂˇtory DOM stromĹŻ
            TransformerFactory tf1 = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer1 = tf1.newTransformer();
            
            //nastavĂ­me kodovĂˇnĂ­
            writer1.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spustĂ­me transformaci DOM stromu do XML dokumentu
            writer1.transform(new DOMSource (doc1), new StreamResult(new File(OUTPUT_FILE1)));
            
            doc2 = db.parse(uri);
            prosessTree2(doc2);
            Transformer writer2 = tf1.newTransformer();
            writer2.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spustĂ­me transformaci DOM stromu do XML dokumentu
            writer2.transform(new DOMSource (doc2), new StreamResult(new File(OUTPUT_FILE2)));
            
            
            doc3 = db.parse(uri);
            prosessTree3(doc3);
            Transformer writer3 = tf1.newTransformer();
            writer3.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spustĂ­me transformaci DOM stromu do XML dokumentu
            writer3.transform(new DOMSource (doc3), new StreamResult(new File(OUTPUT_FILE3)));
            
            
            doc4 = db.parse(uri);
            prosessTree4(doc4);
            Transformer writer4 = tf1.newTransformer();
            writer4.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spustĂ­me transformaci DOM stromu do XML dokumentu
            writer4.transform(new DOMSource (doc4), new StreamResult(new File(OUTPUT_FILE4)));
            
           
        }         
        catch (Exception e)
        {
            e.printStackTrace(System.err);
        }
    
    }
    public static void main(String[] args) {
        // TODO code application logic here

    displayDocument(INPUT_FILE);
    try {

            // DocumentBuilderFactory creates DOM parsers
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            // We don't want to validate file
            dbf.setValidating(false);      

        } catch (Exception e) {

            e.printStackTrace();

        }
    }

    /**
     * Process document tree
     *
     * @param doc Document to be parsed
     */
//    private static void processTree(Document doc) {
//        //put your code here
//        processTree1(doc);
//        
//    }

    
    //modifikace, z attribute title vyrobime element title 
    private static void processTree(Document doc)
    {
        NodeList listSpeaker = doc.getElementsByTagName("speaker");
        for (int i=0; i<listSpeaker.getLength();i++)
        {
            Element speaker = (Element)listSpeaker.item(i);
            Attr attribute = speaker.getAttributeNode("title");
            Element titleEl = doc.createElement("title");
            titleEl.setTextContent(attribute.getTextContent());
            //System.out.println(dateEl.getTextContent());
            Node nodeSpeaker = null;
            if (listSpeaker.getLength() > 0)
            {
                nodeSpeaker = listSpeaker.item(i);
            }
            if (nodeSpeaker.hasChildNodes())
            {
                Node first = nodeSpeaker.getFirstChild().getNextSibling();
                Node second = first.getNextSibling().getNextSibling();
                nodeSpeaker.insertBefore(titleEl, second);               
            }
            else
            {
                nodeSpeaker.appendChild(titleEl);
            }
            speaker.removeAttributeNode(attribute);
        }
    }
    
    //snizime fee o 15% pro studenty, kteri zaplatili v cas
    private static void prosessTree2(Document doc2)
    {
        NodeList listParticipant = doc2.getElementsByTagName("participant");
        NodeList listFee = doc2.getElementsByTagName("fee");
        for (int i = 0; i < listParticipant.getLength(); i++)
        {
            Element participant = (Element)listParticipant.item(i);
            Node nodeType = participant.getAttributeNode("type");
            Element feeEl = (Element)listFee.item(i);
            Node nodePayment = feeEl.getAttributeNode("payment");
            
            if ((nodeType != null) && (nodeType.getNodeValue().equalsIgnoreCase("student")))
            {
                if (nodePayment.getNodeValue().equalsIgnoreCase("in_time"))
                {
                    int fee = new Integer(feeEl.getTextContent());
                    Double newFee = new Double(fee - ((fee*15)/100));
                    feeEl.setTextContent(newFee.toString());
                }
            }
        }        
    }
    
    
    //pridani noveho participanta do conference s id_conference="CID2014"
    private static void prosessTree3(Document doc) {
    
        Element participant = doc.createElement("participant");
        participant.setAttribute("id_participant", "PID245");
        participant.setAttribute("type", "student");
        participant.setAttribute("pay", "yes");
        
        Element speaker = doc.createElement("speaker");
        speaker.setAttribute("title", "Magistr");
        Element speaker_name = doc.createElement("speaker_name");
        speaker_name.appendChild(doc.createElement("first_name")).setTextContent("John");
        speaker_name.appendChild(doc.createElement("surname")).setTextContent("Black");
        speaker.appendChild(speaker_name);
        participant.appendChild(speaker);
        
        participant.appendChild(doc.createElement("department")).setTextContent("University in Vien, Faculty of Mathematics and Physics, Department of Macromolecular Physics");
        
        Element address = doc.createElement("address");
        address.appendChild(doc.createElement("street")).setTextContent("Strasse 45");
        address.appendChild(doc.createElement("post_code")).setTextContent("234156");
        address.appendChild(doc.createElement("city")).setTextContent("Vien");
        address.appendChild(doc.createElement("country")).setTextContent("Austria");
        participant.appendChild(address);
        participant.appendChild(doc.createElement("email")).setTextContent("black@uni.eu");
        participant.appendChild(doc.createElement("phone")).setTextContent("410324345901");
        participant.appendChild(doc.createElement("fax")).setTextContent("410324345902");
        Element presentation_title = doc.createElement("presentation_title");
        presentation_title.setAttribute("idRef", "TID143");
        participant.appendChild(presentation_title).setTextContent("Engineering with atmospheric-pressure plasmas.");
        Element registration = doc.createElement("registration");
        registration.appendChild(doc.createElement("reg_date")).setTextContent("15.09.2014");
        registration.appendChild(doc.createElement("reg_time")).setTextContent("08:45");
        Element fee = doc.createElement("fee");
        fee.setAttribute("payment", "in_time");
        registration.appendChild(fee).setTextContent("&student_price;");
        participant.appendChild(registration);
        Element co_authors = doc.createElement("co_authors");
        co_authors.appendChild(doc.createElement("author_name")).setTextContent("O. White");
        co_authors.appendChild(doc.createElement("author_name")).setTextContent("F. Green");
        participant.appendChild(co_authors);
        
        NodeList listParticipants = doc.getElementsByTagName("participants");
        NodeList listConfrence = doc.getElementsByTagName("conference");
        boolean ok = false;
        for (int i = listParticipants.getLength() - 1; i >= 0; --i)
        {
            //id_conference="CID2014"
            Element conference = (Element)listConfrence.item(i);
            Attr attr = conference.getAttributeNode("id_conference");
            if (attr.getValue().equals("CID2014"))
            {
                ok = true;
                listParticipants.item(i).appendChild(participant); 
            }
        }
        if (!ok)
        {
            System.out.println("Neexistuje konference s danym ID!");
        }
    }

    //smazani vsech participantu, kteri maji pocet co_authoru mensi nez 4
    private static void prosessTree4(Document doc) {
         NodeList listParticipant = doc.getElementsByTagName("participant");
         NodeList listCoAuthor = doc.getElementsByTagName("co_authors");
         for (int i = listParticipant.getLength() - 1; i >= 0; --i)
         {
             Element participant = (Element)listParticipant.item(i);
             Element co_authors = (Element)listCoAuthor.item(i);
             if (co_authors.hasChildNodes())
             {
                NodeList list = co_authors.getChildNodes();
                if (list != null)
                {
                   int count = 0;
                   int length = list.getLength();
                   for (int j = 0; j < length; j++)
                   {
                       Node node = list.item(j);
                       if (node.getNodeType() == Node.ELEMENT_NODE)
                           count++;
                   }            
                   //System.out.println(i + " count: "+ count);
                   if (count < 4)
                   {
                       participant.getParentNode().removeChild(participant);
                   } 

                }
             }   
         }        
    }
}