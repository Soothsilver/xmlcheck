/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package user;

/**
 *
 * @author Tatsiana Maksimenka
 */

import org.xml.sax.helpers.DefaultHandler; 
import org.xml.sax.*;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import org.xml.sax.helpers.XMLReaderFactory;

public class MySaxHandler extends DefaultHandler {
    // overrides of DefaultHandler methods 
    
    private static final String INPUT_FILE = "sax/user/data.xml";
    //private static final String OUTPUT_FILE = "src/user/data_out.xml";
    private static HashMap<String,Integer> map = new HashMap<String,Integer>();
    private static ValueComparator bvc = new ValueComparator(map);
    private static TreeMap<String,Integer> sorted_map = new TreeMap<String,Integer>(bvc);

    
    
    
    /**
     * @param args the command line arguments
     */
        public static void main(String[] args) {

        try {

            // Create parser instance
            XMLReader parser = XMLReaderFactory.createXMLReader();

            // Create input stream from source XML document
            InputSource source = new InputSource(INPUT_FILE);

            // Set our custom content handler for handling SAX events (it must implements ContentHandler interface)
            parser.setContentHandler(new CustomContentHandler());

            // Process input data
            parser.parse(source);
            
            map = new HashMap<String,Integer>();
            bvc = new ValueComparator(map);
            sorted_map = new TreeMap<String,Integer>(bvc);


        } catch (Exception e) {

            e.printStackTrace();

        }

    }
    public static class ValueComparator implements Comparator<String> 
    {

        Map<String, Integer> base;
        public ValueComparator(Map<String, Integer> base) {
            this.base = base;
        }
        public int compare(String a, String b) {
            if (base.get(a) >= base.get(b)) {
                return -1;
            } else {
                return 1;
            } 
        }
    }
    private static class CustomContentHandler implements ContentHandler {

        Locator locator;
        int countStudent = 0;
        int countRegular = 0;
        
        int sumFee = 0;
        
        boolean feeText = false;
        
        int feeInTime = 0;
        int feeLate = 0;
        
        
        //chci zjistit jmena a prijmeni ucastniku a setridit je podle poctu co_authors
        String fullName = "";
        boolean inSpeaker = false;
        boolean inCoAuthor = false;
        boolean inAuthorName = false;
        int countCoAuthors = 0;      
        
		
        
        public CustomContentHandler() {
            
            
        }

        @Override
        public void setDocumentLocator(Locator locator) {
            this.locator = locator;
        }

        // chci spocitat pocet ucastniku typu regular a student zvlast.
        @Override
        public void startDocument() throws SAXException {
            //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void endDocument() throws SAXException {
            System.out.println("Pocet studentu na konferencich: "+ countStudent);
            System.out.println("Pocet ostatnich ucastniku na konferencich: "+ countRegular);
            System.out.println("Pocet vsech ucastniku na konferencich: "  + (countRegular+countStudent));
            System.out.println("Kolik bylo celkove zaplaceno za konference: " + sumFee);
            System.out.println("Stredni fee za konference: " + (double)sumFee/(countRegular+countStudent));
            System.out.println("Celkove bylo preplaceno: " + (sumFee-feeInTime));
            
            
            //vypis odpovidajicich jmen a prisluneho poctu co_authors
            System.out.println("Vypis jmen speakeru a prislusneho poctu co_authoru: ");
            if (map != null)
            {
                sorted_map.putAll(map);
                System.out.println(sorted_map);
            }
        }

        @Override
        public void startPrefixMapping(String string, String string1) throws SAXException {
            //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void endPrefixMapping(String string) throws SAXException {
            //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
            if ((localName.equals("participant")) && (atts.getValue("type").equals("student")))
            {
                countStudent++;
            }
            if ((localName.equals("participant")) && (atts.getValue("type").equals("regular")))
            {
                countRegular++;
            }
            
            if ((localName.equals("fee")))
            {
//                System.out.print("<fee");
//                for (int i = 0; i < atts.getLength(); i++) 
//                {                    
//                    System.out.print(" " + atts.getLocalName(i) + "=" + atts.getValue(i));
//                }
//                System.out.print(">");
                feeText = true;
            }
            
            if (localName.equals("speaker"))
            {
                inSpeaker = true;
            }
            if (localName.equals("co_authors"))
            {
                inCoAuthor = true;
                countCoAuthors = 0;
            }
            if ((localName.equals("author_name") && inCoAuthor))
            {
                inAuthorName = true; 
                countCoAuthors++;
            }
        }

        @Override
        public void endElement(String uri, String localName, String qName) throws SAXException {
            if (localName.equals("fee"))
            {
                //System.out.println("</" + localName + ">");
                
                feeText=false;
            }
            
            if (localName.equals("speaker"))
            {
                inSpeaker = false;
            }
            
            if (localName.equals("co_authors"))
            {
                inCoAuthor = false;
                if (countCoAuthors != 0)
                {
                    map.put(fullName, countCoAuthors);
                }
                    countCoAuthors=0;
                    fullName="";
                
                
            }
             if (localName.equals("author_name"))
            {
                inAuthorName = false;                
            }
        }

        @Override
        public void characters(char[] chars, int start, int length) throws SAXException {
            
            String result = "";
            //filtruju text, ktery odpovida jenom fee            
            if (feeText)
            {
                for (int i = start; i < start+length; i++)
                {                
                    result = result + chars[i];                
                }
                //System.out.print(result);
                int price = Integer.parseInt(result);
                sumFee += price;
                
                //celkove fee, ktere bylo zaplaceno predem
                if (price == 320 || price == 450 || price == 420)
                    feeInTime += price;
                //celkove fee, ktere bylo zaplaceno pozdeji
                if (price == 380 || price == 480 || price == 520)
                    feeLate += price;
                
            }
            
            //zjistieni jmeno a prijmeni speakera            
            if (inSpeaker)
            {
                if (fullName != "") fullName += " ";
                String name = "";
                for (int i = start; i < start+length; i++)
                {                
                    name = name + chars[i];                
                }
                fullName = fullName + name;
            }
            
            
        }

        @Override
        public void ignorableWhitespace(char[] chars, int i, int i1) throws SAXException {
            //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void processingInstruction(String string, String string1) throws SAXException {
            //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void skippedEntity(String string) throws SAXException {
            //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }
}


