package user;

import java.util.ArrayList;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

class Pair {
    String first;
    int second;

    public Pair(String f, int s) {
        first=f;
        second=s;
    }
}
class Doc { //t��da pro informace o po�tech
    int actmales = 0; //po�et herc� mu��
    int actfemales = 0; //po�et here�ek
    int dirmales = 0; // po�et re�is�r� mu��
    int dirfemales = 0; //po�et re�is�rek
    int films = 0; //po�et film�
    int actorsinfilm  = 0; //po�et herc� hraj�c�h vefilmech.
    float rates = 0; //sou�et rating� film�
    ArrayList<Pair> colors = new ArrayList<Pair>(); //seznam barev s po�tem v�skyt�
}
public class MySaxHandler extends DefaultHandler { // overrides of DefaultHandler methods
   /* public static void main(String[] args) {

        // Cesta ke zdrojov�mu XML dokumentu  
        String sourcePath = "data.xml";

        try {
            
            // Vytvor�me instanci parseru.
            XMLReader parser = XMLReaderFactory.createXMLReader();
            
            // Vytvor�me vstupn� proud XML dat.
            InputSource source = new InputSource(sourcePath);
            
            // Nastav�me n� vlastn� content handler pro obsluhu SAX ud�lost�.
            parser.setContentHandler(new MySaxHandler());
            
            // Zpracujeme vstupn� proud XML dat.
            parser.parse(source);
            
        } catch (Exception e) {        
            e.printStackTrace();            
        }        
    }  */


/**
 * N� vlastn� content handler pro obsluhu SAX ud�lost�.
 * Implementuje metody interface ContentHandler. 
 */ 

    // Umo��uje zac�lit m�sto v dokumentu, kde vznikla aktualn� ud�lost
    Locator locator;   
    Boolean inactor = false; // zda jsem v hercovi.
    Boolean infilm = false; // zda jsem ve filmu.
    Boolean inratingfilm = false; // zda jsem v ratingu filmu.
    Boolean indirector = false; // zda jsem v �e�is�rovi.
    Doc d = new Doc(); // t��da dr��c� informace o po�tech.
    /**
     * Nastav� locator
     */     
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Obsluha ud�losti "za��tek dokumentu"
     */     
    @Override
    public void startDocument() throws SAXException {
        //hlavicka xhtml
        System.out.println("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\"" +
                " \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html xmlns=\"http://www.w3.org/1999/xhtml\">" +
                "<head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/><title>stats</title></head><body>");
        // ...
        
    }
    /**
     * Obsluha ud�losti "konec dokumentu"
     */     
    @Override
    public void endDocument() throws SAXException {
        //vypise postupne vsechny statistiky
        System.out.println("Po�et m��� herc� je :" + d.actmales + "<br/>");
        System.out.println("Po�et �en here�ek je :" + d.actfemales + "<br/>");

        String pomer;
        if(d.actmales == 0) pomer = "nekone�no"; //�esk� nekone�no pokd nejsou mu�i herci
        else pomer = String.valueOf(new Float(d.actfemales)/d.actmales); //spo��tat pom�r
        System.out.println("Pom�r �en/mu�� here�ek herc� je : " + pomer + "<br/>");

        System.out.println("Po�et m��� �esis�r� je :" + d.dirmales + "<br/>");
        System.out.println("Po�et �en re�is�rek je :" + d.dirfemales + "<br/>");

        if(d.dirmales == 0) pomer = "nekone�no";//�esk� nekone�no pokd nejsou mu�i �e�is��i
        else pomer = String.valueOf(new Float(d.dirfemales)/d.dirmales);//spo��tat pom�r

        //po�et herc� na film ale pouze ti co n�kde hr�li
        System.out.println("Pr�m�rn� po�et herc�/here�ek na film je: " + new Float(d.actorsinfilm)/d.films);

        //naj�t maximum v barv�ch pokud je v�c maxim ypsat v mno�nym
        int max = 0;
        String color = "";
        Boolean multi = false;
        for(Pair pair : d.colors) {
            if(pair.second > max) {
                max = pair.second;
                color = pair.first;
                multi = false;
            } else if ( pair.second == max) {
                color = color + ", " + pair.first;
                multi = true;
            }
        }
        if(d.colors.size() == 0) color = "none";
        if(!multi)
            System.out.print("Nejobl�ben�j�� hereck� barva je :" + color);
        else {
            System.out.print("Nejobl�ben�j�� hereck� barvy jsou :" + color);
        }
        System.out.println(" s po�tem " + max + "<br/>");

        //rating filmu
        System.out.println("Pr�m�rn� rating filmu je :" + d.rates/d.films);
        System.out.println("</body></html>");
      
        // ...
        
    }
    
    /**
     * Obsluha ud�losti "za��tek elementu".
     * @param uri URI jmenn�ho prostoru elementu (pr�zdn�, pokud element nen� v ��dn�m jmenn�m prostoru)
     * @param localName Lok�ln� jm�no elementu (v�dy nepr�zdn�)
     * @param qName Kvalifikovan� jm�no (tj. prefix-uri + ':' + localName, pokud je element v n�jak�m jmenn�m prostoru, nebo localName, pokud element nen� v ��dn�m jmenn�m prostoru)
     * @param atts Atributy elementu     
     */     
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
      if(qName.equals("actor")) {          
          inactor = true; //nastavit se do hece
          String color = atts.getValue("favourite_color"); //z�skat barvu att
          if(color!=null) {
              Addcolor(color); //p�idat 1 k po�tu barvy
          }
      } else if(qName.equals("name") && inactor == true) { //jm�no herce
          String att = atts.getValue("sex"); //z�skat pohlav� att
          if(att!=null) {
             if(att.equals("male")) {
                 d.actmales++; //p�idat k mu��m
             } else if(att.equals("female")) {
                 d.actfemales++; //p�idat k �en�m
             }
          }
      } else if (qName.equals("film")) { //ve filmu
          d.films++;
          infilm = true;
      } else if(qName.equals("rating") && infilm) { //v ratingu filmu
          inratingfilm = true;
      } else if(qName.equals("actor_infilm") && infilm) { //v herci ve filmu
          d.actorsinfilm++;
      } else if(qName.equals("director")) { //v re�ii
          indirector = true;
      } else if(qName.equals("name") && indirector == true) { //v re�ii jm�nu z�skat ophlav� att
          String att = atts.getValue("sex");
          if(att!=null) {
             if(att.equals("male")) {
                 d.dirmales++;
             } else if(att.equals("female")) {
                 d.dirfemales++;
             }
          }
      }         
    }
    /**
     * Obsluha ud�losti "konec elementu"
     * Parametry maj� stejn� v�znam jako u @see startElement     
     */     
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        //nastaven� false kdy� opou�t�me elementy
        if(qName.equals("actor")) {
          inactor = false;
        } else if (qName.equals("film")) {
          infilm = false;
        } else if(qName.equals("rating") && infilm) {
          inratingfilm = false;
        } else if(qName.equals("director")) {
          indirector = false;
        }
    }
    
    /**
     * Obsluha ud�losti "znakov� data".
     * SAX parser mu�e znakov� data d�vkovat jak chce. Nelze tedy po��tat s t�m, �e je cel� text dorucen v r�mci jednoho vol�n�.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakov�mi daty
     * @param start Index zac�tku �seku platn�ch znakov�ch dat v poli.
     * @param length D�lka �seku platn�ch znakov�ch dat v poli.
     */               
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        //pouze rating jako text
       if(inratingfilm) {
           String rating = String.copyValueOf(ch, start, length);
           d.rates+=Float.parseFloat(rating);
       }
    }
    /**
     * Obsluha ud�losti "deklarace jmenn�ho prostoru".
     * @param prefix Prefix prirazen� jmenn�mu prostoru.
     * @param uri URI jmenn�ho prostoru.
     */     
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
       
        // ...
        
    }

    /**
     * Obsluha ud�losti "konec platnosti deklarace jmenn�ho prostoru".
     */     
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
    
        // ...
    
    }

    /**
     * Obsluha ud�losti "ignorovan� b�l� znaky".
     * Stejn� chov�n� a parametry jako @see characters     
     */     
    @Override
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha ud�losti "instrukce pro zpracov�n�".
     */         
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
      
      // ...
            
    }

    /**
     * Obsluha ud�losti "nezpracovan� entita"
     */         
    @Override
    public void skippedEntity(String name) throws SAXException {    
      // ...

    
    }

    //najde barvu v seznamu a p�i�te jedni�ku jinak p�id� s po�tem 1
    private void Addcolor(String color) {
        Boolean found = false;
        for(Pair pair : d.colors) {
            if(pair.first.equals(color)) {
                found = true;
                pair.second++;
            }
        }
        if(!found) {
            d.colors.add(new Pair(color, 1));
        }
    }
}