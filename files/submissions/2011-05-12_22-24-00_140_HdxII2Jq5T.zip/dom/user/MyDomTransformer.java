package user;

import java.io.File;

import org.w3c.dom.*;
import org.w3c.dom.Attr;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class MyDomTransformer {

    private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "data.out.xml";

    /*public static void main(String[] args) {
        
        try {
            
            //DocumentBuilderFactory vytv��� DOM parsery
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            //nebudeme validovat
            dbf.setValidating(false);


            //vytvo��me si DOM parser
            DocumentBuilder builder = dbf.newDocumentBuilder();

            //parser zpracuje vstupn� soubor a vytvo�� z n�j strom DOM objekt�
            Document doc = builder.parse(VSTUPNI_SOUBOR);

            //zpracujeme DOM strom
            (new MyDomTransformer()).transform(doc);

            //TransformerFactory vytv��� serializ�tory DOM strom�
            TransformerFactory tf = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer = tf.newTransformer();

            //nastav�me kodov�n�
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spust�me transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


        } catch (Exception e) {
            
            e.printStackTrace();
            
        }
    }*/


    public void transform (Document doc) {

        //odeberat rozdeleni na hlavni av vedlejsi role ve filmech
        NodeList actors_infilmlist = doc.getElementsByTagName("actors_infilm"); //najde vsechny actors_infilm
        for(int i=0; i< actors_infilmlist.getLength(); ++i) { //pro kazdej z nich
            if(actors_infilmlist.item(i).getNodeType()!=1) continue; //pokud neni element (text pravd�podobn�) ignoruj
            Element newActors_infilm = doc.createElement("actors_infilm");
            Element actors_infilm = (Element)(actors_infilmlist.item(i));
            NodeList main_or_side_list = actors_infilm.getChildNodes(); //vem jeho potomky (main_actors a side_actors)
            for(int j=0; j< main_or_side_list.getLength(); j++) { //pro ka�dej z nich
                if(main_or_side_list.item(j).getNodeType()!=1) continue; //pokud neni element (text pravd�podobn�) ignoruj
                Element main_or_side = (Element)(main_or_side_list.item(j));
                NodeList actor_in_film_list = main_or_side.getChildNodes(); //vem jejich potomky (actor_infilm) uz jednotliv� herce
                actors_infilm.removeChild(main_or_side);
                for(int p=0; p< actor_in_film_list.getLength(); ++p) {
                if(actor_in_film_list.item(p).getNodeType()!=1) continue; //pokud neni element (text pravd�podobn�) ignoruj
                    newActors_infilm.appendChild(actor_in_film_list.item(p));
                }
            }
            actors_infilm.getParentNode().replaceChild(newActors_infilm, actors_infilm);
        }


        //Sjednotit vsechny osoby do jednoho (herce a re�is�ry)
        Element osoby = doc.createElement("persons"); //novy element misto directors a actors
        NodeList actorslist =  doc.getElementsByTagName("actors"); //vsechny elementy actors
        NodeList directorslist = doc.getElementsByTagName("directors"); //vsechny elementy directors
        for(int u = 0; u<actorslist.getLength(); ++u) { //pro kazdy actors element
            Node actors = actorslist.item(u);
            actors.getParentNode().removeChild(actors); //a odeber actors element
            NodeList actorlist = actors.getChildNodes();    //vem jeho potomky
            for(int i=0; i< actorlist.getLength(); ++i) { //a pro kazdeho z potomku
                Node actor = actorlist.item(i);
                if(actor.getNodeType()!=1) {//pokud neni element (text pravd�podobn�) ignoruj 
                    continue;
                }   
                //actor.getParentNode().removeChild(actor);
                osoby.appendChild(actor);   //ho pridej do osob
            }
        }
        for(int v = 0; v<directorslist.getLength(); ++v) {//pro kazdy directors element
            Node directors = directorslist.item(v);
            directors.getParentNode().removeChild(directors); //a odeber directors element
            NodeList directorlist = directors.getChildNodes();//vem jeho potomky
            for(int j=0; j< directorlist.getLength(); ++j) {//a pro kazdeho z potomku
                Node director = directorlist.item(j);
                if(director.getNodeType()!=1) {//pokud neni element (text pravd�podobn�) ignoruj
                    continue;
                }
                //director.getParentNode().removeChild(director);
                osoby.appendChild(director); //ho pridej do osob
            }
        }
        doc.getDocumentElement().appendChild(osoby);


        NodeList actorlist = doc.getElementsByTagName("actor"); //seznam vsech hercu
        for(int g = 0; g< actorlist.getLength(); ++g) { //pro kazdeho z nich
            Element actor = (Element) actorlist.item(g);
            String color = actor.getAttribute("favourite_color"); //zjistit barvu
            if(color.equals("")) { //pokud neni definovana nebo je prazdna
                actor.setAttribute("favourite_color", "brown"); //pridelit mu hn�dou
            }
        }
        NodeList releasedateslist = doc.getElementsByTagName("releasedates"); //seznam vsech release dates
        for(int h = 0; h< releasedateslist.getLength(); ++h) { //pro kazdy z nich
            Element rel = (Element) releasedateslist.item(h);
            NodeList places = rel .getChildNodes(); //seznam potomku, tedy cinema a dvd
            for(int f = 0; f< places.getLength(); ++f) { //pro kazdy dvd a cinema
                Node place = places.item(f);
                if(place.getNodeType()!=1) {//pokud neni element (text pravd�podobn�) ignoruj
                    continue;
                }
                NodeList countries = place.getChildNodes(); //vem potomky tedy zem�
                Boolean csfound = false;
                for(int d = 0; d< countries.getLength(); ++d) { // a pro ka�dou zemi otestuj jestli neni cz
                    Node country = countries.item(d);
                    if(country.getNodeType()!=1) {//pokud neni element (text pravd�podobn�) ignoruj
                        continue;
                    }
                    if(country.getNodeName().equals("cz")) { //pokud je cz ozna� �e na�el a break
                        csfound = true;
                        break;
                    }
                }
                if(!csfound) { //pokud nebyla cz tak p�idat
                    Element cs = doc.createElement("cz");
                    Node date = doc.createTextNode("1970-1-1");
                    cs.appendChild(date);
                    place.appendChild(cs);
                }
            }
        }
    }

}
