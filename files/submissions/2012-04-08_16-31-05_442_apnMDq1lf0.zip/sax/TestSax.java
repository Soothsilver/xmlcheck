

/*
* Torzo pro SAX
*/

import cz.XmlTester.TestJava;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;
import java.util.HashMap;
//import java.util.Locale;
import java.util.Vector;
import org.xml.sax.helpers.DefaultHandler;

//import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;

public class TestSax extends TestJava
{
    private static final String fileName = "../data.xml";

    /**
    * main funkce
    */
    public void run()
    {
        try
        {
            // Vytvoríme instanci parseru.
            XMLReader parser = XMLReaderFactory.createXMLReader();

            // Nastavíme náą vlastní content handler pro obsluhu SAX událostí.
            parser.setContentHandler(new MyHandler());

            // Vytvoríme vstupní proud XML dat.
            InputSource source = new InputSource(fileName);

            // Zpracujeme vstupní proud XML dat.
            parser.parse(source);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
	
}

/**
 * Spocita priemerny vek kozmonautov pri starte.
 * Celkovo, aj za jednotlive krajiny.
 */
class MyHandler extends DefaultHandler
{
    private class Astronaut
    {
        public String name;
        public Date bornDate;
        public Date dieDate;
        public String country;
        public Vector<Date> missionsDates = new Vector<Date>();

        public Astronaut(Date missionDate)
        {
            missionsDates.add(missionDate);
        }

        public Astronaut(String name, Date bornDate, Date dieDate)
        {
            this.name = name;
            this.bornDate = bornDate;
            this.dieDate = dieDate;
        }
    }

    private class CountryInfo
    {
        public String name = "";
        public long sumAgeInMillis = 0;
        public int missionCount = 0;

        public CountryInfo(String name)
        {
            this.name = name;
        }
    }

    private static final int systemStartYear = 1970;

    private static final String elementMission = "mission";
    private static final String elementCrewMember = "crewMember";
    private static final String elementLaunchDate = "launchDate";
    private static final String elementAstronaut = "astronaut";
    private static final String elementCountry = "country";

    private static final String crewMemAttributeAstronautID = "astronautID";
    private static final String astronautAttributeID = "id";
    private static final String astronautAttributeName = "name";
    private static final String astronautAttributeBornDate = "bornDate";
    private static final String astronautAttributeDieDate = "diedDate";
    

    private static final String dateFormatString = "dd.MM.yyyy";
    private DateFormat dateFormat = new SimpleDateFormat(dateFormatString);

    private HashMap<String,Astronaut> astronauts = new HashMap<String, Astronaut>();

    //docasne premenne potrebne pri parsovani dokumentu
    private String elementTextValue;

    private Date actualLaunchDate = null;
    private String actualAstronautID = "";
    private String actualCountry = "";
    private Astronaut actualAstronaut = null;

    // Umožnuje zacílit místo v dokumentu, kde vznikla aktualní událost
    Locator locator;

    /**
     * Nastaví locator
     */
    @Override
    public void setDocumentLocator(Locator locator)
    {
        this.locator = locator;
    }

    /**
     * Obsluha události "zacátek elementu".
     * @param uri URI jmenného prostoru elementu (prázdné, pokud element není v žádném jmenném prostoru)
     * @param localName Lokální jméno elementu (vždy neprázdné)
     * @param qName Kvalifikované jméno (tj. prefix-uri + ':' + localName, pokud je element v nejakém jmenném prostoru, nebo localName, pokud element není v žádném jmenném prostoru)
     * @param atts Atributy elementu
     */
    @Override
    public void startElement(String uri, String localName, String qName,
            Attributes atts) throws SAXException
    {
            elementTextValue = "";
            
            if (localName.equals(elementCrewMember))
            //<crewMember>: poznacim ID astronauta - launchDate je urcena
            //v dalsom elemente, musim pockat na koniec elementu <mission>
            {
                actualAstronautID = atts.getValue(crewMemAttributeAstronautID);
            }
            else if (localName.equals(elementAstronaut))
            //<astronaut>
            //spracujem
            {
                Date bornDate;
                Date dieDate = null;

                try
                {
                    bornDate = dateFormat.parse(atts.getValue(astronautAttributeBornDate));

                    if (atts.getValue(astronautAttributeDieDate) != null)
                    //nepovinny atribut
                    {
                        dieDate = dateFormat.parse(atts.getValue(astronautAttributeDieDate));
                    }
                }
                catch (Exception ex)
                {
                    throw new SAXException(ex.getMessage());
                }

                if (astronauts.containsKey(atts.getValue(astronautAttributeID)))
                //<astronaut> v HashMape uz vlozeny - doplnim data
                {
                    actualAstronaut = astronauts.get(actualAstronautID);
                    
                    actualAstronaut.name = atts.getValue(astronautAttributeName);
                    actualAstronaut.bornDate = bornDate;
                    actualAstronaut.dieDate = dieDate;
                }
                else
                {
                    actualAstronaut = new Astronaut(atts.getValue(astronautAttributeName),
                            bornDate, dieDate);
                    astronauts.put(atts.getValue(astronautAttributeID),actualAstronaut);
                }
            }


    }

    /**
     * Obsluha události "konec elementu"
     * Parametry mají stejný význam jako u @see startElement
     */
    @Override
    public void endElement(String uri, String localName, String qName)
            throws SAXException
    {
        
        if (localName.equals(elementLaunchDate))
        //poznacim si launchDate, na spracovanie cakam na koniec elementu
        //<mission>
        {
            if (elementTextValue.equals(""))
            {
                throw new SAXException();
            }
            try
            {
                actualLaunchDate = dateFormat.parse(elementTextValue);
            }
            catch (ParseException ex)
            {
                throw new SAXException(ex.getMessage());
            }
        }
        else if (localName.equals(elementMission))
        //doplnim do hashmapy k astronautovi novy <launchDate>
        //ak tam este taky astronaut nie je, vytvorim noveho
        {
            if (actualAstronautID.equals("") || (actualLaunchDate == null))
            {
                throw new SAXException();
            }

            if (astronauts.containsKey(actualAstronautID))
            {
                Astronaut storedAstronaut = astronauts.get(actualAstronautID);
                storedAstronaut.missionsDates.add(actualLaunchDate);
            }
            else
            {
                astronauts.put(actualAstronautID,new Astronaut(actualLaunchDate));
            }
            actualAstronautID = "";
            actualLaunchDate = null;
        }
        else if (localName.equals(elementCountry))
        //poznacim si hodnotu country - na spracovanie musim cakat
        //na koniec elementu <astronaut>
        {
            actualCountry = elementTextValue;
        }
        else if (localName.equals(elementAstronaut))
        //k astronautovi doplnim krajinu
        {
            if (actualAstronaut == null)
            {
                throw new SAXException();
            }
            actualAstronaut.country = actualCountry;
            actualAstronaut = null;
            actualCountry = "";
        }
    }

    /**
     * Obsluha události "znaková data".
     * SAX parser muže znaková data dávkovat jak chce. Nelze tedy pocítat s tím, že je celý text dorucen v rámci jednoho volání.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakovými daty
     * @param start Index zacátku úseku platných znakových dat v poli.
     * @param length Délka úseku platných znakových dat v poli.
     */
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException
    {
        int end = start + length;
        for (int i=start; i<end; ++i)
        {
            elementTextValue = elementTextValue.concat(Character.toString(ch[i]));
        }
    }

     /**
     * Obsluha události "konec dokumentu"
     */
    @Override
    public void endDocument() throws SAXException
    {
        long sumAgeInMillis = 0;
        int missionCount = 0;

        //hashmapa objektov so statistikami jednotlivych krajin
        HashMap<String, CountryInfo> countries = new HashMap<String, CountryInfo>();

        for (Astronaut listedAstronaut : astronauts.values())
        {
            CountryInfo country;
            if (countries.containsKey(listedAstronaut.country))
            {
                country = countries.get(listedAstronaut.country);
            }
            else
            {
                country = new CountryInfo(listedAstronaut.country);
                countries.put(listedAstronaut.country, country);
            }

            for (Date missionDate : listedAstronaut.missionsDates)
            {
                long age = missionDate.getTime()-listedAstronaut.bornDate.getTime();

                country.sumAgeInMillis += age;
                ++country.missionCount;

                sumAgeInMillis +=  age;
                ++missionCount;
            }
        }

        long avgAgeInMillis = sumAgeInMillis / missionCount;
        Calendar avgAge = Calendar.getInstance();
        avgAge.setTimeInMillis(avgAgeInMillis);

        System.out.println("Average astronaut age at launch:");
        System.out.println("================================");
        System.out.printf("ALL (%d missions):\n",missionCount);
        System.out.printf("%d years, %d month(s) and %d day(s)\n",
                avgAge.get(Calendar.YEAR) - systemStartYear,
                avgAge.get(Calendar.MONTH),
                avgAge.get(Calendar.DAY_OF_MONTH));

        for (CountryInfo countryInfo : countries.values())
        {
            System.out.println("--------------------------------");
            long countryAvgAgeInMillis = countryInfo.sumAgeInMillis / countryInfo.missionCount;
            Calendar countryAvgAge = Calendar.getInstance();
            countryAvgAge.setTimeInMillis(countryAvgAgeInMillis);

            System.out.printf("%s (%d mission(s)):\n",countryInfo.name, countryInfo.missionCount);
            System.out.printf("%d years, %d month(s) and %d day(s)\n",
                    countryAvgAge.get(Calendar.YEAR) - systemStartYear,
                    countryAvgAge.get(Calendar.MONTH),
                    countryAvgAge.get(Calendar.DAY_OF_MONTH));
        }
    }
}
