package user;

import java.util.ArrayList;
import java.util.HashSet;

import org.w3c.dom.*;

/**
 * Converts child elements with text content to attributes.
 * Not to lose information those child elements:
 *   - must not have attributes,
 *   - must have unique name (in context of parent node),
 *   - must not collide with existing attribute.
 * 
 * @note Mixed content is handled in the same way as also whitespace
 *       content caused considering the content as mixed.
 * 
 * @author Michal Koutný
 */
public class MyDomTransformer {

    public void transform(Document xmlDocument) {
        transformNode(xmlDocument);
    }

    private void transformNode(Node node) {
        NodeList children = node.getChildNodes();
        ArrayList<Node> toRemove = new ArrayList<Node>();
        HashSet<String> nameConstraint = new HashSet<String>();
        HashSet<String> wrongNames = new HashSet<String>();


        // in the first pass we only check child names uniqueness
        for (int i = 0; i < children.getLength(); ++i) {
            Node child = children.item(i);
            if (nameConstraint.contains(child.getNodeName())) {
                wrongNames.add(child.getNodeName());
            } else {
                nameConstraint.add(child.getNodeName());
            }
        }

        // second pass does the transform itself
        for (int i = 0; i < children.getLength(); ++i) {
            Node child = children.item(i);
            if (canConvertToAttribute(child, node, wrongNames)) {
                ((Element) node).setAttribute(child.getNodeName(), child.getTextContent());
                toRemove.add(child);
            } else {
                transformNode(child);
            }
        }

        // not to modify collection while iterating it
        for (Node redundant : toRemove) {
            node.removeChild(redundant);
        }
    }

    private boolean canConvertToAttribute(Node node, Node parent, HashSet<String> wrongNames) {

        return parent instanceof Element
                && node.getChildNodes().getLength() == 1 // only single child
                && node.getFirstChild().getNodeType() == Node.TEXT_NODE // child must be text
                && !node.hasAttributes() // text must not be "extended" by attributes
                && !wrongNames.contains(node.getNodeName()) // name must be unique
                && !((Element) parent).hasAttribute(node.getNodeName()); // name must not collide
    }
}
