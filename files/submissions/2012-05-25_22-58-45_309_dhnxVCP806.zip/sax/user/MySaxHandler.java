package user;

import java.util.Stack;
import java.util.ArrayList;
import java.util.Collections;

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;

public class MySaxHandler extends DefaultHandler {

    private Stack<Integer> counterStack;
    private ArrayList<Integer> fanoutStats;

    public MySaxHandler() {
        this.counterStack = new Stack<Integer>();
        this.fanoutStats = new ArrayList<Integer>();
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) {
        // note down child of the parent element
        if (!this.counterStack.empty()) {
            Integer children = this.counterStack.pop();
            this.counterStack.push(children + 1);
        }
        // add record for current element
        this.counterStack.push(0);
    }

    @Override
    public void endElement(String uri, String localName, String qName) {
        // on top of stack we have no. of children of the ending element
        // so add it to the statistics
        this.fanoutStats.add(this.counterStack.pop());
    }

    @Override
    public void endDocument()  {
       Integer maximum = Collections.max(this.fanoutStats);
       Integer sum = 0;
       for(Integer fanout: this.fanoutStats){
           sum += fanout;
       }
       
       Double avg = new Double((double)sum / this.fanoutStats.size());
       
       System.out.println("Elements:\t" + String.valueOf(this.fanoutStats.size()));
       System.out.println("Maximum fanout:\t" + maximum.toString());
       System.out.println(String.format("Mean fanout:\t%.2f", avg));
    }
}
