package user;

/**
 * Provede fan-out statistiku dokumentu (+ jeste nejake dalsi charakteristiky)
 */

import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler { 
	
    Locator locator; 
	int pocet_elementu, pocet_atributu, maximalni_hloubka, hloubka;
	int[] pocet_deti, max_fanout;
	String[] max_fanout_el;
	
	@Override
    public void startDocument() throws SAXException {
        pocet_elementu = 0;
		pocet_atributu = 0;
		maximalni_hloubka = 0;
		hloubka = 0;
		pocet_deti = new int[1024];
		pocet_deti[0] = 0;
		max_fanout = new int[1024];
		max_fanout_el = new String[1024];
    }
	
	@Override
    public void endDocument() throws SAXException {
		System.out.println("Celkovy pocet elementu: " + pocet_elementu);
		System.out.println("Celkovy pocet atributu: " + pocet_atributu);
		System.out.println("Hloubka dokumentu: " + maximalni_hloubka);
		
		int max = 0;
		int maxh = 0;
		
		for(int i = 1; i <= maximalni_hloubka; i++) {
			System.out.print("\nVrstva " + i + " - maximalni fanout: " + max_fanout[i]);
			if(max_fanout[i] != 0) System.out.print(" (" + max_fanout_el[i] + ")");
			
			if(max_fanout[i] > max) {
				max = max_fanout[i];
				maxh = i;
			}
		}
		
		System.out.println("\n\nCelkem maximalni fanout " + max + " u elementu " + max_fanout_el[maxh]);
    }
	
	@Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
          pocet_atributu += atts.getLength();        
		  ++pocet_deti[hloubka];
		  
		  if(++hloubka > maximalni_hloubka)
			  maximalni_hloubka = hloubka;
		  
		  pocet_deti[hloubka] = 0;
		  ++pocet_elementu;
    }
	
	@Override
    public void endElement(String uri, String localName, String qName) throws SAXException {        
		
		if(pocet_deti[hloubka] > max_fanout[hloubka]) {
			max_fanout[hloubka] = pocet_deti[hloubka];
			max_fanout_el[hloubka] = localName;
		}
		
		--hloubka;
    }
    
}
