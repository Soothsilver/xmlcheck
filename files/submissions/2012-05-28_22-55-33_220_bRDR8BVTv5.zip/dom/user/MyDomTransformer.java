package user;

import java.util.ArrayList;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer {
	public static void transform (Document xmlDocument) {
	   flatFamilies(xmlDocument);	   
	}

	/**
	 * Zrusi rodinnou hiearchii (ta muze byt libovolne hluboka) a udela z ni plochy seznam osob
	 * Osoby maji vzdy seznam deti (dalsich osob)
	 * @param xmlDocument dokument k opracovani
	 */
	private static void flatFamilies(Document xmlDocument) {
		NodeList l = xmlDocument.getElementsByTagName("osoby");
		
		// prochazi vsechny <osoby> v dokumentu - vzdy 1x za kazdou rezervaci
		for(int i = 0; i < l.getLength(); ++i) {
		
			// vytvorime si novy vysledny element
			Node nove_osoby = xmlDocument.createElement("zplostene_osoby");	
			
			// prislusna rezervace
			Node parent = l.item(i).getParentNode();			
			
			// najdeme si seznam osob v rezervaci a rekurzivne zpracujeme
			NodeList osoby = l.item(i).getChildNodes();
			
			for(int j = 0; j < osoby.getLength(); ++j) {
				
				// vysledek zplosteni nahazime do <nove_osoby>
				for(Node n : flatPerson(osoby.item(j))) {
					nove_osoby.appendChild(n);
				}
			}
			
			parent.appendChild(nove_osoby); // pridame nove osoby (premaze stary element <osoby>
			parent.removeChild(l.item(i)); // smazeme stare hiearchicke <osoby>
		}
	}
	
	/**
	 * Rekurzivne zpracuje <osoba> a jeji deti a zplosti je
	 * @param person <osoba> ke zpracovani
	 * @return vraci zplosteny seznam
	 */
	private static ArrayList<Node> flatPerson(Node person) {
		ArrayList<Node> result = new ArrayList<Node>();
		
		NodeList info = person.getChildNodes(); // informace o osobe
		
		for(int i = 0; i < info.getLength(); ++i) {
			Node child = info.item(i);
			
			if(child.getNodeName().equals("deti")) {
				
				// rekurzivne zpracujeme <deti> a element smazeme
				NodeList deti = child.getChildNodes();
				
				for(int j = 0; j < deti.getLength(); ++j) {
					result.addAll(flatPerson(deti.item(j)));
				}
				
				// smazeme element
				person.removeChild(child);
				--i;
			}
		}
			
		// pridame aktualni zpracovavanou osobu do vysledku
		result.add(person.cloneNode(true));
		
		return result;
	}
}
