// Spocitame pocet elementu, pocet textovych elementu a maximalni hloubku elementu v dokumentu.

package user;

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;

/*public class TridaSAX {
	public static void main(String[] args) {
		String soubor = "data.xml";
		
		try {
			XMLReader parser = XMLReaderFactory.createXMLReader();
			InputSource data = new InputSource(soubor);
			parser.setContentHandler(new MySaxHandler());
			parser.parse(data);
		} catch (Exception e) {
			System.err.println(e);
		}
	}
}*/

public class MySaxHandler extends DefaultHandler {
	Locator locator;
	int hloubka;
	int maxhloubka;
	int elementu;
	int textovych;

	public void setDocumentLocator(Locator locator) {
		this.locator = locator;
	}

	public void startDocument() throws SAXException {
		hloubka = 0;
		maxhloubka = 0;
		elementu = 0;
		textovych = 0;
	}

	public void endDocument() throws SAXException {
		System.out.println("V dokumentu je " + elementu + " elementu (z toho " + textovych + " textovych) o maximalni hloubce " + maxhloubka + ".");
	}
	

	public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
		elementu++;
		hloubka++;
		if (hloubka > maxhloubka) {
			maxhloubka = hloubka;
		}
	}
	

	public void endElement(String uri, String localName, String qName) throws SAXException {
		hloubka--;
	}
	

	public void characters(char[] ch, int start, int length) throws SAXException {
		textovych++;
	}

	public void startPrefixMapping(String prefix, String uri) throws SAXException {
	}

	public void endPrefixMapping(String prefix) throws SAXException {
	}

	public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
	}

	public void processingInstruction(String target, String data) throws SAXException {
	}

	public void skippedEntity(String name) throws SAXException {
	}
}