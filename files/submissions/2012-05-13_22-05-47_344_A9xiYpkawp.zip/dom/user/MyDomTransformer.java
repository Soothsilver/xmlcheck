// Prevedeme vsechny atributy v dokumentu na elementy.

package user;

import org.w3c.dom.Document;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import org.w3c.dom.*;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.OutputKeys;
import java.io.FileOutputStream;
import java.util.Date;
import java.util.Locale;
import java.text.DateFormat;

public class MyDomTransformer {
	public void transform (Document xmlDocument) {
		Element root = xmlDocument.getDocumentElement();
		transformNode((Node)root , xmlDocument);
	}

	public void transformNode(Node n , Document doc) {
		if (n.hasChildNodes()) {
			NodeList deti = n.getChildNodes();
			for (int i = 0;i < deti.getLength();i++) {
				Node dite = deti.item(i);
				transformNode(dite , doc);
			}
		}

		if (n.hasAttributes()) {
			NamedNodeMap map = n.getAttributes ();
			for (int i = 0;i < map.getLength();i++) {
				Node nx = map.item(i);
				String an = nx.getNodeName();
				String av = nx.getNodeValue();
				Element el = (Element)n;
				el.removeAttribute(an);
				Element ne = doc.createElement(an);
				Text nt = doc.createTextNode(av);
				ne.appendChild(nt);
				n.insertBefore(ne , n.getFirstChild());
			}
		}
	}
	
	/*private static void processTree(Document doc) {
		transform(doc.getDocumentElement() , doc);
	}

	public void run() {
		String xmlin = "data.xml";
		String xmlout = "new.xml";
		
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			dbf.setValidating(false);
			DocumentBuilder builder = dbf.newDocumentBuilder();
			Document doc = builder.parse(xmlin);
			processTree(doc);
			TransformerFactory tf = TransformerFactory.newInstance();
			Transformer writer = tf.newTransformer();
			writer.setOutputProperty(OutputKeys.ENCODING , "windows-1250");
			writer.transform(new DOMSource(doc) , new StreamResult(new File(xmlout)));
		} catch (Exception e) {
			System.err.println(e);
		}
	}*/
}