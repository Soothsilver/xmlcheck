package user;

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;

/*public class TridaSAX {
	public static void main(String[] args) {
		String soubor = "data.xml";
		
		try {
			XMLReader parser = XMLReaderFactory.createXMLReader();
			InputSource data = new InputSource(soubor);
			parser.setContentHandler(new MySaxHandler());
			parser.parse(data);
		} catch (Exception e) {
			System.err.println(e);
		}
	}
}*/

class MySaxHandler implements ContentHandler {
	Locator locator;
	int hloubka;
	int maxhloubka;
	int elementu;
	int textovych;
	
	@Override
	public void setDocumentLocator(Locator locator) {
		this.locator = locator;
	}
	
	@Override
	public void startDocument() throws SAXException {
		hloubka = 0;
		maxhloubka = 0;
		elementu = 0;
		textovych = 0;
	}
	
	@Override
	public void endDocument() throws SAXException {
		System.out.println("V dokumentu je " + elementu + " elementu (z toho " + textovych + " textovych) o maximalni hloubce " + maxhloubka + ".");
	}
	
	@Override
	public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
		elementu++;
		hloubka++;
		if (hloubka > maxhloubka) {
			maxhloubka = hloubka;
		}
	}
	
	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		hloubka--;
	}
	
	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		textovych++;
	}
	
	@Override
	public void startPrefixMapping(String prefix, String uri) throws SAXException {
	}
	
	@Override
	public void endPrefixMapping(String prefix) throws SAXException {
	}
	
	@Override
	public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
	}
	
	@Override
	public void processingInstruction(String target, String data) throws SAXException {
	}
	
	@Override
	public void skippedEntity(String name) throws SAXException {
	}
}