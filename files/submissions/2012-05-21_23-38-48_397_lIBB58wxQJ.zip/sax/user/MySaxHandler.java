package user;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 *
 * @author Mejla
 */
public class MySaxHandler extends DefaultHandler {

    // Umoznuje zacilit misto v dokumentu, kde vznikla aktualni udalost
    Locator locator;
    private int countAllElements = 0;
    private int maxDepth = 0;
    private int averageDepth = 0;
    private int maxElementLength = 0;
    private int averageElementLength = 0;
    private int maxAttributeLength = 0;
    private int averageAttributeLength = 0;
    private int countDepth = 0;
    private int countAttributes = 0;
    private int countDifferentAttributes = 0;
    private int countDifferentElements = 0;
    private int countElementsWithAttributes = 0;
    private int countElementsWithTextContent = 0;
    private int countElementsWithoutAttributes = 0;
    private HashMap<String, Integer> attributes;
    private HashMap<String, Integer> elements;
    private HashMap<Integer, Integer> depths;
    private int count = 0;

    /**
     * Nastavi locator
     */
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Obsluha udalosti "zacatek dokumentu"
     */
    @Override
    public void startDocument() throws SAXException {
        countAllElements = 0;
        maxDepth = 0;
        countDepth = 0;
        averageDepth = 0;
        countAttributes = 0;
        countDifferentAttributes = 0;
        countDifferentElements = 0;
        countElementsWithAttributes = 0;
        countElementsWithoutAttributes = 0;
        countElementsWithTextContent = 0;
        maxElementLength = 0;
        averageElementLength = 0;
        maxAttributeLength = 0;
        averageAttributeLength = 0;
        count = 0;
        attributes = new HashMap<String, Integer>();
        elements = new HashMap<String, Integer>();
        depths = new HashMap<Integer, Integer>();
    }

    /**
     * Obsluha udalosti "konec dokumentu"
     */
    @Override
    public void endDocument() throws SAXException {
        System.out.println("SAX");
        System.out.println("-----------------------------------------------------------------");
        System.out.println("Pocet vsech elementu v dokumentu je: " + countAllElements);
        System.out.println("Pocet vsech rozdilnych elementu v dokumentu je: " + elements.size());
        System.out.println("Pocet vsech atributu v dokumentu je: " + countAttributes);
        System.out.println("Pocet vsech rozdilnych atributu v dokumentu je: " + attributes.size());
        System.out.println("Maximalni hloubka v dokumentu je: " + maxDepth);
        averageDepth();
        System.out.println("Prumerna hloubka v dokumentu je: " + averageDepth);
        System.out.println("Pocet vsech elementu s atrbuty v dokumentu je: " + countElementsWithAttributes);
        System.out.println("Pocet vsech elementu bez atrbutu v dokumentu je: " + countElementsWithoutAttributes);
        //System.out.println("Pocet vsech elementu s textovym obsahem v dokumentu je: " + countElementsWithTextContent);
        System.out.println("Maximalni delka atributu v dokumentu je: " + maxAttributeLength);
        averageAttributeName();
        System.out.println("Prumerna delka atributu v dokumentu je: " + averageAttributeLength);
        System.out.println("Maximalni delka elementu v dokumentu je: " + maxElementLength);
        averageElementName();
        System.out.println("Prumerna delka elementu v dokumentu je: " + averageElementLength);

    }

    /**
     * Obsluha udalosti "zacatek elementu".
     *
     * @param uri URI jmenneho prostoru elementu (prazdne, pokud element neni v
     * zadnem jmennem prostoru)
     * @param localName Lokalni jmeno elementu (vzdy neprazdne)
     * @param qName Kvalifikovane jmeno (tj. prefix-uri + ':' + localName, pokud
     * je element v nejakem jmennem prostoru, nebo localName, pokud element neni
     * v zadnem jmennem prostoru)
     * @param atts Atributy elementu
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        countAllElements++;
        countDepth++;
        depths.put(count, countDepth);
        count++;
        countAttributes += atts.getLength();




        if (maxDepth < countDepth) {
            maxDepth = countDepth;
        }
        if (elements.containsKey(localName)) {
            countDifferentElements = elements.get(localName);
            countDifferentElements++;
            elements.put(localName, countDifferentElements);
            countDifferentElements = 0;
        } else {
            elements.put(localName, countDifferentElements);
        }
        averageElementLength += localName.length();
        if (maxElementLength < localName.length()) {
            maxElementLength = localName.length();
        }
        for (int i = 0; i < atts.getLength(); i++) {
            averageAttributeLength += atts.getLocalName(i).length();
            if (maxAttributeLength < atts.getLocalName(i).length()) {
                maxAttributeLength = atts.getLocalName(i).length();
            }
            countDifferentAttributes++;
            attributes.put(atts.getLocalName(i), countDifferentAttributes);
        }
        if (atts.getLength() != 0) {
            countElementsWithAttributes++;
        } else {
            countElementsWithoutAttributes++;
        }



    }

    /**
     * Obsluha udalosti "konec elementu" Parametry maji stejny vyznam jako u
     *
     * @see startElement
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        countDepth--;
    }

    /**
     * Obsluha udalosti "znakova data". SAX parser muze znakova data davkovat
     * jak chce. Nelze tedy pocitat s tim, ze je cely text dorucen v ramci
     * jednoho volani. Text je v poli (ch) na pozicich (start) az
     * (start+length-1).
     *
     * @param ch Pole se znakovymi daty
     * @param start Index zacatku useku platnych znakovych dat v poli.
     * @param length Delka useku platnych znakovych dat v poli.
     */
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        /*   String cdata = new String(ch, start, length);
        if(cdata.length() != 0 && !cdata.contains("  ")){
        System.out.println(cdata.length());
        System.out.println(cdata);
        countElementsWithTextContent++;
        }*/
    }

    private void averageDepth() {
        for (int i = 0; i < depths.size(); i++) {
            averageDepth += depths.get(i);
        }
        averageDepth = averageDepth / depths.size();


    }

    private void averageAttributeName() {
        averageAttributeLength = averageAttributeLength / countAttributes;
    }

    private void averageElementName() {
        averageElementLength = averageElementLength / countAllElements;
    }
}

class SAX_podpora {

    public static void main(String[] args) {

        // Cesta ke zdrojovému XML dokumentu  
        String sourcePath = "data.xml";

        try {

            // Vytvoríme instanci parseru.
            XMLReader parser = XMLReaderFactory.createXMLReader();

            // Vytvoríme vstupní proud XML dat.
            InputSource source = new InputSource(sourcePath);

            // Nastavíme náą vlastní content handler pro obsluhu SAX událostí.
            parser.setContentHandler(new MySaxHandler());

            // Zpracujeme vstupní proud XML dat.
            parser.parse(source);

        } catch (Exception e) {

            e.printStackTrace();

        }

    }
}
