package user;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
public class MyDomTransformer {
public void transform (Document xmlDocument) {
    /** Prida noveho ctenare */
     NodeList nodes = xmlDocument.getElementsByTagName("ctenari");
     Element ctenari;
     if(nodes.getLength() == 0) {
	 ctenari = xmlDocument.createElement("ctenari");
	 xmlDocument.getFirstChild().appendChild(ctenari);
     } else {
	 ctenari = (Element)nodes.item(0);
     }
     Element ctenar = xmlDocument.createElement("ctenar");
     Element info = xmlDocument.createElement("info");
     info.appendChild(xmlDocument.createElement("ctenarskeCislo")).setTextContent("15235647");
     info.appendChild(xmlDocument.createElement("jmeno")).setTextContent("Jakub");
     info.appendChild(xmlDocument.createElement("prijmeni")).setTextContent("Frajer");
     info.appendChild(xmlDocument.createElement("telefon")).setTextContent("502522322");
     Element naroz = xmlDocument.createElement("datumNarozeni");
     naroz.appendChild(xmlDocument.createElement("den")).setTextContent("6");
     naroz.appendChild(xmlDocument.createElement("mesic")).setTextContent("2");
     naroz.appendChild(xmlDocument.createElement("rok")).setTextContent("1899");
     info.appendChild(naroz);
     ctenar.appendChild(info);
     Element vypujcka = xmlDocument.createElement("vypujcky");
     ctenar.appendChild(vypujcka);
     ctenari.appendChild(ctenar);
     
     
     /** Odstrani vytisk 7 knihy s isbn 564238 */
     NodeList nodes2 = xmlDocument.getElementsByTagName("kniha");

    for(int i=0; i<nodes2.getLength(); i++) {
	Element e = (Element)nodes2.item(i);
	if(e.getAttribute("isbn").equals("564238")) {
	    NodeList v = e.getElementsByTagName("vytisky");
	    if(v.getLength() > 0) {
		Element vyt = (Element)v.item(0);
		NodeList vs = vyt.getElementsByTagName("vytisk");
		for(int j=0; j<vs.getLength();j++) {
		    Element vytisk = (Element)vs.item(j);
		    if(vytisk.getAttribute("vid").equals("vyt_7")){
			vyt.removeChild(vytisk);
		    }
		}
	    }
	    
	}
    }
  }
}