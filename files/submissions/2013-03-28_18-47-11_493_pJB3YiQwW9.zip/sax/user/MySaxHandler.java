package user;
import java.util.ArrayList;
import java.util.HashMap;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
public class MySaxHandler extends DefaultHandler {
    
    class Autor {
	public String name;
	public String surname;
	public int pocetKnih;
    }
    class Nakladatelstvi {
	public String nazev;
	public String mesto;
	public int pocetKnih;
    }
    HashMap<String, Autor> autori = new HashMap<String, Autor>();
    HashMap<String, Nakladatelstvi> nakladatelstvi = new HashMap<String, Nakladatelstvi>();
    private Locator locator;
    String autId = "";
    String jmeno = "";
    String prijmeni = "";
    String currentElement = "";
    String elementGroup = "";
    String nakladId = "";
    String nazev = "";
    String mesto = "";
  /**
    * Sets the locator
    *
    * @param Locator locator location in the file
    */
   @Override
   public void setDocumentLocator(Locator locator) {
       this.locator = locator;
   }
   
   @Override
   public void startDocument () throws SAXException
    {
	
    }
   
    @Override
   public void endDocument () throws SAXException
    {
        int maxPocet = 0;
	ArrayList<Autor> nejviceKnih = new ArrayList<Autor>();
	for(Autor a:autori.values()) {
	    if(a.pocetKnih >= maxPocet) {
		if(a.pocetKnih > maxPocet) {
		    nejviceKnih = new ArrayList<Autor>();
		}
		nejviceKnih.add(a);
		maxPocet = a.pocetKnih;
	    }
	}
	System.out.print("Nejvice knih ("+maxPocet+") ma knihovna od autoru: ");
	for(Autor a:nejviceKnih){
	    System.out.print(a.name + " " + a.surname + ", ");
	}
	System.out.println("");
	
	ArrayList<String> zPrahyBezKnih = new ArrayList<String>();
	for(Nakladatelstvi n:nakladatelstvi.values()) {
	    if(n.mesto.equals("Praha") && n.pocetKnih == 0) {
		zPrahyBezKnih.add(n.nazev);
	    }
	}
	System.out.print("Nakladatelstvi z Prahy, kteri nemaji v knihovne knihu: ");
	for(String s:zPrahyBezKnih){
	    System.out.print(s + ", ");
	}
	System.out.println("");
	class Pocet {
	    String surname;
	    int pocet;
	}
	HashMap<String, Pocet> cetnostPrijmeni = new HashMap<String, Pocet>();
	for(Autor a:autori.values()) {
	    if(cetnostPrijmeni.containsKey(a.surname)) {
		cetnostPrijmeni.get(a.surname).pocet++;
	    } else {
		Pocet p = new Pocet();
		p.pocet = 1;
		p.surname = a.surname;
		cetnostPrijmeni.put(a.surname, p);
	    }
	}
	int max = 0;
	ArrayList<String> arprijmeni = new ArrayList<String>();
	for(Pocet p:cetnostPrijmeni.values()) {
	    if(p.pocet >= max) {
		if(p.pocet > max) {
		    arprijmeni = new ArrayList<String>();
		}
		arprijmeni.add(p.surname);
		max = p.pocet;
	    } 
	}
	System.out.print("Nejcastejsi prijmeni mezi autory (pocet vyskytu - "+max+"): ");
	for(String s:arprijmeni){
	    System.out.print(s + ", ");
	}
	System.out.println("");
    }
    @Override
   public void startElement (String uri, String localName,
                              String qName, Attributes attributes) throws SAXException
    {
	if(localName.equals("ctenari")) {
	    elementGroup = "ctenari";
	}
	if(localName.equals("knihy")) {
	    elementGroup = "knihy";
	}
	if(localName.equals("autori")) {
	    elementGroup = "autori";
	}
	if(localName.equals("nakladatelstvi")) {
	    elementGroup = "nakladatelstvi";
	}
        if(elementGroup.equals("autori") && localName.equals("autor")) {
	    autId = attributes.getValue("aut_id");
	    
	}
	if(localName.equals("jmeno")) {
	    currentElement = "jmeno";
	}
	if(localName.equals("prijmeni")) {
	    currentElement = "prijmeni";
	}
	if(elementGroup.equals("knihy") && localName.equals("refautor")) {
	    String[] autIds = attributes.getValue("ref_aut_id").split(" ");
	    for(String id:autIds) {
		if(autori.containsKey(id)) {
		    autori.get(id).pocetKnih++;
		} else {
		    Autor autor = new Autor();
		    autor.pocetKnih = 1;
		    autori.put(id, autor);
		}
	    }
	    
	}
	if(elementGroup.equals("knihy") && localName.equals("refnakladatelstvi")) {
	    String nid = attributes.getValue("ref_nak_id");
	    if(nakladatelstvi.containsKey(nid)) {
		nakladatelstvi.get(nid).pocetKnih++;
	    } else {
		Nakladatelstvi naklad = new Nakladatelstvi();
		naklad.pocetKnih = 1;
		nakladatelstvi.put(nid, naklad);
	    }
	    
	}
	if(elementGroup.equals("nakladatelstvi") && localName.equals("naklad")) {
	    nakladId = attributes.getValue("nak_id");
	}
	if(localName.equals("nazev")) {
	    currentElement = "nazev";
	}
	if(localName.equals("mesto")) {
	    currentElement = "mesto";
	}
    }
    @Override
   public void endElement (String uri, String localName, String qName)
        throws SAXException
    {
	if(localName.equals("ctenari")) {
	    elementGroup = "";
	}
	if(localName.equals("knihy")) {
	    elementGroup = "";
	}
	if(localName.equals("autori")) {
	    elementGroup = "";
	}
	if(localName.equals("nakladatelstvi")) {
	    elementGroup = "";
	}
        if(localName.equals("autor")) {
	    if(autori.containsKey(autId)) {
		autori.get(autId).name = jmeno;
		autori.get(autId).surname = prijmeni;
	    } else {
		Autor au = new Autor();
		au.name = jmeno;
		au.surname = prijmeni;
		autori.put(autId, au);
	    }
	    autId = "";
	    jmeno = "";
	    prijmeni = "";
	}
        if(localName.equals("naklad")) {
	    if(nakladatelstvi.containsKey(nakladId)) {
		nakladatelstvi.get(nakladId).nazev = nazev;
		nakladatelstvi.get(nakladId).mesto = mesto;
	    } else {
		Nakladatelstvi nakl = new Nakladatelstvi();
		nakl.nazev = nazev;
		nakl.mesto = mesto;
		nakladatelstvi.put(nakladId, nakl);
	    }
	    nakladId = "";
	    nazev = "";
	    mesto = "";
	}
	currentElement = "";
    }
   
    @Override
   public void characters (char ch[], int start, int length)
        throws SAXException
    {
        if(!autId.equals("") && currentElement.equals("jmeno")) {
	    jmeno = new String(ch, start, length);
	}
        if(!autId.equals("") && currentElement.equals("prijmeni")) {
	    prijmeni = new String(ch, start, length);
	}
        if(!nakladId.equals("") && currentElement.equals("nazev")) {
	    nazev = new String(ch, start, length);
	}
        if(!nakladId.equals("") && currentElement.equals("mesto")) {
	    mesto = new String(ch, start, length);
	}
    }
}