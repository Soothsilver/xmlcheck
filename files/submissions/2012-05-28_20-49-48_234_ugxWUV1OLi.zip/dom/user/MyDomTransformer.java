package user;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

public class MyDomTransformer {

    private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "data.out.xml";

    public static void main(String[] args) {
        
        try {
            
            //DocumentBuilderFactory vytváří DOM parsery
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            //nebudeme validovat
            dbf.setValidating(false);

            //vytvoříme si DOM parser
            DocumentBuilder builder = dbf.newDocumentBuilder();

            //parser zpracuje vstupní soubor a vytvoří z něj strom DOM objektů
            Document doc = builder.parse(VSTUPNI_SOUBOR);

            //zpracujeme DOM strom
            transform(doc);

            //TransformerFactory vytváří serializátory DOM stromů
            TransformerFactory tf = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer = tf.newTransformer();

            //nastavíme kodování
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spustíme transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


        } catch (Exception e) {
            
            e.printStackTrace();
            
        }
    }

    /**
     * Kazdy netextovy uzel (element) prohodi s nasledujicim uzlem stejneho
     * jmena (usporadani: deti < rodic, levy < pravy). Preusporadani zacina od
     * korene a postupuje prohledavanim do hloubky.
     */
    public static void transform(Document doc) {
        Node root = doc.getDocumentElement();
        transformNode(doc, root);
    }
    
    /**
     * Nalezne nasledujici uzel se shodnym jmenem
     */
    private static Node findNext(Node node) {
        Node root = node.getParentNode();
        Node previous = node;
        
        while (root != null)
        {
            for (Node i = previous.getNextSibling(); i != null; i = i.getNextSibling())
            {
                    Node next = find(i, node);
                    
                    if (next != null) return next;
            }
            
            previous = root;
            root = root.getParentNode();
        }
        
        return node;
    }

    /**
     * Nalezne element se shodnym jmenem jako ma node v podstromu root
     */
    private static Node find(Node root, Node node) {
        for (int i = 0; i < root.getChildNodes().getLength(); ++i) {
            Node next = find(root.getChildNodes().item(i), node);
            
            if (next != null) return next;
        }
        
        if (root.getNodeName().equals(node.getNodeName())) {
            return root;
        }
        
        return null;
    }

    /**
     * Pro kazdy uzel provede transformaci (prohozeni) a rekurzivne prejde na
     * potomky
     */
    private static void transformNode (Document doc, Node node) {
        Node next = findNext(node);
        
        if (node.getNodeType() != Node.TEXT_NODE) {
            Node nodeParent = node.getParentNode();
            Node nextParent = next.getParentNode();
        
            Node dummy = doc.createElement("dummy");
        
            if (nodeParent != null && nextParent != null && node != next) {
                 nodeParent.replaceChild(dummy, node);
                 nextParent.replaceChild(node, next);
                 nodeParent.replaceChild(next, dummy);
            }
        
            for (int i = 0; i < node.getChildNodes().getLength(); ++i) {
                transformNode(doc, node.getChildNodes().item(i));
            }
        }
    }
}
