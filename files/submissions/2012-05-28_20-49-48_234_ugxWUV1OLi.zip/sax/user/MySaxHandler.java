package user;

import java.util.*;
import java.util.Map.Entry;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

class MyNodeStat {
    Integer count = 0;
    Set<String> values = new HashSet<String>();
}

class MyFanout {
    Integer count = 0;
    Vector<String> elements = new Vector<String>();
}

public class MySaxHandler extends DefaultHandler {
    public static void main(String[] args) {

        // Cesta ke zdrojovému XML dokumentu  
        String sourcePath = "data.xml";

        try {
            
            // Vytvoríme instanci parseru.
            XMLReader parser = XMLReaderFactory.createXMLReader();
            
            // Vytvoríme vstupní proud XML dat.
            InputSource source = new InputSource(sourcePath);
            
            MySaxHandler handler = new MySaxHandler();
            
            // Nastavíme náą vlastní content handler pro obsluhu SAX událostí.
            parser.setContentHandler(handler);
            
            // Zpracujeme vstupní proud XML dat.
            parser.parse(source);
            
        } catch (Exception e) {
        
            e.printStackTrace();
            
        }
        
    }

    // Umožňuje zacílit místo v dokumentu, kde vznikla aktualní událost
    Locator locator;
    
    Map<String, Integer> elements = new HashMap<String, Integer>();
    Map<String, MyNodeStat> attributes = new HashMap<String, MyNodeStat>();
    
    Stack<MyFanout> fanouts = new Stack<MyFanout>();
    MyFanout max_fanout = new MyFanout();
    Integer max_attributes = 0;
    
    Integer depth = 0;
    Integer max_depth = 0;
    
    String text = "";
    
    Integer max_text_length = 0;
    String max_text = "";
    
    /**
     * Vypise statistiky
     */
    public void printStats() {
        System.out.println("Pocty vyskytu ruznych elementu:");
        
        Object elementStats[] = elements.entrySet().toArray();
        for (int i = 0; i < elementStats.length; ++i) {
            Entry<String, MyNodeStat> entry = (Entry<String, MyNodeStat>)elementStats[i];
            
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
        
        System.out.println();
        System.out.println("Pocty vyskytu atributu:");
        
        Object attributeStats[] = attributes.entrySet().toArray();
        for (int i = 0; i < attributeStats.length; ++i) {
            Entry<String, MyNodeStat> entry = (Entry<String, MyNodeStat>)attributeStats[i];
            
            System.out.println(entry.getKey() + ": " + entry.getValue().count + " (ruzne hodnoty: " + entry.getValue().values.size() + ")");
        }

        System.out.println();
        System.out.print("Maximalni fanout: " + max_fanout.count + " (");

        for (int i = 0; i < max_fanout.elements.size(); ++i) {
            if (i > 0) System.out.print(" ");
            System.out.print(max_fanout.elements.get(i));
        }
        
        System.out.println("), Maximalni pocet atributu 1 elementu: " + max_attributes + ", Maximalni hloubka zanoreni: " + max_depth);
        
        System.out.println();
        
        max_text = max_text.replaceAll("\n", "\\\\n");
        max_text = max_text.replaceAll("\t", "\\\\t");
        
        System.out.println("Maximalni delka textoveho obsahu: " + max_text_length + " (\"" + max_text + "\")");
    }
    
    /**
     * Nastaví locator
     */     
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Inicializace fanout citace
     */     
    public void startDocument() throws SAXException {
        fanouts.push(new MyFanout());
    }

    /**
     * Jen pro extremni pripady (zde je obvykle fanout 1)
     */     
    public void endDocument() throws SAXException {
        MyFanout fanout = fanouts.pop();
        
        if (fanout.count > max_fanout.count) max_fanout = fanout;
        
        printStats();
    }
    
    /**
     * Updatuje nejdelsi retezec
     * Zaradi element mezi zname elementy (pripocte vyskyt)
     * To same provede s atributy a zohledni jejich konkretni hodnoty
     * Pripocte 1 k hloubce
     * Updatuje max hloubku
     * Zalozi citac pro fanout tohoto elementu
     */     
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if (text.length() > max_text_length) {
            max_text_length = text.length();
            max_text = text;
        }
        text = "";
        
        if (!elements.containsKey(qName)) {
            elements.put(qName, 0);
        }
        
        Integer stat = elements.get(qName);
        
        elements.put(qName, stat + 1);
        
        for (int i = 0; i < atts.getLength(); ++i) {
            if (!attributes.containsKey(atts.getQName(i))) {
                attributes.put(atts.getQName(i), new MyNodeStat());
            }
        
            MyNodeStat attStat = attributes.get(atts.getQName(i));
            
            attStat.count += 1;
            attStat.values.add(atts.getValue(i));
        
            attributes.put(atts.getQName(i), attStat);
        }
        
        if (atts.getLength() > max_attributes) max_attributes = atts.getLength();
        
        depth++;
        
        if (depth > max_depth) max_depth = depth;
        
        fanouts.push(new MyFanout());
    }

    /**
     * Updatuje delku nejdelsiho textoveho retezce, vyprazdni buffer
     * Vynori se o uroven vys
     * Updatuje fanout podle sveho fanoutu
     * Rozsiri rodicovsky fanout
     */     
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (text.length() > max_text_length) {
            max_text_length = text.length();
            max_text = text;
        }
        text = "";

        depth--;
        
        MyFanout fanout = fanouts.pop();
        
        if (fanout.count > max_fanout.count) max_fanout = fanout;
        
        fanout = fanouts.pop();
        
        fanout.count++;
        fanout.elements.add(qName);
        
        fanouts.push(fanout);
    }
    
    /**
     * Bufferuje text
     */
    public void characters(char[] ch, int start, int length) throws SAXException {
        text += new String(ch, start, length);
    }
    
    public void startPrefixMapping(String prefix, String uri) throws SAXException {}
    public void endPrefixMapping(String prefix) throws SAXException {} 
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {}     
    public void processingInstruction(String target, String data) throws SAXException {}   
    public void skippedEntity(String name) throws SAXException {}
}