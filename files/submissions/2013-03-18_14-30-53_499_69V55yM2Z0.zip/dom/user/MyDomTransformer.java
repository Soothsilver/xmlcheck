package user;

import java.util.LinkedList;
import java.util.*;
import org.w3c.dom.*;

public class MyDomTransformer {

    Document doc;

    public void transform(Document xmlDocument) {
        doc = xmlDocument;
        addEmployee("Lex Luthor", "lex@smallShop.com", "Shop assistant");
        removeCustomersFrom("Gotham city");
    }

    /**
     * Add employe of given name and email. Role description determine its
     * permissions
     *
     * @param name
     * @param email
     * @param roleDescription
     */
    void addEmployee(String name, String email, String roleDescription) {
        String roleId = getRoleId(roleDescription);
        Element employee = doc.createElement("employee");

        employee.setAttribute("id", getEmptyId("e_"));
        employee.setAttribute("role_id", roleId);

        employee.appendChild(node("name", name));
        employee.appendChild(node("email", email));

        Node employees = doc.getElementsByTagName("employees").item(0);
        employees.appendChild(employee);
    }

    /**
     * Removes customers from given city. Also their orders are removed.
     *
     * @param city
     */
    void removeCustomersFrom(String city) {
        List<Element> customers = getCustomers(city);


        for (Element customer : customers) {
            removeCustomer(customer);
        }
    }

    private Node node(String tag, String content) {
        Element element = doc.createElement(tag);
        element.setTextContent(content);

        return element;
    }

    private String getEmptyId(String prefix) {
        String id;
        int num = 1;
        do {
            id = prefix + num;
            ++num;
        } while (doc.getElementById(id) != null);
        return id;
    }

    private String getRoleId(String roleDescription) {
        NodeList roles = doc.getElementsByTagName("role");


        for (int i = 0; i < roles.getLength(); ++i) {
            Element role = (Element) roles.item(i);
            String id = role.getAttribute("id");

            if (role.getTextContent().contains(roleDescription)) {
                return id;
            }
        }
        //no role with given description has been found
        return null;
    }

    private List<Element> getCustomers(String cityName) {
        NodeList cities = doc.getElementsByTagName("city");
        List<Element> customers = new LinkedList<Element>();
        for (int i = 0; i < cities.getLength(); ++i) {
            Element city = (Element) cities.item(i);

            if (city.getTextContent().trim().equals(cityName)) {
                customers.add((Element) city.getParentNode());
            }
        }
        return customers;
    }

    private void removeCustomer(Element customer) {
        List<Element> orders = getOrders(customer);

        for (Element order : orders) {
            //remove orders that were made by customer
            order.getParentNode().removeChild(order);
        }

        customer.getParentNode().removeChild(customer);
    }

    /**
     * get orders which are made by customer
     *
     * @param customer
     * @return
     */
    private List<Element> getOrders(Element customer) {
        String customerId = customer.getAttribute("id");
        NodeList orders = doc.getElementsByTagName("order");
        List<Element> customerOrders = new LinkedList<Element>();

        for (int i = 0; i < orders.getLength(); ++i) {
            Element order = (Element) orders.item(i);

            String orderCustomerId = order.getAttribute("customer_id");
            if (customerId.equals(orderCustomerId)) {
                customerOrders.add(order);
            }
        }

        return customerOrders;
    }
}
