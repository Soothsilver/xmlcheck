package user;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {

    private int totalProductPrice = 0;
    private int totalProductCount = 0;
    private Map<String, Integer> wordCount = new HashMap<String,Integer>();
    private PermissionFilter filter = new PermissionFilter("modify employees");
    /**
     * Contains context of current element
     */
    private List<String> context = new ArrayList<String>();
    /**
     * Here we store text data recieved for current element Whole text is
     * available in endElement
     */
    private StringBuilder elementText = new StringBuilder();

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        context.add(localName);

        if (inContextOf("product")) {
            productVisited(atts);
        } else {
            filterRoutines(atts);
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {

        String text = elementText.toString();
        String trimmedText = text.trim();

        if (inContextOf("product", "description")) {
            descriptionVisited(text);
        } else if (inContextOf("employee", "name")) {
            filter.reportEmployeeName(trimmedText);
        } else if (inContextOf("employees", "employee")) {
            filter.popEmployee();
        }

        elementCleanUp(localName);
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        elementText.append(chars, start, length);
    }

    @Override
    public void endDocument() throws SAXException {
        System.out.println("Product price mean");
        System.out.println("\t" + totalProductPrice / totalProductCount);
        System.out.println("");

        System.out.println("Count of words that apeared in product description");
        for (String word : wordCount.keySet()) {
            System.out.println("\t" + word + ": " + wordCount.get(word));
        }
        System.out.println("");
        
        System.out.println("Employes that have permission to: "+ filter.permDescription);
        for(EmployeeEntry entry : filter.getResult()){
            System.out.printf("\t Id:%s, Name:%s\n",entry.id,entry.name);
        }
    }

    /**
     * handler for product visited event.
     *
     * @param atts
     */
    private void productVisited(Attributes atts) {
        String priceStr = atts.getValue("price");
        int price = Integer.parseInt(priceStr);

        ++totalProductCount;
        totalProductPrice += price;
    }

    /**
     * handler for description visited event.
     *
     * NOTE:Expect description where all possible elements are before
     * description text
     *
     * @param descriptionText
     */
    private void descriptionVisited(String descriptionText) {
        int firstBrace = descriptionText.indexOf("<");
        int lastBrace = descriptionText.lastIndexOf(">");
        if (firstBrace < lastBrace) {
            //remove elements (because we are in mixed content)
            descriptionText = descriptionText.substring(lastBrace + 1);
        }

        descriptionText = descriptionText.trim();
        String[] words = descriptionText.split(" ");
        for (String word : words) {
            report(word);
        }
    }

    /**
     * Handler for filter reporting.
     *
     * @param atts
     */
    private void filterRoutines(Attributes atts) {
        if (inContextOf("permissions", "permission")) {
            String permId = atts.getValue("id");
            String permDescr = atts.getValue("description");

            filter.reportPermission(permId, permDescr);
        } else if (inContextOf("roles", "role")) {
            String roleId = atts.getValue("id");
            String attPerms = atts.getValue("attached_permissions");

            filter.reportRole(roleId, attPerms);
        } else if (inContextOf("employees", "employee")) {
            String emplId = atts.getValue("id");
            String roleId = atts.getValue("role_id");

            filter.pushEmployee(emplId, roleId);
        }
    }

    /**
     * reports give word into wordCount
     *
     * @param word
     */
    private void report(String word) {
        if (!wordCount.containsKey(word)) {
            wordCount.put(word, 1);
        } else {
            wordCount.put(word, wordCount.get(word) + 1);
        }
    }

    /**
     * routines which are made after endElement is handled
     *
     * @param localName
     */
    private void elementCleanUp(String localName) {
        //context handling
        int lastIndex = context.size() - 1;
        String poppedContext = context.get(lastIndex);
        context.remove(lastIndex);
        assert poppedContext.equals(localName);


        //empty text after element ending
        elementText.setLength(0);
    }

    /**
     * determine that give localNames are on top of context
     *
     * @param localNames
     * @return
     */
    private boolean inContextOf(String... localNames) {
        for (int i = 0; i < localNames.length; ++i) {
            int reverseIndex = -1 - i;
            String localName = localNames[localNames.length + reverseIndex];
            int contextIndex = context.size() + reverseIndex;
            String contextName = context.get(contextIndex);

            if (!localName.equals(contextName)) {
                return false;
            }
        }

        return true;
    }
}

/**
 * Filter out employees according to given permission
 *
 * @author m9ra
 */
class PermissionFilter {

    /**
     * Description of permission, that we want to obtain.
     */
    public final String permDescription;
    /**
     * Id of permission which we want to obtain.
     */
    private String permId;
    /**
     * Roles that contains permission which we want to obtain
     */
    private Set<String> roles = new HashSet<String>();
    /**
     * Current entry for pushed employee
     */
    private EmployeeEntry entry;
    /**
     * Filtered employees
     */
    private List<EmployeeEntry> result = new LinkedList<EmployeeEntry>();

    public PermissionFilter(String permissionDescription) {
        permDescription = permissionDescription;
    }

    public void reportPermission(String id, String description) {
        if (permDescription.equals(description)) {
            permId = id;
        }
    }

    public void reportRole(String roleId, String attachedPermissions) {
        if (attachedPermissions.contains(permId)) {
            roles.add(roleId);
        }
    }

    public void pushEmployee(String id, String roleId) {
        if (entry != null) {
            throw new UnsupportedOperationException("Cannot push twice");
        }

        entry = new EmployeeEntry();
        entry.id = id;
        entry.roleId = roleId;
    }

    public void popEmployee() {
        if (roles.contains(entry.roleId)) //this employee doesnt have needed permission
        {
            result.add(entry);
        }
        entry = null;
    }

    public void reportEmployeeName(String name) {
        entry.name = name;
    }
    
    public Collection<EmployeeEntry> getResult(){
        return result;
    }
}

class EmployeeEntry {

    String name;
    String id;
    String roleId;
}