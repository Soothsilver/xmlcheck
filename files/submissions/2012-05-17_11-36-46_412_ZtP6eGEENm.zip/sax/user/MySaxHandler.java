package user;

import org.xml.sax.*;
import org.xml.sax.helpers.*;
import java.util.LinkedList;


public class MySaxHandler extends DefaultHandler {
    public static void main(String[] args) {

        // Cesta ke zdrojovÃ©mu XML dokumentu
        String sourcePath = "data.xml";

        try {

            // VytvorÃ­me instanci parseru.
            XMLReader parser = XMLReaderFactory.createXMLReader();

            // VytvorÃ­me vstupnÃ­ proud XML dat.
            InputSource source = new InputSource(sourcePath);

            // NastavÃ­me nÃ¡Ä… vlastnÃ­ content handler pro obsluhu SAX udÃ¡lostÃ­.
            MujContentHandler mch = new MujContentHandler();
            parser.setContentHandler(mch);

            // Zpracujeme vstupnÃ­ proud XML dat.
            parser.parse(source);



        } catch (Exception e) {

            e.printStackTrace();

        }

    }

}

/**
 * NÃ¡Å¡ vlastnÃ­ content handler pro obsluhu SAX udÃ¡lostÃ­.
 * Implementuje metody interface ContentHandler.
 */
class MujContentHandler implements ContentHandler {

    // UmoÅ¾Åˆuje zacÃ­lit mÃ­sto v dokumentu, kde vznikla aktualnÃ­ udÃ¡lost
    Locator locator;
    int element = 0;
    int attribute = 0;
    LinkedList<Integer> depth = new LinkedList();
    int deep = 1;

    /**
     * NastavÃ­ locator
     */
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Obsluha udÃ¡losti "zaÄÃ¡tek dokumentu"
     */
    public void startDocument() throws SAXException {

        // ...
         System.out.println("Zacatek dokumentu\n\n");

    }
    /**
     * Obsluha udÃ¡losti "konec dokumentu"
     */
    public void endDocument() throws SAXException {

        // ...
        int max = 0;
        int sum = 0;
        int len = depth.size();
        while(depth.size()>0){
            sum += depth.getFirst();
            if(depth.getFirst()>max){
                max = depth.getFirst();
            }
            depth.pop();
        }
        System.out.println("\n\nKonec dokumentu\n");
        System.out.println("Maximalni hloubka: "+max);
        System.out.println("Prumerna hloubka: "+(sum/len));
        System.out.println("Pocet elementu: "+element);
        System.out.println("Pocet atributu: "+attribute);


    }

    /**
     * Obsluha udÃ¡losti "zaÄÃ¡tek elementu".
     * @param uri URI jmennÃ©ho prostoru elementu (prÃ¡zdnÃ©, pokud element nenÃ­ v Å¾Ã¡dnÃ©m jmennÃ©m prostoru)
     * @param localName LokÃ¡lnÃ­ jmÃ©no elementu (vÅ¾dy neprÃ¡zdnÃ©)
     * @param qName KvalifikovanÃ© jmÃ©no (tj. prefix-uri + ':' + localName, pokud je element v nÄ›jakÃ©m jmennÃ©m prostoru, nebo localName, pokud element nenÃ­ v Å¾Ã¡dnÃ©m jmennÃ©m prostoru)
     * @param atts Atributy elementu
     */
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        // ...
        System.out.print("<"+qName+attributes(atts)+"> ");

        element++;
        deep++;
    }
    /**
     * Obsluha udÃ¡losti "konec elementu"
     * Parametry majÃ­ stejnÃ½ vÃ½znam jako u @see startElement
     */
    public void endElement(String uri, String localName, String qName) throws SAXException {

        // ...
        System.out.print(" </"+qName+">");
        depth.add(deep);
        deep = 1;

    }

    private String attributes(Attributes atts) {
        if(atts.getLength()>0){
            attribute++;
        }

        StringBuffer buffer = new StringBuffer();
        for(int i=0; i<atts.getLength(); i++) {
            buffer.append(" ");
            buffer.append(atts.getQName(i));
            buffer.append("=\"");
            buffer.append(atts.getValue(i));
            buffer.append("\"");
        }
        return buffer.toString();
    }

    /**
     * Obsluha udÃ¡losti "znakovÃ¡ data".
     * SAX parser muÄ¾e znakovÃ¡ data dÃ¡vkovat jak chce. Nelze tedy poÄÃ­tat s tÃ­m, Å¾e je celÃ½ text dorucen v rÃ¡mci jednoho volÃ¡nÃ­.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakovÃ½mi daty
     * @param start Index zacÃ¡tku Ãºseku platnÃ½ch znakovÃ½ch dat v poli.
     * @param length DÃ©lka Ãºseku platnÃ½ch znakovÃ½ch dat v poli.
     */
    public void characters(char[] ch, int start, int length) throws SAXException {
        // ...
        String s = "";

        for(int i=start; i<start+length; i++) {
            s += ch[i];
        }
        //text += s;
        System.out.print(s);

    }

    /**
     * Obsluha udÃ¡losti "deklarace jmennÃ©ho prostoru".
     * @param prefix Prefix prirazenÃ½ jmennÃ©mu prostoru.
     * @param uri URI jmennÃ©ho prostoru.
     */
    public void startPrefixMapping(String prefix, String uri) throws SAXException {

        // ...

    }

    /**
     * Obsluha udÃ¡losti "konec platnosti deklarace jmennÃ©ho prostoru".
     */
    public void endPrefixMapping(String prefix) throws SAXException {

        // ...

    }

    /**
     * Obsluha udÃ¡losti "ignorovanÃ© bÃ­lÃ© znaky".
     * StejnÃ© chovÃ¡nÃ­ a parametry jako @see characters
     */
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {

        // ...

    }

    /**
     * Obsluha udÃ¡losti "instrukce pro zpracovÃ¡nÃ­".
     */
    public void processingInstruction(String target, String data) throws SAXException {

      // ...

    }

    /**
     * Obsluha udÃ¡losti "nezpracovanÃ¡ entita"
     */
    public void skippedEntity(String name) throws SAXException {

      // ...

    }
}
