package user;



import org.w3c.dom.*;


public class MyDomTransformer {

    public NodeList list;
    public NodeList list2;




    /**
     * Zpracuje DOM strom
     */
    public void transform(Document doc) {
       //ODSTRANI OBSAH ELEMENTU TEXT
       list = doc.getElementsByTagName("TEXT");
       for(int i = 0; i < list.getLength(); i++){
            list.item(i).setTextContent("");
       }

       //ODSTRANI ELEMENTY TELEFON
       removeAll(doc, Node.ELEMENT_NODE, "TELEFON");


       //PRIDA DO ELEMENTU MESTO ATRIBUT PSC A VLOZI DO NEJ HODNOTY Z ELEMNTU PSC, KTERE POTE SMAZE
       list = doc.getElementsByTagName("MESTO");
       list2 = doc.getElementsByTagName("PSC");
       for(int i = 0; i < list.getLength(); i++){
            Element e = (Element) list.item(i);
            e.setAttribute("PSC", list2.item(i).getTextContent());
       }
       removeAll(doc, Node.ELEMENT_NODE, "PSC");



    }


    public static void removeAll(Node node, short nodeType, String name) {
        if (node.getNodeType() == nodeType &&
                (name == null || node.getNodeName().equals(name))) {
            node.getParentNode().removeChild(node);
        } else {
        // Visit the children
        NodeList list3 = node.getChildNodes();
        for (int i=0; i<list3.getLength(); i++) {
            removeAll(list3.item(i), nodeType, name);
            }
        }
    }
}

