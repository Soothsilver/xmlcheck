package user;

/**
 * DOM priklady na zpracovani XML.
 * Jako prvni ukol smaze vsechny hrace mensi 195.
 * Zadruhe prida zcela noveho hrace se vsemi potrebnymi parametry.
 */

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

/**
 * ASSIGNMENT: Update document to be able to transform input XML document to
 * output document by actions mentioned in comments of processTree method.
 */
public class MyDomTransformer {

    private static final String INPUT_FILE = "data.xml";
    private static final String OUTPUT_FILE = "data.out.xml";

    /**
     * Main method
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {

        try {

            // DocumentBuilderFactory creates DOM parsers
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            // We don't want to validate file
            dbf.setValidating(false);

            // Creating of DOM parser instance
            DocumentBuilder builder = dbf.newDocumentBuilder();

            // Parser processes input file and creates a DOM tree of objects
            Document doc = builder.parse(INPUT_FILE);

            // DOM tree processing
            processTree(doc);

            // TransformerFactory creates an object for DOM serialization
            TransformerFactory tf = TransformerFactory.newInstance();

            // Transformer serializes DOM tree
            Transformer writer = tf.newTransformer();

            // Setting of output file encoding
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            // Run transformation of DOM tree to XML document
            writer.transform(new DOMSource(doc), new StreamResult(new File(OUTPUT_FILE)));


        } catch (Exception e) {

            e.printStackTrace();

        }
    }

    /**
     * Process document tree
     *
     * @param doc Document to be parsed
     */
    private static void processTree(Document doc) {
        //Smazani vsech hracu nizsich 195 cm.
        Node playersElement = doc.getElementsByTagName("Players").item(1);
        NodeList players = doc.getElementsByTagName("Player");
        for (int i = 0; i < players.getLength() ; i++)
        {
            Element player = (Element) players.item(i);
            Element height = (Element) player.getElementsByTagName("Height").item(0);
            if (Integer.parseInt(height.getTextContent()) < 195)
            {
                player.getParentNode().removeChild(player);
                i--;
            }
        }
        
        //Vytvoreni noveho hrace se vsemi parametry.
        Element player = (Element) playersElement.appendChild(doc.createElement("Player"));
        player.setAttribute("name", "The Added One");
        player.setAttribute("team_id", "t_02");
        player.appendChild(doc.createElement("Age")).setTextContent("22");
        player.appendChild(doc.createElement("Phone")).setTextContent("723848523");
        player.appendChild(doc.createElement("Email")).setTextContent("to.j@centrum.cz");
        player.appendChild(doc.createElement("Height")).setTextContent("185");
    }
}
