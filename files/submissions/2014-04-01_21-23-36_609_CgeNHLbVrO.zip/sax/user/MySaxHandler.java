package user;

/**
 * SAX dotazy.
 * 1) Tri nejcastejsi krestni jmena.
 * 2) Prumerna vyska vsech hracu.
 * 3) Lidi, kteri hrajou za Spartu, meri 1,9+ metru a je jim 30+.
 */
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 * Main class for SAX parsing
 *
 * @author XML Technologies
 */
public class MySaxHandler {

    // Path to input file
    private static final String INPUT_FILE = "data.xml";
    

    /**
     * Main method
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {



        try {

            // Create parser instance
            XMLReader parser = XMLReaderFactory.createXMLReader();

            // Create input stream from source XML document
            InputSource source = new InputSource(INPUT_FILE);

            // Set our custom content handler for handling SAX events (it must implements ContentHandler interface)
            parser.setContentHandler(new CustomContentHandler());

            // Process input data
            parser.parse(source);

        } catch (Exception e) {

            e.printStackTrace();

        }

    }
}

/**
 * Out custom content handler for managing SAX events Implements methods of the
 * abstract class ContentHandler.
 * @see http://www.saxproject.org/apidoc/org/xml/sax/ContentHandler.html#processingInstruction%28java.lang.String,%20java.lang.String%29
 */
class CustomContentHandler implements ContentHandler {
    
    static Map<String,Integer> krestniJmena = new HashMap<String, Integer>();
    static int numberOfPlayers = 0;
    static int sumOfHeights = 0;
    boolean isParsingHeight = false;
    boolean isParsingAge = false;
    final StringBuilder builder = new StringBuilder();
    final StringBuilder targetPlayers = new StringBuilder();
    String currentPlayer = "";
    boolean playsForSparta = false;
    boolean ourPlayer = false;

    // Helper variable to store location of the handled event
    Locator locator;

    /**
     * Sets the locator
     *
     * @param Locator locator location in the file
     */
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Method to handle "document start"
     *
     * @throws SAXException
     */
    @Override
    public void startDocument() throws SAXException {
        // ...
    }

    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
        // ...
        List mapKeys = new ArrayList(krestniJmena.keySet());
        List mapValues = new ArrayList(krestniJmena.values());
        Collections.sort(mapValues);
        Collections.sort(mapKeys);

        LinkedHashMap sortedMap = new LinkedHashMap();

        Iterator valueIt = mapValues.iterator();
        while (valueIt.hasNext()) 
        {
            Object val = valueIt.next();
            Iterator keyIt = mapKeys.iterator();

            while (keyIt.hasNext()) 
            {
                Object key = keyIt.next();
                String comp1 = krestniJmena.get(key).toString();
                String comp2 = val.toString();

                if (comp1.equals(comp2))
                {
                    krestniJmena.remove(key);
                    mapKeys.remove(key);
                    sortedMap.put((String)key, (Integer)val);
                    break;
                }
            }
        }
        Object[] wow = sortedMap.keySet().toArray();
        String theMostUsedFirstNames = "";
        
        for (int i = wow.length - 1; i >= wow.length - 3; i--)
        {
            if (i < 0) continue;
            theMostUsedFirstNames += "\"" + wow[i] + "\", ";
        }

        System.out.print("Tri nejcastejsi pouzita krestni jmena vsech hracu: " + theMostUsedFirstNames + "\n");
        System.out.print("Prumerna vyska vsech hracu: " + sumOfHeights/numberOfPlayers + "\n");
        System.out.print("Hraci za Spartu, kterym je 30+ a meri 190+ cm: " + targetPlayers.toString() + "\n");
    }

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        // ...
        if (localName.toLowerCase().equals("player"))
        {
            for (int i = 0; i < atts.getLength(); i++) 
            {
                String name = atts.getLocalName(i);
                String playerName = atts.getValue(i).toString();
                String firstName = playerName.split(" ")[0];
                if (name.toLowerCase().equals("name"))
                {
                    currentPlayer = playerName;
                    if (krestniJmena.containsKey(firstName))
                    {
                        krestniJmena.put(firstName, krestniJmena.get(firstName) + 1);
                    }
                    else
                    {
                        krestniJmena.put(firstName, 1);
                    }
                }
                if (name.toLowerCase().equals("team_id"))
                {
                    if (firstName.equals("t_00"))
                    {
                        playsForSparta = true;
                    }
                }
            }
        }
        if (localName.toLowerCase().equals("height"))
        {
            isParsingHeight = true;
            numberOfPlayers++;
        }
        if (localName.toLowerCase().equals("age"))
        {
            isParsingAge = true;
        }
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        // ...
        if (isParsingAge)
        {
            int age = Integer.parseInt(builder.toString());
            if (age >= 30) ourPlayer = true;
            isParsingAge = false;
            builder.setLength(0);
        }
        if (isParsingHeight)
        {
            int height = Integer.parseInt(builder.toString());
            if (height >= 190 && ourPlayer && playsForSparta)
            {
                ourPlayer = false;
                playsForSparta = false;
                targetPlayers.append("\"" + currentPlayer + "\", ");
            }
            isParsingHeight = false;
            sumOfHeights += height;
            builder.setLength(0);
        }
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        // ...
        if (isParsingHeight)
        {
            builder.append(new String(chars, start, length));
        }
        if (isParsingAge)
        {
            builder.append(new String(chars, start, length));
        }
    }

    /**
     * Method to handle " start of namespace declaration"
     *
     * @param prefix Prefix of the namespace
     * @param uri URI of the namespace
     * @throws SAXException
     */
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    /**
     * Method to handle "end of namespace declaration"
     *
     * @param prefix
     * @throws SAXException
     */
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    /**
     * Method to handle "ignoring of whitespaces" Text is in array 'chars' from
     * position ('start') to ('start' + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     * @throws SAXException
     */
    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
        // ...
    }

    /**
     * Method to handle "processing instructions"
     *
     * @param target The processing instruction target
     * @param data  The processing instruction data
     * @throws SAXException
     */
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

    /**
     * Method to handle "unprocessed entity"
     *
     * @param name
     * @throws SAXException
     */
    @Override
    public void skippedEntity(String name) throws SAXException {
        // ...
    }
}
