package user;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

public class MyDomTransformer {

    public void transform(Document xmlDocument) {
        //pridame noveho sportovce
        Element sportovec = (Element) xmlDocument.createElement("sportovec");
        sportovec.setAttribute("tren_ref", "t03");
        sportovec.setAttribute("sport_id", "s_04");
        sportovec.appendChild(xmlDocument.createElement("jmeno")).setTextContent("Roman");
        sportovec.appendChild(xmlDocument.createElement("prijmeni")).setTextContent("Furst");
        sportovec.appendChild(xmlDocument.createElement("vek")).setTextContent("23");
        Element adresa = (Element) xmlDocument.createElement("adresa");
        sportovec.appendChild(adresa);
            adresa.appendChild(xmlDocument.createElement("ulice")).setTextContent("Mostecka");
            Element mesto = (Element) xmlDocument.createElement("mesto");
                mesto.setAttribute("psc", "41501");
                mesto.setTextContent("Teplice");
            adresa.appendChild(mesto);
        sportovec.appendChild(xmlDocument.createElement("telefon")).setTextContent("602765488");
        sportovec.appendChild(xmlDocument.createElement("plat")).setTextContent("26000kc");
        sportovec.appendChild(xmlDocument.createElement("vaha")).setTextContent("73kg");
        sportovec.appendChild(xmlDocument.createElement("vyska")).setTextContent("182cm");
        Element seznam_veci = (Element) xmlDocument.createElement("seznam_veci");
        sportovec.appendChild(seznam_veci);
            Element dres = (Element) xmlDocument.createElement("dres");
            dres.setAttribute("velikost", "XL");
            seznam_veci.appendChild(dres);
            Element kratasy = (Element) xmlDocument.createElement("kratasy");
            kratasy.setAttribute("velikost", "XL");
            seznam_veci.appendChild(kratasy);
            Element boty = (Element) xmlDocument.createElement("boty");
            seznam_veci.appendChild(boty);
                boty.appendChild(xmlDocument.createElement("cislo")).setTextContent("42");
         Element disciplina = (Element) xmlDocument.createElement("disciplina");
         disciplina.setAttribute("druh", "vytrvalec");
         sportovec.appendChild(disciplina);
         
         NodeList n = xmlDocument.getElementsByTagName("sportovni_oddil");
         Element sportovni_oddil;
         if(n.getLength()==0){
             sportovni_oddil = xmlDocument.createElement("sportovni_oddil");
             xmlDocument.getFirstChild().appendChild(sportovni_oddil);
         }else
            sportovni_oddil = (Element) n.item(0);
                  
         sportovni_oddil.appendChild(sportovec);
         
         
         //smazeme sportovce s platem nizsi nes 20tis
         NodeList sportovci = xmlDocument.getElementsByTagName("sportovec");
         for(int i=0; i<sportovci.getLength();i++){
             sportovec = (Element)sportovci.item(i);
             Element plat = (Element) sportovec.getElementsByTagName("plat").item(0);
             String plt = plat.getTextContent();
             plt = plt.substring(0, plt.length()-2); //nechceme posledni dva znaky kc
             int mzda = Integer.parseInt(plt);
             
             if(mzda<20000){
                 sportovec.getParentNode().removeChild(sportovec);
             }
         }
         
                
        
        
    }
}
