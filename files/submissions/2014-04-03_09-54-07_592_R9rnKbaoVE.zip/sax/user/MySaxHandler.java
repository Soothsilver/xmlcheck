
/*
 *  Furst Roman
 * - z obsahu atributu zjistuji kdo jakou ma velikost dresu a pak vypisu pocet jednotlivych velikosti
 * - z obsahu elementu zjistuji mzdu a pote vypisu prumernou mzdu
 * - vypis jmena sportovcu kteri jsou sprinteri a trenuje je trener t01
*/

package user;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

public class MySaxHandler extends DefaultHandler {
    private int S=0,M=0,L=0,XL=0;
    private int mzda = 0;
    private int pocetUvazku = 0;
    private StringBuffer curCharValue = new StringBuffer(1024);
    
    private ArrayList<String> trener = new ArrayList<String>();
    private ArrayList<String> disciplina = new ArrayList<String>();
    private ArrayList<String> sportovec = new ArrayList<String>();

    @Override
    public void startDocument() throws SAXException {
        super.startDocument();
    }

    @Override
    public void endDocument() throws SAXException {
        if(S!=0) System.out.println("Je treba objednat " + S + " dresu velikosti S");
        if(M!=0) System.out.println("Je treba objednat " + M + " dresu velikosti M");
        if(L!=0) System.out.println("Je treba objednat " + L + " dresu velikosti L");
        if(XL!=0) System.out.println("Je treba objednat " + XL + " dresu velikosti XL");
        
        System.out.println("\nPrumerna mzda je " + mzda/pocetUvazku + " kc");
        
        findSportsmen();
        
    }
    
    void findSportsmen(){
        System.out.println("\nTrener t01 trenuje nasledujici sprintery :");
        for(int i=0;i<trener.size();i++){
            if(trener.get(i).equals("t01") && disciplina.get(i).equals("sprinter")){
                System.out.println(sportovec.get(i));
            }
                
        }
    
    }

    
    
    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        if(qName.equals("dres") && attributes.getValue(0).equals("S")) S++;
        if(qName.equals("dres") && attributes.getValue(0).equals("M")) M++;
        if(qName.equals("dres") && attributes.getValue(0).equals("L")) L++;
        if(qName.equals("dres") && attributes.getValue(0).equals("XL")) XL++;
        if(qName.equals("plat"))curCharValue.delete(0, curCharValue.length()); //vymazeme obsah bufferu
        
        if(qName.equals("sportovec") ) trener.add(attributes.getValue(1)); //ulozime id trenera do arrayListu
        if(qName.equals("trener") ) { trener.add("XX"); disciplina.add("XX");} //pokud se jedna o trenera do arraylistu pridame neplatne hodnoty
        if(qName.equals("jmeno"))curCharValue.delete(0, curCharValue.length()); //vymazeme obsah bufferu
        if(qName.equals("disciplina") ) disciplina.add(attributes.getValue(0)); //ulozime id trenera do arrayListu
    
        
        
        
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        //already synchronized
        curCharValue.append(ch, start, length); 
        //curCharValue.
    }
    
    

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if(qName.equals("plat")){ 
            String plat = curCharValue.substring(0, curCharValue.length()-2).toString(); //nechceme posledni dva znakz "kc"
            pocetUvazku++;
            mzda += Integer.parseInt(plat);
        }
        if(qName.equals("jmeno")){ 
            curCharValue.append(" ");
        }
        
        if(qName.equals("prijmeni")){ 
            String jmen = curCharValue.toString();
            sportovec.add(jmen);
        }
        
    }
    
    

    
    
    
   
    
    

    
      
    }
    

