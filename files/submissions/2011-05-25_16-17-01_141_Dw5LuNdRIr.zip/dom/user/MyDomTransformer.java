package user;

import org.w3c.dom.Document;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

/**
 * 
 * Prepise vsechny atributy na elementy stejn�ho jm�na a se stejn�m textov�m obsahem
 *	
 */

public class MyDomTransformer {

    private static final String VSTUPNI_SOUBOR = "letenky.xml";
    private static final String VYSTUPNI_SOUBOR = "letenky.out.xml";

    public void transform(Document doc) {

    	Node rootNode = doc.getChildNodes().item(0);
    		
    	zpracujUzel(rootNode, doc);
        attsToNodes(rootNode, doc); 
    }
    
    public void attsToNodes(Node node, Document doc)
    {
    	NamedNodeMap nnm = node.getAttributes();
    	
    	if (nnm == null) return;
    	
    	int length = nnm.getLength();
    	
    	for (int i = 0; i < length; ++i)
    	{
    		Node attr = nnm.item(i);
    		String attName = attr.getNodeName();
    		String attValue = attr.getNodeValue();
    		
    		Node newChild = doc.createElement(attName);
    		
    		Text nametextNode = doc.createTextNode(attValue);
    		newChild.appendChild(nametextNode);

    		node.appendChild(newChild);
    	}   
    	
    	for (int i = length - 1; i >= 0; --i)
    	{
    		Element nodeAsElement = (Element)node;
    		nodeAsElement.removeAttributeNode((Attr)nnm.item(i));
    	}
    }
    
    public void zpracujUzel(Node node, Document doc)
    {
    	NodeList nl = node.getChildNodes();
    	
    	int l = nl.getLength();
    	
    	for (int i = 0; i < l; ++i)
    	{
    		zpracujUzel(nl.item(i), doc);
    	}
    	
    	attsToNodes(node, doc);
    	
    }
}