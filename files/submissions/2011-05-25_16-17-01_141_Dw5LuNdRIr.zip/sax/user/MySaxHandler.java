package user;

import org.xml.sax.helpers.DefaultHandler;

import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;


/**
 * 
 * Urci pocet atributu, ktere nespecifikuji xmlns
 * Spocte prumernou delku nazvu elementu
 * 
 */

public class MySaxHandler extends DefaultHandler  {

    Locator locator;
    int pocetAttributu = 0;
    int delkaVsechNazvu = 0;
    int pocetProjitychElementu = 0;
    
    public void setDocumentLocator(Locator locator) 
    {
        this.locator = locator;
    }
  
    public void startDocument() throws SAXException 
    {
        
    }
     
    public void endDocument() throws SAXException 
    {
    	System.out.print ("Pocet tributu, ktere nespecifikuji xmlns, v celem dokumentu: ");
    	System.out.println (pocetAttributu);
    	
    	if (pocetProjitychElementu > 0)
    	{
    		System.out.print ("Prumerna delka nazvu elementu: ");
        	System.out.println (delkaVsechNazvu / (double)pocetProjitychElementu);
    	}
    	else
    	{
    		System.out.print ("Prumernou delku nazvu elementu nebylo mozne zjistit, nebot zadne elementy nebyly nalezeny.");
    	}
    }
    
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException 
    {
    	pocetAttributu += atts.getLength();
    	pocetProjitychElementu++;
    	delkaVsechNazvu += localName.length();
    }
    
   
    public void endElement(String uri, String localName, String qName) throws SAXException {}
    
    public void characters(char[] ch, int start, int length) throws SAXException {}
    
    public void startPrefixMapping(String prefix, String uri) throws SAXException {}
  
    public void endPrefixMapping(String prefix) throws SAXException {}
   
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {}
     
    public void processingInstruction(String target, String data) throws SAXException {}
       
    public void skippedEntity(String name) throws SAXException {}
}