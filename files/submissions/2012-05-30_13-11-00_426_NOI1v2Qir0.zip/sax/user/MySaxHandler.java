package user; 

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;


/** Spocita prumerny pocet exemplaru u titulu a vysledek vypise na konzoli.
 * @author Jaroslav Kotrc
 */
public class MySaxHandler extends DefaultHandler {
	public static final String titles = "tituly";
	public static final String title = "titul";
	public static final String book = "kniha";
	public static final String cd = "cd";
	
	private int exemplarCnt = 0;
	private int titleCnt = 0;
	
    public void endDocument() throws SAXException {
    	String str;
        if(titleCnt == 0){
        	str = "V knihovne neni zadny titul;";
        } else {
        	double average = exemplarCnt / (double) titleCnt;
        	str = "Prumerny pocet exemplaru na titul je " + average; 
        }
        System.out.println(str);
    } 
    
    private boolean processingTitles = false;
    private boolean processingTitle = false;
    
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
    	
    	if(localName.equals(titles)){
    		//zacatek seznamu titulu
    		processingTitles = true;
    	} else if(processingTitles && (processingTitle == false) && (localName.equals(title))){
    		//zacatek titulu v seznamu
    		processingTitle = true;
    		++titleCnt;
    	} else if(processingTitles && (processingTitle == true) && (localName.equals(book) || localName.equals(cd))){
    		//vyskyt exemplare
    		++exemplarCnt;
    	}
    }
    
    
    public void endElement(String uri, String localName, String qName) throws SAXException {
    	if(localName.equals(titles)){
    		//konci seznam titulu
    		processingTitles=false;
    	} else if(processingTitles && (processingTitle == true) && (localName.equals(title))){
    		//konci jeden titul v seznamu
    		processingTitle = false;
    	}

    }
}