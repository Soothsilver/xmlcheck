package user; 

import java.util.LinkedList;
import java.util.List;

import org.w3c.dom.Document; 
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


/** Transformace prevede vsechny CD na typ knihy, ponecha signaturu a jako 
 * pocet stran nastavi puvodni delku CD
 * @author Jaroslav Kotrc
 */
public class MyDomTransformer { 
	private static final String titles = "tituly";
	private static final String exemplars = "exemplare";
	private static final String cd = "cd";
	private static final String book = "kniha";
	private static final String signature = "signatura";
	private static final String pages = "stran";
	
	public void transform (Document xmlDocument) {
		NodeList list = xmlDocument.getElementsByTagName(titles);
		for(int idx = 0; idx < list.getLength(); ++idx){
    		processTitles((Element)list.item(idx), xmlDocument);
    	} 
	}

	private void processTitles(Element item, Document xmlDocument) {
		NodeList list = item.getElementsByTagName(exemplars);
		for(int idx = 0; idx < list.getLength(); ++idx){
    		processExemplars((Element)list.item(idx), xmlDocument);
		} 
	}

	private void processExemplars(Element item, Document xmlDocument) {
		NodeList list = item.getElementsByTagName(cd);
		List<Node> cds = new LinkedList<Node>();
		List<Node> books = new LinkedList<Node>();
		for(int idx = 0; idx < list.getLength(); ++idx){
			Node node = list.item(idx);
			cds.add(node);
			
			Element element = xmlDocument.createElement(book);
			element.setAttribute(signature, node.getAttributes().getNamedItem(signature).getNodeValue());
			Element pagesElement = xmlDocument.createElement(pages);
			pagesElement.setTextContent(node.getTextContent());
			element.appendChild(pagesElement);

			books.add(element);
    	}
		for(Node n : cds){
			item.removeChild(n);
		}
		for(Node n : books){
			item.appendChild(n);
		}
	} 
}