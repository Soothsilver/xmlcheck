package user;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {

	private boolean inName = false;
    private boolean inMessage = false;
    private String currencyCode = null;
    private String currencyName = null;
    private Float transactionSum = 0f;
    private Integer messageSeq = 0;
    private Integer messageLengthMean = 0;
    
    // map of currency codes and currency names;
    private Map<String, String> currencyMap = new HashMap<String, String>();
    private List<String> currencies = new ArrayList<String>();
    private boolean isMineable = false;
    private List<String> mineableCurrenciesOccuredInMessage = new ArrayList<String>();
	
	@Override
	public void setDocumentLocator(Locator locator) {
		super.setDocumentLocator(locator);
	}
	
	@Override
    public void endDocument() throws SAXException {
		System.out.println();
    	System.out.print("Currencies that are mineable and are mentioned in a message are: ");
    	for(String s : mineableCurrenciesOccuredInMessage){
    		System.out.print(s + ", ");
    	}
    	System.out.println();
    	System.out.println();
        System.out.println("Mean of the length of a message is " + messageLengthMean/messageSeq);
    }
	
	@Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if(localName.equals("name")){
        	inName = true;
        	transactionSum = 0f;
        }
        else if(localName.equals("transaction")){
        	String volume = atts.getValue("volume");
        	transactionSum += Float.parseFloat(volume);
        }
        else if(localName.equals("message")){
        	inMessage = true;
        	++messageSeq;
        }
        else if(localName.equals("currency")){
        	currencyCode = atts.getValue("code");
        	String mineable = atts.getValue("mineable");
        	isMineable = Boolean.parseBoolean(mineable);
        }
        else if(localName.equals("curr")){
        	String currencyName = currencyMap.get(atts.getValue("code"));
        	if(currencies.contains(currencyName)){
        		mineableCurrenciesOccuredInMessage.add(currencyName);
        	}
        }
    }
	
	@Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
    	if(localName.equals("name")){
        	inName = false;
        }
    	else if(localName.equals("currency")){
    		System.out.println(transactionSum + " " + currencyName + " traded last minute.");
    		if(isMineable) currencies.add(currencyName);
    		currencyMap.put(currencyCode, currencyName);
    	}
    	else if(localName.equals("message")){
    		inMessage = false;
    	}
    }
	
	@Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        if(inName){
        	currencyName = new String(chars, start, length);
        }
        else if(inMessage){
        	String message = new String(chars, start, length);
        	messageLengthMean += message.length();
        }
    }
	
}
