package user;

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

import java.util.*;

public class MySaxHandler extends DefaultHandler {	
	// Testovanie
	public static void main(String[] args) {
        try {
        	String INPUT_FILE = "data.xml";
        	
        	// Create parser instance
            XMLReader parser = XMLReaderFactory.createXMLReader();

            // Create input stream from source XML document
            InputSource source = new InputSource(INPUT_FILE);

            // Set our custom content handler for handling SAX events (it must implements ContentHandler interface)
            parser.setContentHandler(new MySaxHandler());

            // Process input data
            parser.parse(source);                                    

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	// Vlastne sucasti
	List<String> championsAllTypes;
	String abecednePoslednyChampion;
	Map<String, Integer> vyskytSlovItems;	
	boolean nowReadingChampion;
	boolean nowReadingAbilityType;
	boolean abilityToggle;
	boolean abilityActive;
	boolean abilityPassive;
	String tempChampionName;
	public MySaxHandler() {
		championsAllTypes = new ArrayList<String>();
		abecednePoslednyChampion = "<no champions defined>";
		vyskytSlovItems = new TreeMap<String, Integer>();
		nowReadingChampion = false;
		nowReadingAbilityType = false;
		abilityToggle = false;
		abilityActive = false;
		abilityPassive = false;
	}	
	private void PrerozdelAPridajSlova(String myString) {
		int i;
		String subPart;
		while ((i = myString.indexOf(" ")) != -1) {
			subPart = myString.substring(0, i);
			pridajSlovo(subPart);
			myString = myString.substring(i+1);
		} 
		pridajSlovo(myString);
		
	}
	private void pridajSlovo(String subPart) {
		int j = 0;
		if (vyskytSlovItems.containsKey(subPart)) j = vyskytSlovItems.get(subPart);
		vyskytSlovItems.put(subPart, j+1);
	}	
	
	// Locator
    Locator locator;
        
	// SetDocumentLocator
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    } 

    // EndDocument
    @Override
    public void endDocument() throws SAXException {
        // #1 Najcastejsie sa vyskytujuce slovo ako hodnota atributu <Item Name="string"> (t.j. slovo v "string")
    	String mostFrequent = null;
    	for(Map.Entry<String, Integer> entry: vyskytSlovItems.entrySet()) {    		
    		if (mostFrequent != null) {
    			if (entry.getValue() > vyskytSlovItems.get(mostFrequent)) mostFrequent = entry.getKey();
    		} else {
    			mostFrequent = entry.getKey();
    		}
    	}
    	System.out.println("Najcastejsie slovo v mene item-ov: " + mostFrequent);
    	
    	// #2 Najde meno sampiona, ktory je v abecednom poradi posledny, medzi <ChampionName>string</ChampionName>
    	System.out.println("Abecedne posledny sampion: " + abecednePoslednyChampion);
    	
    	// #3 Vypise sampionov, ktori maju vsetky 3 typy ability, t.j. <Type>string</Type> v <Ability><AbilitySpecification>... nabera hodnoty: Toggle, Active, Passive. (Celkovo ma kazdy sampion prave 5 ability.)
    	System.out.println("Sampioni so vsetkymi typmi ability:");
    	for (String champName : championsAllTypes) {
    		System.out.println("   " + champName);
    	}
    }

    // StartElement
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
    	// #1    	
    	if (qName.equals("Item")) {
    		for (int i = 0; i < atts.getLength(); i++) {
    			if (atts.getQName(i).equals("Name")) {
    				PrerozdelAPridajSlova(atts.getValue(i));
    			}    			
    		}
    	}
    	
    	// #2
    	if (qName.equals("ChampionName")) nowReadingChampion = true;
    	
    	// #3
    	if (nowReadingChampion) {
    		abilityToggle = false;
    		abilityActive = false;
    		abilityPassive = false;
    	}	
    	if (qName.equals("Type")) nowReadingAbilityType = true;   
    }

    // EndElement
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {    	    	
    	// #2
    	nowReadingChampion = false;
    	
    	// #3
    	nowReadingAbilityType = false;
    	if (qName.equals("Champion")) {
    		if (abilityToggle && abilityActive && abilityPassive) {
    			championsAllTypes.add(tempChampionName);
    		}
    	}    
    }

    // Characters
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {    	
    	char[] charArrToReturn = new char[length];
    	boolean allWhiteSpaces = true;
    	for (int i = 0; i < length; i++) {    		
    		if (!Character.isWhitespace(charArrToReturn[i] = chars[start+i])) allWhiteSpaces = false;    		
    	}
    	String returnedString;
    	if (allWhiteSpaces) returnedString = ""; else returnedString = new String(charArrToReturn);   
    	
    	// #2
    	if (nowReadingChampion) {    		
    		if (returnedString.compareTo(abecednePoslednyChampion) > 0) abecednePoslednyChampion = returnedString;
    	}
    	
    	// #3
    	if (nowReadingChampion) tempChampionName = returnedString;
    	if (nowReadingAbilityType) {
		if (returnedString.equals("Toggle")) abilityToggle = true;
		if (returnedString.equals("Active")) abilityActive = true;
		if (returnedString.equals("Passive")) abilityPassive = true;    		
    	}    	    
    }
    
}