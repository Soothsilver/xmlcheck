package user;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

public class MyDomTransformer {
	// Testovanie
	public static void main(String[] args) {
        try {
        	String INPUT_FILE = "data.xml";
        	String OUTPUT_FILE = "outputdata.xml";
        	
            // DocumentBuilderFactory creates DOM parsers
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            // We don't want to validate file
            dbf.setValidating(false);

            // Creating of DOM parser instance
            DocumentBuilder builder = dbf.newDocumentBuilder();

            // Parser processes input file and creates a DOM tree of objects
            Document doc = builder.parse(INPUT_FILE);

            // DOM tree processing
            MyDomTransformer mdt = new MyDomTransformer();
            mdt.transform(doc);

            // TransformerFactory creates an object for DOM serialization
            TransformerFactory tf = TransformerFactory.newInstance();

            // Transformer serializes DOM tree
            Transformer writer = tf.newTransformer();

            // Setting of output file encoding
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            // Run transformation of DOM tree to XML document
            writer.transform(new DOMSource(doc), new StreamResult(new File(OUTPUT_FILE)));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	public void transform (Document xmlDocument) {		
		// #1 Pridanie nov�ho �ampi�na		
		if (xmlDocument.getElementsByTagName("Champions").getLength() <= 0)  {			
			xmlDocument.getElementsByTagName("LeagueOfLegends").item(0).appendChild(xmlDocument.createElement("Champions"));			
		}
		Element ch, chtmp, chtmp2, chtmp3, chtmp4, chtmp5; 		
		xmlDocument.getElementsByTagName("Champions").item(0).appendChild(ch = xmlDocument.createElement("Champion"));
		ch.appendChild(chtmp = xmlDocument.createElement("ChampionName"));
		chtmp.setTextContent("Orianna");
		ch.appendChild(chtmp = xmlDocument.createElement("ChampionDescription"));
		chtmp.setTextContent("the Lady of Clockwork");
		ch.appendChild(chtmp = xmlDocument.createElement("ChampionAbilities"));
		// (ability: passive)
		chtmp.appendChild(chtmp2 = xmlDocument.createElement("Ability"));
		chtmp2.setAttribute("Order", "passive");
		chtmp2.appendChild(chtmp3 = xmlDocument.createElement("AbilityName"));
		chtmp3.setTextContent("Clockwork Windup");
		chtmp2.appendChild(chtmp3 = xmlDocument.createElement("AbilityDescription"));
		chtmp3.setTextContent("Orianna�s autoattacks deal 50 (+ 15% AP) bonus magic damage on hit. Subsequent attacks on the same target within 4 seconds deal an additional 20% magic damage. This bonus stacks up to 2 times, dealing a maximum of 70 (+ 21% AP) magic damage.");
		chtmp2.appendChild(chtmp3 = xmlDocument.createElement("AbilitySpecification"));
		chtmp3.appendChild(chtmp4 = xmlDocument.createElement("Type"));
		chtmp4.setTextContent("Passive");
		// (ability: 1)		
		chtmp.appendChild(chtmp2 = xmlDocument.createElement("Ability"));
		chtmp2.setAttribute("Order", "1");
		chtmp2.appendChild(chtmp3 = xmlDocument.createElement("AbilityName"));
		chtmp3.setTextContent("Command: Attack");
		chtmp2.appendChild(chtmp3 = xmlDocument.createElement("AbilityDescription"));
		chtmp3.setTextContent("Orianna commands the Ball to fly towards the target location, dealing magic damage to all enemies that the Ball passes through or that are in the target area. However, the Ball deals 10% less damage for each subsequent target hit down to a minimum of 40% damage done. After Command: Attack is used, the Ball remains behind at the target location.");
		chtmp2.appendChild(chtmp3 = xmlDocument.createElement("AbilitySpecification"));
		chtmp3.appendChild(chtmp4 = xmlDocument.createElement("Type"));
		chtmp4.setTextContent("Active");
		chtmp3.appendChild(chtmp4 = xmlDocument.createElement("Cooldown"));
		chtmp4.appendChild(chtmp5 = xmlDocument.createElement("Stable"));
		chtmp5.setTextContent("3");
		chtmp3.appendChild(chtmp4 = xmlDocument.createElement("Range"));
		chtmp4.setTextContent("825");
		chtmp3.appendChild(chtmp4 = xmlDocument.createElement("Cost"));
		chtmp4.setTextContent("50 MANA");
		// (ability: 2)		
		chtmp.appendChild(chtmp2 = xmlDocument.createElement("Ability"));
		chtmp2.setAttribute("Order", "2");
		chtmp2.appendChild(chtmp3 = xmlDocument.createElement("AbilityName"));
		chtmp3.setTextContent("Command: Dissonance");
		chtmp2.appendChild(chtmp3 = xmlDocument.createElement("AbilityDescription"));
		chtmp3.setTextContent("Orianna commands the Ball to emit an electric pulse around its current location, dealing magic damage to enemies within 250 range and leaving an electric field on the area for 3 seconds that speeds up allies and slows enemies that walk over it. This effect diminishes to normal over 2 seconds after leaving the area.");
		chtmp2.appendChild(chtmp3 = xmlDocument.createElement("AbilitySpecification"));
		chtmp3.appendChild(chtmp4 = xmlDocument.createElement("Type"));
		chtmp4.setTextContent("Active");
		chtmp3.appendChild(chtmp4 = xmlDocument.createElement("Cooldown"));
		chtmp4.appendChild(chtmp5 = xmlDocument.createElement("Stable"));
		chtmp5.setTextContent("9");		
		chtmp3.appendChild(chtmp4 = xmlDocument.createElement("Cost"));
		chtmp4.setTextContent("110 MANA");
		// (ability: 3)		
		chtmp.appendChild(chtmp2 = xmlDocument.createElement("Ability"));
	    chtmp2.setAttribute("Order", "3");
		chtmp2.appendChild(chtmp3 = xmlDocument.createElement("AbilityName"));
		chtmp3.setTextContent("Command: Protect");
		chtmp2.appendChild(chtmp3 = xmlDocument.createElement("AbilityDescription"));
		chtmp3.setTextContent("PASSIVE: The allied champion the Ball is currently attached to is granted bonus armor and magic resistance. ACTIVE: Orianna commands the Ball to fly to and attach onto an allied champion, dealing damage to enemies it passes through and shielding the allied champion for 4 seconds when it arrives");
		chtmp2.appendChild(chtmp3 = xmlDocument.createElement("AbilitySpecification"));
		chtmp3.appendChild(chtmp4 = xmlDocument.createElement("Type"));
		chtmp4.setTextContent("Active");
		chtmp3.appendChild(chtmp4 = xmlDocument.createElement("Cooldown"));
		chtmp4.appendChild(chtmp5 = xmlDocument.createElement("Stable"));
		chtmp5.setTextContent("9");		
		chtmp3.appendChild(chtmp4 = xmlDocument.createElement("Range"));
		chtmp4.setTextContent("1100");
		chtmp3.appendChild(chtmp4 = xmlDocument.createElement("Cost"));
		chtmp4.setTextContent("60 MANA");
		// (ability: 4)
		chtmp.appendChild(chtmp2 = xmlDocument.createElement("Ability"));
		chtmp2.setAttribute("Order", "3");
		chtmp2.appendChild(chtmp3 = xmlDocument.createElement("AbilityName"));
		chtmp3.setTextContent("Command: Shockwave");
		chtmp2.appendChild(chtmp3 = xmlDocument.createElement("AbilityDescription"));
		chtmp3.setTextContent("Orianna commands the Ball to unleash a shockwave after 0.5 seconds, dealing magic damage to enemies within 400 range and flinging them into the air 350 range towards, and possibly over, the Ball.");
		chtmp2.appendChild(chtmp3 = xmlDocument.createElement("AbilitySpecification"));
		chtmp3.appendChild(chtmp4 = xmlDocument.createElement("Type"));
		chtmp4.setTextContent("Active");
		chtmp3.appendChild(chtmp4 = xmlDocument.createElement("Cooldown"));
		chtmp4.appendChild(chtmp5 = xmlDocument.createElement("Stable"));
		chtmp5.setTextContent("90");		
		chtmp3.appendChild(chtmp4 = xmlDocument.createElement("Cost"));
		chtmp4.setTextContent("150 MANA");
		
		// #2 Zmazanie v�etk�ch Items, ktor� obsahuj� v n�zve slovo "of": napr. <Item id="ic_2010" Name="Total Biscuit of Rejuvenation" ... />
		NodeList items = xmlDocument.getElementsByTagName("Item");
		for (int i = 0; i < items.getLength(); i++) {			
			Element xx = (Element) items.item(i);
			if (xx.getAttribute("Name").indexOf("of") != -1) {
				xx.getParentNode().removeChild(xx);
				i--;
			}
		}						
	}
}