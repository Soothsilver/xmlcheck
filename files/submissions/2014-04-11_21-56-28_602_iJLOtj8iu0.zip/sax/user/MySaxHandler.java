package user;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

public class MySaxHandler extends DefaultHandler{
  int celkovaCena = 0;
  int pocetVyrobku = 0; 
  
  boolean cokolada = false;
  String precteno;
  Map<String, Integer> mapa = new HashMap<String, Integer>();
  
  boolean horka = false;
  boolean levna = false;
  int pocetCokolad = 0;
  
  @Override
  public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
    
    if(localName.equals("maloobchodni")){
      celkovaCena += Integer.parseInt(atts.getValue(0));
      pocetVyrobku++;
      
      if(cokolada && (Integer.parseInt(atts.getValue(0)) <= 100)) levna = true;
    }
    
    else if(localName.equals("cokolada")){
      cokolada = true;
    }
    
    else if(cokolada && localName.equals("typ")){
      if(atts.getValue(0).equals("horka")) horka = true;
    }
  }
  
  @Override
  public void endElement(String uri, String localName, String qName) throws SAXException {
  
    if(localName.equals("cokolada")){
      cokolada = false;
      
      if(horka && levna){
        pocetCokolad++;
      }
      horka = false;
      levna = false;
    } else if(cokolada && localName.equals("slozka")){
      int pocet = 0;
      if(mapa.containsKey(precteno)){pocet = mapa.get(precteno);}
      mapa.put(precteno, pocet+1);
    }
  }
  
  @Override
  public void characters(char[] chars, int start, int length) throws SAXException {
    precteno = new String(chars).substring(start, start+length).trim();  
  }
  
  
  @Override
  public void endDocument() throws SAXException {
    System.out.println("Prumerna maloobchodni cena vsech vyrobku: " + (float)celkovaCena/pocetVyrobku);
    
    int max = 0;
    String maxSlozka = "";
    Set<Map.Entry<String, Integer>> set = mapa.entrySet();
    for(Map.Entry<String, Integer> entry : set){
      if(entry.getValue() > max){
        max = entry.getValue();
        maxSlozka = entry.getKey();
      }
    }
    
    System.out.println("Nejcastejsi slozka cokolady: " + maxSlozka + " (" + max + "krat)");
    
    System.out.println("Pocet horkych cokolad s maloobchodni cenou do 100Kc: " + pocetCokolad);
  }  
}
