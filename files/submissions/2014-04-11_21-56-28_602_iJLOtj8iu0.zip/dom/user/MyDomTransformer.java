package user;
import org.w3c.dom.*;
public class MyDomTransformer {
  public static void transform (Document xmlDocument) {
    
    // Pridani rumu mezi vyrobky
    Element rum = xmlDocument.createElement("rum");
      rum.setAttribute("id", "RE38");
      Element jmeno = xmlDocument.createElement("jmeno");
        jmeno.setTextContent("Tuzemak");
      Element velikost = xmlDocument.createElement("velikost");
        velikost.setAttribute("objem", "0,5l");
      Element objemAlkoholu = xmlDocument.createElement("objemalkoholu");
        objemAlkoholu.setAttribute("value", "38%");  
      Element cenaVyrobku = xmlDocument.createElement("cenavyrobku");
        Element vyroba = xmlDocument.createElement("vyroba");
          vyroba.setAttribute("value", "20");
        Element maloobchodni = xmlDocument.createElement("maloobchodni");
          maloobchodni.setAttribute("value", "120");
        Element velkoobchodni = xmlDocument.createElement("velkoobchodni");
          velkoobchodni.setAttribute("value", "85");
        cenaVyrobku.appendChild(vyroba);  
        cenaVyrobku.appendChild(maloobchodni);  
        cenaVyrobku.appendChild(velkoobchodni);
      rum.appendChild(jmeno);
      rum.appendChild(velikost);
      rum.appendChild(objemAlkoholu); 
      rum.appendChild(cenaVyrobku);
    NodeList vyrobkyList = xmlDocument.getElementsByTagName("vyrobky");
    Element vyrobky = (Element) vyrobkyList.item(0);
    vyrobky.appendChild(rum);
     
    //Smazani odberatelu, kteri odebiraji zbozi za mene nez 10 000Kc
    NodeList odberatelList = xmlDocument.getElementsByTagName("odberatel");
    for(int i = odberatelList.getLength() - 1; i >= 0; i--){
      Element odberatel = (Element) odberatelList.item(i);
      Element celkovaCena = (Element) odberatel.getElementsByTagName("celkovacena").item(0);
      if(Integer.parseInt(celkovaCena.getAttribute("value")) < 10000){
        odberatel.getParentNode().removeChild(odberatel);
      }
    }
  } 
}
