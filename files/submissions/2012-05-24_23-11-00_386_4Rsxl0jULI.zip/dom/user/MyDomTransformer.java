/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package user;


import org.w3c.dom.*;
/**
 *
 * @author Murphy
 */
public class MyDomTransformer {
    
    private void goThrough(Node node,Document doc){

        /**
         * U aktualneho uzlu odstranim attributy a pridam ich hodnoty ako podelementy.
         */
        NamedNodeMap attrs=node.getAttributes();
            if(attrs!=null){
                for(int j=0;j<attrs.getLength();j++){
 
                    Attr attr=(Attr)attrs.item(j);
                    
                    if(node.getNodeType()==Node.ELEMENT_NODE){
                        Element e=(Element)node;
                        //Odstranenie attributov
                        e.removeAttributeNode(attr);

                        //Vytvorenie elementu s rovnakym nazvom co mal attribut
                        Element elementNode=doc.createElement(attr.getName());
                        e.appendChild(elementNode);

                        //Vytvorenie obsahu noveho elementu, co je rovnaky, ako hodnota attributu
                        Text textNode=doc.createTextNode(attr.getValue());
                        elementNode.appendChild(textNode);

                    }
                }
            }

        //Pre podelementy aktualneho elementu vykonam tie iste operacie
        NodeList childs=node.getChildNodes();
        for(int i=0;i<childs.getLength();i++){
            Node n=childs.item(i);

            goThrough(n,doc);
        }
        
    }

    public void transform(Document xmlDocument){
        Element root=xmlDocument.getDocumentElement();
        goThrough(root,xmlDocument);
    }

}
