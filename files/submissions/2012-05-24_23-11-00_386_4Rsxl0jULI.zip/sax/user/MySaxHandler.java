/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package user;

import java.util.HashMap;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * @author Murphy
 */
public class MySaxHandler extends DefaultHandler{

    /**
     * Trieda pre ulozenie informacie o tom, ze z daneho predmetu aky je priemer
     */
    class Mark{
        String subject;//Nazov predmetu
        int count;//Pocet znamkov pridelenych k predmetu
        int sum;//Suma znamkov k danemu predmetu

        public Mark(String subject){
            this.subject=subject;
            this.count=0;
            this.sum=0;
        }

        public void addMark(int mark){
            this.count++;
            this.sum+=mark;
        }

        public float getAverage(){
            return ((float)sum)/count;
        }

        public String getSubject(){
            return subject;
        }
    }

    HashMap<String,Mark> marks;//Mapa obsahujuce objekty znamkov identifikovane pomocou nazvu predmetu

    @Override
    public void startDocument() throws SAXException{
        this.marks=new HashMap<String, Mark>();
    }

    boolean wasSubject=false;
    boolean wasMark=false;

    int lastMark=0;
    String lastSubject="";

    @Override
    public void startElement(String namespaceURI,String localName,String qName,Attributes atts) throws SAXException{
        if(qName.equalsIgnoreCase("subject")){
            wasSubject=true;
        }

        if(qName.equalsIgnoreCase("val")){
            wasMark=true;
        }
        
    }

    @Override
    public void characters(char[] ch,int start, int length){
        String s=new String(ch,start,length);
        if(wasMark){
            try{
                lastMark=Integer.parseInt(s);
            }catch(Exception e){
            }
        }

        if(wasSubject){
            lastSubject=s;
        }

    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException{
        if(qName.equalsIgnoreCase("subject")){
            wasSubject=false;
        }
        if(qName.equalsIgnoreCase("val")){
            wasMark=false;
        }
        if(qName.equalsIgnoreCase("mark")){
            Mark mark=marks.get(lastSubject);
            if(mark==null){
                mark=new Mark(lastSubject);
                marks.put(lastSubject, mark);
            }

            mark.addMark(lastMark);

            wasMark=false;
            wasSubject=false;
        }
    }



    @Override
    public void endDocument() throws SAXException{
        for(Mark mark:marks.values()){
            System.out.println(mark.getSubject()+" "+mark.getAverage());
        }
    }
}
