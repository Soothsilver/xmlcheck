/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import org.xml.sax.ContentHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.Attributes;

import org.xml.sax.helpers.DefaultHandler;

import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;

//POPIS FUNKCNOSTI----------------------------------------------POPIS FUNKCNOSTI
//Vypise nasledujici statistiky po zpracovani dokument:
//Vypise seznam starych her + nasledujici statistiky.
//1) Seznam vsech znacek a pocet jejich vyskytu.
//2) Pocet vsech znacek.
//3) Prumerna hloubka dokumentu.
//4) Maximalni hloubka dokumentu.
//5) Pocet a seznam vsech attributu.

/**
 * Náš vlastní content handler pro obsluhu SAX událostí.
 * Implementuje metody interface ContentHandler. 
 */ 
public class MySaxHandler extends DefaultHandler {

    // Umožňuje zacílit místo v dokumentu, kde vznikla aktualní událost
    Locator locator;
    
    
    /**
     * Buffer for characters.
     */
    StringBuilder buffer = new StringBuilder();
    
    /**
     * Counts the number of each tag.
     */
    HashMap<String, Integer> tagsCount = new HashMap<String, Integer>();
    
    /**
     * How deep are we in the document.
     */
    int currentDepth = 0;
    
    /**
     * List of all depths (used for computing average depth).
     */
    List<Integer> depthList = new ArrayList();
    
    /**
     * Counts the number of attributes.
     */
    HashMap<String, Integer> attributesCount = new HashMap<String, Integer>();
    
    /**
     * Stores basic info about a computer game.
     */
    static class GameInfo
    {
        private String name;
        private String year;
        private String developer;
        
        GameInfo(String name, String year, String developer)
        {
            this.name = name.trim();
            this.year = year.trim();
            this.developer = developer.trim();
        }

      
        public String toString() {
            return "Name: " + this.name + " Year: " + this.year + " Developer: " + this.developer;
        }      
    }
    
    List<GameInfo> oldGames = new ArrayList<GameInfo>();
    
    //BOOLEAN VALUES USED FOR NAVIGATION IN DOCUMENT
    boolean startGameStudios = false;
    boolean startGameStudio = false;
    boolean startGames = false;
    boolean startGame = false;
    boolean startReleaseDates = false;
    boolean startReleaseDate = false;
    boolean startDate = false;
    boolean startYear = false;
    boolean startStudioName = false;
    
    //VARIABLE USED FOR STORING INFO ABOUT OLD GAME
    String oldGameName = "";
    String oldGameYear = "";
    String oldGameDeveloper = "";
    boolean isOldGame = false;
    int oldGameYearUpperBound = 2003;
    
    void changeTagsCount(String qualifiedName)
    {
        if(tagsCount.containsKey(qualifiedName))
        {
            //get cound, add one, reinsert
            Integer oldValue = tagsCount.get(qualifiedName);
            oldValue++;
            tagsCount.put(qualifiedName, oldValue);
        }
        else
        {
            tagsCount.put(qualifiedName, new Integer(1));
        }
    }
    
    /**
     * Changes attribute count.
     * @param tagQName Qualified name of the tag.
     * @param atts Tag attributes.
     */
    void changeAttributeCount(String tagQName, Attributes atts)
    {
        for(int i = 0; i < atts.getLength(); ++i)
        {
            String wholeName ="Attribute name: "+atts.getQName(i) +" Tag: "+tagQName;
            if(attributesCount.containsKey(wholeName))
            {
                Integer oldValue = attributesCount.get(wholeName);
                oldValue++;
                attributesCount.put(wholeName, oldValue);
            }
            else
            {
                attributesCount.put(wholeName, new Integer(1));
            }
        }
    }
    
    
    /**
     * Sets the locator.
     */     
   public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Start of the document event handler.
     */     
    public void startDocument() throws SAXException {
        
        // ...
        
    }
    /**
     * Obsluha události "konec dokumentu"
     */     
    public void endDocument() throws SAXException {
        
        //print all data to the screen
        
        int numberOfAllTags = 0;
        
        //number of each element
        System.out.println("Tags count:");
        for(Map.Entry<String, Integer> entry:tagsCount.entrySet())
        {
            System.out.println("Tag: "+entry.getKey()+ " Count: "+entry.getValue());
            numberOfAllTags+=entry.getValue();
        }
        
        System.out.println();
        
        //number of all tags
        System.out.println("Total tag count: " +numberOfAllTags);
        System.out.println();
        
        //ATTRIBUTES INFO----------------------------------------ATTRIBUTES INFO
        int numberOfAllAttributes = 0;
        //number of attributes
        System.out.println("Attributes count:");
        for(Map.Entry<String, Integer> entry:attributesCount.entrySet())
        {
            System.out.println(entry.getKey() +" Count: "+ entry.getValue());
            numberOfAllAttributes+=entry.getValue();
        }
        
        System.out.println();
        
        //number of all tags
        System.out.println("Total attribute count: " +numberOfAllAttributes);
        System.out.println();
        
        
        //DEPTH INFO--------------------------------------------------DEPTH INFO
        System.out.println("Depth information:");
        
        double averageDepth = 0;
        int maximumDepth = 0;
        
        int depthSum = 0;
        
        for(Integer dValue:depthList)
        {
            depthSum+= dValue;
            if(dValue>maximumDepth)
            {
                maximumDepth = dValue;
            }
        }
        
        if(depthList.isEmpty())
        {
            System.out.println("Average depth: " + 0);
            System.out.println("Maximum depth: " + 0);            
        }
        else
        {
            averageDepth = depthSum/depthList.size();
            System.out.println("Average depth: " +averageDepth);
            System.out.println("Maximum depth: " +maximumDepth);
        }
        
        System.out.println();
        
        //OLD GAMES
        System.out.println("List of old games (games made before year "+oldGameYearUpperBound+"):");
        for(GameInfo gi:oldGames)
        {
            System.out.println(gi);
        }
        
        
    }
    
    /**
     * Obsluha události "začátek elementu".
     * @param uri URI jmenného prostoru elementu (prázdné, pokud element není v žádném jmenném prostoru)
     * @param localName Lokální jméno elementu (vždy neprázdné)
     * @param qName Kvalifikované jméno (tj. prefix-uri + ':' + localName, pokud je element v nějakém jmenném prostoru, nebo localName, pokud element není v žádném jmenném prostoru)
     * @param atts Atributy elementu     
     */     
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        //count the tag
        changeTagsCount(qName);
        //count attributes
        changeAttributeCount(qName, atts);
        
        
        //change depth in document
        currentDepth++;
        //add to depthlist
        depthList.add(new Integer(currentDepth));
        
        if(qName.equals("GameStudios"))
        {
            startGameStudios = true;
        }else if(qName.equals("GameStudio"))
        {
            startGameStudio = true;
        }else if(qName.equals("Games"))
        {
            startGames = true;
        }else if(qName.equals("Game"))
        {
            startGame = true;
            
            //get the name for old game from attributes
            oldGameName = atts.getValue("Name");
            
        }else if(qName.equals("ReleaseDates"))
        {
            startReleaseDates = true;
        }else if(qName.equals("ReleaseDate"))
        {
            startReleaseDate = true;
        }else if(qName.equals("Date"))
        {
            startDate = true;
        }else if(qName.equals("Year"))
        {
            startYear = true;
            
        }else if(qName.equals("StudioName"))
        {
            startStudioName = true;
        }

    }
    /**
     * Obsluha události "konec elementu"
     * Parametry mají stejný význam jako u @see startElement     
     */     
    public void endElement(String uri, String localName, String qName) throws SAXException {
        
        if(qName.equals("GameStudios"))
        {
            startGameStudios = false;
        }else if(qName.equals("GameStudio"))
        {
            startGameStudio = false;
        }else if(qName.equals("Games"))
        {
            startGames = false;
        }else if(qName.equals("Game"))
        {
            startGame = false;
            
            if(isOldGame)
            {   
                //insert to list of old games
                oldGames.add(new GameInfo( oldGameName, oldGameYear, oldGameDeveloper));
            }
            
            //change to default
            isOldGame = false;
        }else if(qName.equals("ReleaseDates"))
        {
            startReleaseDates = false;
        }else if(qName.equals("ReleaseDate"))
        {
            startReleaseDate = false;
        }else if(qName.equals("Date"))
        {
            startDate = false;
        }else if(qName.equals("Year"))
        {
            startYear = false;
            
            //if it is a year marking the release of the game
            if(!isOldGame && startGames && startGame && startReleaseDates && startReleaseDate && startDate)
            {
                oldGameYear = buffer.toString();
                
                //if it is old game
                if(Integer.parseInt(oldGameYear.trim())<oldGameYearUpperBound)
                {
                    isOldGame = true;
                }
            }
            
            
        }else if(qName.equals("StudioName"))
        {
            startStudioName = false;
            
            //store the studio name (it is in the buffer)
            oldGameDeveloper = buffer.toString();
        }
        
         //change depth
        currentDepth--;
        //empty the buffer
        buffer.setLength(0);
        

    }
    
    /**
     * Obsluha události "znaková data".
     * SAX parser muľe znaková data dávkovat jak chce. Nelze tedy počítat s tím, že je celý text dorucen v rámci jednoho volání.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakovými daty
     * @param start Index zacátku úseku platných znakových dat v poli.
     * @param length Délka úseku platných znakových dat v poli.
     */               
    public void characters(char[] ch, int start, int length) throws SAXException {

        buffer.append(ch, start, length);
        
    }
    
    /**
     * Obsluha události "deklarace jmenného prostoru".
     * @param prefix Prefix prirazený jmennému prostoru.
     * @param uri URI jmenného prostoru.
     */     
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha události "konec platnosti deklarace jmenného prostoru".
     */     
    public void endPrefixMapping(String prefix) throws SAXException {
    
        // ...
    
    }

    /**
     * Obsluha události "ignorované bílé znaky".
     * Stejné chování a parametry jako @see characters     
     */     
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha události "instrukce pro zpracování".
     */         
    public void processingInstruction(String target, String data) throws SAXException {
      
      // ...
            
    }

    /**
     * Obsluha události "nezpracovaná entita"
     */         
    public void skippedEntity(String name) throws SAXException {
    
      // ...
    
    }
}