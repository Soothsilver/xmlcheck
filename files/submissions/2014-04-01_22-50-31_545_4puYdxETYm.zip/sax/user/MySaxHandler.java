package user;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {

    /*
    features:
    1) atributy - vyber nejcasteji se vyskytujici kategorie vtipu
    2) elementy - vypis nejdelsiho vtipu
    3) kontext - pocet zivych autoru s vysokou vtipnosti (>= 7)
    
    */
    
     // 1)
    Map<String, Integer> cetnostKategorii;
    
     // 2)
    boolean parseVtip = false;
    String nejdelsiVtip = "";
    
    // 3)
    boolean parseVtipnost = false;
    String vtipnostString = "";
    int vtipnost = 0;
    boolean nazivu = false;
    int pocetVtipnychZivych = 0;

    @Override
    public void startDocument() throws SAXException {
        this.cetnostKategorii = new HashMap<String, Integer>();
    }

    @Override
    public void endDocument() throws SAXException {
        
        // 1)
        int maxCetnost = Collections.max(cetnostKategorii.values());
        System.out.println("Nejcasteji se vyskytujici kategorie vtipu je/jsou:");
        for (Map.Entry<String, Integer> k : cetnostKategorii.entrySet()) {
            if (k.getValue() == maxCetnost)
                System.out.println(" " + k.getKey());            
        }
        System.out.println("");
        
        // 2)
        System.out.println("Nejdelsi vtip:");
        System.out.println(nejdelsiVtip);
        System.out.println("");
        
        // 3)
        System.out.println("Na svete existuje jeste " + pocetVtipnychZivych + " nadejnych vtipnych autoru.");
    }



    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        if (localName.equals("vtip")) {
            String kategorie = attributes.getValue("kategorie");
            if (kategorie != null) {
                if (!cetnostKategorii.containsKey(kategorie))
                    cetnostKategorii.put(kategorie, 1);
                else
                    cetnostKategorii.put(kategorie, cetnostKategorii.get(kategorie) + 1);
            }
            
        }
        
        if (localName.equals("text"))
            parseVtip = true;
        
        if (localName.equals("nazivu"))
            nazivu = true;
        
        if (localName.equals("vtipnost")) {
            parseVtipnost = true;
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (localName.equals("text"))
            parseVtip = false;
        
        if (localName.equals("autor")) {
            if (vtipnost >= 7 && nazivu) {
                ++pocetVtipnychZivych;
            }
            vtipnost = 0;
            nazivu = false;
        }
        
        if (localName.equals("vtipnost")) {
            vtipnost = Integer.parseInt(vtipnostString);
            parseVtipnost = false;
        }
    }
    
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        if (parseVtip) {
            String text = "";
            for (int i = 0; i < length; i++) {
                text += ch[i + start];
            }
            
            if (text.length() > nejdelsiVtip.length())
                nejdelsiVtip = text;
            
        }
        
        if (parseVtipnost) {
            vtipnostString = "";
            for (int i = 0; i < length; i++) {
                vtipnostString += ch[i + start];
            }
        }
    }



}
