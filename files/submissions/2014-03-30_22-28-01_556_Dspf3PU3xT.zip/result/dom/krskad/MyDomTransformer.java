package krskad;

import java.util.GregorianCalendar;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer {

	private static Node createOrder(Document doc, Integer id, Float price, Float volume){
    	Element element = doc.createElement("order");
    	element.setAttribute("id", id.toString());
    	element.setAttribute("price", price.toString());
    	element.setAttribute("volume", volume.toString());
    	return element;
    }
	
	public void transform (Document doc) {
		// first amendment: add new order
    	String currencyCode = "AUR";
    	boolean buyOrder = true;
    	Integer id = 121480;
    	Float price = 0.0578f;
    	Float volume = 2.982f;
    	
    	NodeList currencies = doc.getElementsByTagName("currency");
    	for(int i=0; i<currencies.getLength(); ++i){
    		if(currencies.item(i).getAttributes().getNamedItem("code").getNodeValue().equals(currencyCode)){
    			NodeList currencyChilds = currencies.item(i).getChildNodes();
    			for(int j=0; j<currencyChilds.getLength(); ++j){
    				if(currencyChilds.item(j).getNodeName().equals("orders")){
    					NodeList ordersChilds = currencyChilds.item(j).getChildNodes();
    					for(int k=0; k<ordersChilds.getLength(); ++k){
    						if(buyOrder == true  && ordersChilds.item(k).getNodeName().equals("buyOrders") ||
    						   buyOrder == false && ordersChilds.item(k).getNodeName().equals("sellOrders")){
    							ordersChilds.item(k).appendChild(createOrder(doc, id, price, volume));
    						}
    					}
    				}
    			}
    		}
    	}
    	
        // second amendment: remove the oldest message
    	NodeList infos = doc.getElementsByTagName("info");
    	if(infos.getLength() != 0){
    		Node oldestInfo = infos.item(0);
    		NamedNodeMap dateAttributes = oldestInfo.getChildNodes().item(1).getAttributes();
			GregorianCalendar oldestDate = new GregorianCalendar(Integer.parseInt(dateAttributes.getNamedItem("year").getNodeValue()),
    				Integer.parseInt(dateAttributes.getNamedItem("month").getNodeValue()),
    				Integer.parseInt(dateAttributes.getNamedItem("day").getNodeValue()));
        	for(int i=1; i<infos.getLength(); ++i){
        		dateAttributes = infos.item(i).getChildNodes().item(1).getAttributes();
    			GregorianCalendar date = new GregorianCalendar(Integer.parseInt(dateAttributes.getNamedItem("year").getNodeValue()),
        				Integer.parseInt(dateAttributes.getNamedItem("month").getNodeValue()),
        				Integer.parseInt(dateAttributes.getNamedItem("day").getNodeValue()));
    			if(date.before(oldestDate)){
    				oldestDate = date;
    				oldestInfo = infos.item(i);
    			}
        	}
        	oldestInfo.getParentNode().removeChild(oldestInfo);
    	}
	}
	
}
