package user; 

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.*;

public class MySaxHandler extends DefaultHandler
{

// 	public static void main(String[] args)
// 	{
//         String sourcePath = "../data.xml";
// 
//         try
// 		{
//             XMLReader parser = XMLReaderFactory.createXMLReader();
//             InputSource source = new InputSource(sourcePath);
//             parser.setContentHandler(new MySaxHandler());
//             parser.parse(source);
//         }
// 		catch (Exception e) 
// 		{
//             e.printStackTrace();
//         }
//     }


//zavedeni potrebnych promenych ke statistice
	private int elements_count, persons_count, max_depth, avg_depth, atts_count, avg_elem_name_lenght, elem_with_atts_count, men_count, women_count, avg_age, dob, depth;
	private StringBuilder sb;
	private boolean dn, du;


// inicializace promennych
	public MySaxHandler()
	{
		elements_count = 0;
		persons_count = 0;
		max_depth = 0;
		avg_depth = 0;
		atts_count = 0;
		avg_elem_name_lenght = 0;
		elem_with_atts_count = 0;
		men_count = 0;
		women_count = 0;
		avg_age = 0;

		dob = 0;
		depth = 0;
		sb = new StringBuilder();
		dn = false;
		du = false;
	}
    
    // public void startDocument() throws SAXException {}
    

//vypis statistiky - prumerne hodnoty maji presnost na cela cisla
    public void endDocument() throws SAXException 
	{

// vypocet prumeru
		avg_depth /= elements_count;
		avg_elem_name_lenght /= elements_count;
		avg_age /= persons_count;


        System.out.println("Pocet elementu v dokumentu:\t" + elements_count);
        System.out.println("Maximalni hloubka elementu:\t" + max_depth);
        System.out.println("Prumerna hloubka elementu:\t" + avg_depth);
        System.out.println("Prumerna delka jmena elementu:\t" + avg_elem_name_lenght);
        System.out.println("Pocet elementu s atributy:\t" + elem_with_atts_count);
        System.out.println();

        System.out.println("Pocet osob:\t" + persons_count);
        System.out.println("Z toho muzu:\t" + men_count);
        System.out.println("A zen:\t" + women_count);
        System.out.println("Prumerna delka zivota:\t" + avg_age);
    }
    
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException 
	{
		sb.setLength(0);

// pocitani hloubky, elementu a nazvu elementu
		depth++;
		if( max_depth < depth)
			max_depth = depth;
		avg_depth += depth;
		elements_count++;
		avg_elem_name_lenght += qName.length();
		
//pocitani elementu s atributy
		if(atts.getLength() > 0)
			elem_with_atts_count++;

//statistika v ramci ozlu osoba
		if(qName.equals("osoba"))
		{
			persons_count++;
			if(atts.getValue("pohlavi").equals("muz"))
				men_count++;
			else
				women_count++;
		}

// priprava pro vypocet delky zivota
		if(qName.equals("datum_narozeni"))
			dn = true;
		if(qName.equals("datum_umrti"))
			du = true;
    }

    public void endElement(String uri, String localName, String qName) throws SAXException 
	{
// pocitani hloubky
		depth--;

//hodnoty pro vypocet delky zivota
		if(qName.equals("rok") && dn)
			dob = Integer.parseInt(sb.toString().trim());

//vypocet delky zivota
		if(qName.equals("rok") && du)
		{
			try
			{
				avg_age += Integer.parseInt(sb.toString().trim()) - dob;
			}
			catch(NumberFormatException e)
			{			}
		}

// konec indikace vypoctu delky zivota
		if(qName.equals("datum_narozeni"))
			dn = false;
		if(qName.equals("datum_umrti"))
			du = false;
    }
    
    public void characters(char[] ch, int start, int length) throws SAXException 
	{
//nacitani textu uzlu (pouzite pro vypocet delky zivota)
		sb.append(ch, start, length);
    }
    
    // public void startPrefixMapping(String prefix, String uri) throws SAXException {}

    // public void endPrefixMapping(String prefix) throws SAXException {}
     
    // public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {}
         
    // public void processingInstruction(String target, String data) throws SAXException {}
         
    // public void skippedEntity(String name) throws SAXException {}
}


