package user;

import org.w3c.dom.*;
import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class MyDomTransformer
{

// 	public static void main(String[] args) {
//         
// 		String VSTUPNI_SOUBOR = "../data.xml";
// 		String VYSTUPNI_SOUBOR = "../data.out.xml";
// 
//         try {
//             
//             DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
// 
//             dbf.setValidating(false);
// 
//             DocumentBuilder builder = dbf.newDocumentBuilder();
// 
//             Document doc = builder.parse(VSTUPNI_SOUBOR);
// 
//             (new MyDomTransformer()).transform(doc);
// 
//             TransformerFactory tf = TransformerFactory.newInstance();
// 
//             Transformer writer = tf.newTransformer();
// 
// //             writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
// 
//             writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));
// 
// 
//         } catch (Exception e) {
//             
//             e.printStackTrace();
//             
//         }
// 	}


	public void transform (Document xmlDocument)
	{

// zavedeni promennych se kterymi budu v dokumentu pracovat
		NodeList nl = xmlDocument.getElementsByTagName("osoba");
		Node datum_narozeni = null;
		Node datum_umrti = null;
		Node barva_oci = null;
		String pohlavi;
		

// operace v ramci kazdeho uzlu osoba
		for( int i = 0; i < nl.getLength(); i++)
		{
			Node osoba = nl.item(i);
			NodeList osoba_childs = osoba.getChildNodes(); 
			barva_oci = null;

//nalezeni potrebnych deti uzlu osoba
			for(int j = 0; j < osoba_childs.getLength(); j++)
			{
				if(osoba_childs.item(j).getNodeName().equals("datum_narozeni"))
					datum_narozeni = osoba_childs.item(j);
				if(osoba_childs.item(j).getNodeName().equals("datum_umrti"))
					datum_umrti = osoba_childs.item(j);
				if(osoba_childs.item(j).getNodeName().equals("barva_oci"))
					barva_oci = osoba_childs.item(j);
			}

//prevedeni uzlu datumu na atributy datumu
			transform_datum(datum_narozeni);
			transform_datum(datum_umrti);
			
//prevedeni atributu pohlavi na poduzel pohlavi
			pohlavi = ((Element)osoba).getAttributeNode("pohlavi").getNodeValue();
			((Element)osoba).removeAttribute("pohlavi");
			Node n_pohlavi = xmlDocument.createElement("pohlavi");
			n_pohlavi.appendChild(xmlDocument.createTextNode(pohlavi));
			osoba.appendChild(n_pohlavi);

//odstraneni uzlu bara_oci
			if(barva_oci != null)
				osoba.removeChild(barva_oci);

		}
	}

//funkce prevadejici datum z uzlu na atributy
	private void transform_datum(Node old_datum)
	{
		NodeList datum = old_datum.getChildNodes();
		Node r_den = null;
		Node r_mesic = null;
		Node r_rok = null;

		int den = 0;
		int mesic = 0;
		int rok = 0;

//cyklus pres deti uzlu datum (den, mesic, rok) a seberani jejich hodnot
		for(int j = 0; j < datum.getLength(); j++)
		{
			if(datum.item(j).getNodeName().equals("den"))
			{
				try
				{
					den = Integer.parseInt(datum.item(j).getChildNodes().item(0).getNodeValue());
				}
				catch(NumberFormatException e)
				{
					den = 0;
				}
				r_den = datum.item(j);
			}
			if(datum.item(j).getNodeName().equals("mesic"))
			{
				try
				{
					mesic = Integer.parseInt(datum.item(j).getChildNodes().item(0).getNodeValue());
				}
				catch(NumberFormatException e)
				{
					mesic = 0;
				}
				r_mesic = datum.item(j);
			}
			if(datum.item(j).getNodeName().equals("rok"))
			{
				try
				{
					rok = Integer.parseInt(datum.item(j).getChildNodes().item(0).getNodeValue());
				}
				catch(NumberFormatException e)
				{
					rok = 0;
				}
				r_rok = datum.item(j);
			}
		}

//odstraneni podulzlu datumu (den, mesic, rok)
			if(r_den != null)
				old_datum.removeChild(r_den);
			if(r_mesic != null)
				old_datum.removeChild(r_mesic);
			if(r_rok != null)
				old_datum.removeChild(r_rok);

//pridati atributu den, mesic a rok k datumu
			if(den != 0)
				((Element)old_datum).setAttribute("den", String.valueOf(den));
			if(mesic != 0)
				((Element)old_datum).setAttribute("mesic", String.valueOf(mesic));
			if(rok != 0)
				((Element)old_datum).setAttribute("rok", String.valueOf(rok));
	}
}

