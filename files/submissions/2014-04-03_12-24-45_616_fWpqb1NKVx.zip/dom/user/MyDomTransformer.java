package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class MyDomTransformer {
    
    public void transform (Document xmlDocument) {
        //přidání nové obědnávky
        Element order = xmlDocument.createElement("order");
        order.setAttribute("concertID", "id_2");
        order.setAttribute("count", "3");
        order.appendChild(xmlDocument.createElement("name")).setTextContent("Michal Chvala");
        Element address = (Element)order.appendChild(xmlDocument.createElement("address"));
        address.appendChild(xmlDocument.createElement("street")).setTextContent("Komenskeho");
        address.appendChild(xmlDocument.createElement("number")).setTextContent("24");
        address.appendChild(xmlDocument.createElement("city")).setTextContent("Praha");
        NodeList ordersList = xmlDocument.getElementsByTagName("orders");
        Element orders = (Element) ordersList.item(0);
        orders.appendChild(order);
        
        //smazat obědnávky které nemají adresu v praze
        NodeList cityList = xmlDocument.getElementsByTagName("city");
        for(int i= cityList.getLength() -1; i!=0 ; i--){
            Element city = (Element)cityList.item(i);
            if (!city.getTextContent().equals("Praha")){
                Element order2 = (Element) city.getParentNode().getParentNode();
                order2.getParentNode().removeChild(order2);
            }
        }
    }
}
