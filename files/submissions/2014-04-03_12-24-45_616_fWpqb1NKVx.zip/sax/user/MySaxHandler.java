/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {

    Locator locator;
    int countOfOrderedTickets = 0;
    boolean nextIsCity = false;
    boolean nextIsOrder = false;
    int countOfTicketInSingleOrder = 0;
    int countOfOrdersFromPragueWith5OrMore = 0;
    Map<String,Integer> cities = new HashMap<String,Integer>();
    
    @Override
    public void endDocument() throws SAXException {
         System.out.println("Pocet obednanych listku celkem: " + countOfOrderedTickets);
        
        String bestCity = "";
        
        int count = 0;
        Iterator<String> iterator = cities.keySet().iterator();
        String city;
        int c;
        while(iterator.hasNext()){
            city = iterator.next();
            c = cities.get(city);
            if(c > count){
                bestCity = city;
                count = c;
            }
        }
        
        System.out.println("Nejvice obednavek je z mesta: " + bestCity);
        System.out.println("Pocet obednavek z Prahy na 5 a vice listku : " + countOfOrdersFromPragueWith5OrMore);
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
       if(localName.equals("order")){
            countOfOrderedTickets += Integer.parseInt(attributes.getValue(1));
            countOfTicketInSingleOrder = Integer.parseInt(attributes.getValue(1));
        }
        
        if(localName.equals("city")){
            nextIsCity = true;
        }
        
         if(localName.equals("order")){
            nextIsOrder = true;
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        if(nextIsCity && nextIsOrder){
            nextIsOrder = false;
            nextIsCity = false;
           
            String text = "";
            for(int i = start; i < start +length; i++){
                text += ch[i];
               
            }
            if (cities.containsKey(text)){
               
                Integer value = cities.get(text);
                cities.put(text, value + 1);
            }else{
                cities.put(text, 1);
            }
            
         if(countOfTicketInSingleOrder >= 5 && text.equals("Praha")){
             countOfOrdersFromPragueWith5OrMore++;
         }
            
        }else{
            nextIsCity = false;
        }
    }

    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }
   
}
