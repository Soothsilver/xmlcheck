/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hwozd
 */

package user;

import java.io.File;


import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

public class MyDomTransformer {
    
        static void processNode(Node n,Document doc){

        NodeList nList = n.getChildNodes();
        for(int i = 0; i != nList.getLength(); ++i){
            processNode(nList.item(i),doc);
        }
        NamedNodeMap nnm = n.getAttributes();
        if (nnm != null){   //is element
            java.util.ArrayList<Node> attributesToRemove = new java.util.ArrayList<Node>();
            Element e = (Element)n ;
            for(int t = 0; t < nnm.getLength(); ++t){
                Node nA = nnm.item(t);
                //attribute by nemel zacinat xmlns - deklarace namespace (ty neprevadet), pripadne xsi:noNamespaceSchemaLocation
                if (nA != null && nA.getNodeName() != null && !nA.getNodeName().startsWith("xmlns", 0) && !nA.getNodeName().startsWith("xsi:noNamespaceSchemaLocation", 0)){
                    //System.out.printf("%s - %s\n",nA.getNodeName(),nA.getNodeValue());
                    Node nN = doc.createElement(nA.getNodeName());
                    Text text= doc.createTextNode(nA.getNodeValue());
                    nN.appendChild(text);
                    n.appendChild(nN);
                    //e.removeAttribute(nA.getNodeName());//nA.getPrefix() + nA.getNodeName());
                    attributesToRemove.add(nA);
                }
            }
            for(Node nAtr : attributesToRemove){
                e.removeAttribute(nAtr.getNodeName());
            }
        }

    }

    public void transform (Document doc) {
        NodeList nList = doc.getChildNodes();
        for(int i = 0; i != nList.getLength(); ++i){
            processNode(nList.item(i),doc);
        }
    }

}
