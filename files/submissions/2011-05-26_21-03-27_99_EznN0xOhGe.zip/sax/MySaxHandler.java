/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hwozd
 */
package user;

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;

public class MySaxHandler extends DefaultHandler{
        Locator locator;


     /**
     * NastavĂ­ locator
     */
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Obsluha udĂˇlosti "zaÄŤĂˇtek dokumentu"
     */
    public void startDocument() throws SAXException {

        // ...

    }
    /**
     * Obsluha udĂˇlosti "konec dokumentu"
     */
    public void endDocument() throws SAXException {
        // ...
        System.out.printf("počet elementů je %d \n",numElements_);
        System.out.printf("maximalní hloubka je %d \n",maximumDepth_);
        System.out.printf("průměrná hloubka je %f \n",(float)depthSumSoFar_/(float)numElements_);
        System.out.printf("počet všech atributů je %d \n",numAttributes_);
        System.out.printf("průměrný počet atributů pro element je %f \n",(float)numAttributes_/(float)numElements_);


    }

    int currentDepth_ = 0;
    int numElements_ = 0;
    int numAttributes_ = 0;
    int depthSumSoFar_ = 0;
    int maximumDepth_ = 0;
    int numUdalosti_ = 0;
    int numKomentaru_ = 0;
    /**
     * Obsluha udĂˇlosti "zaÄŤĂˇtek elementu".
     * @param uri URI jmennĂ©ho prostoru elementu (prĂˇzdnĂ©, pokud element nenĂ­ v ĹľĂˇdnĂ©m jmennĂ©m prostoru)
     * @param localName LokĂˇlnĂ­ jmĂ©no elementu (vĹľdy neprĂˇzdnĂ©)
     * @param qName KvalifikovanĂ© jmĂ©no (tj. prefix-uri + ':' + localName, pokud je element v nÄ›jakĂ©m jmennĂ©m prostoru, nebo localName, pokud element nenĂ­ v ĹľĂˇdnĂ©m jmennĂ©m prostoru)
     * @param atts Atributy elementu
     */
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        maximumDepth_ = Math.max(maximumDepth_, currentDepth_);
        ++numElements_;
        depthSumSoFar_ += currentDepth_;
        numAttributes_ += atts.getLength();
        ++currentDepth_;

        if(localName.equals("udalost"))
            ++numUdalosti_;
        if(localName.equals("komentar"))
            ++numKomentaru_;


        // ...

    }
    /**
     * Obsluha udĂˇlosti "konec elementu"
     * Parametry majĂ­ stejnĂ˝ vĂ˝znam jako u @see startElement
     */
    public void endElement(String uri, String localName, String qName) throws SAXException {
        --currentDepth_;
    }

    /**
     * Obsluha udĂˇlosti "znakovĂˇ data".
     * SAX parser muÄľe znakovĂˇ data dĂˇvkovat jak chce. Nelze tedy poÄŤĂ­tat s tĂ­m, Ĺľe je celĂ˝ text dorucen v rĂˇmci jednoho volĂˇnĂ­.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakovĂ˝mi daty
     * @param start Index zacĂˇtku Ăşseku platnĂ˝ch znakovĂ˝ch dat v poli.
     * @param length DĂ©lka Ăşseku platnĂ˝ch znakovĂ˝ch dat v poli.
     */
    public void characters(char[] ch, int start, int length) throws SAXException {
        // ...

    }

    /**
     * Obsluha udĂˇlosti "deklarace jmennĂ©ho prostoru".
     * @param prefix Prefix prirazenĂ˝ jmennĂ©mu prostoru.
     * @param uri URI jmennĂ©ho prostoru.
     */
    public void startPrefixMapping(String prefix, String uri) throws SAXException {

        // ...

    }

    /**
     * Obsluha udĂˇlosti "konec platnosti deklarace jmennĂ©ho prostoru".
     */
    public void endPrefixMapping(String prefix) throws SAXException {

        // ...

    }

    /**
     * Obsluha udĂˇlosti "ignorovanĂ© bĂ­lĂ© znaky".
     * StejnĂ© chovĂˇnĂ­ a parametry jako @see characters
     */
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {

        // ...

    }

    /**
     * Obsluha udĂˇlosti "instrukce pro zpracovĂˇnĂ­".
     */
    public void processingInstruction(String target, String data) throws SAXException {

      // ...

    }

    /**
     * Obsluha udĂˇlosti "nezpracovanĂˇ entita"
     */
    public void skippedEntity(String name) throws SAXException {

      // ...

    }



}
