package user;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
    Locator locator;
    
    boolean inShipFreight;
    boolean inVIPCustomer;
    boolean inCustomerName;
    double freight;
    boolean inShipInfo;
    Map<String, Integer> counter;
	
	@Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
        inShipFreight = false;
        inVIPCustomer = false;
        inCustomerName = false;
        inShipInfo = false;
        freight = 0;
        counter = new HashMap<String, Integer>();
    }
	/*
    @Override
    public void startDocument() throws SAXException {
         ...
    }

    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
        System.out.println(freight);
        Iterator it = counter.entrySet().iterator();
        int max = 0;
        String maxS = null;
        while (it.hasNext()) {
            Map.Entry pairs = (Map.Entry)it.next();
            Integer value = (Integer)pairs.getValue();
            if (value > max){
                max = value;
                maxS = (String)pairs.getKey();
            }
        }
        System.out.println(maxS);
    }

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if (localName.equals("Customer"))
        {
            if (atts.getValue("VIP").equals("yes")){
                inVIPCustomer = true;
            }
        }
        else if (inVIPCustomer && localName.equals("CompanyName")){
            inCustomerName = true;
        }
        else if (localName.equals("Freight")){
            inShipFreight = true;
        }
        else if (localName.equals("ShipInfo")){
            String shipDate = atts.getValue("ShippedDate");
            if (shipDate != null){
                String shipYear = shipDate.substring(0, 4);
                Integer count = counter.get(shipYear);
                if (count == null){
                    counter.put(shipYear, 1);
                }
                else{
                    count++;
                    counter.put(shipYear, count);
                }
            }
        }
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (inVIPCustomer && localName.equals("Customer")){ 
            inVIPCustomer = false;
        }
        else if (inCustomerName && localName.equals("CompanyName")){
            inCustomerName = false;
        }
        else if (inShipFreight && localName.equals("Freight")){
            inShipFreight = false;
        }
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        if (inCustomerName){
            System.out.println(new String(chars, start, length));
        }
        else if (inShipFreight){
            String valueS = new String(chars, start, length);
            Double val = Double.parseDouble(valueS);
            freight += val;
        }
    }

    /**
     * Method to handle " start of namespace declaration"
     *
     * @param prefix Prefix of the namespace
     * @param uri URI of the namespace
     * @throws SAXException
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
         ...
    }

    /**
     * Method to handle "end of namespace declaration"
     *
     * @param prefix
     * @throws SAXException
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
         ...
    }

    /**
     * Method to handle "ignoring of whitespaces" Text is in array 'chars' from
     * position ('start') to ('start' + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     * @throws SAXException
    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
         ...
    }

    /**
     * Method to handle "processing instructions"
     *
     * @param target The processing instruction target
     * @param data  The processing instruction data
     * @throws SAXException
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
         ...
    }

    /**
     * Method to handle "unprocessed entity"
     *
     * @param name
     * @throws SAXException
    @Override
    public void skippedEntity(String name) throws SAXException {
         ...
    }
     */
}