package user;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer {
    public void transform (Document xmlDocument) {
        //deletes all orders which have already been shipped
        NodeList shipI = xmlDocument.getElementsByTagName("ShipInfo");
        for (int i = shipI.getLength() - 1; i >=0; i--){
            Element info = (Element)shipI.item(i);
            if (!info.getAttribute("ShippedDate").equals("")){
                Node order = info.getParentNode();
                Node orders = order.getParentNode();
                orders.removeChild(order.getNextSibling());
                orders.removeChild(order);
            }            
        }
        //adds fax number to customer LETSS
        Node fax = xmlDocument.createElement("Fax");
        fax.setTextContent("(509) 123-6666");
        Node lets = xmlDocument.getElementById("LETSS");
        Node address = lets.getLastChild().getPreviousSibling(); //last child is text with newline, i wont bother with inserting newline
        lets.insertBefore(fax, address);
    }
}