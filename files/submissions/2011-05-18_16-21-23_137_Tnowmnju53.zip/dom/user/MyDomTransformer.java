package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

/**
 * Metoda transform prevede atributy genreName u jednotlivych hernich zanru na jejich podelementy.
 * Ty budou vzdy na prvni pozici a jmenovat se budou tez genreName.
 *
 * @author Vladimir Klimes
 */
public class MyDomTransformer {
    Element element,    // prave zpracovavany element
            newElement; // nove vytvoreny element genreName se jmenem zanru
    String genreName;   // jmeno zanru pro prave zpracovavany element

    public void transform (Document xmlDocument) {
        NodeList allElements = xmlDocument.getElementsByTagName("*");
        
        for(int i = 0; i < allElements.getLength(); i++)
        {
            element = (Element) allElements.item(i);

            if ((element.getAttributes().getLength() == 1) && element.hasAttribute("genreName"))
            {
                genreName = element.getAttribute("genreName");
                element.removeAttribute("genreName");

                newElement = xmlDocument.createElement("genreName");
                newElement.setTextContent(genreName);

                // zarad novy element s nazvem zanru na prvni pozici mezi potomky zpracovavaneho elementu
                if (element.hasChildNodes())
                    element.insertBefore(newElement, element.getFirstChild());
                else
                    element.appendChild(newElement);
            }
        }
    }
}