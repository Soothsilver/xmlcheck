package user;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
    boolean inTitul = false, // zpracovava se element titul?
            inVyvojar = false, // zpracovava se element vyvojar?
            startElementWasBefore = false,
            endElementWasBefore = false,
            textWasBefore = false;

    int indent = -1; // odsazeni od okraje
    String lastId = null; // id vyvojare, potrebne k pridani elementu s poctem vydanych titulu k jeho zaznamu
    Map<String, Integer> vyvojarVydanoTitulu = new HashMap<String, Integer>(); // dvojice id - pocet vydanych titulu

    @Override
    public void startDocument() throws SAXException {
        System.out.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if (startElementWasBefore)
            System.out.println();

        System.out.print(createIndent(++indent) + "<" + qName + getAttrs(atts) + ">");

        startElementWasBefore = true;
        endElementWasBefore = false;
        textWasBefore = false;

        // urci soucasny stav a zpracuj udalosti
        if (localName.equals("titul"))
        {
            inTitul = true;
        }
        else if (localName.equals("vyvojarRef") && inTitul)
        {
            if (!vyvojarVydanoTitulu.containsKey(atts.getValue("id")))
                vyvojarVydanoTitulu.put(atts.getValue("id"), 1); // novy vyvojar v databazi
            else
                vyvojarVydanoTitulu.put(atts.getValue("id"), (Integer.parseInt(vyvojarVydanoTitulu.get(atts.getValue("id")).toString()) + 1)); // inkrementace poctu titulu vyvojare v databazi
        }
        else if (localName.equals("vyvojar"))
        {
            inVyvojar = true;
            lastId = atts.getValue("id"); // uloz id vyvojare pro dalsi pouziti
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (endElementWasBefore)
        {
            System.out.print(createIndent(indent));
        }
        
        System.out.println("</" + qName + ">");
       
        indent--;
        startElementWasBefore = false;
        endElementWasBefore = true;

        // urci soucasny stav a zpracuj udalosti
        if (localName.equals("titul"))
            inTitul = false;
        else if (localName.equals("vyvojar"))
            inVyvojar = false;
        else if (localName.equals("nazev") && inVyvojar)
        {
            System.out.println(createIndent(indent + 1) + "<vydanoTitulu>" + vyvojarVydanoTitulu.get(lastId) + "</vydanoTitulu>");
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        String content = String.valueOf(Arrays.copyOfRange(ch, start, start + length));
        content = content.replaceAll("[ \t\n\r]", "");

        if (content != null && !content.equals(""))
        {
            System.out.print(content);
            startElementWasBefore = false;
            endElementWasBefore = false;
            textWasBefore = true;
        }        
    }

    private StringBuilder createIndent(int length)
    {
        StringBuilder indentToReturn = new StringBuilder();

        for(int i = 0; i < length; i++)
        {
            indentToReturn.append("  ");
        }

        return indentToReturn;
    }

    private StringBuilder getAttrs(Attributes atts)
    {
        if (atts.getLength() == 0)
            return new StringBuilder();
        else
        {
            StringBuilder attributes = new StringBuilder();
            
            for(int i = 0; i < atts.getLength(); i++)
            {
                attributes.append(" ").append(atts.getQName(i)).append("=\"").append(atts.getValue(i)).append("\"");
            }

            return attributes;
        }
    }
}
