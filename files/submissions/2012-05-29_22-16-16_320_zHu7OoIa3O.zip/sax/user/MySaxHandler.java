package user;


/*
 * Vytiskne na stdout statistiku evidovanych osob.
 * Pokud nemaji zadny zaznam
 * Pokud nejaky maji, tak se vypise celkovy soucet nasbiranych bodu a zaplacenych pokut.
 */


import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;

   
    

class Stats
{
    static HashMap<String,String> osoby = new HashMap<String,String>();  //jednotlive osoby
    static HashMap<String,ArrayList<Integer>> pokuty = new HashMap<String,ArrayList<Integer>>(); //prestupky k osobam
    static HashMap<String,ArrayList<Integer>> body = new HashMap<String,ArrayList<Integer>>(); //body k osobam
    static HashMap<String,String> ridici = new HashMap<String,String>(); //ridici k osobam
}

class Console
{
    public static void WriteLine(String What)
    {
       System.out.println(What); 
    }
    public static void Write(String What)
    {
        System.out.print(What);
    }

}

public class MySaxHandler extends DefaultHandler {
 public static void main(String[] args) {

  
        String sourcePath = "data.xml";

        try {
            
             
            XMLReader parser = XMLReaderFactory.createXMLReader();
            
             
            InputSource source = new InputSource(sourcePath);
            
             
            parser.setContentHandler(new MySaxHandler());
            
             
            parser.parse(source);
            
        } catch (Exception e) {
        
            e.printStackTrace();
            
        }       
        
        
    }
 
     
    Locator locator;
    String IdKeZpracovani = null;
    boolean WaitingForName = false;
    boolean WaintingForMoney = false;
    
    void ToggleWait()
    {
        if (WaitingForName) WaitingForName = false;
        else WaitingForName = true;
    }
      
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

       
    public void startDocument() throws SAXException {
        Console.WriteLine("**********Statistiky evidence:**********");
        
         
                
    }
      
    public void endDocument() throws SAXException {
        Console.WriteLine("Prehled ridicu a jejich postihu:");
        
        //pro kazdou osobu
        for (String osoba : Stats.osoby.keySet()) {
            if (Stats.ridici.containsKey(osoba))
            {
                //je to i ridic
                Console.Write("Ridic "+Stats.osoby.get(osoba)+" ");
                String ridic = Stats.ridici.get(osoba);
                int Psum = 0;
                int Bsum = 0;
                for (int pokuta : Stats.pokuty.get(ridic))
                {
                    Psum += pokuta;
                }
                
                for (int body : Stats.body.get(ridic))
                {
                    Bsum += body;
                }
                
                Console.Write("nasbiral " + Bsum + " trestnych bodu a zaplatil za to " + Psum);
                Console.WriteLine("");
            }
            else
            {
                Console.WriteLine(Stats.osoby.get(osoba) + " nema zadny zaznam");
            }
            
        }
        
        
        Console.Write("Konec statistik.");
         
        
    }
    
       
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
            
        if (localName.equals("osoba"))
        {
            String RC = atts.getValue("RC");
            IdKeZpracovani = RC;
            return;
        }
        if (localName.equals("jmeno"))
        {
            if (IdKeZpracovani != null)
            {
                WaitingForName = true;
            }
            return;
        }    
        if (localName.equals("prijmeni"))
        {
            if (IdKeZpracovani != null)
            {
                WaitingForName = true;
            }            
            return;
        } 
        if (localName.equals("ridic"))
        {
            String osoba = atts.getValue("osoba");
            String CR = atts.getValue("CR");            
            Stats.ridici.put(osoba,CR);
            return;
        }
        if (localName.equals("kontrola"))
        {
            IdKeZpracovani = atts.getValue("ridic");
        }
        if (localName.equals("pokuta"))
        {
            if (Stats.body.containsKey(IdKeZpracovani))
            {
                Stats.body.get(IdKeZpracovani).add(Integer.parseInt(atts.getValue("bodu")));
            }
            else
            {
                ArrayList<Integer> t = new ArrayList<Integer>();
                t.add(Integer.parseInt(atts.getValue("bodu")));
                Stats.body.put(IdKeZpracovani, t);
            }
            return;
        }
        if (localName.equals("penez"))
        {
            WaintingForMoney = true;
        }
        
        

    }
        
    public void endElement(String uri, String localName, String qName) throws SAXException {

        WaitingForName = false;
        if (localName.equals("osoba") || localName.equals("kontrola"))
        {
            IdKeZpracovani = null;
        }
        if (localName.equals("penez"))
        {
            WaintingForMoney = false;
        }
         
        
    }
                 
    public void characters(char[] ch, int start, int length) throws SAXException
    {
        if (WaitingForName)
        {
            StringBuffer S = new StringBuffer();
            for (int i = start; i < length ;i++) {
                if (!Character.isWhitespace(ch[i]))
                {
                    S.append(ch[i]);
                }
            }
            
            if (Stats.osoby.containsKey(IdKeZpracovani))
            {
                String tmp = Stats.osoby.get(IdKeZpracovani);
                tmp += " " + S.toString();
                Stats.osoby.put(IdKeZpracovani,tmp);
            }
            else
            {
               Stats.osoby.put(IdKeZpracovani,S.toString());
            }            
        }
        else if (WaintingForMoney)
        {
            StringBuffer S = new StringBuffer();
            for (int i = start; i < length ;i++) {
                if (!Character.isWhitespace(ch[i]))
                {
                    S.append(ch[i]);
                }
            }
            
            Integer pokuta = Integer.parseInt(S.toString());
            
            if (Stats.pokuty.containsKey(IdKeZpracovani))
            {
                Stats.pokuty.get(IdKeZpracovani).add(pokuta);
            }
            else
            {
                ArrayList<Integer> t = new ArrayList<Integer>();
                t.add(pokuta);
                Stats.pokuty.put(IdKeZpracovani, t);
            }
            
        }
    }
    
       
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
         
        
    }
   
    public void endPrefixMapping(String prefix) throws SAXException {
    
         
    
    }

       
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
         
        
    }

          
    public void processingInstruction(String target, String data) throws SAXException {
      
       
            
    }
         
    public void skippedEntity(String name) throws SAXException {
    
       
    
    }
}