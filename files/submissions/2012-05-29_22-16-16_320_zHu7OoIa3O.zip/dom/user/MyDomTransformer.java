package user;

/*
 * Provede transformaci XML dokumentu.
 * Ze dvou elementu u osoby - jmeno a prijmeni - udela jeden novy atribut.
 * Smaze kontroly, u kterych nebyl zjisteny zadny prestupek.
 * Zrusi atribut mena u pokuty a identifikator meny pripise k castce.
 * Zrusi atribut auto u kontroly a vlozi kopii elementu, na ktery vedla reference z puvodniho atributu 
 */

import com.sun.org.apache.xerces.internal.dom.AttrImpl;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

public class MyDomTransformer {

    private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "datanew.xml";

    public static void main(String[] args) {
        
        try {
            
             
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

             
            dbf.setValidating(false);

             
            DocumentBuilder builder = dbf.newDocumentBuilder();

             
            Document doc = builder.parse(VSTUPNI_SOUBOR);

             
            transform(doc);

             
            TransformerFactory tf = TransformerFactory.newInstance();

             
            Transformer writer = tf.newTransformer();

             
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

             
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


        } catch (Exception e) {
            
            e.printStackTrace();
            
        }
    }

    
    public static void transform(Document doc) {
        
        Element root = doc.getDocumentElement();
        
        //sjednotim jmeno a prijmeni
        NodeList osoby = root.getElementsByTagName("osoba");

        for (int i = 0; i < osoby.getLength(); i++) {
            Element e = (Element)osoby.item(i);
            NodeList jmenouzel = e.getElementsByTagName("jmeno");
            String jmeno = jmenouzel.item(0).getTextContent().trim();
            
            NodeList prijmeniuzel = e.getElementsByTagName("prijmeni");
            String prijmeni = prijmeniuzel.item(0).getTextContent().trim();
            
            
            Element novy = doc.createElement("jmeno");
            novy.setTextContent(jmeno + " " + prijmeni);
            Attr a = doc.createAttribute("jmeno");
            a.setTextContent(jmeno + " " + prijmeni);
            
            e.removeChild(jmenouzel.item(0));
            e.removeChild(prijmeniuzel.item(0));
            
            e.setAttribute("jmeno", jmeno+" "+prijmeni);
            
            String s = "";  
        }
        
        NodeList pokuty = root.getElementsByTagName("penez");
        for (int i = 0; i < pokuty.getLength(); i++) {
            Element e = (Element)pokuty.item(i);
            String mena = e.getAttribute("mena");
            e.removeAttribute("mena");            
            
            e.setTextContent(e.getTextContent().trim() +" "+ mena.trim());
        }
        
        NodeList prestupky = root.getElementsByTagName("prestupek");
        for (int i = 0; i < prestupky.getLength(); i++) {
            Element e = (Element)prestupky.item(i);
            
            if (e.getElementsByTagName("pokuta").getLength() == 0)
            {
                e.getParentNode().removeChild(e);
            }
        }
        
        NodeList Auta = root.getElementsByTagName("auto");
        HashMap<String,Element> auta = new HashMap<String,Element>();
        for (int i = 0; i < Auta.getLength(); i++) {
            auta.put(((Element)Auta.item(i)).getAttribute("SPZ"),(Element)Auta.item(i));
        }
        
        NodeList Kontroly = root.getElementsByTagName("kontrola");
        for (int i = 0; i < Kontroly.getLength(); i++) {
            Element e = (Element)Kontroly.item(i)            ;
            String Auto = e.getAttribute("auto");
            e.removeAttribute("auto");
            
            e.appendChild(auta.get(Auto).cloneNode(true));
        }
        
            
            
        }
        
        
        
        
        
}