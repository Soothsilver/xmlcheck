package user;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.transform.Transformer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MyDomTransformer {

    /**
     * private class for film
     * reason: sorting
     *
     * @see Comparable
     */
    private class Film implements Comparator, Comparable {
        private String name;
        private Node node;

        private Film(String name, Node node) {
            this.name = name;
            this.node = node;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Node getNode() {
            return node;
        }

        public void setNode(Node node) {
            this.node = node;
        }

        public int compare(Object o1, Object o2) {
            if (o1 instanceof Film && o2 instanceof Film) {
                return ((Film) o1).getName().compareToIgnoreCase(((Film) o2).getName());
            }
            return 0;
        }

        public int compareTo(Object o) {
            if (this.getName() != null && o != null && o instanceof Film) {
                return this.getName().compareToIgnoreCase(((Film) o).getName());
            }
            return 0;
        }

        @Override
        public String toString() {
            return this.name;
        }
    }


    private static final String DUBBING = "dabing";


    public void transform(Document xmlDocument) {
        /**
         * replace dubbing to element value
         */
        NodeList dubbingList = xmlDocument.getElementsByTagName(DUBBING);
        for (int i = 0; i < dubbingList.getLength(); i++) {
            Node dubbed = dubbingList.item(i);
            /**
             * create value
             */
            Node value = xmlDocument.createElement("value");
            /**
             * get value of attr value on dubbing
             */
            String nodeValue = dubbed.getAttributes().getNamedItem("value").getNodeValue();
            value.appendChild(xmlDocument.createTextNode(nodeValue));
            /**
             * append value
             */
            dubbed.appendChild(value);
            /**
             * remove original attr value
             */
            dubbed.getAttributes().removeNamedItem("value");
        }

        /**
         * get films
         */
        NodeList filmList = xmlDocument.getElementsByTagName("film");
        List<Film> films = new ArrayList<Film>();
        for (int i = 0; i < filmList.getLength(); i++) {
            NodeList childList = filmList.item(i).getChildNodes();
            /**
             * find title
             */
            for (int j = 0; j < childList.getLength(); j++) {
                if (childList.item(j).getNodeName().equals("titul")) {
                    /**
                     * create and append to list
                     */
                    Film film = new Film(childList.item(j).getFirstChild().getNodeValue(), filmList.item(i));
                    films.add(film);
                }
            }

        }
        /**
         * using Collestions appi for sorting
         * @see Collections
         */
        Collections.sort(films);
        Node filmsElement = xmlDocument.getElementsByTagName("filmy").item(0);
        int size = filmList.getLength();
        /**
         * replace has problems so--> remove and add
         */
        for (int i = 0; i < size; i++) {
            Node toRemove = filmList.item(i);
            if (toRemove != null) {
                /**
                 * remove
                 */
                filmsElement.removeChild(toRemove);
            }
        }
        /**
         * added new one (sorted)
         */
        for (int i = 0; i < size; i++) {
            filmsElement.appendChild(films.get(i).getNode());
        }


    }

}
