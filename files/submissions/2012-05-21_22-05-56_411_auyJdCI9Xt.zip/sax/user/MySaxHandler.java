package user;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {

    private String buf;

    private static final String MORGAN_FREEMAN = "Morgan Freeman";
    private static final String ACTOR = "herec";

    private static final String VALUE = "hodnota";
    private static final String VALUES = "hodnoceni";

    private static final String GENRE = "zanr";
    private static final String DRAMA = "Drama";

    private static final String LENGTH = "delka";


    private boolean isActor;
    private boolean isMorganFreeman;
    private boolean isDrama;


    private int morganFreemanFilmRatingCount;
    private int morganFreemanFilmRatingSum;

    private int dramaLengthSum;

    private int totalCountOfElement;

    private int totalTextElement;


    public MySaxHandler() {
        buf = "";
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        /**
         * don't need but for sure
         */
        if (qName.equals(ACTOR)) {
            isActor = true;
        }
        /**
         * increments :)
         */
        totalCountOfElement++;
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        /**
         * On actor
         */
        if (qName.equals(ACTOR)) {
            /**
             * Movie contains Morgan Freeman as a actor
             */
            if (buf.equals(MORGAN_FREEMAN)) {
                isMorganFreeman = true;
            }
            isActor = false;
        }

        if (qName.equals(VALUE)) {
            /**
             * if on morgan freeman count his ratings
             */
            if (isMorganFreeman) {
                morganFreemanFilmRatingCount++;
                morganFreemanFilmRatingSum += Integer.valueOf(buf);
            }
        }

        /**
         * on genre
         */
        if (qName.equals(GENRE)) {
            /**
             * is drama ?
             */
            if (buf.equals(DRAMA)) {
                isDrama = true;
            }
        }

        /**
         * count length of drama in minutes
         */
        if (qName.equals(LENGTH)) {
            if (isDrama) {
                /**
                 * need to remove " min" sufffix
                 */
                dramaLengthSum += Integer.valueOf(buf.replace(" min",""));
                isDrama = false;
            }
        }

        /**
         * to count text elements
         */
        try {
            Integer.valueOf(buf);


        } catch (NumberFormatException e) {
            totalTextElement++;
        }


        /**
         * at end of Values reset
         */
        if (qName.equals(VALUES)) {
            isMorganFreeman = false;
            isDrama = false;
        }

    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        /**
         * read value of elements
         */
        buf = (new String(ch)).substring(start, start + length);
    }

    @Override
    public void endDocument() throws SAXException {
        super.endDocument();
        System.out.println("Morgan Freeman ration Rating is: " + morganFreemanFilmRatingSum * 1.0 / morganFreemanFilmRatingCount);

        System.out.println("At our video rental you will be scared for: " + dramaLengthSum + " minutes");

        System.out.println("Total count of text element is: " + totalTextElement);
        System.out.println("Total count of element is: " + totalCountOfElement);

    }
}
