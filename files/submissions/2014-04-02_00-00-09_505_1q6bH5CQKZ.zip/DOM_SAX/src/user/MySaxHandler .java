

import java.util.ArrayList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 * Main class for SAX parsing
 *
 * @author XML Technologies
 */
public class MySaxHandler  {

    // Path to input file
    private static final String INPUT_FILE = "data.xml";

    /**
     * Main method
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {



        try {

            // Create parser instance
            XMLReader parser = XMLReaderFactory.createXMLReader();

            // Create input stream from source XML document
            InputSource source = new InputSource(INPUT_FILE);

            // Set our custom content handler for handling SAX events (it must implements ContentHandler interface)
            parser.setContentHandler(new CustomContentHandler());

            // Process input data
            parser.parse(source);

        } catch (Exception e) {

            e.printStackTrace();

        }

    }
}

/**
 * Out custom content handler for managing SAX events Implements methods of the
 * abstract class ContentHandler.
 * @see http://www.saxproject.org/apidoc/org/xml/sax/ContentHandler.html#processingInstruction%28java.lang.String,%20java.lang.String%29
 */
class CustomContentHandler implements ContentHandler {

    // Helper variable to store location of the handled event
    Locator locator;

    /**
     * Sets the locator
     *
     * @param Locator locator location in the file
     */
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Method to handle "document start"
     *
     * @throws SAXException
     */
    @Override
    public void startDocument() throws SAXException {
        // ...
    }

    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
       
    	 System.out.print("Prumerny vek zakazniku je: ");
    	 int sumAges = 0;
    	 for (Integer age : ages) {
    		 sumAges += age;
    	 }
         System.out.println(sumAges / ages.size());
         
         System.out.print("Nejdelsi prijmeni zakaznika je: ");
         System.out.println(maxSurname + " a jeho delka je " + maxLengthOfSurname);
    }

    List<Integer> ages = new ArrayList<Integer>();
    int maxLengthOfSurname = 0;
    String maxSurname;
    String s;
    
    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
     
    	 if (localName.equals("customer")) {
             for (int i = 0; i < atts.getLength(); ++i) {
                 if(atts.getLocalName(i).equals("age")) {
                	 ages.add(Integer.parseInt(atts.getValue(i)));
                 }
             }
         }
     }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
     	 
   	 	if (localName.equals("surname")) {
            if (maxLengthOfSurname < s.length()) {
            	maxSurname = s;
            	maxLengthOfSurname = s.length();
            }
        }
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        
    	s = new String(chars, start, length); 
    }

    /**
     * Method to handle " start of namespace declaration"
     *
     * @param prefix Prefix of the namespace
     * @param uri URI of the namespace
     * @throws SAXException
     */
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    /**
     * Method to handle "end of namespace declaration"
     *
     * @param prefix
     * @throws SAXException
     */
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    /**
     * Method to handle "ignoring of whitespaces" Text is in array 'chars' from
     * position ('start') to ('start' + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     * @throws SAXException
     */
    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
        // ...
    }

    /**
     * Method to handle "processing instructions"
     *
     * @param target The processing instruction target
     * @param data  The processing instruction data
     * @throws SAXException
     */
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

    /**
     * Method to handle "unprocessed entity"
     *
     * @param name
     * @throws SAXException
     */
    @Override
    public void skippedEntity(String name) throws SAXException {
        // ...
    }
}
