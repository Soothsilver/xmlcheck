
import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

/**
 * ASSIGNMENT: Update document to be able to transform input XML document to
 * output document by actions mentioned in comments of processTree method.
 */
public class MyDomTransformer  {

    private static final String INPUT_FILE = "data.xml";
    private static final String OUTPUT_FILE = "data.out.xml";

    /**
     * Main method
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {

        try {

            // DocumentBuilderFactory creates DOM parsers
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            // We don't want to validate file
            dbf.setValidating(false);

            // Creating of DOM parser instance
            DocumentBuilder builder = dbf.newDocumentBuilder();

            // Parser processes input file and creates a DOM tree of objects
            Document doc = builder.parse(INPUT_FILE);

            // DOM tree processing
            processTree(doc);

            // TransformerFactory creates an object for DOM serialization
            TransformerFactory tf = TransformerFactory.newInstance();

            // Transformer serializes DOM tree
            Transformer writer = tf.newTransformer();

            // Setting of output file encoding
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            // Run transformation of DOM tree to XML document
            writer.transform(new DOMSource(doc), new StreamResult(new File(OUTPUT_FILE)));


        } catch (Exception e) {

            e.printStackTrace();

        }
    }

    /**
     * Process document tree
     *
     * @param doc Document to be parsed
     */
    private static void processTree(Document doc) {
        
    	//Add new customer
    	Element customer = doc.createElement("customer");
    	customer.setAttribute("id", "c5");
    	customer.setAttribute("age", "21");
    	customer.appendChild(doc.createElement("firstname")).setTextContent("Jan");
    	customer.appendChild(doc.createElement("surname")).setTextContent("Holik");
    	customer.appendChild(doc.createElement("idNumber")).setTextContent("9401015432");
    	
    	Element contactInformation = doc.createElement("contactInformation");
    	Element address = doc.createElement("address");
    	address.appendChild(doc.createElement("street")).setTextContent("Plzenska");
    	address.appendChild(doc.createElement("houseNumber")).setTextContent("34");
    	address.appendChild(doc.createElement("city")).setTextContent("Praha 5");
    	address.appendChild(doc.createElement("postalCode")).setTextContent("15000");
    	address.appendChild(doc.createElement("country")).setTextContent("Ceska republika");
    	contactInformation.appendChild(address);
    	Element phones = doc.createElement("phones");
    	phones.appendChild(doc.createElement("phone")).setTextContent("60475832");
    	phones.appendChild(doc.createElement("phone")).setTextContent("272834234");
    	contactInformation.appendChild(phones);
    	Element emails = doc.createElement("emails");
    	phones.appendChild(doc.createElement("email")).setTextContent("jan.holik@seznam.cz");
    	contactInformation.appendChild(emails);
    	contactInformation.appendChild(doc.createElement("primaryContact")).setTextContent("phone");
    	customer.appendChild(contactInformation);
    	
    	customer.appendChild(doc.createElement("courses"));
    
    	Element customers = (Element)doc.getElementsByTagName("customers").item(0);
    	customers.appendChild(customer);
    	
    	//Delete courses with price less than 6000
    	NodeList courses = doc.getElementsByTagName("course");
    	
    	for (int i = courses.getLength()-1; i >= 0; --i) {
    		
    		NodeList course = courses.item(i).getChildNodes();
    		for (int j = course.getLength()-1; j >= 0; --j) {
	    		
    			Node node = course.item(j);
    			if (node.getNodeName().equals("price")) {
    				
    				if (Integer.parseInt(node.getTextContent()) < 6000) {
    					
    						node.getParentNode().getParentNode().removeChild(courses.item(i));
    				}
    			}
        	}
    	}
    }
}
