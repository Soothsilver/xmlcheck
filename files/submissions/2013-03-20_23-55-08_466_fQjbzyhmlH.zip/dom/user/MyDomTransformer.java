package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class MyDomTransformer {

    public void transform(Document xmlDocument) {

        /* Odstraníme filmy s cenou vyšší než 130 Kč */
        NodeList movies = xmlDocument.getElementsByTagName("movies");
        for (int i = movies.getLength() - 1; i >= 0; i--) {
            Element movie = (Element) movies.item(i);
            Element moviePrice = (Element) movie.getElementsByTagName("price").item(0);

            int price = Integer.parseInt(moviePrice.getTextContent());
            if (price > 130) {
                movie.getParentNode().removeChild(movie);
            }
        }

        /* Navýšíme cenu zbylých filmů o 100 Kč */
        movies = xmlDocument.getElementsByTagName("movies");
        for (int i = movies.getLength() - 1; i >= 0; i--) {
            Element movie = (Element) movies.item(i);
            Element moviePrice = (Element) movie.getElementsByTagName("price").item(0);

            int price = Integer.parseInt(moviePrice.getTextContent());
            moviePrice.setTextContent(Integer.toString(price + 100));
        }
    }
}
