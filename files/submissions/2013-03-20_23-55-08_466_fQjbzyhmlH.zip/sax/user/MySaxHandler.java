package user;

import java.io.IOException;
import java.util.jar.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;





/**
 * Out custom content handler for managing SAX events Implements methods of the
 * abstract class ContentHandler.
 *
 * @see
 * http://www.saxproject.org/apidoc/org/xml/sax/ContentHandler.html#processingInstruction%28java.lang.String,%20java.lang.String%29
 */
public class MySaxHandler extends DefaultHandler {

    /* Handler po průchodu najde:
     * 1) film s nejdelším názvem,
     * 2) hodnotu lexikograficky největšího atributu id,
     * 3) počet filmů s cenou > 130 Kč.
     * 
     * Hodnoty se uloží do následujících tří proměnných.
     */
    String longestName = "";
    String maxId = "";
    int numExpensiveMovies = 0;
    
    String curElName = "";
    String movieName = "";
    String moviePrice = "";
    
    // Helper variable to store location of the handled event
    Locator locator;

    /**
     * Sets the locator
     *
     * @param Locator locator location in the file
     */
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Method to handle "document start"
     *
     * @throws SAXException
     */
    @Override
    public void startDocument() throws SAXException {
        // ...
    }

    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
        // ...
    }

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        curElName = localName;

        if (localName.equals("movie")) {
            movieName = "";
            moviePrice = "";

            String movieId = atts.getValue("id");
            if (movieId.compareTo(maxId) > 0) {
                maxId = movieId;
            }
        }
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (localName.equals("movie")) {
            if (movieName.length() > longestName.length()) {
                longestName = movieName;
            }
            if (moviePrice != "") {
                int price = Integer.parseInt(moviePrice);
                if (price > 130) {
                    numExpensiveMovies++;
                }
            }
        }
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        String s = new String(chars, start, length);
        if (curElName.equals("name")) {
            movieName += s;
        } else if (curElName.equals("price")) {
            moviePrice += s;
        }
    }

    /**
     * Method to handle " start of namespace declaration"
     *
     * @param prefix Prefix of the namespace
     * @param uri URI of the namespace
     * @throws SAXException
     */
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    /**
     * Method to handle "end of namespace declaration"
     *
     * @param prefix
     * @throws SAXException
     */
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    /**
     * Method to handle "ignoring of whitespaces" Text is in array 'chars' from
     * position ('start') to ('start' + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     * @throws SAXException
     */
    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
        // ...
    }

    /**
     * Method to handle "processing instructions"
     *
     * @param target The processing instruction target
     * @param data The processing instruction data
     * @throws SAXException
     */
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

    /**
     * Method to handle "unprocessed entity"
     *
     * @param name
     * @throws SAXException
     */
    @Override
    public void skippedEntity(String name) throws SAXException {
        // ...
    }
}