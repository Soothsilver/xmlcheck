package user;

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;

//projde dokument a vypocita prumernou hloubhu uzlu a take nam rekne, jak je hluboky dokument
public class MySaxHandler extends DefaultHandler {
    Locator locator;
    public static int[] hloubkaPrvku;
    public static int maxHloubka;
    public static int hloubka;
    public static void main(String[] args) {
        String sourcePath = "data.xml";
        hloubkaPrvku = new int[10];
        maxHloubka = 0;
        hloubka = 0;
        try {

            XMLReader parser = XMLReaderFactory.createXMLReader();
            InputSource source = new InputSource(sourcePath);
            parser.setContentHandler(new MySaxHandler());
            parser.parse(source);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("maximalni hloubka dokumentu:");
        System.out.println(maxHloubka);
        int pp1=0;
        int pp2=0;
        for(int i = 0;i<maxHloubka;++i)
        {
            pp1 = pp1 + hloubkaPrvku[i]*(i+1);
            pp2 = pp2 + hloubkaPrvku[i];
        }
        double prumer = 0;
        prumer = pp1/pp2;
        System.out.println("prumerna hloubka dokumentu:");
        System.out.println(prumer);
    }
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        ++hloubka;
        if(hloubka>maxHloubka)
            maxHloubka = hloubka;
        if(hloubka>hloubkaPrvku.length)
        {
            int[] pp = new int[hloubkaPrvku.length+10];
            for(int i=0;i<hloubkaPrvku.length;++i)
                pp[i]=hloubkaPrvku[i];
            hloubkaPrvku=pp;
        }
        hloubkaPrvku[hloubka-1] = hloubkaPrvku[hloubka-1]+1;
    }
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        --hloubka;
    }
    
}
