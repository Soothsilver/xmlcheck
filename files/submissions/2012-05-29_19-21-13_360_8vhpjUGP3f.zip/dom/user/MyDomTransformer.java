package user;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

//zmeni vsechny atribury na elementy
public class MyDomTransformer {
    private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "data.out.xml";
    private static Document doc;
    
    public static void main(String[] args) {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setValidating(false);
            DocumentBuilder builder = dbf.newDocumentBuilder();
            doc = builder.parse(VSTUPNI_SOUBOR);
            transform(doc);
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer writer = tf.newTransformer();
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));
        } catch (Exception e) {
            e.printStackTrace();
        }    
    }
    public static void transform (Document xmlDocument) {
        //ze znalosti xml dokumentu vime, ze atributy jsou v elementu - zakaznik, videom, pujcka a rezervace
        //pro zakaznika
        NodeList zakaznici = xmlDocument.getElementsByTagName("zakaznik");
        for(int i = 0; i < zakaznici.getLength();++i)
        {
            Node zakaznik = zakaznici.item(i);
            String text;
            String jmeno;
            for(int j = 0;j < zakaznik.getAttributes().getLength();++j)
            {
                jmeno = zakaznik.getAttributes().item(j).getNodeName();
                text = zakaznik.getAttributes().item(j).getTextContent();
                Element elem = xmlDocument.createElement(jmeno);
                elem.appendChild(xmlDocument.createTextNode(text));
                
                zakaznik.getAttributes().removeNamedItem(jmeno);
                zakaznik.appendChild(elem);
            }
        }
        
        //pro video
        NodeList videa = xmlDocument.getElementsByTagName("video");
        for(int i = 0; i < videa.getLength();++i)
        {
            Node video = videa.item(i);
            String text;
            String jmeno;
            for(int j = 0;j < video.getAttributes().getLength();++j)
            {
                jmeno = video.getAttributes().item(j).getNodeName();
                text = video.getAttributes().item(j).getTextContent();
                Element elem = xmlDocument.createElement(jmeno);
                elem.appendChild(xmlDocument.createTextNode(text));
                
                video.getAttributes().removeNamedItem(jmeno);
                video.appendChild(elem);
            }
            //z duvodu me nepochopitelnych vynechava - idV
            text = video.getAttributes().getNamedItem("idV").getTextContent();
            Element elem = xmlDocument.createElement("idV");
            elem.appendChild(xmlDocument.createTextNode(text));
                
            video.getAttributes().removeNamedItem("idV");
            video.appendChild(elem);
        }
        
        //pro pujcky
        NodeList pujcky = xmlDocument.getElementsByTagName("pujcka");
        for(int i = 0; i < pujcky.getLength();++i)
        {
            Node pujcka = pujcky.item(i);
            String text;
            String jmeno;
            for(int j = 0;j < pujcka.getAttributes().getLength();++j)
            {
                jmeno = pujcka.getAttributes().item(j).getNodeName();
                text = pujcka.getAttributes().item(j).getTextContent();
                Element elem = xmlDocument.createElement(jmeno);
                elem.appendChild(xmlDocument.createTextNode(text));
                
                pujcka.getAttributes().removeNamedItem(jmeno);
                pujcka.appendChild(elem);
            }
            //z duvodu me nepochopitelnych vynechava - vraceno
            text = pujcka.getAttributes().getNamedItem("vraceno").getTextContent();
            Element elem = xmlDocument.createElement("vraceno");
            elem.appendChild(xmlDocument.createTextNode(text));
                
            pujcka.getAttributes().removeNamedItem("vraceno");
            pujcka.appendChild(elem);
        }
        
        //pro rezervace
        NodeList rezervac = xmlDocument.getElementsByTagName("rezervace");
        for(int i = 0; i < rezervac.getLength();++i)
        {
            Node rezervace = rezervac.item(i);
            String text;
            String jmeno;
            for(int j = 0;j < rezervace.getAttributes().getLength();++j)
            {
                jmeno = rezervace.getAttributes().item(j).getNodeName();
                text = rezervace.getAttributes().item(j).getTextContent();
                Element elem = xmlDocument.createElement(jmeno);
                elem.appendChild(xmlDocument.createTextNode(text));
                
                rezervace.getAttributes().removeNamedItem(jmeno);
                rezervace.appendChild(elem);
            }
        }
    }
}
