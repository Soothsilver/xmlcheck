package user;

import org.w3c.dom.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MyDomTransformer {
    public void transform(Document doc) {
        addNewBook(doc);
        sortBooks(doc);
        System.out.println("Books have been sorted and new book has been added.");
    }

    private void addNewBook(Document doc) {
        Element book = doc.createElement("book");

        Attr id = doc.createAttribute("id");
        id.setValue("b_45");
        Attr genre = doc.createAttribute("genre");
        genre.setValue("Sci-fi");
        book.setAttributeNode(id);
        book.setAttributeNode(genre);

        Element name = doc.createElement("name");
        name.setTextContent("Generated book");
        Element year = doc.createElement("year");
        year.setTextContent("2547");
        Element author = doc.createElement("author");
        author.setTextContent("Peter Sourek");
        Element description = doc.createElement("description");
        description.setTextContent("Famous bestseller from Peter Sourek about never ending struggle to complete homework from xml");

        book.appendChild(name);
        book.appendChild(year);
        book.appendChild(author);
        book.appendChild(description);
        doc.getElementsByTagName("books").item(0).appendChild(book);
    }

    private void sortBooks(Document doc) {
        NodeList books = doc.getElementsByTagName("book");

        List<Node> sortedBooks = new ArrayList<Node>();
        while (books.getLength() > 0) {

            sortedBooks.add(books.item(0));
            books.item(0).getParentNode().removeChild(books.item(0));
        }
        Collections.sort(sortedBooks, new Comparator<Node>() {
            public int compare(Node node, Node node2) {
                if (node.getNodeName().equals("book") && node2.getNodeName().equals("book")) {
                    String node1Name = getBookName(node);
                    String node2Name = getBookName(node2);
                    return node1Name.compareToIgnoreCase(node2Name);
                } else {
                    return -1;
                }
            }
        });
        for (Node n : sortedBooks) {
            doc.getElementsByTagName("books").item(0).appendChild(n);
        }
    }

    private String getBookName(Node book) {
        if (!book.getNodeName().equals("book"))
            return null;
        NodeList ch = book.getChildNodes();
        for (int i = 0; i < ch.getLength(); i++) {
            if (ch.item(i).getNodeName().equals("name")) {
                return ch.item(i).getTextContent();
            }
        }
        return null;
    }
}