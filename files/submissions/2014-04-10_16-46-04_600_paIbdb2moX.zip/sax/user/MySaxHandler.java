package user;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import java.util.ArrayList;
import java.util.Collections;
public class MySaxHandler extends DefaultHandler {
    boolean isPlayer;
    boolean isPlayerName;
    boolean isTeam;
    boolean isTeamName;
    boolean isBestPlayer;
    
    int playerCount;
    int levelSum;
    int oldestTeamSeasonCount;
    int currentTeamSeasonCount;
    int bestPlayerLevel;
    
    String currentTeamName;
    String currentTeamId;
    String oldestTeamName;
    String oldestTeamId;
    String bestPlayerName;
    
    ArrayList<String> playerNames;

    @Override
    public void startDocument() throws SAXException {
        this.isPlayer = false;
        this.isPlayerName = false;
        this.isTeam = false;
        this.isTeamName = false;
        this.isBestPlayer = false;
        
        this.playerCount = 0;
        this.levelSum = 0;
        this.oldestTeamSeasonCount = 0;
        this.currentTeamSeasonCount = 0;
        this.bestPlayerLevel = 0;
        
        this.currentTeamName = "";
        this.currentTeamId = "";
        this.oldestTeamName = "";
        this.oldestTeamId = "";
        this.bestPlayerName = "";

        this.playerNames = new ArrayList<String>();
    }

    @Override
    public void endDocument() throws SAXException {
        System.out.println("Average player's level: " + levelSum / playerCount);
        System.out.println("Names of players in alphabetical order:");
        Collections.sort(playerNames);
        for (String name : playerNames) System.out.println("\t" + name);
        System.out.println("The oldest team is " + oldestTeamName + " with " + oldestTeamSeasonCount + " seasons." );
        System.out.println("The best player from the oldest team is " + bestPlayerName + " with level " + bestPlayerLevel + ".");
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if ("player".equals(localName)) {
            isPlayer = true;
            playerCount++;
            int level = 0;
            String team = "";
            for (int i = 0; i < atts.getLength(); i++) {
                if ("level".equals(atts.getQName(i))) {
                    level = Integer.parseInt(atts.getValue(i));
                }
                else if ("team".equals(atts.getQName(i))) {
                    team = atts.getValue(i);
                }
            }   
            levelSum += level;
            if ((team.equals(oldestTeamId)) && (level > bestPlayerLevel))
            {
                bestPlayerLevel = level;
                isBestPlayer = true;
            }       
        }
        else if ("name".equals(localName)){
            if (isPlayer) isPlayerName = true;
            if (isTeam) isTeamName = true;
        }
        else if ("team".equals(localName)){
            isTeam = true;
            for (int i = 0; i < atts.getLength(); i++)
            {
                if ("id".equals(atts.getQName(i))) currentTeamId = atts.getValue(i);
            }
        }
        else if ("season".equals(localName)){
            if (isTeam) currentTeamSeasonCount++;
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if ("player".equals(localName)) {
            isPlayer = false;
        }
        else if ("name".equals(localName)) {
            if (isPlayer) isPlayerName = false;
            if (isTeam) isTeamName = false;
        }
        else if ("team".equals(localName)) {
            if (currentTeamSeasonCount > oldestTeamSeasonCount)
            {
                oldestTeamSeasonCount = currentTeamSeasonCount;
                oldestTeamId = currentTeamId;
                oldestTeamName = currentTeamName;
            }  
            isTeam = false;
            currentTeamSeasonCount = 0;  
        }
    }

    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        if (isPlayerName)
        {
            String name = String.copyValueOf(chars, start, length);
            playerNames.add(name);
            if (isBestPlayer)
            {
                bestPlayerName = name;
                isBestPlayer = false;
            }
        }
        else if (isTeamName)
        {
            currentTeamName = String.copyValueOf(chars, start, length); 
        }
    }
}