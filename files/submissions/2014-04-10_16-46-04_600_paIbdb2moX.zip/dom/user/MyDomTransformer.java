package user;
import org.w3c.dom.Document;
import org.w3c.dom.*;
public class MyDomTransformer {
public void transform (Document xmlDocument) {
	//Removing players with no team
        NodeList players = xmlDocument.getElementsByTagName("player");
        for (int i = 0; i < players.getLength(); i++)
        {
            if (players.item(i).getAttributes().getNamedItem("team") == null) players.item(i).getParentNode().removeChild(players.item(i));
        }
        
        //Adding special player Admin and his team
        Element team = xmlDocument.createElement("team");
        team.setAttribute("id","t00");
        
        Element name = xmlDocument.createElement("name");
        name.setTextContent("AdminTeam");
        
        Element members = xmlDocument.createElement("members");
        members.setAttribute("count", "1");
        
        Element created = xmlDocument.createElement("created");
        created.setAttribute("day", "11");
        created.setAttribute("month", "4");
        created.setAttribute("year", "2014");
        
        Element founder = xmlDocument.createElement("founder");
        founder.setAttribute("id", "p00");
        
        created.appendChild(founder);
        
        Element leader = xmlDocument.createElement("leader");
        leader.setAttribute("id", "p00");
        
        team.appendChild(name);
        team.appendChild(members);
        team.appendChild(created);
        team.appendChild(leader);
        
        xmlDocument.getElementsByTagName("teams").item(0).appendChild(team);
        
        Element player = xmlDocument.createElement("player");
        player.setAttribute("id", "p00");
        player.setAttribute("team", "t00");
        player.setAttribute("level", "0");
        
        Element playerName = xmlDocument.createElement("name");
        playerName.setTextContent("Admin");
        
        player.appendChild(playerName);
        
        xmlDocument.getElementsByTagName("players").item(0).appendChild(player);
  }
}