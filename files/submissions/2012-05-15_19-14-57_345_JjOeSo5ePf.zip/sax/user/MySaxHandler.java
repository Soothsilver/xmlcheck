package user;

import java.util.HashSet;
import java.util.Set;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

public class MySaxHandler extends DefaultHandler { 
	
    // Umožňuje zacílit místo v dokumentu, kde vznikla aktualní událost
    Locator locator;
    
    //pole stringu s nejdelsim nazvem elementu, muze jich byt vice
    String[] longest = new String[1];
    //pocet elementu s atributy
    int withAtts = 0;
    //pocet elementu s textovym obsahem
    int textEl = 0;
    
    //mnozina elementu s atributy
    Set<String> elementsWithAttributes = new HashSet<String>();
    //mnozina elementu s atributy
    Set<String> textElements = new HashSet<String>();
    
    public static void main(String[] args) {
    	
    	MySaxHandler m = new MySaxHandler();
    	
        // Cesta ke zdrojovému XML dokumentu  
        String sourcePath = "data.xml";

        try {
            
            // Vytvoríme instanci parseru.
            XMLReader parser = XMLReaderFactory.createXMLReader();
            
            // Vytvoríme vstupní proud XML dat.
            InputSource source = new InputSource(sourcePath);
            
            // Nastavíme náą vlastní content handler pro obsluhu SAX událostí.
            parser.setContentHandler(m);
            
            // Zpracujeme vstupní proud XML dat.
            parser.parse(source);
            
            //1. uloha - maximální délka názvu/ů elementu/ů (vrátí všechny pokud jich je více)
            for(String s: m.longest) System.out.println(s);
            		
            //2. uloha - počet elementů s atributy
            System.out.println("Počet (různých) elementů s atributy: " + m.withAtts);
            
            //3. uloha - počet elementů s textovým obsahem
            System.out.println("Počet (různých) elementů s textovym obsahem: " + m.textEl);
            for(String s: m.textElements) System.out.println(s);
            		
        } catch (Exception e) {
        
            e.printStackTrace();
            
        }
        
    }
    
    /**
     * Nastaví locator
     */    
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }
    
    
    String currElement;

    /**
     * Obsluha události "začátek elementu".
     * @param uri URI jmenného prostoru elementu (prázdné, pokud element není v žádném jmenném prostoru)
     * @param localName Lokální jméno elementu (vždy neprázdné)
     * @param qName Kvalifikované jméno (tj. prefix-uri + ':' + localName, pokud je element v nějakém jmenném prostoru, nebo localName, pokud element není v žádném jmenném prostoru)
     * @param atts Atributy elementu     
     */   
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
    	
    	
    	//1. uloha - maximální délka názvu/ů elementů
    	if (longest[0] == null) {
    		longest[0] = localName;
    	} else if(longest[0].length() < localName.length()){
    		if(longest.length > 1) longest = new String[1];
    		longest[0] = localName; 
    	} else if(longest[0].length() == localName.length()){
    		String[] tmp = new String[longest.length + 1];
    		for (int i = 0; i < longest.length; i++) tmp[i] = longest[i];
    		tmp[tmp.length-1] = localName;
    		longest = tmp;
    	}
    	
    	//2. uloha - počet elementů s atributy.
    	
        if(atts.getLength() > 0){
        	// Jedna se o typy elementu => Pokud se najde element se stejnym nazvem nekde pozdeji v dokumentu, neni bran v potaz.
        	if(elementsWithAttributes.contains(localName)){}
        	else {
        		withAtts++;
        	}
        	elementsWithAttributes.add(localName);
        }
        
        currElement = localName;
        
    }
    /**
     * Obsluha události "konec elementu"
     * Parametry mají stejný význam jako u @see startElement     
     */   
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {

        // ...

    }
    
    int cnt = 0;
    /**
     * Obsluha události "znaková data".
     * SAX parser muľe znaková data dávkovat jak chce. Nelze tedy počítat s tím, že je celý text dorucen v rámci jednoho volání.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakovými daty
     * @param start Index zacátku úseku platných znakových dat v poli.
     * @param length Délka úseku platných znakových dat v poli.
     */   
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
    	//3. uloha - počet elementů s textovým obsahem
			String s = new String(ch, start, length);
    		
    		for (int i = 0; i < s.length(); i++) {
				if(s.charAt(i) == ' '){
					//System.out.println("==");
					cnt++;
				}
			}
    		
    		if(!( cnt == s.length()) ){

    			if(!s.equals("")) {
    				//System.out.println(s);
    				if(textElements.add(currElement)) textEl++;
    			}
    		
    		}
    	
        
    }

}
