package user;
import java.io.File;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Element;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

public class MyDomTransformer {

    private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "data_out.xml";

    public static void main(String[] args) {
    	MyDomTransformer d = new MyDomTransformer();
    	
        try {
            
            //DocumentBuilderFactory vytváří DOM parsery
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            //nebudeme validovat
            dbf.setValidating(false);

            //vytvoříme si DOM parser
            DocumentBuilder builder = dbf.newDocumentBuilder();

            //parser zpracuje vstupní soubor a vytvoří z něj strom DOM objektů
            Document doc = builder.parse(VSTUPNI_SOUBOR);

            //zpracujeme DOM strom
            d.transform(doc);

            //TransformerFactory vytváří serializátory DOM stromů
            TransformerFactory tf = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer = tf.newTransformer();

            //nastavíme kodování
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spustíme transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


        } catch (Exception e) {
            
            e.printStackTrace();
            
        }
    }
    
    /*********************************************************
    //      ukol - převést atributy na elementy
	*********************************************************/
    
	public void transform (Document doc) {
		
		NodeList list = doc.getElementsByTagName("*");
		changeToElement(list, doc);
	}
	
	private void changeToElement(NodeList list, Document doc){
		//list jmen atributu, abych je pozdeji mohl odstranit
		ArrayList<String> al = new ArrayList<String>();
		//cyklem projedu seznam nodu, pro ktere se ma operace provest
		for (int i = 0; i < list.getLength(); i++) {
			Element element = (Element)list.item(i);
			NamedNodeMap attrs = element.getAttributes();
			//timto cyklem projedu vsechny atributy a vytvorim podle nich elementy
			//System.out.println(element.getNodeName());
				for(int j = 0 ;  j < attrs.getLength() ; j++) {
					Attr attribute = (Attr)attrs.item(j);     
					Element e = doc.createElement(attribute.getName());
					element.appendChild(e);
					Text t = doc.createTextNode(attribute.getValue());
					e.appendChild(t);
					al.add(attribute.getName());
					//System.out.println(attribute.getName()+" = "+attribute.getValue());
				}
				// nakonec jeste odstranim vsechny atributy z aktualniho elementu
				for(String s: al){
					element.removeAttribute(s);
				}
			al.clear();
		 }
			
	}

}

