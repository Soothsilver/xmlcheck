package user;

import java.util.HashMap;
import java.util.Stack;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Úloha SAX: Pocet kategorii, ktere obsahuji vice programu nez dana mez.
 *
 * @author Milan Rybář <gjofum@gmail.com>
 */
public class MySaxHandler extends DefaultHandler {
    
    // horni mez pro pocet programu v kategorii
    public int MaxProgramu = 2;
    
    // vsechny kategorie - <id kategorie, pocet programu>
    private HashMap<String, Integer> kategorie = new HashMap<String, Integer>();
    // aktualni kategorie (pri prochazeni)
    private Stack<String> aktualniKategorie = new Stack<String>();

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        // zacatek kategorie
        if (localName.equals("kategorie")) {
            String kategorieId = atts.getValue("", "id");
            kategorie.put(kategorieId, 0);
            aktualniKategorie.push(kategorieId);
        } 
        // zacatek programu
        else if (localName.equals("program")) {
            // pricteme program vsem aktualne aktivnim kategoriim
            for (int i = 0; i < aktualniKategorie.size(); ++i) {
                String kategorieId = aktualniKategorie.get(i);
                kategorie.put(kategorieId, kategorie.get(kategorieId) + 1);
            }
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        // konec kategorie
        if (localName.equals("kategorie")) {
            aktualniKategorie.pop();
        }
    }

    @Override
    public void endDocument() throws SAXException {
        // spocitame kategorie, ktere obsahuji vice programu nez MaxProgramu
        int count = 0;
        for (String kategorieId : kategorie.keySet()) {
            if (kategorie.get(kategorieId) >= MaxProgramu) {
                ++count;
                // vypis vyhovujici kategorie
                //System.out.println(kategorieId);
            }
        }

        // vypiseme vysledek
        System.out.println(count);
    }
}