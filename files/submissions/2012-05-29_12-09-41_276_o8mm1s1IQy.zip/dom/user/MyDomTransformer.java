package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Úloha DOM: Transformace databaze na seznam programu. Kazdy program bude
 * obsahovat vsechna puvodni data + jeho vyrobce + vsechny kategorie, ve kterych
 * se nachazi.
 *
 * @author Milan Rybář <gjofum@gmail.com>
 */
public class MyDomTransformer {

    private Document doc;

    public void transform(Document xmlDocument) {
        doc = xmlDocument;

        // programy
        NodeList programy = doc.getElementsByTagName("program");
        for (int i = 0; i < programy.getLength(); ++i) {
            // upravime program do finalni podoby
            addAllDataToProgram(programy.item(i));
        }

        // pridame programy do noveho elementu
        Node newProgramyNode = createChild(doc.getDocumentElement(), "programy");
        for (int i = 0; i < programy.getLength(); ++i) {
            newProgramyNode.appendChild(programy.item(i));
        }

        // odstranime vse krome programu z korenoveho elementu
        NodeList rootChildren = doc.getDocumentElement().getChildNodes();
        for (int i = 0; i < rootChildren.getLength(); ++i) {
            Node child = rootChildren.item(i);
            if ((child.getNodeType() == Node.ELEMENT_NODE && !child.getNodeName().equals("programy")) || child.getNodeType() == Node.COMMENT_NODE) {
                child.getParentNode().removeChild(child);
            }
        }
    }

    private void addAllDataToProgram(Node program) {
        // autor (vyrobce) uvedeny v programu
        Node autor = findAutorInProgram(program);
        // globalni vyrobce
        Node vyrobce = findVyrobceById(autor.getAttributes().getNamedItem("id").getTextContent());
        // nahradime stareho autora vyrobcem
        program.replaceChild(vyrobce.cloneNode(true), autor);

        // vytvorime vsechny kategorie ve kterych se program nachazi
        Node kategorie = createChild(program, "vsechnyKategorie");
        addAllCategories(program, kategorie);
    }

    private Node findAutorInProgram(Node program) {
        NodeList children = program.getChildNodes();

        for (int i = 0; i < children.getLength(); ++i) {
            if (children.item(i).getNodeName().equals("autor")) {
                return children.item(i);
            }
        }

        return null;
    }

    private Node findVyrobceById(String vyrobceId) {
        NodeList vyrobci = doc.getElementsByTagName("vyrobce");

        for (int i = 0; i < vyrobci.getLength(); ++i) {
            Node vyrobce = vyrobci.item(i);
            if (vyrobce.getAttributes().getNamedItem("id").getTextContent().equals(vyrobceId)) {
                return vyrobce;
            }
        }

        return null;
    }

    private Element createChild(Node node, String name, String value) {
        Element child = doc.createElement(name);
        child.setTextContent(value);
        node.appendChild(child);
        return child;
    }

    private Element createChild(Node node, String name) {
        Element child = doc.createElement(name);
        node.appendChild(child);
        return child;
    }

    private void addAllCategories(Node currentNode, Node kategorie) {
        Node parent = currentNode.getParentNode();
        if (parent.getNodeName().equals("kategorie")) {
            addAllCategories(parent, kategorie);
            createChild(kategorie, "kategorie", parent.getAttributes().getNamedItem("nazev").getTextContent()).setAttribute("id", parent.getAttributes().getNamedItem("id").getTextContent());
        }
    }
}
