package user;

//~--- non-JDK imports --------------------------------------------------------

import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

//~--- JDK imports ------------------------------------------------------------

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class MySaxHandler extends DefaultHandler {

    /**
     * pocet elementu overall
     */
    private long attributesCount;

    /**
     * max depth of current 1st level subelement
     */
    private long currentMaxDepth;

    /**
     * list of subelement depth to compute avg
     */
    private List<Long> depths;

    /**
     * pocet elementu overall
     */
    private long elementsCount;

    /**
     * has the element text?
     */
    private boolean hasText;

    /**
     * current depth
     */
    private long level;

    // Umožňuje zacílit místo v dokumentu, kde vznikla aktualní událost
    Locator locator;

    /**
     * maximum depth of the document so far
     */
    private long maxDepth;

    /**
     * elements with attrs
     */
    private long withAttrs;

    /**
     * elements with text contents
     */
    private long withTextCount;

    /**
     * Nastaví locator
     */
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Obsluha události "začátek dokumentu"
     */
    public void startDocument() throws SAXException {

        // ...
        maxDepth        = 0;
        level           = 0;
        currentMaxDepth = 0;
        depths          = new LinkedList<Long>();
        elementsCount   = 0;
        attributesCount = 0;
        withTextCount   = 0;
        withAttrs       = 0;
    }

    /**
     * Obsluha události "konec dokumentu"
     */
    public void endDocument() throws SAXException {
        System.out.printf("Max. hloubka dokumentu: %d \n", maxDepth);

        long sum = 0;

        for (Long d : depths) {
            sum += d;
        }

        System.out.printf("Avg. hloubka dokumentu: %f \n", (depths.size() > 0)
                ? sum / (double) depths.size()
                : 0);
        System.out.printf("Pocet elementu dokumentu: %d \n", elementsCount);
        System.out.printf("Pocet atributu v dokumentu: %d \n", attributesCount);
        System.out.printf(
            "Pocet elementu v dokumentu s textovym obsahem: %d \n",
            withTextCount);
        System.out.printf("Pocet elementu v dokumentu s atributy: %d \n",
                          withAttrs);
    }

    /**
     * Obsluha události "začátek elementu".
     * @param uri URI jmenného prostoru elementu (prázdné, pokud element není v žádném jmenném prostoru)
     * @param localName Lokální jméno elementu (vždy neprázdné)
     * @param qName Kvalifikované jméno (tj. prefix-uri + ':' + localName, pokud je element v nějakém jmenném prostoru, nebo localName, pokud element není v žádném jmenném prostoru)
     * @param atts Atributy elementu
     */
    public void startElement(String uri, String localName, String qName,
                             Attributes atts)
            throws SAXException {
        ++level;

        // max depth
        if (level > maxDepth) {
            maxDepth = level;
        }

        // current max depth reset while 1st level subelement is detected
        if (level == 2) {
            currentMaxDepth = 2;
        }

        // current max depth computed in the same way as overall
        if (level > currentMaxDepth) {
            currentMaxDepth = level;
        }

        // register another element
        ++elementsCount;

        // add attributes count
        attributesCount += atts.getLength();

        if (atts.getLength() > 0) {
            ++withAttrs;
        }

        hasText = false;
    }

    /**
     * Obsluha události "konec elementu"
     * Parametry mají stejný význam jako u @see startElement
     */
    public void endElement(String uri, String localName, String qName)
            throws SAXException {
        --level;

        // got back to the 1st level subelement
        if (level == 2) {
            depths.add(new Long(currentMaxDepth));
        }

        if (hasText) {
            ++withTextCount;
        }

        hasText = false;    // stop propagation
    }

    /**
     * Obsluha události "znaková data".
     * SAX parser muľe znaková data dávkovat jak chce. Nelze tedy počítat s tím, že je celý text dorucen v rámci jednoho volání.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakovými daty
     * @param start Index zacátku úseku platných znakových dat v poli.
     * @param length Délka úseku platných znakových dat v poli.
     */
    public void characters(char[] ch, int start, int length)
            throws SAXException {
        hasText = true;
    }

    /**
     * Obsluha události "deklarace jmenného prostoru".
     * @param prefix Prefix prirazený jmennému prostoru.
     * @param uri URI jmenného prostoru.
     */
    public void startPrefixMapping(String prefix, String uri)
            throws SAXException {

        // ...
    }

    /**
     * Obsluha události "konec platnosti deklarace jmenného prostoru".
     */
    public void endPrefixMapping(String prefix) throws SAXException {

        // ...
    }

    /**
     * Obsluha události "ignorované bílé znaky".
     * Stejné chování a parametry jako @see characters
     */
    public void ignorableWhitespace(char[] ch, int start, int length)
            throws SAXException {

        // ...
    }

    /**
     * Obsluha události "instrukce pro zpracování".
     */
    public void processingInstruction(String target, String data)
            throws SAXException {

        // ...
    }

    /**
     * Obsluha události "nezpracovaná entita"
     */
    public void skippedEntity(String name) throws SAXException {

        // ...
    }
}
