package user;

//~--- non-JDK imports --------------------------------------------------------

import org.w3c.dom.*;

/**
 * ZADANI:
 * Upravte program tak, aby transformoval vstupní XML dokument na výstupní pomocí akcí
 * uvedených v komentářích metody processTree(doc).
 */
public class MyDomTransformer {

    /**
     * Zpracuje DOM strom
     */
    public void transform(Document xmlDocument) {
        Element  root         = xmlDocument.getDocumentElement();
        NodeList rootChildren = root.getChildNodes();

        // prohozeni poradi elementu... projdu odzadu, odeberu, appendnu...
        // -> z posledniho prvni, z predposledniho druhy, ...
        for (int i = rootChildren.getLength() - 1; i > -1; --i) {
            Node current = rootChildren.item(i);

            root.removeChild(current);
            root.appendChild(current);
        }

        // transformace atributu na podelementy
        
        NodeList usersContainer = root.getElementsByTagName("users");
        
        // zaroven funguje jako if na pritomnost elementu
        for (int i = 0; i < usersContainer.getLength(); ++i) {
            Node     container = usersContainer.item(i);
            NodeList users     = container.getChildNodes();

            // pro kazdeho usera vezmeme atritbuty a vyrobime z nich deti
            for (int j = 0; j < users.getLength(); ++j) {
                Node         user  = users.item(j);
                NamedNodeMap attrs = user.getAttributes();
                
                if (attrs == null) continue; //skip #text

                // projdeme vsechny atributy a vyrobime z nich deti
                for (int k = 0; k < attrs.getLength(); ++k) {
                    Node    currentAttr = attrs.item(k);
                    
                    //vyrobime dite
                    Element newElem     =
                        xmlDocument.createElement(currentAttr.getNodeName());

                    //pripojime textovy obsah
                    //pridame dite na spravne misto
                    newElem.appendChild(
                        xmlDocument.createTextNode(currentAttr.getNodeValue()));
                    user.appendChild(newElem);
                }
            }
        }
    }
}
