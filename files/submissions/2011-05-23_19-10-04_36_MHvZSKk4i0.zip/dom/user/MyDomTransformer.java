// vsechny atributy prevede na elementy s textovym obsahem,
// ve kterem je hodnota atributu


package user; 

import org.w3c.dom.Document; 
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


public class MyDomTransformer
{ 
	public void transform (Document xmlDocument)
	{
		makeElementsFromAttributes(xmlDocument);
	}
	
	private void makeElementsFromAttributes(Node act)
	{
		// nejdriv projde deti uzlu:
		NodeList childnodes = act.getChildNodes();
		for(int i = 0; i < childnodes.getLength(); ++i)
			makeElementsFromAttributes(childnodes.item(i));
		
		if (act.hasAttributes())
		{
			NamedNodeMap attrs = act.getAttributes();
			// pro kazdy atribut vytvori element s textovym obsahem:
			for(int j = 0; j < attrs.getLength(); ++j)
			{
				String name = attrs.item(j).getNodeName();
				String value = attrs.item(j).getNodeValue();
				
				Element n = act.getOwnerDocument().createElement(name);
				n.setTextContent(value);
				
				act.appendChild(n);
			}
			
			// smaze vsechny atributy:
			String[] names = new String[attrs.getLength()];
			for (int i=0; i < names.length; i++)
			{
			    names[i] = attrs.item(i).getNodeName();
			}
			for (int i=0; i < names.length; i++)
			{
			    attrs.removeNamedItem(names[i]);
			}
		}
	}
}