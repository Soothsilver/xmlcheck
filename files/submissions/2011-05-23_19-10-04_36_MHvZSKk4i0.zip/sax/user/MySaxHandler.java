// spocita maximalni hloubku a pocet elementu a atributu xml dokumentu "..\data.xml"


package user;

import org.xml.sax.Attributes;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;


public class MySaxHandler extends DefaultHandler
{
	int depth = 0;
	int maxdepth = 0;
	int elements = 0;
	int attributes = 0;

	
 	public void startElement(String uri, String localName, String qName, Attributes attributes)
	{
 		depth++;
 		elements++;
 		this.attributes += attributes.getLength();
 		
 		if(depth > maxdepth)
 			maxdepth = depth;
	}
 	
	public void characters(char[] ch, int start, int length)
	{ 
 		 if (depth + 1 > maxdepth)
 			 maxdepth = depth + 1;
	} 
	     
	public void endElement(String uri, String localName, String qName)
	{ 
		depth--;
	} 

    public void error(SAXParseException e)
    { 
    	System.out.println(e.getMessage()); 
    } 

	public void warning(SAXParseException e)
	{ 
		System.out.println(e.getMessage()); 
	} 

	public void fatalError(SAXParseException e)
	{ 
		System.out.println(e.getMessage()); 
	} 
}
