package user;

import java.util.Collection;
import java.util.Comparator;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.Map.Entry;

import org.w3c.dom.*;

public class MyDomTransformer {

	
	
	public void transform (Document xmlDocument) {
	    // libovolne transformace objektu 'xmlDocument'
	    // (metoda pracuje primo na objektu, nic nevraci)
		
		/* Transformace:
		 * p�id� z�znam
		 * odstrani vsechny knihy od Pratchetta
		 * */
		
		//pridani zaznamu
		 NodeList nodes = xmlDocument.getElementsByTagName("SeznamKnih");
         Element knihy;

         if(nodes.getLength()==0){
        	 knihy = xmlDocument.createElement("SeznamKnih");
             xmlDocument.getFirstChild().appendChild(knihy);
         } else knihy = (Element)nodes.item(0);
         
         Element kniha = xmlDocument.createElement("kniha");

         kniha.setAttribute("id", "013");
         kniha.setAttribute("state", "doma");
         kniha.appendChild(xmlDocument.createElement("autor"));
         NodeList x1 = kniha.getElementsByTagName("autor");
         Element jmaut = (Element) x1.item(0);
         jmaut.appendChild(xmlDocument.createElement("jmenoAutora"));
         NodeList x2 = jmaut.getElementsByTagName("jmenoAutora");
         Element work = (Element) x2.item(0);
         work.appendChild(xmlDocument.createElement("jmeno")).setTextContent("Roger");
         work.appendChild(xmlDocument.createElement("prijmeni")).setTextContent("Zelazny");
         kniha.appendChild(xmlDocument.createElement("nazev")).setTextContent("Dev�t princ� Amberu");
         kniha.appendChild(xmlDocument.createElement("jazyk")).setTextContent("cz");

         knihy.appendChild(kniha);
         
         ///odstraneni knih
         nodes = xmlDocument.getElementsByTagName("autor");
         String name = "Terry Pratchett";
         for(int i=nodes.getLength()-1; i>=0; i--){
        	 
             Element aut = (Element)nodes.item(i);
             if (aut.getTextContent().trim().equalsIgnoreCase(name)) {
            	 Element parent = (Element)aut.getParentNode();
            	 Element grandparent = (Element)parent.getParentNode();
            	 grandparent.removeChild(parent);
             }

         }
	}
}

