package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer {
	public void transform(Document xmlDocument) {
		// delete user items with count <= 3
		NodeList l = xmlDocument.getElementsByTagName("userItem");
		for (int i = l.getLength() - 1; i >= 0; i--) {
			Node n = l.item(i);
			if (n.getNodeType() == Node.ELEMENT_NODE) {
				Element e = ( Element )n;
				if ( Integer.parseInt(e.getAttribute("count")) <= 3 ){
					e.getParentNode().removeChild(e);
				}
			}
		}
		
		//add new minifig
		Element sourceItemsEl = (Element)xmlDocument.getElementsByTagName("sourceItems").item(0);
		Element sourceMinifig = xmlDocument.createElement("sourceItem");
		sourceMinifig.setAttribute("type", "minifig" );
		sourceMinifig.setAttribute("number", "ID123456");
		Element nameElement = xmlDocument.createElement("name");
		nameElement.setTextContent("New Minifig");
		sourceMinifig.appendChild(nameElement);
		Element categoryElement = xmlDocument.createElement("category");
		categoryElement.setTextContent("City");
		sourceMinifig.appendChild(categoryElement);
		Element weightElement = xmlDocument.createElement("weight");
		weightElement.setTextContent("12 g");
		sourceMinifig.appendChild(weightElement);
		sourceItemsEl.appendChild(sourceMinifig);
	}
}