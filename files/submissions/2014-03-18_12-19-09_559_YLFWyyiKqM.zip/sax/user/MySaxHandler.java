package user;

import java.text.DecimalFormat;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

public class MySaxHandler extends DefaultHandler {

	// Helper variable to store location of the handled event
	Locator locator;

	/**
	 * Sets the locator
	 * 
	 * @param Locator
	 *            locator location in the file
	 */
	@Override
	public void setDocumentLocator(Locator locator) {
		this.locator = locator;
	}

	private HashMap<String, Integer> categoryCounts = new HashMap<String, Integer>();
	private HashSet<String> spacePartSet = new HashSet<String>();
	private int totalUserCollectionCount = 0;
	private int userCollectionInstanceCount = 0;
	private boolean catchCategory = false;

	/**
	 * Method to handle "document start"
	 * 
	 * @throws SAXException
	 */
	@Override
	public void startDocument() throws SAXException {
		// ...
	}

	/**
	 * Method to handle "document end"
	 * 
	 * @throws SAXException
	 */
	@Override
	public void endDocument() throws SAXException {
		if (userCollectionInstanceCount != 0) {
			System.out.println("Average user collection size is: "
					+ Math.round(totalUserCollectionCount
							/ (userCollectionInstanceCount * 1.0) * 100.0)
					/ 100.0);
		} else {
			System.out
					.println("No user has collection, can't calculate average collection size.");
		}

		String bestCategory = "";
		Integer maxNumber = 0;
		for (Map.Entry<String, Integer> entry : categoryCounts.entrySet()) {
			if (entry.getValue() > maxNumber) {
				bestCategory = entry.getKey();
			}
		}
		System.out.println("The most frequent category is " + bestCategory);
		System.out
				.println("# of space parts with at least five occurences inside user collection: "
						+ contextCounter);
	}

	String currentPartId = "";
	Integer contextCounter = 0;

	/**
	 * Method to handle "begin element"
	 * 
	 * @param uri
	 *            URI of the element namespace (empty if element is no
	 *            namespace)
	 * @param localName
	 *            local name of the element (never empty)
	 * @param qName
	 *            qualified name (prefix-URI + ':' + localName, if the element
	 *            is in some namespace or localName otherwise)
	 * @param atts
	 *            Element's attributes
	 * @throws SAXException
	 */
	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes atts) throws SAXException {
		if (localName.equals("userCollection")) {
			userCollectionInstanceCount++;
		} else if (localName.equals("userItem")) {
			Integer currentCount = 0;
			String currentRef = "";
			for (int i = 0; i < atts.getLength(); i++) {

				// get count attribute
				if (atts.getLocalName(i).equals("count")) {
					currentCount = Integer.parseInt(atts.getValue(i));
					totalUserCollectionCount += currentCount;
				} else if (atts.getLocalName(i).equals("refNumber")) {
					currentRef = atts.getValue(i);
				}
			}
			if (currentCount >= 5) {
				if (spacePartSet.contains(currentRef)) {
					contextCounter++;
				}
			}
		} else if (localName.equals("category")) {
			catchCategory = true;
		} else if (localName.equals("sourceItem")) {
			boolean isPart = false;
			for (int i = 0; i < atts.getLength(); i++) {
				if (atts.getLocalName(i).equals("type")
						&& atts.getValue(i).equals("part")) {
					isPart = true;
				}
				if (atts.getLocalName(i).equals("number")) {
					currentPartId = atts.getValue(i);
				}
			}
		}
	}

	/**
	 * Method to handle "element end"
	 * 
	 * @param uri
	 *            URI of the element namespace (empty if element is no
	 *            namespace)
	 * @param localName
	 *            local name of the element (never empty)
	 * @param qName
	 *            qualified name (prefix-URI + ':' + localName, if the element
	 *            is in some namespace or localName otherwise)
	 * @param atts
	 *            Element's attributes
	 * @throws SAXException
	 */
	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		catchCategory = false;
		if (localName.equals("sourceItem")) {
			currentPartId = "";
		}
	}

	/**
	 * Method to handle "character data" SAX parser can process data in various
	 * batches. so we can't rely that whole whole text content will be delivered
	 * in one call Text is in array 'chars' from position ('start') to ('start'
	 * + 'length' - 1)
	 * 
	 * @param chars
	 *            Array with char data
	 * @param start
	 *            Index of the begin of valid data
	 * @param length
	 *            Length of the valid data
	 * @throws SAXException
	 */
	@Override
	public void characters(char[] chars, int start, int length)
			throws SAXException {
		if (catchCategory) {
			String category = "";
			for (int i = start; i < start + length; i++) {
				category += chars[i];
			}
			category = category.trim();
			if (categoryCounts.containsKey(category)) {
				categoryCounts.put(category, categoryCounts.get(category) + 1);
			} else {
				categoryCounts.put(category, 1);
			}
			if (category.equals("Space")) {
				if (currentPartId.length() > 0) {
					spacePartSet.add(currentPartId);
				}
			}
			catchCategory = false;
		}
	}

	/**
	 * Method to handle " start of namespace declaration"
	 * 
	 * @param prefix
	 *            Prefix of the namespace
	 * @param uri
	 *            URI of the namespace
	 * @throws SAXException
	 */
	@Override
	public void startPrefixMapping(String prefix, String uri)
			throws SAXException {
		// ...
	}

	/**
	 * Method to handle "end of namespace declaration"
	 * 
	 * @param prefix
	 * @throws SAXException
	 */
	@Override
	public void endPrefixMapping(String prefix) throws SAXException {
		// ...
	}

	/**
	 * Method to handle "ignoring of whitespaces" Text is in array 'chars' from
	 * position ('start') to ('start' + 'length' - 1)
	 * 
	 * @param chars
	 *            Array with char data
	 * @param start
	 *            Index of the begin of valid data
	 * @param length
	 *            Length of the valid data
	 * @throws SAXException
	 * @throws SAXException
	 */
	@Override
	public void ignorableWhitespace(char[] chars, int start, int length)
			throws SAXException {
		// ...
	}

	/**
	 * Method to handle "processing instructions"
	 * 
	 * @param target
	 *            The processing instruction target
	 * @param data
	 *            The processing instruction data
	 * @throws SAXException
	 */
	@Override
	public void processingInstruction(String target, String data)
			throws SAXException {
		// ...
	}

	/**
	 * Method to handle "unprocessed entity"
	 * 
	 * @param name
	 * @throws SAXException
	 */
	@Override
	public void skippedEntity(String name) throws SAXException {
		// ...
	}
}