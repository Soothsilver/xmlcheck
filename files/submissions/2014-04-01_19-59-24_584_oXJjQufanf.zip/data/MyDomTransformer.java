package user;

import java.util.ArrayList;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * @author Imrich Kuklis
 */
public class MyDomTransformer 
{
    public MyDomTransformer()
    {
    }
    
    private Element createAddressElement(Document xmlDocument, String countryValue,
                                                String cityValue, String districtValue,
                                                String streetNameValue, String streetNumberValue,
                                                String zipcodeValue)
    {
        Element result;
        
        if(xmlDocument == null || countryValue == null || cityValue == null || 
           districtValue == null || streetNameValue == null || streetNumberValue == null ||
           zipcodeValue == null)
            return null;
        
        // creating country element
        Element country = xmlDocument.createElement("country");
        country.appendChild(xmlDocument.createTextNode(countryValue));
        
        // creating city element
        Element city = xmlDocument.createElement("city");
        city.appendChild(xmlDocument.createTextNode(cityValue));
        
        // creating district element
        Element district = xmlDocument.createElement("district");
        district.appendChild(xmlDocument.createTextNode(districtValue));
        
        // creating street name element
        Element streetName = xmlDocument.createElement("name");
        streetName.appendChild(xmlDocument.createTextNode(streetNameValue));
        
        // creating street number element
        Element streetNumber = xmlDocument.createElement("number");
        streetNumber.appendChild(xmlDocument.createTextNode(streetNumberValue));
        
        // creating street element
        Element street = xmlDocument.createElement("street");
        street.appendChild(streetName);
        street.appendChild(streetNumber);
        
        // creating zipcode element
        Element zipcode = xmlDocument.createElement("zipcode");
        zipcode.appendChild(xmlDocument.createTextNode(zipcodeValue));
        
        // creating address element
        result = xmlDocument.createElement("address");
        result.appendChild(country);
        result.appendChild(city);
        result.appendChild(district);
        result.appendChild(street);
        result.appendChild(zipcode);
        
        return result;
    }
    
    
    private Element createPersonElement(Document xmlDocument)
    {
        if(xmlDocument == null)
            return null;
        
        // creating id attribute of person element
        Attr idAttribute = xmlDocument.createAttribute("id");
        idAttribute.setValue("E8547A915C");
        // creating first name attribute of person element
        Attr firsnameAttribute = xmlDocument.createAttribute("firstname");
        firsnameAttribute.setValue("Jan");
        // creating surname attribute of person element
        Attr surnameAttribute = xmlDocument.createAttribute("surname");
        surnameAttribute.setValue("Flasar");
        // creating other contact id attribute of person element
        Attr otherIDAttribute = xmlDocument.createAttribute("other_contact_id");
        otherIDAttribute.setValue("D8547BE15");
        
        // creating address element of person element
        Element address = createAddressElement(xmlDocument, "Czech Repulic", 
                                               "Cesky Krumlov", "Cesky Krumlov", 
                                               "Palarikova", "17", "158 09");
        
        // creating mobil element of person
        Element mobil  = xmlDocument.createElement("mobil");
        mobil.appendChild(xmlDocument.createTextNode("756894578"));
        
        // creating email element of person
        Element email = xmlDocument.createElement("email");
        email.appendChild(xmlDocument.createTextNode("jan.flasar@gmail.com"));
        
        // creating person element
        Element result = xmlDocument.createElement("person");
        result.setAttributeNode(idAttribute);
        result.setAttributeNode(firsnameAttribute);
        result.setAttributeNode(surnameAttribute);
        result.setAttributeNode(otherIDAttribute);
        result.appendChild(address);
        result.appendChild(mobil);
        result.appendChild(email);
        
        return result;
    }
    
    private Element createDateElement(Document xmlDocument, String yearValue, 
                                      String monthValue, String dayValue,
                                      String hourValue, String minuteValue)
    {
        if(xmlDocument == null || yearValue == null ||
           monthValue == null || dayValue == null ||
           hourValue == null || minuteValue == null)
            return null;
        
        // creating element year of date element
        Element year = xmlDocument.createElement("year");
        year.appendChild(xmlDocument.createTextNode(yearValue));
        // creating element month of date element
        Element month = xmlDocument.createElement("month");
        month.appendChild(xmlDocument.createTextNode(monthValue));
        // creating element day of date element
        Element day = xmlDocument.createElement("day");
        day.appendChild(xmlDocument.createTextNode(dayValue));
        // creating element hours of time element
        Element hours = xmlDocument.createElement("hours");
        hours.appendChild(xmlDocument.createTextNode(hourValue));
        // creating element minutes of time element
        Element minutes = xmlDocument.createElement("minutes");
        minutes.appendChild(xmlDocument.createTextNode(minuteValue));
        // creating element time of date element
        Element time = xmlDocument.createElement("time");
        time.appendChild(hours);
        time.appendChild(minutes);
        // creating date element
        Element result = xmlDocument.createElement("date");
        result.appendChild(year);
        result.appendChild(month);
        result.appendChild(day);
        result.appendChild(time);
        
        return result;
    }
    
    private Element createReservationDateElement(Document xmlDocument)
    {
        if(xmlDocument == null)
            return null;
        
        // creating from element of reservation date element
        Element fromDate = createDateElement(xmlDocument, "2014", "May", "5", "16", "30");
        Element from = xmlDocument.createElement("from");
        from.appendChild(fromDate);
        
        // creating to element of reservation date element
        Element toDate = createDateElement(xmlDocument, "2014", "May", "5", "19", "30");
        Element to = xmlDocument.createElement("to");
        to.appendChild(toDate);
        
        Element result = xmlDocument.createElement("reservationdate");
        result.appendChild(from);
        result.appendChild(to);
        
        return result;
    }
    
    
    private Element createReservedElement(Document xmlDocument)
    {
        if(xmlDocument == null)
            return null;
        
        // creating person element of reserved element
        Element person = createPersonElement(xmlDocument);
        // creating reservation date of reserved element
        Element reservationDate = createReservationDateElement(xmlDocument);
        // creating attribute type of sport element 
        Attr sportType = xmlDocument.createAttribute("type");
        sportType.setValue("hockey");
        // creating sport elemnt of reserved element
        Element sport = xmlDocument.createElement("sport");
        sport.setAttributeNode(sportType);
        // creating attribute type of payment element
        Attr paymentType = xmlDocument.createAttribute("type");
        paymentType.setValue("creditcard");
        // creating attribute amount of payment element
        Attr paymentAmount = xmlDocument.createAttribute("amount");
        paymentAmount.setValue("6000");
        // creating attribute currency of peyment element
        Attr paymentCurrency = xmlDocument.createAttribute("currency");
        paymentCurrency.setValue("czech crown");
        // creating payment elemnt of reserved element
        Element payment = xmlDocument.createElement("payment");
        payment.setAttributeNode(paymentType);
        payment.setAttributeNode(paymentAmount);
        payment.setAttributeNode(paymentCurrency);
        // creating message element of reserved element
        Element message = xmlDocument.createElement("message");
        message.appendChild(xmlDocument.createTextNode("Is it possible to rent hockey equipment from the stadium or do we have to bring our equipment?<?php echo Date(\"d.m.Y\")?>"));
        // creating reserved element
        Element result = xmlDocument.createElement("reserved");
        result.appendChild(person);
        result.appendChild(reservationDate);
        result.appendChild(sport);
        result.appendChild(payment);
        result.appendChild(message);
        
        return result;
    }
    
    private Element createStadionElement(Document xmlDocument)
    {
        if(xmlDocument == null)
            return null;
        
        // creating stadion addresss element of stadion element
        Element stadionAddress = createAddressElement(xmlDocument, "Czech Republic", 
                                                     "Prague", "Prague 4 - Branik", 
                                                     "Mikuleckeho", "1584", "148 06");
        // creating stadion capacity elemnt
        Element capacity = xmlDocument.createElement("capacity");
        capacity.appendChild(xmlDocument.createTextNode("1200"));
        
        // creating stadion reservation element
        Element reserved = createReservedElement(xmlDocument);
        
        // create attribute name
        Attr stadionName = xmlDocument.createAttribute("name");
        stadionName.setValue("HC Kobra");
        
        // creating stadion element
        Element result = xmlDocument.createElement("stadion");
        result.setAttributeNode(stadionName);
        result.appendChild(stadionAddress);
        result.appendChild(capacity);
        result.appendChild(reserved);
        
        return result;
    }
    
    // Creates new reservation and adds it to the document
    private void createNewReservation(Document xmlDocument)
    {
        if(xmlDocument == null)
            return;
        
        // creating staion element
        Element stadion = createStadionElement(xmlDocument);
        // creating id attribute
        Attr idAttribute = xmlDocument.createAttribute("id");
        idAttribute.setValue("r11");
        
        Element reservation = xmlDocument.createElement("reservation");
        reservation.setAttributeNode(idAttribute);
        reservation.appendChild(stadion);
        
        NodeList reservations = xmlDocument.getElementsByTagName("reservations");
        
        if(reservations.getLength() > 0)
        {
            Element current  = (Element)reservations.item(0);
            current.appendChild(reservation);
        }
                
    }
    
    private void removeReservationsWherePaymentWithTransaction(Document xmlDocument)
    {
        
        if(xmlDocument == null)
            return;
        ArrayList<Node> nodesToRemove = new ArrayList<>();
        
        NodeList payments = xmlDocument.getElementsByTagName("payment");
        
        for(int i = 0; i < payments.getLength(); ++i)
        {
            Element currentPaymentElement = (Element)payments.item(i);
            if(currentPaymentElement.hasAttribute("type") && currentPaymentElement.getAttribute("type").equals("transaction"))
                nodesToRemove.add(currentPaymentElement.getParentNode().getParentNode().getParentNode());
        }
        
        // resmoving nodes with transaction
        for(int i = 0; i < nodesToRemove.size(); ++i)
            nodesToRemove.get(i).getParentNode().removeChild(nodesToRemove.get(i));
    }
    
    public void transform (Document xmlDocument) 
    {
        // removing reservation from document where payment type is transaction
        removeReservationsWherePaymentWithTransaction(xmlDocument);
        // adds a new reservation to the output xml file
        createNewReservation(xmlDocument);
    }
}
