package user;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;
public class MySaxHandler extends DefaultHandler {
	public static void main(String[] args) {
        try {

            // Create parser instance
            XMLReader parser = XMLReaderFactory.createXMLReader();

            // Create input stream from source XML document
            InputSource source = new InputSource("data.xml");

            // Set our custom content handler for handling SAX events (it must implements ContentHandler interface)
            parser.setContentHandler(new MySaxHandler());

            // Process input data
            parser.parse(source);

        } catch (Exception e) {

            e.printStackTrace();

        }

    }
	
	// Helper variable to store location of the handled event
    Locator locator;
    private int users;
    private Map<String, Integer> languages = new HashMap<String,Integer>();

    /**
     * Sets the locator
     *
     * @param Locator locator location in the file
     */
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    @Override
    public void startDocument() throws SAXException {
        
    }

    @Override
    public void endDocument() throws SAXException {
        System.out.println("User count: " + users);
        // language contains language quantities
        //short of time!
    }


    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if (localName.equals("interfaceLanguage")) {
        	if (languages.containsKey(atts.getValue("language_id"))) {
        		Integer a = languages.get(atts.getValue("language_id"));
        		a++;
        		languages.put(atts.getValue("language_id"), a);
			} else {
				languages.put(atts.getValue("language_id"), 1);
			}
        }
        if (localName.equals("user")) {
        	users++;
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        // ...
    }

    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        // ...
    }

    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }


    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
        // ...
    }

    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }


    @Override
    public void skippedEntity(String name) throws SAXException {
        // ...
    }
}