package user;

import java.util.ArrayList;

/**
 * Created with IntelliJ IDEA.
 * Player: nynza
 * Date: 2.4.14
 * Time: 22:29
 * To change this template use File | Settings | File Templates.
 */
public class Guild {
    String id;
    String name;
    String leaderId;
    String spec;
    String plan;
    ArrayList<Member> members;

    public Guild(String id, String name) {
        this.id = id;
        this.members = new ArrayList<Member>();
        this.name = name;
    }

    @Override
    public String toString() {
        return "Guild:\n"
            + " id " + id + "\n"
            + " name " + name + "\n"
            + " leaderId " + leaderId + "\n"
            + " spec " + spec + "\n"
            + "members: \n"
            + members.toString()
            + " plan " + plan + "\n";
    }
}
