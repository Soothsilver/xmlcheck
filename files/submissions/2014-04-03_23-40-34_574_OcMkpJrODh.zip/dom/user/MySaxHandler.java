package user;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import java.util.ArrayList;

public class MySaxHandler extends DefaultHandler {
    ArrayList<Player> players;
    ArrayList<Guild> guilds;

    boolean player = false;
        boolean pName = false;
        boolean pLevel = false;
    boolean guild = false;
        boolean gLevel = false;
        boolean gSpec = false;
            boolean mRole = false;
        boolean gPlan = false;

    public void startDocument() throws SAXException {
        players = new ArrayList<Player>();
        guilds = new ArrayList<Guild>();
    }

    public void endDocument() throws SAXException {
    }

    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        if(qName.equals("player")){
            players.add(new Player(attributes.getValue(0)));
            player = true;
        }else if(qName.equals("class"))
            players.get(players.size()-1).className = attributes.getValue(0);
        else if(qName.equals("level") && player == true)
            pLevel = true;
        else if(qName.equals("name"))
            pName = true;

        else if(qName.equals("guild")){
            guilds.add(new Guild(attributes.getValue(0), attributes.getValue(1)));
            guild = true;
        }else if(qName.equals("level") && guild == true)
            gLevel = true;
        else if(qName.equals("spec"))
            gSpec = true;
        else if(qName.equals("role"))
            mRole = true;
        else if(qName.equals("plan"))
            gPlan = true;
        else if(qName.equals("member"))
            guilds.get(guilds.size()-1).members.add(new Member(attributes.getValue(0)));
    }

    public void endElement(String uri, String localName, String qName) throws SAXException {
        if(qName.equals("player"))
            player = false;
        else if(qName.equals("level") && player == true)
            pLevel = false;
        else if(qName.equals("name"))
            pName = false;

        else if(qName.equals("guild"))
            guild = false;
        else if(qName.equals("level") && guild == true)
            gLevel = false;
        else if(qName.equals("spec"))
            gSpec = false;
        else if(qName.equals("role"))
            mRole = false;
        else if(qName.equals("plan"))
            gPlan = false;
    }

    public void characters(char ch[], int start, int length) throws SAXException {
        if(pName)
            players.get(players.size()-1).name = new String(ch, start, length);
        else if(pLevel)
            players.get(players.size()-1).level = Integer.parseInt(new String(ch, start, length));
        else if(gLevel);
        else if(gSpec)
            guilds.get(guilds.size()-1).spec = new String(ch, start, length);
        else if(mRole)
            guilds.get(guilds.size()-1).
                members.get(guilds.get(guilds.size()-1).members.size()-1).role
                    = new String(ch, start, length);
        //\System.out.println("start characters : " + new String(ch, start, length));
    }

}