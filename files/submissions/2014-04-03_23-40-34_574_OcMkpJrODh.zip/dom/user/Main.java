package user;

import org.w3c.dom.Document;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.util.HashMap;

/**
 * Created with IntelliJ IDEA.
 * Player: nynza
 * Date: 2.4.14
 * Time: 21:46
 * To change this template use File | Settings | File Templates.
 */
public class Main {
    public static void main(String[] args) {
        SAXParserFactory factory = SAXParserFactory.newInstance();
        MySaxHandler handler = new MySaxHandler();

        try {
            SAXParser saxParser = factory.newSAXParser();
            saxParser.parse("domacaky\\src\\user\\data.xml", handler);
            System.out.println(handler.players.toString());
            System.out.println(handler.guilds.toString());


            HashMap<String, Integer> classes = new HashMap<String, Integer>();
            for (Player p : handler.players){
                if(classes.containsKey(p.className))
                    classes.put(p.className, classes.get(p.className)+1);
                else
                    classes.put(p.className, 1);

            }

            int temp = 0;
            String mostCommon = "";
            for (String s : classes.keySet()){
                 if (classes.get(s) > temp){
                     mostCommon = s;
                     temp = classes.get(s);
                 }
            }

            int avarage = 0;
            temp = 0;
            for (Player p : handler.players){
                avarage += p.level;
                temp++;
            }

            System.out.println("Most common class: " + mostCommon);
            System.out.println("Avarage level: " + ((double)avarage/temp));

            temp = 0;
            for (Guild g : handler.guilds)
                for (Member m : g.members)
                    for (Player p : handler.players)
                        if (p.id.equals(m.id) && p.level == 90)
                            temp++;

            System.out.println("Number of players of level 90 in guild: " + temp);

            // DOM -------------------------------------
            String filepath = "domacaky\\src\\user\\data.xml";
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath);

            MyDomTransformer.transform(doc);

            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
