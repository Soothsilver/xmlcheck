package user;

/**
 * Created with IntelliJ IDEA.
 * Player: nynza
 * Date: 2.4.14
 * Time: 22:23
 * To change this template use File | Settings | File Templates.
 */
public class Player {
    String id;
    String name;
    String className;
    int level;

    public Player(String id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Player: " + id + " " + name + " " + level + "\n";
    }

    public boolean equals(Player player){
        return id == player.id ? true : false;
    }

    public boolean equals(Member member){
        return id == member.id ? true : false;
    }
}
