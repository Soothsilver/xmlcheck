package user;

/**
 * Created with IntelliJ IDEA.
 * Player: nynza
 * Date: 2.4.14
 * Time: 22:38
 * To change this template use File | Settings | File Templates.
 */
public class Member {
    String id;
    String role;

    public Member(String id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "   member: " + id + " " + role + "\n";
    }
}
