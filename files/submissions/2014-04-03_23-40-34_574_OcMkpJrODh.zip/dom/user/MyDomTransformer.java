package user;

import org.w3c.dom.Document;

import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;


public class MyDomTransformer {
    public static void transform (Document doc) {
        Node players = doc.getElementsByTagName("players").item(0);

        Element player = doc.createElement("player");
        player.setAttribute("id", "p11");

        Element name = doc.createElement("name");
        name.appendChild(doc.createTextNode("name11"));

        Element pClass = doc.createElement("class");
        pClass.setAttribute("name", "rogue");

        Element level = doc.createElement("level");
        level.appendChild(doc.createTextNode("90"));

        player.appendChild(name);
        player.appendChild(pClass);
        player.appendChild(level);

        players.appendChild(player);

        NodeList playersList = doc.getElementsByTagName("player");
        Node members = doc.getElementsByTagName("members").item(0);

        for (int i = 0; i < playersList.getLength(); i++){
            Element tempPlayer = (Element) playersList.item(i);
            String level2 = tempPlayer.getElementsByTagName("level").item(0).getFirstChild().getNodeValue();
            if (level2.equals("90")){
                Element temp = doc.createElement("member");
                temp.setAttribute("id", tempPlayer.getAttribute("id"));

                Element role = doc.createElement("role");
                temp.appendChild(role);

                members.appendChild(temp);
            }
        }
    }

}