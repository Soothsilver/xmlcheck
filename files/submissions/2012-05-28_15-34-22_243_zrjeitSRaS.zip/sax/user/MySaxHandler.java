package user;

import java.util.ArrayList;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * @author Daniel Douša
 *
 * Počet elementů s textovým obsahem/s atributy/s podelementy.
 * Elementy s textovým obsahem můžou obsahovat i podelementy.
 */
public class MySaxHandler extends DefaultHandler {

	/**
	 * Čítač elementů s textovým obsahem.
	 */
	private int elTextove;
	/**
	 * Čítač elementů s atributy.
	 */
	private int elSAtributy;
	/**
	 * Čítač elementů s podatributy.
	 */
	private int elSPodelementy;
	/**
	 * Aktuální hloubka elementů. 
	 */
	private int hloubka;
	/**
	 * Hloubka, ve které byl naposled konec elementu. 
	 */
	private int hloubkaPoslZav;
	/**
	 * Pole, ve kterém se uchovávají informace o textových datech v jednotlivých vrstvách.
	 */
	private ArrayList<Boolean> textData; 
	
	/**
     * Obsluha události "začátek dokumentu"
     */     
    public void startDocument() throws SAXException {
        
    	elTextove = 0;
    	elSAtributy = 0;
    	elSPodelementy = 0;
    	hloubka = 0;
    	hloubkaPoslZav = 0;
    	textData = new ArrayList<Boolean>();
    	
    }
    
    /**
     * Obsluha události "konec dokumentu"
     * Vypíše výsledek zadání.
     */     
    public void endDocument() throws SAXException {
        
    	System.out.println("Elementů s textovým obsahem: " + elTextove);
    	System.out.println("Elementů s atributy: " + elSAtributy);
    	System.out.println("Elementů s podelementy: " + elSPodelementy);
        
    }
    
    /**
     * Obsluha události "začátek elementu".
     * @param uri URI jmenného prostoru elementu (prázdné, pokud element není v žádném jmenném prostoru)
     * @param localName Lokální jméno elementu (vždy neprázdné)
     * @param qName Kvalifikované jméno (tj. prefix-uri + ':' + localName, pokud je element v nějakém jmenném prostoru, nebo localName, pokud element není v žádném jmenném prostoru)
     * @param atts Atributy elementu     
     */     
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        
    	++hloubka;
    	
    	while(textData.size() < hloubka + 1)
    		textData.add(false);
    	
    	textData.add(hloubka, false);
    	
    	if(atts.getLength() > 0)
    		++elSAtributy;

    }
    
    /**
     * Obsluha události "konec elementu"
     * Parametry mají stejný význam jako u @see startElement     
     */     
    public void endElement(String uri, String localName, String qName) throws SAXException {
       
    	// identifikátor na textová data TRUE => element obsahuje textová data
    	if(textData.get(hloubka)) {
    		++elTextove;
    	}
    	
    	// při zjištění, že předchozí zavírací element byl výše než aktuální => tento element obsahuje podelementy
    	if(hloubkaPoslZav > hloubka) {
    		++elSPodelementy;
    	}
    	
    	hloubkaPoslZav = hloubka;
    	
    	--hloubka;
    }
    
    /**
     * Obsluha události "znaková data".
     * SAX parser muľe znaková data dávkovat jak chce. Nelze tedy počítat s tím, že je celý text dorucen v rámci jednoho volání.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakovými daty
     * @param start Index zacátku úseku platných znakových dat v poli.
     * @param length Délka úseku platných znakových dat v poli.
     */               
    public void characters(char[] ch, int start, int length) throws SAXException {

    	// vydolování nebílých znaků
    	String str = "";
    	for(int i = 0; i < length; ++i)
    		str += ch[start + i];
    	str = str.replaceAll("\\s","");
    	
    	// jestliže řetězec obsahuje nebílé znaky, tak je zaznamenáno, že odpovídající element obsahuje text 
    	if(str.length() > 0) 
    		textData.add(hloubka, true);
        
    }
	
}
