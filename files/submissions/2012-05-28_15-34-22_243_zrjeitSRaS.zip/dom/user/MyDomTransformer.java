package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

/**
 * @author Daniel Douša
 * 
 * Smazat elementy v zadané hloubce/přesahující povolený fan-out.
 *
 */
public class MyDomTransformer {

	/**
	 * Maximální povolená hloubka. Elementy s vyšší hloubkou budou smazány.
	 */
	private int maxHloubka = 5;
	
	/**
	 * Počet povolených podelementů jednoho elementu.
	 */
	private int fanOut = 4;
	
	/**
	 * @param maxHloubka the hloubka to set
	 */
	public void setMaxHloubka(int maxHloubka) {
		this.maxHloubka = maxHloubka;
	}

	/**
	 * @param fanOut the fanOut to set
	 */
	public void setFanOut(int fanOut) {
		this.fanOut = fanOut;
	}

	/**
	 * Funkce spouštěná XMLCheck.
	 * 
	 * @param xmlDocument Vstupní dokument, na kterém bude provedena změna.
	 */
	public void transform (Document xmlDocument) {
		
		Element first = xmlDocument.getDocumentElement();
		
		prolez(first, xmlDocument, 1);
		
	}
	
	/**
	 * Funkce při dosažení maximální hloubky smaže všechny podelementy.
	 * Při nedosažení maximální hloubky maže podelementy přesahující povolený fan-out. 
	 * 
	 * @param input Vstupní uzel.
	 * @param doc Dokument XML.
	 * @param aktHloubka Aktuální zanoření.
	 */
	private void prolez (Node input, Document doc, int aktHloubka) {
		
		input.normalize();
		
		//System.out.println(aktHloubka + ": " + input.getNodeName());
		
		int elementu = 0;
		Node node = input.getFirstChild();
		Node prevNode;
		
		while(node != null) {
			
			// mažou se jen elementy
			if(node.getNodeType() == Node.ELEMENT_NODE) {
				
				++elementu;
				
				// při dosažení maximální hloubky nebo překročení fan-outu, budou následující elementy smazány
				if((aktHloubka >= maxHloubka) || (elementu > fanOut)) {
				
					prevNode = node.getPreviousSibling();
					input.removeChild(node);
					
					if(prevNode == null)
						node = input.getFirstChild();
					else
						node = prevNode.getNextSibling();
				
					continue;
				} 
				
				// rekurzivní volání funkce na podelementy
				prolez(node, doc, aktHloubka + 1);
				
			} 

			node = node.getNextSibling();
			
		}

		input.normalize();
		
	}
	
}
