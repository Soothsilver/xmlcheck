package user;

import java.util.ArrayList;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;


// spočítá počty prvků v jednotlivých hloubkách, které mají atributy, a vypíše procentuální zastoupení
public class MySaxHandler extends DefaultHandler {
    
    private int[] p;        // jelikoz nevim jak funguji dynamicke kolekce v jave, je to staticke pole
    private int hloubka=0;  // aktualni zanoreni
    private int celkovyPocetElementu=0; // celkovy pocet elementu
    private int[] pBezAtt;
    
    @Override
    public void startDocument() throws SAXException {
        p = new int[100];
        pBezAtt = new int[100];
    }

    @Override
    public void endDocument() throws SAXException {
        
        System.out.println("Vypis poctu prvku v dane hloubce s atributy a bez attributu");
        System.out.println("Celkovy pocet elementu " + celkovyPocetElementu );
        System.out.println("s attributy : bez attributu");
        for (int i = 0; i < 100; i++) {
            if(p[i] != 0 || pBezAtt[i] != 0)
            {               
               System.out.println("Hloubka " + i + ":\t" + p[i] + ":" + pBezAtt[i]);
            }            
        }
    }    
    
    // nepotrebuji ulozena data, pracuji jen s elementy
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {

    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
      celkovyPocetElementu++;
      hloubka++;
      if(attributes.getLength()>0)
      {
        p[hloubka]++;
      }
      else
      {          
        pBezAtt[hloubka]++;
      }
    } 
    
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        hloubka--;
    }

}