package user;

import java.util.ArrayList;
import java.util.List;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

// nahradi vsechny datumy na <date att="datum" /> a to same s casy
public class MyDomTransformer {
    
    // zmenim vsechny datumy a casy na atributy
    public void transform(Document xmlDocument) {
        NodeList data = xmlDocument.getElementsByTagName("date");
        
        for (int i = 0; i < data.getLength(); i++) {
            ZpracujDatum(data.item(i));
        }      
        
        NodeList casy = xmlDocument.getElementsByTagName("time");
        
        for (int i = 0; i < data.getLength(); i++) {
            ZpracujCas(casy.item(i));
        }    
        
        
    }
    
    // zpracuje datumy
    private void ZpracujDatum(Node datum)
    {
        NodeList childs = datum.getChildNodes();
        
        String den="";
        String mesic="";
        String rok="";
        
        for (int i = 0; i < childs.getLength(); i++) {
            if(childs.item(i).getNodeName() == "day")
            {
                den = childs.item(i).getTextContent();
            }
            if(childs.item(i).getNodeName() == "month")
            {
                mesic = childs.item(i).getTextContent();
            }
            if(childs.item(i).getNodeName() == "year")
            {
                rok = childs.item(i).getTextContent();
            }
        } 

        // datum ve format dd.mm.yyyy
        String sdatum = den + "." + mesic + "." + rok;

        ((Element)datum).setAttribute("date", sdatum);
        
        while(datum.hasChildNodes())
        {
            datum.removeChild(datum.getFirstChild());
        }
    }
    // zpracuje casy
    private void ZpracujCas(Node cas)
    {
        NodeList childs = cas.getChildNodes();
        
        String hodina="";
        String minuta="";
        String vterina="";
        
        for (int i = 0; i < childs.getLength(); i++) {
            if(childs.item(i).getNodeName() == "hours")
            {
                hodina = childs.item(i).getTextContent();
            }
            if(childs.item(i).getNodeName() == "minutes")
            {
                minuta = childs.item(i).getTextContent();
            }
            if(childs.item(i).getNodeName() == "seconds")
            {
                vterina = childs.item(i).getTextContent();
            }
        }

        // cas ve format hh:mm:ss
        String scas = hodina + ":" + minuta + ":" + vterina;
        
        ((Element)cas).setAttribute("time", scas);
        
        while(cas.hasChildNodes())
        {
            cas.removeChild(cas.getFirstChild());
        }  
    }
}