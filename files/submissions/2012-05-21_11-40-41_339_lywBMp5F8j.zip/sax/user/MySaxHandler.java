
package user;


import java.util.ArrayList;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 *
 * @author aidanamukhametkaliyeva
 * 
 */


/*
 *Moje tema  je ze program  spocita kolik filmu je v kazdem kine
 */
public class MySaxHandler extends DefaultHandler {

    public static void main(String[] args) {
        String sourcePath = "data.xml";
        try {
            XMLReader parser = XMLReaderFactory.createXMLReader();


            InputSource source = new InputSource(sourcePath);


            parser.setContentHandler(new MujContentHandler());

            parser.parse(source);

        } catch (Exception e) {
        }
    }
}

class MujContentHandler extends DefaultHandler {

    private int pocetKIN = 0;
    private int counterFilm = 0;

    private ArrayList<Integer> filmy = new ArrayList<Integer>();

    private ArrayList<String> nameCinema = new ArrayList<String>();

    @Override
    public void startDocument() throws SAXException {
        System.out.println("**************************************");
        System.out.println("Zpracovani dokumentu data.xml\n");
    }

    @Override
    public void endDocument() throws SAXException {
        System.out.println("Pocet kin: " + pocetKIN);
        System.out.println("Pocet filmu v kine: ");
        for (int film : filmy) {
            System.out.println("\tKino: " + " Pocet filmu: " + film);
        }
       

        System.out.println("\nKonec zpracovani dokumentu");
        System.out.println("**************************************");
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if (qName.equals("cinema")) {
            pocetKIN++;
        }
        if (qName.equals("film")) {
            counterFilm++;
        }
        if (qName.equals("name")) {
            nameCinema.add(atts.getValue(0));
        }
      
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (qName.equals("cinema")) {
            filmy.add(counterFilm);
            counterFilm = 0;
           
        }
    }
    // <editor-fold defaultstate="collapsed" desc="unused">
    Locator locator;

    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
    }

    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
    }

    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
    }

    @Override
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
    }

    @Override
    public void processingInstruction(String target, String data) throws SAXException {
    }

    @Override
    public void skippedEntity(String name) throws SAXException {
    }
    // </editor-fold>
}
// </editor-fold>