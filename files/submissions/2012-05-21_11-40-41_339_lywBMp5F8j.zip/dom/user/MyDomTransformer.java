/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

/**
 * moje tema je ze smaze description u filmun a prida mesto pro kazde kino
 * @author aidanamukhametkaliyeva
 */
public class MyDomTransformer {

    private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "data.out.xml";

    public static void main(String[] args) {



        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setValidating(false);//pro parsovani,if true check the correctness of the document
            DocumentBuilder builder = dbf.newDocumentBuilder();
            Document doc = builder.parse(VSTUPNI_SOUBOR);
            MyDomTransformer mdt = new MyDomTransformer();
            mdt.transform(doc);
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer writer = tf.newTransformer();
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


        } catch (Exception e) {

            e.printStackTrace();

        }
    }

    public void transform(Document doc) {

//        //dostaneme korenovy element
//        Element root = doc.getDocumentElement();
//        System.out.println("The root element is " + root.getNodeName());


        //smazeme vsechny popisy u filmu   
        NodeList popis = doc.getElementsByTagName("film");
        for (int i = 0; i < popis.getLength(); i++) {
            Element k = (Element) popis.item(i);
            // System.out.println("this one is"+k.getFirstChild());
            k.removeChild(k.getElementsByTagName("description").item(0));
        }

        //vypiseme kolik je potomku v dokumentu
//        NodeList children = root.getChildNodes();
//        System.out.println("There are " + children.getLength()
//                + " nodes in this document.");

        //pridame element city do kazdeho kina
        NodeList pridatRok = doc.getElementsByTagName("cinema");
        for (int i = 0; i < pridatRok.getLength(); i++) {
            Element film = (Element) pridatRok.item(i);

            Element name = doc.createElement("city");
            film.appendChild(name);

        }

        // zmeni obsah textoveho elementu telephone na not defined
//        changeTelephone(root, "telephone", "not defined");
//        NodeList orders = root.getElementsByTagName("telephone");
//        for (int telNum = 0;
//                telNum < orders.getLength();
//                telNum++) {
//            System.out.println(orders.item(telNum).getFirstChild().getNodeValue());
//        }



    }
//metoda pro zmenu obsahu
    private static void changeTelephone(Node start,
            String elemName,
            String elemValue) {
        if (start.getNodeName().equals(elemName)) {
            start.getFirstChild().setNodeValue(elemValue);
        }
        for (Node child = start.getFirstChild();
                child != null;
                child = child.getNextSibling()) {
            changeTelephone(child, elemName, elemValue);
        }
    }
}
