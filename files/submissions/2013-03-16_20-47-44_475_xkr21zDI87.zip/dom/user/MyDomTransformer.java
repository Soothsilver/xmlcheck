package dom.user;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

public class MyDomTransformer {

    private static final String INPUT_FILE = "data.xml";
    private static final String OUTPUT_FILE = "data.out.xml";

    /**
     * Main method
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {

        try {

            // DocumentBuilderFactory creates DOM parsers
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            // We don't want to validate file
            dbf.setValidating(false);

            // Creating of DOM parser instance
            DocumentBuilder builder = dbf.newDocumentBuilder();

            // Parser processes input file and creates a DOM tree of objects
            Document doc = builder.parse(INPUT_FILE);

            // DOM tree processing
            processTree(doc);

            // TransformerFactory creates an object for DOM serialization
            TransformerFactory tf = TransformerFactory.newInstance();

            // Transformer serializes DOM tree
            Transformer writer = tf.newTransformer();

            // Setting of output file encoding
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            // Run transformation of DOM tree to XML document
            writer.transform(new DOMSource(doc), new StreamResult(new File(OUTPUT_FILE)));


        } catch (Exception e) {

            e.printStackTrace();

        }
    }

    /**
     * Zpracuje DOM strom
     */
    private static void processTree(Document doc) {

        // TASK 01 (vytvoreni a naplneni noveho elementu vino)
        createCustomElement(doc);

        // TASK 02 (zmazani vsech vin, ktera byli sklizena pred rokem 2010)
        deleteWinesUntil(doc, 2010);

    }

    private static void createCustomElement(Document doc) throws DOMException {
        // prepare a new element
        Element root = doc.createElement("vino");
        root.setAttribute("kod-vina", "_rulandske_bile_valtice_2008");

        Element vinarstviRef = doc.createElement("vinarstvi-ref");
        vinarstviRef.setAttribute("id-vinarstvi-ref", "_valtice");
        root.appendChild(vinarstviRef);

        Element puvod = doc.createElement("puvod");
        Element stat = doc.createElement("stat");
        stat.setTextContent("Česká republika");
        Element oblast = doc.createElement("oblast");
        oblast.setTextContent("Novosedly");
        puvod.appendChild(stat);
        puvod.appendChild(oblast);
        root.appendChild(puvod);

        Element sklizen = doc.createElement("sklizen");
        Element rok = doc.createElement("rok");
        rok.setTextContent("2008");
        Element mesic = doc.createElement("mesic");
        mesic.setTextContent("rijen");
        sklizen.appendChild(rok);
        sklizen.appendChild(mesic);
        root.appendChild(sklizen);

        Element hrozny = doc.createElement("hrozny");
        Element plod = doc.createElement("plod");
        plod.setTextContent("reva vinna");
        Element barva = doc.createElement("barva");
        barva.setAttribute("jmeno-barvy", "bila");

        Element odruda = doc.createElement("odruda");
        Element synonymum1 = doc.createElement("synonymum");
        synonymum1.setTextContent("Pinot blanc");
        Element synonymum2 = doc.createElement("synonymum");
        synonymum2.setTextContent("Burgundske bile");
        Element puvodOdrudy = doc.createElement("puvod-odrudy");
        puvodOdrudy.setTextContent("Pinot noir");
        Element oblastPestovani = doc.createElement("oblast-pestovani");
        Element statPestovani = doc.createElement("stat-pestovani");
        statPestovani.setTextContent("Francie");
        Element region = doc.createElement("region");
        region.setTextContent("Alsace");
        oblastPestovani.appendChild(statPestovani);
        oblastPestovani.appendChild(region);
        Element zapis = doc.createElement("zapis");
        zapis.setTextContent("1993");
        odruda.appendChild(synonymum1);
        odruda.appendChild(synonymum2);
        odruda.appendChild(puvodOdrudy);
        odruda.appendChild(oblastPestovani);
        odruda.appendChild(zapis);

        hrozny.appendChild(plod);
        hrozny.appendChild(barva);
        hrozny.appendChild(odruda);

        root.appendChild(hrozny);

        Element trieda = doc.createElement("trieda");
        trieda.setAttribute("jmeno-tridy", "privlastkove");
        Element stupneCukernatosti = doc.createElement("stupne-cukernatosti");
        stupneCukernatosti.setTextContent("26");
        Element privlastok = doc.createElement("privlastok");
        privlastok.setAttribute("jmeno-privlastku", "vyber-z-hroznu");
        trieda.appendChild(stupneCukernatosti);
        trieda.appendChild(privlastok);

        root.appendChild(trieda);

        Element zbytkovyCukr = doc.createElement("zbytkovy-cukr");
        Element klasifikace = doc.createElement("klasifikace");
        klasifikace.setAttribute("jmeno-klasifikace", "polosuche");
        Element gNaLitr = doc.createElement("g-na-litr");
        gNaLitr.setTextContent("8.7");
        zbytkovyCukr.appendChild(klasifikace);
        zbytkovyCukr.appendChild(gNaLitr);
        root.appendChild(zbytkovyCukr);

        Element alkohol = doc.createElement("alkohol");
        alkohol.setAttribute("percent", "12");
        root.appendChild(alkohol);

        Element odporucenaTeplotaPodavani = doc.createElement("odporucena-teplota-podavani");
        odporucenaTeplotaPodavani.setAttribute("od", "10");
        odporucenaTeplotaPodavani.setAttribute("do", "12");
        root.appendChild(odporucenaTeplotaPodavani);

        Element siricitany = doc.createElement("siricitany");
        siricitany.setAttribute("obsahuje", "ano");
        root.appendChild(siricitany);

        Element popis = doc.createElement("popis");
        popis.setTextContent("Vůně vína připomíná kandované ovoce s nádechem zralého kiwi. Chuť je plná a extraktivní. Víno doporučujeme k pikantní úpravě drůbežích jater a k extra tvrdým sýrům.");
        root.appendChild(popis);

        // append to the existing document tree
        NodeList parent = doc.getElementsByTagName("vina");
        parent.item(0).appendChild(root);
    }

    private static void deleteWinesUntil(Document doc, int year) throws DOMException, NumberFormatException {
        NodeList inspected = doc.getElementsByTagName("rok");
        for (int i = 0; i < inspected.getLength(); i++) {
            Element check = (Element) inspected.item(i);
            if (Integer.parseInt(check.getTextContent()) < year) {
                Node deleted = check.getParentNode().getParentNode();
                Node deletedParent = deleted.getParentNode();
                System.out.format("Romving [%s] from [%s].%n", deleted.getAttributes().getNamedItem("kod-vina").getNodeValue(), deletedParent.getNodeName());
                deletedParent.removeChild(deleted);
            }
        }
    }
}
