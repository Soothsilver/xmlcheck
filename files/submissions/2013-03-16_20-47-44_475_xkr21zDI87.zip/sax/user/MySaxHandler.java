package sax.user;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 * Out custom content handler for managing SAX events Implements methods of the
 * abstract class ContentHandler.
 * @see http://www.saxproject.org/apidoc/org/xml/sax/ContentHandler.html#processingInstruction%28java.lang.String,%20java.lang.String%29
 */
public class MySaxHandler implements ContentHandler {
    
    // Helper variable to store location of the handled event
    Locator locator;

    // Helper collections
    private Map<String, AtomicInteger> colorCounter = new HashMap<String, AtomicInteger>();
    private List<Double> gNaLitre = new ArrayList<Double>();
    private List<Vino> vina = new ArrayList<Vino>();

    // Helper objects
    private Vino currVino;
    private Vinarstvi vinarstvi;
    
    // Helper values
    private String retrievedVinarstviId = "";
    
    /**
     * Sets the locator
     *
     * @param Locator locator location in the file
     */
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Method to handle "document start"
     *
     * @throws SAXException
     */
    @Override
    public void startDocument() throws SAXException {
        // ...
    }

    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
        // TASK 01 - ktera barva vina sa v dokumente najviac krat vyskytuje?
        System.out.println("TASK 01:");
        String color = retrieveColorWithHighestOccurence(colorCounter);
        System.out.format("Color [%s] has the highest occurence [%d] in the document.%n", color, colorCounter.get(color).intValue());
        System.out.format("Total color stats: [%s]%n", colorCounter);
        
        // TASK 02 - aky je priemer hodnoty gramov cukru na liter u vin uvedenych v dokumente?
        System.out.println("TASK 02:");
        System.out.format("Avarage value of 'g-na-liter' is [%s] %n", countAverage(gNaLitre));
        
        // TASK 03 - najdi jmeno a rok zalozeni vinarstva (staci jedno), ktore ma aspon jedno bile vino z privlastkom 'pozdni-sber'
        System.out.println("TASK 03:");
        String output = "";
        if (retrievedVinarstviId.isEmpty()) {
            output = "Vinarstvo, ktore ma aspon jedno bile vino s privlastkom 'pozdni sber' nebylo nalezeno.";
        } else {
            output = String.format("Vinarstvo, ktore ma aspon jedno bile vino s privlastkom 'pozdni sber' sa vola [%s] a bylo zalozeno v roku [%s].", vinarstvi.getJmeno(), vinarstvi.getRok());
        }
        System.out.println(output);
        
    }

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        
        handleTask01(uri, localName, qName, atts); // requried for counting the wine color with the hightest occurence

        if (localName.equals("g-na-litr")) {
            InElement.gNaLiter = true;
        }
        if (localName.equals("vino")) {
            InElement.vino = true;
            currVino = new Vino();
        }
        if (localName.equals("vinarstvi-ref")) {
            String idVinarstvi = atts.getValue("id-vinarstvi-ref");
            currVino.setIdVinarstvi(idVinarstvi);
        }
        if (localName.equals("privlastok")) {
            String privlastek = atts.getValue("jmeno-privlastku");
            currVino.setPrivlastok(privlastek);
        }
        if (localName.equals("barva")) {
            String barva = atts.getValue("jmeno-barvy");
            currVino.setBarva(barva);
        }
        if (localName.equals("vinarstvi")) {
            if (atts.getValue("id-vinarstvi").equals(retrievedVinarstviId)) {
                InElement.vinarstviKtereSmeHledali = true;
                vinarstvi = new Vinarstvi();
            }
        }
        if (InElement.vinarstviKtereSmeHledali && localName.equals("jmeno")) {
            InElement.jmenoVinarstvi = true;
        }
        if (InElement.vinarstviKtereSmeHledali && localName.equals("rok-zalozeni")) {
            InElement.rokZalozeni = true;
        }
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (localName.equals("g-na-litr")) {
            InElement.gNaLiter = false;
        }
         if (localName.equals("vino")) {
            InElement.vino = false;
            vina.add(currVino.copy());
            currVino = null;
        }
        if (localName.equals("vina")) {
            // opustame element vina, treba urcit ci sme nasli aspon jedno bile vino z privlastkom 'vyber-z-hroznu'
            checkIfAnyWinesMatch();
        }
        if (InElement.vinarstviKtereSmeHledali) {
            if (InElement.jmenoVinarstvi) {
                InElement.jmenoVinarstvi = false;
            }
            if (InElement.rokZalozeni) {
                InElement.rokZalozeni = false;
            }
        }
        if (localName.equals("vinarsvti")) {
            if (InElement.vinarstviKtereSmeHledali) {
                InElement.vinarstviKtereSmeHledali = false;
            }
        }
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        // v pripade ze sa parser nachazda vo vnutri elementu 'g-na-liter' precitajme a ulozme jeho hodnotu
        readGNaLiterContentIfNecessary(start, length, ch);
        
        // v pripade ze sa parser nachazda vo vnutri vinarstva ktore sme hladali spracujme dalej jeho hodnoty
        readVinarstviKtereJsmeHledaliContentIfNecessary(start, length, ch);
    }

    /**
     * Method to handle " start of namespace declaration"
     *
     * @param prefix Prefix of the namespace
     * @param uri URI of the namespace
     * @throws SAXException
     */
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    /**
     * Method to handle "end of namespace declaration"
     *
     * @param prefix
     * @throws SAXException
     */
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    /**
     * Method to handle "ignoring of whitespaces" Text is in array 'chars' from
     * position ('start') to ('start' + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     * @throws SAXException
     */
    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
        // ...
    }

    /**
     * Method to handle "processing instructions"
     *
     * @param target The processing instruction target
     * @param data The processing instruction data
     * @throws SAXException
     */
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

    /**
     * Method to handle "unprocessed entity"
     *
     * @param name
     * @throws SAXException
     */
    @Override
    public void skippedEntity(String name) throws SAXException {
        // ...
    }

    //////////  Helper Methods  //////////
    
    /**
     * Required for retriving a wine color count with the highest occurence.
     */
    private void handleTask01(String uri, String localName, String qName, Attributes atts) {
        if (localName.equals("barva")) {
            String color = atts.getValue("jmeno-barvy");
            if (colorCounter.containsKey(color)) {
                colorCounter.put(color, new AtomicInteger(colorCounter.get(color).incrementAndGet()));
            } else {
                colorCounter.put(color, new AtomicInteger(1));
            }
        }
    }

    private String retrieveColorWithHighestOccurence(Map<String, AtomicInteger> map) {
        String highest = "";
        for (String key : map.keySet()) {
            if (map.get(key).intValue() > getCurrentHighestSafe(map, highest)) {
                highest = key;
            }
        }
        return highest;
    }

    private int getCurrentHighestSafe(Map<String, AtomicInteger> map, String curr) {
        return map.get(curr) == null ? -1 : map.get(curr).intValue();
    }
    
    private double countAverage(List<Double> doubles){
        double result = 0;
        for (Double d : doubles) {
            result = result + d;
        }
        return result/doubles.size();
    }

    private void checkIfAnyWinesMatch() {
        for (Vino vino : vina) {
            if (vino.getBarva() != null && vino.getPrivlastok() != null && vino.getBarva().equals("bila") && vino.getPrivlastok().equals("pozdni-sber")) {
                retrievedVinarstviId = vino.getIdVinarstvi();
            }
        }
    }
    
    /**
     * V pripade ze sa parser nachazda vo vnutri elementu 'g-na-liter' precitajme a ulozme jeho hodnotu.
     */
    private void readGNaLiterContentIfNecessary(int start, int length, char[] ch) throws NumberFormatException {
        if (InElement.gNaLiter) {
            StringBuilder sb = new StringBuilder("");
            for (int i = start; i < start + length; i++) {
                sb.append(ch[i]);
            }
            gNaLitre.add(Double.parseDouble(sb.toString()));
        }
    }

    /**
     * V pripade ze sa parser nachazda vo vnutri vinarstva ktore sme hladali spracujme dalej jeho hodnoty.
     */
    private void readVinarstviKtereJsmeHledaliContentIfNecessary(int start, int length, char[] ch) {
        if (InElement.vinarstviKtereSmeHledali) {
            if (InElement.jmenoVinarstvi) {
                StringBuilder sb = new StringBuilder("");
                for (int i = start; i < start + length; i++) {
                    sb.append(ch[i]);
                }
                vinarstvi.setJmeno(sb.toString());
            }
            if (InElement.rokZalozeni) {
                StringBuilder sb = new StringBuilder("");
                for (int i = start; i < start + length; i++) {
                    sb.append(ch[i]);
                }
                vinarstvi.setRok(sb.toString());
            }
        }
    }
    
    //////////  Inner Classes Declarations  //////////

    private static class InElement {
        public static boolean gNaLiter = false;
        public static boolean vinarstviRef = false;
        public static boolean vino = false;
        public static boolean vinarstvi = false;
        public static boolean vinarstviKtereSmeHledali = false;
        public static boolean jmenoVinarstvi = false;
        public static boolean rokZalozeni = false;
    }
    
    private class Vino implements Cloneable{
        private String barva;
        private String privlastok;
        private String idVinarstvi;

        public Vino() {
        }

        public Vino(Vino vino) {
            this.barva = vino.getBarva();
            this.privlastok = vino.getPrivlastok();
            this.idVinarstvi = vino.getIdVinarstvi();
        }
        
        public String getBarva() {
            return barva;
        }

        public void setBarva(String barva) {
            this.barva = barva;
        }

        public String getPrivlastok() {
            return privlastok;
        }

        public void setPrivlastok(String privlastok) {
            this.privlastok = privlastok;
        }

        public String getIdVinarstvi() {
            return idVinarstvi;
        }

        public void setIdVinarstvi(String idVinarstvi) {
            this.idVinarstvi = idVinarstvi;
        }
        
        public Vino copy(){
            return new Vino(this);
        }

        @Override
        public String toString() {
            return "Vino{" + "barva=" + barva + ", privlastok=" + privlastok + ", idVinarstvi=" + idVinarstvi + '}';
        }
    }
    
    private class Vinarstvi{
        private String jmeno;
        private String rok;

        public Vinarstvi() {
        }
        
        public Vinarstvi(String jmeno, String rok) {
            this.jmeno = jmeno;
            this.rok = rok;
        }

        public String getJmeno() {
            return jmeno;
        }

        public String getRok() {
            return rok;
        }

        public void setJmeno(String jmeno) {
            this.jmeno = jmeno;
        }

        public void setRok(String rok) {
            this.rok = rok;
        }
        
        @Override
        public String toString() {
            return "Vinarstvi{" + "jmeno=" + jmeno + ", rok=" + rok + '}';
        }
        
    }

    //////////  Main Method  //////////
    public static void main(String[] args) {
        String sourcePath = "data.xml";
        try {

            // Create parser instance
            XMLReader parser = XMLReaderFactory.createXMLReader();

            // Create input stream from source XML document
            InputSource source = new InputSource(sourcePath);

            // Set our custom content handler for handling SAX events (it must implements ContentHandler interface)
            parser.setContentHandler(new MySaxHandler());

            // Process input data
            parser.parse(source);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    ////////// Main Method End  //////////
    
}
