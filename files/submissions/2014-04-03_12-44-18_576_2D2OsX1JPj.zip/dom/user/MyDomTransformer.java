/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

/**
 *
 * @author Jirka
 */
public class MyDomTransformer {
public void transform (Document xmlDocument) {
    // libovolne transformace objektu 'xmlDocument'
    // (metoda pracuje primo na objektu, nic nevraci)
    Element car = xmlDocument.createElement("Car");
    car.setAttribute("carNumber", "AAA0011");
    car.setAttribute("year", "2014");
    Element type = xmlDocument.createElement("Type");
    type.setAttribute("brand", "Skoda");
    type.setTextContent("Rapid");
    car.appendChild(type);
    car.appendChild(xmlDocument.createElement("img"));
    NodeList carLists = xmlDocument.getElementsByTagName("CarList");
    Element carList = (Element) carLists.item(0);
    carList.appendChild(car);
        
    NodeList cars = xmlDocument.getElementsByTagName("Car");
    for (int i = 0; i < cars.getLength(); i++) {
        Element tmp = (Element)cars.item(i);
        String att = tmp.getAttribute("year");
        if(Integer.parseInt(att) <= 2009){
            carList.removeChild(tmp);
        }
    }
}
}
