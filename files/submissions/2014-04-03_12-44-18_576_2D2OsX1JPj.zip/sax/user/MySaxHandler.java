package user;

import java.io.IOException;
import java.util.HashMap;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {

    Locator locator;
    int numberOfCar;
    String[] myTypes;
    int[] numberOfMyTypes;
    boolean myType;
    double averageAgeOfSkoda;
    int numberOfSkoda;
    int age;

    @Override
    public void fatalError(SAXParseException e) throws SAXException {
        super.fatalError(e); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void error(SAXParseException e) throws SAXException {
        super.error(e); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void warning(SAXParseException e) throws SAXException {
        super.warning(e); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void skippedEntity(String name) throws SAXException {
        super.skippedEntity(name); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        super.processingInstruction(target, data); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        super.ignorableWhitespace(ch, start, length); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        if (myType) {
            String typeOfCar = "";
            for (int i = start; i < start + length; i++) {
                if (!Character.isWhitespace(ch[i])) {
                    typeOfCar += (ch[i]);
                }
            }
            int tmp = 0;
            for (int i = 0; i < myTypes.length; i++) {
                if (numberOfMyTypes[i] == 0) {
                    tmp = i;
                    break;
                }
                if (myTypes[i].equals(typeOfCar)) {
                    tmp = i;
                    break;
                }
            }
            myTypes[tmp] = typeOfCar;
            numberOfMyTypes[tmp]++;

        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        super.endElement(uri, localName, qName); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        if (localName.equals("Car")) {
            this.age = 2014 - Integer.parseInt(attributes.getValue(1));
            if (age < 4) {
                numberOfCar++;
            }
        }
        this.myType = localName.equals("Type");
        if (myType && attributes.getValue(0).equals("Skoda")) {
            numberOfSkoda++;
            averageAgeOfSkoda += age;
        }
    }

    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        super.endPrefixMapping(prefix); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        super.startPrefixMapping(prefix, uri); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void endDocument() throws SAXException {
        String mostCommonType = "";
        int count = 0;
        for (int i = 0; i < myTypes.length; i++) {
            if (numberOfMyTypes[i] > count) {
                mostCommonType = myTypes[i];
                count = numberOfMyTypes[i];
            }
        }
        averageAgeOfSkoda = averageAgeOfSkoda / numberOfSkoda;
        System.out.println("Pocet aut starsich nez 4 roky: " + numberOfCar);
        System.out.println("Nejcastejsi typ auta: " + mostCommonType);
        System.out.println("Prumerne stari aut znacky Skoda " + String.format("%.2f", averageAgeOfSkoda));
    }

    @Override
    public void startDocument() throws SAXException {
        System.out.println("SAX Handler");
        this.numberOfCar = 0;
        this.myTypes = new String[50];
        this.numberOfMyTypes = new int[50];
        this.myType = false;
        this.averageAgeOfSkoda = 0;
        this.age = 0;
        this.numberOfSkoda = 0;
    }

    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    @Override
    public void unparsedEntityDecl(String name, String publicId, String systemId, String notationName) throws SAXException {
        super.unparsedEntityDecl(name, publicId, systemId, notationName); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void notationDecl(String name, String publicId, String systemId) throws SAXException {
        super.notationDecl(name, publicId, systemId); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public InputSource resolveEntity(String publicId, String systemId) throws IOException, SAXException {
        return super.resolveEntity(publicId, systemId); //To change body of generated methods, choose Tools | Templates.
    }

  // override metod DefaultHandleru
}
