package user;

import java.util.ArrayList;
import java.util.List;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class MyDomTransformer {
	
	public void transform(Document xmlDocument) {
		
		/**
		 * add station
		 */
		//always has to be there
		NodeList all = xmlDocument.getElementsByTagName("trainSystem");
		if(all.getLength() != 1) {
			return;
		}
		
		Element trainSystem = (Element) all.item(0);
		
		NodeList nodes = xmlDocument.getElementsByTagName("stations");
		if(nodes.getLength() == 0) {
			Element stations = xmlDocument.createElement("stations");
			trainSystem.appendChild(stations);
			nodes = xmlDocument.getElementsByTagName("stations");
		}
		
		Element root = (Element) nodes.item(0);
		
		Element station = xmlDocument.createElement("station");
		station.setAttribute("id", "station_x");
		
		Element stationName = xmlDocument.createElement("stationName");
		stationName.setTextContent("Vídeň Hlavní nádaží");
		
		Element stationCode = xmlDocument.createElement("stationCode");
		stationCode.setTextContent("VIEHN");
		
		Element stationCity = xmlDocument.createElement("stationCity");
		stationCity.setTextContent("Vídeň");
		
		root.appendChild(station);
		station.appendChild(stationName);
		station.appendChild(stationCode);
		station.appendChild(stationCity);
		
		
		/**
		 * del ticket seats reservation where price < 100 and delete the reference in tickets
		 */	
		List<String> toDel = new ArrayList<String>();
		NodeList seatReservation = xmlDocument.getElementsByTagName("seatReservation");
		for (int i = seatReservation.getLength() - 1; i >= 0; i--) {
			Element element = (Element) seatReservation.item(i);
			
			NodeList siblings = element.getElementsByTagName("price");
			if(siblings.getLength() != 1) {
				continue;
			}
			Element sibling = (Element) siblings.item(0);
			if(Integer.parseInt(sibling.getTextContent()) < 100) {
				Element el2 = (Element) sibling.getParentNode();
				Element el3 = (Element) el2.getParentNode();
				toDel.add(el2.getAttribute("id"));
				el3.removeChild(el2);
			}
		}
		
		
		seatReservation = xmlDocument.getElementsByTagName("ticketSeatReservation");
		for (int i = seatReservation.getLength() - 1; i >= 0; i--) {
			Element element = (Element) seatReservation.item(i);

			for(String s : toDel) {
				System.out.println(s);
				if(element.hasAttribute("ref") && element.getAttribute("ref").equals(s)) {
					Element el2 = (Element) element.getParentNode();
					el2.removeChild(element);
				}
			}
		}
		
	}
}
