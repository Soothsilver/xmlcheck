/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.util.ArrayList;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author Fran
 */
public class MyDomTransformer {

    public void transform(Document xmlDocument) {
        // code transforming xmlDocument object 
        // (method works on the object itself - no return value)
        
        //Odstrani vsechny hrace s mensim platem nez 30000
        //a pokud byli nominovani na nejaky zapas,
        //tak je z nominace odstrani
        NodeList players = xmlDocument.getElementsByTagName("player");
        NodeList matches = xmlDocument.getElementsByTagName("match");
        ArrayList<String> firedPlayers = new ArrayList();
        int i = 0;
        while (i < players.getLength()) {
            Node player = players.item(i);
            Element ePlayer = (Element) player;
            Element eContract = (Element) ePlayer.getElementsByTagName("contract").item(0).getChildNodes();
            int wage = Integer.parseInt(eContract.getElementsByTagName("wage").item(0).getTextContent());
            if (wage < 30000) {
                firedPlayers.add(ePlayer.getAttribute("id"));
                ePlayer.getParentNode().removeChild(player);
                i--;
            }
            i++;
        }
        for (int j = 0; j < matches.getLength(); j++) {
            Node match = matches.item(j);
            Element eMatch = (Element) match;
            String squad = eMatch.getAttribute("squad");
            for (String id : firedPlayers) {
                if (squad.contains(id)) {
                    String updatedSquad = squad.replaceAll(id, "");
                    eMatch.setAttribute("squad", updatedSquad);
                }
            }
        }

        //Prida noveho hrace
        Element player = xmlDocument.createElement("player");
        player.setAttribute("id", "p20");
        player.setAttribute("squad", "first_team");
        player.setAttribute("position", "midfielder");
        player.appendChild(xmlDocument.createElement("name")).setTextContent("Mathieu Flamini");
        player.appendChild(xmlDocument.createElement("nation")).setTextContent("France");
        player.appendChild(xmlDocument.createElement("date_of_birth")).setTextContent("7.3.1984");
        player.appendChild(xmlDocument.createElement("number")).setTextContent("20");
        Node contract = xmlDocument.createElement("contract");
        contract.appendChild(xmlDocument.createElement("started")).setTextContent("29.8.2013");
        contract.appendChild(xmlDocument.createElement("expires")).setTextContent("30.6.2015");
        contract.appendChild(xmlDocument.createElement("wage")).setTextContent("50000");
        player.appendChild(contract);

        NodeList nlPlayers = xmlDocument.getElementsByTagName("players");
        Element elPlayers;
        if (players.getLength() == 0) {
            elPlayers = xmlDocument.createElement("players");
            elPlayers.appendChild(player);
        } else {
            elPlayers = (Element) nlPlayers.item(0);
        }
        elPlayers.appendChild(player);
    }
}
