package user;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.helpers.DefaultHandler;

class Player {

    private String id;
    private String name;
    private String nation;

    public String getID() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNation() {
        return nation;
    }

    public void setNation(String nation) {
        this.nation = nation;
    }
    private String dateOfBirth;
    private int number;
    private String squad;
    private String position;

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getSquad() {
        return squad;
    }

    public void setSquad(String squad) {
        this.squad = squad;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }
    private String contractType;
    private String contractStarted;
    private String contractExpires;
    private int contractWage;

    public String getContractType() {
        return contractType;
    }

    public void setContractType(String type) {
        this.contractType = type;
    }

    public String getContractStarted() {
        return contractStarted;
    }

    public void setContractStarted(String started) {
        this.contractStarted = started;
    }

    public String getContractExpires() {
        return contractExpires;
    }

    public void setContractExpires(String expires) {
        this.contractExpires = expires;
    }

    public int getContractWage() {
        return contractWage;
    }

    public void setContractWage(int wage) {
        this.contractWage = wage;
    }

    public String toString() {
        return "Player: " + getID() + "\n"
                + "   name: " + getName() + "\n"
                + "   nation: " + getNation() + "\n"
                + "   date of birth: " + dateOfBirth + "\n"
                + "   number: " + number + "\n"
                + "   squad: " + squad + "\n"
                + "   position: " + position
                + "   Contract: \n"
                + "      type: " + contractType + "\n"
                + "      started: " + contractStarted + "\n"
                + "      expires: " + contractExpires + "\n"
                + "      wage: " + contractWage;
    }
}

public class MySaxHandler extends DefaultHandler {

    public static void main(String[] args) {
        try {
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser saxParser = factory.newSAXParser();
            MySaxHandler handler = new MySaxHandler();

            File file = new File("data.xml");
            InputStream inputStream = new FileInputStream(file);
            Reader reader = new InputStreamReader(inputStream, "UTF-8");

            InputSource is = new InputSource(reader);
            is.setEncoding("UTF-8");

            saxParser.parse(file, handler);

            List<Player> players = handler.getPlayers();

            System.out.println("___________");
            //Spocita prumernou mzdu hracu v klubu
            int wages = 0;
            int nPlayers = 0;
            for (Player p : players) {
                wages += p.getContractWage();
                nPlayers++;
            }
            System.out.println("Prumerna mzda vsech hracu v klubu: " + wages / nPlayers);

            //Zjisti nejcastejsi narodnost vsech hracu v klubu a jejich pocet
            Map<String, Integer> occurrences = new HashMap();
            String nation = "";
            int nationCount = 0;
            for (Player p : players) {
                String s = p.getNation();
                if (occurrences.containsKey(s)) {
                    occurrences.put(s, occurrences.get(s) + 1);
                } else {
                    occurrences.put(s, 1);
                }
            }
            for (Map.Entry pair : occurrences.entrySet()) {
                if ((Integer) pair.getValue() > nationCount) {
                    nationCount = (Integer) pair.getValue();
                    nation = pair.getKey().toString();
                }
            }
            System.out.println("Nejcastejsi narodnost je: " + nation + "; pocet vyskytu: " + nationCount);

            //Zjisti kterym hracum konci smlouva v roce 2014
            List<Player> endingContracts = new ArrayList();
            for (Player p : players) {
                if (p.getContractExpires().endsWith("2014")) {
                    endingContracts.add(p);
                }
            }
            System.out.println("Temto lidem konci smlouva v roce 2014:");
            for (Player p : endingContracts) {
                System.out.println("    " + p.getName());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    // overrides of DefaultHandler methods
    private Player player = null;
    private List<Player> players = new ArrayList();
    private boolean bCity = false;
    private boolean bClub = false;
    private boolean bDirector = false;
    private boolean bCompetition = false;
    private boolean bEmployee = false;
    private boolean bContract = false;
    private boolean bDate = false;
    private boolean bDateOfBirth = false;
    private boolean bExpires = false;
    private boolean bFounded = false;
    private boolean bFullName = false;
    private boolean bGround = false;
    private boolean bLastSeasonStanding = false;
    private boolean bLeague = false;
    private boolean bMatch = false;
    private boolean bName = false;
    private boolean bNation = false;
    private boolean bNickname = false;
    private boolean bNumber = false;
    private boolean bOpponent = false;
    private boolean bPlayer = false;
    private boolean bStarted = false;
    private boolean bTrainingGround = false;
    private boolean bWage = false;

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) {
        if (qName.equalsIgnoreCase("captain")) {
        } else if (qName.equalsIgnoreCase("chairman")) {
            bDirector = true;
        } else if (qName.equalsIgnoreCase("chief_executive_officer")) {
            bDirector = true;
        } else if (qName.equalsIgnoreCase("city")) {
            bCity = true;
        } else if (qName.equalsIgnoreCase("info")) {
            bClub = true;
        } else if (qName.equalsIgnoreCase("coach")) {
            bEmployee = true;
        } else if (qName.equalsIgnoreCase("competition")) {
            bCompetition = true;
        } else if (qName.equalsIgnoreCase("contract")) {
            if (player != null) {
                player.setContractType(attributes.getValue("type"));
                bContract = true;
            }
        } else if (qName.equalsIgnoreCase("date")) {
            bDate = true;
        } else if (qName.equalsIgnoreCase("date_of_birth")) {
            bDateOfBirth = true;
        } else if (qName.equalsIgnoreCase("expires")) {
            bExpires = true;
        } else if (qName.equalsIgnoreCase("founded")) {
            bFounded = true;
        } else if (qName.equalsIgnoreCase("fullname")) {
            bFullName = true;
        } else if (qName.equalsIgnoreCase("ground")) {
            bGround = true;
        } else if (qName.equalsIgnoreCase("last_season_standing")) {
            bLastSeasonStanding = true;
        } else if (qName.equalsIgnoreCase("league")) {
            bLeague = true;
        } else if (qName.equalsIgnoreCase("manager")) {
            bEmployee = true;
        } else if (qName.equalsIgnoreCase("management")) {
        } else if (qName.equalsIgnoreCase("match")) {
            bMatch = true;
        } else if (qName.equalsIgnoreCase("fixtures")) {
        } else if (qName.equalsIgnoreCase("name")) {
            bName = true;
        } else if (qName.equalsIgnoreCase("nation")) {
            bNation = true;
        } else if (qName.equalsIgnoreCase("number")) {
            bNumber = true;
        } else if (qName.equalsIgnoreCase("physiotherapist")) {
            bEmployee = true;
        } else if (qName.equalsIgnoreCase("nickname")) {
            bNickname = true;
        } else if (qName.equalsIgnoreCase("opponent")) {
            bOpponent = true;
        } else if (qName.equalsIgnoreCase("place")) {
        } else if (qName.equalsIgnoreCase("player")) {
            player = new Player();
            player.setId(attributes.getValue("id"));
            player.setSquad(attributes.getValue("squad"));
            player.setPosition(attributes.getValue("position"));
            bPlayer = true;
        } else if (qName.equalsIgnoreCase("players")) {
        } else if (qName.equalsIgnoreCase("scout")) {
            bEmployee = true;
        } else if (qName.equalsIgnoreCase("staff")) {
        } else if (qName.equalsIgnoreCase("started")) {
            bStarted = true;
        } else if (qName.equalsIgnoreCase("training_ground")) {
            bTrainingGround = true;
        } else if (qName.equalsIgnoreCase("wage")) {
            bWage = true;
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) {
        if (qName.equalsIgnoreCase("chairman")) {
            bDirector = false;
        } else if (qName.equalsIgnoreCase("chief_executive_officer")) {
            bDirector = false;
        } else if (qName.equalsIgnoreCase("city")) {
            bCity = false;
        } else if (qName.equalsIgnoreCase("info")) {
            bClub = false;
        } else if (qName.equalsIgnoreCase("coach")) {
            bEmployee = false;
        } else if (qName.equalsIgnoreCase("competition")) {
            bCompetition = false;
        } else if (qName.equalsIgnoreCase("contract")) {
            bContract = false;
        } else if (qName.equalsIgnoreCase("date")) {
            bDate = false;
        } else if (qName.equalsIgnoreCase("date_of_birth")) {
            bDateOfBirth = false;
        } else if (qName.equalsIgnoreCase("expires")) {
            bExpires = false;
        } else if (qName.equalsIgnoreCase("founded")) {
            bFounded = false;
        } else if (qName.equalsIgnoreCase("fullname")) {
            bFullName = false;
        } else if (qName.equalsIgnoreCase("ground")) {
            bGround = false;
        } else if (qName.equalsIgnoreCase("last_season_standing")) {
            bLastSeasonStanding = false;
        } else if (qName.equalsIgnoreCase("league")) {
            bLeague = false;
        } else if (qName.equalsIgnoreCase("manager")) {
            bEmployee = false;
        } else if (qName.equalsIgnoreCase("match")) {
            bMatch = false;
        } else if (qName.equalsIgnoreCase("name")) {
            bName = false;
        } else if (qName.equalsIgnoreCase("nation")) {
            bNation = false;
        } else if (qName.equalsIgnoreCase("number")) {
            bNumber = false;
        } else if (qName.equalsIgnoreCase("opponent")) {
            bOpponent = false;
        } else if (qName.equalsIgnoreCase("physiotherapist")) {
            bEmployee = false;
        } else if (qName.equalsIgnoreCase("nickname")) {
            bNickname = false;
        } else if (qName.equalsIgnoreCase("player")) {
            players.add(player);
            bPlayer = false;
            System.out.println(player.toString());
        } else if (qName.equalsIgnoreCase("scout")) {
            bEmployee = false;
        } else if (qName.equalsIgnoreCase("started")) {
            bStarted = false;
        } else if (qName.equalsIgnoreCase("training_ground")) {
            bTrainingGround = false;
        } else if (qName.equalsIgnoreCase("wage")) {
            bWage = false;
        }
    }

    @Override
    public void characters(char ch[], int start, int length) {
        if (bPlayer) {
            if (bName) {
                player.setName(new String(ch, start, length));
            } else if (bNation) {
                player.setNation(new String(ch, start, length));
            } else if (bDateOfBirth) {
                player.setDateOfBirth(new String(ch, start, length));
            } else if (bNumber) {
                player.setNumber(Integer.parseInt(new String(ch, start, length)));
            }
        }
        if (bContract && (player != null)) {
            if (bStarted) {
                player.setContractStarted(new String(ch, start, length));
            } else if (bExpires) {
                player.setContractExpires(new String(ch, start, length));

            } else if (bWage) {
                player.setContractWage(Integer.parseInt(new String(ch, start, length)));
            }
        }
    }

    public List<Player> getPlayers() {
        return players;
    }
}
