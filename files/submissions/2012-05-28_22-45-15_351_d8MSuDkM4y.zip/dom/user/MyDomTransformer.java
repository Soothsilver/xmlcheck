package y36xml;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

import sun.rmi.runtime.NewThreadAction;

/**
 * ZADANI:
 * Upravte program tak, aby transformoval vstupni XML dokument na vystupni pomoci akci
 * uvedenych v komentarich metody processTree(doc).
 */
public class MyDomTransformer {

    private static final String VSTUPNI_SOUBOR = "..\\..\\data.xml";
    //private static final String VSTUPNI_SOUBOR = "C:\\Documents and Settings\\hlisp7am\\Desktop\\data.xml";
    private static final String VYSTUPNI_SOUBOR = "..\\..\\data.out.xml";
    //private static final String VYSTUPNI_SOUBOR = "C:\\Documents and Settings\\hlisp7am\\Desktop\\data.out.xml";

    public static void main(String[] args) {
        
        try {
            
            //DocumentBuilderFactory vytvari DOM parsery
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            //nebudeme validovat
            dbf.setValidating(false);

            //vytvorime si DOM parser
            DocumentBuilder builder = dbf.newDocumentBuilder();

            //parser zpracuje vstupni soubor a vytvori z nej strom DOM objektu
            Document doc = builder.parse(VSTUPNI_SOUBOR);

            //zpracujeme DOM strom
            processTree(doc);

            //TransformerFactory vytvari serializatory DOM stromu
            TransformerFactory tf = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer = tf.newTransformer();

            //nastavime kodovani
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spustime transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


        } catch (Exception e) {
            
            e.printStackTrace();
            
        }
    }
    
    private static int processHeadshots(Node element) {
    	//System.out.println(element.getNodeName());
    	NodeList zbrane = element.getChildNodes();
		int headshots = 0;
		for (int i = 0; i < zbrane.getLength(); ++i) {
			Node zbran = zbrane.item(i);
			//System.out.println(zbran.getNodeName());
			String nazov = zbran.getNodeName();
			if (nazov.equals("knife") ||
				nazov.equals("usp") ||
				nazov.equals("glock") ||
				nazov.equals("deagle") ||
				nazov.equals("p-228") ||
				nazov.equals("dual") ||
				nazov.equals("five-seven") ||
				nazov.equals("m3") ||
				nazov.equals("xm1014") ||
				nazov.equals("ingram") ||
				nazov.equals("stmp") ||
				nazov.equals("mp5") ||
				nazov.equals("ump45") ||
				nazov.equals("p90") ||
				nazov.equals("famas") ||
				nazov.equals("m4") ||
				nazov.equals("steyr") ||
				nazov.equals("galil") ||
				nazov.equals("ak-47") ||
				nazov.equals("kreig") ||
				nazov.equals("scout") ||
				nazov.equals("awm") ||
				nazov.equals("HaK_G3") ||
				nazov.equals("SG-550") ||
				nazov.equals("m249") ||
				nazov.equals("he")) {
				NodeList stats = zbran.getChildNodes();
				for (int j = 0; j < stats.getLength();++j) {
					Node a = stats.item(j);
					if (a.getNodeName().equals("headshots")) {
						headshots += Integer.parseInt(a.getTextContent());
					}
				}
			}
		}
		return headshots;
    }
    
    private static double processAccuracy(Node element) {
    	//System.out.println(element.getNodeName());
    	NodeList zbrane = element.getChildNodes();
		int num = 0;
		double sum = 0.0;
		for (int i = 0; i < zbrane.getLength(); ++i) {
			Node zbran = zbrane.item(i);
			//System.out.println(zbran.getNodeName());
			String nazov = zbran.getNodeName();
			if (nazov.equals("knife") ||
				nazov.equals("usp") ||
				nazov.equals("glock") ||
				nazov.equals("deagle") ||
				nazov.equals("p-228") ||
				nazov.equals("dual") ||
				nazov.equals("five-seven") ||
				nazov.equals("m3") ||
				nazov.equals("xm1014") ||
				nazov.equals("ingram") ||
				nazov.equals("stmp") ||
				nazov.equals("mp5") ||
				nazov.equals("ump45") ||
				nazov.equals("p90") ||
				nazov.equals("famas") ||
				nazov.equals("m4") ||
				nazov.equals("steyr") ||
				nazov.equals("galil") ||
				nazov.equals("ak-47") ||
				nazov.equals("kreig") ||
				nazov.equals("scout") ||
				nazov.equals("awm") ||
				nazov.equals("HaK_G3") ||
				nazov.equals("SG-550") ||
				nazov.equals("m249") ||
				nazov.equals("he")) {
				NodeList stats = zbran.getChildNodes();
				int kill = 0;
				double accu = 0.0;
				for (int j = 0; j < stats.getLength();++j) {
					//odboku pocitana presnost (jeden zasah = jeden kill) - pre nedostatok informacii
					Node a = stats.item(j);
					if (a.getNodeName().equals("accuracy")) {
						accu = Double.parseDouble(a.getTextContent().replace(',', '.'));
						++num;
					}
				}
				sum += accu;
			}
		}
		sum = sum / num;
		return sum;
    }
    
    private static int processActions(Node element) {
    	//System.out.println(element.getNodeName());
		NodeList akcie = element.getChildNodes();
		int body = 0;
		//spocitanie bodov
		for (int i = 0; i < akcie.getLength(); ++i) {
			Node akcia = akcie.item(i);
			if (akcia.getNodeName().equals("plant")) {
				body += (Integer.parseInt(akcia.getTextContent()) * 1);
			} else if (akcia.getNodeName().equals("defuse")) {
				body += (Integer.parseInt(akcia.getTextContent()) * 1 );
			} else if (akcia.getNodeName().equals("hostage")) {
				body += (Integer.parseInt(akcia.getTextContent()) * 1 );
			} else if (akcia.getNodeName().equals("double-kill")) {
				body += (Integer.parseInt(akcia.getTextContent()) * 2 );
			} else if (akcia.getNodeName().equals("triple-kill")) {
				body += (Integer.parseInt(akcia.getTextContent()) * 3 );
			} else if (akcia.getNodeName().equals("domination")) {
				body += (Integer.parseInt(akcia.getTextContent()) * 4 );
			} else if (akcia.getNodeName().equals("rampage")) {
				body += (Integer.parseInt(akcia.getTextContent()) * 5 );
			} else if (akcia.getNodeName().equals("mega-kill")) {
				body += (Integer.parseInt(akcia.getTextContent()) * 6 );
			} else if (akcia.getNodeName().equals("ownage")) {
				body += (Integer.parseInt(akcia.getTextContent()) * 7 );
			} else if (akcia.getNodeName().equals("ultra-kill")) {
				body += (Integer.parseInt(akcia.getTextContent()) * 8 );
			} else if (akcia.getNodeName().equals("killing-spree")) {
				body += (Integer.parseInt(akcia.getTextContent()) * 9 );
			} else if (akcia.getNodeName().equals("monster-kill")) {
				body += (Integer.parseInt(akcia.getTextContent()) * 10 );
				} else if (akcia.getNodeName().equals("unstoppable")) {
					body += (Integer.parseInt(akcia.getTextContent()) * 11 );
			} else if (akcia.getNodeName().equals("god-like")) {
				body += (Integer.parseInt(akcia.getTextContent()) * 12 );
			}
		}
		// vratenie poctu bodov
		return body;
    }
    
    private static void processDelete(Node element, int zanorenie) {
    	NodeList elements = element.getChildNodes();
    	for (int i = elements.getLength() - 1; i >= 0; --i) {
    		if (zanorenie < 2) { // zanorenie 8 a viac
    			//System.out.println(elements.item(i).getNodeName() + " " + (zanorenie + 1));
    			processDelete(elements.item(i), zanorenie + 1);
    		} else {
    			//System.out.println("mazanie: " + elements.item(i).getNodeName());
    			element.removeChild(elements.item(i));
    		}
    	}
    }

    /**
     * Zpracuje DOM strom
     */
    private static void processTree(Document doc) {
        // zredukovat jednotlive statistiky (tj. z statistik pre jednotlive zbrane spravit vseobecnu statistiku, z akcii spravit bodove ohodnotenie)
    	NodeList hraci = doc.getElementsByTagName("statistiky");
    	for (int i = 0; i < hraci.getLength(); ++i) {
    		Node hrac = hraci.item(i);
    		//System.out.println(hrac.getNodeName());
    		Node hlavne = null;
    		NodeList info = hrac.getChildNodes();
    		for (int j = 0; j < info.getLength(); ++j) {
    			Node element = info.item(j);
    			if (element.getNodeName().equals("hlavne")) {
    				hlavne = element;
    			}
    		}
    		for (int j = 0; j < info.getLength(); ++j) {
    			Node element = info.item(j);
    			if (element.getNodeName().equals("zbrane")) {
    				int head = processHeadshots(element);
    				Element newHeadshots = doc.createElement("headshots");
    				newHeadshots.appendChild(doc.createTextNode(String.valueOf(head)));
    				double accuracy = processAccuracy(element);
    				Element newAccuracy = doc.createElement("accuracy");
    				newAccuracy.appendChild(doc.createTextNode(String.valueOf(accuracy)));
    				hrac.removeChild(element);
    				hlavne.appendChild(newHeadshots);
    				hlavne.appendChild(newAccuracy);
    			}
    			if (element.getNodeName().equals("akcie")) {
    				int body = processActions(element);
    				Element newAkcie = doc.createElement("body");
    				newAkcie.appendChild(doc.createTextNode(String.valueOf(body)));
    				hrac.removeChild(element);
    				hrac.appendChild(newAkcie);
    			}
    		}
    	}
    	
		// zredukovat pocet IP na jednu (pripadne doplnit defaultnu ak tam ziadna nie je)
    	hraci = doc.getElementsByTagName("pripojenie");
    	for (int i = 0; i < hraci.getLength(); ++i) {
    		Node hrac = hraci.item(i);
    		NodeList ip = hrac.getChildNodes();
    		int numberOfIP = 0;
    		for (int j = 0; j < ip.getLength(); ++j) {
    			Node element = ip.item(j);
    			if (element.getNodeName().equals("ip")) {
    				++numberOfIP;
    				if (numberOfIP > 1) {
    					hrac.removeChild(element);
    				}
    			}
    		}
    		if (numberOfIP == 0) {
    			Element newIP = doc.createElement("ip");
    			newIP.appendChild(doc.createTextNode("10.10.10.10")); //default
    			hrac.appendChild(newIP);
    		}
    	}
    	
		// previest vsetky atributy na elementy (ak pojde o prazdny element s jednym atributom tak hodnotu atributu vlozit priamo elementu a nevytvarat z atributu element)
    	hraci = doc.getElementsByTagName("hrac");
    	for (int i = 0; i < hraci.getLength(); ++i) {
    		Node hrac = hraci.item(i);
    		//NICK
    		String text = hrac.getAttributes().getNamedItem("nick").getTextContent();
    		
    		Element nick = doc.createElement("nick");
            nick.appendChild(doc.createTextNode(text));
            hrac.appendChild(nick);
            hrac.getAttributes().removeNamedItem("nick");
            
            //CISLO
            text = hrac.getAttributes().getNamedItem("cislo").getTextContent();
            
            Element cislo = doc.createElement("cislo");
            cislo.appendChild(doc.createTextNode(text));
            hrac.appendChild(cislo);
            hrac.getAttributes().removeNamedItem("cislo");
            
            //BAN
            NodeList infos = hrac.getChildNodes();
            Node info = null;
            for (int j = 0; j < infos.getLength(); ++j) {
            	if (infos.item(j).getNodeName().equals("info")) {
            		info = infos.item(j);
            	}
            }
            
            if (info.getAttributes().getLength() != 0) {
	            text = info.getAttributes().getNamedItem("ban").getTextContent();
	            
	            Element ban = doc.createElement("ban");
	            ban.appendChild(doc.createTextNode(text));
	            info.appendChild(ban);
	            info.getAttributes().removeNamedItem("ban");
            }
            
            //RANK + STEAM
            NodeList longList = info.getChildNodes();
            Node umiestnenie = null;
            Node steam = null;
            for (int j = 0; j < longList.getLength(); ++j) {
            	if (longList.item(j).getNodeName().equals("umiestnenie")) {
            		umiestnenie = longList.item(j);
            	}
            	if (longList.item(j).getNodeName().equals("steam")) {
            		steam = longList.item(j);
            	}
            }
            
            text = umiestnenie.getAttributes().getNamedItem("rank").getTextContent();
            
            Element rank = doc.createElement("rank");
            rank.appendChild(doc.createTextNode(text));
            info.appendChild(rank);
            umiestnenie.getAttributes().removeNamedItem("rank");
            info.removeChild(umiestnenie);
            
            text = steam.getAttributes().getNamedItem("steam_id").getTextContent();
            
            Element steam_id = doc.createElement("steam_id");
            steam_id.appendChild(doc.createTextNode(text));
            info.appendChild(steam_id);
            steam.getAttributes().removeNamedItem("steam_id");
            info.removeChild(steam);
    	}
    	//ID_REF
    	NodeList suhrn = doc.getElementsByTagName("ref");
    	for (int i = 0; i < suhrn.getLength(); ++i) {
    		Node n = suhrn.item(i);
        	if (n.getNodeName().equals("ref")) {
        		String text = n.getAttributes().getNamedItem("id_ref").getTextContent();
        		
        		Element newNode = doc.createElement("id_ref");
        		newNode.appendChild(doc.createTextNode(text));
        		
        		n.getAttributes().removeNamedItem("id_ref");
        		n.appendChild(newNode);
        	}
        }
    	
		// zmazat elementy hlbsie ako 8 (az ako posledna uprava)
    	NodeList root = doc.getElementsByTagName("hraci");
    	for (int i = root.getLength() - 1; i >= 0; --i) {
    		//System.out.println(root.item(i).getNodeName() + " 0");
    		processDelete(root.item(i), 0);
    	}
    }
}
