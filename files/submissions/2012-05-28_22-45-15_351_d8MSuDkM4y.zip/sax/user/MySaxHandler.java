package y36xml;

import java.util.ArrayList;

import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;

public class MYSaxHandler {

    public static void main(String[] args) {

        // Cesta ke zdrojovemu XML dokumentu  
        String sourcePath = "..\\..\\data.xml";
        //String sourcePath = "C:\\Documents and Settings\\hlisp7am\\Desktop\\data.xml";

        try {
            
            // Vytvorime instanci parseru.
            XMLReader parser = XMLReaderFactory.createXMLReader();
            
            // Vytvorime vstupni proud XML dat.
            InputSource source = new InputSource(sourcePath);
            
            // Nastavime nas vlastni content handler pro obsluhu SAX udalosti.
            parser.setContentHandler(new MujContentHandler());
            
            // Zpracujeme vstupni proud XML dat.
            parser.parse(source);
            
        } catch (Exception e) {
        
            e.printStackTrace();
            
        }
        
    }
    
}

/**
 * Nas vlastni content handler pro obsluhu SAX udalosti.
 * Implementuje metody interface ContentHandler. 
 */ 
class MujContentHandler implements ContentHandler {

    // Umoznuje zacilit misto v dokumentu, kde vznikla aktualni udalost
    Locator locator;
    
    /**
     * Nastavi locator
     */     
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Premenne pre statisticke udaje
     */
    int numberOfElements;
    ArrayList<Integer> averageLengthOfElement;
    
    int numberOfAttributes;
    ArrayList<Integer> averageLengthOfAttribute;
    
    ArrayList<Integer> fanOut;
    ArrayList<Integer> fanOutFILO;
    
    ArrayList<Integer> averageLengthOfCharacters;
    int maxLengthChar;
    String maxLengthCharacters;
    
    boolean textEl;
    
    int weapons;
    int knife;
    int usp;
    int glock;
    int deagle;
    int p228;
    int dual;
    int fiveseven;
    int m3;
    int xm1014;
    int ingram;
    int stmp;
    int mp5;
    int ump45;
    int p90;
    int famas;
    int m4;
    int steyr;
    int galil;
    int ak47;
    int kreig;
    int scout;
    int awm;
    int HaK_G3;
    int SG550;
    int m249;
    int he;

    /**
     * Obsluha udalosti "zacatek dokumentu"
     */     
    public void startDocument() throws SAXException {
        numberOfElements = 0;
        averageLengthOfElement = new ArrayList<Integer>();
        numberOfAttributes = 0;
        averageLengthOfAttribute = new ArrayList<Integer>();
        fanOut = new ArrayList<Integer>();
        fanOutFILO = new ArrayList<Integer>();
        fanOutFILO.add(0);
        averageLengthOfCharacters = new ArrayList<Integer>();
        maxLengthChar = 0;
        maxLengthCharacters = "";
        textEl = false;
        weapons = 0;
        knife = 0;
        usp = 0;
        glock = 0;
        deagle = 0;
        p228 = 0;
        dual = 0;
        fiveseven = 0;
        m3 = 0;
        xm1014 = 0;
        ingram = 0;
        stmp = 0;
        mp5 = 0;
        ump45 = 0;
        p90 = 0;
        famas = 0;
        m4 = 0;
        steyr = 0;
        galil = 0;
        ak47 = 0;
        kreig = 0;
        scout = 0;
        awm = 0;
        HaK_G3 = 0;
        SG550 = 0;
        m249 = 0;
        he = 0;
        // ...
        
    }
    /**
     * Obsluha udalosti "konec dokumentu"
     */     
    public void endDocument() throws SAXException {
    	fanOut.add(fanOutFILO.remove(fanOutFILO.size() - 1)); // pridame posledny fanout spocitany
        //System.out.println(" posledny fan-out:" + fanOut.get(fanOut.size() - 1));
    	
    	
        // vypisovanie vysledku:
    	// celkovy pocet zakladnych veci (tj. komplet pocet elementov a atributov) a ich priemernu a maximalnu dlzku nazvu,
    	int averageElement = 0;
    	int maxEl = 0;
    	for (int i = 0; i < averageLengthOfElement.size(); ++i) {
    		averageElement += averageLengthOfElement.get(i);
    		if (maxEl < averageLengthOfElement.get(i)) {
    			maxEl = averageLengthOfElement.get(i);
    		}
    	}
    	double averageEl = averageElement / averageLengthOfElement.size();
    	System.out.println("celkovy pocet elementov:" + averageLengthOfElement.size());
    	System.out.println("priemerna dlzka nazvu elementov:" + averageEl);
    	System.out.println("maximalna dlzka nazvu elementov:" + maxEl);
    	
    	int averageAttribute = 0;
    	int maxAtt = 0;
    	for (int i = 0; i < averageLengthOfAttribute.size(); ++i) {
    		averageAttribute += averageLengthOfAttribute.get(i);
    		if (maxAtt < averageLengthOfAttribute.get(i)) {
    			maxAtt = averageLengthOfAttribute.get(i);
    		}
    	}
    	double averageAtt = averageAttribute / averageLengthOfAttribute.size();
    	System.out.println("celkovy pocet atributov:" + averageLengthOfAttribute.size());
    	System.out.println("priemerna dlzka nazvu atributov:" + averageAtt);
    	System.out.println("maximalna dlzka nazvu atributov:" + maxAtt);
    	
    	
    	// maximalny a priemerny fan-out,
    	int averageFanOut = 0;
    	int maxFan = 0;
    	for (int i = 0; i < fanOut.size(); ++i) {
    		averageFanOut += fanOut.get(i);
    		if (maxFan < fanOut.get(i)) {
    			maxFan = fanOut.get(i);
    		}
    	}
    	double averageFan = averageFanOut / fanOut.size();
    	System.out.println("priemerny fan-out: " + averageFanOut + " / " + fanOut.size() + " = " + averageFan);
    	System.out.println("maximalny fan-out:" + maxFan);
    	
    	
    	//pocet konkretnych elementov (tj. pocet hracov co vystrelili konkretnou zbranou - zistovanie pomocou toho ci obsahuje dany element)
    	System.out.println("Pocet hracov ktory zabili danou zbranou:");
    	System.out.println("knife:\t" + knife); //knife
        System.out.println("H&K USP .45 Tactical:\t" + usp); //usp
        System.out.println("Glock 18 Select Fire:\t" + glock); //glock
        System.out.println("Desert Eagle .50AE:\t" + deagle); //deagle
        System.out.println("Sig Sauer P-228:\t" + p228); //p-228
        System.out.println("Dual Beretta 96G Elite:\t" + dual); //dual
        System.out.println("FN Five-Seven:\t" + fiveseven); //five-seven
        System.out.println("Benelli M3 Super 90 Combat:\t" + m3); //m3
        System.out.println("Benelli/H&K M4 Super 90 XM1014:\t" + xm1014); //xm1014
        System.out.println("Ingram MAC-10:\t" + ingram); //ingram
        System.out.println("Steyr Tactical Machine Pistol:\t" + stmp); //stmp
        System.out.println("H&K MP5-Navy:\t" + mp5); //mp5
        System.out.println("H&K UMP45:\t" + ump45); //ump45
        System.out.println("FN P90:\t" + p90); //p90
        System.out.println("Fusil Automatique:\t" + famas); //famas
        System.out.println("Colt M4A1 Carbine:\t" + m4); //m4
        System.out.println("Steyr Aug:\t" + steyr); //steyr
        System.out.println("Galil:\t" + galil); //galil
        System.out.println("Kalashnikov AK-47:\t" + ak47); //ak-47
        System.out.println("Sig Sauer SG-552 Commando:\t" + kreig); //kreig
        System.out.println("Steyr Scout:\t" + scout); //scout
        System.out.println("Arctic Warfare Magnum:\t" + awm); //awm
        System.out.println("H&K G3/SG1 Sniper Rifle:\t" + HaK_G3); //HaK_G3
        System.out.println("Sig SG-550 Sniper:\t" + SG550); //SG-550
        System.out.println("M249 PARA Light Machine Gun:\t" + m249); //m249
        System.out.println("High Explosive Grenade:\t" + he); //he
    	
    	
    	//priemernu dlzku textoveho obsahu elementu, maximalnu dlzku (a aj konkretne vypisanie daneho textu)
    	int averageCharacters = 0;
    	for (int i = 0; i < averageLengthOfCharacters.size(); ++i) {
    		averageCharacters += averageLengthOfCharacters.get(i);
    	}
    	double averageChar = averageCharacters / averageLengthOfCharacters.size();
        System.out.println("priemernu dlzku textoveho obsahu elementu:" + averageChar);
        System.out.println("maximalnu dlzku textoveho obsahu elementu:" + maxLengthChar + " - \"" + maxLengthCharacters + "\"");
    }
    
    /**
     * Obsluha udalosti "zacatek elementu".
     * @param uri URI jmenneho prostoru elementu (prazdne, pokud element neni v zadnem jmennem prostoru)
     * @param localName Lokalni jmeno elementu (vzdy neprazdne)
     * @param qName Kvalifikovane jmeno (tj. prefix-uri + ':' + localName, pokud je element v nejakem jmennem prostoru, nebo localName, pokud element neni v zadnem jmennem prostoru)
     * @param atts Atributy elementu     
     */     
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
    	++numberOfElements; // pripocitame element
    	averageLengthOfElement.add(localName.length()); // zaznamename si dlzku elementu
    	//System.out.println("\"" + localName + "\" - " + localName.length() + " \"" + qName + "\" - " + qName.length());
    	fanOutFILO.set(fanOutFILO.size() - 1, fanOutFILO.get(fanOutFILO.size() - 1) + 1); // posledny zaznam zvysime o jedna
    	//System.out.println(atts.getLength());
    	for (int i = 0; i < atts.getLength(); ++i) {
    		//System.out.println("\"" + atts.getQName(i) + "\" - " + atts.getQName(i).length() + " \"" + atts.getValue(i) + "\" - " + atts.getValue(i).length());
    		++numberOfAttributes;
    		averageLengthOfAttribute.add(atts.getQName(i).length());
    	}
    	fanOutFILO.add(atts.getLength()); // pridame novy fan-out uz so spocitanym poctom attributov
    	textEl = false;
    	if (localName == "kills") {
    		switch (weapons) {
    			case 1: ++knife;
    				break;
    			case 2: ++usp;
					break;
    			case 3: ++glock;
					break;
    			case 4: ++deagle;
					break;
    			case 5: ++p228;
					break;
    			case 6: ++dual;
					break;
    			case 7: ++fiveseven;
					break;
    			case 8: ++m3;
					break;
    			case 9: ++xm1014;
					break;
    			case 10: ++ingram;
					break;
    			case 11: ++stmp;
					break;
    			case 12: ++mp5;
					break;
    			case 13: ++ump45;
					break;
    			case 14: ++p90;
					break;
    			case 15: ++famas;
					break;
    			case 16: ++m4;
					break;
    			case 17: ++steyr;
					break;
    			case 18: ++galil;
					break;
    			case 19: ++ak47;
					break;
    			case 20: ++kreig;
					break;
    			case 21: ++scout;
					break;
    			case 22: ++awm;
					break;
    			case 23: ++HaK_G3;
					break;
    			case 24: ++SG550;
					break;
    			case 25: ++m249;
					break;
    			case 26: ++he;
					break;
    		}
    		weapons = 0;
    	}
    	if (localName == "knife") {
    		weapons = 1;
    	} else if (localName == "usp") {
    		weapons = 2;
    	} else if (localName == "glock") {
    		weapons = 3;
    	} else if (localName == "deagle") {
    		weapons = 4;
    	} else if (localName == "p-228") {
    		weapons = 5;
    	} else if (localName == "dual") {
    		weapons = 6;
    	} else if (localName == "five-seven") {
    		weapons = 7;
    	} else if (localName == "m3") {
    		weapons = 8;
    	} else if (localName == "xm1014") {
    		weapons = 9;
    	} else if (localName == "ingram") {
    		weapons = 10;
    	} else if (localName == "stmp") {
    		weapons = 11;
    	} else if (localName == "mp5") {
    		weapons = 12;
    	} else if (localName == "ump45") {
    		weapons = 13;
    	} else if (localName == "p90") {
    		weapons = 14;
    	} else if (localName == "famas") {
    		weapons = 15;
    	} else if (localName == "m4") {
    		weapons = 16;
    	} else if (localName == "steyr") {
    		weapons = 17;
    	} else if (localName == "galil") {
    		weapons = 18;
    	} else if (localName == "ak-47") {
    		weapons = 19;
    	} else if (localName == "kreig") {
    		weapons = 20;
    	} else if (localName == "scout") {
    		weapons = 21;
    	} else if (localName == "awm") {
    		weapons = 22;
    	} else if (localName == "HaK_G3") {
    		weapons = 23;
    	} else if (localName == "SG-550") {
    		weapons = 24;
    	} else if (localName == "m249") {
    		weapons = 25;
    	} else if (localName == "he") {
    		weapons = 26;
    	} else {
    		weapons = 0;
    	}
    	
        // ...

    }
    /**
     * Obsluha udalosti "konec elementu"
     * Parametry maji stejny vyznam jako u @see startElement     
     */     
    public void endElement(String uri, String localName, String qName) throws SAXException {
    	if (textEl){
    		fanOutFILO.set(fanOutFILO.size() - 1, fanOutFILO.get(fanOutFILO.size() - 1) + 1); // posledny zaznam ma textovy podelement
    		textEl = false;
    	}
    	fanOut.add(fanOutFILO.remove(fanOutFILO.size() - 1));
        // ...

    }
    
    /**
     * Obsluha udalosti "znakova data".
     * SAX parser mule znakova data davkovat jak chce. Nelze tedy pocitat s tim, ze je cely text dorucen v ramci jednoho volani.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakovymi daty
     * @param start Index zacatku useku platnych znakovych dat v poli.
     * @param length Delka useku platnych znakovych dat v poli.
     */               
    public void characters(char[] ch, int start, int length) throws SAXException {
    	textEl = true; // textovy element je vacsinou list - nie je to uplne presne ale blizi sa to realite
    	if (maxLengthChar < length) {
    		maxLengthChar = length;
    		maxLengthCharacters = String.copyValueOf(ch, start, length);
    	}
    	averageLengthOfCharacters.add(length);
        // ...
        
    }
    
    /**
     * Obsluha udalosti "deklarace jmenneho prostoru".
     * @param prefix Prefix prirazeny jmennemu prostoru.
     * @param uri URI jmenneho prostoru.
     */     
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha udalosti "konec platnosti deklarace jmenneho prostoru".
     */     
    public void endPrefixMapping(String prefix) throws SAXException {
    
        // ...
    
    }

    /**
     * Obsluha udalosti "ignorovane bile znaky".
     * Stejne chovani a parametry jako @see characters     
     */     
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha udalosti "instrukce pro zpracovani".
     */         
    public void processingInstruction(String target, String data) throws SAXException {
      
      // ...
            
    }

    /**
     * Obsluha udalosti "nezpracovana entita"
     */         
    public void skippedEntity(String name) throws SAXException {
    
      // ...
    
    }
}