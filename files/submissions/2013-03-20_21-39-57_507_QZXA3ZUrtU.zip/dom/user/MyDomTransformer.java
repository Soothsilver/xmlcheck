package user;

import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * ASSIGNMENT: Update document to be able to transform input XML document to
 * output document by actions mentioned in comments of processTree method.
 */
public class MyDomTransformer {

    public void transform(Document doc) {
    	createWaypoint(doc);
    	removeAllEastwardWaypoints(doc);
    }

	private void removeAllEastwardWaypoints(Document doc) {
		NodeList elementsByTagName = doc.getElementsByTagName("route");
		if (elementsByTagName.getLength() == 0)
			return;
		Node rootNode = elementsByTagName.item(0);
		NodeList wayPoints = rootNode.getChildNodes();
		List<Node> wpToRemove = new ArrayList<Node>();
		for (int i = 0; i < wayPoints.getLength(); i++) {
			Node wp = wayPoints.item(i);
			if (!"wpt".equals(wp.getNodeName()))
				continue;
			NamedNodeMap attributes = wp.getAttributes();				
			Node dir = attributes.getNamedItem("direction");
			if (dir == null)
				continue;
			
			String dirStr = dir.getNodeValue().trim();
			if ("e".equals(dirStr))
				wpToRemove.add(wp);
		}
		
		for (Node node : wpToRemove) {
			rootNode.removeChild(node);			
		}
	}

	private void createWaypoint(Document doc) {
		NodeList elementsByTagName = doc.getElementsByTagName("route");
		if (elementsByTagName.getLength() == 0)
			return;
		Node rootNode = elementsByTagName.item(0);
		Element newChild = doc.createElement("wpt");
		newChild.setAttribute("id", "w10000");
		Element coord = doc.createElement("coord");
		Element lon = doc.createElement("lon");
		lon.setTextContent(generRandCoord());
		Element lat = doc.createElement("lat");
		lat.setTextContent(generRandCoord());
		coord.appendChild(lon);
		coord.appendChild(lat);
		newChild.appendChild(coord);
		Element info = doc.createElement("info");
		info.appendChild(doc.createElement("title")).setTextContent("Randomly generated waypoint.");
		info.appendChild(doc.createElement("text")).setTextContent("Truly pseudorandom coordinates. I wonder where we are.");
		newChild.appendChild(info );
		rootNode.appendChild(newChild);
		
	}

	private static String generRandCoord() {
		return (int)(Math.random() * 180) + "&dg;" + (int)(Math.random() * 60) + "'" + (int)(Math.random() * 100) + "\"";
	}
}
