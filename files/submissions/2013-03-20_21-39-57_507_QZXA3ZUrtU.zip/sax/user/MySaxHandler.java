package user;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Main class for SAX parsing
 *
 * @author XML Technologies
 */
public class MySaxHandler extends DefaultHandler {

    // Helper variable to store location of the handled event
    Locator locator;
    
    // THESE THREE VARIABLES CONTAIN RETRIEVED VALUES AT THE END OF PARSING THE DOCUMENT
    String mostCommonWaypointDirection; //attribute
    String longestQuestionOfATask;  // content
    int countWaypointsWithNoTask; // context
    
    //HELPER VARIABLES
    Map<String, Integer> wptDirectionsCount = new HashMap<String, Integer>();
    String currentQueestionOfATask = "";
    boolean hasTask = false;
    boolean inWpt = false;
    boolean inTask = false;
    boolean inTaskTitle = false;

    /**
     * Sets the locator
     *
     * @param Locator locator location in the file
     */
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
    	int max = -1;    	
    	for (Entry<String, Integer> entry : wptDirectionsCount.entrySet()) {
			if (entry.getValue() > max)
			{
				max = entry.getValue();
				mostCommonWaypointDirection = entry.getKey();
			}
		}
    	
    	System.out.println(mostCommonWaypointDirection);
    	System.out.println(longestQuestionOfATask);
    	System.out.println(countWaypointsWithNoTask);
    }

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
    	if ("wpt".equals(localName))
    	{
    		inWpt = true;
    		hasTask = false;
    		
    		String dir = atts.getValue("direction");
    		Integer dirCount = wptDirectionsCount.get(dir);
    		if (dirCount == null)
    		{
    			dirCount = 0;
    		}
    		wptDirectionsCount.put(dir, dirCount + 1);
    	} 
    	else if ("task".equals(localName))
    	{
    		inTask = true;
    		if (inWpt)
    			hasTask = true;
    	}
    	else if ("title".equals(localName) && inTask)
    	{
    		inTaskTitle = true;
    		currentQueestionOfATask = "";
    	}
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
    	if ("wpt".equals(localName))
    	{
    		inWpt = false;
    		if (!hasTask)
    			countWaypointsWithNoTask++;
    	} 
    	else if ("task".equals(localName))
    	{
    		inTask = false;
    	}
    	else if ("title".equals(localName) && inTask)
    	{
    		inTaskTitle = false;
    		if (longestQuestionOfATask == null || longestQuestionOfATask.length() < currentQueestionOfATask.length())
    			longestQuestionOfATask = currentQueestionOfATask;
    	}
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
    	if (inTaskTitle)
    	{
    		char[] subArray = Arrays.copyOfRange(chars, start, start + length);
			currentQueestionOfATask += new String(subArray);
    	}
    }

}
