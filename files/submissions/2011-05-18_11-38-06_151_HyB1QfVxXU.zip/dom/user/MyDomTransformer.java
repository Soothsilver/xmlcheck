/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author tchap
 * 
 * Transformation is:
 * There is info and description element under the game element.
 * All we do is to drop description element and bring all elements under
 * the info element one level up.
 */
public class MyDomTransformer {
    
    public void transform(Document xmlDocument) {
        Element catalogue = (Element)xmlDocument.getFirstChild();
        Element games = (Element)catalogue.getElementsByTagName("games").item(0);
        
        NodeList gameList = games.getElementsByTagName("game");
       
        for (int i = 0; i < gameList.getLength(); ++i) {
            processGame((Element)gameList.item(i));
        }
    }

    private void processGame(Element game) {
        Element infoElement;
        Element descriptionElement;
        
        infoElement = (Element)game.getElementsByTagName("info").item(0);
        descriptionElement = (Element)game.getElementsByTagName("description").item(0);
        
        game.removeChild(descriptionElement);
        
        for (Node curInfo = infoElement.getFirstChild(); 
                curInfo != null; 
                curInfo = curInfo.getNextSibling()) {
        
            game.appendChild(curInfo.cloneNode(true));
        }
        
        game.removeChild(infoElement);
    }
}
