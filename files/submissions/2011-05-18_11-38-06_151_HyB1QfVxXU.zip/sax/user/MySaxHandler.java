/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * @author tchap
 * 
 * Count various statistics like number of games and publishers,
 * average number of expansions one game has, date of first and last game published...
 */
public class MySaxHandler extends DefaultHandler {
    
    private int nPublishers;
    private int nGames;
    private int expansionsSum;
    private int firstGame = 0;
    private String firstGamePublisher;
    private int lastGame = 0;
    private String lastGamePublisher;
  
    @Override
    public void endDocument() throws SAXException {
        
        System.out.println("Statistics are here!");        
        System.out.println("-------------------------------------------------");
        System.out.println("Number of game publishers: " + nPublishers);
        System.out.println("Number of games published: " + nGames);
        System.out.println("-------------------------------------------------");
        System.out.println("First game published in: " + firstGame + " (" + firstGamePublisher + ")");
        System.out.println("Last game published in: " + lastGame + " (" + lastGamePublisher + ")");
        System.out.println("-------------------------------------------------");
        System.out.println("Average number of expansions per game: " + new Double(expansionsSum / nGames).toString());
        System.out.println("-------------------------------------------------");
        System.out.println("Tradidadidaa, that's it!");
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if (localName.equals("publisher")) {
            nPublishers += 1;
        }
        else if (localName.equals("game")) {
            nGames += 1;
        }
        else if (localName.equals("published_by")) {
            int year = Integer.parseInt(atts.getValue("year"));
            String publisher = atts.getValue("pref");
            
            if (firstGame == 0 || year < firstGame) {
                firstGame = year;
                firstGamePublisher = publisher;
            }
            
            if (lastGame == 0 || year > lastGame) {
                lastGame = year;
                lastGamePublisher = publisher;
            }
            
        }
        else if (localName.equals("expansion")) {
            expansionsSum += 1;
        }
    }    
}
