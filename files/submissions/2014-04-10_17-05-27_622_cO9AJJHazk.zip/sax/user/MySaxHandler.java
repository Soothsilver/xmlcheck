package user;

import java.util.TreeSet;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
    private enum Strana {
        Rise_Alexis, Federativni_spolek, common;
    }
    private enum Jednotka {
        Vojak, Stroj, Stihacka, Lod, undefined;
    }
    private Locator locator;
    private Strana strana;
    private Boolean vjednotce;
    // prumerna udrzba jednotek, podle stran
    public double udrzbaAlexis;
    public double udrzbaSpolek;
    private double udrzba;
    private int pocetAlexis;
    private int pocetSpolek;    
    private Boolean vudrzbe;
    
    // pocty typu jednotek, podle stran
    public int vojakAlexis;
    public int vojakSpolek;
    public int strojAlexis;
    public int strojSpolek;
    public int stihackaAlexis;
    public int stihackaSpolek;
    public int lodAlexis;
    public int lodSpolek;
    private Jednotka jednotka;
    
    // zbrane pouzivane lodemi Rise Alexis
    public TreeSet<String> zbrane;
    private TreeSet<Integer> idzbrani;
    private TreeSet<Integer> tmpzbrane;
    private Boolean vezbrani;
    private Boolean ctijmeno;
    
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    @Override
    public void startDocument() throws SAXException {
        this.strana = Strana.common;
        this.vjednotce = false;
        this.udrzba = 0;
        this.udrzbaAlexis = 0;
        this.pocetAlexis = 0;
        this.udrzbaSpolek = 0;
        this.pocetSpolek = 0;
        this.vudrzbe = false;
        
        this.vojakAlexis = 0;
        this.vojakSpolek = 0;
        this.strojAlexis = 0;
        this.strojSpolek = 0;
        this.stihackaAlexis = 0;
        this.stihackaSpolek = 0;
        this.lodAlexis = 0;
        this.lodSpolek = 0;
        this.jednotka = Jednotka.undefined;
        
        this.zbrane = new TreeSet<String>();
        this.idzbrani = new TreeSet<Integer>();
        this.tmpzbrane = new TreeSet<Integer>();
        this.vezbrani = false;
        this.ctijmeno = false;
    }

    @Override
    public void endDocument() throws SAXException {
        System.out.print("Prumerna udrzba jednotek Rise Alexis je: ");
        System.out.print(this.udrzbaAlexis / this.pocetAlexis);
        System.out.println();
        
        System.out.print("Prumerna udrzba jednotek Federativniho spolku je: ");
        System.out.print(this.udrzbaSpolek / this.pocetSpolek);
        System.out.println();
        System.out.println();
        
        System.out.println("Pocty typu jednotek Rise Alexis: ");
        System.out.print("Vojaci " + this.vojakAlexis + ",\t");
        System.out.print("Stroje " + this.strojAlexis + ",\t");
        System.out.print("Stihacky " + this.stihackaAlexis + ",\t");
        System.out.print("Lode " + this.lodAlexis + '\n');
        
        System.out.println("Pocty typu jednotek Federativniho spolku: ");
        System.out.print("Vojaci " + this.vojakSpolek + ",\t");
        System.out.print("Stroje " + this.strojSpolek + ",\t");
        System.out.print("Stihacky " + this.stihackaSpolek + ",\t");
        System.out.print("Lode " + this.lodSpolek + '\n');
        
        System.out.println();
        System.out.println("Zbrane pouzivane lodemi Federativniho spolku:");
        for(String zbran : this.zbrane) System.out.println(zbran);
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if(localName.equals("military_unit")) this.vjednotce = true;
        else if(localName.equals("fation") && this.vjednotce) {
            if(atts.getValue("faction").equals("Rise_Alexis")) this.strana = Strana.Rise_Alexis;
            else if(atts.getValue("faction").equals("Federativni_spolek")) this.strana = Strana.Federativni_spolek;
            else this.strana = Strana.common;
        }
        else if(localName.equals("unit_type") && this.vjednotce) {
            if(atts.getValue("type").equals("troop")) this.jednotka = Jednotka.Vojak;
            else if(atts.getValue("type").equals("car")) this.jednotka = Jednotka.Stroj;
            else if(atts.getValue("type").equals("fighter")) this.jednotka = Jednotka.Stihacka;
            else if(atts.getValue("type").equals("ship")) this.jednotka = Jednotka.Lod;
            else this.jednotka = Jednotka.undefined;
        }
        else if(localName.equals("upkeep") && this.vjednotce) this.vudrzbe = true;
        else if(localName.equals("unit_equipment") && this.vjednotce) {
            try { this.tmpzbrane.add(Integer.parseInt(atts.getValue("id").substring(2))); }
            catch (NumberFormatException ex) {}
        }
        else if(localName.equals("military_equipment")) {
            try {
                if(this.idzbrani.contains(Integer.parseInt(atts.getValue("id").substring(2))))
                this.vezbrani = true;
            } catch (NumberFormatException ex) {}
        }
        else if(localName.equals("name") && this.vezbrani) this.ctijmeno = true;
        /**
        switch(localName) {
            case "military_unit":
                this.vjednotce = true;
                break;
            case "faction":
                if(this.vjednotce) {
                    if(atts.getValue("faction").equals("Rise_Alexis")) this.strana = Strana.Rise_Alexis;
                    else if(atts.getValue("faction").equals("Federativni_spolek")) this.strana = Strana.Federativni_spolek;
                    else this.strana = Strana.common;
                    switch (atts.getValue("faction")) {
                        case "Rise_Alexis": this.strana = Strana.Rise_Alexis; break;
                        case "Federativni_spolek": this.strana = Strana.Federativni_spolek; break;
                        default: this.strana = Strana.common;
                    }
                }
                break;
            case "unit_type":
                if(this.vjednotce) {
                    switch(atts.getValue("type")) {
                        case "troop": this.jednotka = Jednotka.Vojak; break;
                        case "car": this.jednotka = Jednotka.Stroj; break;
                        case "fighter": this.jednotka = Jednotka.Stihacka; break;
                        case "ship": this.jednotka = Jednotka.Lod; break;
                        default: this.jednotka = Jednotka.undefined;
                    }
                }
            case "upkeep":
                if(this.vjednotce) this.vudrzbe = true;
                break;
            case "unit_equipment":
                if(this.vjednotce) {
                    try { this.tmpzbrane.add(Integer.parseInt(atts.getValue("id").substring(2))); }
                    catch (NumberFormatException ex) {}
                } break;
            case "military_equipment":
                try {
                    if(this.idzbrani.contains(Integer.parseInt(atts.getValue("id").substring(2))))
                    this.vezbrani = true;
                } catch (NumberFormatException ex) {}
                break;
            case "name":
                if(this.vezbrani) this.ctijmeno = true;
                break;
        }
        /**/
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if(localName.equals("military_unit")) {
            switch(this.strana) {
                case Rise_Alexis: 
                    this.pocetAlexis++;
                    this.udrzbaAlexis += this.udrzba;
                    switch(this.jednotka) {
                        case Vojak: this.vojakAlexis++; break;
                        case Stroj: this.strojAlexis++; break;
                        case Stihacka: this.stihackaAlexis++; break;
                        case Lod: this.lodAlexis++; break;
                    } break;
                case Federativni_spolek: 
                    this.pocetSpolek++;
                    this.udrzbaSpolek += this.udrzba;
                    switch(this.jednotka) {
                        case Vojak: this.vojakSpolek++; break;
                        case Stroj: this.strojSpolek++; break;
                        case Stihacka: this.stihackaSpolek++; break;
                        case Lod: this.lodSpolek++; this.idzbrani.addAll(this.tmpzbrane); break;
                    } break;
            }
            this.vjednotce = false;
            this.strana = Strana.common;
            this.jednotka = Jednotka.undefined;
            this.tmpzbrane = new TreeSet<Integer>();
        } 
        else if(localName.equals("upkeep")) this.vudrzbe = false;
        else if(localName.equals("military_equipment")) this.vezbrani = false;
        else if(localName.equals("name")) this.ctijmeno = false;
        /**
        switch(localName) {
            case "military_unit":
                switch(this.strana) {
                    case Rise_Alexis: 
                        this.pocetAlexis++;
                        this.udrzbaAlexis += this.udrzba;
                        switch(this.jednotka) {
                            case Vojak: this.vojakAlexis++; break;
                            case Stroj: this.strojAlexis++; break;
                            case Stihacka: this.stihackaAlexis++; break;
                            case Lod: this.lodAlexis++; break;
                        } break;
                    case Federativni_spolek: 
                        this.pocetSpolek++;
                        this.udrzbaSpolek += this.udrzba;
                        switch(this.jednotka) {
                            case Vojak: this.vojakSpolek++; break;
                            case Stroj: this.strojSpolek++; break;
                            case Stihacka: this.stihackaSpolek++; break;
                            case Lod: this.lodSpolek++; this.idzbrani.addAll(this.tmpzbrane); break;
                        } break;
                }
                this.vjednotce = false;
                this.strana = Strana.common;
                this.jednotka = Jednotka.undefined;
                this.tmpzbrane = new TreeSet<Integer>();
                break;
            case "upkeep": this.vudrzbe = false; break;
            case "military_equipment": this.vezbrani = false; break;
            case "name": this.ctijmeno = false; break;
        }
        /**/
    }

    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        if(this.vudrzbe) {
            try {
                this.udrzba = Double.parseDouble(
                        new String(chars).substring(start, start+length).replaceAll("[\\s\u00A0]", ""));
                // \u00A0 je nezalamovaci mezere a musi byt jmenovana, protoze je chapana jako nebily znak
            } catch (NumberFormatException ex) {
                this.udrzba = 0;
            }
        }
        if(this.ctijmeno) {
            try {
                this.zbrane.add(new String(chars).substring(start, start+length));
            } catch (NullPointerException ex) {}
        }
    }

    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
        // ...
    }

    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

    @Override
    public void skippedEntity(String name) throws SAXException {
        // ...
    }
}
