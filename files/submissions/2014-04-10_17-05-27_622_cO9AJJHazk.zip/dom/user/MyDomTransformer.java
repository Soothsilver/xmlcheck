package user;

import org.w3c.dom.*;

public class MyDomTransformer {
    public void transform(Document doc) {
        Element root = doc.getDocumentElement();
        
        // Smaz�n� nulov�ch cen jednotek
        NodeList listofprices = root.getElementsByTagName("price");
        for (int i = 0; i < listofprices.getLength(); i++) {
            Node pricenode = listofprices.item(i);
            NodeList prices = pricenode.getChildNodes();
            for (int j = prices.getLength() - 1; j >= 0 ; j--) {
                Node price = prices.item(j);
                if(price.getTextContent().equals("0")) pricenode.removeChild(price);
            }
        }
        /**
        // Explicitn� nastaven� �rovn� u pr�myslu, kde je vyu�ita implicitn� hodnota 0
        NodeList listofrequirements = root.getElementsByTagName("requirements");
        for (int i = 0; i < listofrequirements.getLength(); i++) {
            Node requirementnode = listofrequirements.item(i);
            NodeList listofindustries = requirementnode.getChildNodes();
            for (int j = 0; j < listofindustries.getLength(); j++) {
                Element industry = (Element)listofindustries.item(j);
                if(industry.getAttribute("level").equals("")) industry.setAttribute("level", "0");
            }
        }
        /**/
        
        // Smaz�n� nulov�ch n�kladov�ch kapacit
        NodeList listofcargohold = root.getElementsByTagName("cargo");
        for (int i = 0; i < listofcargohold.getLength(); i++) {
            Node cargohold = listofcargohold.item(i);
            NodeList listofcargo = cargohold.getChildNodes();
            for (int j = listofcargo.getLength() - 1; j >= 0; j--) {
                Node cargo = listofcargo.item(j);
                if(cargo.getTextContent().equals("0")) cargohold.removeChild(cargo);
            }
        }
    }
}
