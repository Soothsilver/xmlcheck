package sax;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.CharacterData;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


// Prevod ciselnych elementu (ciselny element = neobsahuje podelementy, 
// a obsahuje pouze cele cislo s libovolnym poctem bilych znaku 
// na konci nebo zacatku) na atributy a prevod textovych atributu 
// (textovy atribut = neobsahuje pouze cele cislo) na elementy
public class MyDomTransformer {
	public static void main(String[] args){
		try{
	        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
	
	        dbf.setValidating(false);
	
	        DocumentBuilder builder = dbf.newDocumentBuilder();
	
	        Document doc = builder.parse("library.xml");
	        
	        MyDomTransformer trans = new MyDomTransformer();
	        trans.transform(doc);
	        
	        //TransformerFactory vytv��� serializ�tory DOM strom�
            TransformerFactory tf = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer = tf.newTransformer();

            //nastav�me kodov�n�
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spust�me transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(new File("library_out.xml")));
		} catch(IOException e){
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (TransformerException e) {
			e.printStackTrace();
		}
	}
	public void transform(Document xmlDocument){
        processElement(xmlDocument.getDocumentElement(),xmlDocument);
	}
	private void processElement(Element elem,Document doc){
		// Pokud ma element atributy, zpracujeme je
		if(elem.getAttributes() != null)
			processAttributes(elem.getAttributes(),doc);
		
		// Projdeme vsechny syny a vyfiltrujeme ty, co nejsou elementy
		// a do stringu content ulozime obsah vsech textovych uzlu
		NodeList children = elem.getChildNodes();
		String content = "";
		// Pocet vsech 'dcerinych' elementu (genderova politika je neuprosna, byla by
		// to diskriminace zen ;-))
		int elements_c = 0;
		for (int i = 0; i < children.getLength(); i++) {
			Node node = children.item(i);
			if(node instanceof Element){
				// Pokud je synem element, volame rekurzivne stejnou metodu
				processElement((Element)node,doc);
				elements_c++;
			} else if(node.getNodeType() == Node.TEXT_NODE){
				// Pridavame textovy obsah do content, bude se hodit, pri zmene na atribut
				content += ((CharacterData) node).getData();
			}
		}
		// Pokud nemel element zadne podelementy a zaroven je obsah oriznuty o koncove
		// bile znaky cislem, prevedem na atribut
		if(elements_c == 0 && isInt(content.trim())){
			// Ziskame parenta a vytvorime novy atribut v documentu se stejnym 
			// nazvem jako ma element, co bude smazan 
			Node parent = elem.getParentNode();
			Node newN = doc.createAttribute(elem.getTagName());
			// Nastavime hodnotu atributu na obsah elementu oriznuty o koncove bile znaky
			newN.setNodeValue(content.trim());
			// Pridame do rodice novy atribut a nakonec smazem zpracovavany element z rodice
			parent.getAttributes().setNamedItem(newN);
			parent.removeChild(elem);
		}
	}
	private void processAttributes(NamedNodeMap attrs,Document doc){
		for (int i = 0; i < attrs.getLength(); i++) {
			// Projdeme vsechny atributy
			Attr node = (Attr)attrs.item(i);
			// Pokud je atribut neciselny prevedeme ho na element, ktery je
			// pod vlastnikem atributu (parent)
			Node parent = node.getOwnerElement();
			if(!isInt(node.getNodeValue())){
				// Vytvorime novy element s jmenem puvodniho atributu
				// a uzel s hodnotou puvodniho atributu
				Node newN = doc.createElement(node.getNodeName());
				Node charN = doc.createTextNode(node.getValue());
				// Pridame novy element pod uzel, ktery vlastnil puvodni atribut
				parent.appendChild(newN);
				// Jako syna noveho elementu pridame textovy uzel s hodnotou
				newN.appendChild(charN);
				// Smazeme atribut
				parent.getAttributes().removeNamedItem(node.getNodeName());
				// Dekrementujeme i, protoze na pozici smazaneho zaznamu
				// se posunul dalsi a je treba kompenzovat inkrementaci
				--i;
			}
		}
	}
	// Test ciselnosti naparsovanim Integeru
	private boolean isInt(String arg){
		try{
			Integer.parseInt(arg);
			return true;
		}catch(NumberFormatException e){
			return false;
		}
	}
}
