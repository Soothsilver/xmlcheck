/*
Provedene transformace:
- prejmenovani korenoveho elementu
- smazani elementu objednavka
- vytvoreni elementu zakaznici, vyrobky
- prevedeni atributu xsi:type na element type, jako podelement elementu osoba
- prevedeni elementu datum_zadani na atribut datum v elementu novy_vyrobek
 */
package user;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Node;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

/**
 *
 * @author petr
 */
public class MyDomTransformer {

    private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "vystup.xml";

    public static void main(String[] args) {

        try {

            //DocumentBuilderFactory vytvari DOM parsery
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            //nebudeme validovat
            dbf.setValidating(false);

            //vytvorime si DOM parser
            DocumentBuilder builder = dbf.newDocumentBuilder();

            //parser zpracuje vstupni soubor a vytvori z nej strom DOM objektů
            Document doc = builder.parse(VSTUPNI_SOUBOR);

            //zpracujeme DOM strom
            transform(doc);

            //TransformerFactory vytvari serializatory DOM stromů
            TransformerFactory tf = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer = tf.newTransformer();

            //nastavime kodovani
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spustime transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


        } catch (Exception e) {

            System.out.println("chyba");

        }
    }

    /**
     * Zpracuje DOM strom
     */
    
    public static void transform(Document doc) {
        // vytvoreni noveho korenoveho elementu
        Element root = doc.getDocumentElement();

        NodeList objednavky = root.getElementsByTagName("objednavka");
        NodeList zakaznik = root.getElementsByTagName("zakaznik");
        NodeList vyrobek = root.getElementsByTagName("vyrobek");
        NodeList osoba = root.getElementsByTagName("osoba");
        
        Node zakaznici = doc.createElement("zakaznici");
        Node vyrobky = doc.createElement("vyrobky");

        

        for (int i = 0; i < osoba.getLength(); i++) {
            Element e = (Element) osoba.item(i);
            Node n = doc.createElement("type");
            n.setTextContent(e.getAttribute("xsi:type"));
            e.appendChild(n);
            e.removeAttribute("xsi:type");
        }

        for (int i = 0; i < zakaznik.getLength(); i++) {
            zakaznici.appendChild(zakaznik.item(i));
        }

        for (int i = 0; i < vyrobek.getLength(); i++) {
            vyrobky.appendChild(vyrobek.item(i));
        }


        root.appendChild(zakaznici);
        root.appendChild(vyrobky);

        for (int i = vyrobek.getLength() - 1; i >= 0; i--) {
            Node novy_vyrobek = vyrobek.item(i).getFirstChild();
            while(novy_vyrobek.getNodeName().equals("#text")) novy_vyrobek = novy_vyrobek.getNextSibling();
            Node datum_zadani = novy_vyrobek.getLastChild();
            while(datum_zadani.getNodeName().equals("#text")) datum_zadani = datum_zadani.getPreviousSibling();
            if(!datum_zadani.getNodeName().equals("datum_zadani")) datum_zadani = datum_zadani.getPreviousSibling();
            Element novy_vyr = (Element) novy_vyrobek;
            novy_vyr.setAttribute("datum", datum_zadani.getTextContent());
            novy_vyrobek.removeChild(datum_zadani);
        }
        
        for (int i = objednavky.getLength() - 1; i >= 0; i--) {
            root.removeChild(objednavky.item(i)); // smazani vsech elementů objednavka
        }

        doc.renameNode(root, "", "zakaznici");
    }
}
