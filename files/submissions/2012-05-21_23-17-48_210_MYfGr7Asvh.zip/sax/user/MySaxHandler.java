/*
 Trida MySaxHandler pocita 
 * pocet atributu, 
 * celkovou delku atributu, 
 * prumernou delku atributu,
 * nejcasteji vyskutujici se atribut a jeho pocet, 
 * atribut s nejdelsim nazvem
 * pocet elementu,
 * delku elementu,
 * prumernou delku elementu,
 * nejcasteji vyskutujici se element a jeho pocet,
 * element s nejdelsim nazvem,
 * pocet elementu s atributy,
 * pocet elementu bez atributu.
 */
package user;

import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 *
 * @author petr
 */
class SAX_podpora {

    public static void main(String[] args) {

        // Cesta ke zdrojovemu XML dokumentu  
        String sourcePath = "cviceni_8_xslt.xml";

        try {

            // Vytvorime instanci parseru.
            XMLReader parser = XMLReaderFactory.createXMLReader();

            // Vytvorime vstupni proud XML dat.
            InputSource source = new InputSource(sourcePath);
            // Nastavime nas vlastni content handler pro obsluhu SAX udalosti.
            parser.setContentHandler(new MySaxHandler());

            // Zpracujeme vstupni proud XML dat.
            parser.parse(source);

        } catch (Exception e) {
        }

    }
}

/**
 * Nas vlastni content handler pro obsluhu SAX udalosti. Implementuje metody
 * interface ContentHandler.
 */
public class MySaxHandler extends DefaultHandler implements ContentHandler{

    // Umoznuje zacilit misto v dokumentu, kde vznikla aktualni udalost
    Locator locator;
    Map<String, Integer> mapaElementu, mapaAtributu;
    int delkaElementu = 0;
    int delkaAtributu = 0;
    int pocetElementuBezAtributu = 0;
    int pocetElementuSAtributy = 0;
    int pocetElementu = 0;

    /**
     * Nastavi locator
     */
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Obsluha udalosti "zacatek dokumentu"
     */
    @Override
    public void startDocument() throws SAXException {
        mapaElementu = new HashMap<String, Integer>();
        mapaAtributu = new HashMap<String, Integer>();
    }

    /**
     * Obsluha udalosti "konec dokumentu"
     */
    @Override
    public void endDocument() throws SAXException {
        StringTokenizer elem = new StringTokenizer(mapaElementu.toString(), "{} ,=");
        String nejcastejsiElement = null;
        String nejdelsiElement = "";
        int cetnost = Integer.MIN_VALUE;
        while (elem.hasMoreTokens()) {
            String nazev = elem.nextToken();
            int cislo = Integer.parseInt(elem.nextToken());
            delkaElementu += nazev.length();
            if (cislo > cetnost) {
                cetnost = cislo;
                nejcastejsiElement = nazev;
            }
            if (nejdelsiElement.length() < nazev.length()) {
                nejdelsiElement = nazev;
            }
        }
        elem = new StringTokenizer(mapaAtributu.toString(), "{} ,=");
        String nejcastejsiAtribut = null;
        String nejdelsiAtribut = "";
        int cetnostAtributu = Integer.MIN_VALUE;
        while (elem.hasMoreTokens()) {
            String nazev = elem.nextToken();
            int cislo = Integer.parseInt(elem.nextToken());
            delkaAtributu += nazev.length();
            if (cislo > cetnostAtributu) {
                cetnostAtributu = cislo;
                nejcastejsiAtribut = nazev;
            }
            if (nejdelsiAtribut.length() < nazev.length()) {
                nejdelsiAtribut = nazev;
            }
        }

        System.out.println("***************** ATRIBUTY ***************");
        System.out.println("pocet atributu je: " + mapaAtributu.size());
        System.out.println("delka atriarr.lengthbutu je: " + delkaAtributu);
        System.out.println("prumerna delka atributu je: " + (double) delkaAtributu / mapaAtributu.size());
        System.out.println("nejcasteji vyskutujici se atribut je \"" + nejcastejsiAtribut + "\", vyskytujici se " + cetnostAtributu + "-krat.");
        System.out.println("atribut s nejdelsim nazvem je: " + nejdelsiAtribut);
        System.out.println("\n***************** ELEMENTY ***************");
        System.out.println("pocet elementu je: " + mapaElementu.size());
        System.out.println("delka elementu je: " + delkaElementu);
        System.out.println("prumerna delka elementu je: " + (double) delkaElementu / mapaElementu.size());
        System.out.println("nejcasteji vyskutujici se element je \"" + nejcastejsiElement + "\", vyskytujici se " + cetnost + "-krat.");
        System.out.println("element s nejdelsim nazvem je: " + nejdelsiElement);
        System.out.println("pocet elementu s atributy: " + pocetElementuSAtributy);
        System.out.println("pocet elementu bez atributu: " + pocetElementuBezAtributu);
    }

    /**
     * Obsluha udalosti "zacatek elementu".
     *
     * @param uri URI jmenneho prostoru elementu (prazdne, pokud element neni v
     * zadnem jmennem prostoru)
     * @param localName Lokalni jmeno elementu (vzdy neprazdne)
     * @param qName Kvalifikovane jmeno (tj. prefix-uri + ':' + localName, pokud
     * je element v nejakem jmennem prostoru, nebo localName, pokud element neni
     * v zadnem jmennem prostoru)
     * @param atts Atributy elementu
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if (atts.getLength() == 0) {
            pocetElementuBezAtributu++;
        }
        if (atts.getLength() != 0) {
            pocetElementuSAtributy++;
        }
        pocetElementu++;
        // *********************** Pocitani atributu *********************
        for (int i = 0; i < atts.getLength(); i++) {
            int pocet = 1;
            if (mapaAtributu.containsKey(atts.getQName(i))) {
                pocet = mapaAtributu.get(atts.getQName(i));
                mapaAtributu.remove(atts.getQName(i));
                pocet++;
            }
            mapaAtributu.put(atts.getQName(i), pocet);
        }

        // *********************** Pocitani elementu *********************        
        int pocet = 1;
        if (mapaElementu.containsKey(localName)) {
            pocet = mapaElementu.get(localName);
            mapaElementu.remove(localName);
            pocet++;
        }
        mapaElementu.put(localName, pocet);
    }

    /**
     * Obsluha udalosti "konec elementu" Parametry maji stejny vyznam jako u
     *
     * @see startElement
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
    }

    /**
     * Obsluha udalosti "znakova data". SAX parser muze znakova data davkovat
     * jak chce. Nelze tedy pocitat s tim, ze je cely text dorucen v ramci
     * jednoho volani. Text je v poli (ch) na pozicich (start) az
     * (start+length-1).
     *
     * @param ch Pole se znakovymi daty
     * @param start Index zacatku useku platnych znakovych dat v poli.
     * @param length Delka useku platnych znakovych dat v poli.
     */
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
    }

    /**
     * Obsluha udalosti "deklarace jmenneho prostoru".
     *
     * @param prefix Prefix prirazeny jmennemu prostoru.
     * @param uri URI jmenneho prostoru.
     */
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    /**
     * Obsluha udalosti "konec platnosti deklarace jmenneho prostoru".
     */
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    /**
     * Obsluha udalosti "ignorovane bile znaky". Stejne chovani a parametry jako
     *
     * @see characters
     */
    @Override
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        // ...
    }

    /**
     * Obsluha udalosti "instrukce pro zpracovani".
     */
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

    /**
     * Obsluha udalosti "nezpracovana entita"
     */
    @Override
    public void skippedEntity(String name) throws SAXException {
        // ...
    }
}
