package user;

import org.w3c.dom.Document;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

import org.w3c.dom.*;

public class MyDomTransformer {


    private static int nextArtistId = 0;
    private static int nextSongId = 0;
    private static int nextBandId = 0;
    private static int nextAlbumId = 0;


    /**
     * We are going to:
     * 1. Create new Band from scratch with 2 artists , 1 album and 3 songs
     * 2. Sort songs in all the albums alphabetically
     * 3. Remove all the artists that contain more then 2 "a" symbols in their both lastname or firstname together
     */
    public void transform(Document doc) {


        /** ANALYZING IDs TO MAINTAIN ID UNIQUALITY **/
        nextAlbumId = getMaxAtrribValue(doc, "album", "album_id") + 1;
        nextSongId = getMaxAtrribValue(doc, "song", "song_id") + 1;
        nextBandId = getMaxAtrribValue(doc, "band", "band_id") + 1;
        nextArtistId = getMaxAtrribValue(doc, "artist", "artist_id") + 1;

        /** COMPOSING NEW BAND **/
        Node band = createBand(doc, "Up The Wolf", new int[]{1995, 5, 5});
        Node bandArtists = getFirstChildWithName(band, "artists");
        Node bandAlbums = getFirstChildWithName(band, "albums");

        //adding artists:
        bandArtists.appendChild(createArtist(doc, "Lord", "Mister", "guitar", new int[]{1967, 2, 5}));
        bandArtists.appendChild(createArtist(doc, "Mister", "Lord", "vocal", new int[]{1973, 8, 29}));

        //creating album
        Node album = createAlbum(doc, "Bonbones above the rainbow unicorn", "DEATH METTAAALL", new int[]{2001, 5, 9});
        Node albumSongs = getFirstChildWithName(album, "songs");
        albumSongs.appendChild(createSong(doc, "Destrroooy", 3));
        albumSongs.appendChild(createSong(doc, "Reppaaaair", 9));
        albumSongs.appendChild(createSong(doc, "Tea time", 2));
        doc.getDocumentElement().appendChild(band);

        /** SORTING ALL THE ALBUMS **/
        NodeList albums = doc.getElementsByTagName("album");
        for (int i = 0; i < albums.getLength(); i++) {
            Node node = albums.item(i);
          
            sortSongs(node);
        }

        /** ANALYZING ARTISTS AND REMOVING THOSE, WHO CONTAIN 2+ 'a' in their names (CASE-INSENSETIVE) **/

        NodeList artists = doc.getElementsByTagName("artist");
      
        for (int i = 0; i < artists.getLength(); i++) {
            int as = 0;
            Node artist = artists.item(i);
            String fullname = (getFirstChildWithName(artist, "first_name").getTextContent() + " " +
                    getFirstChildWithName(artist, "last_name").getTextContent()).toLowerCase();
            for (char c : fullname.toCharArray())
                if (c == 'a') as++;

            if (as >= 2) {
                artist.getParentNode().removeChild(artist);
               
            }
        }

    }


    /**
     * Subroutine to sort songs on given album node
     *
     * @param album album node to sort
     */
    private static void sortSongs(Node album) {
        //Get songs container
        Node songs = getFirstChildWithName(album, "songs");
        //Get all songs on container
        NodeList songlist = getAllChildrenWithName(songs, "song");
        //Transform songlist to sortable array
        Node[] songsArray = new Node[songlist.getLength()];
        for (int i = 0; i < songlist.getLength(); i++) {
            Node node = songlist.item(i);
            songs.removeChild(node);
            songsArray[i] = node;
        }
        //Sort using a specific comparator
        Arrays.sort(songsArray, new SongComparator());
        //Append songs back in the sorted order
        for (Node song : songsArray) {
            songs.appendChild(song);
        }
    }

    /**
     * Utility method to search fo the first child with given tagname
     *
     * @param where a node to search on
     * @param what  a tag name to search against
     * @return first children with given tag name or NULL
     */
    private static Node getFirstChildWithName(Node where, String what) {
        for (int i = 0; i < where.getChildNodes().getLength(); i++) {
            Node item = where.getChildNodes().item(i);
            if (what.equals(item.getNodeName())) return item;
        }
        return null;
    }

    /**
     * Utility method to get all children with certain name
     *
     * @param where a node to search on
     * @param what  a tag name to search against
     * @return NodeList of all the children with given tag name
     */
    private static NodeList getAllChildrenWithName(Node where, String what) {

        final ArrayList<Node> children = new ArrayList<Node>();
        for (int i = 0; i < where.getChildNodes().getLength(); i++) {
            Node item = where.getChildNodes().item(i);
            if (what.equals(item.getNodeName())) children.add(item);
        }
        return new ArrayNodeList(children);
    }

    /**
     * Utility method to get the max numeric value of the given attribute on a given tag name
     *
     * @param doc         document to work on
     * @param tagName     tag name to process
     * @param attrib_name attribute namae to process
     * @return max value of processed attributes
     */
    private static int getMaxAtrribValue(Document doc, String tagName, String attrib_name) {
        int res = 0;
        NodeList nodes = doc.getElementsByTagName(tagName);

        for (int i = 0; i < nodes.getLength(); i++) {
            Node node = nodes.item(i);
            String textVal = node.getAttributes().getNamedItem(attrib_name).getTextContent();
            if ("".equals(textVal.trim())) continue;
            try {
                int parsedInt = Integer.parseInt(textVal);
                if (parsedInt > res) res = parsedInt;
            } catch (Exception ex) {
                
            }
        }
        return res;
    }


    /**
     * Factory method to create artist node
     *
     * @param doc           document to work on
     * @param first_name    first name
     * @param last_name     last name
     * @param type          type of the artist
     * @param date_of_birth date of birth
     * @return
     */
    private static Node createArtist(Document doc, String first_name, String last_name, String type, int[] date_of_birth) {
        Node artistNode = doc.createElement("artist");

        //first name node
        Node first_nameNode = doc.createElement("first_name");
        first_nameNode.setTextContent(first_name);
        //last name nodenode
        Node last_nameNode = doc.createElement("last_name");
        last_nameNode.setTextContent(last_name);

        //date of birth
        Node date_of_birthNode = doc.createElement("a:date_of_birth");
        Node yearNode = doc.createElement("a:year");
        Node monthNode = doc.createElement("a:month");
        Node dayNode = doc.createElement("a:day");
        yearNode.setTextContent(date_of_birth[0] + "");
        monthNode.setTextContent(date_of_birth[1] + "");
        dayNode.setTextContent(date_of_birth[2] + "");
        date_of_birthNode.appendChild(yearNode);
        date_of_birthNode.appendChild(monthNode);
        date_of_birthNode.appendChild(dayNode);

        //Setting up id
        int id = nextArtistId++;
        Node idNode = doc.createAttribute("artist_id");
        idNode.setTextContent(id + "");
        artistNode.getAttributes().setNamedItem(idNode);

        //Setting up type
        Node typeNode = doc.createAttribute("type");
        typeNode.setTextContent(type);
        artistNode.getAttributes().setNamedItem(typeNode);

        //Composing final node
        artistNode.appendChild(first_nameNode);
        artistNode.appendChild(last_nameNode);
        artistNode.appendChild(date_of_birthNode);

        return artistNode;
    }

    /**
     * Factory method for song node
     *
     * @param doc    document to work on
     * @param title  song title
     * @param length song length
     * @return
     */
    private static Node createSong(Document doc, String title, int length) {
        Node songNode = doc.createElement("song");

        //title node
        Node titleNode = doc.createElement("title");
        titleNode.setTextContent(title);

        //length node
        Node lengthNode = doc.createElement("length");
        lengthNode.setTextContent(length + "");

        //setting up id attribute
        int id = nextSongId++;
        Node idNode = doc.createAttribute("song_id");
        idNode.setTextContent(id + "");
        songNode.getAttributes().setNamedItem(idNode);

        //composing final node
        songNode.appendChild(titleNode);
        songNode.appendChild(lengthNode);

        return songNode;
    }


    /**
     * Factory method for album node
     *
     * @param doc             document to work on
     * @param title           album title
     * @param genre           genre
     * @param date_of_release date of release
     * @return
     */
    private static Node createAlbum(Document doc, String title, String genre, int[] date_of_release) {
        Node albumNode = doc.createElement("album");

        //title node
        Node titleNode = doc.createElement("title");
        titleNode.setTextContent(title);

        //release date node
        Node date_of_releaseNode = doc.createElement("date_of_release");
        Node yearNode = doc.createElement("year");
        Node monthNode = doc.createElement("month");
        Node dayNode = doc.createElement("day");
        yearNode.setTextContent(date_of_release[0] + "");
        monthNode.setTextContent(date_of_release[1] + "");
        dayNode.setTextContent(date_of_release[2] + "");
        date_of_releaseNode.appendChild(yearNode);
        date_of_releaseNode.appendChild(monthNode);
        date_of_releaseNode.appendChild(dayNode);

        //genre node
        Node genreNode = doc.createElement("genre");
        genreNode.setTextContent(genre);

        //Placeholder for songs
        Node songsNode = doc.createElement("songs");

        //Setting up ID
        int id = nextAlbumId++;
        Node idNode = doc.createAttribute("album_id");
        idNode.setTextContent(id + "");
        albumNode.getAttributes().setNamedItem(idNode);

        //Composing final node
        albumNode.appendChild(titleNode);
        albumNode.appendChild(date_of_releaseNode);
        albumNode.appendChild(genreNode);
        albumNode.appendChild(songsNode);

        return albumNode;
    }


    /**
     * Factory method for band node
     *
     * @param doc              document to work on
     * @param name             name of band
     * @param date_of_creation date of creation
     * @return
     */
    private static Node createBand(Document doc, String name, int[] date_of_creation) {
        Node bandNode = doc.createElement("band");

        //name node
        Node nameNode = doc.createElement("name");
        nameNode.setTextContent(name);

        //setup date of creation
        Node date_of_creationNode = doc.createElement("b:date_of_creation");
        Node yearNode = doc.createElement("b:year");
        Node monthNode = doc.createElement("b:month");
        Node dayNode = doc.createElement("b:day");
        yearNode.setTextContent(date_of_creation[0] + "");
        monthNode.setTextContent(date_of_creation[1] + "");
        dayNode.setTextContent(date_of_creation[2] + "");
        date_of_creationNode.appendChild(yearNode);
        date_of_creationNode.appendChild(monthNode);
        date_of_creationNode.appendChild(dayNode);

        //Setting up id
        int id = nextBandId++;
        Node idNode = doc.createAttribute("band_id");
        idNode.setTextContent(id + "");
        bandNode.getAttributes().setNamedItem(idNode);

        //placeholders for artists and albums

        Node artistsNode = doc.createElement("artists");
        Node albumsNode = doc.createElement("albums");

        //Composing final node
        bandNode.appendChild(nameNode);
        bandNode.appendChild(date_of_creationNode);
        bandNode.appendChild(artistsNode);
        bandNode.appendChild(albumsNode);

        return bandNode;
    }



    static class ArrayNodeList implements NodeList {

        ArrayNodeList(ArrayList<Node> c) {
            this.children = c;
        }

        ArrayList<Node> children;

        public Node item(int index) {
            return children.get(index);
        }

        public int getLength() {
            return children.size();
        }
    }

    static class SongComparator implements Comparator<Node> {

        public int compare(Node o1, Node o2) {
            Node title = getFirstChildWithName(o1, "title");
            String firstTitle = title.getTextContent();
            String secondTitle = getFirstChildWithName(o2, "title").getTextContent();
            return firstTitle.compareTo(secondTitle);
        }
    }

}


