package user;

import org.xml.sax.Attributes;

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import java.util.*;

public class MySaxHandler extends DefaultHandler {

    /** TAG STACK to look up current tag when needed**/
    Stack<String> tagStack = new Stack<String>();
    /** Caching bands, artists and song name entries for final computation**/
    List<Band> bands = new ArrayList<Band>();
    Map<String,Integer> songTitleWords = new HashMap<String, Integer>();
    Band currentBand;
    Artist currentArtist;

    /** locator **/
    Locator locator;


    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    public void startDocument() throws SAXException { }

    public void endDocument() throws SAXException {

        int totalArtists = 0;
        int youngArtists = 0;
        int vocalists = 0;
        int vocalistPercentage = 0;
        String[] mostPopWords = new String[5];

        /** FINAL ANALYSIS **/
        /** VALUES 1 and 3 **/
        for (Band band : bands) {
            List<Artist> artists = band.getArtists();
            for (Artist artist : artists) {
                totalArtists++;
                if(artist.type.equals("vocal")) vocalists++;
                if(band.createDate[0] - artist.birthDay[0] < 20) youngArtists++;
            }
        }

        vocalistPercentage = (int)((float)vocalists*100/totalArtists);


        /** VALUE 2 **/
        Set<String> keys = songTitleWords.keySet();
        for (int i = 0; i < 5; i++) {
            String top = "";
            int topcount = 0;
            for (String key : keys) {
                Integer count = songTitleWords.get(key);
                if(count > topcount){
                    top = key;
                    topcount = count;
                }
            }
            mostPopWords[i] = top;
            songTitleWords.put(top,-1);
        }

       // output(vocalistPercentage,mostPopWords,youngArtists);

    }

    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        tagStack.push(qName);
        /* ANALYZING ATTRIBUTES AND CACHING INSTANCES*/
        if(localName.equals("artist")){
            currentArtist = new Artist();
            currentArtist.type = atts.getValue("type");
        } else if(localName.equals("band")){
            currentBand = new Band();
        }

    }

    public void endElement(String uri, String localName, String qName) throws SAXException {
        String popped = tagStack.pop();
        if(popped.equals("artist")){
            currentBand.addArtist(currentArtist);
        } else if(popped.equals("band")){
            bands.add(currentBand);
        }
    }

    public void characters(char[] chars, int start, int length) throws SAXException {
        String content = String.copyValueOf(Arrays.copyOfRange(chars, start, start + length));
        if("".equals(content.trim())) return;

        //Looking up the current tag
        String qName = tagStack.peek();
        if(qName.equals("a:year")){
            currentArtist.birthDay[0] = Integer.parseInt(content);
        } else if(qName.equals("a:month")){
            currentArtist.birthDay[1] = Integer.parseInt(content);
        } else if(qName.equals("a:day")){
            currentArtist.birthDay[2] = Integer.parseInt(content);
        } else if(qName.equals("b:year")){
            currentBand.createDate[0] = Integer.parseInt(content);
        } else if(qName.equals("b:month")){
            currentBand.createDate[1] = Integer.parseInt(content);
        } else if(qName.equals("b:day")){
            currentBand.createDate[2] = Integer.parseInt(content);
        } else if(qName.equals("title") && tagStack.search("song")!=-1){
            //Split song title into chunks without punctuation
            String[] chunks = content.replaceAll("[^a-zA-Z ]", "").toLowerCase().split("\\s+");
            for (String chunk : chunks) {
                songTitleWords.put(chunk,1+ (songTitleWords.containsKey(chunk) ? songTitleWords.get(chunk) : 0) );
            }
        }
    }

    public void startPrefixMapping(String prefix, String uri) throws SAXException {}

    public void endPrefixMapping(String prefix) throws SAXException {}

    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {}

    public void processingInstruction(String target, String data) throws SAXException {}

    public void skippedEntity(String name) throws SAXException {}

    public void output(float vocalArtistsRatio,String[] top5WordsInSongNames, int youngArtists){
        System.out.println("The vocal artists take "+vocalArtistsRatio+"% of all of the artists");
        System.out.println("Top 5 words used in song names: ");
        for (int i = 0; i < top5WordsInSongNames.length; i++)
            System.out.println((i+1)+". "+top5WordsInSongNames[i]);
        System.out.println(youngArtists+" artists had already been in band before they reached 20 years old.");
    }

}

class Band{
    List<Artist> artists = new ArrayList<Artist>();
    int[] createDate = new int[3];

    void addArtist(Artist a){
        artists.add(a);
    }

    List<Artist> getArtists(){
        return new ArrayList<Artist>(artists);
    }

}

class Artist{
    int[] birthDay = new int[3];
    String type;
}
