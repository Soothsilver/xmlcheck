package user;

import java.util.HashMap;
import java.util.Set;
import org.xml.sax.SAXException;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

/**
 * @author Imrich Kuklis
 */
public class MySaxHandler extends DefaultHandler
{
    // number of reservations in xml file
    private int ReservationCounter;
    // sum of the total reservation money 
    private int ReservationMoneySumUp;
    // testing if xml parser is currently in zipcode element
    private boolean InZipCode;
    // contains the frequency of the zip codes
    private final HashMap<String, Integer> ZipCodeFrequency;
    // current zip code in string format
    private String CurrentZipCode;
    // testing if xml parser is in reservation date from 
    private boolean FromDateIn;
    // in year, in month , in day
    private final boolean[] FromDateInData;
    // string values of year, month and day 
    private final String[]  FromDateValues;
    // testing if xml  parser is in reservation date to 
    private boolean ToDateIn;
    // in year, in month, in day
    private final boolean[] ToDateInData;
    // string values of year, month and day
    private final String[] ToDateValues;
    // number of reservations starting and ending on same day
    private int NumberOfReservationsEndingSameDay;
    
    public MySaxHandler()
    {
        this.ReservationCounter = 0;
        this.ReservationMoneySumUp = 0;
        this.InZipCode = false;
        this.ZipCodeFrequency = new HashMap<>();
        this.CurrentZipCode = null;
        // third question
        this.FromDateIn = false;
        this.FromDateInData = new boolean[3];
        this.FromDateValues = new String[3];
        for(int i = 0; i < this.FromDateInData.length; ++i)
        {
            this.FromDateInData[i] = false;
            this.FromDateValues[i] = null;
        }
        
        this.ToDateIn = false;
        this.ToDateInData = new boolean[3];
        this.ToDateValues = new String[3];
        
        for(int i = 0; i < this.ToDateInData.length; ++i)
        {
            this.ToDateInData[i] = false;
            this.ToDateValues[i] = null;
        }
        
    }

    private void sumReservationMoney(Attributes attributes)
    {
        if(attributes == null)
            return;
        
        String Money = null;
        String Currency = null;
        
        for(int i = 0; i < attributes.getLength(); ++i)
        {
            if(attributes.getQName(i) != null && attributes.getQName(i).equals("amount"))
            {
                Money = attributes.getValue(attributes.getQName(i));
            }
            else if(attributes.getQName(i) != null && attributes.getQName(i).equals("currency"))
            {
                Currency = attributes.getValue(attributes.getQName(i));
            }
        }
        
        int money;
        if(Money == null || Currency == null)
            return;
        
        try
        {
            money = Integer.parseInt(Money);
            if(Currency.equals("czech crown"))
                this.ReservationMoneySumUp += (money / 27);
            else
                this.ReservationMoneySumUp += money;
        }
        catch(NumberFormatException e)
        {
        }
    }
    
    @Override
    public void startElement(java.lang.String uri, java.lang.String localName, java.lang.String qName, Attributes atts) throws SAXException
    {
        // calculating first question answer
        if((localName != null && localName.equals("payment")) || (qName != null && qName.equals("payment")))
        {
            ++this.ReservationCounter;
            sumReservationMoney(atts);
        }
        
        // second question parsing
        if((localName != null && localName.equals("zipcode")) || (qName != null && qName.equals("zipcode")))
            this.InZipCode = true;
        
        // third question parsing
        
        // from date begining
        if((localName != null && localName.equals("from")) || (qName != null && qName.equals("from")))
            this.FromDateIn = true;
        
        if(this.FromDateIn)
        {
            if((localName != null && localName.equals("year")) || (qName != null && qName.equals("year")))
                this.FromDateInData[0] = true;
            
            if((localName != null && localName.equals("month")) || (qName != null && qName.equals("month")))
                this.FromDateInData[1] = true;
            
            if((localName != null && localName.equals("day")) || (qName != null && qName.equals("day")))
                this.FromDateInData[2] = true;
        }
        
        // to date beggining
        if((localName != null && localName.equals("to")) || (qName != null && qName.equals("to")))
            this.ToDateIn = true;
        
        if(this.ToDateIn)
        {
            if((localName != null && localName.equals("year")) || (qName != null && qName.equals("year")))
                this.ToDateInData[0] = true;
            
            if((localName != null && localName.equals("month")) || (qName != null && qName.equals("month")))
                this.ToDateInData[1] = true;
            
            if((localName != null && localName.equals("day")) || (qName != null && qName.equals("day")))
                this.ToDateInData[2] = true;
        }
    }
    
    @Override
    public void endElement(java.lang.String uri, java.lang.String localName, java.lang.String qName) throws SAXException
    {
        // second question parsing
        if((localName != null && localName.equals("zipcode")) || (qName != null && qName.equals("zipcode")))
        {
            if(this.ZipCodeFrequency.containsKey(this.CurrentZipCode))
            {
                int frequency = this.ZipCodeFrequency.get(CurrentZipCode).intValue();
                ++frequency;
                this.ZipCodeFrequency.put(CurrentZipCode, (Integer)frequency);
            }
            else
                this.ZipCodeFrequency.put(this.CurrentZipCode, (Integer)1);
            this.InZipCode = false;
        }
        
        // thrid question parsing
        
        // from date ending
        if((localName != null && localName.equals("from")) || (qName != null && qName.equals("from")))
            this.FromDateIn = false;
        
        if(this.FromDateIn)
        {
            if((localName != null && localName.equals("year")) || (qName != null && qName.equals("year")))
                this.FromDateInData[0] = false;
            
            if((localName != null && localName.equals("month")) || (qName != null && qName.equals("month")))
                this.FromDateInData[1] = false;
            
            if((localName != null && localName.equals("day")) || (qName != null && qName.equals("day")))
                this.FromDateInData[2] = false;
        }
        
        // to date ending
        if((localName != null && localName.equals("to")) || (qName != null && qName.equals("to")))
        {
            if(this.FromDateValues[0].equals(this.ToDateValues[0]) &&
               this.FromDateValues[1].equals(this.ToDateValues[1]) && 
               this.FromDateValues[2].equals(this.ToDateValues[2]))
                ++this.NumberOfReservationsEndingSameDay;
            this.ToDateIn = false;
        }
        
        if(this.ToDateIn)
        {
            if((localName != null && localName.equals("year")) || (qName != null && qName.equals("year")))
                this.ToDateInData[0] = false;
            
            if((localName != null && localName.equals("month")) || (qName != null && qName.equals("month")))
                this.ToDateInData[1] = false;
            
            if((localName != null && localName.equals("day")) || (qName != null && qName.equals("day")))
                this.ToDateInData[2] = false;
        }
    }
    
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException
    {
        // zipcode string format
        if(this.InZipCode)
            this.CurrentZipCode = new String(ch, start, length);
        
        if(this.FromDateIn)
        {
            // from date year string format
            if(this.FromDateInData[0])
                this.FromDateValues[0] = new String(ch, start, length);
            // from date month string format
            if(this.FromDateInData[1])
                this.FromDateValues[1] = new String(ch, start, length);
            // from date day string format
            if(this.FromDateInData[2])
                this.FromDateValues[2] = new String(ch, start, length);
        }
        
        if(this.ToDateIn)
        {
            // to date year string format
            if(this.ToDateInData[0])
                this.ToDateValues[0] = new String(ch, start, length);
            // to date month string format
            if(this.ToDateInData[1])
                this.ToDateValues[1] = new String(ch, start, length);
            // to date day string format
            if(this.ToDateInData[2])
                this.ToDateValues[2] = new String(ch, start, length);
        }
    }
    
    @Override
    public void endDocument()
    {
        double avarageFee;
        /*
            1. question : Avarage reservation fee?
            Question for of atribute property
        */
        if(this.ReservationCounter == 0)
            System.out.println("Document has no reservations!");
        else
        {
            // can be a large number because some reservations duration is more than one day 
            avarageFee = (double)this.ReservationMoneySumUp / (double)this.ReservationCounter;
            System.out.println("Avarage reservation fee in euros is: " + avarageFee);
        }
        System.out.println();
        
        /*
            2. question : The most frequently used zip code in reservations
            Question for element property
        */
        if(this.ZipCodeFrequency.isEmpty())
            System.out.println("Document has no zipcode!");
        else
        {
            int max = 0;
            String zipCode = "";
            Set<String> zipcodes = this.ZipCodeFrequency.keySet();
            for(String key : zipcodes)
            {
                if(this.ZipCodeFrequency.get(key).intValue() >= max)
                {
                    max = this.ZipCodeFrequency.get(key).intValue();
                    zipCode = key;
                }
            }
            System.out.println("The most frequent zipcode is: " + zipCode);
            System.out.println("Number of occurences of the zipcode is: " + max);
            System.out.println();
            /*
                3. question : Number of reservation starting and ending on same day;
                question for context 
            */
            System.out.println("Number of reservations starting and ending on same day: " + this.NumberOfReservationsEndingSameDay);
        }
            
    }
    
}
