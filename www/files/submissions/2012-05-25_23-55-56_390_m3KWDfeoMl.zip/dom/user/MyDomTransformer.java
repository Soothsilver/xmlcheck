package user;


import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.soap.Node;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.xml.sax.helpers.DefaultHandler;


/*
import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;
*/
/*
 * ZADANI:
 * Upravte program tak, aby transformoval vstupní XML dokument na výstupní pomocí akcí
 * uvedených v komentářích metody processTree(doc).
 */
public class MyDomTransformer //extends DefaultHandler
{
//public class MySaxHandler extends DefaultHandler

    
    private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "data.out.xml";


    /*
     * Zpracuje DOM strom
     */
    private static org.w3c.dom.Element vypis_rockeru;
    
    private static void transform(org.w3c.dom.Document doc)
    {
        org.w3c.dom.Element root = doc.getDocumentElement();
       
        pridev_vypis_rockeru(doc, root);
        
        uprav_informace(doc, root);
        
        uprav_id_prace(doc, root);
        
        zanoreni(doc, root);
                
        int asdf = 5;
    }
    
    private static void zanoreni(org.w3c.dom.Document doc, org.w3c.dom.Element root)
    {
        int hloubka = spocitani_maximalniho_zanoreni(root);
        
        org.w3c.dom.Text text_zanoreni = doc.createTextNode("Dloubka maximalniho zanoreni je " + hloubka);

        org.w3c.dom.Element elem_info_o_zanoreni = doc.createElement("info_o_zanoreni");
                            elem_info_o_zanoreni.appendChild(text_zanoreni);
        
        root.appendChild(elem_info_o_zanoreni);
    }
            
    private static int spocitani_maximalniho_zanoreni(org.w3c.dom.Element root)
    {
        int deep = 0;
        
        org.w3c.dom.NodeList nodes_informace = root.getChildNodes();
        for (int i = 0; i < nodes_informace.getLength(); i++)
        {
            org.w3c.dom.Node node = nodes_informace.item(i);
            String str = node.getNodeName();
            
            if (!str.equals("#text"))
            {
                int deep_node = spocitani_maximalniho_zanoreni(node);
                if (deep_node > deep)
                 {deep = deep_node;}
            }
        }
        
        return deep +1;
    }
    
    private static int spocitani_maximalniho_zanoreni(org.w3c.dom.Node root)
    {
        int deep = 0;
        
        org.w3c.dom.NodeList nodes_informace = root.getChildNodes();
        for (int i = 0; i < nodes_informace.getLength(); i++)
        {
            org.w3c.dom.Node node = nodes_informace.item(i);
            String str = node.getNodeName();
            
            if (!str.equals("#text"))
            {
                int deep_node = spocitani_maximalniho_zanoreni(node);
                if (deep_node > deep)
                 {deep = deep_node;}
            }
        }
        
        return deep +1;
    }
    
    private static void uprav_id_prace(org.w3c.dom.Document doc, org.w3c.dom.Element root)
    {
        org.w3c.dom.Node node_id_prace = null;
                
        org.w3c.dom.NodeList nodes_id_prace = root.getChildNodes();
        for (int i = 0; i < nodes_id_prace.getLength(); i++)
        {
            node_id_prace = nodes_id_prace.item(i);
            String str = node_id_prace.getNodeName();
            
            if (str.equals("id_prace"))
             {break;}
        }
        
        String velikan_id = null;
        org.w3c.dom.NamedNodeMap nodes_atr = node_id_prace.getAttributes();
        org.w3c.dom.Node node_id_prace_atr = nodes_atr.getNamedItem("idecko");
        if (node_id_prace_atr != null)
         {velikan_id = node_id_prace_atr.getNodeValue();}
        
        org.w3c.dom.Text text_id_velikan = doc.createTextNode(velikan_id);
        
        node_id_prace.appendChild(text_id_velikan);
        
        org.w3c.dom.NamedNodeMap attributes = node_id_prace.getAttributes();
                                 attributes.removeNamedItem("idecko");
    }
    
    private static void uprav_informace(org.w3c.dom.Document doc, org.w3c.dom.Element root)
    {
        org.w3c.dom.Node node_informace = null;
                
        org.w3c.dom.NodeList nodes_informace = root.getChildNodes();
        for (int i = 0; i < nodes_informace.getLength(); i++)
        {
            node_informace = nodes_informace.item(i);
            String str = node_informace.getNodeName();
            
            if (str.equals("informace"))
             {break;}
        }
       
        org.w3c.dom.Node node_doba_hlavniho_proudu = null;
        org.w3c.dom.Node node_kulturni_pozadi = null;
                        
        org.w3c.dom.NodeList nodes_doba_hlavniho_proudu = node_informace.getChildNodes();
        for (int i = 0; i < nodes_doba_hlavniho_proudu.getLength(); i++)
        {
            org.w3c.dom.Node node_i = nodes_doba_hlavniho_proudu.item(i);
            String str = node_i.getNodeName();
            
            if (str.equals("doba_hlavniho_proudu"))
             {node_doba_hlavniho_proudu = node_i;}
            
            if (str.equals("kulturni_pozadi"))
             {node_kulturni_pozadi = node_i;}
        }
                
        org.w3c.dom.Element el1 = doc.createElement("el1");
        org.w3c.dom.Element el2 = doc.createElement("el2");
        
        node_informace.replaceChild(el1, node_kulturni_pozadi);
        node_informace.replaceChild(el2, node_doba_hlavniho_proudu);
        
        node_informace.replaceChild(node_kulturni_pozadi, el2);
        node_informace.replaceChild(node_doba_hlavniho_proudu, el1);
        
        
        
    }
        
    private static void pridev_vypis_rockeru(org.w3c.dom.Document doc, org.w3c.dom.Element root)
    {
        vypis_rockeru = doc.createElement("vypis_rockeru");
        vypis_rockeru.setAttribute("popis","Zde se nachazi vypis vsech umelcu z databaze");
        root.appendChild(vypis_rockeru);
  
        
        org.w3c.dom.NodeList nodes = root.getChildNodes();
        for (int i = 0; i < nodes.getLength(); i++)
        {
            org.w3c.dom.Node node = nodes.item(i);
            String str = node.getNodeName();
            
            if (str.equals("vlivy"))
             {zpracuj_vlivy(doc, node);}
        }
    }
    
    private static void zpracuj_vlivy(org.w3c.dom.Document doc, org.w3c.dom.Node node_vlivy)
    {
        org.w3c.dom.NodeList nodes = node_vlivy.getChildNodes();
        for (int i = 0; i < nodes.getLength(); i++)
        {
            org.w3c.dom.Node node = nodes.item(i);
            String str = node.getNodeName();
            
            if (str.equals("vliv"))
             {zpracuj_vliv(doc, node);}
        }
    }
    
    private static void zpracuj_vliv(org.w3c.dom.Document doc, org.w3c.dom.Node node_vliv)
    {
        org.w3c.dom.NodeList nodes = node_vliv.getChildNodes();
        
        String vliv_nazev = "";
        for (int i = 0; i < nodes.getLength(); i++)
        {
            org.w3c.dom.Node node = nodes.item(i);
            String str = node.getNodeName();     
            
            if (str.equals("nazev"))
             {vliv_nazev = getText((org.w3c.dom.Element)node); break;}
        }
        
        for (int i = 0; i < nodes.getLength(); i++)
        {
            org.w3c.dom.Node node = nodes.item(i);
            String str = node.getNodeName();
            
            if (str.equals("predstavitele"))
             {zpracuj_predstavitele(doc, node, vliv_nazev);}
        }
    }
    
    private static void zpracuj_predstavitele(org.w3c.dom.Document doc, org.w3c.dom.Node node_predstavitele, String vliv_nazev)
    {
        org.w3c.dom.NodeList nodes = node_predstavitele.getChildNodes();
        for (int i = 0; i < nodes.getLength(); i++)
        {
            org.w3c.dom.Node node = nodes.item(i);
            String str = node.getNodeName();
            
            if (str.equals("skupina"))
             {zpracuj_skupina(doc, node, vliv_nazev);}
        }
    }
    
    private static void zpracuj_skupina(org.w3c.dom.Document doc, org.w3c.dom.Node node_predstavitele, String vliv_nazev)
    {
        org.w3c.dom.NodeList nodes = node_predstavitele.getChildNodes();
        
        String nazev_skupiny = "";
        for (int i = 0; i < nodes.getLength(); i++)
        {
            org.w3c.dom.Node node = nodes.item(i);
            String str = node.getNodeName();
            
            if (str.equals("nazev_skupiny"))
             {nazev_skupiny = getText((org.w3c.dom.Element)node); break;}
        }
        
        for (int i = 0; i < nodes.getLength(); i++)
        {
            org.w3c.dom.Node node = nodes.item(i);
            String str = node.getNodeName();
            
            if (str.equals("clenove"))
             {zpracuj_clenove(doc, node, vliv_nazev, nazev_skupiny);}
        }
    }
    
    private static void zpracuj_clenove(org.w3c.dom.Document doc, org.w3c.dom.Node node_predstavitele, String vliv_nazev, String nazev_skupiny)
    {
        org.w3c.dom.NodeList nodes = node_predstavitele.getChildNodes();
        
        for (int i = 0; i < nodes.getLength(); i++)
        {
            org.w3c.dom.Node node = nodes.item(i);
            String str = node.getNodeName();
            
            if (str.equals("clen"))
            {
               String jmeno_clena = getText((org.w3c.dom.Element)node);
               String velikan_id = "";
               
               org.w3c.dom.NamedNodeMap nodes_atr = node.getAttributes();
               org.w3c.dom.Node node_velikan_id = nodes_atr.getNamedItem("velikan_id");
               if (node_velikan_id != null)
                {velikan_id = node_velikan_id.getNodeValue();}
               
               pridej_clena(doc, vliv_nazev, nazev_skupiny, jmeno_clena, velikan_id);
            }
        }
    }
    
    private static org.w3c.dom.Node najdi_velikana(org.w3c.dom.Document doc, String vliv_nazev, String nazev_skupiny, String jmeno_clena, String velikan_id)
    {
        org.w3c.dom.Element root = doc.getDocumentElement();
        
        org.w3c.dom.Node node_rockovy_velikani = null;
                
        org.w3c.dom.NodeList nodes_rockova_historie = root.getChildNodes();
        for (int i = 0; i < nodes_rockova_historie.getLength(); i++)
        {
            org.w3c.dom.Node node = nodes_rockova_historie.item(i);
            String str = node.getNodeName();
            
            if (str.equals("rockovy_velikani"))
             {node_rockovy_velikani = node;}
        }

        org.w3c.dom.NodeList nodes_hudebnik = (node_rockovy_velikani).getChildNodes();

        for (int i = 0; i < nodes_hudebnik.getLength(); i++)
        {
            org.w3c.dom.Node node = nodes_hudebnik.item(i);
            String str = node.getNodeName();

            if (str.equals("hudebnik"))
            {
                org.w3c.dom.NamedNodeMap nodes_atr = node.getAttributes();
                org.w3c.dom.Node node_velikan_id = nodes_atr.getNamedItem("id");
                String id = node_velikan_id.getNodeValue();

                if (id.equals(velikan_id))
                {return node.cloneNode(true);}
            }
        }
        
        return null;
    }
    
    private static void pridej_clena(org.w3c.dom.Document doc, String vliv_nazev, String nazev_skupiny, String jmeno_clena, String velikan_id)
    {
        org.w3c.dom.Element umelec = doc.createElement("umelec");
        
        org.w3c.dom.Text text_vliv_nazev    = doc.createTextNode(vliv_nazev);
        org.w3c.dom.Text text_nazev_skupiny = doc.createTextNode(nazev_skupiny);
        org.w3c.dom.Text text_jmeno_clena   = doc.createTextNode(jmeno_clena);
        org.w3c.dom.Text text_velikan_id    = doc.createTextNode(velikan_id);

        org.w3c.dom.Element element_vliv_nazev = doc.createElement("nazev_vlivu");
                            element_vliv_nazev.appendChild(text_vliv_nazev);
        
        org.w3c.dom.Element element_nazev_skupiny = doc.createElement("nazev_skupiny");
                            element_nazev_skupiny.appendChild(text_nazev_skupiny);
        
        org.w3c.dom.Element element_jmeno_clena = doc.createElement("jmeno_clena");
                            element_jmeno_clena.appendChild(text_jmeno_clena);
        
        org.w3c.dom.Element element_text_velikan_id = doc.createElement("text_velikan_id");
                            element_text_velikan_id.appendChild(text_velikan_id);
        
                        
        org.w3c.dom.Node velikan = najdi_velikana(doc, vliv_nazev, nazev_skupiny, jmeno_clena, velikan_id);
        org.w3c.dom.Element element_rockovy_velikan = null;
        
        if (velikan != null)
        {
            org.w3c.dom.NodeList nl = velikan.getChildNodes();
                                         
            element_rockovy_velikan = doc.createElement("rockovy_velikan");
            for (int i = 0; i < nl.getLength(); i++)
            {
               org.w3c.dom.Node node = nl.item(i);
               String str = node.getNodeName();
               
               if (!str.equals("#text"))
               element_rockovy_velikan.appendChild(node);
             }
        }
        
        umelec.appendChild(element_vliv_nazev);
        umelec.appendChild(element_nazev_skupiny);
        umelec.appendChild(element_jmeno_clena);
        
        if (!velikan_id.equals(""))
        {
            umelec.appendChild(element_text_velikan_id);
            if (velikan != null && velikan_id != "")
             {umelec.appendChild(element_rockovy_velikan);}
        }
        
        
        if ((!velikan_id.equals("")) && (velikan == null))
         {vypis_chybu(doc, vliv_nazev, nazev_skupiny, jmeno_clena, velikan_id);}

        vypis_rockeru.appendChild(umelec);
    }
    
    private static void vypis_chybu(org.w3c.dom.Document doc, String vliv_nazev, String nazev_skupiny, String jmeno_clena, String velikan_id)
    {
        org.w3c.dom.Element root = doc.getDocumentElement();
        org.w3c.dom.NodeList nl = root.getChildNodes();
        
        org.w3c.dom.Element elem_chyby = null;
        
        for (int i = 0; i < nl.getLength(); i++)
        {
            org.w3c.dom.Node elem = nl.item(i);
            
            String str = elem.getNodeName();
            if (str.equals("chyby"))
            {
                elem_chyby = (org.w3c.dom.Element) elem;
                break;
            }
        }
        
        if ( elem_chyby == null)
        {
            elem_chyby = doc.createElement("chyby");
            root.appendChild(elem_chyby);
        }
        
        String velikan_id_ = "neuvedeno";
        if (! velikan_id.equals(""))
         {velikan_id_ =velikan_id;}
        
        org.w3c.dom.Text text_popis = doc.createTextNode("Rockovy umelec nebyl nalezen v databazi rockovych velikanu.");
        org.w3c.dom.Element element_popis_chyby = doc.createElement("popis_chyby");
                            element_popis_chyby.appendChild(text_popis);
        
        org.w3c.dom.Text text_chyba = doc.createTextNode(jmeno_clena);
        org.w3c.dom.Element element_clen = doc.createElement("clen");
                            element_clen.appendChild(text_chyba);
        
        org.w3c.dom.Text text_id = doc.createTextNode(velikan_id_);
        org.w3c.dom.Element element_id = doc.createElement("id");
                            element_id.appendChild(text_id);
                            
        org.w3c.dom.Element element_chyba = doc.createElement("chyba");
                            element_chyba.appendChild(element_popis_chyby);
                            element_chyba.appendChild(element_id);
                            element_chyba.appendChild(element_clen);
        
        elem_chyby.appendChild(element_chyba);
        
    }
    
    public static String getText(org.w3c.dom.Element element)
    {
        StringBuffer buf = new StringBuffer();
        org.w3c.dom.NodeList list = element.getChildNodes();
        boolean found = false;
    
        for (int i = 0; i < list.getLength(); i++)
        {
            org.w3c.dom.Node node = list.item(i);
            if (node.getNodeType() == Node.TEXT_NODE)
            {
                buf.append(node.getNodeValue());
                found = true;
            }
        }
        return found ? buf.toString() : null;
    }
}
 