package user;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import org.xml.sax.helpers.DefaultHandler;

import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;
import user.Datovy_model.Uzel;

class SAX_podpora {

    
   
    public static void main(String[] args) {

        // Cesta ke zdrojovému XML dokumentu 
        String sourcePath = "data.xml";

        try {
           
            // Vytvoríme instanci parseru.
            XMLReader parser = XMLReaderFactory.createXMLReader();
           
            // Vytvoríme vstupní proud XML dat.
            InputSource source = new InputSource(sourcePath);
           
            // Nastavíme náą vlastní content handler pro obsluhu SAX událostí.
            parser.setContentHandler(new MySaxHandler());
           
            // Zpracujeme vstupní proud XML dat.
            parser.parse(source);
           
        } catch (Exception e) {
       
            e.printStackTrace();
           
        }
       
    }
   
}




/*
 * Náš vlastní content handler pro obsluhu SAX událostí.
 * Implementuje metody interface ContentHandler.
 */

public class MySaxHandler extends DefaultHandler {

    // Umožňuje zacílit místo v dokumentu, kde vznikla aktualní událost
    Locator locator;

    Datovy_model dat_mod = new Datovy_model();
   
 
    // Obsahuje retezec uvnitr elementu
    StringBuffer str_buff = new StringBuffer();
    boolean inside_element = false;
   
    // Obsahuje pocet aktualne otevrenych elementu
    int opened_elements = -1;
    // Urcuje pocet mezer pro odsazeni nasledujiciho elementu
    int offset = 3;
   
    /*
     * Nastaví locator
     */
   
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /*
     * Obsluha události "začátek dokumentu"
     */    
    @Override
    public void startDocument() throws SAXException {
       
        // ...
       
    }
    /*
     * Obsluha události "konec dokumentu"
     */    
    @Override
    public void endDocument() throws SAXException {
       
        // ...
        System.out.println();
        System.out.println("<tabulka>");

        ArrayList<Uzel> pole = this.dat_mod.uzely_setrizene_podle_jmena_clena_skupiny();
                
        for (int i = 0; i < pole.size(); i++)
        {
            for (int ii = 0; ii < this.offset; ii++)
             {System.out.print(" ");}
            System.out.println("<umelec>");
           
            Uzel uzel = pole.get(i);
               for (int ii = 0; ii < 2*offset; ii++)
                {System.out.print(" ");}
            System.out.println("<idecko>" + uzel.ID_velikana + "</idecko>");
               for (int ii = 0; ii < 2*offset; ii++)
                {System.out.print(" ");}
            System.out.println("<jmeno>" +  uzel.jmeno_clena + "</jmeno>");
               for (int ii = 0; ii < 2*offset; ii++)
                {System.out.print(" ");}
            System.out.println("<rok_narozeni>" + uzel.rok_narozeni + "</rok_narozeni>");
               for (int ii = 0; ii < 2*offset; ii++)
                {System.out.print(" ");}
            System.out.println("<skupina>" + uzel.skupina + "</skupina>");
                       
            for (int ii = 0; ii < this.offset; ii++)
             {System.out.print(" ");}
            System.out.println("</umelec>");
           
        }
       
        System.out.println("</tabulka>");

        System.out.println();
        System.out.println("<skupiny_s_mene_nez_tremi_umelci>");
       
        ArrayList<String> skupiny = this.dat_mod.vsechny_skupiny();
        for (int i = 0; i < skupiny.size(); i++)
        {
            String skupina = skupiny.get(i);
            ArrayList<String> umelci_skupiny = this.dat_mod.umelci_skupiny(skupina);
           
            Uzel posledni_clen = this.dat_mod.uzel_posledniho_clena_skupiny(skupina);
            
            if (umelci_skupiny.size() < 3)
            {
                for (int ii = 0; ii < this.offset; ii++)
                 {System.out.print(" ");}
                System.out.println("<skupina>" + skupina + "</skupina>");
                for (int ii = 0; ii < this.offset; ii++)
                 {System.out.print(" ");}
                System.out.println("<radek>" + posledni_clen.line + "</radek>");
                for (int ii = 0; ii < this.offset; ii++)
                 {System.out.print(" ");}
                System.out.println("<sloupec>" + posledni_clen.column + "</sloupec>");
            }
        }
       
        System.out.println("</skupiny_s_mene_nez_tremi_umelci>");
   
        System.out.println();
        System.out.println("<umelci_s_id_pro_ktere_neexestuje_velikan>");
       
        ArrayList<Uzel> uzly = this.dat_mod.uzely_setrizene_podle_jmena_clena_skupiny();
        for (int i = 0; i < uzly.size(); i++)
        {
            Uzel uzel = uzly.get(i);
            String uzel_id = uzel.ID_velikana;
            String uzel_rok_narozeni = uzel.rok_narozeni;
                                    
            if ( (!uzel_id.equals("neuvedeno")) &&
                 uzel_rok_narozeni.equals("neuvedeno") )
            {
                for (int ii = 0; ii < this.offset; ii++)
                 {System.out.print(" ");}
                System.out.println("<umelec>");
            
                for (int ii = 0; ii < 2*this.offset; ii++)
                 {System.out.print(" ");}
                System.out.println("<skupina>" + uzel.skupina + "</skupina>");
                for (int ii = 0; ii < 2*this.offset; ii++)
                 {System.out.print(" ");}
                System.out.println("<jmeno_clena>" + uzel.jmeno_clena + "</jmeno_clena>");
            
                for (int ii = 0; ii < this.offset; ii++)
                 {System.out.print(" ");}
                System.out.println("</umelec>");
            }
        }
        
        System.out.println("</umelci_s_id_pro_ktere_neexestuje_velikan>");
       
        
    }
   
    public boolean rockova_historie = false;
    public boolean vlivy = false;
    public boolean vliv = false;
    public boolean predstavitele = false;
    public boolean zpevak = false;
    public boolean zpevacka = false;
    public boolean skupina = false;
    public boolean nazev_skupiny = false;
    public boolean clenove = false;
    public boolean clen_zpevak = false;
    public boolean clen_zpevacka = false;
    public boolean clen_skupina = false;
    
    public String template_nazev_skupiny = "";
    public String template_velikan_id = "";
    public String template_clen = "";
    public String template_id = "";
    public String template_rok_narozeni = "";
   
    public boolean rockovy_velikani = false;
    public boolean hudebnik = false;
    public boolean rok_narozeni = false;
   
    /*
     * Obsluha události "začátek elementu".
     * @param uri URI jmenného prostoru elementu (prázdné, pokud element není v žádném jmenném prostoru)
     * @param localName Lokální jméno elementu (vždy neprázdné)
     * @param qName Kvalifikované jméno (tj. prefix-uri + ':' + localName, pokud je element v nějakém jmenném prostoru, nebo localName, pokud element není v žádném jmenném prostoru)
     * @param atts Atributy elementu    
     */    
    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
/*
        boolean stav_start            = (!rockova_historie) && (!vlivy) && (!vliv) && (!predstavitele) && (!zpevacka) && (!zpevak) && (!skupina) && (!clenove) && (!clen);
        boolean stav_rockova_historie = ( rockova_historie) && (!vlivy) && (!vliv) && (!predstavitele) && (!zpevacka) && (!zpevak) && (!skupina) && (!clenove) && (!clen);
        boolean stav_vlivy            = ( rockova_historie) && ( vlivy) && (!vliv) && (!predstavitele) && (!zpevacka) && (!zpevak) && (!skupina) && (!clenove) && (!clen);
        boolean stav_vliv             = ( rockova_historie) && ( vlivy) && ( vliv) && (!predstavitele) && (!zpevacka) && (!zpevak) && (!skupina) && (!clenove) && (!clen);
        boolean stav_predstavitele    = ( rockova_historie) && ( vlivy) && ( vliv) && ( predstavitele) && (!zpevacka) && (!zpevak) && (!skupina) && (!clenove) && (!clen);
        boolean stav_zpevacka         = ( rockova_historie) && ( vlivy) && ( vliv) && ( predstavitele) && ( zpevacka) && (!zpevak) && (!skupina) && (!clenove) && (!clen);
        boolean stav_zpevak           = ( rockova_historie) && ( vlivy) && ( vliv) && ( predstavitele) && (!zpevacka) && ( zpevak) && (!skupina) && (!clenove) && (!clen);
        boolean stav_skupina          = ( rockova_historie) && ( vlivy) && ( vliv) && ( predstavitele) && (!zpevacka) && (!zpevak) && ( skupina) && (!clenove) && (!clen);
        boolean stav_clenove          = ( rockova_historie) && ( vlivy) && ( vliv) && ( predstavitele) && (!zpevacka) && (!zpevak) && ( skupina) && ( clenove) && (!clen);
        boolean stav_clen_skupina     = ( rockova_historie) && ( vlivy) && ( vliv) && ( predstavitele) && (!zpevacka) && (!zpevak) && ( skupina) && ( clenove) && ( clen);
        boolean stav_clen_zpevacka    = ( rockova_historie) && ( vlivy) && ( vliv) && ( predstavitele) && ( zpevacka) && (!zpevak) && (!skupina) && (!clenove) && ( clen);
        boolean stav_clen_zpevak      = ( rockova_historie) && ( vlivy) && ( vliv) && ( predstavitele) && (!zpevacka) && ( zpevak) && (!skupina) && (!clenove) && ( clen);
*/

        
        if ((!rockova_historie) && qName.endsWith("rockova_historie"))
         {rockova_historie = true;}
       
        if (rockova_historie && qName.endsWith("vlivy"))
         {rockova_historie = false; vlivy = true;}
       
        if (vlivy && qName.endsWith("vliv"))
         {vlivy = false; vliv = true;}
       
        if (vliv && qName.endsWith("predstavitele"))
         {vliv = false; predstavitele = true;}
       
        if (predstavitele && qName.endsWith("zpevacka"))
         {predstavitele = false; zpevacka = true;}
       
        if (zpevacka && qName.endsWith("clen"))
         {zpevacka = false; clen_zpevacka = true;}
       
        if (predstavitele && qName.endsWith("zpevak"))
         {predstavitele = false; zpevak = true;}
       
        if (zpevak   && qName.endsWith("clen"))
         {zpevak = false; clen_zpevak = true;} 
       
        if (predstavitele && qName.endsWith("skupina"))
         {predstavitele = false; skupina = true;}
       
        if (skupina  && qName.endsWith("clenove"))
         {skupina = false; clenove = true;}
       
        if (skupina  && qName.endsWith("nazev_skupiny"))
         {skupina = false; nazev_skupiny = true;}
       
        if (clenove  && qName.endsWith("clen"))
         {clenove = false; clen_skupina = true;}

       
       
        if (rockova_historie && qName.endsWith("rockovy_velikani"))
         {rockova_historie = false; rockovy_velikani = true;}
       
        if (rockovy_velikani && qName.endsWith("hudebnik"))
         {rockovy_velikani = false; hudebnik = true;}  
       
        if (hudebnik && qName.endsWith("rok_narozeni"))
         {hudebnik = false; rok_narozeni = true;}  
       
       
        boolean clen = clen_zpevacka || clen_zpevak || clen_skupina;
         for(int i=0; i<attributes.getLength(); i++)
         {
            String jmeno   = attributes.getQName(i);
            String hodnota = attributes.getValue(i);

            if (clen && jmeno.endsWith("velikan_id"))
             {this.template_velikan_id = hodnota;}
           
            if (hudebnik && jmeno.endsWith("id"))
             {this.template_id = hodnota;}
         }
        
        // ... vypis
        String str = this.str_buff.toString();
                     this.str_buff.delete(0, str.length());
       
        this.inside_element = true;
        this.opened_elements++;
      
        System.out.println("");
        int range = this.opened_elements * this.offset;
        for (int i = 0; i < range; i++)
         {System.out.print(" ");}
       
        System.out.print("<"+qName);
        for(int i=0; i<attributes.getLength(); i++)
        { 
            String jmeno   = attributes.getQName(i);
            String hodnota = attributes.getValue(i);

            System.out.print(" " + jmeno + "=\"" + hodnota + "\"");
        }
        System.out.print(">");

    }
   
    /*
     * Obsluha události "konec elementu"
     * Parametry mají stejný význam jako u @see startElement    
     */    
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
   
        if (rok_narozeni && qName.endsWith("rok_narozeni"))
         {template_rok_narozeni = this.str_buff.toString();}
   
        if (skupina && qName.endsWith("skupina"))
         {template_nazev_skupiny = "";}
                         
        if (nazev_skupiny && qName.endsWith("nazev_skupiny"))
         {template_nazev_skupiny = this.str_buff.toString();}
           
        boolean clen = clen_zpevacka || clen_zpevak || clen_skupina;
        if (clen && qName.endsWith("clen"))
         {
             template_clen = this.str_buff.toString();
             
             int line = this.locator.getLineNumber();
             int column = this.locator.getColumnNumber();
        
             dat_mod.vloz(template_clen, template_velikan_id, template_nazev_skupiny, line, column);
             template_velikan_id = "";
         }
       
         if (hudebnik && qName.endsWith("hudebnik"))
          {dat_mod.vloz(template_id, template_rok_narozeni);}
         
         
       
        if (rockova_historie && qName.endsWith("rockova_historie"))
         {rockova_historie = false;}
        
        if (vlivy && qName.endsWith("vlivy"))
         {vlivy = false; rockova_historie = true;}
        
        if (vliv && qName.endsWith("vliv"))
         {vliv = false; vlivy = true;}
        
        if (predstavitele && qName.endsWith("predstavitele"))
         {predstavitele = false; vliv = true;}
        
        if (zpevak && qName.endsWith("zpevak"))
         {zpevak = false; predstavitele = true;}
        
        if (zpevacka && qName.endsWith("zpevacka"))
         {zpevacka = false; predstavitele = true;}
        
        if (skupina && qName.endsWith("skupina"))
         {skupina = false; predstavitele = true;}
        
        if (nazev_skupiny && qName.endsWith("nazev_skupiny"))
         {nazev_skupiny = false;  skupina = true;}
        
        if (clenove && qName.endsWith("clenove"))
         {clenove = false; skupina = true;}
        
        if (clen_zpevacka && qName.endsWith("clen"))
         {clen_zpevacka = false; zpevacka = true;}
       
        if (clen_zpevak && qName.endsWith("clen"))
         {clen_zpevak = false; zpevak = true;}
       
        if (clen_skupina && qName.endsWith("clen"))
         {clen_skupina = false; clenove = true;}
       
        
        
        if (rockovy_velikani && qName.endsWith("rockovy_velikani"))
         {rockovy_velikani = false;}
        
        if (hudebnik && qName.endsWith("hudebnik"))
         {hudebnik = false;  rockovy_velikani = true;}
        
        if (rok_narozeni && qName.endsWith("rok_narozeni"))
         {rok_narozeni = false;  hudebnik = true;}
       
        
        // ... vypis
        String str = this.str_buff.toString();
                     this.str_buff.delete(0, str.length());
       
        System.out.print(str);
       
        boolean is_deepest_element = str.length() != 0;
        if (!is_deepest_element)
        {
          System.out.println("");
          int range = this.opened_elements * this.offset;
          for (int i = 0; i < range; i++)
           {System.out.print(" ");}
        }
       
        System.out.print("</"+qName+">");

        this.inside_element = false;
        this.opened_elements--;
       
    }
   
    /*
     * Obsluha události "znaková data".
     * SAX parser muľe znaková data dávkovat jak chce. Nelze tedy počítat s tím, že je celý text dorucen v rámci jednoho volání.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakovými daty
     * @param start Index zacátku úseku platných znakových dat v poli.
     * @param length Délka úseku platných znakových dat v poli.
     */              
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {

        // ...
       
        // Retezec pridame do bufferu v pripade, kdy cteme nejky vnitrek elementu
        // tento stav zjistime tek, ze overime, ze
        if (this.inside_element)
        {
            String str = new String(ch, start, length);
            str_buff.append(str);
        }
       
    }
   
    /*
     * Obsluha události "deklarace jmenného prostoru".
     * @param prefix Prefix prirazený jmennému prostoru.
     * @param uri URI jmenného prostoru.
     */    
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
       
        // ...
       
    }

    /*
     * Obsluha události "konec platnosti deklarace jmenného prostoru".
     */    
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
   
        // ...
   
    }

    /*
     * Obsluha události "ignorované bílé znaky".
     * Stejné chování a parametry jako @see characters    
     */    
    @Override
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
       
        // ...
       
    }

    /*
     * Obsluha události "instrukce pro zpracování".
     */        
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
     
      // ...
           
    }

    /*
     * Obsluha události "nezpracovaná entita"
     */        
    @Override
    public void skippedEntity(String name) throws SAXException {
   
      // ...
   
    }
}


class Datovy_model
{      
    class Uzel
    {
        public String jmeno_clena = "neuvedeno";
        public String ID_velikana = "neuvedeno";
        public String skupina = "neuvedeno";
        public String rok_narozeni = "neuvedeno";
        public int line = -1;
        public int column = -1;
       
        public Uzel(String jmeno_clena, String ID_velikana, String skupina, int line, int column)
        {
            if (jmeno_clena != null && jmeno_clena != "")
             {this.jmeno_clena = jmeno_clena;}
            if (ID_velikana != null && ID_velikana != "")
             {this.ID_velikana = ID_velikana;}
            if (skupina != null && skupina != "")
             {this.skupina = skupina;}
            
            this.line = line;
            this.column = column;
        }
       
        public Uzel(String ID_velikana, String rok_narozeni)
        {
            if (ID_velikana != null && ID_velikana != "")
             {this.ID_velikana = ID_velikana;}
            if (rok_narozeni != null && rok_narozeni != "")
             {this.rok_narozeni = rok_narozeni;}
        }
    }
   
    private List<Uzel> list = new ArrayList<Uzel>();
   
    public void vloz(String jmeno_clena, String ID_velikana, String skupina, int line, int column)
    {
        int index = index_velikana_id(ID_velikana);
        if (ID_velikana.equals(""))
         {index = -1;}
       
        if ( index == -1)
        {
            Uzel uz = new Uzel(jmeno_clena, ID_velikana, skupina, line, column);
            list.add(uz);
        }
        else
        {
            Uzel uzel = get_i(index);
                if (jmeno_clena != null || jmeno_clena != "")
                 {uzel.jmeno_clena = jmeno_clena;}
                if (skupina != null || skupina != "")
                 {uzel.skupina = skupina;}
        }
    }
   
    public void vloz(String id, String rok_narozeni)
    {
        int index = index_velikana_id(id);
        if ( index == -1)
        {
            Uzel uzel = new Uzel(id, rok_narozeni);
            list.add(uzel);
        }
        else
        {
            Uzel uzel = get_i(index);
               if (rok_narozeni != null || rok_narozeni != "")
                {uzel.rok_narozeni = rok_narozeni;}
        }
    }
   
    private int index_velikana_id(String id_velikana)
    {
        for (int i = 0; i < list.size(); i++)
        {
            Uzel uzel = list.get(i);
            if (uzel.ID_velikana.endsWith(id_velikana))
             {return i;}
        }
        return -1;
    }
   
    public int pocet_zaznamu()
     {return list.size();}
   
    public Uzel get_i(int i)
     {return list.get(i);}
   
    public ArrayList<String> vsechny_skupiny()
    {
        ArrayList<String> pole_skupin = new ArrayList<String>();
       
        for (int i = 0; i < list.size(); i++)
        {
            Uzel uzel = list.get(i);
            int index = pole_skupin.indexOf(uzel.skupina);
           
            if (index < 0)
             {pole_skupin.add(uzel.skupina);}
        }
       
        pole_skupin.remove("neuvedeno");
        return pole_skupin;
    }
   
    public ArrayList<String> umelci_skupiny(String skupina)
    {
        ArrayList<String> pole_umelcu_skupiny = new ArrayList<String>();
       
        for (int i = 0; i < list.size(); i++)
        {
            Uzel uzel = list.get(i);
           
            if (uzel.skupina.endsWith(skupina))
             {pole_umelcu_skupiny.add(uzel.jmeno_clena);}
        }
       
        return pole_umelcu_skupiny;

    }
    
    public Uzel uzel_posledniho_clena_skupiny(String skupina)
    {
        ArrayList<String> skupiny = this.vsechny_skupiny();
        int index = skupiny.indexOf(skupina);
        
        if (index == -1)
         {return null;}
        
        
        ArrayList<Uzel> clenove_skupiny = new ArrayList<Uzel>();
        
        for (int i = 0; i <list.size(); i++)
        {
            Uzel uzel = list.get(i);
            if (uzel.skupina.equals(skupina))
             {clenove_skupiny.add(uzel);}
        }
        
        Uzel clenove_skupiny_pole[] = new Uzel[clenove_skupiny.size()];
        for (int i = 0; i < clenove_skupiny.size(); i++)
         {clenove_skupiny_pole[i] = clenove_skupiny.get(i);}
        
        Arrays.sort(clenove_skupiny_pole, new Uzel_Lines_Comparator());
        
        Uzel posledni_clen = clenove_skupiny_pole[clenove_skupiny.size() -1];
        
        return posledni_clen;
        
    }
    

    public ArrayList<Uzel> uzely_setrizene_podle_jmena_clena_skupiny()
    {
        Uzel pole[] = new Uzel[list.size()];
        for (int i = 0; i < list.size(); i++)
         {pole[i] = list.get(i);}
        
        Arrays.sort(pole, new Uzel_jmeno_Comparator());
        
        ArrayList<Uzel> list_setrizeny = new ArrayList<Uzel>();
        for (int i = 0; i < list.size(); i++)
         {list_setrizeny.add(pole[i]);}
        
        return list_setrizeny;
    }

}


class Uzel_Lines_Comparator implements Comparator{
 
    public int compare(Object o1, Object o2)
    {
        Uzel uzel1 = (Uzel) o1;
        Uzel uzel2 = (Uzel) o2;
        
        int line1 = uzel1.line;        
        int line2 = uzel2.line;
       
        if (line1 > line2)
        {return 1;}
        
        if (line1 < line2)
        {return -1;}
        
        return 0;
    }

}
 

class Uzel_jmeno_Comparator implements Comparator{
 
    public int compare(Object o1, Object o2)
    {
        Uzel uzel1 = (Uzel) o1;
        Uzel uzel2 = (Uzel) o2;
        
        String jmeno1 = uzel1.jmeno_clena;        
        String jmeno2 = uzel2.jmeno_clena;
       
        return jmeno1.compareTo(jmeno2);
    }

}