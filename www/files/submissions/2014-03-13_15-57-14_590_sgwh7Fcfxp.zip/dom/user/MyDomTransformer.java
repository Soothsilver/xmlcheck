package user; 

import org.w3c.dom.*;

public class MyDomTransformer 
{ 
	public void transform (Document xmlDocument)
	{  
		// add a movie
		
		Element vrs = xmlDocument.getDocumentElement();
		
		Element movies;
		
		if (vrs.getElementsByTagName("movies").getLength()==0)
		{
			movies=xmlDocument.createElement("movies");
			vrs.appendChild(movies);
		}
		else
		{
			movies=(Element)vrs.getElementsByTagName("movies").item(0);
		}
		
		int count=movies.getElementsByTagName("movie").getLength();
		
		Element movie=xmlDocument.createElement("movie");
		movie.setAttribute("id", String.format("m%03d", count+1));
		movie.setAttribute("count", "10");
		movie.setAttribute("rating","R");
		movie.appendChild(xmlDocument.createElement("title")).setTextContent("300: Rise of an Empire");
		movie.appendChild(xmlDocument.createElement("director")).setTextContent("Noam Murro");
		movie.appendChild(xmlDocument.createElement("length")).setTextContent("102");
		
		movies.appendChild(movie);
		
		
		// delete all R rated films
		
		NodeList ms=movies.getElementsByTagName("movie");
		
		for(int i=ms.getLength()-1;i>=0;i--)
		{
			if (((Element)ms.item(i)).getAttribute("rating").equals("R")) movies.removeChild(ms.item(i));
		}
		
	}
}