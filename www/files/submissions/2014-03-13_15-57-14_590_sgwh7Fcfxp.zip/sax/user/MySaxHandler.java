package user;

import java.util.*;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;


public class MySaxHandler extends DefaultHandler 
{
	boolean in_length;
	boolean in_name;
	
	int total_length;
	int movie_count;
	
	int total_count;
	
	String last_customer_name;
	
	ArrayList<String> unavailable=new ArrayList<String>();
	ArrayList<String> customers=new ArrayList<String>();


	@Override
	public void characters(char[] ch, int start, int length) throws SAXException 
	{
		if (in_length)
		{
			total_length+=Integer.parseInt(new String(ch,start,length));
			in_length=false;
		}
		if (in_name)
		{
			last_customer_name=new String(ch,start,length);
			in_name=false;
		}
	}

	@Override
	public void endDocument() throws SAXException 
	{
		if (movie_count>0) System.out.println("Average length of a movie:" + total_length/movie_count);
		else System.out.println("No movies");
		System.out.println("Total number of discs:"+ total_count);
		for (String s :customers)
		{
			System.out.println(s);
		}
	}

	@Override
	public void startElement(String uri, String localName, String qName,Attributes attributes) throws SAXException 
	{
		if (qName.equals("movie"))
		{
				movie_count++;
				int count=Integer.parseInt(attributes.getValue("count"));
				total_count+=count;
				if (count==0) unavailable.add(attributes.getValue("id"));
		}
		if (qName.equals("length"))	in_length=true;
		if (qName.equals("name")) in_name=true;
			
		if (qName.equals("rental"))
		{
			for (String s : unavailable)
				if (s.equals(attributes.getValue("id"))) customers.add(last_customer_name + ": " + s);
		}
	}
}

