package user;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

public class MySaxHandler extends DefaultHandler
{ 
    private static final String INPUT_FILE = "data.xml";
    public static void main(String[] args) {
        
        try {
            //XMLReader parser = XMLReaderFactory.createXMLReader();
            //InputSource source = new InputSource(INPUT_FILE);
            //parser.setContentHandler(new CustomContentHandler());

            // Process input data
            //parser.parse(source);

        } catch (Exception e) {
            //e.printStackTrace();
        }
 
    }
}
