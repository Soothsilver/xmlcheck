/*
 * Zanalyzuje XML dokument a vypíše jeho maximální hloubku, cestu k nejhlubšímu
 * elementu, počet všech elementů, průměrnou délku názvu elementů a celkový počet
 * atributů.
 */

package user;

import java.util.Stack;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {

    int currentDepth;
    int maxDepth;
    String maxDepthPath;
    Stack<String> elementStack;

    int elementCount;
    int elementNameLenSum;
    int attributeCount;

    @Override
    public void startDocument() throws SAXException {
        super.startDocument();

        currentDepth = 0;
        maxDepth = 0;
        elementCount = 0;
        elementNameLenSum = 0;
        attributeCount = 0;
        elementStack = new Stack<String>();
    }

    @Override
    public void endDocument() throws SAXException {
        super.endDocument();

        System.out.printf("Maximal depth: %s (%s)\nElement count: %s\nAverage element name length: %s\nAttribute count: %s\n",
                maxDepth, maxDepthPath, elementCount, (double)(elementNameLenSum) / elementCount, attributeCount);
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        super.startElement(uri, localName, qName, attributes);

        currentDepth++;
        elementStack.push(localName);
        if (currentDepth > maxDepth)
        {
            maxDepth = currentDepth;
            maxDepthPath = "/";
            for (String S : elementStack)
            {
                maxDepthPath += S + "/";
            }
        }

        elementCount++;
        elementNameLenSum += localName.length();
        attributeCount += attributes.getLength();
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        super.endElement(uri, localName, qName);

        currentDepth--;
        elementStack.pop();
    }
}
