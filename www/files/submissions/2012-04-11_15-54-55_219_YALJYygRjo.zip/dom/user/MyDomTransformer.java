/*
 * Transformuje dokument data.xml (redakční system) tak, že všechny články převede
 * pod jejich autory, takže se všechny budou vyskytovat jako podelement u svých
 * autorů. Původni seznam článků odstraní.
 */

package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer {
    public Element getAuthorById(Document xmlDocument, String authorID) {
        Element root = xmlDocument.getDocumentElement();
        NodeList authors = root.getElementsByTagName("author");

        for (int i = 0; i < authors.getLength(); i++) {
            Element author = (Element)authors.item(i);
            if (author.getAttribute("id").equals(authorID))
                return author;
        }

        return null;
    }

    public void transform (Document xmlDocument) {
        Element root = xmlDocument.getDocumentElement();
        NodeList articles = root.getElementsByTagName("article");

        for (int i = 0; i < articles.getLength(); i++) {
            Element article = (Element)articles.item(i);
            NodeList articleAuthors = article.getElementsByTagName("article-author-id");

            for (int j = 0; j < articleAuthors.getLength(); j++) {
                Element articleAuthor = (Element)articleAuthors.item(j);
                String authorID = articleAuthor.getAttribute("id");

                Element cloned = ((Element)article.cloneNode(true));
                xmlDocument.renameNode(cloned, xmlDocument.getNamespaceURI(), "author-article");

                Element author = getAuthorById(xmlDocument, authorID);
                if (author != null) author.appendChild(cloned);
            }
        }

        Node articlesNode = root.getElementsByTagName("articles").item(0);
        articlesNode.getParentNode().removeChild(articlesNode);
    }
}
