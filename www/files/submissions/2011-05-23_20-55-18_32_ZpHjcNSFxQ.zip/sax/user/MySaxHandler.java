package user;

/**
 * MOJE ZADANI (domaci uloha 6 - SAX)
 * Spocitat charakteristiky:
 * 1) pocet elementu, ktere maji atributy
 * 2) celkovy pocet atributu v dokumentu
 * 3) prumerna delka textoveho obsahu elementu (zahrnout elementy s textovym obsahem)
 * 4) maximalni fan-out (tj. pocet podelementu elementu)
 */

import org.xml.sax.helpers.DefaultHandler; 

import java.util.Collection;
import java.util.HashMap;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;
import java.util.Stack;
import java.util.Iterator;

/**
 * Nas vlastni content handler pro obsluhu SAX udalosti.
 * Implementuje metody interface ContentHandler. 
 */ 
public class MySaxHandler extends DefaultHandler  {	
    // Umoznuje zacilit misto v dokumentu, kde vznikla aktualni udalost
    Locator locator;
    
    // Pomocne promenne pro ukoly
    
    // pro ukol 1 - pocet elementu s atributy
    private int elementsWithAttributes = 0;
    // pro ukol 2 - pocet atributu
    private int totalAttributesCount = 0;
    // pro ukol 3 - prumerna delka textoveho elementu
    private int averageElementTextLengthCount = 0;
    private int averageElementTextLength = 0;   
    private String currentElemName;
    private String currentElemContent;      
    // pro ukol 4 - fanout        
    private int currentElementID; 
    private HashMap dictionary;
    private Stack elementTree;
        
    /**
     * Nastavi locator
     */     
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Obsluha udalosti "zacatek dokumentu"
     */     
    public void startDocument() throws SAXException {    	
    	this.currentElementID = 0;
    	this.dictionary = new HashMap();
    	this.elementTree = new Stack();
    }
    /**
     * Obsluha udalosti "konec dokumentu"
     */     
    public void endDocument() throws SAXException {       
    	// 1. pocet elementu, ktere maji atributy
    	System.out.println("1. pocet elementu s atributy = " + this.elementsWithAttributes);

    	// 2. pocet atributu v dokumentu
    	System.out.println("2. pocet atributu v dokumentu = " + this.totalAttributesCount);
    	
    	// 3. prumerna delka textoveho elementu
    	System.out.println("3. prumerna delka = " + ((double)averageElementTextLength / this.averageElementTextLengthCount));
    	
    	// 4. maximalni fan-out (pocet podelementu)
    	int maximalFanOut = 0;
    	// Projdu ulozenou kolekci fanout pro jednotlive elementy a vyberu maximum
    	for (Iterator iter = this.dictionary.values().iterator(); iter.hasNext();) {
			Integer fanout = (Integer) iter.next();			   
			if (fanout > maximalFanOut) {
				maximalFanOut = fanout;
			}
    	}
    	System.out.println("4. fanout = " + maximalFanOut);
    }
    
    /**
     * Obsluha udalosti "zacatek elementu".
     * @param uri URI jmenneho prostoru elementu (prazdne, pokud element neni v zadnem jmennem prostoru)
     * @param localName Lokalni jmeno elementu (vzdy neprazdne)
     * @param qName Kvalifikovane jmeno (tj. prefix-uri + ':' + localName, pokud je element v nejakem jmennem prostoru, nebo localName, pokud element neni v zadnem jmennem prostoru)
     * @param atts Atributy elementu     
     */     
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

    	// Ukol 1. Pripocitat element k poctu elementu s atributy, pokud nejake existuji
    	if (atts.getLength() > 0) {
    		this.elementsWithAttributes++;
    	}
    	
    	// Ukol 2. Pricist atributy elementu k celkovemu poctu atributu
    	this.totalAttributesCount += atts.getLength();   	
        	    	
    	// Ukol 3. delka textoveho elementu
    	this.currentElemName = qName;
    	this.currentElemContent = "";    	
    	
    	// Ukol 4.
    	if (currentElemName != "") {
    		// Pridat aktualni uzel na zasobnik    		
    		this.currentElementID++;
    		this.elementTree.push(this.currentElementID);
    		this.dictionary.put(this.currentElementID, 0);
    	}
    	
    	//System.out.println("|" + this.currentElemName + "|" + this.currentElementID + "|");    	
    }
    
    /**
     * Obsluha udalosti "konec elementu"
     * Parametry maji stejny vyznam jako u @see startElement     
     */     
    public void endElement(String uri, String localName, String qName) throws SAXException {
        	    	
    	if (this.currentElemName != "") {
    		// Ukol 3 - pripocitat delku textoveho obsahu
	    	this.averageElementTextLength += this.currentElemContent.length();    	
	    	this.averageElementTextLengthCount++;
	    	
	    	this.currentElemName = "";
	    	this.currentElemContent = "";	    	
    	}
    	
    	// Ukol 4
    	// odstranit aktualni uzel ze zasobniku
    	this.elementTree.pop();	    	
    	// pokud existuje rodic, zapocist mu jednicku do fanout za aktualni prvek
    	if (!this.elementTree.isEmpty()) {
    		Integer parentID = (Integer)this.elementTree.peek();
    		Integer oldValue = (Integer)this.dictionary.get(parentID);	    		
    		this.dictionary.put(parentID, oldValue + 1);	    		
    		//System.out.println("endof " + qName + " fanout=" + (oldValue + 1));
    	}
    }
    
    /**
     * Obsluha udlosti "znakova data".
     * SAX parser muze znakova data davkovat jak chce. Nelze tedy pocitat s tim, ze je cely text dorucen v ramci jednoho volani.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakovymi daty
     * @param start Index zacatku useku platnych znakovych dat v poli.
     * @param length Delka useku platnych znakovych dat v poli.
     */               
    public void characters(char[] ch, int start, int length) throws SAXException {
     
    	if (currentElemName != "") {    		
    		currentElemContent = currentElemContent + new String(ch, start, length);
    	}
    }
    
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
    }

    public void endPrefixMapping(String prefix) throws SAXException {
    
        // ...
    
    }

        
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
        // ...
        
    }

    public void processingInstruction(String target, String data) throws SAXException {
      
      // ...
            
    }

    public void skippedEntity(String name) throws SAXException {
    
      // ...
    	
    }
}