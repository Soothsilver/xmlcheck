package user;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.NodeList;
import org.w3c.dom.*;
import java.util.ArrayList;

/**
 * MOJE ZADANI:
 * 1) najit ve vstupnim dokumentu takove tagy "zaznam", ktere obsahuji podelement "kontaktovat", jehoz atribut "stav" je roven hodnote "ano" a ktery take ma atribut "kdy"
 * 2) na konci dokumentu vytvorit novy element "plan". V elementu "plan" vytvorit podelementy "plan-kontakt" pro kazdy kontakt z bodu 1.
 * 3) kazdy element "plan-kontakt" bude mit dva atributy - "zakaznikID" a "zaznamID" a v textovem obsahu elementu bude datum z atributu "kdy"
 * 4) osetrit skript tak, aby fungoval i kdyz zadny element "zaznam" v dokumentu neexistuje
 */
public class MyDomTransformer {

    /**
     * Zpracuje DOM strom
     */
    public void transform(Document xmlDocument) {    	
    	// Pole, do ktereho ulozim elementy "zaznam", ktere vyhovuji zadani (1)
    	ArrayList seznamZaznamu = new ArrayList();
        
    	// Nacist vsechny elementy "zaznam" v dokumentu
    	NodeList zaznamy = xmlDocument.getElementsByTagName("zaznam");
    	for (int i = 0; i < zaznamy.getLength(); i++) {
    		Element zaznam = (Element)zaznamy.item(i);
    		
    		// Otestovat, zda element "zaznam" obsahuje podelement "kontaktovat"
    		Element kontaktovatElement = this.getKontaktovatElement(zaznam); 
    		if (kontaktovatElement == null) {
    			continue;
    		}
    		    		    	
    		// Otestovat, zda element "kontaktovat" obsahuje pozadovane atributy    		
    		if (!(kontaktovatElement.hasAttribute("kdy") 
    				&& kontaktovatElement.hasAttribute("stav") 
    				&& "ano".equals(kontaktovatElement.getAttribute("stav")))) {
    			continue;
    		}    		
    		
    		// Podminky splneny, ulozim element na pozdeji
    		seznamZaznamu.add(zaznam);
    	}
    	
    	// Projdu vsechny elementy "zaznam", ktere splnuji podminky zadani a pro kazdy vytvorim pozadovany vystup
    	// Zalozim element "plan" pro ulozeni vysledku
    	Element plan = xmlDocument.createElement("plan");
    	for (int i = 0; i < seznamZaznamu.size(); i++) {
    		// Ulozeny "zaznam"
    		Element zaznam = (Element)seznamZaznamu.get(i);
    		// a jeho atributy
    		String zaznamID = zaznam.getAttribute("id");
    		String zakaznikID = zaznam.getAttribute("zakaznik");
    		
    		// Zalozim element "plan-kontakt" a naplnim data 
    		Element planKontakt = xmlDocument.createElement("plan-kontakt");
    		planKontakt.setAttribute("zaznamID", zaznamID);
    		planKontakt.setAttribute("zakaznikID", zakaznikID);
    		
    		Element kontaktovatElement = this.getKontaktovatElement(zaznam);
    		String when = kontaktovatElement.getAttribute("kdy");
    		planKontakt.appendChild(xmlDocument.createTextNode(when));
    		
    		// Pridam "plan-kontakt" do seznamu
    		plan.appendChild(planKontakt);
    	}
    	
    	// Nakonec pridam element "plan" do dokumentu
    	xmlDocument.getDocumentElement().appendChild(plan);
    }
    
    // Pomocna metoda - najde element "kontaktovat" v ramci elementu "zaznam"
    private Element getKontaktovatElement(Element zaznam) {    	    	
    	NodeList children = zaznam.getChildNodes();		
		for (int j = 0; j < children.getLength(); j++) {    
			Node child = children.item(j);
			if (child.getNodeName() == "kontaktovat" && child.getNodeType() == org.w3c.dom.Node.ELEMENT_NODE) {
				return (Element)child;				
			}
		}
		return null;
    }
}

