
package user;

import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.helpers.DefaultHandler;

class CoordinatesCounter {

    // index je roven (souradnice - 1)
    private int[] quantities = new int[10];

    public void addCoordinate(int coordinate) {
        quantities[coordinate - 1] = quantities[coordinate - 1] + 1;
    }

    public int getMostUsedCoordinate() {
        int index = -1;
        int index_score = -1;

        for (int i = 0; i != quantities.length; ++i) {
            if (quantities[i] > index_score) {
                index_score = quantities[i];
                index = i;
            }
        }

        // souradnice je o 1 vetsi nez index jejiho vyskytu
        return index + 1;
    }
}

public class MySaxHandler extends DefaultHandler {

    private Locator locator;
    private CoordinatesCounter counter;
    private StringBuilder builder;
    private int wordLengths;
    private int wordCount;
    private int agentNameLength;
    private String gender;
    private String lastGender;
    private boolean right_sector;
    private String portal_id;
    private int portal_line;

    public MySaxHandler() {
        this.counter = new CoordinatesCounter();
        this.builder = new StringBuilder();
        this.wordLengths = 0;
        this.wordCount = 0;
        this.agentNameLength = Integer.MAX_VALUE;
        this.gender = "zadny agent nebyl nenalezen";
        this.right_sector = false;
    }

    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    @Override
    public void startDocument() {
    }

    @Override
    public void endDocument() {
        System.out.println("Zpracovani XML dokumentu pomoci SAX:\n");
        
        System.out.print("Nejcastejsi souradnice dlazdice: ");
        System.out.println(counter.getMostUsedCoordinate());

        System.out.print("Prumerna delka jmena agenta: ");
        System.out.println(wordLengths / wordCount);

        System.out.print("Pohlavi agenta s nejkratsim jmenem: ");
        System.out.println(gender);

        System.out.print("Na jakem radku je definovan portal, jez ma odkaz v 3. sektoru: ");
        System.out.println(portal_line);
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) {
        // pocita nejcastejsi vyskyt hodnoty souradnice (atributy elementu "tile")
        if (localName.equals("tile")) {
            for (int i = 0; i != attributes.getLength(); ++i) {
                int coordinate = Integer.parseInt(attributes.getValue(i));

                counter.addCoordinate(coordinate);
            }
        }

        // pamatuje si posledni pohlavi
        if (localName.equals("agent")) {
            lastGender = attributes.getValue("gender");
        }
        
        // resi vyskyt reference na portal a spravneho sektoru
        if(localName.equals("sector") && attributes.getValue("id").equals("S3")){
            right_sector = true;
        }
        
        if(right_sector && localName.equals("portal_ref")){
            portal_id = attributes.getValue("id");
        }
        
        if(localName.equals("portal") && attributes.getValue("id").equals(portal_id)){
            portal_line = locator.getLineNumber();
        }
            

        // smazani obsahu bufferu skladajiciho znaky z funkce "characters"
        builder.delete(0, builder.length());
    }

    @Override
    public void endElement(String uri, String localName, String qName) {
        if (localName.equals("name")) {
            //pocita delku jmena agenta a uklada jeho pohlavi
            if (agentNameLength > builder.length() && lastGender != null) {
                agentNameLength = builder.length();
                gender = lastGender;
            }

            // pocita dilci casti prumeru delky jmen
            wordLengths += builder.length() - 2;    // odecteni uvozovek z delky jmena
            wordCount++;
        }
        
        // "vynulovani" promenne po opusteni spravneho sektoru
        if(localName.equals("sector")){
            right_sector = false;
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) {
        builder.append(ch, start, length);
    }
}
