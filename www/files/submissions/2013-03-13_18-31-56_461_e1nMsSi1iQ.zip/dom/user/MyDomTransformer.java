package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

class SectorCreator {

    static final String SECTOR = "sector";
    static final String ID = "id";
    static final String BIRTHPLACES = "local_birthplaces";
    static final String BIRTHPLACES_COMMENT = " seznam rodist daneho sektoru ";
    static final String PORTALS = "local_portals";
    static final String PORTALS_COMMENT = " seznam portalu daneho sektoru ";
    static final String AGENTS = "local_agents";
    static final String AGENTS_COMMENT = " seznam agentu v danem sektoru ";
    static final String GRID = "grid";
    static final String GRID_COMMENT = " sit dlazdic sektoru ";
    static final String TILE = "tile";

    private static Element createSector(Document xmlDocument, String id) {
        Element new_sector = xmlDocument.createElement(SECTOR);

        new_sector.setAttribute(ID, id);

        new_sector.appendChild(xmlDocument.createComment(BIRTHPLACES_COMMENT));
        new_sector.appendChild(xmlDocument.createElement(BIRTHPLACES));
        new_sector.appendChild(xmlDocument.createComment(PORTALS_COMMENT));
        new_sector.appendChild(xmlDocument.createElement(PORTALS));
        new_sector.appendChild(xmlDocument.createComment(AGENTS_COMMENT));
        new_sector.appendChild(xmlDocument.createElement(AGENTS));
        new_sector.appendChild(xmlDocument.createComment(GRID_COMMENT));

        Element grid = xmlDocument.createElement(GRID);

        Element tile;

        // vytvoreni dlazdic noveho sektoru
        for (int i = 0; i != 5; ++i) {
            tile = xmlDocument.createElement(TILE);
            tile.setAttribute("x", "1");
            tile.setAttribute("y", Integer.toString(i + 1));

            grid.appendChild(tile);
        }

        new_sector.appendChild(grid);

        return new_sector;
    }

    private static String generateNextSectorId(String id) {
        // rozparsovani id sektoru
        char firstCharacter = id.charAt(0);
        String sectorNumber = id.substring(1);

        // id noveho sektoru
        int numberOfNextSector = Integer.parseInt(sectorNumber) + 1;

        // zpetne slozeni id noveho sektoru
        return firstCharacter + Integer.toString(numberOfNextSector);
    }

    private static Node getLastSector(Node root) {
        // ziskani odkazu na vsechny sektory
        NodeList agent_references = ((Element) root).getElementsByTagName(SECTOR);

        return agent_references.item(agent_references.getLength() - 1);
    }

    public static void addNewSector(Document xmlDocument) {
        // prechod na korenovy element
        Node root = xmlDocument.getDocumentElement();

        // ziskani posledniho sektoru
        Node lastSector = getLastSector(root);

        // prechod na id posledniho sektoru
        String id = lastSector.getAttributes().getNamedItem(ID).getNodeValue();

        // vytvoreni a pridani noveho sektoru s novym id
        lastSector.getParentNode().appendChild(xmlDocument.createComment(" sektor vytvoreny pomoci DOM rozhrani "));
        lastSector.getParentNode().appendChild(createSector(xmlDocument, generateNextSectorId(id)));
    }
}

class AgentManager {

    static final String AGENT = "agent";
    static final String GENDER = "gender";
    static final String ID = "id";
    static final String AGENT_REF = "agent_ref";
    static final String DELETE_COMMENT = " zde byl odebran odkaz na agenta ";

    private static String getAgentId(Node root) {

        NodeList agents = ((Element) root).getElementsByTagName(AGENT);
        NamedNodeMap attributes;

        for (int i = 0; i != agents.getLength(); ++i) {
            attributes = agents.item(i).getAttributes();

            // test na existenci atributu gender
            if (attributes.getNamedItem(GENDER) == null) {
                return attributes.getNamedItem(ID).getNodeValue();
            }
        }

        return null;
    }

    private static void deleteAgentReferences(Document xmlDocument, Node root, String id) {
        // ziskani vsech odkazu na agenty
        NodeList agent_references = ((Element) root).getElementsByTagName(AGENT_REF);

        for (int i = agent_references.getLength() - 1; i >= 0; --i) {
            Node child = agent_references.item(i);

            // ziskani id reference
            String local_id = child.getAttributes().getNamedItem(ID).getNodeValue();

            if (local_id.equals(id)) {
                child.getParentNode().appendChild(xmlDocument.createComment(DELETE_COMMENT));

                // vlastni odebrani reference na agenta
                child.getParentNode().removeChild(child);
            }
        }
    }

    public static void deleteGenderlessAgentReferences(Document xmlDocument) {
        Node root = xmlDocument.getDocumentElement();

        String id = getAgentId(root);

        // smaze vsechny reference agenta s danym id
        deleteAgentReferences(xmlDocument, root, id);
    }
}

public class MyDomTransformer {

    public void transform(Document xmlDocument) {
        // pridani noveho sektoru
        SectorCreator.addNewSector(xmlDocument);

        // smazani odkazu na prvniho agenta bez uvedeneho pohlavi
        AgentManager.deleteGenderlessAgentReferences(xmlDocument);
    }
}
