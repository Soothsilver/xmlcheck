// Spocita pocet elementu ktere obsahuji textovy obsah;
// ignoruje pritom bile znaky.
// Vysledek vypise do konzole.
// Pouziva zasobnik, protoze je potreba urcit, ke kteremu elementu dany text patri.

package user;

import java.util.Stack;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;

public class MySaxHandler extends DefaultHandler
{
  Stack<Boolean> hasTextStack = new Stack<Boolean>();
  int hasTextCount;

  @Override
  public void startDocument()
  {
    hasTextCount = 0;
  }

  @Override
  public void startElement(String uri, String localName, String qName, Attributes attributes)
  {
    hasTextStack.push(false);
  }

  @Override
  public void characters(char[] ch, int start, int length)
  {
    String str = new String(ch, start, length);
    if (str.trim().length() > 0)
    {
      hasTextStack.pop();
      hasTextStack.push(true);
    }
  }

  @Override
  public void endElement(String uri, String localName, String qName)
  {
    if (hasTextStack.pop())
      hasTextCount++;
  }

  @Override
  public void endDocument()
  {
    System.out.println("Elements with text content: " + hasTextCount);
  }
}
