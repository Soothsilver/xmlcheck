package user;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

public class Program
{
    public static void main(String[] args) {

        // Cesta ke zdrojovemu XML dokumentu  
        String sourcePath = "..\\data.xml";

        try {
            
            // Vytvorime instanci parseru.
            XMLReader parser = XMLReaderFactory.createXMLReader();
            
            // Vytvorime vstupni proud XML dat.
            InputSource source = new InputSource(sourcePath);
            
            // Nastavime nas vlastni content handler pro obsluhu SAX udalosti.
            parser.setContentHandler(new MySaxHandler());
            
            // Zpracujeme vstupni proud XML dat.
            parser.parse(source);
            
        } catch (Exception e) {
        
            e.printStackTrace();
            
        }
        
    }
}
