package user;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

public class Program
{
    public static void main(String[] args) {

        // Cesta ke zdrojovemu XML dokumentu  
        String sourcePath = "..\\data.xml";

        try {
            //DocumentBuilderFactory vytvari DOM parsery
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            //nebudeme validovat
            dbf.setValidating(false);

            //vytvorime si DOM parser
            DocumentBuilder builder = dbf.newDocumentBuilder();

            //parser zpracuje vstupni soubor a vytvori z nej strom DOM objektu
            Document doc = builder.parse(sourcePath);

            //zpracujeme DOM strom
            new MyDomTransformer().transform(doc);

            //TransformerFactory vytvari serializatory DOM stromu
            TransformerFactory tf = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer = tf.newTransformer();

            //spustime transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(System.out));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
