package user;
import org.w3c.dom.*;

// *****************************************************
// * prevedieme atributy na elementy s textovy obsahom *
// *****************************************************
public class MyDomTransformer { 

 public static void transform (Document xmlDocument) { 
     NodeList list = xmlDocument.getElementsByTagName("titul");
     
     for (int i = 0; i < list.getLength(); i++) {
         Node currentNode = list.item(i);
         Element currentTitleElement = ((Element)list.item(i));
         NamedNodeMap attributes = currentNode.getAttributes();
         
         for (int j = 0; j < attributes.getLength(); j++) {
             Attr attr = (Attr)attributes.item(j);
             String attrName = attr.getName();
             String attrValue = attr.getValue();
             
             Element newElement = xmlDocument.createElement(attrName);
             newElement.appendChild(xmlDocument.createTextNode(attrValue));
             
             currentTitleElement.removeAttribute(attrName);
             currentTitleElement.appendChild(newElement);
         }
     }
     
          list = xmlDocument.getElementsByTagName("kniha");
     
     for (int i = 0; i < list.getLength(); i++) {
         Node currentNode = list.item(i);
         Element currentBookElement = ((Element)list.item(i));
         NamedNodeMap attributes = currentNode.getAttributes();
         
         for (int j = 0; j < attributes.getLength(); j++) {
             Attr attr = (Attr)attributes.item(j);
             String attrName = attr.getName();
             String attrValue = attr.getValue();
             
             Element newElement = xmlDocument.createElement(attrName);
             newElement.appendChild(xmlDocument.createTextNode(attrValue));
             
             currentBookElement.removeAttribute(attrName);
             currentBookElement.appendChild(newElement);
         }
     }
 } 
}