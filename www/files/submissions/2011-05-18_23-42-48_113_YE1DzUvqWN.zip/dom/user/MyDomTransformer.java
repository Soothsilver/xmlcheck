package user;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author kolage
 */
public class MyDomTransformer {

    /**
     * @param args the command line arguments
     */
    static final String inputFile = "data.xml";
    static final String outputFile = "out.xml";

    public void transform(Document doc) throws XPathExpressionException {
        
        /** Zpracovani pomocniku - premena na slozene elementy **/
        NodeList pomocnici_list = doc.getElementsByTagName("pomocnici");
        int delkaPomocnici = pomocnici_list.getLength();
        for(int i = 0; i < delkaPomocnici; i++) {
    		Element pomocnici = (Element)pomocnici_list.item(i);
                Element parentPomocnici = (Element)pomocnici.getParentNode();
                Node newPomocnici = doc.createElement("pomocnici");
                NodeList children = pomocnici.getChildNodes();
                String prezdivka = ""; String jmeno = "";
                int delkaChildren = children.getLength();
                int j = 0;
                while(j < delkaChildren) {
                    Node node = children.item(j);
                    if(node.getNodeType() == Node.TEXT_NODE) {                        
                        String[] pole = node.getTextContent().split("\\s+");
                        for(String retez : pole) {
                            if(!retez.isEmpty()) {
                                if(prezdivka.isEmpty())
                                    prezdivka += retez;
                                else
                                    prezdivka += " " + retez;
                            }
                        }
                    }
                    if(node.getNodeType() == Node.ELEMENT_NODE) {
                        try {
                            jmeno = node.getAttributes().item(0).getTextContent();
                        }
                        catch(ArrayIndexOutOfBoundsException e) {
                            jmeno = "NoName";
                        }
                    }
                    if(!prezdivka.isEmpty() && !jmeno.isEmpty()) {
                        Node pomocnikNode = doc.createElement("pomocnik");
                        Node jmenoNode = doc.createElement("jmeno");
                        Node prezdivkaNode = doc.createElement("prezdivka");
                        jmenoNode.appendChild(doc.createTextNode(jmeno));
                        prezdivkaNode.appendChild(doc.createTextNode(prezdivka));
                        pomocnikNode.appendChild(jmenoNode);
                        pomocnikNode.appendChild(prezdivkaNode);
                        newPomocnici.appendChild(pomocnikNode);
                        prezdivka = "";
                        jmeno = "";
                        
                    }
                    j++;
                }  
                parentPomocnici.removeChild(pomocnici);
                parentPomocnici.appendChild(newPomocnici);              		            
    	}
        
        /** Transformace elitnich zavodniku **/
        NodeList vysledky_list = doc.getElementsByTagName("vysledek");
        int delkaVysledky = vysledky_list.getLength();
        XPathFactory factory = XPathFactory.newInstance();
        XPath xpath = factory.newXPath();
        for(int i = 0; i < delkaVysledky; i++) {
            Node vysledek = vysledky_list.item(i);
            String kod = vysledek.getAttributes().getNamedItem("kod").getNodeValue();
            // XPath vyraz, ktery nam vrati zavodniky daneho zavodu
            XPathExpression expr = xpath.compile("//zavodnik[ancestor::vysledek/@kod='" + kod + "']");
            Object result = expr.evaluate(doc, XPathConstants.NODESET);
            NodeList zavodnici = (NodeList) result;
            String jmeno = ""; String licence = "";
            int delkaZavodnici = zavodnici.getLength();
            Node elitaci = doc.createElement("elita");
            for(int j = 0; j < delkaZavodnici; j++) {
                Node zavodnik = zavodnici.item(j);
                NodeList zavodnikChilds = zavodnik.getChildNodes();
                int delkaZavodnik = zavodnikChilds.getLength();
                for(int k = 0; k < delkaZavodnik; k++) {
                    Node nodeZ = zavodnikChilds.item(k);
                    if(nodeZ.getNodeName().equals("jmeno")) {
                        jmeno = nodeZ.getFirstChild().getNodeValue();
                    } else
                    if(nodeZ.getNodeName().equals("licence")) {
                        licence = nodeZ.getFirstChild().getNodeValue();
                    }
                }
                if(licence.equals("E")) {
                    Node n = doc.createElement("jmeno");
                    n.appendChild(doc.createTextNode(jmeno));
                    elitaci.appendChild(n);
                }
            }
            vysledek.appendChild(elitaci);
        }
        
        /** Predelani datumu v souboru **/
        NodeList datumy_list = doc.getElementsByTagName("datum");
        int delkaDatum = datumy_list.getLength();
        for(int i = 0; i < delkaDatum; i++) {
            Node datum = datumy_list.item(i);
            String[] pole = datum.getTextContent().split("-");
            Node rok = doc.createElement("rok");
            Node mesic = doc.createElement("mesic");
            Node den = doc.createElement("den");
            rok.appendChild(doc.createTextNode(pole[0]));
            mesic.appendChild(doc.createTextNode(pole[1]));
            den.appendChild(doc.createTextNode(pole[2]));
            datum.setTextContent("");
            datum.appendChild(rok);
            datum.appendChild(mesic);
            datum.appendChild(den);
        }
    }
}
