package user;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * @author kolage
 */

public class MySaxHandler extends DefaultHandler {
  
    Locator locator;
    boolean zav = false;
    boolean jm = false;
    boolean reg = false;
    boolean od = false;
    
    Zavodnik zavodnik;
    
    String kodZ = "";
    String oddil = "";
    String jmeno = "";
    int umisteni = 0;
    
    class Zavodnik {
        String reg;
        String jmeno;
        int nej_umisteni;
        String zavod;
        
        void setReg(String reg) {
            this.reg = reg;
        }
        
        void setJmeno(String jmeno) {
            this.jmeno = jmeno;
        }
        
        void setUm(int um) {
            nej_umisteni = um;
        }
        
        void setZavod(String zavod) {
            this.zavod = zavod;
        }
        
        String getReg() {
            return reg;
        }
        
        String getJmeno() {
            return jmeno;
        }
        
        int getUmisteni() {
            return nej_umisteni;
        }
        
        String getZavod() {
            return zavod;
        }
        
    }
    
    Map<String, Map<String, Zavodnik>> oddily = new HashMap<String, Map<String, Zavodnik>>();

    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    @Override
    public void endDocument() throws SAXException {
        Set<String> klice = oddily.keySet();
        for(String tym : klice) {
            System.out.println("*** Oddil " + tym + " ***");
            for(Zavodnik bezec : oddily.get(tym).values()) {
                System.out.println("Jmeno: " + bezec.getJmeno());
                System.out.println("-- Registracka: " + bezec.getReg());
                System.out.println("-- Nej umisteni: " + bezec.getUmisteni());
                System.out.println("-- Zavod: " + bezec.getZavod());
            }
        }
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        if(qName.equals("vysledek")) {
            kodZ = atts.getValue(0);
        }
        
        if(qName.equals("umisteni")) {
            umisteni = Integer.parseInt(atts.getValue(0));
        }
        
        if(qName.equals("zavodnik")) {
            zav = true;
        }
        
        if(zav && qName.equals("jmeno")) {
            jm = true;
        }
        
        if(zav && qName.equals("oddil")) {
            od = true;
        }
        
        if(zav && qName.equals("reg")) {
            reg = true;
        }
        
        
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if(qName.equals("zavodnik")) {
            zav = false;
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        if(jm) {
            zavodnik = new Zavodnik();
            zavodnik.setJmeno(new String(ch,start,length));
            jm = false;
        }
        
        if(reg) {
            zavodnik.setReg(new String(ch,start,length));
            
            if(oddily.get(oddil) == null)
                oddily.put(oddil, new HashMap<String, Zavodnik>());
            if(oddily.get(oddil).get(zavodnik.reg) == null) {
                zavodnik.setUm(umisteni);
                zavodnik.setZavod(kodZ);
                oddily.get(oddil).put(zavodnik.getReg(), zavodnik);
            }
            else {
                Zavodnik stary = oddily.get(oddil).get(zavodnik.getReg());
                if(stary.getUmisteni() > umisteni) {
                    stary.setUm(umisteni);
                    stary.setZavod(kodZ);
                }
            }
            
            reg = false;
            
        }
        
        if(od) {
            oddil = new String(ch,start,length);
            od = false;
        }
    }
}
