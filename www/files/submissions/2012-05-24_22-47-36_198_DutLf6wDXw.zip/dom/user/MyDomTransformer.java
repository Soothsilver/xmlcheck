
import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

public class MyDomTransformer {

    private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "data.out.xml";

    public static void main(String[] args) {

	try {
	    DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
	    dbf.setValidating(false);
	    DocumentBuilder builder = dbf.newDocumentBuilder();
	    Document doc = builder.parse(VSTUPNI_SOUBOR);
	    processTree(doc);
	    TransformerFactory tf = TransformerFactory.newInstance();
	    Transformer writer = tf.newTransformer();
	    writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
	    writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


	} catch (Exception e) {

	    e.printStackTrace();

	}
    }

    private static void processTree(Document doc) {
	Element root = (Element)doc.getElementsByTagName("spravci").item(0);
	NodeList spravci = root.getElementsByTagName("spravce");
	for(int i = 0; i < spravci.getLength(); i++){
	    Element s = (Element)spravci.item(i);
	    transform(s, doc);        	
	}
	
	
    }
    
    private static void transform(Element s, Document doc) {
	Element eJmeno = (Element)s.getElementsByTagName("jmeno").item(0);
	Element eKrestni = (Element)eJmeno.getElementsByTagName("krestni").item(0);
	String krestni = eKrestni.getTextContent();
	eJmeno.setAttribute("krestni", krestni);
	eJmeno.removeChild(eKrestni);
	Element ePrijmeni = (Element)eJmeno.getElementsByTagName("prijmeni").item(0);
	String prijmeni = ePrijmeni.getTextContent();
	eJmeno.setAttribute("prijmeni", prijmeni);
	eJmeno.removeChild(ePrijmeni);
    }
}
