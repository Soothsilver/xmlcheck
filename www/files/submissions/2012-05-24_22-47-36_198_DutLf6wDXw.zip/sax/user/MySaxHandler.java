
import java.util.LinkedList;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;

public class MySaxHandler {

    public static void main(String[] args) {
	String sourcePath = "data.xml";

	try {

	    XMLReader parser = XMLReaderFactory.createXMLReader();

	    InputSource source = new InputSource(sourcePath);

	    parser.setContentHandler(new MujContentHandler());

	    parser.parse(source);

	} catch (Exception e) {

	    e.printStackTrace();

	}

    }
}

class MujContentHandler implements ContentHandler {

    Locator locator;

    public void setDocumentLocator(Locator locator) {
	this.locator = locator;
    }

    public void startDocument() throws SAXException {

    }

    public void endDocument() throws SAXException {
	System.out.println("pocet spravcu: " + pocetSpravcu);
	System.out.println("prumerna delka nazvu dluznika: " + celkovaDelkaNazvu/pocetNazvu);
    }

    boolean spravciJsouTady;
    boolean spravceJeTady;
    int pocetSpravcu = 0;
    
    boolean dluznikJeTady;
    boolean nazevJeTady;
    int pocetNazvu;
    int celkovaDelkaNazvu;

    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
	if (localName.equals("spravci")) { spravciJsouTady = true; }
	if (localName.equals("spravce") && spravciJsouTady) { spravceJeTady = true; pocetSpravcu++; }
	
	if (localName.equals("dluznik")) { dluznikJeTady = true; }
	if (localName.equals("nazev") && dluznikJeTady) { nazevJeTady = true; pocetNazvu++; }
    }

    public void endElement(String uri, String localName, String qName) throws SAXException {
	if (localName.equals("spravci")) { spravciJsouTady = false; }
	if (localName.equals("spravce")) { spravceJeTady = false; }
	
	if (localName.equals("dluznik")) { dluznikJeTady = false; }
	if (localName.equals("nazev")) { nazevJeTady = false; }
    }

    public void characters(char[] ch, int start, int length) throws SAXException {
	if (nazevJeTady) { celkovaDelkaNazvu += length; }
    }

    public void startPrefixMapping(String prefix, String uri) throws SAXException {
    }

    public void endPrefixMapping(String prefix) throws SAXException {
    }

    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
    }

    public void processingInstruction(String target, String data) throws SAXException {
    }

    public void skippedEntity(String name) throws SAXException {
    }
}