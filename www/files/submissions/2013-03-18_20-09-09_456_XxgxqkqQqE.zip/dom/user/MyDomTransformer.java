package user;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class MyDomTransformer {
    
    /**
     * Realizace ulohy 1: Vytvori testovaci zakazku a vlozi ji do dokumentu.
     * Vytvoreni nove zakazky - uzivatel muze pomoci trid ContractState, 
     * PersonName, Adress a ContractInfo zadat data nove zakazky a nasledne 
     * pridat zakazku na spravne misto do dokumentu.
     * @param document 
     */
    public void addTestContract(Document document)
    {
        System.out.println("DOM1: Pridani nove zakazky");
        try {
            PersonName chief = new PersonName("James", "Cameron");
            Adress adress = new Adress("Shakespeare street", "25", "Stanford", "254 22");
            ContractInfo contract = new ContractInfo(3, "2495", "Heliport stanford", chief, adress);

            SimpleDateFormat formatter = new SimpleDateFormat ("dd.MM.yyyy"); 
            contract.setStartDate(formatter.parse("18.3.2013"));
            contract.setPlannedEndDate(formatter.parse("26.8.2015"));
            contract.setContractState(ContractState.Processing);

            contract.InsertNewElemIntoDocument(document);

        } catch (ParseException ex) {

        }
    }
    
    /**
     * Realizace ulohy 2: Smazani klienta a vsech jeho zakazek.
     * Metoda vyhleda klienta se zadanym ID a odstrani jej ze sekce Klienti.
     * Dale projde vsechny zakazky a odstrani zakazky, kde je klient nastaven 
     * jako odberatel.
     * @param clientID
     * @param document 
     */
    public void deleteClient(int clientID, Document document)
    {
        System.out.println(String.format("DOM2: Smazani klienta %d a vsech jeho zakazek", clientID));
        String kid = "k_" + clientID;
        
        NodeList clients = document.getElementsByTagName("Klient");
        for (int x = 0; x < clients.getLength(); x++)
        {
            Element client = (Element) clients.item(x);
            if (client.getAttribute("kid").equals(kid))
            {
                client.getParentNode().removeChild(client);
                break;
            }
        }
        
        NodeList contracts = document.getElementsByTagName("Zakazka");
        for (int x = 0; x < contracts.getLength(); x++)
        {
            Element contract = (Element) contracts.item(x);
            if (contract.getAttribute("Odberatel").equals(kid))
            {
                contract.getParentNode().removeChild(contract);
                x--;
            }
        }
    }
    
    public void transform(Document xmlDocument) { 
        System.out.println();
        addTestContract(xmlDocument);
        deleteClient(2, xmlDocument);
    }
    
    /**
     * Vytvori novy textovy element a vlozi jej jako podelement do zadaneho 
     * rodicovskeho elementu.
     * @param elemName
     * @param elemValue
     * @param parent
     * @param doc 
     */
    void createSubElem(String elemName, String elemValue, Element parent, Document doc)
    {
        Element newElem = doc.createElement(elemName);
        newElem.appendChild(doc.createTextNode(elemValue));
        parent.appendChild(newElem);
    }
    
    /**
     * Pro vsechny zadane hodnoty vytvori nove textove elementy a vlozi je jako 
     * podelementy do zadaneho rodicovskeho elementu.
     * @param elemName
     * @param elemValues
     * @param parent
     * @param doc 
     */
    void createSubElems(String elemName, ArrayList elemValues, Element parent, Document doc)
    {
        for (Object val : elemValues)
        {
            createSubElem(elemName, val.toString(), parent, doc);
        }
    }

    /** Pomocne tridy k uloze 1 ***********************************************************************************/

    /**
     * Zapouzdreni vyctoveho atributu StavStavby. 
     */
    enum ContractState
    {
        Study("Studie"), Processing("Probiha"), Done("Ukoncena");
        
        String text;
        
        ContractState(String text)
        {
            this.text = text;
        }
        public String getText()
        {
            return text;
        }
    }
    
    /**
     * Zapouzdreni elementu JmenoOsoby s podelementy ve tvaru (Titul*, Jmeno, Jmeno*, Prijmeni, Titul*).
     * Umoznuje zadat jmeno, prijmeni, tituly pred a za jmenem a dalsi jmena.
     */
    class PersonName
    {
        String firstname, surename;
        ArrayList otherNames = new ArrayList();
        ArrayList titularBefore = new ArrayList();
        ArrayList titularAfter = new ArrayList();
        
        public PersonName(String firstname, String surename)
        {
            this.firstname = firstname;
            this.surename = surename;
        }
        
        /**
         * Vygeneruje vyhovujici element se jmenem osoby s vyuzitim zadanych dat.
         * @param document
         * @return 
         */
        public Element createElement(Document document)
        {
            Element personName = document.createElement("JmenoOsoby");
            createSubElems("Titul", titularBefore, personName, document);
            createSubElem("Jmeno", firstname, personName, document);
            createSubElems("Jmeno", otherNames, personName, document);
            createSubElem("Prijmeni", surename, personName, document);
            createSubElems("Titul", titularAfter, personName, document);
            
            return personName;
        }
        
        public void setFirstname(String name)
        {
            firstname = name;
        }
        public void setSurename(String name)
        {
            surename = name;
        }
        public void addMidleName(String name)
        {
            otherNames.add(name);
        }
        public void addTitularAfter(String t)
        {
            titularBefore.add(t);
        }
        public void addTitularBefore(String t)
        {
            titularAfter.add(t);
        }
    }
    
    /**
     * Zapouzdreni elementu Adresa s podelementy ve tvaru (Ulice?, CisloPopisne?, Obec, PSC).
     */
    class Adress
    {
        String street = null, houseNumber = null, city, postalCode;
        

        public Adress(String city, String postalCode)
        {
            this.city = city;
            this.postalCode = postalCode;
        }
        
        public Adress(String street, String houseNumber, String city, String postalCode)
        {
            this.street = street;
            this.houseNumber = houseNumber;
            this.city = city;
            this.postalCode = postalCode;
        }  
        
        /**
         * Vygeneruje vyhovujici element s adresou podle zadanych dat.
         * @param document
         * @return 
         */
        public Element createElement(Document document)
        {
            Element adress = document.createElement("Adresa");
            if (street != null) createSubElem("Ulice", street, adress, document);
            if (houseNumber != null) createSubElem("CisloPopisne", houseNumber, adress, document);
            createSubElem("Obec", city, adress, document);
            createSubElem("PSC", postalCode, adress, document);
            
            return adress;
        }
        
        public void setStreet(String value)
        {
            street = value;
        }
        public void setHouseNumber(String value)
        {
            houseNumber = value;
        }
        public void setCity(String value)
        {
            city = value;
        }
        public void setPostalCode(String value)
        {
            postalCode = value;
        }   
    }
    
    /**
     * Reprezentuje element Zakazka.
     * Umoznuje vytvoreni validniho elementu, nastaveni ID podle maximalni
     * zakazky dokumentu a vlozeni noveho elementu na spravne misto stromu 
     * vcetne pripadneho vytvoreni rodicovskeho elementu.
     * Struktura noveho elementu: (PopisStavby, Stavbyvedouci, MistoPrace, Komentar?)
     */
    class ContractInfo
    {
        int contractId, clientId;
        String contractNumber;
        String contractName;
        String coment = null;
        
        Date startDate = null, endDate = null, plannedEndDate = null;
        ContractState contractState = ContractState.Study;
        
        boolean isPaid = false;
        long paid;
        
        PersonName chiefName; 
        Adress adress;
        
        public ContractInfo(int clientId, String contractNumber, String contractName, PersonName chiefName, Adress adress)
        {
            this.clientId = clientId;
            this.contractNumber = contractNumber;
            this.contractName = contractName;
            this.chiefName = chiefName;
            this.adress = adress;
        }
        
        /**
         * Vytvori novy element a vlozi jej do kolekce Zakazky v ramci dokumentu.
         * Pokud dokument neobsahuje sekci zakazky, tak ji vytvori.
         * @param document 
         */
        public void InsertNewElemIntoDocument(Document document)
        {
            setGreatestUniqueContractId(document);
            
            NodeList contracts = document.getElementsByTagName("Zakazky");
            Element contractsElement;
            if (contracts.getLength() > 0)
            {
                contractsElement =(Element) contracts.item(0);
            }
            else
            {
                contractsElement = document.createElement("Zakazky");
                document.getDocumentElement().appendChild(contractsElement);
            }
            
            contractsElement.appendChild(createElement(document));
        }
             
        /**
         * Vytvori novy element s vyuzitim nastavenych dat.
         * @param document
         * @return 
         */
        public Element createElement(Document document)
        {
            Element contract = document.createElement("Zakazka");
            
            contract.setAttribute("zid", "z_" + Integer.toString(contractId));
            contract.setAttribute("Odberatel", "k_" + Integer.toString(clientId));
            contract.setAttribute("CisloSmlouvy", contractNumber);
            if (startDate != null) contract.setAttribute("DatumZacatkuStavby", startDate.toString());
            if (plannedEndDate != null) contract.setAttribute("DatumPlanovanehoUkonceni", plannedEndDate.toString());
            if (endDate != null) contract.setAttribute("DatumUkonceni", endDate.toString());            
            contract.setAttribute("StavStavby", contractState.getText());      
            
            if (isPaid)
            {
                contract.setAttribute("Zaplaceno", "Ano");
                contract.setAttribute("ZaplacenaCastka", Long.toString(paid));
            }
            else
            {
                contract.setAttribute("Zaplaceno", "Ne");
            }
            
            createSubElem("PopisStavby", contractName, contract, document);

            contract.appendChild(
                    document.createElement("Stavbyvedouci")
                        .appendChild(chiefName.createElement(document)
                    )
                );
            
            contract.appendChild(
                    document.createElement("MistoPrace")
                        .appendChild(adress.createElement(document)
                    )
                );
            
            if (coment != null)
            {
                createSubElem("Komentar", coment, contract, document);
            }
            
            return contract;
        }
        
        /**
         * Projde vsechny zakazky dokumentu a nastavi id tak, aby bylo o 1 vetsi
         * nez nejvyssi ID existujici zakazky.
         * @param document 
         */
        public void setGreatestUniqueContractId(Document document)
        {
            contractId = 0;
            NodeList contracts = document.getElementsByTagName("Zakazka");
            for (int x = 0; x < contracts.getLength(); x++)
            {
                Element contractNode = (Element) contracts.item(x);
                String id = contractNode.getAttribute("zid");
                
                try
                {
                    int idVal = Integer.parseInt(id.substring(2));
                    if (idVal > contractId)
                    {
                        contractId = idVal;
                    }
                }
                catch (Exception e) { }
            }
            contractId++;
        }
        
        public void setContractId(int value)
        {
            contractId = value;
        }
        public void setClientId(int value)
        {
            clientId = value;
        }
        public void setContractNumber(String value)
        {
            contractNumber = value;
        }
        public void setContractName(String value)
        {
            contractName = value;
        }
        public void setComent(String value)
        {
            coment = value;
        }
        public void setStartDate(Date value)
        {
            startDate = value;
        }
        public void setEndDate(Date value)
        {
            endDate = value;
        }
        public void setPlannedEndDate(Date value)
        {
            plannedEndDate = value;
        }
        public void setContractState(ContractState value)
        {
            contractState = value;
        }
        public void setPaidValue(long value)
        {
            paid = value;
            isPaid = true;
        }
        public void setChiefName(PersonName value)
        {
            chiefName = value;
        }
        public void setAdress(Adress value)
        {
            adress = value;
        }        

    }
    
    /** Pomocne tridy k uloze 1 *************************************************************************************/
}