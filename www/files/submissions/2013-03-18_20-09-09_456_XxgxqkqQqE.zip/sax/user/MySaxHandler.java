package user;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/** Pomocna trida pro vypocet 1. charakteristiky
 *  Pro kazdou zakazku spocita prumernou cenu prace
 *      - Zkouma elementy Zakazka pro hodnotu atributu zid
 *      - Vystup je pro kazdou zakazku vypocitan jako prumer atributu CenaPrace elementu Prace
 *      - Jmeno zakazky je ziskan z hodnoty elementu popis prace
 **/
class AvgJobCost
{
    int jobCounter = 0;
    int costSum = 0;
    
    boolean inJobName = false;
    String zid = null;
    String name = null;
    
    StringBuilder text = new StringBuilder();
    
    public void printAvgJobCosts()
    {
        System.out.println(text.toString());
    }
    
    public void checkElement(String uri, String localName, String qName, Attributes atts)
    {     
        if ("Zakazka".equals(localName))
        {
            zid = atts.getValue("zid");
        }
        else if ("PopisStavby".equals(localName))
        {
            inJobName = true;
        }
        else if ("Prace".equals(localName))
        {
            String jobValue = atts.getValue("CenaPrace");
            try
            {
                int value = Integer.parseInt(jobValue);
                costSum += value;
                jobCounter++;
            }
            catch (Exception e) { }
        }
    }
        
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if ("Zakazka".equals(localName))
        {
            if (jobCounter != 0)
            {
                int avg = costSum / jobCounter;
                text.append(String.format(
                        "Prumerna cena prace v zakazce '%s' s id %s je: %d\n",
                        name,
                        zid,
                        avg
                    ));
            }
            else
            {
                text.append(String.format(
                        "Prace na zakazce '%s' s id %s dosud nezacaly.\n",
                        name,
                        zid
                    ));
            }
            
            jobCounter = 0;
            costSum = 0;

            inJobName = false;
            zid = null;
            name = null;
        }
        else if ("PopisStavby".equals(localName))
        {
            inJobName = false;
        }
    }

    public void characters(char[] chars, int start, int length) throws SAXException {
        if (inJobName)
        {
            name = new String(chars, start, length);
        }
    }
}

/** Pomocna trida pro vypocet 2. charakteristiky
 *  Vypise jmeno, e-mailovou adresu a druh spoluprace vsech organizaci se kterymi spolupracujeme
 *      - Zkouma elementy Organizace
 *      - Jmeno je obsah podelementu JmenoOrganizace
 *      - E-mail je obsah podelementu E-mail
 *      - Pro kazdou organizaci vypise pouze jeden e-mail, nebo hlasku, ze e-mail neni definovan
 *      - Druh spoluprace je urcen podle rodicovskeho elementu - Klient / Dodavatel
 **/
class OrganizationEmails
{
    enum OrgType
    {
        None, Klient, Dodavatel
    }
    
    boolean inOrg = false;
    boolean inOrgName = false;
    boolean inMail = false;
    
    String orgName = null;
    String email = null;
    OrgType orgType = OrgType.None;
    
    StringBuilder text = new StringBuilder();
    
    public void printEmails()
    {
        System.out.println(text.toString());
    }
    
    public void checkElement(String uri, String localName, String qName, Attributes atts)
    {     
        if ("Klient".equals(localName))
        {
            orgType = OrgType.Klient;
        }
        else if ("Dodavatel".equals(localName))
        {
            orgType = OrgType.Dodavatel;
        }
        else if ("Organizace".equals(localName))
        {
            inOrg = true;
        }
        else if ("JmenoOrganizace".equals(localName))
        {
            inOrgName = true;
        }
        else if ("E-mail".equals(localName))
        {
            if (inOrg)
                inMail = true;
        }
    }
        
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if ("Organizace".equals(localName))
        {
            switch (orgType)
            {
                case Dodavatel:
                    text.append("Dodavatel");
                    break;
                    
                case Klient:
                    text.append("Klient");
                    break;
                    
                default:
                    text.append("Nedefinovany partner");
            }
            
            if (email != null)
            {
                text.append(String.format(
                        " '%s' s kontaktnim e-mailem %s\n",
                        orgName,
                        email
                    ));
            }
            else
            {
                text.append(String.format(
                        " '%s' s nedefinovanym e-mailem\n",
                        orgName
                    ));
            }
            
            inOrg = false;
            inOrgName = false;
            inMail = false;

            orgName = null;
            email = null;
            orgType = OrgType.None;
        }
        else if ("JmenoOrganizace".equals(localName))
        {
            inOrgName = false;
        }
        else if ("E-mail".equals(localName))
        {
            if (inOrg)
                inMail = false;
        }
    }

    public void characters(char[] chars, int start, int length) throws SAXException {
        if (inOrgName)
        {
            orgName = new String(chars, start, length);
        }
        else if (inMail && email == null)
        {
            email = new String(chars, start, length);
        }
    }
}

/** Pomocna trida pro vypocet 3. charakteristiky
 *  Zjisti jmena zakazniku s nejvice ukoncenymi zakazkami
 *      - Nejprve vyrobi tabulku zakazniku z elementu Klienti
 *          - Id klienta z atributu kid elementu Klient
 *          - Typ klienta (organizace/osoba) podle druhu podelemntu
 *          - Jmeno osoby z podelementu JmenoOsoby a sekvenci Titul, Jmeno, Prijmeni
 *          - Jmeno organizace z elementu JmenoOrganizace
 *      - Dale prochazi zakazky (element Zakazka) a zvetsuje citac u klientu ukoncenych zakazek
 *          - ID klienta z atributu Odberatel
 *          - Stav zakazky z elementu StavStavby musi mit hodnotu Ukoncena
 **/
class BestCustomer
{
    class ClientData
    {
        String id;
        String name;
        int count;
        
        public ClientData(String id, String name)
        {
            this.id = id;
            this.name = name;
            this.count = 0;
        }
        
        public void IncrementCounter()
        {
            count++;
        }
        
        public String getClientName()
        {
            return name;
        }
        public String getId()
        {
            return id;
        }
        public int getCount()
        {
            return count;
        }
    }
    
    public static String ENDED_VAL = "Ukoncena";
    
    int maxCount = 0;
    String clientId = null;
    StringBuilder clientName = new StringBuilder();
    boolean inClient, inPerson, inName, inSurename, inTit, inOrg, inOrgName;
    HashMap clientCounter = new HashMap();
    
    public void checkElement(String uri, String localName, String qName, Attributes atts)
    {        
        if ("Klient".equals(localName))
        {
            inClient = true;
            clientId = atts.getValue("kid");
        }
        else if ("Osoba".equals(localName))
        {
            if (inClient)
            {
                inPerson = true;
            }
        }
        else if ("Jmeno".equals(localName))
        {
            if (inPerson)
            {
                inName = true;
            }
        }
        else if ("Prijmeni".equals(localName))
        {
            if (inPerson)
            {
                inSurename = true;
            }
        }
        else if ("Titul".equals(localName))
        {
            if (inPerson)
            {
                inTit = true;
            }
        }
        else if ("Organizace".equals(localName))
        {
            if (inClient)
            {
                inOrg = true;
            }
        }
        else if ("JmenoOrganizace".equals(localName))
        {
            if (inOrg)
            {
                inOrgName = true;
            }
        }
        else if ("Zakazka".equals(localName))
        {
            String kidValue = atts.getValue("Odberatel");
            String ended = atts.getValue("StavStavby");
            ClientData data = (ClientData) clientCounter.get(kidValue);
            
            if (data != null && ended.equals(ENDED_VAL))
            {
                data.IncrementCounter();
                if (data.getCount() > maxCount)
                    maxCount = data.getCount();
            }
        }
    }
    
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if ("Klient".equals(localName))
        {
            if (clientId != null && clientName.length() > 0)
            {
                ClientData data = new ClientData(clientId, clientName.toString());
                clientCounter.put(clientId, data);
                
                inClient = false;
                clientName.delete(0, clientName.length());
                clientId = null;
            }
        }
        else if ("Osoba".equals(localName))
        {
            if (inClient)
            {
                inPerson = false;
            }
        }
        else if ("Jmeno".equals(localName))
        {
            if (inPerson)
            {
                inName = false;
            }
        }
        else if ("Prijmeni".equals(localName))
        {
            if (inPerson)
            {
                inSurename = false;
            }
        }
        else if ("Titul".equals(localName))
        {
            if (inPerson)
            {
                inTit = false;
            }
        }
        else if ("Organizace".equals(localName))
        {
            if (inClient)
            {
                inOrg = false;
            }
        }
        else if ("JmenoOrganizace".equals(localName))
        {
            if (inOrg)
            {
                inOrgName = false;
            }
        }
    }

    public void characters(char[] chars, int start, int length) throws SAXException {
        if (inName || inSurename || inTit)
        {
            clientName.append(chars, start, length);
            clientName.append(' ');
        }
        else if (inOrgName)
        {
            clientName.append("organizace: '");
            clientName.append(chars, start, length);
            clientName.append("' ");
        }
    }
    
    public void printMaxValueMessage()
    {
        if (maxCount > 0)
        {
            System.out.println(String.format(
                    "Nasi nejlepsi zakaznici s %d ukoncenymi zakazkami:",
                    maxCount
                    ));
            
            for (Object client : clientCounter.entrySet())
            {
                ClientData data = (ClientData) ((Entry<Object, Object>) client).getValue();
                if (maxCount == data.getCount()) 
                {
                    System.out.println(data.getClientName());
                }
            }
        }
        else
        {
            System.out.println("Nebyly nalezeny zadne ukoncene zakazky");
        }
    }
}

public class MySaxHandler extends DefaultHandler {
   // Helper variable to store location of the handled event
    Locator locator;
    
    AvgJobCost avgJobCost = new AvgJobCost();
    OrganizationEmails organizationEmails = new OrganizationEmails();
    BestCustomer bestCustomer = new BestCustomer();
    

    /**
     * Sets the locator
     *
     * @param Locator locator location in the file
     */
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Method to handle "document start"
     *
     * @throws SAXException
     */
    @Override
    public void startDocument() throws SAXException {
    }

    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
        
        System.out.println("Charakteristika 1: prumerna ceny prace v zakazce");
        avgJobCost.printAvgJobCosts();
        
        System.out.println("Charakteristika 2: e-maily organizaci");
        organizationEmails.printEmails();
        
        System.out.println("Charakteristika 3: nejlepsi zakaznici");
        bestCustomer.printMaxValueMessage();
    }

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        avgJobCost.checkElement(uri, localName, qName, atts);
        organizationEmails.checkElement(uri, localName, qName, atts);
        bestCustomer.checkElement(uri, localName, qName, atts);
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        avgJobCost.endElement(uri, localName, qName);
        organizationEmails.endElement(uri, localName, qName);
        bestCustomer.endElement(uri, localName, qName);
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        avgJobCost.characters(chars, start, length);
        organizationEmails.characters(chars, start, length);
        bestCustomer.characters(chars, start, length);
    }

    /**
     * Method to handle " start of namespace declaration"
     *
     * @param prefix Prefix of the namespace
     * @param uri URI of the namespace
     * @throws SAXException
     */
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    /**
     * Method to handle "end of namespace declaration"
     *
     * @param prefix
     * @throws SAXException
     */
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    /**
     * Method to handle "ignoring of whitespaces" Text is in array 'chars' from
     * position ('start') to ('start' + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     * @throws SAXException
     */
    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
        // ...
    }

    /**
     * Method to handle "processing instructions"
     *
     * @param target The processing instruction target
     * @param data  The processing instruction data
     * @throws SAXException
     */
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

    /**
     * Method to handle "unprocessed entity"
     *
     * @param name
     * @throws SAXException
     */
    @Override
    public void skippedEntity(String name) throws SAXException {
        // ...
    }
}
