package user;

import java.util.HashMap;
import java.util.Map;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

public class MySaxHandler extends DefaultHandler {
    
    public static void main(String[] args) {
        
        String xml_file = "data.xml";

        try {
            XMLReader parser = XMLReaderFactory.createXMLReader();
            InputSource source = new InputSource(xml_file);
            parser.setContentHandler(new MySaxHandler());
            parser.parse(source);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
    
    /**
     * Objekt nesuci statistiku o autorovi.
     * @author Maros Kasinec
     *
     */
    class AuthorStats {
        public String Name;
        public int ActivityCount;
        public int LikeCount;
        public int DislikeCount;
        public int CommentCount;
        public int CommentsSize;
    }
    
    /**
     * Vycet parsovacich stavov.
     * @author Maros Kasinec
     *
     */
    enum Parsing {
        Undefined,
        Author,
        Feed,
    }
    
    Map<String, AuthorStats> authors = new HashMap<String, AuthorStats>();
    Parsing parsing = Parsing.Undefined;
    
    StringBuffer buffer = new StringBuffer();
    AuthorStats current_parsing;
    boolean is_comment = false;
    
    /**
     * Metoda vypise vysledky na vystup.
     */
    @Override
    public void endDocument() throws SAXException {
        System.out.println("The end of the document reached.");
        System.out.println("Here are the results:\n");
        for (Map.Entry<String, AuthorStats> e : authors.entrySet()) {
            System.out.println("Author with ID '" + e.getKey() + "' and name '" + e.getValue().Name + "' stats:");
            System.out.println("\tNumber of activites:\t" + e.getValue().ActivityCount);
            System.out.println("\tNumber of likes:\t" + e.getValue().LikeCount);
            System.out.println("\tNumber of dislikes:\t" + e.getValue().DislikeCount);
            System.out.println("\tNumber of comments:\t" + e.getValue().CommentCount);
            System.out.println("\tSize of all comments:\t" + e.getValue().CommentsSize);
            System.out.println();
        }
    }
    
    @Override
    public void startElement(String uri, String localName, String qName,
            Attributes attributes) throws SAXException {
        if (localName == "author") { // nacitanie autorov
            if (attributes.getValue("id") == null) {
                System.out.println("ERROR: No author ID found!");
            } else {
                
                parsing = Parsing.Author;
                
                if (authors.containsKey(attributes.getValue("id"))) {
                    System.out.println("WARNING: Duplicity in authors id found! Overwriting by latter ID.");
                }
                
                current_parsing = new AuthorStats();
                authors.put(attributes.getValue("id"), current_parsing);
                
            }
        } else if (localName == "feed") {
            parsing = Parsing.Feed; // nastavi vnutorny stav na parsovanie feedu
        } else if (parsing == Parsing.Feed) {
            String id;
            if ((id = attributes.getValue("author")) != null) {
                if (localName == "like" && attributes.getValue("value") != null && attributes.getValue("value").equals("0"))
                    authors.get(id).DislikeCount++;
                else if (localName == "like")
                    authors.get(id).LikeCount++;
                else if (localName == "comment") {
                    authors.get(id).CommentCount++;
                    is_comment = true;
                    current_parsing = authors.get(id);
                }
                else if (localName == "activity")
                    authors.get(id).ActivityCount++;
            }
        }
    }
    
    @Override
    public void endElement(String uri, String localName, String qName)
            throws SAXException {
        if (localName == "author" && parsing == Parsing.Author) {
            current_parsing.Name = buffer.toString();
            buffer.delete(0, buffer.length());
            parsing = Parsing.Undefined;
        } else if (localName == "comment") {
            is_comment = false;
        }
    }
    
    @Override
    public void characters(char[] ch, int start, int length)
            throws SAXException {
        if (parsing == Parsing.Author) {
            for (int i = start; i < start + length; i++) {
                buffer.append(ch[i]);
            }
        }
        if (is_comment) {
            current_parsing.CommentsSize += length;
        }
    }
    
}