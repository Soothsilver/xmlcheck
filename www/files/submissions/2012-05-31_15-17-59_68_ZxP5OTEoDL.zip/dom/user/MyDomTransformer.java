package user;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer {

    public static void main(String[] args) {
        try {
            //DocumentBuilderFactory vytváří DOM parsery
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            //nebudeme validovat
            dbf.setValidating(false);
            //vytvoříme si DOM parser
            DocumentBuilder builder = dbf.newDocumentBuilder();
            //parser zpracuje vstupní soubor a vytvoří z něj strom DOM objektů
            Document doc = builder.parse("data.xml");
            MyDomTransformer transformer = new MyDomTransformer();
            
            //zpracujeme DOM strom
            transformer.transform(doc);

            //TransformerFactory vytváří serializátory DOM stromů
            TransformerFactory tf = TransformerFactory.newInstance();
            //Transformer serializuje DOM stromy
            Transformer writer = tf.newTransformer();
            //nastavíme kodování
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            //spustíme transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(System.out));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void transform (Document xmlDocument) {
        // nastavi pre vsetky likey a komenty ID aktivity ku ktorej patri
        NodeList likes = xmlDocument.getElementsByTagName("like");
        for (int i = 0; i < likes.getLength(); i++) {
            String id = likes.item(i).getParentNode().getAttributes().getNamedItem("id").getTextContent();
            likes.item(i).getAttributes().setNamedItem(xmlDocument.createAttribute("on_activity"));
            likes.item(i).getAttributes().getNamedItem("on_activity").setTextContent(id);
        }
        NodeList comments = xmlDocument.getElementsByTagName("comment");
        for (int i = 0; i < comments.getLength(); i++) {
            String id = comments.item(i).getParentNode().getAttributes().getNamedItem("id").getTextContent();
            comments.item(i).getAttributes().setNamedItem(xmlDocument.createAttribute("on_activity"));
            comments.item(i).getAttributes().getNamedItem("on_activity").setTextContent(id);
        }
        
        // presunie vsetky aktivity, likey a komenty odpovedajuceho elementu author
        NodeList nl = xmlDocument.getElementsByTagName("author");
        for (int i = 0; i < nl.getLength(); i++) {
            Node author = nl.item(i);
            // presun meno autora do atributu 'name'
            String name = nl.item(i).getTextContent();
            author.getAttributes().setNamedItem(xmlDocument.createAttribute("name"));
            author.getAttributes().getNamedItem("name").setTextContent(name);
            author.setTextContent("");
            // ziskaj id autora
            String id = author.getAttributes().getNamedItem("id").getTextContent();
            // vloz aktivity patriace autorovi
            NodeList list = xmlDocument.getElementsByTagName("activity");
            for (int j = 0; j < list.getLength(); j++) {
                if (list.item(j).getAttributes().getNamedItem("author").getTextContent().equals(id)) {
                    author.appendChild(list.item(j));
                }
            }
            // vloz autorove likey
            list = xmlDocument.getElementsByTagName("like");
            for (int j = 0; j < list.getLength(); j++) {
                if (list.item(j).getAttributes().getNamedItem("author").getTextContent().equals(id)) {
                    author.appendChild(list.item(j));
                }
            }
            // vloz autorove komentare
            list = xmlDocument.getElementsByTagName("comment");
            for (int j = 0; j < list.getLength(); j++) {
                if (list.item(j).getAttributes().getNamedItem("author").getTextContent().equals(id)) {
                    author.appendChild(list.item(j));
                }
            }
        }
        
        // nahradi root element wall vyslednym elementom transformacie authors
        xmlDocument.replaceChild(
                xmlDocument.getElementsByTagName("authors").item(0),
                xmlDocument.getElementsByTagName("wall").item(0));
        
        // nakoniec este odstrani nepotrebny atribut id autora v kazdej aktivite, likeu a komente
        nl = xmlDocument.getElementsByTagName("activity");
        for (int i = 0; i < nl.getLength(); i++) {
            nl.item(i).getAttributes().removeNamedItem("author");
            // odstrani like a komenty z aktivit
            NodeList nl1 = nl.item(i).getChildNodes();
            for (int j = 0; j < nl1.getLength(); j++) {
                String elem = nl1.item(j).getLocalName();
                if (elem != null && (elem.equals("likes") || elem.equals("comment")))
                    nl.item(i).removeChild(nl1.item(j));
            }
        }
        nl = xmlDocument.getElementsByTagName("like");
        for (int i = 0; i < nl.getLength(); i++) {
            nl.item(i).getAttributes().removeNamedItem("author");
        }
        nl = xmlDocument.getElementsByTagName("comment");
        for (int i = 0; i < nl.getLength(); i++) {
            nl.item(i).getAttributes().removeNamedItem("author");
        }
    }
}