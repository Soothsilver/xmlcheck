package user;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {

    boolean flag = false;
    int counter = 0;
    boolean value = false;

    public void endDocument() throws SAXException {
        System.out.println(counter);

    }

    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        if ("pouziteKytary".equals(localName)) {
            flag = true;
        }

        if ("jeSkladem".equals(localName) && flag) {
            counter++;
        }

    }

    public void endElement(String uri, String localName, String qName) throws SAXException {

        if ("pouziteKytary".equals(localName)) {
            flag = false;
        }

    }

}
