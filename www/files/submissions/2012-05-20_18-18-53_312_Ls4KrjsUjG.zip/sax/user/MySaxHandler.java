package user;

import java.util.HashMap;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;


// vypise na standardni vystup informaci o podilu "uzitecnych" informaci k "XML rezii":
// za XML rezii se povazuji nazvy elementu a atributu, za uzitecne hodnoty atributu + textovy obsah elementu
// vysledkem je procentualni zastoupeni vlastnich dat v XML dokumentu (jakou cast dokumentu tvori vlastni data)

// dale vypise novy podil, ktery by vznikl, kdyby se za nazvy elementu a atributu volily co nejkratsi hodnoty - a,b,...,z,aa,ab,...
public class MySaxHandler extends DefaultHandler {

    private int elementsLength, // delka nazvu vsech tagu (oteviraci+zaviraci)
            attributesLength, // delka nazvu vsech atributu
            usefulLength; // uzitecna delka - hodnoty atributu + textovy obsah elementu
    private int reducedElementsLength, // delka nazvu tagu po zkraceni
            reducedAttributesLength; // delka nazvu atributu po zkraceni
    private HashMap<String,String> map; // prevodni tabulka stary nazev --> novy nazev
    
    @Override
    public void startDocument() throws SAXException {
        elementsLength=0;
        attributesLength=0;
        usefulLength=0;    
        reducedAttributesLength=0;
        reducedElementsLength=0;
        map=new HashMap<String, String>();
    }

    @Override
    public void endDocument() throws SAXException {
        // soucasny podil vlastnich dat v dokumentu
        float quotient=usefulLength/(float)(elementsLength+attributesLength+usefulLength);
        quotient*=100;
        
        // podil po nahrazeni minimalistickymi nazvy
        float newQuotient=usefulLength/(float)(reducedElementsLength+reducedAttributesLength+usefulLength);
        newQuotient*=100;
        
        System.out.println(String.format("Current quotient: %f%%", quotient));
        System.out.println(String.format("Improved quotient: %f%%", newQuotient));        
    }    
    
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        // pripocitam textovy obsah mezi uzitecny obsah
        usefulLength+=length;
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        // pokud jeste nemam nahradni nazev pro element, vyrobim ho
        if (!map.containsKey(qName)) {
            map.put(qName, getNextFreeIdentifier());
        }
        
        // zapoctu delku nazvu elementu
        elementsLength+=qName.length();
        
        // zapoctu zkracenou delku nazvu elementu
        reducedElementsLength+=map.get(qName).length();
        
        for (int i=0;i<attributes.getLength();i++) {
            String name=attributes.getQName(i);
            
            // pokud jeste nemam nahradni nazev pro atribut, vyrobim ho
            if (!map.containsKey(name)) {
                map.put(name, getNextFreeIdentifier());
            }   
            
            attributesLength+=name.length();
            reducedAttributesLength+=map.get(name).length();
            
            // zapoctu obsah atributu do uzitecneho obsahu
            usefulLength+=attributes.getValue(i).length();
        }
    } 
    
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        // pripocitam delku nazvu koncoveho tagu
        elementsLength+=qName.length();
        reducedElementsLength+=map.get(qName).length();
    }

    private String currentIdent="a";
    private String getNextFreeIdentifier() {
        String ret=currentIdent;
                  
        currentIdent=raiseAt(currentIdent, currentIdent.length()-1);            
 
        return ret;
    }
    
    private String raiseAt(String s,int i) {        
        if (i<0) {
            return "a"+s;
        }
        int code=s.charAt(i);
        if (code=='z') {
            return raiseAt(s, i-1).substring(0,i+1) +"a";
        } else {
            code++;
            if (i==0) {
                return Character.toChars(code)[0]+s.substring(i+1);
            } else {
                return s.substring(0,i)+Character.toChars(code)[0]+s.substring(i+1);
            }
        }
    }
}