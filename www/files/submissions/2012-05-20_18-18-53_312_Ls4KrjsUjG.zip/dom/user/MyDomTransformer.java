package user;

import java.util.ArrayList;
import java.util.List;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

// nahradi vsechny elementy "personRef" (odkaz na osobu) elementem "person", jehoz obsahem bude jmeno osoby s danym ID
public class MyDomTransformer {
    
    private NodeList studentList,teacherList;
    
    public void transform(Document xmlDocument) {
        // najdu vsechny odkazy na osoby
        NodeList refList=xmlDocument.getElementsByTagName("personRef");        
        
        List<Element> newElements=new ArrayList<Element>();
        List<Element> removeElements=new ArrayList<Element>();
        List<Element> parents=new ArrayList<Element>();
        
        for (int i=0;i<refList.getLength();i++) {
            Element element=(Element)refList.item(i);                        
            
            // vytvorim novy element person, jako obsah mu dam jmeno osoby
            Element newElement=xmlDocument.createElement("person");
            newElement.setTextContent(getNameOf(xmlDocument,element.getAttribute("refid")));
            
            // pridam stary element, novy element a otce stareho elementu do seznamu k nahrazeni
            removeElements.add(element);
            newElements.add(newElement);
            parents.add((Element)element.getParentNode());
        }
        
        for (int i=0;i<newElements.size();i++) {
            parents.get(i).replaceChild(newElements.get(i),removeElements.get(i));
        }
        
    }

    // vrati jmeno osoby s danym ID
    private String getNameOf(Document document,String id) {                
        // najdu si seznamy vsech studentu a ucitelu, pokud je uz nemam        
        if (studentList==null) {
            studentList=document.getElementsByTagName("student");
            teacherList=document.getElementsByTagName("teacher");        
        }
        
        // zkusim najit ID mezi studenty
        Element found=lookup(studentList, id);
        
        // pokud jsem nenasel, zkusim to mezi uciteli
        if (found==null)
            found=lookup(teacherList, id);
            
        // pokud jsem nasel, ziskam obsahy elementu name a surname
        if (found!=null) {
            String firstName=found.getElementsByTagName("name").item(0).getTextContent();
            String surname=found.getElementsByTagName("surname").item(0).getTextContent();

            return firstName+" "+surname;
        } else return "(name not found)";
    }
    
    // projde dany seznam elementu, jestli v nem neni element s ID id
    private Element lookup(NodeList list,String id) {
        for (int i=0;i<list.getLength();i++) {
            Element el=(Element)list.item(i);
            if (el.getAttribute("id").equals(id)) 
                return el;            
        }
        return null;
    }
            
}
