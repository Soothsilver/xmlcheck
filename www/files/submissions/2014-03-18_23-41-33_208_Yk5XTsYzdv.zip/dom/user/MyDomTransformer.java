package user;
import org.w3c.dom.Document;
public class MyDomTransformer {
    public void transform (Document doc) {
        // (1) Přidání dítěte
        Element child = doc.createElement("dite");
        child.setAttribute("rodne-cislo", "1151015316");
        child.setAttribute("trida", "sluníčka");
        child.appendChild(doc.createElement("jmeno")).setTextContent("Dominik");
        child.appendChild(doc.createElement("prijmeni")).setTextContent("Zátopek");

        Element parent = doc.createElement("zakonnyZastupce");
        parent.setAttribute("typ", "otec");
        parent.appendChild(doc.createElement("jmeno")).setTextContent("Josef");
        parent.appendChild(doc.createElement("prijmeni")).setTextContent("Zátopek");
        
        child.appendChild(parent);
                
        NodeList registry = doc.getElementsByTagName("matrikaDeti");

        if (registry != null && registry.getLength() > 0) {
            registry.item(0).appendChild(child);
        }

        // (2) Odstranění hodnocení z předchozích let
        NodeList evals  = doc.getElementsByTagName("hodnoceni");

        if (evals != null && evals.getLength() > 0) {
            for (int i = evals.getLength() -1; i >= 0; i--) {
                Element el = (Element) evals.item(i);

                String date = el.getAttributes().getNamedItem("datum").getNodeValue();

                if (!date.endsWith("2014")) {
                    Element elParent = (Element) el.getParentNode();
                    elParent.removeChild(el);
                }
            }
        }
    }
}
