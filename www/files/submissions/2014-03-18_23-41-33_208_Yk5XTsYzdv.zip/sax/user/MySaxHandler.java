package user;
import org.xml.sax.helpers.DefaultHandler;
public class MySaxHandler extends DefaultHandler {
    // Helper variable to store location of the handled event
    Locator locator;

    ArrayList<String> parents = new ArrayList<String>();
    
    ArrayList<String> langs = new ArrayList<String>();

    boolean inEval = false;
    boolean inGrade = false;
    int grades = 0;
    int gradesNo = 0;
    
    
    /**
     * Sets the locator
     *
     * @param Locator locator location in the file
     */
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Method to handle "document start"
     *
     * @throws SAXException
     */
    @Override
    public void startDocument() throws SAXException {
        // ...
    }

    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
        // ...
    }

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        String attname;

        if (qName.equals("hodnoceni")) {
            inEval = true;
        }

        if (inEval) {
            inGrade = true;
        }

        if (atts != null) {
            int numberAttributes = atts.getLength();

            for (int i = 0; i < numberAttributes; i++){

                attname = atts.getQName(i);

                if (attname.toLowerCase().equals("typ")) {
                    parents.add(atts.getValue(i));
                }

                if (attname.toLowerCase().equals("xml:lang")) {
                    if (!langs.contains(atts.getValue(i))) {
                        langs.add(atts.getValue(i));
                    }
                }
            }
        }
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        
        if (qName.equals("hodnoceni")) {
            inEval = false;
            inGrade = false;
        }

        if (qName.equals("materskaSkola")) {

            // (1) Jsou častěji zástupci otcové či matky?
            int fatherOccurrences = Collections.frequency(parents, "otec");
            int motherOccurrences = Collections.frequency(parents, "matka");

            if (fatherOccurrences > motherOccurrences) {
                System.out.println("Otcové jsou častěji uváděni jako zástupci.");
            }

            if (fatherOccurrences < motherOccurrences) {
                System.out.println("Matky jsou častěji uváděny jako zástupci.");
            }

            if (fatherOccurrences == motherOccurrences) {
                System.out.println("Otcové a matky jsou stejně často uvádeni jako zástupci.");
            }

            // Kolik je v dokumentu jazyků?
            System.out.print("XML obsahuje ");
            System.out.print(langs.size());
            System.out.println(" jazyky/ů");

            // Jaké je průměrné hodnocení?
            System.out.print("Průměrné hodnocení je ");
            System.out.println((float) grades / gradesNo);

        }
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {

        String characterData = (new String(chars, start, length)).trim();

        if (inGrade == true && characterData.length() > 0) {
            
            grades += Integer.parseInt(characterData);
            gradesNo++;

            inGrade = false;
        }
    }

    /**
     * Method to handle " start of namespace declaration"
     *
     * @param prefix Prefix of the namespace
     * @param uri URI of the namespace
     * @throws SAXException
     */
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    /**
     * Method to handle "end of namespace declaration"
     *
     * @param prefix
     * @throws SAXException
     */
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    /**
     * Method to handle "ignoring of whitespaces" Text is in array 'chars' from
     * position ('start') to ('start' + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     * @throws SAXException
     */
    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
        // ...
    }

    /**
     * Method to handle "processing instructions"
     *
     * @param target The processing instruction target
     * @param data  The processing instruction data
     * @throws SAXException
     */
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

    /**
     * Method to handle "unprocessed entity"
     *
     * @param name
     * @throws SAXException
     */
    @Override
    public void skippedEntity(String name) throws SAXException {
        // ...
    }

}
