package user;

import java.util.Stack;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

// Vypise statistiky souboru data.xml

public class MySaxHandler extends DefaultHandler { 
    
    int countElements = 0;
    int elementNamesLength = 0;
    int topNameMax = 0;
    Stack<String> s = new Stack<String>();
    int maxDepth = 0;
    int countAtt = 0;

    @Override
    public void startDocument() throws SAXException {
        super.startDocument();
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        countElements++;
        elementNamesLength += qName.length();
        topNameMax = (topNameMax < qName.length()) ? qName.length() : topNameMax;
        s.push(qName);    
        countAtt += attributes.getLength();
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        maxDepth = (maxDepth < s.size()) ? s.size() : maxDepth;
        s.pop();
    }
    

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {

    }
    
    @Override
    public void endDocument() throws SAXException {
        System.out.println("V dokumentu je " + countElements + " elementu.");
        System.out.println("Prumerna delka nazvu elementu je " + (elementNamesLength / countElements));
        System.out.println("Nejdelsi nazev elementu je " + topNameMax);
        System.out.println("Maximalni hloubka je " + maxDepth);
        System.out.println("Pocet atributu v dokumentu je " + countAtt);
    }

}
