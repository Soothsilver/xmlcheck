package user;

import org.w3c.dom.*;

public class MyDomTransformer {

    /*
     * Metoda sjednoti veskera jmena a prijmeni zakaznika do jednoho tagu.
     * Metoda dále přesune atribute zakaznik_id do elementu id. 
     */
    
    public static void transform(Document xmlDocument) {
        NodeList zakaznici = xmlDocument.getElementsByTagName("zakaznik");
        String jmeno = "";
        String id = "";
        for (int i = 0; i < zakaznici.getLength(); i++) {
            
            // Dostane potomky + atribty
            NodeList zakazniciE = zakaznici.item(i).getChildNodes();
            NamedNodeMap att = zakaznici.item(i).getAttributes();
            id = att.getNamedItem("zakaznik_id").getTextContent();
            
            //smaze atribut
            Element l = (Element) zakaznici.item(i);
            l.removeAttribute("zakaznik_id");
            
            // Zpracuj jmeno
            for (int j = 0; j < zakazniciE.getLength(); j++) {
                Node elem = zakazniciE.item(j);
                if(elem != null && (elem.getNodeName().equals("jmeno") || elem.getNodeName().equals("prijmeni"))){   
                    jmeno += elem.getTextContent()+" ";
                    zakaznici.item(i).removeChild(elem);
                }                
            }
            
            // nastavi nove elementy
            Element newName = xmlDocument.createElement("jmeno");
            newName.appendChild(xmlDocument.createTextNode(jmeno.trim()));
            zakaznici.item(i).appendChild(newName);
            
            Element idAsElement = xmlDocument.createElement("id");
            idAsElement.appendChild(xmlDocument.createTextNode(id));
            
            zakaznici.item(i).appendChild(newName);
            zakaznici.item(i).appendChild(idAsElement);
            jmeno = "";
        }       
    }
}
