package user;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

import org.w3c.dom.*;


/*
 * Trida pro DOM transformaci
 */
public class MyDomTransformer 
{
	// dvojice (nazev mesta, seznam company do mesta patrici) 
	private HashMap<String, ArrayList<Element>> _cities = new HashMap<String, ArrayList<Element>>();
	
	
	/*
	 * Transformuje xmlDocument saleSystemu
	 * klicovym elementem jsou mesta
	 * do kazdeho mesta jsou zarazeny ty spolecnosti, ktere maji v tomto meste sidlo
	 */
	public void transform (Document xmlDocument) 
	{
		_findAllCompany(xmlDocument);
		_reorganizeByCity(xmlDocument);
	}

	
	/*
	 * Najde vechny spolecnosti a ulozi je pod nazvem mesta do _cities
	 */
	private void _findAllCompany(Document xmlDocument) 
	{
		// korenovy element
		Element docElement = xmlDocument.getDocumentElement();
		
		// seznam vsech spolecnosti
		NodeList companies = docElement.getElementsByTagName("Company");
		
		for(int i = 0; i < companies.getLength(); ++i)
		{
			Node companyNode = companies.item(i);
			
			if(companyNode.getNodeType() == Node.ELEMENT_NODE)
			{
				Element companyElement = (Element)companyNode;
				
				// mesto, z ktereho spolecnost pochazi
				String city;
				try
				{
					city = ((Element)companyElement.getElementsByTagName("City").item(0)).getTextContent();
				}
				catch (Exception e)
				{ 
					city = "unknown_city";
				}
				
				// vlozi spolecnost do seznamu podle mesta
				if(_cities.containsKey(city))
				{
					// prida do mesta dovou spolecnost
					_cities.get(city).add(companyElement);
				}
				else
				{
					// vytvori novy list a nove mesto
					ArrayList<Element> list = new ArrayList<Element>();
					list.add(companyElement);
					_cities.put(city, list);
				}
			}
		}
	}
	
	
	/*
	 * Upravi xmlDocument do kyzene podoby
	 * pred zpustenim teto metody se musi zavolat _findAllCompany
	 */
	private void _reorganizeByCity(Document xmlDocument) 
	{		
		Element citiesElement = xmlDocument.createElement("Cities");
		Element cityElement, newCompanyElement;
		
		for(Entry<String, ArrayList<Element>> city : _cities.entrySet())
		{
			cityElement = xmlDocument.createElement("City");
			cityElement.setAttribute("name", city.getKey());
			
			for(Element companyElement : city.getValue())
			{
				newCompanyElement = xmlDocument.createElement("Company");
				newCompanyElement.setAttribute("name", companyElement.getElementsByTagName("Name").item(0).getTextContent());
				
				cityElement.appendChild(newCompanyElement);
			}
			
			citiesElement.appendChild(cityElement);
		}
		
		// nastavi obsah korenoveho elementu
		xmlDocument.replaceChild(citiesElement, xmlDocument.getDocumentElement());
	}
}