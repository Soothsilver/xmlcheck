package user;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler 
{
	private int _voucherCount;
	private int _validVoucherCount;
	private boolean _isInVoucher;
	private Date _today;
	

	public MySaxHandler()
	{
		// inicializace promennych
		_voucherCount = 0;
		_validVoucherCount = 0;
		_isInVoucher = false;
		_today = new Date();
	}
	

	public void startElement (String uri, String name, String qName, Attributes atts)
	{
		// hleda ve voucheru element udavajici platnost voucheru
		if(_isInVoucher && qName.equals("Valid"))
		{
			try
			{
			// zjisti od kdy a do kdy je voucher platny
			Date validFrom = null , validTo = null;
			DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
			for(int i = 0; i < atts.getLength(); ++i)
			{
				if(atts.getQName(i).equals("from")) 
				{
					validFrom = dateFormat.parse(atts.getValue(i));
				}
				else if(atts.getQName(i).equals("to")) 
				{
					validTo = dateFormat.parse(atts.getValue(i));
					
					// posune datum platnosti o jeden den kvuli naslednemu porovnavani - porovnava se na mensi a ne na mensi-rovno
					validTo.setTime(validTo.getTime() + 24*60*60*1000);
				}
			}
			
			// kontrola platnosti
			if(validFrom == null || validTo == null) throw new Exception("Spatny format platnosti!");
			
			// zjisti, jestli je voucher dnes platny
			if(_today.after(validFrom) && _today.before(validTo)) ++_validVoucherCount;
			
			}
			catch(Exception e){ /* nejspise spatne zadany format datumu v xml dokumentu - voucher neni platny */}
		}
		
		// oznami, ze se prave nachazi ve voucheru
		if(qName.equals("Voucher")) 
		{
			_isInVoucher = true;
			++_voucherCount;
		}
	}
	
	
	public void endElement(String uri, String name, String qName)
	{
		if(qName.equals("Voucher")) _isInVoucher = false;
	}

	
	/*
	 * Vraci celkovy pocet voucheru
	 */
	public int GetVoucherCount()
	{
		return _voucherCount;
	}
	
	
	/*
	 * Vraci pocet prave validnich voucheru
	 */
	public int GetValidVoucherCount()
	{
		return _validVoucherCount;
	}
}
