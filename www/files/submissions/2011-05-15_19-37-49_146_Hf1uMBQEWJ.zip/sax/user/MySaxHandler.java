package user;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler
	   extends DefaultHandler
{	
	int pocet_deti;
	int pocet_pojistitelu;
	
	@Override
	public void startDocument() throws SAXException
	{
	    // TODO Auto-generated method stub
	    super.startDocument();
	    
	    // Začátek dokumentu, začínáme počítat
	    pocet_deti = 0;
	    pocet_pojistitelu = 0;
	}
	
	@Override
	public void endDocument() throws SAXException
	{
	    // TODO Auto-generated method stub
	    super.endDocument();
	    
	    if(pocet_pojistitelu > 0)
	    {
	    	// Vypočteme a vypíšeme průměr
		    double prumer = (double)pocet_deti / (double)pocet_pojistitelu;
		    
		    System.out.format("Průměrný počet dětí jednoho pojistitele: %.2f\n", prumer);
	    }
	    else
	    {
	    	System.out.println("V dokumentu nejsou žádní pojistitelé.");
	    }
	    
	    
	}
	
	@Override
	public void startElement(String uri, String localName, String qName,
	        Attributes attributes) throws SAXException
	{
	    // TODO Auto-generated method stub
	    super.startElement(uri, localName, qName, attributes);
	    
	    if("dite".equals(localName))
	    {
	    	pocet_deti++;
	    }
	    else if("pojistitel".equals(localName))
	    {
	    	pocet_pojistitelu++;
	    }
	}
}
