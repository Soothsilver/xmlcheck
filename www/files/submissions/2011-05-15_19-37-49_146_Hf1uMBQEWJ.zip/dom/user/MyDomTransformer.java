package user;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.w3c.dom.Document; 
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class MyDomTransformer 
{ 
	public void transform (Document xmlDocument) 
	{
		List<Element> pojistiteleKeSmazani = new ArrayList<Element>();
		Set<String> smlouvyId = new HashSet<String>();
		
		NodeList pojistitele = xmlDocument.getElementsByTagName("pojistitel");
		NodeList smlouvyList = xmlDocument.getElementsByTagName("smlouva");
		
		for(int i = 0; i < smlouvyList.getLength(); ++i)
		{
			String id = getIdRefFromSmlouva(smlouvyList, i);
			
			if(id != null)
				smlouvyId.add(id);
		}
		
		for(int i = 0; i < pojistitele.getLength(); ++i)
		{
			Element pojistitel = (Element)pojistitele.item(i);
			
			if(!maSmlouvu(pojistitel, smlouvyId))
				pojistiteleKeSmazani.add(pojistitel);
		}
		
		for(Element pojistitel : pojistiteleKeSmazani)
		{
			pojistitel.getParentNode().removeChild(pojistitel);
		}
	}

	private String getIdRefFromSmlouva(NodeList smlouvyList, int i)
    {
	    Element smlouva = (Element)smlouvyList.item(i);
	    NodeList refs = smlouva.getElementsByTagName("pojistitel-ref");
	    
	    if(refs.getLength() > 0)
	    {
	    	Element ref = (Element)refs.item(0);
	    	return ref.getAttribute("id");
	    }
	    
	    return null;
    }

	private boolean maSmlouvu(Element pojistitel, Set<String> smlouvyId)
    {
	    String pojistitel_id = pojistitel.getAttribute("id");
	    return smlouvyId.contains(pojistitel_id);
    }
}
