package user;

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;
import java.util.HashMap;

public class MySaxHandler extends DefaultHandler {
    int max = 0; // Maximalni vydaj za jizdne, ktere bylo uvedeno v korunach
    
    boolean elementStat = false; // Jsme uvnitr elementu stat
    HashMap<String, Integer> staty = new HashMap<String, Integer>(); // Staty s pocty sluzebnich cest do jednotlivych statu

    final int MAX_NAKLADY = 5000;
    boolean zahranicni = false; // cesta je zahranicni
    int vydaje = 0; // celkove vydaje na aktualni cestu
    int pocetDrahych = 0; // Pocet vnitrostatnich sluzebnich cest, jejichz celkove naklady presahly MAX_NAKLADY.

    @Override
    public void endDocument() {
        System.out.println("Maximalni cena za jizdne, ktere bylo v korunach, je " + max);
        System.out.println();
        
        System.out.println("Pocty sluzebnich cest pro jednotlive staty:");
        for (String stat : staty.keySet()) {
            System.out.println(stat + ": " + staty.get(stat));
		}
        System.out.println();
        
        System.out.println("Pocet vnitrostatnich sluzebnich cest, jejichz celkove naklady presahly " + MAX_NAKLADY + " je " + pocetDrahych);
        System.out.println();
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) {
        if (localName.equals("jizdne") && atts.getValue("mena").equals("CZK"))
        {
        	int cena = Integer.parseInt(atts.getValue("cena"));
        	if (cena > max)
        		max = cena;
        }
        
        if (localName.equals("stat"))
        	elementStat = true;
        
        if (localName.equals("sluzebni_cesta"))
        {
        	zahranicni = false;
        	vydaje = 0;
        }

        if (localName.equals("zahranicni"))
        	zahranicni = true;
        
        if (localName.equals("jizdne") || localName.equals("noclezne") || localName.equals("stravne") || localName.equals("dalsi_vydaje"))
        	vydaje += Integer.parseInt(atts.getValue("cena"));
    }

    @Override
    public void endElement(String uri, String localName, String qName) {
        if (localName.equals("stat"))
        	elementStat = false;

        if (localName.equals("sluzebni_cesta") && !zahranicni && vydaje > MAX_NAKLADY)
        	pocetDrahych++;
    }
    
    @Override
    public void characters(char[] chars, int start, int length) {
    	if (elementStat)
    	{
	    	int pocet = 0;
	    	String nazev = String.valueOf(chars).substring(start, start + length);
	    	if (staty.containsKey(nazev))
	    		pocet = staty.get(nazev);
	    	
	    	staty.remove(nazev);
	    	staty.put(nazev, pocet + 1);
    	}
    }
}
