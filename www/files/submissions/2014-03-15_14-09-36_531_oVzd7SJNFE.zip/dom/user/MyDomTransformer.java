package user;
import org.w3c.dom.*;

public class MyDomTransformer {
public void transform (Document xmlDocument) {
    // libovolne transformace objektu 'xmlDocument'
    // (metoda pracuje primo na objektu, nic nevraci)
    
        	// Pridani sluzebni cesty
    	
    	Element cesty = (Element) xmlDocument.getElementsByTagName("sluzebni_cesty").item(0);
    	
    	Element cesta = xmlDocument.createElement("sluzebni_cesta");
    	cesta.setAttribute("id", "sluzebni_cesta-12");
    	cesta.setAttribute("schvalil", "zamestnanec-2");
    	cesta.setAttribute("ucel", "klient");
    	cesta.setAttribute("zamestnanec", "zamestnanec-1");
    	
    	Element pocatek = xmlDocument.createElement("pocatek_cesty");
    		pocatek.appendChild(xmlDocument.createElement("misto")).setTextContent("Praha");
    		pocatek.appendChild(xmlDocument.createElement("datum")).setTextContent("5.2.2014");
    	cesta.appendChild(pocatek);
    	
    	Element konec = xmlDocument.createElement("konec_cesty");
    		konec.appendChild(xmlDocument.createElement("misto")).setTextContent("Praha");
    		konec.appendChild(xmlDocument.createElement("datum")).setTextContent("7.2.2014");
    	cesta.appendChild(konec);

    	cesta.appendChild(xmlDocument.createElement("mesto")).setTextContent("Temelin");
    	cesta.appendChild(xmlDocument.createElement("stat")).setTextContent("CR");

    	Element vyuctovani = xmlDocument.createElement("vyuctovani");
			Element jizdne = xmlDocument.createElement("jizdne");
			jizdne.setAttribute("cena", "1300");
			jizdne.setAttribute("mena", "CZK");
			vyuctovani.appendChild(jizdne);
			Element noclezne = xmlDocument.createElement("noclezne");
			noclezne.setAttribute("cena", "2000");
			noclezne.setAttribute("mena", "CZK");
			vyuctovani.appendChild(noclezne);
			Element stravne = xmlDocument.createElement("stravne");
			stravne.setAttribute("cena", "1400");
			stravne.setAttribute("mena", "CZK");
			vyuctovani.appendChild(stravne);
			Element dalsi_vydaje = xmlDocument.createElement("dalsi_vydaje");
			dalsi_vydaje.setAttribute("cena", "700");
			dalsi_vydaje.setAttribute("mena", "CZK");
			vyuctovani.appendChild(dalsi_vydaje);
    	cesta.appendChild(vyuctovani);

		cesta.appendChild(xmlDocument.createElement("shrnuti_cesty")).setTextContent("Oprava turbiny.");
		
		cesty.appendChild(cesta);
		
		// vsem autum z roku 2009 a starsim je nastavena znacka na Skoda, pokud znacka nebyla uvedena
		
		NodeList auta = xmlDocument.getElementsByTagName("auto");
		
		for (int i = 0; i < auta.getLength(); i++) {
			Element auto = (Element) auta.item(i);
			if ((Integer.parseInt(auto.getAttribute("rok_vyroby")) <= 2009) && !auto.hasAttribute("znacka"))
				auto.setAttribute("znacka", "Skoda");
		}
		
		// smaze sluzebni cesty do USA

		NodeList sluzebni_cesty = xmlDocument.getElementsByTagName("sluzebni_cesta");
		
		for (int i = sluzebni_cesty.getLength() - 1; i >= 0; i--) {
			Element sluzebni_cesta = (Element) sluzebni_cesty.item(i); 
			Element stat = (Element) sluzebni_cesta.getElementsByTagName("stat").item(0);
			if (stat.getTextContent().equals("USA"))
				sluzebni_cesta.getParentNode().removeChild(sluzebni_cesta);
		}
    }
  }
