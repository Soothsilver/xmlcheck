/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
/**
 *
 * @author Wolen
 */
 public class MyDomTransformer { 
     public void transform (Document xmlDocument) { 
         // code transforming xmlDocument object 
         // (method works on the object itself - no return value) 
         Node l = xmlDocument.getElementsByTagName("utulek").item(0);
         /**
          * nastavi do update atributu dnesni datum
          */
         Element e = (Element) l;
         e.setAttribute("update", nowDate(0));
         /**
          * smaze aktualizovano
          */
         l = xmlDocument.getElementsByTagName("aktualizovano").item(0);
         e.removeChild(l);
         /**
          * zid id psa a kocky do elementu
          */
         NodeList nl =xmlDocument.getElementsByTagName("pes");
         idToElement(xmlDocument, nl,"zid");
         nl =xmlDocument.getElementsByTagName("kocka");
         idToElement(xmlDocument, nl,"zid");
         /**
          * datum rozdel na den, mesic ,rok
          */
         nl =xmlDocument.getElementsByTagName("prijmuto");
         dateToEachDMY(xmlDocument, nl);
         /**
          * jmeno rozdel na jmeno+prijemni
          */
         nl =xmlDocument.getElementsByTagName("predchoziMajitel");
         splitJmeno(xmlDocument, nl);
         nl =xmlDocument.getElementsByTagName("pujcka");
         splitJmeno(xmlDocument, nl);
         /**
          * ve vupuckach zvire: z attributu element
          */
         nl =xmlDocument.getElementsByTagName("zvire");
         idToElement(xmlDocument, nl,"id");
         /**
          * cislo op z elementu do attributu
          */
         nl =xmlDocument.getElementsByTagName("op");
         elementToatt( nl);
         /**
          * doobednavka
          */
         nl =xmlDocument.getElementsByTagName("potrava");
         newStuff((Element)nl.item(0),10,20,25,15);
     }
     private void newStuff(Element element,int a,int b,int c,int d){
         NodeList nl = element.getChildNodes();
         for (int i = 0; i < nl.getLength(); i++) 
         {
              if ("hmyz".equals(nl.item(i).getNodeName())) {
                 NodeList list=nl.item(i).getChildNodes();
                 for (int j = 0; j < list.getLength(); j++) 
                 {
                      if ("obednano".equals(list.item(j).getNodeName())) {
                          orderStuff(a,(Element)list.item(j) );
                      } 
                 }
             }
              if ("granule".equals(nl.item(i).getNodeName())) {
                 NodeList list=nl.item(i).getChildNodes();
                 for (int j = 0; j < list.getLength(); j++) 
                 {
                      if ("obednano".equals(list.item(j).getNodeName())) {
                          orderStuff(d,(Element)list.item(j) );
                      } 
                 }
             }
              if ("maso".equals(nl.item(i).getNodeName())) {
                 NodeList list=nl.item(i).getChildNodes();
                 for (int j = 0; j < list.getLength(); j++) 
                 {
                      if ("obednano".equals(list.item(j).getNodeName())) {
                          orderStuff(b,(Element)list.item(j) );
                      } 
                 }
             }
              if ("zrni".equals(nl.item(i).getNodeName())) {
                 NodeList list=nl.item(i).getChildNodes();
                 for (int j = 0; j < list.getLength(); j++) 
                 {
                      if ("obednano".equals(list.item(j).getNodeName())) {
                          orderStuff(c,(Element)list.item(j) );
                      } 
                 }
             }
         }
     }
     private void orderStuff(int a,Element e){
         String s = e.getTextContent();
         int i = a + Integer.parseInt(s);
         e.setTextContent(Integer.toString(i));
         e.setAttribute("dodani", nowDate(7));
         
     }
     private void elementToatt( NodeList nl){
         for (int i = 0; i < nl.getLength(); i++) 
         {
              Element e = ((Element)nl.item(i));
              String s = e.getTextContent();
              e.setTextContent("");
              e.setAttribute("numb", s);
         }
     }
     
     private void splitJmeno(Document xmlDocument, NodeList nl){
         for (int i = 0; i < nl.getLength(); i++) 
         {
              Element e = ((Element)nl.item(i));
              NodeList list = e.getChildNodes();
              Node n=null;
              for (int j = 0; j < list.getLength(); j++) 
                 {

                      if("jmeno".equals(list.item(j).getNodeName())){
                          n=list.item(j);
                      }
                 }
              
              String s = n.getTextContent();
              String[] sPole= s.split(" ");
              Element childElement = xmlDocument.createElement("Jmeno");
              childElement.setTextContent(sPole[0]);
              nl.item(i).appendChild(childElement );
              childElement = xmlDocument.createElement("Prijmeni");
              childElement.setTextContent(sPole[1]);
              nl.item(i).appendChild(childElement );
              nl.item(i).removeChild(n);
              
         }
     }

     private void idToElement(Document xmlDocument, NodeList nl,String newElement){
         for (int i = 0; i < nl.getLength(); i++) 
         {
              Element e = ((Element)nl.item(i));
              String s = e.getAttribute(newElement);
              e.removeAttribute(newElement);
              Element childElement = xmlDocument.createElement(newElement);
              childElement.setTextContent(s);
              nl.item(i).appendChild(childElement );
             
         }
     }
     private void dateToEachDMY(Document xmlDocument, NodeList nl){
         for (int i = 0; i < nl.getLength(); i++) 
         {
              Element e = ((Element)nl.item(i));
              String s = e.getTextContent();
              String[] datum = s.split("\\.");
              e.setTextContent("");
              Element childElement = xmlDocument.createElement("den");
              childElement.setTextContent(datum[0]);
              nl.item(i).appendChild(childElement );
              childElement = xmlDocument.createElement("mesic");
              childElement.setTextContent(datum[1]);
              nl.item(i).appendChild(childElement );
              childElement = xmlDocument.createElement("rok");
              childElement.setTextContent(datum[2]);
              nl.item(i).appendChild(childElement );
         }
     }
     public String nowDate(int i){
          Calendar currentDate = Calendar.getInstance();
          SimpleDateFormat formatter=new SimpleDateFormat("dd/MM/yyyy");
          
          currentDate.setTime( currentDate.getTime() );
          currentDate.add( Calendar.DATE, i );

          String dateNow = formatter.format(currentDate.getTime());
          return dateNow;
     }
 }
