package user;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Wolen
 */
import java.util.LinkedList;


import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
public class MySaxHandler extends DefaultHandler { 
    // Umožňuje zacílit místo v dokumentu, kde vznikla aktualní událost
    Locator locator;
    
    /**
     * Nastaví locator
     */     
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Obsluha události "začátek dokumentu"
     */     
    public void startDocument() throws SAXException {
        
        System.out.println("Start document");
        
    }
    /**
     * Obsluha události "konec dokumentu"
     */     
    public void endDocument() throws SAXException {
            System.out.println("V dokumentu je "+allElements+" elementu a maji celkem "+allAttribues+" atributu.\n\n");
            System.out.println("Pocet zvirat v kotci "+kotec.size());
            for (zvire object : kotec) {
                System.out.println( "\t"+object.toString());
               
            }
            System.out.println("Pocet zvirat ve voliere "+voliera.size());
            for (zvire object : voliera) {
                System.out.println( "\t"+object.toString());
               
            }
            System.out.println("Pocet zvirat v terrariu "+terrarium.size());
            for (zvire object : terrarium) {
                System.out.println( "\t"+object.toString());
               
            }
            System.out.println("Lide dajici zvirata do utulku: ");
            for (pMaj object : pMajitele) {
                System.out.println( "\t"+object.toString());
        }
        System.out.println("End document");
        
    }
    
    /**
     * Obsluha události "začátek elementu".
     * @param uri URI jmenného prostoru elementu (prázdné, pokud element není v žádném jmenném prostoru)
     * @param localName Lokální jméno elementu (vždy neprázdné)
     * @param qName Kvalifikované jméno (tj. prefix-uri + ':' + localName, pokud je element v nějakém jmenném prostoru, nebo localName, pokud element není v žádném jmenném prostoru)
     * @param atts Atributy elementu     
     */ 
    private int allElements =0;
     private int allAttribues =0;      
    private boolean inKotec=false;
    private LinkedList<zvire> kotec= new LinkedList();
    private boolean inVoliera=false;
    private LinkedList<zvire> voliera= new LinkedList();
    private boolean inTerrarium=false;
    private LinkedList<zvire> terrarium= new LinkedList();
    private boolean pMajit=false;
    private boolean tel = false;
    private boolean jmeno = false;
    private LinkedList<pMaj> pMajitele= new LinkedList();
    String previusElement = null;
    String wasParrent=null;
    String thief=null;
    class zvire {
        String name;
        String id;
        public zvire(String s, String ss){
            name=s;
            id=ss;
        }
        public String toString(){
            return ("Zvire "+name+" a jeho id "+id);
        }
    }
    class pMaj {
        String name;
        int tel;

        public void set(int i){
            tel=i;
        }
        public void setN(String i){
            name=i;
        }
        public String toString(){
            return ("Majitel "+name+" a jeho telefon "+tel);
        }
    }
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        allElements++;
        int length = atts.getLength();
        allAttribues+=length;
        if("predchoziMajitel".equals(qName)){
            pMajit=true;
            pMajitele.add(new pMaj());
        }
        if("tel".equals(qName)){
            tel=true;
        }
        if("jmeno".equals(qName)){
            jmeno=true;
        }
        if ("kotec".equals(qName)) {
            inKotec=true;
        }else{
            if ("voliera".equals(qName)) {
                inVoliera=true;
            }else{
                if ("terarium".equals(qName)) {
                    inTerrarium=true;
                }else{

                    if (inKotec||inVoliera||inTerrarium) {
                        if("kotec".equals(previusElement)){
                            set(qName);
                            kotec.add(new zvire(qName,atts.getValue(0)));
                        }
                        if("voliera".equals(previusElement)){
                            set(qName);
                            voliera.add(new zvire(qName,atts.getValue(0)));
                        }
                        if("terarium".equals(previusElement)){
                            set(qName);
                            terrarium.add(new zvire(qName,atts.getValue(0)));
                        }
                    }

                    
                }
            }
        }
        previusElement=qName;
    }
    private void set(String qName){
       thief=qName;
       wasParrent=previusElement; 
    }
    /**
     * Obsluha události "konec elementu"
     * Parametry mají stejný význam jako u @see startElement     
     */     
    public void endElement(String uri, String localName, String qName) throws SAXException {
        
        if ("kotec".equals(qName)) {
            inKotec=false;
        }
        if ("voliera".equals(qName)) {
            inVoliera=false;
        }
        if ("terarium".equals(qName)) {
            inTerrarium=false;
        }
        if (qName.equals(thief)) {
            previusElement=wasParrent;
        }
        if("tel".equals(qName)){
            tel=false;
        }
        if("jmeno".equals(qName)){
            jmeno=false;
        }
            
        
    }
    public static boolean isIntegerParseInt(String str) {
        try {
            Integer.parseInt(str);
            return true;
        } catch (NumberFormatException nfe) {}
        return false;
    }
    /**
     * Obsluha události "znaková data".
     * SAX parser muľe znaková data dávkovat jak chce. Nelze tedy počítat s tím, že je celý text dorucen v rámci jednoho volání.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakovými daty
     * @param start Index zacátku úseku platných znakových dat v poli.
     * @param length Délka úseku platných znakových dat v poli.
     */               
    public void characters(char[] ch, int start, int length) throws SAXException {
        if(pMajit&&tel){
            StringBuilder buf = new StringBuilder();
            buf.append(ch, start, length);
            String s = buf.toString();
            if(isIntegerParseInt(s)){
                pMajitele.getLast().set(Integer.parseInt(s));
                pMajit=false;
            }
        }
        if(pMajit&&jmeno){
            StringBuilder buf = new StringBuilder();
            buf.append(ch, start, length);
            String s = buf.toString();
            pMajitele.getLast().setN(s);
        }
        
        
    }
    
    /**
     * Obsluha události "deklarace jmenného prostoru".
     * @param prefix Prefix prirazený jmennému prostoru.
     * @param uri URI jmenného prostoru.
     */     
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha události "konec platnosti deklarace jmenného prostoru".
     */     
    public void endPrefixMapping(String prefix) throws SAXException {
    
        // ...
    
    }

    /**
     * Obsluha události "ignorované bílé znaky".
     * Stejné chování a parametry jako @see characters     
     */     
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha události "instrukce pro zpracování".
     */         
    public void processingInstruction(String target, String data) throws SAXException {
      
      // ...
            
    }

    /**
     * Obsluha události "nezpracovaná entita"
     */         
    public void skippedEntity(String name) throws SAXException {
    
      // ...
    
    }
    

}
