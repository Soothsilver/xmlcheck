/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

/**
 *
 * @author Linh
 */
import org.w3c.dom.Document;
import java.io.File;
import java.util.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;
 public class MyDomTransformer {

    private static final String VSTUPNI_SOUBOR = "../data.xml";
    private static final String VYSTUPNI_SOUBOR = "../data.out.xml";

    public static void main(String[] args) {
        
        try {
            
            //DocumentBuilderFactory vytvárí DOM parsery
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            //nebudeme validovat
            dbf.setValidating(false);

            //vytvoríme si DOM parser
            DocumentBuilder builder = dbf.newDocumentBuilder();

            //parser zpracuje vstupní soubor a vytvorí z nej strom DOM objektu
            Document doc = builder.parse(VSTUPNI_SOUBOR);

            //zpracujeme DOM strom
            transform(doc);

            //TransformerFactory vytvárí serializátory DOM stromu
            TransformerFactory tf = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer = tf.newTransformer();

            //nastavíme kodování
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spustíme transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


        } catch (Exception e) {
            
            e.printStackTrace();
            
        }
    }

    /**
     * Zpracuje DOM strom
     */
    public static void transform(Document doc) {
        HashMap<String, Node> empL = new HashMap<String, Node>();
		NodeList emps = doc.getElementsByTagName("Person");
		for (int i = 0; i < emps.getLength(); i++) {
			Node emp = emps.item(i);
			NodeList elms = emp.getChildNodes();
			for (int j = 0; j < elms.getLength(); j++) {
				Node elm = elms.item(j);
				if (elm.getNodeName().equals("Name")) {
					empL.put(elm.getTextContent(), emp);
				}
			}
		}

		NodeList sEmps = doc.getElementsByTagName("Employees");
		Node elide = sEmps.item(0);


		
		//sort
		Map<String, Node> employees = new TreeMap<String, Node>(empL);
		for (Map.Entry<String, Node> entry : employees.entrySet()) {
			elide.appendChild(entry.getValue()); // kdyz tam existuje tak je nejdrive odstranen a pak vlozen (= presunut na konec)
		}

        
        
    }

 } 
