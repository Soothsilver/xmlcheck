/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

/**
 *
 * @author Linh
 */

//package y36xml;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler; 
import java.util.*;

public class MySaxHandler extends DefaultHandler {

	public static void main(String[] args) {

        // Cesta ke zdrojovému XML dokumentu  
        String sourcePath = "../data.xml";

        try {
            
            // Vytvoríme instanci parseru.
            XMLReader parser = XMLReaderFactory.createXMLReader();
            
            // Vytvoríme vstupní proud XML dat.
            InputSource source = new InputSource(sourcePath);
            
            // Nastavíme náą vlastní content handler pro obsluhu SAX událostí.
            parser.setContentHandler(new MujContentHandler());
            
            // Zpracujeme vstupní proud XML dat.
            parser.parse(source);
            
        } catch (Exception e) {
        
            e.printStackTrace();
            
        }
        
    }
}

/**
 * Náš vlastní content handler pro obsluhu SAX událostí.
 * Implementuje metody interface ContentHandler. 
 */
class MujContentHandler implements ContentHandler {

	private int p = 0;
	
	//  zacílit místo v dokumentu, kde vznikla aktualní událost
	Locator locator;

	/**
	 * Nastaví locator
	 */
	public void setDocumentLocator(Locator locator) {
		this.locator = locator;
	}

	/**
	 * Obsluha události "začátek dokumentu"
	 */
	public void startDocument() throws SAXException {

	// ...

	}

	/**
	 * Obsluha události "konec dokumentu"
	 */
	public void endDocument() throws SAXException {
		System.out.println("Pocet zen: "+p);

	// ...

	}


	/**
	 * Obsluha události "začátek elementu".
	 * @param uri URI jmenného prostoru elementu (prázdné, pokud element není v žádném jmenném prostoru)
	 * @param localName Lokální jméno elementu (vždy neprázdné)
	 * @param qName Kvalifikované jméno (tj. prefix-uri + ':' + localName, pokud je element v nějakém jmenném prostoru, nebo localName, pokud element není v žádném jmenném prostoru)
	 * @param atts Atributy elementu     
	 */

	boolean in = false;
	boolean print = false;
	public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
		if (localName.equals("Person")) {
			for (int i=0; i<atts.getLength(); i++){
				if(atts.getLocalName(i).equals("sex") && atts.getValue(i).equals("Female")) {
					in = true;
					p++;
				}
			}
		}
		if (in && localName.equals("Name")) print = true;
	}

	/**
	 * Obsluha události "konec elementu"
	 * Parametry mají stejný význam jako u @see startElement     
	 */
	public void endElement(String uri, String localName, String qName) throws SAXException {
		if (localName.equals("Person")) {
					in = false;
		}
		if (in && localName.equals("Name")) {
			print = false;		
			System.out.println("");
		}
	}

	/**
	 * Obsluha události "znaková data".
	 * SAX parser muľe znaková data dávkovat jak chce. Nelze tedy pocítat s tím, že je celý text dorucen v rámci jednoho volání.
	 * Text je v poli (ch) na pozicich (start) az (start+length-1).
	 * @param ch Pole se znakovými daty
	 * @param start Index zacátku úseku platných znakových dat v poli.
	 * @param length Délka úseku platných znakových dat v poli.
	 */
	public void characters(char[] ch, int start, int length) throws SAXException {
		if(print) {
			for (int i=start; i<start+length; i++) System.out.print(ch[i]);
		}
	}

	/**
	 * Obsluha události "deklarace jmenného prostoru".
	 * @param prefix Prefix prirazený jmennému prostoru.
	 * @param uri URI jmenného prostoru.
	 */
	public void startPrefixMapping(String prefix, String uri) throws SAXException {

	// ...

	}

	/**
	 * Obsluha události "konec platnosti deklarace jmenného prostoru".
	 */
	public void endPrefixMapping(String prefix) throws SAXException {

	// ...

	}

	/**
	 * Obsluha události "ignorované bílé znaky".
	 * Stejné chování a parametry jako @see characters     
	 */
	public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {

	// ...

	}

	/**
	 * Obsluha události "instrukce pro zpracování".
	 */
	public void processingInstruction(String target, String data) throws SAXException {

	// ...

	}

	/**
	 * Obsluha události "nezpracovaná entita"
	 */
	public void skippedEntity(String name) throws SAXException {

	// ...

	}
}


