package user;

import org.w3c.dom.*;
import java.util.*;

public class MyDomTransformer {

    public void transform(Document xmlDocument) {

        //transformation #1
        //remove projection halls with capactiy lower than 100

        NodeList capacityNodes = xmlDocument.getElementsByTagName("capacity");

        for (int i = capacityNodes.getLength() - 1; i >= 0; i--) {
            Element capacityElement = (Element) capacityNodes.item(i);
            Element capacityElementParent = (Element) capacityElement.getParentNode();
            Element capacityElementParentParent = (Element) capacityElementParent.getParentNode();

            if (Integer.parseInt(capacityElement.getTextContent()) <= 100) {
                capacityElementParentParent.removeChild(capacityElementParent);
            }
        }

        // transformation #2
        // add a new movie to the xml file

        NodeList movieNode = xmlDocument.getElementsByTagName("movies");

        if (movieNode.getLength() >= 0) { //check if movies node exists
            Element movie = xmlDocument.createElement("movie");
            movie.setAttribute("id", "m55");
            movie.appendChild(xmlDocument.createElement("name")).setTextContent("Schindler's list");
            movie.appendChild(xmlDocument.createElement("category")).setTextContent("Drama");
            movie.appendChild(xmlDocument.createElement("suitableFrom")).setTextContent("16");
            movie.appendChild(xmlDocument.createElement("length")).setTextContent("240");
            movie.appendChild(xmlDocument.createElement("price")).setTextContent("1");
            movie.appendChild(xmlDocument.createElement("country")).setTextContent("USA");
            movie.appendChild(xmlDocument.createElement("director")).setTextContent("Steven Spielberg");
            movie.appendChild(xmlDocument.createElement("language")).setTextContent("English");
            movie.appendChild(xmlDocument.createElement("subtitles")).setTextContent("Czech");

            movieNode.item(0).appendChild(movie);
        }

        // transformation #3
        // sort the movies by title name

        NodeList movieNode2 = xmlDocument.getElementsByTagName("movies");

        if (movieNode2.getLength() >= 0) { //check if movies node exists
            sortChildNodes(movieNode2.item(0), true, null);
        }
    }

    public static void sortChildNodes(Node node, boolean descending, Comparator comparator) {

        List nodes = new ArrayList();
        NodeList childNodeList = node.getChildNodes();
        if (childNodeList.getLength() > 0) {
            for (int i = 0; i < childNodeList.getLength(); i++) {
                Node tNode = childNodeList.item(i);  
                if (tNode.getNodeName().equals("movie")){
                    nodes.add(tNode);
                }
            }
            
            Comparator comp = (comparator != null) ? comparator
                    : new DefaultNodeNameComparator();
            if (descending) {                     //if descending is true, get the reverse ordered comparator
                Collections.sort(nodes, Collections.reverseOrder(comp));
            } else {
                Collections.sort(nodes, comp);
            }

            //removeAllChildNodes(node);

            for (Iterator iter = nodes.iterator(); iter.hasNext();) {
                Node element = (Node) iter.next();
                node.appendChild(element);
            }
        }

    }

}

class DefaultNodeNameComparator implements Comparator {

    public int compare(Object arg0, Object arg1) {           
        return ((Node) arg0).getChildNodes().item(1).getTextContent().compareTo(
                ((Node) arg1).getChildNodes().item(1).getTextContent());
    }
}