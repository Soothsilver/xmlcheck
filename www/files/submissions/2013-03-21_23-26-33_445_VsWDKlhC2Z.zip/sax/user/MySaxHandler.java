package user;

import java.util.ArrayList;
import java.util.Collections;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;


public class MySaxHandler extends DefaultHandler {

    // Helper variable to store location of the handled event
    Locator locator;
    
    boolean isMovieLength = false;
    int totalLength = 0;
    
    boolean isMovie = false;
    ArrayList<String> movieIDs = new ArrayList<String>();
    
    boolean isLanguage = false;
    boolean isSubtitles = false;
    boolean languageSet = false;
    String lastLanguage = "";
    int czLanguageCzSubtitlesCount = 0;

    /**
     * Sets the locator
     *
     * @param Locator locator location in the file
     */
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Method to handle "document start"
     *
     * @throws SAXException
     */
    @Override
    public void startDocument() throws SAXException {
        // ...
    }

    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
        
        // calculation #1
        // most common movie id
        Collections.sort(movieIDs);   
        String maxIndex = findMostCommon(movieIDs);
        System.out.println("Most common movie id is: " + maxIndex);
        
        // calculation #2
        // total movie length
        System.out.println("Total movie length is: " + totalLength);
        
        // calculation #3
        // number of films with czech subtitles and english language
        
        System.out.println("List of films with czech subtitles and english language: " + czLanguageCzSubtitlesCount);
    }
    
    private String findMostCommon(ArrayList<String> list){
        
        int currentCount = 1;
        int currentIndex = 0;
        int maxIndex = 0;
        int maxCount = 0;
        for (int k = 0; k < list.size(); k++){
            for (int i = 0; i < list.size(); i++){
                if (list.get(i).equals(list.get(currentIndex))){
                    currentCount++;
                }
            }
            if (currentCount > maxCount){
                maxCount = currentCount;
                maxIndex = currentIndex;
            }
            currentIndex++;
            currentCount = 1;
        }
        return list.get(maxIndex);
    }

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if (localName.equals("length")){
            isMovieLength = true;
        }
        
        if (localName.equals("movie")){
            String id = atts.getValue("","id");
            movieIDs.add(id);
        }
        
        if (localName.equals("language")){
            isLanguage = true;
        }
        
        if (localName.equals("subtitles")){
            isSubtitles = true;
        }
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        // ...
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        if (isMovieLength){
            totalLength += Integer.parseInt(new String(chars, start, length));
            isMovieLength = false;
        }
        
        if (isLanguage && !languageSet){
            lastLanguage = new String(chars, start, length);
            languageSet = true;
        }
        
        if (isLanguage && isSubtitles){
            String lastSubtitles = new String(chars, start, length);
            
            if (lastSubtitles.equals("cs") && lastLanguage.equals("cs")){
                czLanguageCzSubtitlesCount++;
            }
            isLanguage = false;
            isSubtitles = false;
            languageSet = false;
        }
        
        
        
        
    }

    /**
     * Method to handle " start of namespace declaration"
     *
     * @param prefix Prefix of the namespace
     * @param uri URI of the namespace
     * @throws SAXException
     */
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    /**
     * Method to handle "end of namespace declaration"
     *
     * @param prefix
     * @throws SAXException
     */
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    /**
     * Method to handle "ignoring of whitespaces" Text is in array 'chars' from
     * position ('start') to ('start' + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     * @throws SAXException
     */
    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
        // ...
    }

    /**
     * Method to handle "processing instructions"
     *
     * @param target The processing instruction target
     * @param data  The processing instruction data
     * @throws SAXException
     */
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

    /**
     * Method to handle "unprocessed entity"
     *
     * @param name
     * @throws SAXException
     */
    @Override
    public void skippedEntity(String name) throws SAXException {
        // ...
    }
}
