package user;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/*
class Main {
    
    public static void main(String[] args) {
        String inputPath="data.xml";
        try {            
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setValidating(false);
            DocumentBuilder builder = dbf.newDocumentBuilder();
            Document doc = builder.parse(inputPath);
            
            new MyDomTransformer().transform(doc);

            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer writer = tf.newTransformer();

            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            writer.transform(new DOMSource(doc), new StreamResult(new File(inputPath+".xml")));
        } catch (Exception e) {            
            e.printStackTrace();            
        }
    }
    
    /*public static void main(String[] args) {
        String inputPath="data.xml";
        
        try {
            XMLReader parser = XMLReaderFactory.createXMLReader();
            InputSource source = new InputSource(inputPath);
            parser.setContentHandler(new MySaxHandler());
            parser.parse(source);            
        } catch (Exception e) {        
            e.printStackTrace();            
        }
    }
    
}
*/
public class MySaxHandler extends DefaultHandler {

    private int elementsLength,attributesLength,whitespaceLength,usefulLength,otherLength;
    
    @Override
    public void startDocument() throws SAXException {
        elementsLength=0;
        attributesLength=0;
        whitespaceLength=0;
        usefulLength=0;
        otherLength=0;
    }

    @Override
    public void endDocument() throws SAXException {
        float quotient=usefulLength/(float)(elementsLength+attributesLength+whitespaceLength+usefulLength+otherLength);
        quotient*=100;
        System.out.println(String.format("Quotient: %f%%", quotient));
    }    
    
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        usefulLength+=length;
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        elementsLength+=qName.length()+2;
        
        for (int i=0;i<attributes.getLength();i++) {
            attributesLength+=attributes.getQName(i).length();
            usefulLength+=attributes.getValue(i).length();
        }
    }

    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        otherLength+=data.length();
    }    
    
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        elementsLength+=qName.length()+3;
    }

    @Override
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        whitespaceLength+=length;
    }
    
}