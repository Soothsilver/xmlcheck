package user;

import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

import java.util.HashMap;
import java.util.Set;

/**
 * Náš vlastní content handler pro obsluhu SAX událostí.
 * Implementuje metody interface ContentHandler. 
 */ 
public class MySaxHandler extends DefaultHandler 
{
	/* the bussiness logic implementation */
	private Statistics statistics;
	
	/** the current author id */
	private String currentKey;
	
	/** a buffer to store temporary character data */
	private String buffer;
	
	/** mode-indicating flags */
	private boolean modeFirstname, modeSurname;
	
    // Umožňuje zacílit místo v dokumentu, kde vznikla aktualní událost
    Locator locator;
 
    public static void main(String[] args) 
    {
        // Cesta ke zdrojovému XML dokumentu  
        String sourcePath = "data.xml";

        try {
            
            // Vytvoríme instanci parseru.
            XMLReader parser = XMLReaderFactory.createXMLReader();
            
            // Vytvoríme vstupní proud XML dat.
            InputSource source = new InputSource(sourcePath);
            
            // Nastavíme náą vlastní content handler pro obsluhu SAX událostí.
            parser.setContentHandler(new MySaxHandler());
            
            // Zpracujeme vstupní proud XML dat.
            parser.parse(source);
            
        } catch (Exception e) {
        
            e.printStackTrace();
            
        }
        
    }
    
    /**
     * Nastaví locator
     */     
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Obsluha události "začátek dokumentu"
     */     
    public void startDocument() throws SAXException 
	{
		statistics = new Statistics();
		currentKey = "";
		modeFirstname = modeSurname = false;
    }
    /**
     * Obsluha události "konec dokumentu"
     */     
    public void endDocument() throws SAXException 
	{
		System.out.println(statistics);
    }
    
    /**
     * Obsluha události "začátek elementu".
     * @param uri URI jmenného prostoru elementu (prázdné, pokud element není v žádném jmenném prostoru)
     * @param localName Lokální jméno elementu (vždy neprázdné)
     * @param qName Kvalifikované jméno (tj. prefix-uri + ':' + localName, pokud je element v nějakém jmenném prostoru, nebo localName, pokud element není v žádném jmenném prostoru)
     * @param atts Atributy elementu     
     */     
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException 
	{
		if (localName.equals("author"))
		{
			currentKey = atts.getValue("id");
			
			// initiates an item for the current author
			statistics.newItem(currentKey);
			
			return;
		}
		
		buffer = "";
		
		if (localName.equals("firstname"))
			modeFirstname = true;
			
		if (localName.equals("surname"))
			modeSurname = true;
		
		// sends "a new book found" message to the statistics object
		if (localName.equals("book") || localName.equals("magazine"))
			statistics.increment(atts.getValue("author_id"));
    }
    /**
     * Obsluha události "konec elementu"
     * Parametry mají stejný význam jako u @see startElement     
     */     
    public void endElement(String uri, String localName, String qName) throws SAXException 
	{
		if (modeFirstname && localName.equals("firstname"))
		{
			// sets the firstname of the current author
			statistics.setFirstname(currentKey, buffer);
			modeFirstname = false;
		}
			
		if (modeSurname && localName.equals("surname"))
		{
			// sets the surname of the current author
			statistics.setSurname(currentKey, buffer);
			modeSurname = false;
		}
    }
    
    /**
     * Obsluha události "znaková data".
     * SAX parser muľe znaková data dávkovat jak chce. Nelze tedy počítat s tím, že je celý text dorucen v rámci jednoho volání.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakovými daty
     * @param start Index zacátku úseku platných znakových dat v poli.
     * @param length Délka úseku platných znakových dat v poli.
     */               
    public void characters(char[] ch, int start, int length) throws SAXException 
	{
    	// stores the characters to the buffer to be read later
		for (int i = start; i < start + length; i++)
			buffer += ch[i];
    }
}

/**
 * Description: Stores statistics (the numbers of registered books) about 
 * the registered authors.
 *
 * @author Dušan Rychnovský
 * @version 0.1 (18.5.2011 16:29:28)
 */
class Statistics
{
	private HashMap<String, StatItem> data;
	
	public Statistics()
	{
		this.data = new HashMap<String, StatItem>();
	}
	
	/**
	 * Creates a record for a new author (to be indexed by the given key).
	 */
	public void newItem(String key)
	{
		data.put(key, new StatItem());
	}
	
	/**
	 * Sets the firstname for the given author.
	 */
	public void setFirstname(String key, String firstname)
	{
		data.get(key).setFirstname(firstname);
	}

	/**
	 * Sets the surname for the given author.
	 */
	public void setSurname(String key, String surname)
	{
		data.get(key).setSurname(surname);
	}
	
	/**
	 * Increments the number of registered books for the given author.
	 */
	public void increment(String key)
	{
		data.get(key).increment();
	}
	
	/**
	 * Prints the statistics.
	 */
	@Override
	public String toString()
	{
		String result = "";
		Set<String> keys = data.keySet();
		for (String key : keys)
			result += data.get(key) + "\n";
		
		return result;
	}
}

/**
 * Description: A record for an author.
 *
 * @author Dušan Rychnovský
 * @version 0.1 (18.5.2011 16:31:25)
 */
class StatItem
{
	private String firstname, surname;
	private int count;
	
	public StatItem()
	{
		firstname = surname = "";
		count = 0;
	}
	
	/**
	 * Sets their firstname.
	 */
	public void setFirstname(String firstname)
	{
		this.firstname = firstname;
	}

	/**
	 * Sets their surname.
	 */
	public void setSurname(String surname)
	{
		this.surname = surname;
	}

	/**
	 * Increments the number of books by the represented author registered.
	 */
	public void increment()
	{
		count++;
	}
	
	/**
	 * Prints the author related line of the statistics.
	 */
	@Override
	public String toString()
	{
		return surname + ", " + firstname + ": " + count;
	}
}
