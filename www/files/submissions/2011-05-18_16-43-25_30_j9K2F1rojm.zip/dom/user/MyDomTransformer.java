package user;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

/**
 * ZADANI:
 * Upravte program tak, aby transformoval vstupní XML dokument na výstupní pomocí akcí
 * uvedených v komentářích metody processTree(doc).
 */
public class MyDomTransformer {

    private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "data.out.xml";

    public static void main(String[] args) {
        
        try {
            
            //DocumentBuilderFactory vytváří DOM parsery
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            //nebudeme validovat
            dbf.setValidating(false);

            //vytvoříme si DOM parser
            DocumentBuilder builder = dbf.newDocumentBuilder();

            //parser zpracuje vstupní soubor a vytvoří z něj strom DOM objektů
            Document doc = builder.parse(VSTUPNI_SOUBOR);

            //zpracujeme DOM strom
			new MyDomTransformer().transform(doc);

            //TransformerFactory vytváří serializátory DOM stromů
            TransformerFactory tf = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer = tf.newTransformer();

            //nastavíme kodování
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spustíme transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


        } catch (Exception e) {
            
            e.printStackTrace();
            
        }
    }

    /**
     * Zpracuje DOM strom
     */
    public void transform(Document xmlDocument) 
    {
    	// get the parent element of all books
    	Node elBooks = xmlDocument.getElementsByTagName("books").item(0);
    	if (elBooks == null) return;
    	
    	// list its children (e.g. book and magazine elements)
    	NodeList books = elBooks.getChildNodes();
    	
    	// iterate over them and move each of them to the appropriate author element
    	for (int i = 0; i < books.getLength(); i++)
    	{
    		if (books.item(i).getNodeType() != Node.ELEMENT_NODE)
    			continue;
    		
    		Element book = (Element)books.item(i);
    		dispatchBook(xmlDocument, book);    		
    	}
    }
    
    /**
     * Moves the given book (or magazine) element as a subelement
     * of the appropriate author element.
     */
	private void dispatchBook(Document doc, Element book)
    {
		String author_id = book.getAttribute("author_id");
		Element author = getAuthorById(doc, author_id);
		
		// remove the book element of its former place
		book.getParentNode().removeChild(book);
		
		// set a new place for it
		author.appendChild(book);		 
    }
    
    /**
     * Returns the author element with the corresponding id - if such
     * element exists, null otherwise.
     */
    private Element getAuthorById(Document doc, String id)
    {
		NodeList authors = doc.getElementsByTagName("author");
		
		for (int i = 0; i < authors.getLength(); i++)
		{
			Element author = (Element)authors.item(i);
			if (id.equals(author.getAttribute("id")))
				return author;
		}
		
		return null;
    }
}
