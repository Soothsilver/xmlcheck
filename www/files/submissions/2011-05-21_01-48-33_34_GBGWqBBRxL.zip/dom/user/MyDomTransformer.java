package user;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;


public class MyDomTransformer {
	
    // pro ka�dou zast�vku (element station), zjist�, zda je pou�ita (tzn. existuje n�jak� stref, kter� ji referencuje), pokud ne, tuto zast�vku sma�e; v�sledkem je tedy identick� dokument bez nepot�ebn�ch zast�vek
    public void transform(Document doc) {

        NodeList pouzite = doc.getElementsByTagName("stref");
        NodeList vsechny = doc.getElementsByTagName("station");
        
        for(int s = 0; s < vsechny.getLength(); ++s)
        {
            Boolean pouzita = false;
            String id = vsechny.item(s).getAttributes().getNamedItem("id").getNodeValue();
            for(int i = 0; i < pouzite.getLength(); ++i)
            {
                String refId = pouzite.item(i).getAttributes().getNamedItem("id").getNodeValue();
                if(id.equals(refId))
                {
                    pouzita = true;
                    break;
                }
            }
            
            if(!pouzita)
            {
                vsechny.item(s).getParentNode().removeChild(vsechny.item(s));
		--s;
            }
        }
    }
}
