package user;

import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;

// pr�b�n� p�i proch�zen� dokumentu po��t� zast�vky (element station) a linky (elementy line nebo specialLine) a jejich po�ty na konci vyp�e


public class MySaxHandler extends DefaultHandler {

    Locator locator;
    int stopCount = 0;
    int lineCount = 0;
       
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    public void endDocument() throws SAXException {
        System.out.println("Pocet zastavek v systemu: " + stopCount);
        System.out.println("Pocet linek v systemu: " + lineCount);
    }
     
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if(localName.equals("station"))
        {
            stopCount++;
        }
        else if(localName.equals("line") || localName.equals("specialLine"))
        {
            lineCount++;
        }
    }
}