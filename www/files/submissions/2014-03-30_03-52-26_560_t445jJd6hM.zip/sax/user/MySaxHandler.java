/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package user;

import java.util.ArrayList;
import java.util.List;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
/**
 * UKOL XML IMPLEMENTACE SAX Handleru
 * @author Tran Tuan Hiep
 */
public class MySaxHandler extends DefaultHandler {
    
    // ruzne atributy
    int ageSum;
    int personSize;
    
    boolean isMovie;
    boolean isTitle;
    boolean isLength;
    boolean isColor;
    boolean colorTest;
    
    String movieName;
    int maxLength;
    String longestMovie;
    
    int castSize = 0;
    List<String> cMovies;

    public MySaxHandler() {
        this.ageSum = 0;
        this.castSize = 0;
    }
    
    
     @Override
    public void startDocument() throws SAXException {
        super.startDocument();
        // udaje k vypoctu prumerneho veku
        this.ageSum = 0; // 
        this.personSize = 0;
        this.maxLength = Integer.MIN_VALUE;
        // filmy ktere splnuji podminku ze
        // jsou cernobile a zaroven maji alespon 5 hercu
        cMovies = new ArrayList<String>(); 
               
    }

    @Override
    public void endDocument() throws SAXException {
        super.endDocument(); 
        System.out.printf("average age:%f",(double) ageSum/personSize);
        System.out.printf("longestMovie :%s\n",longestMovie);
        System.out.println("black and white movie with more than 5 actors:");
        for ( String s: cMovies ) {
            System.out.println(s);
        }
    }
    
   
    
     @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        
       // na zacatek elementu nastavim flagy ktery potrebuju
        if ( qName.equals("person") ) {   
            ageSum += Integer.parseInt(attributes.getValue("age"));
            personSize++;
        } else if ( qName.equals("movie")) {
            isMovie = true;            
        } else if ( qName.equals("title")) {
            isTitle = true;            
        } else if ( qName.equals("length")) {
            isLength=true;
        } else if ( qName.equals("actor") && isMovie ) {
            castSize++;
        } else if ( qName.equals("color")) {
            isColor = true;
        }
        
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
       // na konci zas "odflaguju"
        if ( qName.equals("movie") && isMovie ) {
            if (colorTest && castSize > 4) {
                cMovies.add(movieName);
            }
            isMovie = false;
            movieName = null;
            castSize = 0;
        } else if ( qName.equals("title")) {
            isTitle = false;            
        } else if ( qName.equals("length")) {
            isLength= false;
        } else if ( qName.equals("color")) {
            isColor = false;
        }
            
        
    }

     @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        // zpracuju hodnoty 
        String data = new String( ch, start, length );
         if (isMovie) {
             if (isTitle) {
                 //System.out.println(data);
                 movieName = data.trim();                 
             } else if (isLength) {
                 int movieLength = Integer.parseInt(data.trim());
                 if ( movieLength > maxLength ) {
                     longestMovie = movieName;                     
                 }
             } else if ( isColor ) {
                 String color = data.trim();
                 colorTest = color.equalsIgnoreCase("black and white");                    
             }
         }

    }
   
    
    
}
