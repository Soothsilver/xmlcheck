/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package user;

/**
 *
 * @author honza
 */

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


/**
 * trida pro ukol xml dom
 * @author Tran Tuan Hiep
 */
public class MyDomTransformer {
    Document doc = null;
    
    // funkce nacte xml fileName a zpracuje data a ulozi do xml souboru outputFileName
    public void process(String fileName, String outputFileName ) {
        try {
            // nactu 
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setValidating(false);

            DocumentBuilder builder = dbf.newDocumentBuilder();

            Document domDoc = builder.parse(new File(fileName));
            // zpracuju
            transform(domDoc);
            
            // ulozim 
            TransformerFactory tf = TransformerFactory.newInstance();
            
            Transformer writer = tf.newTransformer();
            
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            writer.setOutputProperty(OutputKeys.INDENT, "yes");
            writer.transform( new DOMSource(domDoc), new StreamResult(new File(outputFileName)) );

        } catch ( Exception e ) {
            System.out.println(e.toString());
            System.exit(1);
        } 
            
        
    }
    
    public void transform( Document xmlDocument ) {
        this.doc = xmlDocument;
        
        // najdu element person_list
        NodeList tmpPersonList = xmlDocument.getElementsByTagName("person_list");
        Node personList = tmpPersonList.item(0);
        // 1 pridam novou osobu
        personList.appendChild( createNewPerson("p9","Franta Novotny","male",95 ) );
      
        // najdu vsechny filmy v xml souboru
        NodeList movies = xmlDocument.getElementsByTagName("movie");
        // updatu jejich seznam
        // vsechny co nebudou vyhovovat Criteria.isOK
        // vymazem 
        update( movies, new Criteria() {

            @Override
            public boolean isOK(Element el) {
                Node tmp = el.getElementsByTagName("language").item(0);
                if (tmp == null) {
                    return true;
                }
                
                
                String languageText = tmp.getFirstChild().getNodeValue().trim();
                // vymazem vsechny cesky mluvene filmy
                return !languageText.equalsIgnoreCase("czech");
                
            }
        });
              
        this.doc = null;
        
    }
    
    /**
     * vytvori element person 
     * @param id
     * @param name
     * @param sex
     * @param age
     * @return 
     */
    Node createNewPerson( String id, String name, String sex, int age ) {
        Element person = doc.createElement("person");
        person.setAttribute("p_id", id);
        person.setAttribute("name", name);
        person.setAttribute("sex", sex);
        person.setAttribute("age", String.valueOf(age));
        
        return person;
    }

    /**
     * vymaze vsechny criteriu neodpovidajici prvky 
     * @param movies
     * @param criteria 
     */
    private void update(NodeList movies, Criteria criteria) {
        ArrayList<Node> remove = new ArrayList<>();
        for (int i = 0; i < movies.getLength(); i++ ) {
            Node iNode = movies.item(i);
            if (!criteria.isOK((Element) iNode)) {
                remove.add(iNode);
            }
        }
        
        for ( Node n: remove ) {
            n.getParentNode().removeChild(n);
        }
        
    }

    interface Criteria {
        boolean isOK( Element el ) ;
    }
   
}
