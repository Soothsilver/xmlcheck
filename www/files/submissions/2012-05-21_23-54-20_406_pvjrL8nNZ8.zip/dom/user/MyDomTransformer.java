package user;

import java.io.*;
import java.util.LinkedList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

public class MyDomTransformer {

    Document doc;
    String outputfile;

    public MyDomTransformer(Document doc) {
        this.doc = doc;

    }

//    public static void main(String[] args) {
//        try {
//
//            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
//            dbf.setValidating(false);
//            DocumentBuilder builder = dbf.newDocumentBuilder();
//            Document doc = builder.parse("data.xml");
//
//            MyDomTransformer t = new MyDomTransformer(doc);
//            t.processTree();
//            TransformerFactory tf = TransformerFactory.newInstance();
//            Transformer writer = tf.newTransformer();
//            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
//            writer.transform(new DOMSource(doc), new StreamResult(new File("dataoutputdom.xml")));
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

    public void transform(Document xmlDocument) {

        try {

            MyDomTransformer t = new MyDomTransformer(xmlDocument);
            t.processTree();
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer writer = tf.newTransformer();
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            writer.transform(new DOMSource(xmlDocument), new StreamResult(new File("dataoutputdom.xml")));


        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    void processAttributes(Node attr) {
    }

    /**
     * transformuje elementy signatura u elementu vypujcka/exemplare na element
     * signatura a podelementy id s text. obsahem z puvodniho atributu
     * +(odstrani element exemplare)
     */
    void transformAtts(Node node) {
        //node == exemplare

        if (node.hasChildNodes()) {

            Element signatury = doc.createElement("signatury");

            NodeList nodes = node.getChildNodes();
            for (int i = 0; i < nodes.getLength(); i++) {

                Node child = nodes.item(i);//signatura
                if (child.hasAttributes()) {
                    NamedNodeMap childAttr = child.getAttributes();
                    Element id = doc.createElement("id");
                    id.setTextContent(childAttr.item(0).getNodeValue());
                    signatury.appendChild(id);
                    node.removeChild(child);
                }
            }
            Node parent = node.getParentNode();
            parent.removeChild(node);
            parent.appendChild(signatury);
//            node.appendChild(signatury);
        }

    }

    /**
     * obrati poradi vypujcek
     *
     * @param node
     */
    void reverse(Node node) {

        //node = vypujcky
        if (node.hasChildNodes()) {


            NodeList nodes = node.getChildNodes();
            List<Node> list = new LinkedList<Node>();

            for (int i = 0; i < nodes.getLength(); i++) {
                Node n = nodes.item(i);
                if (n.getNodeType() == Node.ELEMENT_NODE && n.getNodeName().equals("vypujcka")) {
                    list.add(n.cloneNode(true));
                    node.removeChild(n);
                }
            }

            for (int i = list.size() - 1; i >= 0; i--) {
                node.appendChild(list.get(i));
            }

        }

    }

    void processNode(Node node) {
        if (node.getNodeName().equals("exemplare")) {
            transformAtts(node);
        }

        if (node.getNodeName().equals("vypujcky")) {
            reverse(node);
        }

        if (node.hasAttributes()) {
            NamedNodeMap a = node.getAttributes();
            for (int i = 0; i < a.getLength(); i++) {
                processAttributes(a.item(i));
            }
        }
        for (Node iter = node.getFirstChild(); iter != null; iter = iter.getNextSibling()) {
            processNode(iter);
        }

    }

    void processTree() {


        Element elem = doc.getDocumentElement();
        elem.normalize();

        addEmp(elem);

        NodeList nodes = elem.getChildNodes();
        for (int i = 0; i < nodes.getLength(); i++) {
            processNode(nodes.item(i));
        }


    }

    /**
     * prida zamestnance
     *
     * @param node
     */
    void addEmp(Node node) {
        NodeList personal = doc.getElementsByTagName("personal");

        if (personal == null) {
            Element pers = doc.createElement("pesonal");
            node.appendChild(pers);
        }

        //find unique id
        int cnt = 1;
        String newid = "zamestnanec1";
        Element dummy = doc.getElementById(newid);
        while (true) {
            if (dummy == null) {
                System.out.println("newid " + newid);
                break;
            } else {
                newid = "zamestnanec" + (++cnt);
                dummy = doc.getElementById(newid);
            }

        }
        Element zamestnanec = doc.createElement("zamestnanec");
        zamestnanec.setAttribute("id", newid);

        Element jmenozam = doc.createElement("jmeno-zam");
        jmenozam.setTextContent("addEmpjmenozamaddEmp");
        Element prijmenizam = doc.createElement("prijmeni-zam");
        prijmenizam.setTextContent("prijmenizam");
        Element funkcezam = doc.createElement("funkce-zam");
        funkcezam.setTextContent("funkcezam");
        Element mzda = doc.createElement("mzda");
        mzda.setTextContent("mzda");
        Element hodinovamzda = doc.createElement("hodinova-mzda");
        hodinovamzda.setTextContent("hodinovamzda");
        Element pocethodin = doc.createElement("pocet-hodin");
        pocethodin.setTextContent("pocethodin");
        mzda.appendChild(hodinovamzda);
        mzda.appendChild(pocethodin);


        Element adresa = doc.createElement("adresa");
        Element ulicezam = doc.createElement("ulice-zam");
        pocethodin.setTextContent("ulicezam");

        Element cisloUlice = doc.createElement("cislo-ulice-za");
        cisloUlice.setTextContent("cisloUlice");

        Element mesto = doc.createElement("mesto-zam");
        mesto.setTextContent("mesto");

        Element psc = doc.createElement("psc-zam");
        psc.setTextContent("psc");

        Element stat = doc.createElement("stat-zam");
        stat.setTextContent("stat");

        adresa.appendChild(ulicezam);
        adresa.appendChild(cisloUlice);
        adresa.appendChild(mesto);
        adresa.appendChild(psc);
        adresa.appendChild(stat);

        Element telefon = doc.createElement("telefon-zam");
        telefon.setTextContent("telefon");

        Element email = doc.createElement("email-zam");
        email.setTextContent("email");



        Element datumnastupu = doc.createElement("datum-nastupu");
        Element nastupden = doc.createElement("nastup-den");
        nastupden.setTextContent("23");
        Element nastupmesic = doc.createElement("nastup-mesic");
        nastupmesic.setTextContent("05");
        Element nastuprok = doc.createElement("nastup-rok");
        nastuprok.setTextContent("2010");
        datumnastupu.appendChild(nastupden);
        datumnastupu.appendChild(nastupmesic);
        datumnastupu.appendChild(nastuprok);

        Element datumodchodu = doc.createElement("datum-odchodu");
        Element odchodden = doc.createElement("odchod-den");
        odchodden.setTextContent("2");
        Element odchodmesic = doc.createElement("odchod-mesic");
        odchodmesic.setTextContent("12");
        Element odchodrok = doc.createElement("odchod-rok");
        odchodrok.setTextContent("2011");

        datumodchodu.appendChild(odchodden);
        datumodchodu.appendChild(odchodmesic);
        datumodchodu.appendChild(odchodrok);

        personal.item(0).appendChild(zamestnanec);
        zamestnanec.appendChild(jmenozam);
        zamestnanec.appendChild(prijmenizam);
        zamestnanec.appendChild(funkcezam);
        zamestnanec.appendChild(mzda);
        zamestnanec.appendChild(adresa);
        zamestnanec.appendChild(telefon);
        zamestnanec.appendChild(email);
        zamestnanec.appendChild(datumnastupu);
        zamestnanec.appendChild(datumodchodu);

    }
}
