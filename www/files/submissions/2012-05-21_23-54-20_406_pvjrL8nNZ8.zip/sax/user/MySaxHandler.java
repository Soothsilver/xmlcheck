package user;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.Map.Entry;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

public class MySaxHandler extends DefaultHandler {

    BufferedWriter bf;
    Locator locator;
    int indent;
    int numOfElems;
    int numOfAtts;
    //validacevypujcek
    Stack<String> vypujcky = new Stack<String>();
    List<Error> errors = new LinkedList<Error>();
    // hlavni stack
    Stack<String> stack = new Stack<String>();
    List<String> textElements = new LinkedList<String>();
    //elementy s atributy 
    List<String> elemsWithAtts = new LinkedList<String>();
    //elementy s podelementy
    List<String> elemsWithSubElems = new LinkedList<String>();
    //element = K , V = seznam podelementu(fanout)
    Map<String, List<String>> fanout = new HashMap<String, List<String>>();
    //hloubka elementu, korenovej element knihovna ma hloubku 0
    Map<String, Integer> depth = new HashMap<String, Integer>();

    public MySaxHandler(BufferedWriter bf) {
        this.bf = bf;
    }

    public static void main(String[] args) {
        String sourcePath = "data.xml";
        BufferedWriter bf = null;
        try {

            XMLReader parser = XMLReaderFactory.createXMLReader();

            InputSource source = new InputSource(sourcePath);

            bf = new BufferedWriter(new FileWriter(new File("dataoutputsax.xml")));

            MySaxHandler mch = new MySaxHandler(bf);
            parser.setContentHandler(mch);

            try {
                parser.parse(source);
            } catch (SAXException se) {
            }
        } catch (Exception e) {
        } finally {
            try {
                bf.close();
            } catch (IOException ex) {
            }
        }
    }

    void writeSpaces(int num) {
        try {
            for (int i = 0; i < num; i++) {
                bf.write(" ");
            }
        } catch (IOException ex) {
        }
    }

    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    public void endDocument() throws SAXException {
        System.out.println("num of elemens " + numOfElems);
        System.out.println("num of atts " + numOfAtts);


        //fanout
        double sumOfFanouts = 0;
        for (Map.Entry<String, List<String>> entry : fanout.entrySet()) {
            sumOfFanouts += entry.getValue().size();

        }

        // AVERAGE FANOUT
        double avgFanOut = sumOfFanouts / fanout.entrySet().size();
        System.out.println(avgFanOut);
        try {
            bf.write("<avgFanOut>");
            bf.write(avgFanOut + "");
            bf.write("</avgFanOut>");
        } catch (IOException ex) {
        }

// AVERAGE DEPTH
        double sumOfDepths = 0;
        System.out.println("\n depth \n");
        for (Map.Entry<String, Integer> entry : depth.entrySet()) {
            sumOfDepths += entry.getValue();
        }
        double avgDepth = sumOfDepths / depth.entrySet().size();
        System.out.println(avgDepth);
        try {
            bf.write("<avgDepth>");
            bf.write(avgDepth + "");
            bf.write("</avgDepth>");
            bf.flush();
        } catch (IOException ex) {
        }



        //num of textElements
        System.out.println("\ntext elemets\n");
        for (String string : this.textElements) {
        }

        //num of elemsWithAtts
        System.out.println("\nelemsWithAtts\n ");
        for (String string : this.elemsWithAtts) {
        }


        //num of elements with subelems
        System.out.println("\nelemsWithSubElems \n");
        for (Map.Entry<String, List<String>> entry : fanout.entrySet()) {
            if (!entry.getValue().isEmpty()) {
            }
        }


        for (Error err : this.errors) {
            try {
                bf.write("<error>\n");
                bf.write(err.linenum + "  " + err.colnum + "  " + err.msg + "\n");
                bf.write("</error>\n");
                bf.flush();

            } catch (IOException ex) {
            }

        }

    }

    public void startDocument() throws SAXException {
    }

    /**
     * class na ulozeni chyboveho mista a zpravy
     */
    class Error {

        int linenum;
        int colnum;
        String msg;

        public Error(int linenum, int colnum, String msg) {
            this.linenum = linenum;
            this.colnum = colnum;
            this.msg = msg;
        }
    }

    /**
     * zvaliduje datum u elementu vypujcka, v pripade chyby vypise na konec xml
     * dokumentu zpravu v elementu \<error\>
     */
    public void validateVypujcky() {
        int odDen = 0;
        int odMesic = 0;
        int odRok = 0;
        int doDen = 0;
        int doMesic = 0;
        int doRok = 0;

        while (true) {
            if (vypujcky.pop().equals("do-rok")) {
                break;
            }
        }
        try {
            if (!vypujcky.peek().equals("do-rok")) {
                doRok = Integer.parseInt(vypujcky.pop());
            }
            vypujcky.pop();
            vypujcky.pop();

            if (!vypujcky.peek().equals("do-mesic")) {
                doMesic = Integer.parseInt(vypujcky.pop());
            }
            vypujcky.pop();
            vypujcky.pop();

            if (!vypujcky.peek().equals("do-den")) {
                doDen = Integer.parseInt(vypujcky.pop());
            }

            vypujcky.pop();
            vypujcky.pop();
            vypujcky.pop();
            vypujcky.pop();

            if (!vypujcky.peek().equals("od-rok")) {
                odRok = Integer.parseInt(vypujcky.pop());
            }
            vypujcky.pop();
            vypujcky.pop();
            if (!vypujcky.peek().equals("od-mesic")) {
                odMesic = Integer.parseInt(vypujcky.pop());
            }
            vypujcky.pop();
            vypujcky.pop();

            if (!vypujcky.peek().equals("od-den")) {
                odDen = Integer.parseInt(vypujcky.pop());
            }

            if (odDen <= 0 || odMesic <= 0 || odRok <= 0) {
                this.errors.add(new Error(locator.getLineNumber(), locator.getColumnNumber(), "Element vypujcka contains wrong date"));
            }


        } catch (NumberFormatException e) {
        }


    }

    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        //FANOUT
        fanout.put(qName, new LinkedList<String>());
        if (!stack.isEmpty()) {
            String n = stack.peek();
            List<String> values = fanout.get(n);
            if (values != null) {
                values.add(qName);
            }
        }


        //DEPTH of element
        if (!stack.isEmpty()) {
            int upper = depth.get(stack.peek());
            depth.put(qName, 1 + upper);

        } else {
            this.depth.put(qName, 0);
        }


        if (atts.getLength() > 0) {
            this.elemsWithAtts.add(qName);
        }

        if (qName.equals("vypujcka") || !vypujcky.isEmpty()) {
            vypujcky.push(qName);
        }


        try {
            numOfElems++;
            stack.push(qName);

            indent++;
            writeSpaces(indent);
            bf.write("<" + qName + " ");
            numOfAtts += atts.getLength();
            for (int i = 0; i < atts.getLength(); i++) {
                String attrname = atts.getQName(i);
                bf.write(attrname + "=\"");
                bf.write(atts.getValue(i) + "\"");
            }
            bf.write(">\n");

            bf.flush();
        } catch (IOException ex) {
        }

    }

    public void endElement(String uri, String localName, String qName) throws SAXException {


        //stack slouzici k validaci vypujcek
        if (!vypujcky.isEmpty()) {
            vypujcky.push(qName);
            if (qName.equals("vypujcka")) {
                validateVypujcky();
                vypujcky.clear();
            }
        }

        if (!stack.isEmpty() && stack.peek().equals(qName)) {
            stack.pop();
        }

        if (!stack.isEmpty() && !stack.peek().equals(qName)) {
            this.elemsWithSubElems.add(qName);
        }

        try {
            writeSpaces(indent);

            bf.write("</" + qName + ">\n");
            bf.flush();
        } catch (IOException ex) {
        }

        indent--;
    }

    public void characters(char[] ch, int start, int length) throws SAXException {

        if (!stack.isEmpty()) {
            this.textElements.add(stack.peek());
        }

        try {
            this.writeSpaces(indent);

            String content = String.valueOf(ch).substring(start, start + length).toUpperCase().trim();


            if (!vypujcky.isEmpty()) {
                vypujcky.push(content);
            }

            bf.write(content);
            bf.newLine();

        } catch (IOException ex) {
        }
    }

    public void startPrefixMapping(String prefix, String uri) throws SAXException {
    }

    public void endPrefixMapping(String prefix) throws SAXException {
    }

    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
    }

    public void processingInstruction(String target, String data) throws SAXException {
    }

    public void skippedEntity(String name) throws SAXException {
    }
}
