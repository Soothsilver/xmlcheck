package user;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

// ****************************************
// * Spocitame pocet elementov, atributov *
// * a k nim aj priemernu dlzku nazvu     *
// * udaje su uvedene v triede XmlStats   *
// ****************************************

public class MySaxHandler extends DefaultHandler { 
    
    class XmlStats  {
        public int numberOfElements = 0;
        public int numberOfAttributes = 0;
        public int totalAttNameChars = 0;
        public int totalElementNameChars = 0;        
        
        public void DisplayStats(){
            System.out.println("Number of elements: " + numberOfElements);            
            System.out.println("Average length of an element name: " + totalElementNameChars/numberOfElements);
            System.out.println("Number of attributes: " + numberOfAttributes);
            System.out.println("Average length of an attribute name: " + totalAttNameChars/numberOfAttributes);           
        }
    }

    Locator locator;
    XmlStats stats = new XmlStats();
    
    public void setDocumentLocator(Locator locator){
        this.locator = locator;      
    }
    
    public void startDocument() throws SAXException {
        // ....
    }    

    public void endDocument() throws SAXException {
        stats.DisplayStats();
    }
    
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        stats.numberOfElements++;
        stats.totalElementNameChars += qName.length();
        for (int i = 0; i < atts.getLength(); i++) {
            stats.totalAttNameChars += atts.getLocalName(i).length();
            stats.numberOfAttributes++;           
        }
    }


    public void endElement(String uri, String localName, String qName) throws SAXException {

    }

    
    public void characters(char[] ch, int start, int length) throws SAXException {

    }

    public void startPrefixMapping(String prefix, String uri) throws SAXException {

    }

    public void endPrefixMapping(String prefix) throws SAXException {

    }

    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {

    }

    public void processingInstruction(String target, String data) throws SAXException {

    }

    public void skippedEntity(String name) throws SAXException {
      // ...
    
   }
}