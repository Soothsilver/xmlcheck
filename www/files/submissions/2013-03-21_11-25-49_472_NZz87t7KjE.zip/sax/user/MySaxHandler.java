/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * 1) Prumerna delka zivota skladatele 
 * 2) Tri nejcastejsi typy skladeb, jako Nocturno apod 
 * 3) Pocet skladeb, ktere jsou klavirni ale nejsou v moll tonine.
 *
 * @author luk
 */
public class MySaxHandler extends DefaultHandler {

    Locator locator;
    StringBuilder stringBuilder = new StringBuilder();
    /**
     * 1) Prumerny vek vsech skladatelu
     */
    final String THIS_YEAR = "2013";
    int sumOld = 0;
    int numberOfComposer = 0;
    boolean flag_composer = false;

    int getOld(String fromAttrs, String toAttrs, Locator locator) {
        String[] from = fromAttrs.split("\\.");
        String[] to = toAttrs.split("\\.");
        if (from.length != 3 && to.length != 3) {
            try {
                throw new Exception();
            } catch (Exception ex) {
                System.out.println("Vek skladatele neni v xml dokumentu ve spravem formatu\n"
                        + "chyba: row " + locator.getLineNumber() + ", column: " + locator.getColumnNumber());
                System.exit(1);
            }
        }
        int res = Integer.parseInt(to[2]) - Integer.parseInt(from[2]);
        return res;
    }

    /**
     * 2) Tri nejcastejsi typy klavirnich skladeb - beru v uvahu pouze prvni tri nejcastejsi
     * 
     */
    class Composition {

        int number;
        String type;

        public Composition(int number, String type) {
            this.number = number;
            this.type = type;
        }
    }
    List<Composition> compositions = new ArrayList<Composition>();
    boolean flag_typeOfComposition;
    //Map<String, Integer> compositions = new HashMap<>();

    void addComposition(String typeComposition) {
        boolean add = false;
        for (int i = 0; i < compositions.size(); i++) {
            if (compositions.get(i).type.equals(typeComposition)) {
                compositions.get(i).number++;
                add = true;
            }
        }
        if (!add) {
            compositions.add(new Composition(1, typeComposition));
        }
    }

    List<Composition> sortComposition(List<Composition> c) {
        if (c.size() > 0) {
            List<Composition> res = new ArrayList<Composition>();
            int j = 0;
            while (j < 3) {
                Composition composition = new Composition(-1, "");
                for (int i = 0; i < c.size(); i++) {
                    if (c.get(i).number > composition.number) {
                        composition = c.get(i);
                    }
                }
                res.add(new Composition(composition.number, composition.type));
                c.remove(composition);
                ++j;
            }
            return res;
        } else {
            return new ArrayList<Composition>();
        }
    }
    /**
     * 3) Pocet skladeb, ktere jsou klavirni ale nejsou v moll
     *
     */
    boolean flag_composition_piano;
    boolean flag_key;
    int pianoCompositionDur = 0;

    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    @Override
    public void startDocument() {
    }

    @Override
    public void endDocument() {
        // prumerny vek skladatelu
        double prumernyVekSkladatelu = (double) (sumOld / numberOfComposer);
        System.out.println("Prumerny vek skladatelu: " + (int)prumernyVekSkladatelu + " let");
        // pocty skladeb
        System.out.println("Tri nejcastejsi skladby v poradi jak jsou uvedeny v xml doc");
        compositions = sortComposition(this.compositions);
        for (int i = 0; i < compositions.size(); ++i) {
            System.out.println(i + 1 + ". " + compositions.get(i).type + " pocet: " + compositions.get(i).number);
        }
        // pocet durovych klavirnich skladeb
        System.out.println("Pocet klavirnich durovych skladeb je " + pianoCompositionDur);
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        if (localName.equals("narozeni")) {
            String from = "";
            String to = "";
            for (int i = 0; i < attributes.getLength(); i++) {
                if (attributes.getQName(i).equals("datum_narozeni")) {
                    from = attributes.getValue(i);
                }
                if (attributes.getQName(i).equals("datum_umrti")) {
                    to = attributes.getValue(i);
                }
            }
            // Kdz skladatel jests neumrel beru jako constantu tento rok
            if (to.length() == 0) {
                to = THIS_YEAR;
            }
            sumOld += getOld(from, to, locator);
            numberOfComposer++;
        }

        if (localName.equals("typ_skladby")) {
            flag_typeOfComposition = true;
        }

        if (localName.equals("skladba")) {
            for (int i = 0; i < attributes.getLength(); i++) {
                if (attributes.getQName(i).equals("druh") && attributes.getValue(i).equals("klavirni")) {
                    flag_composition_piano = true;
                }
            }
        }
        if (localName.equals("tonina")) {
            flag_key = true;
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (localName.equals("typ_skladby")) {
            flag_typeOfComposition = false;
        }
        if (localName.equals("tonina")) {
            flag_composition_piano = false;
            flag_key = false;
        }
    }

    @Override
    public void characters(char ch[], int start, int length) throws SAXException {
        if (flag_typeOfComposition | (flag_composition_piano && flag_key)) {
            stringBuilder.delete(0, stringBuilder.length());
            for (int i = start; i < start + length; i++) {
                stringBuilder.append(ch[i]);
            }
            if (flag_typeOfComposition) {
                addComposition(stringBuilder.toString());
            }
            if(flag_composition_piano && flag_key) {
                String[] key = stringBuilder.toString().toLowerCase().split(" ");
                if(key[1].equals("dur")) {
                    pianoCompositionDur++;
                }
            }
        }
    }
}
