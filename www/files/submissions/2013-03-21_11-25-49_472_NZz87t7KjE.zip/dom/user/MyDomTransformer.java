/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.util.HashMap;
import java.util.Map;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author luk
 */
public class MyDomTransformer {

    public void transform(Document xmlDocument) {

        /*
         * Pridani noveho skladatele
         */
        // element vazna hudba
        NodeList nodeList;
        Node skladatele;

        nodeList = xmlDocument.getElementsByTagName("skladatele");
        if (nodeList.getLength() == 0) {
            skladatele = xmlDocument.createElement("skladatele");
            xmlDocument.getElementsByTagName("vazna_hudba").item(0).appendChild(skladatele);
        } else {
            skladatele = nodeList.item(0);
        }

        // vytvoreni noveho skladatele
        Element skladatel = xmlDocument.createElement("skladatel");
        skladatel.setAttribute("skladatel_id", "id_s_4");
        skladatel.setAttribute("era_ref", "era_2");
        skladatel.setAttribute("zijici", "ne");
        Node osobni = xmlDocument.createElement("osobni_udaje");
        Node jmeno = xmlDocument.createElement("jmeno");
        Node krestni = xmlDocument.createElement("krestni");
        krestni.setTextContent("Ludwig van");
        Node prijmeni = xmlDocument.createElement("prijmeni");
        prijmeni.setTextContent("Beethoven");
        Element narozeni = xmlDocument.createElement("narozeni");
        narozeni.setAttribute("datum_narozeni", "16.12.1770");
        narozeni.setAttribute("datum_umrti", "26.3.1827");
        narozeni.setAttribute("misto_narozeni", "Vídeň");
        Node zivot = xmlDocument.createElement("zivot");
        zivot.setTextContent("... . V prubehu sveho zivota rozvinul klasicistni slohove a formove prostredky do sveho individualniho hudebniho stylu a otevrel tak dvere nove hudebni epose – romantismu.");
        osobni.appendChild(jmeno).appendChild(krestni).getParentNode().appendChild(prijmeni).getParentNode().appendChild(narozeni);
        skladatel.appendChild(osobni).getParentNode().appendChild(zivot);

        skladatele.appendChild(skladatel);
        
        /*
         * Smazani vsech klavirnich mollových skladeb
         */
        nodeList = xmlDocument.getElementsByTagName("skladba");
        for(int i = nodeList.getLength()-1; i >= 0 ; i--) {
             NamedNodeMap attr = nodeList.item(i).getAttributes();
             for(int j = 0; j < attr.getLength(); j++) {
                 if(attr.item(j).getNodeName().equals("druh") && attr.item(j).getNodeValue().equals("klavirni")) {
                     NodeList children = nodeList.item(i).getChildNodes();
                     for(int h = 0; h < children.getLength(); h++) {
                         if(children.item(h).getNodeName().equals("tonina") && children.item(h).getTextContent().contains("moll")) {
                             nodeList.item(i).getParentNode().removeChild(nodeList.item(i));
                             break;
                         }
                     }
                 }
             }
        }
        
    }
}
