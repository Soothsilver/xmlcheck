package user;

import org.xml.sax.*;
import org.xml.sax.helpers.*;

/**
 * Pocty udalosti v kalendari podle dni v mesici (rozepsano podle skupin a celkem).
 */
public class MySaxHandler extends DefaultHandler {

	/* Jmena elementu */
	static final String KALENDAR = "kalendar";
	static final String UDALOSTI = "udalosti";
	static final String VE_DNI = "ve-dni";
	static final String KAZDODENNE = "kazdodenne";
	static final String UDALOST = "udalost";
	static final String ZACATEK = "zacatek-udalosti";
	static final String PRERUSENI_UDALOSTI = "preruseni-udalosti";
	static final String POKRACOVANI_UDALOSTI = "pokracovani-udalosti";
	static final String KONEC = "konec-udalosti";
	static final String JMENO = "jmeno";

	/* Bunky vysledne tabulky */
	static final int JEDNODENNI = 0;
	static final int ZACATKY = 1;
	static final int PRERUSENI = 2;
	static final int POKRACOVANI = 3;
	static final int KONCE = 4;
	static final int TOTAL = 5;

	/* Maximalni pocet dni v mesici */
	static final int MAX_DAY = 31;

	/* Soucty pro jednotlive dny v mesici */
	static class DaySums {
		private int[] counts = new int[TOTAL];

		void print(String title) {
			System.out.print("\t\t\t<tr>");
			printCell(title);

			int total = 0;
			for (int count : counts) {
				printCell(count);
				total += count;
			}

			printCell(total);
			System.out.println("</tr>");
		}

		void printCell(String value) {
			System.out.printf("<td>%s</td>", value);
		}

		void printCell(int value) {
			printCell(Integer.toString(value));
		}

		void inc(int item) {
			++counts[item];
		}

		void add(DaySums other) {
			for (int i = 0; i < TOTAL; i++)
				counts[i] += other.counts[i];
		}
	}

	/* Soucty pro kazdy den v mesici */
	static class MonthSums {
		private DaySums[] days = new DaySums[MAX_DAY + 1];

		MonthSums() {
			for (int i = 0; i <= MAX_DAY; i++)
				days[i] = new DaySums();
		}

		void print() {
			days[0].print("všechny");

			DaySums total = new DaySums();
			total.add(days[0]);

			for (int i = 1; i <= MAX_DAY; i++) {
				DaySums day = days[i];

				day.print(Integer.toString(i));
				total.add(day);
			}

			total.print("celkem");
		}

		void inc(int day, int item) {
			days[day].inc(item);
		}

		void add(MonthSums other) {
			for (int i = 0; i <= MAX_DAY; i++)
				days[i].add(other.days[i]);
		}
	}

	/* Soucty */
	MonthSums total = null;
	MonthSums group = null;
	int groups = 0;
	int currentDay = -1;

	/* Sber textoveho obsahu, ktery je nekde potreba */
	String name = null;
	boolean nameCalendar = false; // nasledujici element <jmeno> patri ke kalendari
	boolean nameGroup = false;    // nasledujici element <jmeno> patri ke skupine udalosti

	/* Chyby */
	String errors = null;
	Locator locator = null;

	@Override
	public void setDocumentLocator(Locator locator) {
		this.locator = locator;
	}

	@Override
	public void startDocument() throws SAXException {
		/* Vypise hlavicku vystupu */
		System.out.print(
				"<?xml version='1.0' encoding='UTF-8'?>\n" +
				"<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN'\n" +
				"               SYSTEM 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>\n" +
				"<html lang='cs' xml:lang='cs' xmlns='http://www.w3.org/1999/xhtml'>\n" +
				"\t<head>\n" +
				"\t\t<title>Počty událostí v kalendáři</title>\n" +
				"\t</head>\n" +
				"\t<body>\n");
	}

	@Override
	public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
		if (KALENDAR.equals(localName)) {

			if (total != null)
				report("Vnořený kalendář");

			/* Vynulovat pocitadla */
			total = new MonthSums();
			group = null;
			groups = 0;
			currentDay = -1;

			/* Text v nasledujicim elementu <jmeno> bude vypsan jako titulek */
			nameCalendar = true;

		} else if (UDALOSTI.equals(localName)) {

			if (total == null)
				report("Události mimo kalendář");

			if (group != null)
				report("Vnořená skupina událostí");

			/* Pred prvni skupinou vypsat hlavicku tabulky
			   (nemohu driv, protoze pred tabulku prijde titulek) */
			if (groups == 0) {
				System.out.print(
						"\t\t<table>\n" +
						"\t\t\t<caption>Počty událostí v kalendáři</caption>\n" +
						"\t\t\t<tr>\n" +
						"\t\t\t\t<th>Den v měsíci</th>\n" +
						"\t\t\t\t<th>Jednodenní události</th>\n" +
						"\t\t\t\t<th>Začátky událostí</th>\n" +
						"\t\t\t\t<th>Přerušení</th>\n" +
						"\t\t\t\t<th>Pokračování</th>\n" +
						"\t\t\t\t<th>Konce</th>\n" +
						"\t\t\t\t<th>Celkem</th>\n" +
						"\t\t\t</tr>\n");
			}
			++groups;

			group = new MonthSums();

			/* Text v nasledujicim elementu <jmeno> bude vypsan jako hlavicka v tabulce */
			nameGroup = true;

		} else if (VE_DNI.equals(localName)) {

			checkGroup();

			String cislo = atts.getValue("cislo");
			try {
				currentDay = Integer.parseInt(cislo);

				if (currentDay < 1 || currentDay > MAX_DAY) {
					currentDay = -1;
					report("Číslo dne mimo rozsah");
				}
			} catch (NumberFormatException e) {
				report("Špatné číslo dne");
				currentDay = -1;
			}

		} else if (KAZDODENNE.equals(localName)) {

			checkGroup();

			/* 0 = vsechny dny */
			currentDay = 0;

		} else if (UDALOST.equals(localName)) {
			mark(JEDNODENNI);
		} else if (ZACATEK.equals(localName)) {
			mark(ZACATKY);
		} else if (PRERUSENI_UDALOSTI.equals(localName)) {
			mark(PRERUSENI);
		} else if (POKRACOVANI_UDALOSTI.equals(localName)) {
			mark(POKRACOVANI);
		} else if (KONEC.equals(localName)) {
			mark(KONCE);
		} else if (JMENO.equals(localName)) {
			if (nameCalendar || nameGroup)
				name = "";
		}
	}

	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		if (name != null)
			name += new String(ch, start, length);
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		if (KALENDAR.equals(localName)) {
			if (groups > 1) {
				System.out.print("\t\t\t<tr><th colspan='7'>Všechno dohromady</th></tr>\n");
				total.print();
			}
			System.out.print("\t\t</table>\n");
			total = null;
		} else if (UDALOSTI.equals(localName)) {
			group.print();
			total.add(group);
			group = null;
		} else if (VE_DNI.equals(localName)) {
			currentDay = -1;
		} else if (KAZDODENNE.equals(localName)) {
			currentDay = -1;
		} else if (JMENO.equals(localName)) {

			if (nameCalendar) {
				System.out.printf("\t\t<h1>%s</h1>\n", name);
				nameCalendar = false;
			}

			if (nameGroup) {
				System.out.printf("\t\t\t<tr><th colspan='7'>%s</th></tr>\n", name);
				nameGroup = false;
			}

			name = "";
		}
	}

	@Override
	public void endDocument() throws SAXException {
		if (errors != null)
			System.out.printf(
					"\t\t<h2>Chyby</h2>\n" +
					"\t\t<pre>\n" +
					"%s" +
					"\t\t</pre>\n", errors);

		System.out.println(
				"\t</body>\n" +
				"</html>");
	}

	private void report(String message) {
		String line = String.format("\t\t%d.%d: %s\n",
				locator.getLineNumber(), locator.getColumnNumber(), message);

		if (errors == null)
			errors = line;
		else
			errors = errors + line;
	}

	private void checkGroup() {
		if (group == null)
			report("Den mimo skupinu událostí");
	}

	private void mark(int item) {
		if (currentDay < 0)
			report("Událost mimo den");

		group.inc(currentDay, item);
	}

	/**
	 * Main podle podkladu ze cviceni.
	 *
	 * @param args ignorovano
	 */
	public static void main(String[] args) {

		// Cesta ke zdrojovemu XML dokumentu
		String sourcePath = "data.xml";

		try {
			// Vytvorime instanci parseru.
			XMLReader parser = XMLReaderFactory.createXMLReader();

			// Vytvorime vstupni proud XML dat.
			InputSource source = new InputSource(sourcePath);

			// Nastavime nas vlastni content handler pro obsluhu SAX udalosti.
			parser.setContentHandler(new MySaxHandler());

			// Zpracujeme vstupni proud XML dat.
			parser.parse(source);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}