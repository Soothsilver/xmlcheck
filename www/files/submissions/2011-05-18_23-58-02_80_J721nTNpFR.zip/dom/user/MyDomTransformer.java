package user;

import java.io.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import org.w3c.dom.*;

/**
 * Slije udalosti do jedine skupiny.
 * Opakovane udalosti ze skupiny prepise do roku, ktere se ve skupine vyskytuji.
 * Neresi spravnou indentaci.
 */
public class MyDomTransformer {

	public void transform(Document xmlDocument) {
		Element root = xmlDocument.getDocumentElement();

		/* Vytvori novou skupinu udalosti, kam se sliji vsechny puvodni. */
		Element newGroup = xmlDocument.createElement("udalosti");
		newGroup.setAttribute("id", "Vse");

		/* Jmeno nove skupiny. */
		Element newGroupName = xmlDocument.createElement("jmeno");
		newGroupName.setTextContent("Vsechny udalosti");
		newGroup.appendChild(newGroupName);

		/* Popis nove skupiny vytvoreny spojenim popisu vsech skupin. */
		Element newGroupDesc = xmlDocument.createElement("popis");
		newGroup.appendChild(newGroupDesc);

		/* Projde vsechny puvodni skupiny. */
		Element group;
		while ((group = getFirstChild(root, "udalosti")) != null) {

			/* Jmeno puvodni skupiny bude nadpis v popisu nove skupiny. */
			String name = group.getAttribute("id");

			Element groupName = getFirstChild(group, "jmeno");
			if (groupName != null) {
				Element newTitle = xmlDocument.createElement("nadpis");
				name = groupName.getTextContent();

				newTitle.setTextContent(name);
				newGroupDesc.appendChild(newTitle);
			}

			/* Presunuti puvodniho popisu do noveho popisu. */
			Element groupDesc = getFirstChild(group, "popis");
			if (groupDesc != null)
				moveChildren(groupDesc, newGroupDesc);

			/* Presunuti opakovanych udalosti do vsech roku */
			Element repeated;
			while ((repeated = getFirstChild(group, "kazdorocne")) != null) {
				int copies = 0;

				/* Vlozeni opakovanych udalosti do vsech roku */
				NodeList yearList = group.getElementsByTagName("v-roce");
				int yearCount = yearList.getLength();
				for (int j = 0; j < yearCount; j++) {
					Element year = (Element) yearList.item(j);

					/* Protoze mohu obsah elementu potrebovat jeste pro dalsi roky, zkopiruji si ho. */
					Element events = (Element) repeated.cloneNode(true);

					if (copies > 0) {
						/* Je potreba modifikovat identifikatory ve klonovanem elementu. */
						NodeList elementList = events.getElementsByTagName("*");
						int elementCount = elementList.getLength();
						for (int k = 0; k < elementCount; k++) {
							Element element = (Element) elementList.item(k);
							Attr id = element.getAttributeNode("id");
							if (id != null)
								id.setTextContent(id.getTextContent() + "_" + copies);
						}
					}

					++copies;
					moveChildren(events, year);
				}

				group.removeChild(repeated);
			}

			newGroup.appendChild(xmlDocument.createComment("Ze skupiny " + name));

			/* Presunuti udalosti do nove skupiny */
			Element year;
			while ((year = getFirstChild(group, "v-roce")) != null)
				newGroup.appendChild(year);

			/* Odstraneni skupiny */
			root.removeChild(group);
		}

		/* Vlozeni nove skupiny do dokumentu */
		root.appendChild(newGroup);

		/* Protoze stare skupiny uz neexistuji, je treba presmerovat odkazy. */
		NodeList linkList = root.getElementsByTagName("odkaz-na-udalosti");
		int linkCount = linkList.getLength();
		for (int i = 0; i < linkCount; i++)
			((Element) linkList.item(i)).setAttribute("ref", "Vse");
	}

	/**
	 * Vrati prvni synovsky element zadaneho jmena.
	 *
	 * @param parent rodicovsky element
	 * @param name jmeno potomka
	 * @return potomek nebo {@code null}
	 */
	private Element getFirstChild(Element parent, String name) {
		NodeList candidates = parent.getElementsByTagName(name);
		if (candidates.getLength() > 0) {

			Element candidate = (Element) candidates.item(0);
			if (parent.isSameNode(candidate.getParentNode()))
				return candidate;
		}

		return null;
	}

	/**
	 * Presune synovske uzly z jednoho elementu na konec druheho.
	 *
	 * @param source element s potomky
	 * @param destination element, kam potomky vlozit
	 */
	private void moveChildren(Element source, Element destination) {
		for (;;) {
			Node child = source.getFirstChild();
			if (child == null)
				break;

			destination.appendChild(child);
		}
	}

	/**
	 * Main podle podkladu ze cviceni.
	 *
	 * @param args ignorovano
	 */
	public static void main(String[] args) {
		final String VSTUPNI_SOUBOR = "data.xml";
		final String VYSTUPNI_SOUBOR = "out.xml";

		try {
			//DocumentBuilderFactory vytvari DOM parsery
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

			//nebudeme validovat
			dbf.setValidating(false);

			//vytvorime si DOM parser
			DocumentBuilder builder = dbf.newDocumentBuilder();

			//parser zpracuje vstupní soubor a vytvori z nej strom DOM objektu
            Document doc = builder.parse(VSTUPNI_SOUBOR);

            //zpracujeme DOM strom
            new MyDomTransformer().transform(doc);

            //TransformerFactory vytvari serializatory DOM stromu
            TransformerFactory tf = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer = tf.newTransformer();

            //nastavime kodovani
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spustime transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}