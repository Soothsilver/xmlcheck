package user;

import java.util.ArrayList;
import java.util.Stack;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

/**
 * N� vlastn� content handler pro obsluhu SAX ud�lost�.
 * Implementuje metody interface ContentHandler. 
 */ 
public class MySaxHandler extends DefaultHandler {

    // Umo��uje zac�lit m�sto v dokumentu, kde vznikla aktualn� ud�lost
    Locator locator;
    
    /**
     * Nastav� locator
     */     
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Obsluha ud�losti "za��tek dokumentu"
     */     
    public void startDocument() throws SAXException {
        
        // ...
        
    }
    /**
     * Obsluha ud�losti "konec dokumentu"
     */     
    public void endDocument() throws SAXException {
        System.out.println("simplifiable elements: " + count);
        // ...
        
    }
    
    private Stack<ArrayList<String>> atstack = new Stack<ArrayList<String>>();
    private boolean started;
    private int count = 0;
    
    /**
     * Obsluha ud�losti "za��tek elementu".
     * @param uri URI jmenn�ho prostoru elementu (pr�zdn�, pokud element nen� v ��dn�m jmenn�m prostoru)
     * @param localName Lok�ln� jm�no elementu (v�dy nepr�zdn�)
     * @param qName Kvalifikovan� jm�no (tj. prefix-uri + ':' + localName, pokud je element v n�jak�m jmenn�m prostoru, nebo localName, pokud element nen� v ��dn�m jmenn�m prostoru)
     * @param atts Atributy elementu     
     */     
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        ArrayList<String> a = new ArrayList<String>();
        for (int i = 0; i < atts.getLength(); ++i)
        {
            a.add(atts.getQName(i));
        }
        atstack.push(a);
        started = true;
    }
    /**
     * Obsluha ud�losti "konec elementu"
     * Parametry maj� stejn� v�znam jako u @see startElement     
     */     
    public void endElement(String uri, String localName, String qName) throws SAXException {

        // ...
        ArrayList<String> a = atstack.pop();
        if (started //element has just started (no inner elements)
                && a.size() == 0 //no attributes
                && !atstack.peek().contains(qName)) //parent has no attribute of element`s name
        {
            ++count;
        }
        started = false;
        
    }
    
    /**
     * Obsluha ud�losti "znakov� data".
     * SAX parser mu�e znakov� data d�vkovat jak chce. Nelze tedy po��tat s t�m, �e je cel� text dorucen v r�mci jednoho vol�n�.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakov�mi daty
     * @param start Index zac�tku �seku platn�ch znakov�ch dat v poli.
     * @param length D�lka �seku platn�ch znakov�ch dat v poli.
     */               
    public void characters(char[] ch, int start, int length) throws SAXException {

        
    }
    
    /**
     * Obsluha ud�losti "deklarace jmenn�ho prostoru".
     * @param prefix Prefix prirazen� jmenn�mu prostoru.
     * @param uri URI jmenn�ho prostoru.
     */     
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha ud�losti "konec platnosti deklarace jmenn�ho prostoru".
     */     
    public void endPrefixMapping(String prefix) throws SAXException {
    
        // ...
    
    }

    /**
     * Obsluha ud�losti "ignorovan� b�l� znaky".
     * Stejn� chov�n� a parametry jako @see characters     
     */     
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha ud�losti "instrukce pro zpracov�n�".
     */         
    public void processingInstruction(String target, String data) throws SAXException {
      
      // ...
            
    }

    /**
     * Obsluha ud�losti "nezpracovan� entita"
     */         
    public void skippedEntity(String name) throws SAXException {
    
      // ...
    
    }
}