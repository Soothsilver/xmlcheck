package user;

import com.sun.org.apache.xalan.internal.xsltc.compiler.util.NodeType;
import java.io.File;

import javax.management.AttributeList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

public class MyDomTransformer{

    /**
     * Zpracuje DOM strom
     */
    public void transform(Document doc) {
        
        for (int i = 0; i < doc.getChildNodes().getLength(); ++i)
        {
        	processNode(doc.getChildNodes().item(i), doc);
        }
        
    }
    
    /**
     * Zavola obsluznou rutinu pro uzel a rekurzivne se zavola pro vsechny child uzly
     * 
     * @param n
     * @param doc 
     */
    private static void processNode(Node n, Document doc) {
        
    	processSingleNode(n, doc);
        for (int i = 0; i < n.getChildNodes().getLength(); ++i)
        {
        	processNode(n.getChildNodes().item(i), doc);
        }
        
    }
    
    /**
     * obsluzna rutina jednoho uzlu
     * 
     * @param n
     * @param doc 
     */
    private static void processSingleNode(Node n, Document doc) {
        NamedNodeMap pa = n.getParentNode().getAttributes();
        if (
                n.getNodeType() == Node.ELEMENT_NODE
                && textOnly(n) //uzel nema potomky
                && pa.getNamedItem(n.getNodeName()) == null) //nadrazeny uzel nema atribut s timto nazvem
        {
            Attr x = doc.createAttribute(n.getNodeName());
            x.setTextContent(n.getTextContent());
            pa.setNamedItem(x);
            n.getParentNode().removeChild(n);
        }
    }
    
    private static boolean textOnly(Node n)
    {
        if (n.hasAttributes()) return false;
        for (int i = 0; i < n.getChildNodes().getLength(); ++i)
        {
        	if (n.getChildNodes().item(i).getNodeType() != Node.TEXT_NODE) return false;
        }
        return true;
    }
}