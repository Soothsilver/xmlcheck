package user;

import org.w3c.dom.Document;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class MyDomTransformer 
{
    public static void main(String[] args) 
	{
        try 
		{
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            dbf.setValidating(false);

            DocumentBuilder builder = dbf.newDocumentBuilder();

            Document doc = builder.parse("data.xml");

            transform(doc);
        } 
		catch (Exception e) 
		{
            e.printStackTrace();
        }
    }

    /*
        strukturu:
     
        <dodavatel>
            ...
     
            <dodavatel>
                ...
     
                <dodavatel>
                
                ...
                
                </dodavatel>
            </dodavatel>
        </dodavatel>
     
        prevedeme na:
     
        <dodavatel>
        ...
        </dodavatel>
     
        <dodavatel>
        ...
        </dodavatel>
     
        <dodavatel>
        ...
        </dodavatel>
    */
    
    public static void transform(Document doc)
	{
		//pomocny - odkladaci - element
		Element result = doc.createElement("result");
		NodeList odberatele = doc.getElementsByTagName("odberatel");
		
		//nakopirujeme vsechny odberatele do elementu result
		for (int i = 0; i < odberatele.getLength(); i++) 
		{
			Node odberatel = odberatele.item(i);
			
			result.appendChild(odberatel.cloneNode(true));
		}
		
		//vymazeme vsechny odberatele z Nodu odberatele
		Node odberateleNode = doc.getElementsByTagName("odberatele").item(0);
		
		while (odberateleNode.hasChildNodes())
		{
			odberateleNode.removeChild(odberateleNode.getFirstChild());       
		} 
		
		//ze vsech odberatelu odstranime potomky odberatel a nakopirujeme je zpet do Nodu odberatele
		while (result.hasChildNodes())
		{
			Node odberatel = result.getFirstChild();
			NodeList odberatelChilds = odberatel.getChildNodes();
			
			for (int j = 0; j < odberatelChilds.getLength(); j++) 
			{
				if (odberatelChilds.item(j).getNodeName().equals("odberatel"))
				{
					odberatel.removeChild(odberatelChilds.item(j));
				}
			}
			
			odberateleNode.appendChild(odberatel);
		}
    }
}
