package user;

import org.xml.sax.helpers.DefaultHandler;

import org.xml.sax.InputSource;
import org.xml.sax.Attributes;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

public class MySaxHandler extends DefaultHandler 
{
	int vyrobku = 0;
	double celkovaCena = 0;
	
	public static void main(String[] args) 
	{
        String sourcePath = "data.xml";

        try 
		{
            XMLReader parser = XMLReaderFactory.createXMLReader();

            InputSource source = new InputSource(sourcePath);

            parser.setContentHandler(new MySaxHandler());

            parser.parse(source);
            
        } 
		catch (Exception e) 
		{
        
            e.printStackTrace();
            
        }
        
    }
	
	//spocitame pocet vsech vyrobku a jejich celkovou cenu
	public void startElement(String uri, String localName, String qName, Attributes attrs)
	{
		if (localName == "vyrobek")
		{
			vyrobku++;
			
			String value = attrs.getValue("cena");
			celkovaCena += Double.parseDouble(value);
		}
    }
	
	//na zaver vypiseme vysledek
	public void endDocument()
	{
		System.out.print("Je nabizeno " + vyrobku + " vyrobku s celkovou cenou " + celkovaCena + "Kc");
    }
}