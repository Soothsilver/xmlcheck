/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * @author honza
 */
//
public class MySaxHandler extends DefaultHandler {
    // override metod DefaultHandleru
    private final int MATCHES = 100;
    private int countInjuries;
    private int forward;
    private int midfielder;
    private int defender;
    private int goalkeeper;
    private boolean isPlayer;
    private int sumAge;
    private int countPlayer;
    private boolean isAge;
    private boolean isFirstName;
    private String nameOfCurrentPlayer;
    private boolean isSurname;
    private boolean isInjured;
    private boolean isMatches;
    private boolean isGoals;
    private int goalsOfCurrentPlayer;
    private int mostGoals;
    private String bestPlayer;
    private int matchesOfCurrentPlayer;
    
    @Override
    public void startDocument() throws SAXException {
       countInjuries = 0;
       forward = 0;
       midfielder = 0;
       defender = 0;
       goalkeeper = 0;
       isPlayer = false;
       sumAge = 0;
       countPlayer = 0;
       isAge = false;
       isFirstName = false;
       isSurname = false;
       nameOfCurrentPlayer="";
       isInjured = false;
       isMatches = false;
       isGoals = false;
       goalsOfCurrentPlayer = 0;
       matchesOfCurrentPlayer = 0;
       
       
   }

   
   @Override
   public void endDocument() throws SAXException {
       System.out.println("Zranenych hracu je: "+countInjuries);
       System.out.println("Hracu na pozici brankar je: "+goalkeeper);
       System.out.println("Hracu na pozici obrance je: "+defender);
       System.out.println("Hracu na pozici zaloznik je: "+midfielder);
       System.out.println("Hracu na pozici urocnik je: "+forward);
       System.out.println("Prumerny vek hracu je: "+((double)sumAge)/countPlayer);
       System.out.println("Hrac, ktery odehral vice jak "+ MATCHES +" zapasu, neni zraneny a dal nejvicegolu je " + bestPlayer+" a dal " +mostGoals+" golu.");

   }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if (localName.compareTo("player")==0) {
            countPlayer++;
            isPlayer = true;
            if (atts.getValue("injury").compareTo("yes")==0) {
                isInjured = true;
                countInjuries++;
            }
            String position = atts.getValue("position");
            if(position.compareTo("forward")==0){
                forward++;
            }
            if(position.compareTo("defender")==0){
                defender++;
            }
            if(position.compareTo("midfielder")==0){
                midfielder++;
            }
            if(position.compareTo("goalkeeper")==0){
                goalkeeper++;
            }
        }
        if(localName.compareTo("age")==0 && isPlayer){
            isAge = true;
        }
        if(localName.compareTo("first_name")==0 && isPlayer){
            isFirstName = true;
        }
        if(localName.compareTo("surname")==0 && isPlayer){
            isSurname = true;
        }
        if(localName.compareTo("numberOfMatches")==0 && isPlayer){
            isMatches = true;
        }
        if(localName.compareTo("goals")==0 && isPlayer){
            isGoals = true;
        }
        
        

    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if(localName.compareTo("player")==0){
            if((matchesOfCurrentPlayer > MATCHES) && !isInjured){
                if(mostGoals<goalsOfCurrentPlayer){
                    mostGoals = goalsOfCurrentPlayer;
                    bestPlayer = nameOfCurrentPlayer;
                }
            }
            isPlayer = false;
            isInjured = false;
            nameOfCurrentPlayer="";
            goalsOfCurrentPlayer = 0;
            matchesOfCurrentPlayer = 0;
        }
        if(localName.compareTo("age")==0 && isPlayer){
            isAge = false;
        }
        if(localName.compareTo("first_name")==0 && isPlayer){
            isFirstName = false;
        }
        if(localName.compareTo("surname")==0 && isPlayer){
            isSurname = false;
        }
        if(localName.compareTo("numberOfMatches")==0 && isPlayer){
            isMatches = false;
        }
        if(localName.compareTo("goals")==0 && isPlayer){
            isGoals = false;
        }
    }

    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        if(isAge){
            String s = new String(chars, start, length);
            sumAge+=Integer.parseInt(s);
        }
        if(isFirstName){
            String s = new String(chars, start, length);
            nameOfCurrentPlayer+=s;
        }
        if(isSurname){
            String s = new String(chars, start, length);
            nameOfCurrentPlayer+=" "+s;
        }
        if(isGoals){
            String s = new String(chars, start, length);
            goalsOfCurrentPlayer = Integer.parseInt(s);
        }
        if(isMatches){
            String s = new String(chars, start, length);
            matchesOfCurrentPlayer = Integer.parseInt(s);
            
        }
    }
    
}
