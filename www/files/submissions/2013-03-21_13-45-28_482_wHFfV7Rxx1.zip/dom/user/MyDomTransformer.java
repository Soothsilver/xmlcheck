/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.util.Map;
import java.util.TreeMap;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

/**
 *
 * @author honza
 */
public class MyDomTransformer {

    public void transform(Document xmlDocument) {
        addPlayer(xmlDocument, "p10", null, null, null, "Honza", "Kubicek",null, 20, 1, 1);
        sortPlayerBySurname(xmlDocument);
        
    }
    private void addPlayer(Document doc, String id, String photo, String injury, String position,
                           String firstName, String surname, String phone, int age, int matches, int goals ){
        if(id==null || firstName == null || surname==null || age < 0 || matches < 0 || goals < 0 ){
            System.out.println("CHYBA V ZADAVANI PARAMETRU!");
            return;
        }
        Element player_list = (Element)doc.getElementsByTagName("player_list").item(0);
        Element player = doc.createElement("player");
        player.setAttribute("id", id);
        if(photo!=null){
            player.setAttribute("photo", photo);
        }
        if(injury!=null){
            player.setAttribute("injury", injury);
        }
        if(position!=null){
            player.setAttribute("position", position);
        }
        player.appendChild(doc.createElement("first_name")).setTextContent(firstName);
        player.appendChild(doc.createElement("surname")).setTextContent(surname);
        if(phone!=null){
            player.appendChild(doc.createElement("phone")).setTextContent(phone);
        }
        player.appendChild(doc.createElement("age")).setTextContent(Integer.toString(age));
        Element statistics = doc.createElement("statistics");
        statistics.appendChild(doc.createElement("numberOfMatrches")).setTextContent(Integer.toString(matches));
        statistics.appendChild(doc.createElement("goals")).setTextContent(Integer.toString(goals));
        player.appendChild(statistics);
        player_list.appendChild(player);
        
    }
    
    private void sortPlayerBySurname(Document doc){
        Element player_list = (Element)doc.getElementsByTagName("player_list").item(0);
        NodeList players = player_list.getElementsByTagName("player");
        Map<String, Element> map = new TreeMap<String, Element>();
        for (int i = players.getLength()-1; i >= 0 ; i--) {
            Element player = (Element)players.item(i);
            String surname = ((Element)player.getElementsByTagName("surname").item(0)).getTextContent();
            map.put(surname, player);
            player_list.removeChild(player);
        }
        for (String key : map.keySet()) {
            player_list.appendChild(map.get(key));
        }
    }
    
}

