package user;

import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;


class MySaxHandler extends DefaultHandler {

    
    Locator locator;
    int posun;
    int pocetElementu = 0;
    int pocetAtr = 0;
    int pocetZnakuDoc = 0;
    boolean plat = false;
    int pocetPlatu = 0;
    int sumaPlatu = 0;
    int nejvissiPlat = 0;
    double prumPlat = 0;
    boolean pobocka = false;
    boolean nazev = false;
    boolean kontaktB = false;
    String[] nazevPobocky = new String[20];
    int[] pocetTelefonu = new int[20];
    int pocetPobocek = 0;
    String[] kontakt = new String[20];

    public void PrumPlat(int plat) {
        pocetPlatu++;
        sumaPlatu += plat;
        if (nejvissiPlat < plat) {
            nejvissiPlat = plat;
        }
        prumPlat = sumaPlatu / pocetPlatu;
    }

    public String posun(int a) {
        String b = "";
        for (int i = 0; i < a; i++) {
            b += " ";
        }
        return b;
    }

    /**
     * Nastaví locator
     */
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Obsluha události "začátek dokumentu"
     */
    public void startDocument() throws SAXException {
        System.out.println("----------------------------------------------------");
        System.out.println("Vojtěch Hlavačka - Domácí úkol SAX");
        System.out.println("Výsledky jsou na konci výpisu.");
        System.out.println("----------------------------------------------------");
    }

    /**
     * Obsluha události "konec dokumentu"
     */
    public void endDocument() throws SAXException {
        System.out.println("----------------------------------------------------");
        System.out.println("Vojtěch Hlavačka - Domácí úkol SAX");
        System.out.println(" - Atributy jsem převedl na Elementy ");
        System.out.println(" - obsah elementu jsem převedl na velká písmena");
        System.out.println(" - Document jsem vypsal s znázorněním zanoření");
        System.out.println(" - Dále jsem vypsal názvy všech poboček kontakt na ně a ke každé jsem spočítal kolik vlastní telefonů");
        System.out.println(" - dále pak pocet zamestnanců nejvižší, průměrný plat a sumu platů");
        System.out.println(" - na konec jsem uved pocti znaků atributů a elementů");
        System.out.println("----------------------------------------------------");
        for (int i = 0; i < pocetPobocek; i++) {
            System.out.println("Nazev pobocky: " + nazevPobocky[i]);
            System.out.println("  -  Kontakt na pobocku: " + kontakt[i]);
            System.out.println("  -  Pocet telefonu ktere se na pobocce vyskytuji: " + pocetTelefonu[i]);
        }
        System.out.println("----------------------------------------------------");
        System.out.println("Pocet zamestnanců: " + pocetPlatu);
        System.out.println("Prumerný plat všech zamestnanců: " + prumPlat);
        System.out.println("Nejvissi plat ze zamestnanců: " + nejvissiPlat);
        System.out.println("Suma platu všech zamestnanců: " + sumaPlatu);
        System.out.println("----------------------------------------------------");
        System.out.println("Pocet Elementu: " + pocetElementu);
        System.out.println("Pocet attributu: " + pocetAtr);
        System.out.println("Pocet znaku XML dokumentu: " + pocetZnakuDoc);
        System.out.println("----------------------------------------------------");
    }

    /**
     * Obsluha události "začátek elementu".
     *
     * @param uri URI jmenného prostoru elementu (prázdné, pokud element není v
     * žádném jmenném prostoru)
     * @param localName Lokální jméno elementu (vždy neprázdné)
     * @param qName Kvalifikované jméno (tj. prefix-uri + ':' + localName, pokud
     * je element v nějakém jmenném prostoru, nebo localName, pokud element není
     * v žádném jmenném prostoru)
     * @param atts Atributy elementu
     */
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        System.out.println(posun(posun) + "<" + localName + ">");
        posun += 2;
        for (int i = 0; i < atts.getLength(); i++) {
            System.out.println(posun(posun) + "<" + atts.getLocalName(i) + ">" + atts.getValue(i) + "</" + atts.getLocalName(i) + ">");
            pocetAtr++;
        }
        pocetElementu++;
        if (localName == "plat") {
            plat = true;
        }
        if (localName == "pobocka") {
            pobocka = true;
            pocetPobocek++;
        }
        if (localName == "kontakt") {
            kontaktB = true;
        }
        if (localName == "telefon" && pobocka) {
            pocetTelefonu[pocetPobocek - 1] += 1;
        }
        if (localName == "nazev") {
            nazev = true;
        }

    }

    /**
     * Obsluha události "konec elementu" Parametry mají stejný význam jako u
     *
     * @see startElement
     */
    
    public void endElement(String uri, String localName, String qName) throws SAXException {
        posun -= 2;
        System.out.println(posun(posun) + "</" + qName + ">");
        if (localName == "plat") {
            plat = false;
        }
        if (localName == "pobocka") {
            pobocka = false;
        }
        if (localName == "kontakt") {
            kontaktB = false;
        }
        if (localName == "nazev") {
            nazev = false;
        }

    }

    /**
     * Obsluha události "znaková data". SAX parser muľe znaková data dávkovat
     * jak chce. Nelze tedy počítat s tím, že je celý text dorucen v rámci
     * jednoho volání. Text je v poli (ch) na pozicich (start) az
     * (start+length-1).
     *
     * @param ch Pole se znakovými daty
     * @param start Index zacátku úseku platných znakových dat v poli.
     * @param length Délka úseku platných znakových dat v poli.
     */
    public void characters(char[] ch, int start, int length) throws SAXException {
        String s = "";
        for (int i = start; i < start + length; i++) {
            if (ch[i] == ' ' || ch[i] == '\n' || ch[i] == '	') {
            } else {
                s += ch[i];
            }
        }
        if (!s.equals("")) {
            s = s.toUpperCase();
            System.out.println(posun(posun) + s);
            if (plat == true) {
                PrumPlat(Integer.parseInt(s));
            }
            if (pobocka == true) {
                if (kontaktB) {
                    kontakt[pocetPobocek - 1] = s;
                } else if (nazev) {
                    nazevPobocky[pocetPobocek - 1] = s;
                }
            }

        }
        pocetZnakuDoc = ch.length;
        // ...

    }

    /**
     * Obsluha události "deklarace jmenného prostoru".
     *
     * @param prefix Prefix prirazený jmennému prostoru.
     * @param uri URI jmenného prostoru.
     */
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    /**
     * Obsluha události "konec platnosti deklarace jmenného prostoru".
     */
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    /**
     * Obsluha události "ignorované bílé znaky". Stejné chování a parametry jako
     *
     * @see characters
     */
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        // ...
    }

    /**
     * Obsluha události "instrukce pro zpracování".
     */
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

    /**
     * Obsluha události "nezpracovaná entita"
     */
    public void skippedEntity(String name) throws SAXException {
        // ...
    }
}