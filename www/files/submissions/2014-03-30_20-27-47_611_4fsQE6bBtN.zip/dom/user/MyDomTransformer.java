package user;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer {

	public void transform (Document doc) {
	    // libovolne transformace objektu 'xmlDocument'
	    // (metoda pracuje primo na objektu, nic nevraci)
		/**
		 * Pridani noveho hrace
		 */
		/*
    	Element novyHrac = doc.createElement("hrac");
    	novyHrac.setAttribute("id", "_"+doc.getElementsByTagName("hrac").getLength());
    	novyHrac.setAttribute("status", "aktivni");
    	novyHrac.setAttribute("pohlavi", "muz");
    	novyHrac.appendChild(doc.createElement("name")).setTextContent("Honza Novak");
    	Element adresa= doc.createElement("adress");
    	adresa.appendChild(doc.createElement("town")).setTextContent("Praha 1");
    	novyHrac.appendChild(adresa);

    	doc.getElementsByTagName("hraci").item(0).appendChild(novyHrac);
    	*/
    	
    	/**
    	 * Smazani vsech pasivnich hracu
    	 */
		 /*
    	NodeList hraci=doc.getElementsByTagName("hrac");
    	for(int i=hraci.getLength()-1; i>=0;i--){
    		Node status = hraci.item(i).getAttributes().getNamedItem("status");
    		if(status.getTextContent().equals("pasivni"))
    			hraci.item(i).getParentNode().removeChild(hraci.item(i));    	
    	}
		*/

	  }
}
