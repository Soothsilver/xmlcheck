package user;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {

	/**
	 * Spocitat pocet muzu
	 */
/*	
	private int pocetMuzu=0;
	
	@Override
	public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
		// TODO Auto-generated method stub
		super.startElement(uri, localName, qName, atts);
		if(atts.getValue(uri, "pohlavi").equals("muz"))
			pocetMuzu++;
	}
*/
	
	
	/**
	 * pocet turnaju v roce 2014
	 */
/*	
	boolean turnaje=false;
	boolean datumTurnaje=false;
	int pocetTurnajuV2014=0;
	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes atts) throws SAXException {
		// TODO Auto-generated method stub
		super.startElement(uri, localName, qName, atts);
		if (localName.equals("turnaje")){
			turnaje=true;
		}
		if (localName.equals("datum")&&turnaje){
			datumTurnaje=true;
		}
	}
	
	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		// TODO Auto-generated method stub
		super.endElement(uri, localName, qName);
		if (localName.equals("turnaje")){
			turnaje=false;
		}
		if (localName.equals("datum")&&turnaje){
			datumTurnaje=false;
		}
	}
	
	@Override
	public void characters(char[] ch, int start, int length)
			throws SAXException {
		// TODO Auto-generated method stub
		super.characters(ch, start, length);
		if(datumTurnaje){
			if(ch[start+length-1]=='4'&&ch[start+length-2]=='1'){
				pocetTurnajuV2014++;
			}
		}
		
	}
*/
	/**
	 * Pocet aktivnich muzu
	 */
/*
	private int pocetAktivnichMuzu=0;

	@Override
	public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
		// TODO Auto-generated method stub
		super.startElement(uri, localName, qName, atts);
		if(atts.getValue(uri, "pohlavi").equals("muz")&&atts.getValue(uri, "status").equals("aktivni"))
			pocetAktivnichMuzu++;
	}
*/
}
