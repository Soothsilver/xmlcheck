package user; 

import org.w3c.dom.Attr;  
import org.w3c.dom.Text; 
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

public class MyDomTransformer {
    
    public void transform (Document xmlDocument) {
        // pridame noveho vyvojare
        
	xmlDocument.getDocumentElement().normalize();
        
        Element vyvojar = xmlDocument.createElement("vyvojar");
        vyvojar.setAttribute("id", "v8");
        
        Element nazev = xmlDocument.createElement("nazev");
        Text nazev_T = xmlDocument.createTextNode("SCS Software");
        nazev.appendChild(nazev_T);
        
        Element zeme_puvodu = xmlDocument.createElement("zeme-puvodu");
        Text zeme_puvodu_T = xmlDocument.createTextNode("Ceska republika");
        zeme_puvodu.appendChild(zeme_puvodu_T);
                
        Element popis = xmlDocument.createElement("popis");  
        Text popis_T = xmlDocument.createTextNode("Novi herni vyvojari, kteri se zameruji na truckove simulatory.");
        popis.appendChild(popis_T);
         
        Element rok_vzniku = xmlDocument.createElement("rok-vzniku");
        Text rok_vzniku_T = xmlDocument.createTextNode("2005");
        rok_vzniku.appendChild(rok_vzniku_T);
        
        Element rok_zaniku = xmlDocument.createElement("rok-zaniku");
        Element vytvorene_hry = xmlDocument.createElement("vytvorene-hry");
        
        vyvojar.appendChild(nazev);
        vyvojar.appendChild(zeme_puvodu);
        vyvojar.appendChild(popis);
        vyvojar.appendChild(rok_vzniku);
        vyvojar.appendChild(rok_zaniku);
        vyvojar.appendChild(vytvorene_hry);
        
        Element d = xmlDocument.getDocumentElement();
        Node vyvojari = d.getElementsByTagName("vyvojari").item(0);
        vyvojari.appendChild(vyvojar);
        
        // smazeme vsechny hry starsi roku 2000
        
        Node hry = d.getElementsByTagName("hry").item(0);
        
        NodeList roky = d.getElementsByTagName("rok");
        for(int i = 0; i < roky.getLength(); i++){
            Node rok = roky.item(i);
            System.out.println(rok.getTextContent());
            if(Integer.parseInt(rok.getTextContent()) < 2000)
                hry.removeChild(rok.getParentNode().getParentNode());
        }
    }
}
