package user;

import java.util.Enumeration;
import java.util.Hashtable;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Domaci ukol 2
 *
 * Jako zaklad poslouzil soubor ze stranek cviceni
 * 
 * @author Jan Bok
 */
public class MySaxHandler extends DefaultHandler {

    int with_multiplayer = 0, games = 0, new_games_with_mp = 0, year; 
    boolean has_multiplayer = false, inside_year_element = false, inside_country_element = false;
    String country;
    
    StringBuffer element_content;
    
    Hashtable<String,Integer> countries = new Hashtable<String,Integer>();
    
    @Override
    public void startDocument() throws SAXException {
    }

    @Override
    public void endDocument() throws SAXException {
        System.out.println("Multiplayer ma " + with_multiplayer + " her z " +  games);
        
        int max = 0, act;
        String max_country = "";
        
        Enumeration keys = countries.keys(); 
        while(keys.hasMoreElements()) { 
            String str = (String) keys.nextElement(); 
            act = countries.get(str);
            if(act > max)
                max_country = str;
        } 
        
        System.out.println("Nejcastejsi zeme puvodu vyvojaru je: " + max_country);
        
        System.out.println("Pocet her s hrou pro vice hracu a zaroven vydanych v roce 2004 a pozdeji " + new_games_with_mp);
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        if(qName.equals("hra"))
        {
            ++games;
            
            for(int i = 0; i < attributes.getLength(); ++i)
            {
                if(attributes.getQName(i).equals("multiplayer"))
                {
                    String tmp = attributes.getValue(i);
                    System.out.println(tmp);
                    if(tmp.equals("ano"))
                        has_multiplayer = true;
                }
            }
        }
        
        if(qName.equals("zeme-puvodu"))
        {
            inside_country_element = true;
            element_content = new StringBuffer();
        }
        
        if(qName.equals("rok"))
        {
            inside_year_element = true;
            element_content = new StringBuffer();
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName)
    throws SAXException {
        if(qName.equals("hra"))
        {
            if(has_multiplayer)
                ++with_multiplayer;
            
            if(has_multiplayer && year >= 2004)
                ++new_games_with_mp;
        }
        
        if(qName.equals("rok"))
        {
            inside_year_element = false;
            year = Integer.parseInt(element_content.toString());
        }
        
        if(qName.equals("zeme-puvodu"))
        {
            inside_country_element = false;
            country = element_content.toString();
            
            if(countries.containsKey(country))
            {
                int tmp = countries.get(country);
                countries.put(country, tmp + 1);
            }
            else
            {
                countries.put(country, 1);
            }
            
        }
    }

    @Override
    public void characters(char ch[], int start, int length)
    throws SAXException {
        if(inside_year_element || inside_country_element)
        {
            element_content.append(ch, start, length);
        }
    }
}