package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

//transformacia prejde cely XML dokument a vsetky uzly s nazvom rating nahradi
//novym uzlom ratings, ktory bude obsahovat dva uzly: imdb a csfd
//tieto dva uzly budu obsahovat hodnoty z atributov v povodnom uzle rating
public class MyDomTransformer {

    public static void transform (Document xmlDocument) {
    	String imdbRating = "";
    	String csfdRating = "";
    	
    	NodeList movies = xmlDocument.getElementsByTagName("movie");
    	//iteracia cez vsetky filmy
    	for(int i=0; i<movies.getLength(); i++) {
    		Node movie = movies.item(i);
    		NodeList children = movie.getChildNodes();

    		for(int j=0; j<children.getLength(); j++) {
    			//najdeme Node s nazvom rating, vytiahneme data a odstranime ho
    			if (children.item(j).getNodeName().equals("rating")) {
    				Node rating = children.item(j);
    				imdbRating = rating.getAttributes().getNamedItem("imdb").getNodeValue();
    				csfdRating = rating.getAttributes().getNamedItem("csfd").getNodeValue();
    				movie.removeChild(rating);
    				break;
    			}
    		}

    		//vytvorenie noveho Node-u ratings s hodnotami z toho stareho
    		Element newRating = xmlDocument.createElement("ratings");

    		Element imdbNode = xmlDocument.createElement("imdb");
    		Text imdbValue = xmlDocument.createTextNode(imdbRating);
    		imdbNode.appendChild(imdbValue);

    		Element csfdNode = xmlDocument.createElement("csfd");
    		Text csfdValue = xmlDocument.createTextNode(csfdRating);
    		csfdNode.appendChild(csfdValue);
    		
    		newRating.appendChild(imdbNode);
    		newRating.appendChild(csfdNode);
    		
    		movie.appendChild(newRating);
    	} 	
    }
}
