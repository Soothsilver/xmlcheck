package user;

import java.util.ArrayList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

//vypise zoznam osob a k nim filmy v ktorych hraju
public class MySaxHandler extends DefaultHandler {


    List<Person> persons = new ArrayList<Person>();

    class Person
    {
    	String id;
    	String firstname;
    	String surname;
    	List<String> movies = new ArrayList<String>();
    	
    	Person(String id, String firstname, String surname)
    	{
    		this.id = id;
    		this.firstname = firstname;
    		this.surname = surname;
    	}
    	
    }
	
    
    String actualMovieName = "";
	
	public void startDocument() throws SAXException {

	}
	
	public void endDocument() throws SAXException {
		//vypis vysledku na konzolu
		for(Person person : persons) {
			if (person.movies.size()>0) {
				System.out.println(person.firstname + " " + person.surname + ":");
				for(String movieName : person.movies) {
					System.out.println(movieName);
				}
				System.out.println("-----------------------------------------");
			}
		}
	}
	
	public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
		//berieme vsetky osoby
		if (qName.equals("person")) {
			String id = atts.getValue("id");
			String firstname = atts.getValue("firstname");
			String surname = atts.getValue("surname");
			persons.add(new Person(id, firstname, surname));
		}
		//ulozenie nazvu filmu
		if (qName.equals("officialName")) {
			actualMovieName = atts.getValue("value");
		}
		if (qName.equals("actor")) {
			if (actualMovieName!="") {
				String actorId = atts.getValue("idref");
				for(Person p : persons) {
					//pridanie filmu k spravnym osobam
					if (p.id.equals(actorId))
					{
						p.movies.add(actualMovieName);
					}
				}
			}
		}
	}
	
	public void endElement(String uri, String localName, String qName) throws SAXException {

	}
}
