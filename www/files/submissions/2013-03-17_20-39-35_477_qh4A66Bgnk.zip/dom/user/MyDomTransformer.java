package user;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * 2 implementovane upravy dokumentu:
 * 1) pridani nove hry se vsemi parametry
 * 2) smazani vsech vydavatelu, kteri maji sidlo v USA
 * 
 * @author Pavel Salamon <salampa1 at fel.cvut.cz>
 */
public class MyDomTransformer {

    public void transform(Document xmlDocument) {
        addNewGame(xmlDocument);
        deletePublishersFromUSA(xmlDocument);
    }
    
    private void addNewGame(Document xmlDocument) {
        Node titles = xmlDocument.getElementsByTagName("titles").item(0);
        
        Node game = xmlDocument.createElement("game");
        game.getAttributes().setNamedItem(xmlDocument.createAttribute("id"));
        game.getAttributes().getNamedItem("id").setNodeValue("_13");
        
        game.appendChild(xmlDocument.createElement("name").appendChild(xmlDocument.createTextNode("Starcraft")).getParentNode()); 
        game.appendChild(xmlDocument.createElement("year").appendChild(xmlDocument.createTextNode("1997")).getParentNode());
        game.appendChild(xmlDocument.createElement("description").appendChild(xmlDocument.createTextNode("Strategy game by Blizzard.")).getParentNode());
        Node genre = xmlDocument.createElement("genre");
        genre.getAttributes().setNamedItem(xmlDocument.createAttribute("type"));
        genre.getAttributes().getNamedItem("type").setNodeValue("Strategy");
        game.appendChild(genre);
        
        Node publisher = xmlDocument.createElement("gamePublisher");
        publisher.getAttributes().setNamedItem(xmlDocument.createAttribute("idref"));
        publisher.getAttributes().getNamedItem("idref").setNodeValue("_5");
        game.appendChild(publisher);
        
        Node developer = xmlDocument.createElement("gameDeveloper");
        developer.getAttributes().setNamedItem(xmlDocument.createAttribute("idref"));
        developer.getAttributes().getNamedItem("idref").setNodeValue("_7");
        game.appendChild(developer);
        
        Node platform = xmlDocument.createElement("platform");
        platform.getAttributes().setNamedItem(xmlDocument.createAttribute("playableOn"));
        platform.getAttributes().getNamedItem("playableOn").setNodeValue("PC");
        game.appendChild(platform);
        
        game.appendChild(xmlDocument.createElement("attachments"));
        
        
        titles.appendChild(game);
    }
    
    private void deletePublishersFromUSA(Document xmlDocument) {
        NodeList states = xmlDocument.getElementsByTagName("state");
        
        for (int i = states.getLength()-1; i >=0; i--) {
            String value = states.item(i).getTextContent();
            if (value.equals("USA")) {
                Node publisherOrDeveloper = states.item(i).getParentNode().getParentNode().getParentNode();
                if (publisherOrDeveloper.getNodeName().equals("publisher")) {
                    publisherOrDeveloper.getParentNode().removeChild(publisherOrDeveloper);
                }
            }
        }
    }
}