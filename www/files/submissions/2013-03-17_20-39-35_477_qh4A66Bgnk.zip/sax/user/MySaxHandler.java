package user;

import java.util.HashMap;
import java.util.Map.Entry;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;

/**
 * Charakteristika vztahnuta k hodnotam atributu: pocty her, ktere sa daji hrat na dane platforme
 * Charakteristika vztahnuta k obsahu elementu: pocty vydavatelu dle zemi
 * Charakteristika vztahnuta ke kontextu: pocet her, ktere vysly po roce 2000, jsou hratelne na XBOX a maji zanr RPG
 * 
 * @author Pavel Salamon <salampa1 at fel.cvut.cz>
 */
public class MySaxHandler extends DefaultHandler {

    HashMap<String, Integer> publishers = new HashMap<String, Integer>();
    HashMap<String, Integer> platforms = new HashMap<String, Integer>();
    boolean insidePublisher = false;
    boolean insideState = false;
    int numGames = 0;
    boolean game_playableOnXBOX = false;
    boolean game_afterYear2000 = false;
    boolean game_isRPG = false;
    boolean insideYear = false;

    public void endDocument() throws SAXException {
        System.out.println("Pocty vydavatelu dle zeme:");
        for (Entry<String, Integer> e : publishers.entrySet()) {
            System.out.println(e.getKey() + ": " + e.getValue());
        }

        System.out.println("\nPocty her, ktere sa daji hrat na dane platforme:");
        for (Entry<String, Integer> e : platforms.entrySet()) {
            System.out.println(e.getKey() + ": " + e.getValue());
        }

        System.out.println("\nPocet her, ktere vysly po roce 2000, jsou hratelne na XBOX a maji zanr RPG: " + numGames);

    }

    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        if (qName.equals("publisher")) {
            insidePublisher = true;
        } else if (qName.equals("state")) {
            insideState = true;
        } else if (qName.equals("platform")) {
            String platform = atts.getValue("playableOn");
            if (platforms.containsKey(platform)) {
                platforms.put(platform, platforms.get(platform) + 1);
            } else {
                platforms.put(platform, 1);
            }

            if (platform.equals("XBOX")) {
                game_playableOnXBOX = true;
            }
        } else if (qName.equals("game")) {
            game_afterYear2000 = false;
            game_isRPG = false;
            game_playableOnXBOX = false;
        } else if (qName.equals("year")) {
            insideYear = true;
        } else if (qName.equals("genre")) {
            String type = atts.getValue("type");
            if (type.equals("RPG")) {
                game_isRPG = true;
            }
        }

    }

    public void endElement(String uri, String localName, String qName) throws SAXException {

        if (qName.equals("publisher")) {
            insidePublisher = false;
        } else if (qName.equals("state")) {
            insideState = false;
        } else if (qName.equals("year")) {
            insideYear = false;
        } else if (qName.equals("game")) {
            if (game_afterYear2000 && game_isRPG && game_playableOnXBOX) {
                numGames++;
            }
        }

    }

    public void characters(char[] ch, int start, int length) throws SAXException {

        String text = new String(ch, start, length);
        text = text.trim();
        if (text.length() != 0) {
            if (insidePublisher && insideState) {
                if (publishers.containsKey(text)) {
                    publishers.put(text, publishers.get(text) + 1);
                } else {
                    publishers.put(text, 1);
                }
            } else if (insideYear) {
                if (Integer.parseInt(text) > 2000) {
                    game_afterYear2000 = true;
                }
            }

        }


    }
}