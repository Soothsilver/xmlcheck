package user;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Main: new MySaxHandler();
 * Trida co vypise strukturu XML dokumentu a statistiku jako je :
 * První element v dokumentu.
 * Počet elementu v dokumentu a kolik z nich obsahuje textova data.
 * Počet attributu v dokumentu.
 * Maximalni hloubka dokumentu.
 * Nejdelší název elementu a jeho jmeno.
 * Nejdelší název attributu a jeho jmeno.
 * Průměrná délka názvů elementu(zaokrouhleno) v charech.
 * Průměrná délka názvů attributu(zaokrouhleno) v charech.
 */

public class MySaxHandler extends DefaultHandler{
    // Cesta ke zdrojovému XML dokumentu  
    private String cestaSouboru = "data.xml";
    
    public MySaxHandler() {
        try {

            XMLReader parser = XMLReaderFactory.createXMLReader();
            InputSource source = new InputSource(cestaSouboru);
            parser.setContentHandler(this);
            parser.parse(source);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    //pomocne promenne
    int hloubka;
    int elementy;
    int data;
    int atts = 0;
    int maxHloubka = 0;
    boolean platnaData = false;
    String prvniElement = "";
    String maxNazevElementu = "";
    String maxNazevAttributu = "";
    double celkovaDelkaElementu = 0;
    double celkovaDelkaAttributu = 0;
    
    /**
     * Vypisuje hloubku pomoci znaku z parametru
     * @param s 
     */
    void hloubka(String s) {
        for (int i = 0; i < hloubka; i++) {
            System.out.print(s);
        }
    }

    @Override
    public void startDocument() {
        System.out.println("***Začátek XML***");

    }

    @Override
    public void endDocument() {
      System.out.println("***Konec XML***");
      vypis();
    }
    /**
     * Vypise statistiku dokumentu
     */
    private void vypis(){
        System.out.println("První element v dokumentu je: " + prvniElement);
        System.out.println("Počet elementu v dokumentu: " + elementy + ". Z toho " + data + " elementu obsahuje data." );
        System.out.println("Počet attributu v dokumentu: " + atts);
        System.out.println("Maximalni hloubka dokumentu je: " + maxHloubka);
        System.out.println("Nejdelší název elementu je " + maxNazevElementu.length() + " znaků : " + maxNazevElementu);
        System.out.println("Nejdelší název attributu je " + maxNazevAttributu.length() + " znaků : " + maxNazevAttributu);
        System.out.println("Průměrná délka názvů elementu(zaokrouhleno) je: " + Math.round(celkovaDelkaElementu / elementy));
        System.out.println("Průměrná délka názvů attributu(zaokrouhleno) je: " + Math.round(celkovaDelkaAttributu / atts));
    
    }
    /**
     * 
     * @param uri
     * @param localName
     * @param qName
     * @param attributes 
     */
    @Override
    public void startElement(String uri, String localName,
            String qName, Attributes attributes) {
        hloubka("-");
        if (prvniElement.isEmpty()) {
            prvniElement = qName;
        }
        System.out.print("Začínající element: " + qName);
        elementy++;
        hloubka++;
        celkovaDelkaElementu += qName.length();
        int i = 0;
        //vypisuje atributy
        while (i < attributes.getLength()) {
            System.out.print(", attribut: " + attributes.getQName(i));
            System.out.print("=\"" + attributes.getValue(i) + "\"");
            // uklada nazev nejdelsiho nazvu atributu
            if (maxNazevAttributu.length() < (attributes.getQName(i)).length()) {
                maxNazevAttributu = attributes.getQName(i);
            }
            celkovaDelkaAttributu += (attributes.getQName(i)).length();
            i++;
            atts++;
        }
        System.out.println("");
        // rozhoduje o nejdelsim nazvu elementu
        if (maxNazevElementu.length() < qName.length()) {
            maxNazevElementu = qName;
        }
        // rozhoduje o maximalni hloubce elementu
        if (hloubka > maxHloubka) {
            maxHloubka = hloubka;
        }
    }

    @Override
    public void endElement(String uri, String localName,
            String qName) {
        hloubka--;
        hloubka("-");
        System.out.println("Končící element   : " + qName);
    }
    /**
     * rozhoduje zda se jedna o zbytecne whitespaces
     * @param ch
     * @param start
     * @param length 
     */
    @Override
    public void ignorableWhitespace(char[] ch, int start, int length) {
        if (new String(ch, start, length).trim().isEmpty()) {
            platnaData = false;
        } else {
        platnaData = true;
        }
    }
    /**
     * Pocatecni instrukce
     * @param target
     * @param data 
     */
    @Override
    public void processingInstruction(String target, String data) {
        hloubka("");
        System.out.println("Instrukce pro zpracování: " + target + ", " + data);
    }
    /**
     * Vypisuje textova data v elementech
     * @param ch
     * @param start
     * @param length 
     */
    @Override
    public void characters(char[] ch, int start, int length) {
    ignorableWhitespace(ch, start, length);
        if (platnaData) {
            hloubka(" ");
           System.out.println("Data:" + new String(ch, start, length).trim()); 
           platnaData = false;
           data++;
        }  
    }
}

