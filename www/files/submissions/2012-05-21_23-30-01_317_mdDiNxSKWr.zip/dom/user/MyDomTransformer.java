package user;

import java.io.File;


import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

/**
 * Prejmenovava root element.
 * Prehazeni elementu sestupne.
 * Nahrazeni atributu elementem.
 */
public class MyDomTransformer {

    private static final String VYSTUPNI_SOUBOR = "data.out.xml";
    //promenna jak se bude jmenovat novy root element
    private static String NOVY_ROOT = "prejmenovany_root";

    /**
     * Zpracuje DOM strom
     */
    public void transform(Document doc) throws ParserConfigurationException {
        try {
            Element root = doc.getDocumentElement();
            Element newRoot = doc.createElement(NOVY_ROOT);
            //Prehazeni elementu sestupne
            NodeList reverseChilds = root.getChildNodes();
            for (int i = (reverseChilds.getLength() - 1); (i > -1); i--) {
                root.appendChild(reverseChilds.item(i));
            }
            ////Konec prehazeni
            
            //Prejmenuje root element na zvoleny a varuje v komentu  
            Comment comment = doc.createComment("Prejmenovany root na " + NOVY_ROOT);
            newRoot.appendChild(comment);

            NodeList childs = root.getChildNodes();
            for (int i = 0; i < childs.getLength(); i++) {
                newRoot.appendChild(childs.item(i).cloneNode(true));
            }
            root.appendChild(newRoot);
            doc.replaceChild(newRoot, root);
            ////Konec prejmenovani rootu
            
            //Nahrazeni atributu elementem
            childs = newRoot.getChildNodes();
            NamedNodeMap map = null;
            for (int i = 0; i < childs.getLength(); i++) {
                 map = newRoot.getAttributes();
            }
            if (map.getLength() > 0 && map != null) {
                for (int j = 0; j < map.getLength(); j++) {
                    Element child = doc.createElement(map.item(j).getNodeName());
                    child.removeAttribute(map.item(j).getNodeName());
                    child.setTextContent(map.item(j).getNodeValue());
                    newRoot.appendChild(child);
                }   
            }    
            ////Konec predelani atributu
            makeFile(doc);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    
    /**
     * Vytvori nove zmenene XML
     * @param doc
     * @throws TransformerException 
     */
    private static void makeFile(Document doc) throws TransformerException {
        TransformerFactory transfac = TransformerFactory.newInstance();
        Transformer trans;
        try {
            trans = transfac.newTransformer();
            trans.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            trans.setOutputProperty(OutputKeys.INDENT, "yes");
            trans.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            trans.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));
        } catch (TransformerConfigurationException ex) {
            Logger.getLogger(MyDomTransformer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
