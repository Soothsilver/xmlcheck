package user;

import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;
import java.util.ArrayList;
import org.xml.sax.helpers.DefaultHandler;

/*public class SAX_podpora {

    public static void main(String[] args) {
        String sourcePath = "data.xml";
        try {
            XMLReader parser = XMLReaderFactory.createXMLReader();
            InputSource source = new InputSource(sourcePath);
            parser.setContentHandler(new MyContentHandler());
            parser.parse(source);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}*/

public class MySaxHandler extends DefaultHandler {

    public Locator locator;
    Integer releaseSizeAll = 0;
    Integer releaseCount = 0;
    Integer releaseSizeMin = Integer.MAX_VALUE;
    Integer releaseSizeMax = Integer.MIN_VALUE;
    Integer currentReleaseSize = 0;
    
    public Double GetReleaseSizeAvg()
    {
        if(releaseCount == 0)
            return 0.0;
        else
            return ((1.0*releaseSizeAll) / (1.0*releaseCount)); //Nejsem odbornik na javu, radsi vynasobim 1.0 pro jistotu
    }
    
    public Integer GetReleaseSizeMin()
    {
        return releaseSizeMin;
    }
    
    public Integer GetReleaseSizeMax()
    {
        return releaseSizeMax;
    }
    
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    @Override
    public void startDocument() throws SAXException {
        
        // ...
        
    }
    @Override
    public void endDocument() throws SAXException {
        
        System.out.println("Release sizes:");
        System.out.print("\t - Minimum:");
        System.out.println(GetReleaseSizeMin());
        System.out.print("\t - Maximum:");
        System.out.println(GetReleaseSizeMax());
        System.out.print("\t - Average:");
        System.out.println(GetReleaseSizeAvg());
    }
    
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if("release".equals(localName))
            currentReleaseSize = 0; // pro jistotu
        else if("track".equals(localName))
            currentReleaseSize++;
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {

        if("release".equals(localName))
        {
            releaseSizeAll += currentReleaseSize;
            releaseCount++;
            if(releaseSizeMin > currentReleaseSize)
                releaseSizeMin = currentReleaseSize;
            if(releaseSizeMax < currentReleaseSize)
                releaseSizeMax = currentReleaseSize;
            currentReleaseSize = 0;
        }

    }
            
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {

        // ...
        
    }

    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
        // ...
        
    }

    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
    
        // ...
    
    }
 
    @Override
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
        // ...
        
    }
     
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
      
      // ...
            
    }
      
    @Override
    public void skippedEntity(String name) throws SAXException {
    
      // ...
    
    }
}