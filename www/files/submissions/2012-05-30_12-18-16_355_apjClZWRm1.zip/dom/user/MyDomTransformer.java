package user;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

public class MyDomTransformer {

    /*private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "data.reversed.xml";

    public static void main(String[] args) {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setValidating(false);
            DocumentBuilder builder = dbf.newDocumentBuilder();
            Document doc = builder.parse(VSTUPNI_SOUBOR);
            processTree(doc);
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer writer = tf.newTransformer();
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }*/

    public static void transform(Document doc) {
        Node root = doc.getElementsByTagName("musicdb").item(0);
        Node tracksNode = doc.createElement("tracks");
        root.appendChild(tracksNode);
        NodeList artistsNl = doc.getElementsByTagName("artists"); 
        for(int asi = 0; asi < artistsNl.getLength(); asi++)
        {
            NodeList artistNl = artistsNl.item(asi).getChildNodes();   
            for(int ai = 0; ai < artistNl.getLength(); ai++)
            {
                Node artistNode = artistNl.item(ai);
                if(!"artist".equals(artistNode.getNodeName()))
                    continue;
                NodeList releasesNl = artistNode.getChildNodes();      
                for(int rsi = 0; rsi < releasesNl.getLength(); rsi++)
                {
                    Node releasesNode = releasesNl.item(rsi);
                    if(!"releases".equals(releasesNode.getNodeName()))
                        continue;
                    NodeList releaseNl = releasesNode.getChildNodes();
                    for(int ri = 0; ri < releaseNl.getLength(); ri++)
                    {
                        Node releaseNode = releaseNl.item(ri);
                        if(!"release".equals(releaseNode.getNodeName()))
                            continue;
                        NodeList trackNl = releaseNode.getChildNodes();
                        for(int ti = 0; ti < trackNl.getLength(); ti++)
                        {
                            Node trackNode = trackNl.item(ti);
                            if(!"track".equals(trackNode.getNodeName()))
                                continue;
                            trackNode.appendChild(artistNode.cloneNode(false));
                            trackNode.appendChild(releaseNode.cloneNode(false));
                            tracksNode.appendChild(trackNode);
                        }
                    }
                }
            }
            root.removeChild(artistsNl.item(asi));
        }
    }
}
