package user;

import java.util.*;

import org.w3c.*;
import org.w3c.dom.*;

public class MyDomTransformer {
	private static int CUT_LEVEL = 3;
	
	private void cut(Node node, int level) {
		NodeList children = node.getChildNodes();
		
		if (children!=null) {
			if (level<CUT_LEVEL) {
				for (int i=0; i<children.getLength(); i++) {
					cut(children.item(i), level+1);
				}
			} else {
				Set<Node> to_be_removed = new HashSet<Node>();
				
				for (int i=0; i<children.getLength(); i++) {
					to_be_removed.add(children.item(i));
				}				
				
				for (Node n: to_be_removed) {					
					node.removeChild(n);
				}
			}
		}
	}
	
	public void transform(Document xmlDocument) {
		cut(xmlDocument.getDocumentElement(), 0);
	}
}
