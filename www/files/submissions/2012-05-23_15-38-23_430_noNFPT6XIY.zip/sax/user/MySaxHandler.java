package user;

import java.util.*;

import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
	Set<String> unique_attributes = new HashSet<String>();

	@Override
	public void endDocument() throws SAXException {
		
		
		System.out.printf("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>");
		System.out.printf("<attributes>\n");
		System.out.printf("\t<count>%s</count>\n", unique_attributes.size());
		System.out.printf("\t<list>\n");
		for (String attr: unique_attributes) {
			System.out.printf("\t\t<attribute>%s</attribute>\n", attr);
		}
		System.out.printf("\t</list>\n");
		System.out.printf("</attributes>\n");
	}
	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {
		for (int i=0; i<attributes.getLength(); i++) {
			unique_attributes.add(attributes.getQName(i));
		}
	}	
}
