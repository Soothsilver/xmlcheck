package user;

import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler 
{ 
  // Path to input file
   private static final String INPUT_FILE = "data.xml";

   /**
    * Main method
    *
    * @param args command line arguments
    */
   public static void main(String[] args) {

       try {

           // Create parser instance
           XMLReader parser = XMLReaderFactory.createXMLReader();

           // Create input stream from source XML document
           InputSource source = new InputSource(INPUT_FILE);

           // Set our custom content handler for handling SAX events (it must implements ContentHandler interface)
           parser.setContentHandler(new MySaxHandler());

           // Process input data
           parser.parse(source);

       } catch (Exception e) {

           e.printStackTrace();

       }

   }
   
   public MySaxHandler()
   {
   }
   
   int depth = 0;
   int pocetClanku = 0;
   int pocetAutoru = 0;
   
   List<String> redaktoriPodleAbecedy = null;
   List<String> sefredaktoriPodleAbecedy = null;
   String aktualJmeno;
   String currentElementName;
   
   int pocetPublikovatelnychClankuBezObrazku = 0;
   boolean maClanekObrazek = false;
   
   // Helper variable to store location of the handled event
   Locator locator;
   
   void printWithDepth(String s) {
       for (int i = 0; i < depth; i++) {
           System.out.print("  ");
       }
       System.out.println(s);
   }

   /**
    * Sets the locator
    *
    * @param Locator locator location in the file
    */
   @Override
   public void setDocumentLocator(Locator locator) {
       this.locator = locator;
   }

   /**
    * Method to handle "document start"
    *
    * @throws SAXException
    */
   @Override
   public void startDocument() throws SAXException 
   {
       aktualJmeno = "";
       redaktoriPodleAbecedy = new ArrayList<String>();
       sefredaktoriPodleAbecedy = new ArrayList<String>();
   }

   /**
    * Method to handle "document end"
    *
    * @throws SAXException
    */
   @Override
   public void endDocument() throws SAXException {
       
       System.out.println("<PocetClanku>" + Integer.toString(pocetClanku) + "</PocetClanku>");
       System.out.println("<PocetAutoru>" + Integer.toString(pocetAutoru) + "</PocetAutoru>");
       
       Collections.sort(redaktoriPodleAbecedy);
       Collections.sort(sefredaktoriPodleAbecedy);
 
       System.out.println();
       System.out.println("<RedaktoriPodleAbecedy>");
       for (String str : redaktoriPodleAbecedy) 
       {
          System.out.println("<Redaktor>" + str + "</Redaktor>");
       }
       System.out.println("</RedaktoriPodleAbecedy>");
       
       System.out.println();
       System.out.println("<SefredaktoriPodleAbecedy>");
       for (String str : sefredaktoriPodleAbecedy) 
       {
          System.out.println("<Sefredaktor>" + str + "</Sefredaktor>");
       }
       System.out.println("</SefredaktoriPodleAbecedy>");
       
       System.out.println();
       System.out.println("<PocetPublikovatelnychClankuBezObrazku>" + Integer.toString(pocetPublikovatelnychClankuBezObrazku) + "</PocetPublikovatelnychClankuBezObrazku>");
   }

   /**
    * Method to handle "begin element"
    *
    * @param uri URI of the element namespace (empty if element is no
    * namespace)
    * @param localName local name of the element (never empty)
    * @param qName qualified name (prefix-URI + ':' + localName, if the element
    * is in some namespace or localName otherwise)
    * @param atts Element's attributes
    * @throws SAXException
    */
   @Override
   public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
       
       for (int i = 0; i < atts.getLength(); i++) 
       {
           String name = atts.getLocalName(i);           
           if(name.equals("id"))
           {
               pocetClanku++;
           }        
           if(name.equals("idaut"))
           {
               pocetAutoru++;
           } 
           if(name.equals("stat"))
           {
              String val = atts.getValue(name);
              if(val.equals("ano"))
              {
                if(maClanekObrazek)
                {
                  pocetPublikovatelnychClankuBezObrazku++;
                }
              }
           }            
       }       
       
       if (localName.equals("clanek"))
       {  
          maClanekObrazek = false;
       }
       if (localName.equals("obrazek"))
       {
          maClanekObrazek = true;
       }
         
       currentElementName = localName; 
       depth++;
    }

   /**
    * Method to handle "element end"
    *
    * @param uri URI of the element namespace (empty if element is no
    * namespace)
    * @param localName local name of the element (never empty)
    * @param qName qualified name (prefix-URI + ':' + localName, if the element
    * is in some namespace or localName otherwise)
    * @param atts Element's attributes
    * @throws SAXException
    */
   @Override
   public void endElement(String uri, String localName, String qName) throws SAXException 
   {  
      depth--;
   }

   /**
    * Method to handle "character data" SAX parser can process data in various
    * batches. so we can't rely that whole whole text content will be delivered
    * in one call Text is in array 'chars' from position ('start') to ('start'
    * + 'length' - 1)
    *
    * @param chars Array with char data
    * @param start Index of the begin of valid data
    * @param length Length of the valid data
    * @throws SAXException
    */
   @Override
   public void characters(char[] chars, int start, int length) throws SAXException 
   {
      String s = new String(chars, start, length).trim();;
      
      if (currentElementName.equals("prijmeni"))
      {
          aktualJmeno += " ";
          aktualJmeno += s;  
      }
      
      if (currentElementName.equals("pozice"))
      {
         if (s.equals("redaktor"))
         {
            redaktoriPodleAbecedy.add(aktualJmeno);
         }
         if (s.equals("sefredaktor"))
         {
            sefredaktoriPodleAbecedy.add(aktualJmeno);
         } 
         
         aktualJmeno = "";
      }
   }

   /**
    * Method to handle " start of namespace declaration"
    *
    * @param prefix Prefix of the namespace
    * @param uri URI of the namespace
    * @throws SAXException
    */
   @Override
   public void startPrefixMapping(String prefix, String uri) throws SAXException {
       // ...
   }

   /**
    * Method to handle "end of namespace declaration"
    *
    * @param prefix
    * @throws SAXException
    */
   @Override
   public void endPrefixMapping(String prefix) throws SAXException {
       // ...
   }

   /**
    * Method to handle "ignoring of whitespaces" Text is in array 'chars' from
    * position ('start') to ('start' + 'length' - 1)
    *
    * @param chars Array with char data
    * @param start Index of the begin of valid data
    * @param length Length of the valid data
    * @throws SAXException
    * @throws SAXException
    */
   @Override
   public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
       // ...
   }

   /**
    * Method to handle "processing instructions"
    *
    * @param target The processing instruction target
    * @param data  The processing instruction data
    * @throws SAXException
    */
   @Override
   public void processingInstruction(String target, String data) throws SAXException {
       // ...
   }

   /**
    * Method to handle "unprocessed entity"
    *
    * @param name
    * @throws SAXException
    */
   @Override
   public void skippedEntity(String name) throws SAXException {
       // ...
   }
}


