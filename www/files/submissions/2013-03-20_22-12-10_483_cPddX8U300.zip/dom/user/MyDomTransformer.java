package user; 

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;
import org.w3c.dom.Document;
import org.w3c.dom.Element; 

public class MyDomTransformer 
{ 
    private static final String INPUT_FILE = "data.xml";
    private static final String OUTPUT_FILE = "data.out.xml";

    /**
     * Main method
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {

        try {

            // DocumentBuilderFactory creates DOM parsers
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            // We don't want to validate file
            dbf.setValidating(false);

            // Creating of DOM parser instance
            DocumentBuilder builder = dbf.newDocumentBuilder();

            // Parser processes input file and creates a DOM tree of objects
            Document doc = builder.parse(INPUT_FILE);

            MyDomTransformer dom = new MyDomTransformer();
            // DOM tree processing
            dom.transform(doc);

            // TransformerFactory creates an object for DOM serialization
            TransformerFactory tf = TransformerFactory.newInstance();

            // Transformer serializes DOM tree
            Transformer writer = tf.newTransformer();

            // Setting of output file encoding
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            // Run transformation of DOM tree to XML document
            writer.transform(new DOMSource(doc), new StreamResult(new File(OUTPUT_FILE)));


        } catch (Exception e) {

            e.printStackTrace();

        }
    }
    
    public MyDomTransformer()
    {}

    public void transform(Document xmlDocument) 
    { 
        // přidá šéfredaktora
        NodeList nodes = xmlDocument.getElementsByTagName("autori");
        
        Element autorElement = xmlDocument.createElement("autor");
        autorElement.setAttribute("idaut","id_11");
            
            
        Element jmenoElement = xmlDocument.createElement("jmeno");
        autorElement.appendChild(jmenoElement);
            
        Element krestniElement = xmlDocument.createElement("krestni");
        krestniElement.appendChild(xmlDocument.createTextNode("Jaja"));
        jmenoElement.appendChild(krestniElement);
            
        Element prijmeniElement = xmlDocument.createElement("prijmeni");
        prijmeniElement.appendChild(xmlDocument.createTextNode("Paja"));
        jmenoElement.appendChild(prijmeniElement);
            
            
            
        Element poziceElement = xmlDocument.createElement("pozice");
        poziceElement.appendChild(xmlDocument.createTextNode("sefredaktor"));
        autorElement.appendChild(poziceElement);
            
        nodes.item(0).appendChild(autorElement);
        
        
        // smaže všechny redaktory (šéfredaktory nechá)
        for (int i = 0;i<nodes.getLength();++i)
        {
            NodeList nodesAutor = nodes.item(i).getChildNodes();
            for (int j = 0;j<nodesAutor.getLength();++j)
            {
                NodeList inAutor = nodesAutor.item(j).getChildNodes();                
                for (int k = 0;k<inAutor.getLength();++k)
                {
                if (inAutor.item(k).getNodeName().equals("pozice"))
                {
                    if (inAutor.item(k).getTextContent().equals("redaktor"))
                    {
                        nodesAutor.item(j).getParentNode().removeChild(nodesAutor.item(j));
                    }
                }
                }
            }
        }
        
    
        
    } 
}