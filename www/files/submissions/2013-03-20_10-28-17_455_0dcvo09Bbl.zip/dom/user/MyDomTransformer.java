package user;
import org.w3c.dom.Document;
public class MyDomTransformer {
public void transform (Document xmlDocument) {
        //Pridani nove prazdne kancelare
        Element kancl = xmlDocument.createElement("kancelar");
        kancl.setAttribute("id", "kan_209");
        kancl.appendChild(xmlDocument.createElement("cislo")).setTextContent("209");
        Element obyv = (Element)kancl.appendChild(xmlDocument.createElement("obyvatele"));   
        obyv.setAttribute("refs", "");
        NodeList list = xmlDocument.getElementsByTagName("kancelare");
        list.item(0).appendChild(kancl);
        
        //Odstraneni vsech zamestnancu s platem mensim, nez 50000
        NodeList platy = xmlDocument.getElementsByTagName("plat");
        for(int i=0; i < platy.getLength(); i++){
            Element p = (Element)platy.item(i);
            String plat = p.getTextContent();
            String intPlat = "";
            for(int j = 0; j < plat.length(); j++){
                if(!Character.isWhitespace(plat.charAt(j))){
                    intPlat += plat.charAt(j);
                }
            }
            if(Integer.parseInt(intPlat) < 70000){
                Element zam = (Element)p.getParentNode();
                zam.getParentNode().removeChild(zam);
            }
        }
    }
}
