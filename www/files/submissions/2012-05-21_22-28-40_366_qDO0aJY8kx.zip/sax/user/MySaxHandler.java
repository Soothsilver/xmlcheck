package user;

import java.util.HashMap;
import java.util.Map;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.*;

/*
 * autor: Marek Cech (cechmare)
 * program vypise:
 *      maximalni, minimalni a prumernou delku nazvu elementu
 *      maximalni, minimalni a prumernou delku nazvu atributu
 *      element s nejdelsim a nejkratsim nazvem
 *      atribut s nejdelsim a nejkratsim nazvem
 *      celkovy pocet elementu
 *      celkovy pocet atributu
 *      nejcastejsi element
 *      nejcastejsi atribut
 *      pokud narazi na element kniha, vypise jeho pozici (radek, sloupec)
 *      pocet znakovych dat
 */
public class MySaxHandler extends DefaultHandler {
    
    private Locator lokator;
    private int pocetZnaku = 0;
    
    private Map<String,Integer> atributy;
    private String elementMaximalniDelky = "";
    private int maxDelkaNazvuElementu = -1;
    private String elementMinimalniDelky = "";
    private int minDelkaNazvuElementu = -1;
    private int celkovaDelkaNazvuElementu = 0;
    private int pocetElementu = 0;
    
    private Map<String,Integer> elementy;
    private String atributMaximalniDelky = "";
    private int maxDelkaNazvuAtributu = -1;
    private String atributMinimalniDelky = "";
    private int minDelkaNazvuAtributu = -1;
    private int celkovaDelkaNazvuAtributu = 0;
    private int pocetAtributu = 0;

    //bezparametricky konstruktor
    public MySaxHandler() {
        try {
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
    
    /******************  OVERRIDE - FUNKCNI METODY   **************************/
    public void setDocumentLocator(Locator lokator) {
        this.lokator = lokator;
    }
    
    public void characters(char[] ch, int start, int length) {
        this.pocetZnaku += length;
    }
    
    public void showEvent(String s) {
        System.out.println("Nastala udalost: "+s);
    }
    
    //zacatek dokumentu
    public void startDocument() throws SAXException {
        atributy = new HashMap<String,Integer>();
        elementy = new HashMap<String,Integer>();
        System.out.println("*** zacalo parsovani ***\nhledam element kniha...");
    }
    
    //zacatek elementu
    public void startElement(String namespaceURI, String localName, String qName, Attributes atts) throws SAXException {
        
        if (qName.equals("kniha")) {
            System.out.println("Našel jsem element kniha na pozici:");
            System.out.println("radek "+lokator.getLineNumber()+", sloupec "+lokator.getColumnNumber());
        }
        //zpracovani informaci o elementu
        this.pocetElementu++;
        int delkaLocalName = qName.length();
        this.celkovaDelkaNazvuElementu += delkaLocalName;
        if (delkaLocalName > this.maxDelkaNazvuElementu) {
            this.maxDelkaNazvuElementu = delkaLocalName;
            this.elementMaximalniDelky = qName;
        } else if (delkaLocalName < this.minDelkaNazvuElementu || this.minDelkaNazvuElementu == -1) {
            this.minDelkaNazvuElementu = delkaLocalName;
            this.elementMinimalniDelky = qName;
        }
        
        //obsluha hashmapy elementu
        Integer pocetVyskytuElementu = elementy.get(qName);
        if (pocetVyskytuElementu==null) pocetVyskytuElementu=0;
        pocetVyskytuElementu++;
        elementy.put(qName, pocetVyskytuElementu);
        
        //zpracovani informaci o atributech + obsluha hashmapy atributu
        Integer pocetVyskytuAtributu = null;
        for(int i = 0; i < atts.getLength(); i++){
            //hashmapa
            pocetVyskytuAtributu = atributy.get(atts.getLocalName(i));
            if (pocetVyskytuAtributu==null) pocetVyskytuAtributu=0;
            pocetVyskytuAtributu++;
            atributy.put(atts.getLocalName(i), pocetVyskytuAtributu);
            
            this.pocetAtributu++;
            int delkaNazvuAtributu = atts.getLocalName(i).length();
            this.celkovaDelkaNazvuAtributu += delkaNazvuAtributu;
            
            if (delkaNazvuAtributu > this.maxDelkaNazvuAtributu) {
                this.maxDelkaNazvuAtributu = delkaNazvuAtributu;
                this.atributMaximalniDelky = atts.getLocalName(i);
            } else if (delkaNazvuAtributu < this.minDelkaNazvuAtributu || this.minDelkaNazvuAtributu == -1) {
                this.minDelkaNazvuAtributu = delkaNazvuAtributu;
                this.atributMinimalniDelky = atts.getLocalName(i);
            }
        }
    }
    
    //konec dokumentu
    public void endDocument() throws SAXException {
        System.out.println("\n*** celkove summary ***\n");
        System.out.println("Pocet znaku je: "+this.pocetZnaku+"\n");
        System.out.println("*** informace o elementech ***");
        System.out.println("Celkovy pocet elementu: "+this.pocetElementu);
        System.out.println("Element maximalni delky je: "+this.elementMaximalniDelky);
        System.out.println("Jeho delka je: "+this.elementMaximalniDelky.length());
        System.out.println("Element minimalni delky je: "+this.elementMinimalniDelky);
        System.out.println("Jeho delka je: "+this.elementMinimalniDelky.length());
        double prumernyElement = (double) celkovaDelkaNazvuElementu / (double) pocetElementu;
        System.out.println("Prumer delky nazvu elementu je: "+prumernyElement);
        
        String element ="";
        Integer pocetVyskytuElementu = 0;
        Integer maxPocetVyskytuElementu = 0;
        for (String key : elementy.keySet()){
            pocetVyskytuElementu = elementy.get(key);
            if(pocetVyskytuElementu > maxPocetVyskytuElementu){
                element = key;
                maxPocetVyskytuElementu = pocetVyskytuElementu;
            } 
        }
        System.out.println("Nejcastejsim elementem je: "+element+
                " s poctem vyskytu: "+maxPocetVyskytuElementu+"x");
        
        System.out.println("");
        
        System.out.println("*** informace o atributech ***");
        System.out.println("Celkovy pocet atributu: "+this.pocetAtributu);
        System.out.println("Atribut maximalni delky je: "+this.atributMaximalniDelky);
        System.out.println("Jeho delka je: "+this.atributMaximalniDelky.length());
        System.out.println("Atribut minimalni delky: "+this.atributMinimalniDelky);
        System.out.println("Jeho delka je: "+this.atributMinimalniDelky.length());
        double prumernyAtribut = (double) celkovaDelkaNazvuAtributu / (double) pocetAtributu;
        System.out.println("Prumer delky nazvu atributu je: "+prumernyAtribut);
        
        String atribut ="";
        Integer pocetVyskytuAtributu = 0;
        Integer maxPocetVyskytuAtributu = 0;
        for (String key : atributy.keySet()){
            pocetVyskytuAtributu = atributy.get(key);
            if(pocetVyskytuAtributu > maxPocetVyskytuAtributu){
                atribut = key;
                maxPocetVyskytuAtributu = pocetVyskytuAtributu;
            } 
        }
        System.out.println("Nejcastejsim atributem je: "+atribut+
                " s poctem vyskytu: "+maxPocetVyskytuAtributu+"x");
    }

    /******************   OVERRRIDE - LOGOVACI METODY   ***********************/
    public void error (SAXParseException e) {
        System.out.println("SAXParseException: error");
        e.printStackTrace();
    }

    public void warning (SAXParseException e) {
        System.out.println("SAXParseException: warning");
        e.printStackTrace();
    }

    public void fatalError (SAXParseException e) {
        System.out.println("SAXParseException: fatal error");
        System.exit(1);
    }
}