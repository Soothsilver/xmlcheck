package user; 

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

public class MyDomTransformer { 
    
    public void transform (Document doc) {
        Element koren = doc.getDocumentElement();
        obratPoradiElementu(koren);
        atributyNaElementy(doc);
        smazAtributy(doc);
        dodelejMinFanOutAHloubku(doc, koren, 2);
    }
    
    private static void obratPoradiElementu(Element koren) {
        NodeList potomci = koren.getChildNodes();
        for (int i=potomci.getLength()-1; i>=0; i--) {
            if (potomci.item(i) instanceof Element) {
                Element e = (Element) potomci.item(i);
                koren.appendChild(e);
                obratPoradiElementu(e);
            }
        }
    }
    
    private static void atributyNaElementy(Document doc) {
        Element e = doc.getDocumentElement();
        NodeList potomci = e.getElementsByTagName("*");
        for (int i=0; i<potomci.getLength(); i++) {
            Element actual = (Element) potomci.item(i);
            NamedNodeMap atts = actual.getAttributes();
            for (int x=0; x<atts.getLength(); x++) {
                Element tmp = doc.createElement(atts.item(x).getNodeName());
                tmp.appendChild(doc.createTextNode(atts.item(x).getNodeValue()));
                actual.appendChild(tmp);
            }
        }
    }
    
    private static void smazAtributy(Document doc) {
        Element e = doc.getDocumentElement();
        NodeList potomci = e.getElementsByTagName("*");
        for (int i=0; i<potomci.getLength(); i++) {
            Element actual = (Element) potomci.item(i);
            NamedNodeMap atts = actual.getAttributes();
            while (actual.hasAttributes()) {
                actual.removeAttribute(atts.item(0).getNodeName());
            }
        }
    }
    
    private static void dodelejMinFanOutAHloubku(Document doc, Element e, int lvl) {
        if (lvl>8) return;
        NodeList potomci = e.getChildNodes();
        Element actual = null;
        int pocetElementu = 0;
        for (int i=0; i<potomci.getLength(); i++) {
            if (!(potomci.item(i) instanceof Element)) {
                
            } else {
                actual = (Element) potomci.item(i);
                dodelejMinFanOutAHloubku(doc, actual, lvl+1);
                pocetElementu++;
            }
        }
        int dodelat = 1 - pocetElementu;
        if (dodelat > 0) {
            for (int i=0; i<dodelat; i++) {
                Element vycpavka = doc.createElement("vycpavka");
                vycpavka.appendChild(doc.createTextNode("vycpana data na urovni: "+lvl));
                e.appendChild(vycpavka);
                dodelejMinFanOutAHloubku(doc, vycpavka, lvl+1);
            }
        }
    }
}