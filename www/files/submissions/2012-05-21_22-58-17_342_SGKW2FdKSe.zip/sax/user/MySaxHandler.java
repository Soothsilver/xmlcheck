package user;

/**
 *
 * @author Martin
 */

import java.util.ArrayList;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;

public class MySaxHandler extends DefaultHandler {


    public static void main(String[] args) {

        // Cesta ke zdrojovému XML dokumentu  
        String sourcePath = "../data.xml";

        try {
            
            // Vytvoríme instanci parseru.
            XMLReader parser = XMLReaderFactory.createXMLReader();
            
            // Vytvoríme vstupní proud XML dat.
            InputSource source = new InputSource(sourcePath);
            
            // Nastavíme náą vlastní content handler pro obsluhu SAX událostí.
            parser.setContentHandler(new MujContentHandler());
            
            // Zpracujeme vstupní proud XML dat.
            parser.parse(source);
            
            
        } catch (Exception e) {
        
            e.printStackTrace();
            
        }
        
    }
    
}
/**
 * Náš vlastní content handler pro obsluhu SAX událostí.
 * Implementuje metody interface ContentHandler. 
 */ 
class MujContentHandler implements ContentHandler {
    //Budu pocitat pocet elementu v XML dokumentu a prumernou a maximalni delku nazvu elementu.
    int pocetElementu = 0;    
    ArrayList<String> elementy;    
    
    /**
     * Nastaví locator
     */     
    public void setDocumentLocator(Locator locator) {
        
    }

    /**
     * Obsluha události "začátek dokumentu"
     */     
    public void startDocument() throws SAXException {
        elementy = new ArrayList<String>();        
        
    }
    /**
     * Obsluha události "konec dokumentu"
     */     
    public void endDocument() throws SAXException {
        
        
        int maximalniDelkaNazvu = 0;
        String celkovaDelka = "";
        String nazev;
        String maxElement = "";
        
        for (int i = 0; i < elementy.size(); i++) {
            nazev = elementy.get(i);
            celkovaDelka += nazev;
            if(nazev.length() > maximalniDelkaNazvu){
                maximalniDelkaNazvu = nazev.length();
                maxElement = nazev;
            }
        }        
        double prumernaDelkaNazvu = (double) celkovaDelka.length()/(double) pocetElementu;
        
        System.out.println("Celkovy pocet elementu je: " + pocetElementu + ".");
        System.out.println("Prumerna delka nazvu elementu je: " + prumernaDelkaNazvu + " znaku.");
        System.out.println("Maximalni delka nazvu elementu je: " + maximalniDelkaNazvu + " znaku. A tento element se jmenuje " + maxElement + ".");
       
        
    }
    
    /**
     * Obsluha události "začátek elementu".
     * @param uri URI jmenného prostoru elementu (prázdné, pokud element není v žádném jmenném prostoru)
     * @param localName Lokální jméno elementu (vždy neprázdné)
     * @param qName Kvalifikované jméno (tj. prefix-uri + ':' + localName, pokud je element v nějakém jmenném prostoru, nebo localName, pokud element není v žádném jmenném prostoru)
     * @param atts Atributy elementu     
     */     
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        
        pocetElementu++;        
        elementy.add(localName);
    }
    /**
     * Obsluha události "konec elementu"
     * Parametry mají stejný význam jako u @see startElement     
     */     
    public void endElement(String uri, String localName, String qName) throws SAXException {
        
        // ...

    }
    
    /**
     * Obsluha události "znaková data".
     * SAX parser muľe znaková data dávkovat jak chce. Nelze tedy počítat s tím, že je celý text dorucen v rámci jednoho volání.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakovými daty
     * @param start Index zacátku úseku platných znakových dat v poli.
     * @param length Délka úseku platných znakových dat v poli.
     */               
    public void characters(char[] ch, int start, int length) throws SAXException {

        // ...
        
    }
    
    /**
     * Obsluha události "deklarace jmenného prostoru".
     * @param prefix Prefix prirazený jmennému prostoru.
     * @param uri URI jmenného prostoru.
     */     
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha události "konec platnosti deklarace jmenného prostoru".
     */     
    public void endPrefixMapping(String prefix) throws SAXException {
    
        // ...
    
    }

    /**
     * Obsluha události "ignorované bílé znaky".
     * Stejné chování a parametry jako @see characters     
     */     
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha události "instrukce pro zpracování".
     */         
    public void processingInstruction(String target, String data) throws SAXException {
      
      // ...
            
    }

    /**
     * Obsluha události "nezpracovaná entita"
     */         
    public void skippedEntity(String name) throws SAXException {
    
      // ...
    
    }
}