

 /*
 * ----------------------------------------------------------
 * | NA RADKU 82 je komentar k chybe vychozene v XML Checku |
 * ----------------------------------------------------------
 */

package user;

/**
 *
 * @author Martin
 */
import java.io.File;

import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

/**
 * ZADANI:
 * Upravte program tak, aby transformoval vstupnĂ­ XML dokument na vĂ˝stupnĂ­ pomocĂ­ akcĂ­
 * uvedenĂ˝ch v komentĂˇĹ™Ă­ch metody processTree(doc).
 */
public class MyDomTransformer{
    private static Document doc;

    private static final String VSTUPNI_SOUBOR = "../data.xml";
    private static final String VYSTUPNI_SOUBOR = "../transformovanaData.xml";

    public static void main(String[] args) {
        
        try {
            
            //DocumentBuilderFactory vytvĂˇĹ™Ă­ DOM parsery
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            //nebudeme validovat
            dbf.setValidating(false);

            //vytvoĹ™Ă­me si DOM parser
            DocumentBuilder builder = dbf.newDocumentBuilder();

            //parser zpracuje vstupnĂ­ soubor a vytvoĹ™Ă­ z nÄ›j strom DOM objektĹŻ
            doc = builder.parse(VSTUPNI_SOUBOR);

            //zpracujeme DOM strom
            transform(doc);

            //TransformerFactory vytvĂˇĹ™Ă­ serializĂˇtory DOM stromĹŻ
            TransformerFactory tf = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer = tf.newTransformer();

            //nastavĂ­me kodovĂˇnĂ­
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spustĂ­me transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


        } catch (Exception e) {
            
            e.printStackTrace();
            
        }
    }

    /**
     * Zpracuje DOM strom
     */
    public static void transform(Document doc) {
    //!!!!!!!!!!!!!!!!!!!!!!!!!!DOM v XML checku mi vyhodi chybu(NullPointer na radku 118). Je to asi kvuli tomu, ze
    //se tam vola metoda transform, tudiz se do promene doc neulozi naparsovany VSTUPNI_SOUBOR, tudiz je to NullPointer. 
    //V NetBeans ale chodi bez problemu. 
        
    //Cil:   
    //Prevedu vsechny atributy na textove elementy a pripojim je k danemu uzlu. Pokud bych chtel napriklad vytahnout 
    //vsechny informace z dokumentu, muzu prochazet jen elementy a ukladat si jejich hodnoty. Atributy uz nemusim hlidat.   
        Node root = doc.getFirstChild();
        prochazeniStromu(root);
    }
    
    public static void prochazeniStromu(Node n){
        //beru si vsechny potomky daneho Nodu.
        NodeList potomci = n.getChildNodes(); 
        Node ukladaci;
        
        //NodeList potomku budu postupne prochazet, a zjistovat, zda maji potomci nejake atributy.
        for (int i = 0; i < potomci.getLength(); i++) {
            ukladaci = potomci.item(i);
            
        //Pokud ma potomek nejake atributy, ulozim si je do NamedNodeMap.    
            if(ukladaci.hasAttributes()){                
                String nazevAtributu = "";
                String hodnotaAtributu = "";
                NamedNodeMap atributy = ukladaci.getAttributes();                
                Element a = (Element) ukladaci;
                
        //Projdu cely NamedNodeMap a ukladam si jmena atributu Nodu ukladaci a vytvarim elementy
        //se stejnymy jmeny a hodnotami, jako meli atributy. Tyto elementy nasledne pripojim jako 
        //deti k aktualnimu Nodu ukladaci.        
                ArrayList<String> nazvy = new ArrayList<String>();
                for (int j = 0; j < atributy.getLength(); j++) {
                    nazevAtributu = atributy.item(j).getNodeName();                   
                    hodnotaAtributu = atributy.item(j).getNodeValue();                   
                    nazvy.add(nazevAtributu);
                    
                    Element novyElement = doc.createElement(nazevAtributu);
                    
                    Node q = doc.createTextNode(hodnotaAtributu);                                        
                    novyElement.appendChild(q);
                            
                    novyElement.setNodeValue(hodnotaAtributu);
                    ukladaci.appendChild(novyElement);                 
                }
            
        //Pote vsechny atributy Nodu ukladaci vymazu.      
                for (int j = 0; j < nazvy.size(); j++) {
                    a.removeAttribute(nazvy.get(j));                    
                }
            }
        //Rekurzivne zavolam metodu prochazeniStromu na Node ukladaci, ktera vymaze atributy i z jeho potomku.     
            prochazeniStromu(ukladaci);                        
        }
        return;
    }
}


