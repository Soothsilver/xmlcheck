package user;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer {
	public void transform(Document xmlDocument) {
		addHotel(xmlDocument);
		removeExpensiveTermins(xmlDocument);
	}

	private void removeExpensiveTermins(Document doc) {

		Element rootNode = doc.getDocumentElement();

		/*
		 * Chceme smazat vsechny terminy, ktere jsou drazsi nez 13000.
		 */

		// and for extra safety - ifs and fors and ifs and fors ... etc. ...
		// This code is not for eyes of Ing. Bulej, Ph.D. :)
		List<Node> ckNodes = getChildren(rootNode, "ck");
		for (Node ckNode : ckNodes) {
			Node descriptions = getChild(ckNode, "descriptions");
			if (descriptions != null) {
				for (Node countryNode : getChildren(descriptions, "country")) {
					for (Node descinationNode : getChildren(countryNode, "destination")) {
						for (Node placeNode : getChildren(descinationNode, "place")) {
							for (Node hotelNode : getChildren(placeNode, "hotel")) {
								Node termGroups = getChild(hotelNode, "term_groups");
								if (termGroups != null) {
									for (Node termGroupNode : getChildren(termGroups, "term_group")) {
										for (Node terminNode : getChildren(termGroupNode, "term")) {
											// :) THE END OF HELL FOR-CYCLE
											// ... UFF
											// ....
											// ....
											// ....
											// GOD, PLEASE, GIVE ME XPATH :)
											String cenaStr = terminNode.getAttributes().getNamedItem("price_per_person").getNodeValue();
											// ok, vim ze dena do double
											// neni dobry napad, ale kdyz je
											// to jen ukol...
											if (Double.parseDouble(cenaStr) >= 13000) {
												termGroupNode.removeChild(terminNode);
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}

	private void addHotel(Document doc) {
		Element rootNode = doc.getDocumentElement();
		/*
		 * Chceme prezentovat zajezdy do noveho hotelu Krakonos ve Spindlerove
		 * mlyne v Cechach v Ceske republice.
		 * 
		 * Bohuzel, zadny hotel v CR jeste nemame, tak muzime
		 * stat/mistecko/destinaci/hotel pridat a teprve k nemu pridat nove
		 * zajezdy. Zajezd ale porada jiz existujici cestovni kancelar, takze
		 * nemusime resit pridani cestovni kancelare.
		 */

		Node ckNode = getChild(rootNode, "ck", "ck_id", "n123");
		// take bych mohl pouzit metodu
		// getFirstChildWithNameAndAttributes(rootNode, "ck", "ck_id",
		// "n123");
		Node descriptionsNode = getChild(ckNode, "descriptions");

		Node countryNode = descriptionsNode.appendChild(createElement(doc, "country", "country_id", "d34", "name", "Ceska Republika"));
		Node destinationNode = countryNode.appendChild(createElement(doc, "destination", "destination_id", "d741", "name", "Cechy"));
		Node placeNode = destinationNode.appendChild(createElement(doc, "place", "destination_id", "d3251", "name", "Spindleruv Mlyn"));
		Node hotelNode = placeNode.appendChild(createElement(doc, "hotel", "destination_id", "d8744", "name", "Krakonos"));
		hotelNode.setTextContent("Krasny hotel v prostredi Krkonos s kapacitou pro 120 hostu.");

		Node locNode = hotelNode.appendChild(createElement(doc, "loc"));
		Node latNode = locNode.appendChild(createElement(doc, "lat"));
		latNode.setTextContent("7.548874");
		Node lonNode = locNode.appendChild(createElement(doc, "lon"));
		lonNode.setTextContent("2.548874");

		Node termGroupsNode = hotelNode.appendChild(createElement(doc, "term_groups"));
		Node termGroup1Node = termGroupsNode.appendChild(createElement(doc, "term_group", "gid", "g3", "date_from", "2013-08-01", "date_to", "2013-08-15",
				"transfer", "own"));

		termGroup1Node.appendChild(createElement(doc, "term", "tid", "t5468784115", "room", "2+0", "price_per_person", "7958.00", "food", "AI"));
		termGroup1Node.appendChild(createElement(doc, "term", "tid", "t5468784116", "room", "3+0", "price_per_person", "6958.00", "food", "AI"));
	}

	public Node getChild(Node parent, String nodeName, String... attributes) throws IllegalArgumentException {
		List<Node> children = getChildren(parent, nodeName, attributes);
		return children.isEmpty() ? null : children.iterator().next();
	}

	private Map<String, String> createAttributeMap(String[] attributes) throws IllegalArgumentException {
		Map<String, String> attributeMap = new HashMap<String, String>();
		String key = null;
		for (int pos = 0; pos < attributes.length; pos++) {
			if (pos % 2 == 0) {
				key = attributes[pos];
			} else {
				attributeMap.put(key, attributes[pos]);
			}
		}
		return attributeMap;
	}

	public List<Node> getChildren(Node parent, String name, String... attributes) {
		Map<String, String> attributeMap = createAttributeMap(attributes);
		List<Node> childrenWithName = new ArrayList<Node>();

		NodeList childNodes = parent.getChildNodes();
		for (int i = 0; i < childNodes.getLength(); i++) {
			Node child = childNodes.item(i);
			if (child.getNodeName().equals(name)) {
				NamedNodeMap nodeAttributes = child.getAttributes();
				boolean canBeAdded = true;
				for (Entry<String, String> entry : attributeMap.entrySet()) {
					String key = entry.getKey();
					String value = entry.getValue();
					Node attribute = nodeAttributes.getNamedItem(key);
					if (attribute != null) {
						if (!attribute.getTextContent().equals(value)) {
							canBeAdded = false;
						}
					}
				}
				if (canBeAdded) {
					childrenWithName.add(child);
				}

			}
		}
		return childrenWithName;
	}

	public Element createElement(Document doc, String elementName, String... attributes) throws IllegalArgumentException {
		Element element = doc.createElement(elementName);

		Map<String, String> attributeMap = createAttributeMap(attributes);
		for (Entry<String, String> entry : attributeMap.entrySet()) {
			element.setAttribute(entry.getKey(), entry.getValue());
		}

		return element;
	}
}