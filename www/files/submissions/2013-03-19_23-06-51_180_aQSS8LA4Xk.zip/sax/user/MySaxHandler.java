package user;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Stack;

import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {

	//
	//
	// HODNOTY K DOMACIMU UKOLU
	//
	//

	// 1. vztah k attributum
	// ZDE BUDE PO DOBEHNUTI PRUMERNA CENA ZAJEZDU
	public double avgPrice;

	// 2. vztah k obsahu elementu
	// ZDE BUDOU PO DOBEHNUTI MAPA SE SEZNAMEM KRESTNICH JMEN
	// A POCTEM JEJYCH VYSKYTU (tj. key = jmeno, value = # vyskytu)
	// ucely dostatecne znasilnen)
	//
	// v zadani je priklad "napr tri nejcastejsi jmena" .. myslim, ze to jiz
	// neni v tomto pripade nutne - kazdy si muze mapu sesortit a vzit si jmen
	// kolik chce
	public Map<String, Integer> names = new HashMap<String, Integer>();

	// 3. a vztah ke kontextu
	// pocet terminu ktere jsou drazsi nez 13 000, a ktere jsou maji latitude >
	// 80 a < 100 (pokud ji maji)
	public int expensiveTerms = 0;

	//
	//
	// POMOCNE STRUKTURY A PROMENNE
	//
	//

	private List<String> prices = new ArrayList<String>();
	// jasne, stack v nasem pripade asi neni potreba, ale co kdyz bych mel vice
	// elementu se stejnym nazvem? pak uz se mi stack hodi, protoze v kazdem
	// okamziku znam plnou cestu k elementum, ve kterem se prave vyskytuji.
	public Stack<String> elementNameStack = new Stack<String>();
	// buffer tu musi byt - ukazky zverejnene na strankach jsou chybne :(.
	// Buffer tu musi byt, protoze mi nic nezarucuje, ze metoda characters(...)
	// se mi pri dlouhem textu neusekne treba v polovine tohoto textu a teprve
	// az v nasledujicim volani characters bude druha polovina tohoto textu.
	// Obe ukazky dom. ukolu jsou tedy spatne.
	public StringBuffer elementContentBuffer = new StringBuffer();

	public Double actualLatitude;
	// musime si terminPrices ukladat a pocet predrazenych terminu kontrolovat
	// az po vystupu z elementu hotel, protoze nemame jistotu, v jakem poradi v
	// elementu hotel jsou jeho podelementy loc a term_groups
	public List<String> actualHotelPrices = new ArrayList<String>();

	//
	//
	//
	//
	//

	// Helper variable to store location of the handled event
	Locator locator;

	public void setDocumentLocator(Locator locator) {
		this.locator = locator;
	}

	public void endDocument() throws SAXException {
		double sum = 0;
		for (String priceStr : prices) {
			sum += Double.parseDouble(priceStr);
		}
		avgPrice = sum / new Double(prices.size());

		System.out.println("prumerna cena zajezdu je : " + avgPrice);
		System.out.println("pocet terminu ktere jsou drazsi nez 13 000, a ktere jsou maji latitude > 80 a < 100 (pokud ji maji): " + expensiveTerms);
		System.out.println("cetnost vsech krestnich jmen :");
		for (Entry<String, Integer> kvp : names.entrySet()) {
			System.out.println(String.format("    %s : %d", kvp.getKey(), kvp.getValue()));
		}
	}

	public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
		elementNameStack.push(localName);
		if (localName.equals("term")) {
			prices.add(atts.getValue("price_per_person"));
			actualHotelPrices.add(atts.getValue("price_per_person"));
		}
	}

	public void endElement(String uri, String localName, String qName) throws SAXException {
		if (localName.equals("person_name")) {
			String personName = elementContentBuffer.toString().split(" ")[0];
			if (!names.containsKey(personName)) {
				names.put(personName, 0);
			}
			names.put(personName, names.get(personName) + 1);
		} else if (localName.equals("lat")) {
			actualLatitude = Double.parseDouble(elementContentBuffer.toString());
		} else if (localName.equals("hotel")) {
			if (actualLatitude != null) {
				if (actualLatitude > 80d && actualLatitude < 100d) {
					for (String priceStr : actualHotelPrices) {
						Double price = Double.parseDouble(priceStr);
						if (price > 13000d) {
							expensiveTerms++;
						}
					}
				}
			}
			actualLatitude = null;
			actualHotelPrices.clear();
		}
		elementContentBuffer = new StringBuffer();
		elementNameStack.pop();
	}

	public void characters(char[] chars, int start, int length) throws SAXException {
		elementContentBuffer.append(new String(chars, start, length));
	}

}
