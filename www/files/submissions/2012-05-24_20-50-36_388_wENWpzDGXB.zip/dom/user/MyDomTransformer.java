// U elementů, kde to dává smysl (viz elementsToTransform),
// změní atributy na elementy s textovým obsahem.

package user;

import org.w3c.dom.*;

public class MyDomTransformer
{
  String[] elementsToTranform = { "correct-title", "start-date", "section" };

  public void transform(Document xmlDocument)
  {
    for (String elementName : elementsToTranform)
    {
      NodeList nodeList = xmlDocument.getElementsByTagName(elementName);
      for (int i = 0; i < nodeList.getLength(); i++)
      {
        Element parent = (Element)nodeList.item(i);
        NamedNodeMap attributes = parent.getAttributes();

        // odzadu, protože attributy v průběhu iterace odebírám
        for (int j = attributes.getLength() - 1; j >= 0; j--)
        {
          Attr childAttr = (Attr)attributes.item(j);
          Element childElem = xmlDocument.createElement(childAttr.getName());
          childElem.insertBefore(xmlDocument.createTextNode(childAttr.getNodeValue()), null);
          parent.insertBefore(childElem, parent.getFirstChild());
          parent.removeAttribute(childAttr.getName());
        }
      }
    }
  }
}
