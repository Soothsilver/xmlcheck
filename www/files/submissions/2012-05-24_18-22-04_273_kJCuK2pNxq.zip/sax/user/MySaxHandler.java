package user;

import java.util.HashMap;
import java.util.Map;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * @author Jiří Vytasil
 */
public class MySaxHandler extends DefaultHandler {
    
    
    HashMap<String, Integer> skolitele = new HashMap<String, Integer>();
    String skolitel;

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        
        if (localName.equals("student")) {
            //najdu-li element student, tak si zapamatuju jeho skolitele
            for (int i = 0; i < attributes.getLength(); i++) {
                if (attributes.getLocalName(i).equals("skolitel")) {
                    skolitel = attributes.getValue(i);
                    if (!skolitele.containsKey(skolitel)) {
                        skolitele.put(skolitel, 0);
                    }
                }
            }
        }
        
        if (localName.equals("delka")) {
            //narazim-li na element delka, ktera je u jizdy
            //tak zvysim (nastavim) hodnotu v HashMap
            for (int i = 0; i < attributes.getLength(); i++) {
                if (attributes.getLocalName(i).equals("hodin")) {
                    //nasel jsem atribut hodin
                    int val = skolitele.remove(skolitel);
                    //zjistim si prozatimni cas straveny se studenty
                    
                    val += Integer.parseInt(attributes.getValue(i));
                    skolitele.put(skolitel, val);
                    //pridame skolitele do HashMap
                }
            }
        }
    }

    @Override
    public void endDocument() throws SAXException {
        //na konci dokumentu vypiseme skolitele s jejich casem stravenem se studenty na jizdach
        System.out.println("<pocet_hodin>");
        for (Map.Entry<String, Integer> entry : skolitele.entrySet()) {
            String string = entry.getKey();
            Integer integer = entry.getValue();
            System.out.println("\t<skolici login=\"" + string + "\">\n\t\t" + "<celkova_delka>" + integer + "</celkova_delka>\n\t</skolici>");
        }
        System.out.println("</pocet_hodin>");
    }
}
