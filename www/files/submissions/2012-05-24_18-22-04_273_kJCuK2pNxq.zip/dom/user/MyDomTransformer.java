package user;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author Jiří Vytasil
 */
public class MyDomTransformer {
	//cilem je smazat ty studenty, kteri prekrocili urcity pocet hodin na jizdach

    public void transform(Document xmlDocument) {
        NodeList jizdy = xmlDocument.getElementsByTagName("jizdy");
        //najdeme vsechny elementy jizdy (tyto elementy obsahuji jednotlive jizdy

        int i = jizdy.getLength() - 1;
        //index posledniho prvku z jizd

        while (i >= 0) {
            //jdeme odshora kvuli mazani, kdybychom smazali napr. prvni prvek, tak se indexy posunou

            Node akt = jizdy.item(i);
            //ulozime si aktualni node

            NodeList synove = akt.getChildNodes();
            //synove aktualniho nodu

            int pocet = 0;
            //udava pocet hodin stravenych jizdami

            for (int j = 0; j < synove.getLength(); j++) {
                Node syn = synove.item(j);
                //syn aktualni jizdy
                if (syn.getNodeName().equals("jednotliva_jizda")) {
                    Node delka = syn.getLastChild().getPreviousSibling();
                    //getLastChild nevraci posledni prvek v elementu jednotliva jizda, coz je delka, ale jinou hodnotu

                    Node hodin = delka.getAttributes().getNamedItem("hodin");
                    //vezmu atribut, ktery udava delku jizdy (1, nebo 2 hodiny)

                    pocet += Integer.parseInt(hodin.getTextContent());
                    //prictu pocet hodin k jiz provedenym
                }
            }

            if (pocet > 10) {
                //pocet hodin presahl urcitou mez

                Node rodic = akt.getParentNode();
                //ulozime si rodice aktualniho prvku, coz je student

                rodic.getParentNode().removeChild(rodic);
                //smazeme naseho studenta
            }
            i--;
        }
    }
}
