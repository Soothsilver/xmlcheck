package user;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;


public class MyDomTransformer {
       
    /*
     * Two examples:
     * 1. Add athlete
     * 2. Remove athlete who is younger than 28
     */
    
    public void transform (Document xmlDocument) {
        
       //***********************Removes athlete younger than 28 from xmlDocument****
        
       this.removeAthleteOlderYoungerThan28(xmlDocument);
       
       //***********************Adds athlete to xmlDocument*************************
       
       this.addAthlete(xmlDocument);
} 
    private void addAthlete(Document xmlDocument){
        Element _100metresLondon2012 = (Element) xmlDocument.getElementById("d_1");
        Element sportsman = xmlDocument.createElement("Sportsman");
        sportsman.setAttribute("id", "s_3");
        Element record = xmlDocument.createElement("Record");
        record.setAttribute("ranking", "2");
        record.setAttribute("score", "9.75");
        Element firstname = xmlDocument.createElement("Firstname");
        firstname.setTextContent("Yohan");
        Element surname = xmlDocument.createElement("Surname");
        surname.setTextContent("Blake");
        Element age = xmlDocument.createElement("Age");
        age.setTextContent("24");
        Element nationality = xmlDocument.createElement("Nationality");
        nationality.setTextContent("Jamaican");
        Element placeOfBirth = xmlDocument.createElement("PlaceOfBirth");
        placeOfBirth.setTextContent("St.James");
        Element height = xmlDocument.createElement("Height");
        height.setTextContent("180");
        Element weight = xmlDocument.createElement("Weight");
        weight.setTextContent("76");
        Element sponsor = xmlDocument.createElement("Sponsor");
        sponsor.setAttribute("name", "Adidas");
        Element stuff = xmlDocument.createElement("Stuff");
        stuff.setTextContent("Shoes");
        Element motto = xmlDocument.createElement("Motto");
        motto.setTextContent("When you guys are sleeping at night, I am out there working.");
        sponsor.appendChild(stuff);
        sportsman.appendChild(record);
        sportsman.appendChild(firstname);
        sportsman.appendChild(surname);
        sportsman.appendChild(age);
        sportsman.appendChild(nationality);
        sportsman.appendChild(placeOfBirth);
        sportsman.appendChild(height);
        sportsman.appendChild(weight);
        sportsman.appendChild(sponsor).appendChild(stuff);
        sportsman.appendChild(motto);
        _100metresLondon2012.appendChild(sportsman);
    }
    private void removeAthleteOlderYoungerThan28(Document xmlDocument){
        
        //************************Get all Ages elements*****************************
        
        NodeList ages = xmlDocument.getElementsByTagName("Age");
        for(int i = 0; i < ages.getLength();i++){
            
        //*************************Parse age value form text content****************
            
        int age = Integer.parseInt(ages.item(i).getTextContent());
        if(age <= 27){
            
        //*************************Remove target athlete from parent element********
            
        Element athlete = (Element) ages.item(i).getParentNode();
        Element discipline = (Element) athlete.getParentNode();
        discipline.removeChild(athlete);
        }
    }
    }
}
