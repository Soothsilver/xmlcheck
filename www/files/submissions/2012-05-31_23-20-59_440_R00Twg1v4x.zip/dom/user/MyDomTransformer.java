package user;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import java.util.LinkedList;
import org.w3c.dom.*;

public class MyDomTransformer {

    public void transform(Document doc) {
        
    	// pro kazdy machine pod registeredMachines najit hwTypeConfiguration a jeho elementy zaradit pod machine misto elementu hwType.
    	// soucasne z daneho hwType najit image a jeho elementy dat misto image elementu v hwTypeConfiguration
    	
    	// projdi vsechny machine
    	LinkedList<String> processedHwTypes = new LinkedList<String>();
    	NodeList machines = doc.getElementsByTagName("machine");
    	try {
            for(int i = 0; i < machines.getLength(); i++) {
            	Node machine = machines.item(i);
            	String machineName = machine.getAttributes().getNamedItem("dnsName").getNodeValue();
            	// najdi hwType pro danou machine
            	String hwType = "";
            	Node hwTypeNode = null;
            	NodeList children = machine.getChildNodes();
            	for(int n = 0; n < children.getLength(); n++){
            		Node tmp = children.item(n);
            		if(tmp.getNodeName() != null && tmp.getNodeName().equals("hwType")){
            			hwType = tmp.getTextContent();
            			hwTypeNode = tmp;
            			break;
            		}
            	}
            	if (hwType.equals("")) {
            		// skip elements without hwType
            		continue;
            	}
            	System.out.printf("Found HWType: %s\n", hwType);
            	// najdi hwTypeConfiguration pro dany hwType
            	NodeList hwTypeConfigurations = doc.getElementsByTagName("hwTypeConfiguration");
            	Node hwTypeConfig = null;
            	for(int n=0; n < hwTypeConfigurations.getLength(); n++){
            		Node tmp = hwTypeConfigurations.item(n);
            		if(tmp.getAttributes().getNamedItem("hwType").getNodeValue().equals(hwType)){
            			hwTypeConfig = tmp;
            			break;
            		}
            	}
            	if (hwTypeConfig == null) {
            		// ignore given machine, no hwtype found
            		continue;
            	}
            	System.out.printf("Found hwTypeConfiguration for %s\n", hwType);
            	if(processedHwTypes.contains(hwType)) {
            		System.out.print("hwType already processed, skipping to machine processing");
            	}
            	else {
	            	// najdi image name z image elementu z hwType
	            	String image = "";
	            	Node imageElement = null;
	            	children = hwTypeConfig.getChildNodes();
	            	for(int n = 0; n < children.getLength(); n++){
	            		Node tmp = children.item(n); 
	            		if(tmp.getNodeName() != null && tmp.getNodeName().equals("image")){
	            			imageElement = children.item(n);
	            			image = imageElement.getTextContent();
	            			break;
	            		}
	            	}
	            	System.out.printf("Found image name %s\n", image);
	            	// najdi image config
	            	NodeList images = doc.getElementsByTagName("image");
	            	Node imageConfig = null;
	            	for(int n=0; n < images.getLength(); n++){
	            		NamedNodeMap tmp = images.item(n).getAttributes();
	            		if(tmp.getNamedItem("name") != null && tmp.getNamedItem("name").getNodeValue().equals(image)){
	            			imageConfig = images.item(n);
	            			break;
	            		}
	            	}
	            	// mame vse, ted nahrad image element v hwTypeConfig detmi imageConfig, jestli jsme image nasli
	            	if (imageConfig != null) {
	            		System.out.printf("Found image config for image %s\n", image);
	            		hwTypeConfig.replaceChild(imageConfig.cloneNode(true), imageElement);
	            	}
            	}
            	// ted vse z hwTypeConfig dej misto hwType elementu v machine
            	machine.replaceChild(hwTypeConfig.cloneNode(true), hwTypeNode);
            	processedHwTypes.add(hwType);
            	System.out.printf("Machine %s processed\n", machineName);
            }
        	// na zaver smaz globalni data
            Node globals = doc.getElementsByTagName("objectContainer").item(0); // muze byt jenom jeden
        	globals.getParentNode().removeChild(globals);
    	}
    	catch (Exception e) {
    		e.printStackTrace();
    	}
    }
}
