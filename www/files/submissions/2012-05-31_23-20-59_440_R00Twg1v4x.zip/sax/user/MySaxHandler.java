package user;

/*
 * Spocitat 1) vysledek hostpodareni a 2) statistiku vyuziti
 * 
 * Hospodareni = sum pres vsechny klienty( cena klienta ) - sum pres servery( cena serveru + sum pres klienty(naklady na klienta))
 * 	cena klienta = cena za nainstalovany system/deployed system = je uvedena v image config
 *  cena serveru = uvedena v server config
 *  naklady klienta = uvedena v hw config
 * 
 * Statistika  = nejoblibenejsi a nejmene oblibeny system, nejoblibenejsi a nejmene oblibeny server
 * */
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

// extra modules
import java.util.HashMap;
import java.util.Iterator;

class MySaxHandler extends DefaultHandler {
	
	// My Vars
		// Accountant info
	private HashMap<String, Integer> clientPrice = new HashMap<String, Integer>();
	private HashMap<String, Integer> clientExpense = new HashMap<String, Integer>();
	private HashMap<String, Integer> serverExpense = new HashMap<String, Integer>();
	private Integer totalIncome = 0;
	private Integer totalExpense = 0;
		// Statistics
	private HashMap<String, Integer> serverRating = new HashMap<String, Integer>();
	private HashMap<String, Integer> imageRating = new HashMap<String, Integer>();
	private HashMap<String, String> hwImageMap = new HashMap<String, String>();
		// state data
	private String charData;
	private String openedElement = "";
	private String serverElement = "";
	private enum acceptedElement {
		image, hwTypeConfiguration, server, machine, none
	};
	private acceptedElement elementState = acceptedElement.none;
	
    Locator locator;

    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    public void startDocument() throws SAXException {
        
        // nothing to do, init v class
        
    }

    public void endDocument() throws SAXException {
        
        // print data
    	System.out.printf("Vysledek hospodareni:\nZisk z klientu: %d\nNaklady na provoz: %d\nZisk celkem: %d\n", totalIncome, totalExpense, totalIncome - totalExpense);
    	String imageMax = "", imageMin = "";
    	Integer max = 0, min = 1;
    	Iterator<String> it = imageRating.keySet().iterator();
    	while (it.hasNext()){
    		String key = it.next();
    		Integer value = imageRating.get(key);
    		if (min > max) {
    			// usable only on init
    			min = value;
    			imageMin = key;
    		}
    		if (max < value) {
    			max = value;
    			imageMax = key;
    		}
    		else if (min > value) {
    			min = value;
    			imageMin = key;
    		}
    	}
    	String serverMax = "", serverMin = "";
    	max = 0; min = 1;
    	it = serverRating.keySet().iterator();
    	while (it.hasNext()){
    		String key = it.next();
    		Integer value = serverRating.get(key);
    		if (min > max) {
    			// usable only on init
    			min = value;
    			serverMin = key;
    		}
    		if (max < value) {
    			max = value;
    			serverMax = key;
    		}
    		else if (min > value) {
    			min = value;
    			serverMin = key;
    		}
    	}
    	System.out.printf("Statistika provozu:\nNejoblibenejsi server: %s\nNejoblibenejsi image: %s\nNejneoblibenejsi server %s\nNejneoblibenejsi image: %s", serverMax, imageMax, serverMin, imageMin);
    }
    

    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
    	// always clear charData
  		charData = "";
    	if(localName.equals("image") && elementState == acceptedElement.none){
    		elementState = acceptedElement.image;
    		openedElement = atts.getValue("name");
    	}
    	else if(localName.equals("hwTypeConfiguration")){
    		elementState = acceptedElement.hwTypeConfiguration;
    		openedElement = atts.getValue("hwType");
    	}
    	else if(localName.equals("server")){
    		elementState = acceptedElement.server;
    		serverElement = atts.getValue("name");
    	}
    	else if(localName.equals("machine")){
    		elementState = acceptedElement.machine;
    	}
    	else if(localName.equals("hwType")){
    		charData = "";
    	}
    	//else nothing
    }
     
    public void endElement(String uri, String localName, String qName) throws SAXException {
    	if(localName.equals("image") && elementState == acceptedElement.image){
    		elementState = acceptedElement.none;
    	}
    	else if(localName.equals("image") && elementState == acceptedElement.hwTypeConfiguration){
    		// map image to hwtype
    		hwImageMap.put(openedElement, charData);
    	}
    	else if(localName.equals("hwTypeConfiguration")){
    		elementState = acceptedElement.none;
    	}
    	else if(localName.equals("server")){
    		// update total expense
    		totalExpense += serverExpense.get(serverElement);
    		elementState = acceptedElement.none;
    	}
    	else if(localName.equals("hwType") && elementState == acceptedElement.machine){
    		// this store proper openedElement for machine elements
    		openedElement = charData;
    	}
    	else if(localName.equals("machine")){
    		// add machine to server stats
    		Integer x = serverRating.get(serverElement); 
    		if(x == null){
    			x = 1;
    		}
    		else {
    			x += 1;
    		}
    		serverRating.put(serverElement, x);
    		// add image rating
     		String image = hwImageMap.get(openedElement);
    		if (image != null){
    			x = imageRating.get(image);
        		if(x == null){
        			x = 1;
        		}
        		else {
        			x += 1;
        		}
        		imageRating.put(image, x);
    		}
    		// update income
    		totalIncome += clientPrice.get(image);
    		// update expense
    		totalExpense += clientExpense.get(openedElement);
    		// machine elements are always under server
    		elementState = acceptedElement.server;
    	}
    	else if(localName.equals("price")) {
    		// Load prices - if conversion fails, assume free
			Integer x;
			try {
				x = Integer.decode(charData);
			}
			catch (NumberFormatException e){
				x = 0;
			}
    		if (elementState == acceptedElement.image) {
				clientPrice.put(openedElement, x);
    		}
    		else if (elementState == acceptedElement.hwTypeConfiguration) {
    			clientExpense.put(openedElement, x);
    		}
    		else if (elementState == acceptedElement.server) {
    			serverExpense.put(serverElement, x);
    		}
    	}
    }
    public void characters(char[] ch, int start, int length) throws SAXException {
        // append ch to buffer when accepting
    	charData += String.copyValueOf(ch, start, length);
    }
    
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
        // nothing to do here
        
    }

    public void endPrefixMapping(String prefix) throws SAXException {
    
        // nothing to do here
    
    }

    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
        // ignore
        
    }

    public void processingInstruction(String target, String data) throws SAXException {
      
      // ignore
            
    }

    public void skippedEntity(String name) throws SAXException {
    
      // ignore
    
    }
}
