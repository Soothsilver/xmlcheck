package user;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
public class MyDomTransformer {
  public void transform (Document xmlDocument) {
    // libovolne transformace objektu 'xmlDocument'
    // (metoda pracuje primo na objektu, nic nevraci)
    
    // přidej jednu partii do BC card cupu 2011
    Element e=xmlDocument.createElement("partie");
    e.setAttribute("id", getFreeId(xmlDocument,"partie","p"));
    e.setAttribute("cerny", "h2"); // najít ze jména
    e.setAttribute("bily","h5");
    
    addChildWithContent(e,"cerny","Gu Li");
    addChildWithContent(e,"bily","Lee Sedol");
    addChildWithContent(e,"datum","20110427");
    addChildWithContent(e,"vysledek","C");
    addChildWithContent(e,"rozdil","R");
    
    NodeList tourneys=xmlDocument.getElementsByTagName("turnaj");
    for(int i=0;i<tourneys.getLength();i++){
      Element t=(Element)tourneys.item(i);
      if(t.getElementsByTagName("nazev").item(0).getTextContent().equals("BC Card Cup")&&
              t.getElementsByTagName("rok").item(0).getTextContent().equals("2011")){
        t.getElementsByTagName("seznam_partii").item(0).appendChild(e);
      }
    }
    
    // srovnej partie podle data
    
  }
  private void addChildWithContent(Element e,String childName,String childValue){
    e.appendChild(e.getOwnerDocument().createElement(childName));
    e.getLastChild().setTextContent(childValue);
  }
  private String getFreeId(Document doc,String element,String prefix){
    NodeList els=doc.getElementsByTagName(element);
    int highestUsed=0;
    
    for(int i=0;i<els.getLength();i++){
      int t=Integer.parseInt(els.item(i).getAttributes().getNamedItem("id").getTextContent().substring(prefix.length())); // extrahuj číslo
      if(t>highestUsed){highestUsed=t;}
    }
    
    return prefix+(highestUsed+1);
  }
}