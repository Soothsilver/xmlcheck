package dom.user;

import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


/**
 * Odstrani atributy a jejich hodnoty da do elementu a prida.
 * Atributy s defaultni hodnotou se bohuzel objevi znovu a nejde je odstranit.
 * Po zmene ovsem muzeme ignorovat vsechy atributy.
 * @author Jan Skalický <hskalicky@gmail.com>
 */
public class MyDomTransformer {

	public void transform (Document xmlDocument) {

		Deque<Node> toChange = new LinkedList<Node>();
		toChange.add(xmlDocument);

		while (!toChange.isEmpty())
		{
			Node currNode = toChange.pop();

			NodeList children = currNode.getChildNodes();
			for (int i = 0; i < children.getLength(); i++)
			{
				toChange.add(children.item(i));
			}

			if (currNode.hasAttributes())
			{
				NamedNodeMap attributes = currNode.getAttributes();
				List<String> toDelete = new ArrayList<String>();

				for (int i = 0; i < attributes.getLength(); i++)
				{
					Node attributNode = attributes.item(i);
					Attr attribut = (Attr)attributNode;

					if (attribut.getName().length() < 5
							|| !attribut.getName().substring(0, 5).equals("xmlns"))
					{
						Element newElement = xmlDocument.createElement(attribut.getName());
						newElement.setTextContent(attribut.getValue());

						toDelete.add(attributNode.getNodeName());
						currNode.appendChild(newElement);
					}
				}

				for (int i = 0; i < toDelete.size(); i++)
				{
					attributes.removeNamedItem(toDelete.get(i));
				}
			}
		}
	}
}