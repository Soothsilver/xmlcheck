package sax.user;

import java.util.ArrayList;
import java.util.List;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Spocita frekvence elementu.
 * @author Jan Skalický <hskalicky@gmail.com>
 */
public class MySaxHandler extends DefaultHandler {

	private static int INDENTATION = 30;

	List<String> elementNames = new ArrayList<String>();
	List<Integer> elementCounts = new ArrayList<Integer>();

	@Override
    public void startDocument() throws SAXException {


    }

	String makeIndent(int count)
	{
		if (count < 0)
		{
			count = 0;
		}

		StringBuilder s = new StringBuilder();

		for (int i = 0; i < count; i++)
		{
			s.append(' ');
		}

		return s.toString();
	}

	@Override
    public void endDocument() throws SAXException {

		System.out.println("Frequence of elements:\n");

        for (int i=0; i < elementNames.size(); ++i)
        {
			System.out.println(String.format("name: %s %s frequency: %s",
					elementNames.get(i),
					makeIndent(INDENTATION - elementNames.get(i).length()),
					elementCounts.get(i)));
        }
    }

	@Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

		int index = elementNames.indexOf(localName);

		if (index == -1)
		{
			elementNames.add(localName);
			elementCounts.add(1);
		}
		else
		{
			elementCounts.set(index, elementCounts.get(index) + 1);
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {

    
    }

	@Override
    public void characters(char[] ch, int start, int length) throws SAXException {

    }

}

