/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;


/**
 *
 * @author Grudik-thinks
 */
public class MyDomTransformer {

    public static void main(String[] args) {
        

    }

    public void transform(Document xmlDocument) {
        // code transforming xmlDocument object // (method works on the object itself - no return value) 
        DomPraser d = new DomPraser(xmlDocument);
    }
}
class DomPraser {

    private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "data.out.xml";

    public DomPraser(Document xmlDocument) {

        try {

            //DocumentBuilderFactory vytváří DOM parsery
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            //nebudeme validovat
            dbf.setValidating(false);

            //vytvoříme si DOM parser
            DocumentBuilder builder = dbf.newDocumentBuilder();

            //parser zpracuje vstupní soubor a vytvoří z něj strom DOM objektů
            Document doc = builder.parse(xmlDocument.getDocumentURI());

            //zpracujeme DOM strom
            vymenZnacku(doc);

            //TransformerFactory vytváří serializátory DOM stromů
            TransformerFactory tf = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer = tf.newTransformer();

            //nastavíme kodování
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spustíme transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


        } catch (Exception e) {

            e.printStackTrace();

        }


    }

    /**
     * Tato metoda vymaze atribut Znacka a zalozi element Znacka do ktereho
     * nahraje obsah atributu
     *
     * @param doc
     */
    private static void vymenZnacku(Document doc) {

//        Najde vsechny elementy, ktere se jmenuji "kompakt"
        NodeList kompakty = doc.getElementsByTagName("kompakt");

//        Postupne vsechny prochazi
        for (int i = 0; i < kompakty.getLength(); i++) {

            Node kompakt = kompakty.item(i);
//            Bere si list atributu
            NamedNodeMap atributy = kompakt.getAttributes();
//            Najde atribut s nayzvem znacka
            Node atr = atributy.getNamedItem("Znacka");
//            Ulozi z nej obsah
            String znacka = atr.getTextContent();

//            Vytvori element Znacka
            Element s = doc.createElement("znacka");
//            Vytvori textovy uzel, do ktereho se ulozi hodnota puvodniho atributu
            Text e = doc.createTextNode("Znacka");
            e.setData(znacka);

//            Prirazeni obsahu do elementu
            s.appendChild(e);
//            Prirazeni elementu pod element kompakt
            kompakt.appendChild(s);

//            Odstraneni atributu "Znacka"
            atributy.removeNamedItem("Znacka");

        }

    }
}
