/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 *
 * @author Grudik-thinks
 */

/**
 * 
 * Tato trida dedi od tridy DefaultHandler a pretezuje jeji metody tak, abydelali, co potrebuji.
 *
 */
public class MySaxHandler extends DefaultHandler { 
    // overrides of DefaultHandler methods 

    int aktualniHloubka = 0;
    int maxHloubka = 0;
    int nejdelsiNazevElementu = 0;
    double prumernaDelkaElementu = 0;
    int pocetElementu = 0;

    void printIndent() {
        for (int i = 0; i < aktualniHloubka; i++) {
            System.out.print("-");
        }
        if (aktualniHloubka > maxHloubka) {
            maxHloubka = aktualniHloubka;
        }
    }

    @Override
//    Metoda se zavolá na začátku dokumentu
    public void startDocument() {
        System.out.println("Zacinam cist dokument.");
    }

    @Override
//    Metoda se zavloá na konci dokumentu
    public void endDocument() {
        System.out.println("Konec dokumentu.");
        System.out.println("--------------------------------------------------------");
        System.out.println("SOUHRN: ");
        System.out.println("MAXIMALNI HLOUBKA DOKUMENTU: " + maxHloubka);
        System.out.println("POCET ELEMENTU: " + pocetElementu);
        System.out.println("NEJDELSI NAZEV ELEMENTU: " + nejdelsiNazevElementu);
        System.out.println("PRUMERNA DELKA ELEMENTU: " + prumernaDelkaElementu);
        System.out.println("--------------------------------------------------------");
    }

    @Override
//    Metoda se spustí při každém začátku elementu
    public void startElement(String uri, String localName,
            String qName, Attributes attributes) {
        printIndent();
        System.out.println("Zacina element: " + qName);
        aktualniHloubka++;

        if (nejdelsiNazevElementu < qName.length()) {
            nejdelsiNazevElementu = qName.length();
        }
        if (prumernaDelkaElementu == 0) {
            prumernaDelkaElementu = qName.length();
        } else {
            prumernaDelkaElementu = (prumernaDelkaElementu + qName.length()) / 2;
        }
        pocetElementu++;

    }

    @Override
    //    Metoda se spustí při každém konci elementu
    public void endElement(String uri, String localName,
            String qName) {
        aktualniHloubka--;
        printIndent();
        System.out.println("Konci element: " + qName);
    }


    @Override
//    Metoda se spustí v každém elementu
    public void characters(char[] ch, int start, int length) {
        printIndent();
        System.out.println("character data, length " + length);

        String data = new String();

        for (int i = start; i < start + length; i++) {
            if (ch[i] != ' ') {
                data = data + ch[i];
            }
        }
        if (!(data.length() < 2)) {
            printIndent();
            System.out.println("CDATA :" + data);
        }


    }

    
//    Zajišťuje spuštění
    public static void main(String[] args) {
//      Vytvareni instance
        MySaxHandler t = new MySaxHandler();
//      Zadani cesty k souboru s daty
        String sourcePath = "data.xml";

        try {

            // VytvorĂ­me instanci parseru.
            XMLReader parser = XMLReaderFactory.createXMLReader();

            // VytvorĂ­me vstupnĂ­ proud XML dat.
            InputSource source = new InputSource(sourcePath);

            // NastavĂ­me nĂˇÄ… vlastnĂ­ content handler pro obsluhu SAX udĂˇlostĂ­.
            parser.setContentHandler(new MySaxHandler());

            // Zpracujeme vstupnĂ­ proud XML dat.
            parser.parse(source);

        } catch (Exception e) {

            e.printStackTrace();

        }

    }
}
