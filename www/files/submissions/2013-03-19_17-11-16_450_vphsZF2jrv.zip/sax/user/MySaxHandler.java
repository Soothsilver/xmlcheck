/* 
 * 1) Vypise staty, ve kterych se nachazi vice nez jeden tym.
 * 2) Spocita prumernou kapacitu aren.
 * 3) Vypise data, kdy padlo v nekterem ze zapasu pres 7 golu.
 */

package user;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 * Main class for SAX parsing
 *
 * @author XML Technologies
 */
public class MySaxHandler extends DefaultHandler {
    
    // Helper variable to store location of the handled event
    Locator locator;
    private static boolean inCapacity = false;
    private static boolean inGoals = false;
    private static HashMap<String, Integer> states = new HashMap<String,Integer>();
    private static HashSet<String> dates = new HashSet<String>();
    private static int overallCapacity = 0;
    private static int noOfStadiums = 0;
    private static int goals = 0;
    private static String date;

    /**
     * Sets the locator
     *
     * @param Locator locator location in the file
     */
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Method to handle "document start"
     *
     * @throws SAXException
     */
    @Override
    public void startDocument() throws SAXException {
    }

    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
        // Vypise staty s vice tymy
        System.out.print("Staty s vice tymy: ");
        Iterator it = states.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pairs = (Map.Entry) it.next();
            if ((Integer) pairs.getValue() > 1) {
                System.out.print(pairs.getKey() + ", ");
            }
        }
        System.out.println("\b\b");
        // prumernou kapacitu stadionu
        System.out.println("Prumerna kapacita stadionu je: " + overallCapacity / noOfStadiums);
        // Data, kdy se hraly zapasy, ve kterych padlo alespon 8 golu
        System.out.println("Data, kdy se hraly zapasy, ve kterych padlo alespon 8 golu: ");
        it = dates.iterator();
        while (it.hasNext()) {
            System.out.print(it.next() + ", ");
        }
        System.out.println("\b\b.");
    }

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        // Staty s vice tymy
        if (localName.equals("state")) {
            String stateTemp = atts.getValue("name");
            // pocita, kolik je v kazdem state tymu
            if (states.containsKey(stateTemp)) {
                states.put(stateTemp, states.get(stateTemp) + 1);
            } else {
                states.put(stateTemp, 1);
            }
        // nastavi priznaky pro zpracovani jinych elementu
        } else if (localName.equals("capacity")) {
            inCapacity = true;
        } else if (localName.equals("match")) {
            goals = 0;
            date = atts.getValue("date");
        } else if (localName.equals("goals")) {
            inGoals = true;
        }
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        // rusi priznaky a pokud padlo v zapase vice nez 8 golu, zapise si jeho datum
        if (localName.equals("capacity")) {
            inCapacity = false;
        } else if (localName.equals("goals")) {
            inGoals = false;
            if (goals >= 8) {
                dates.add(date);
            }
        }
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        // pocita celkovou kapacitu stadionu a udrzuje si jejich pocet
        if (inCapacity) {
            StringBuffer s = new StringBuffer().append(chars, start, length);
            int capacity = Integer.parseInt(s.toString());
            overallCapacity += capacity;
            noOfStadiums++;
        } 
        // zjisti pocet vstrelenych golu tymem v zapase
        else if (inGoals) {
            StringBuffer s = new StringBuffer().append(chars, start, length);
            int goal = Integer.parseInt(s.toString());
            goals += goal;
        }
    }

    /**
     * Method to handle " start of namespace declaration"
     *
     * @param prefix Prefix of the namespace
     * @param uri URI of the namespace
     * @throws SAXExceptio
     */
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    /**
     * Method to handle "end of namespace declaration"
     *
     * @param prefix
     * @throws SAXException
     */
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    /**
     * Method to handle "ignoring of whitespaces" Text is in array 'chars' from
     * position ('start') to ('start' + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     * @throws SAXException
     */
    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
        // ...
    }

    /**
     * Method to handle "processing instructions"
     *
     * @param target The processing instruction target
     * @param data The processing instruction data
     * @throws SAXException
     */
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

    /**
     * Method to handle "unprocessed entity"
     *
     * @param name
     * @throws SAXException
     */
    @Override
    public void skippedEntity(String name) throws SAXException {
        // ...
    }
}
