/* 
 * 1) Seradi zapasy podle id (vzestupne).
 * 2) Prida novy zapas s dnesnim datem a danymi parametry.
 * 3) Smaze zapasy, ktere se nehraly tento mesic.
 */
package user;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.w3c.dom.*;

/**
 * ASSIGNMENT: Update document to be able to transform input XML document to
 * output document by actions mentioned in comments of processTree method.
 */
public class MyDomTransformer {

    public void transform(Document xmlDocument) {
        // seradi zapasy podle id, vzestupne
        sortMatchesById(xmlDocument, true);
        // prida novy zapas s danymi parametry
        addMatch(xmlDocument, "ea2", "ea1", 5, 4, "OT");
        // smaze zaznamy zapasu, ktere nejsou z tohoto mesice
        deleteOldMatches(xmlDocument);
    }

    public static void sortMatchesById(Document doc, final boolean ascending) {
        // vytvori ArrayList vsech zapasu, ten setridi podle id
        Node matchesTag = doc.getElementsByTagName("matches").item(0);
        NodeList matches = matchesTag.getChildNodes();
        List<Node> matchesList = new ArrayList<Node>();
        for (int i = 0; i < matches.getLength(); i++) {
            // pokud jde o element, ulozi ho do ArrayListu
            int type = matches.item(i).getNodeType();
            if (type == Element.ELEMENT_NODE) {
                matchesList.add(matches.item(i));
            }
        }
        // setridi ArrayList podle id 
        Collections.sort(matchesList, new Comparator<Node>() {
            public int compare(Node n1, Node n2) {
                String id1 = n1.getAttributes().getNamedItem("id").getNodeValue();
                int id1Int = Integer.parseInt(id1.substring(1));
                String id2 = n2.getAttributes().getNamedItem("id").getNodeValue();
                int id2Int = Integer.parseInt(id2.substring(1));
                int result = id2Int - id1Int;
                if (ascending) {
                    result *= -1;
                }
                return result;
            }
        });

        // vytvori novy element matches, do ktereho prida elementy ve spravnem poradi
        Element newMatches = doc.createElement("matches");
        for (int i = 0; i < matchesList.size(); i++) {
            newMatches.appendChild(matchesList.get(i));
        }
        // nahradi novy element matches za stary 
        doc.getElementsByTagName("NHL").item(0).removeChild(doc.getElementsByTagName("matches").item(0));
        doc.getElementsByTagName("NHL").item(0).appendChild(newMatches);
    }

    public static void addMatch(Document doc, String homeTeam, String awayTeam,
            int homeGoals, int awayGoals, String end) {
        Node matches = doc.getElementsByTagName("matches").item(0);
        //vytvori novy match
        Element newMatch = doc.createElement("match");
        Node n = matches.getLastChild();
        while (true) {
            if (n.getNodeType() == Element.ELEMENT_NODE) {
                break;
            }
            n = n.getPreviousSibling();
        }
        String highestId = n.getAttributes().getNamedItem("id").getNodeValue();
        String newId = "m" + (Integer.parseInt(highestId.substring(1)) + 1);
        // prida mu nove id - document je jiz serazeny podle id zapasu
        newMatch.setAttribute("id", newId);
        DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
        Calendar cal = Calendar.getInstance();
        // prida zapasu dnesni datum
        newMatch.setAttribute("date", dateFormat.format(cal.getTime()));
        // vytvori homeTeam element
        Element homeTeamEl = doc.createElement("homeTeam");
        homeTeamEl.setAttribute("ref", homeTeam);
        Element homeGoalsEl = doc.createElement("goals");
        homeGoalsEl.setTextContent(homeGoals + "");
        homeTeamEl.appendChild(homeGoalsEl);
        // vytvori awayTeam element
        Element awayTeamEl = doc.createElement("awayTeam");
        awayTeamEl.setAttribute("ref", awayTeam);
        Element awayGoalsEl = doc.createElement("goals");
        awayGoalsEl.setTextContent(awayGoals + "");
        awayTeamEl.appendChild(awayGoalsEl);
        // vytvori end element
        Element endEl = doc.createElement("end");
        endEl.setAttribute("type", end);
        // prida vsechny tri subelementy do newMatch
        newMatch.appendChild(homeTeamEl);
        newMatch.appendChild(awayTeamEl);
        newMatch.appendChild(endEl);
        // prida newMatch do matches
        matches.appendChild(newMatch);
    }

    public static void deleteOldMatches(Document doc) {
        // smaze vsechny zaznamy zapasu, ktere nejsou z tohoto mesice

        // zjisti aktualni mesic a rok
        Calendar cal = Calendar.getInstance();
        int month = cal.get(Calendar.MONTH) + 1;
        int year = cal.get(Calendar.YEAR);

        // prochazi jednotlive zapasy a ty stare maze
        Node matches = doc.getElementsByTagName("matches").item(0);
        int i = 0;
        while (true) {
            if (i == matches.getChildNodes().getLength()) {
                break;
            }
            int type = matches.getChildNodes().item(i).getNodeType();
            if (type == Element.ELEMENT_NODE) {
                String date = matches.getChildNodes().item(i).getAttributes().getNamedItem("date").getNodeValue();
                String[] fields = date.split("\\.");
                // z parametru date elementu match ziska jeho mesic a rok
                int matchMonth = Integer.parseInt(fields[1]);
                int matchYear = Integer.parseInt(fields[2]);
                // pokud je stary, smaze ho
                if (matchMonth != month || matchYear != year) {
                    matches.removeChild(matches.getChildNodes().item(i));
                    i--;
                }
            }
            i++;
        }
    }
}