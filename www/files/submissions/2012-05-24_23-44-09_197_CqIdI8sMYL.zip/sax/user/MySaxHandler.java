package user;

import java.math.BigDecimal;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Tento handler spocte maximalni hloubku dokumentu (vnoreni elementu) a pomer zastoupeni uzivatelu dle pohlavi.
 * @author Jakub Duběda
 */
public class MySaxHandler extends DefaultHandler {
    String currentElem;
    double muzi = 0, zeny = 0;
    int depth = 0;
    int maxDepth = 0;
    
    @Override
    public void startDocument() throws SAXException {
        System.out.println("Zpracovávám dokument...");
    }

    @Override
    public void endDocument() throws SAXException {
        if (muzi != 0 && zeny != 0) {
            double pm = (muzi/(muzi+zeny))*100;
            double pz = (zeny/(muzi+zeny))*100;

            System.out.println("Poměr zastoupení dle pohlaví uživatelů: muži "+BigDecimal.valueOf(pm).setScale(2, BigDecimal.ROUND_HALF_UP)+
                    "% a ženy "+BigDecimal.valueOf(pz).setScale(2, BigDecimal.ROUND_HALF_UP)+"%.");
        }
        System.out.println("Maximální hloubka dokumentu (root element počítán jako hloubka 1): "+maxDepth);
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        currentElem = qName;
        depth++;
        if (depth > maxDepth) maxDepth = depth;
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        depth--;
    }

    @Override
    public void characters(char ch[], int start, int length) throws SAXException {
        String var = new String(ch, start, length).trim(); //Trim vynecha pripadne white spaces na zacatku a na konci stringu
        
        if (var.length() == 0) return; //prazdne retezce/elementy neresime
        
        if (currentElem.equals("pohlavi")) {
            if (var.contains("Muž")) muzi++;
            else if (var.contains("Žena")) zeny++;
        }
    }
}
