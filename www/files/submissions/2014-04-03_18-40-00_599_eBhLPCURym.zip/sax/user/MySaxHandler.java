/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

/**
 *
 * @author Ondra
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {

    public MySaxHandler() {
        //String je jmeno knihy (NameB)   Integer je pocet kusu dane knihy
        knihyPocet.put("R.U.R.", 0);
        knihyPocet.put("Blecha", 0);
        knihyPocet.put("Kniha krale Petrika 70", 0);
        knihyPocet.put("Bojove umeni", 0);
        knihyPocet.put("Radkova cesta do pekel", 0);
    }
    int pocetKnih = 0;
    double prumernaPopularitaKnih = 0;
    List<Integer> listOfPopularity = new ArrayList<Integer>();
    String knihaSnejvetsimPoctemKusu;
    int autorNeviceKnihPocet = 0;
    String localName = "";
    Map<String, Integer> knihyPocet = new HashMap<String, Integer>();

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        this.localName = localName;

        if ("Popularity".equals(localName)) {
            listOfPopularity.add(Integer.parseInt(atts.getValue("Popularity")));
        }
    }

    @Override
    public void characters(char ch[], int start, int length) throws SAXException {
        if ("Kniha".equals(localName)) {
            if (knihyPocet.containsKey(ch)) {
                pocetKnih++;
                knihyPocet.put(ch + "", knihyPocet.get(ch) + 1);
            }
        }

    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
    }

    @Override
    public void endDocument() throws SAXException {

        // <editor-fold defaultstate="collapsed" desc="prumerna popularita + pocet knih">
        int celkem = 0;
        pocetKnih = 0;
        for (Integer i : listOfPopularity) {
            celkem += i;
            pocetKnih++;
        }
        prumernaPopularitaKnih = celkem / pocetKnih;
        // </editor-fold>

        // <editor-fold defaultstate="collapsed" desc="knizka ktera se objevuje nejvic vypocet">
        int maxPocet = 0;
        int actual = 0;
        for (String kniha : knihyPocet.keySet()) {
            if (maxPocet < (actual = knihyPocet.get(kniha))) {
                maxPocet = actual;
                knihaSnejvetsimPoctemKusu = kniha;
            }
        }

        // </editor-fold>
    }

}
