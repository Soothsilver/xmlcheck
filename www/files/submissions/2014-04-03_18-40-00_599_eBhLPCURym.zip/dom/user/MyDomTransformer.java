/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

/**
 *
 * @author Ondra
 */
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class MyDomTransformer {
    
    public void transform(Document xmlDocument) {
        // libovolne transformace objektu 'xmlDocument'
        // (metoda pracuje primo na objektu, nic nevraci)

        /*pokud nalezne knihovnu bez knih tak neni potreba a zrusi ji 
         */
        NodeList libraries = xmlDocument.getElementsByTagName("Library");
        for (int i = libraries.getLength() - 1; i >= 0; --i) {
            Element library = (Element) libraries.item(i);
            int pocetKnihVKnihovne = library.getElementsByTagName("book").getLength();
            if (pocetKnihVKnihovne <= 0) {
                library.getParentNode().removeChild(library);
            }
        }
        //----------------------------------------------------------------------
        //pridani nového Authora ke knize z ID=i362
          NodeList books =xmlDocument.getElementsByTagName("Book");
        
        Element author = xmlDocument.createElement("Author");
        Element bornPlaceA;
        author.appendChild(xmlDocument.createElement("firstNameA")).setTextContent("Pepik");
        author.appendChild(xmlDocument.createElement("lastNameA")).setTextContent("Novak");
        author.appendChild(xmlDocument.createElement("PopisA")).setTextContent("Znamy ilustrstor");
        
        author.appendChild(bornPlaceA = xmlDocument.createElement("bornPlaceA"));
        bornPlaceA.appendChild(xmlDocument.createElement("CountryA")).setTextContent("Czech Republic");
        bornPlaceA.appendChild(xmlDocument.createElement("CityA")).setTextContent("Prague");
        if(books==null){
        throw new Error("nefunguje to");
        }
//        books.item(0).appendChild(author);
    }
}
