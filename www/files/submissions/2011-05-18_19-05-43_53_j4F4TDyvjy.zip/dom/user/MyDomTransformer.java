package user;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

public class MyDomTransformer 
{ 
	
	public void transform (Document doc) 
	{
		//zkopirovani profilu do elementu clen podle referenci
		NodeList cleni = doc.getElementsByTagName("clen");
		for(int i = 0; i < cleni.getLength(); i++)
		{			
			Node n = cleni.item(i);
			if(n instanceof Element)
			{
				Element clen = (Element) n;
				if(clen.hasAttribute("pref"))
				{
					//smazani atributu pref
					String id = clen.getAttribute("pref");
					clen.removeAttribute("pref");
					
					//nalezeni profilu
					Element profil = null;
					NodeList profily = doc.getElementsByTagName("profil");
					for(int j = 0; j < profily.getLength(); j++)
					{
						Node p = profily.item(j);
						if(p instanceof Element)
						{
							Element pe = (Element) p;
							if(pe.getAttribute("pid").equals(id))
							{
								profil = pe;
								break;
							}
						}
					}
					
					//zkopirovani
					if(profil != null)
					{
						NodeList pcontent = profil.getChildNodes();
						for(int j = 0; j < pcontent.getLength(); j++)
							clen.appendChild(pcontent.item(j).cloneNode(true));	
					}
				}
			}
		}
		
		
		//smazani samostatnych profilu
		NodeList profily = doc.getElementsByTagName("profil");
		while(profily.getLength() > 0)	
		{			
			Node profil = profily.item(0);
			Node parent = profil.getParentNode();
			if(parent != null)
				parent.removeChild(profil);
			profily = doc.getElementsByTagName("profil");
		}			
	}
}

