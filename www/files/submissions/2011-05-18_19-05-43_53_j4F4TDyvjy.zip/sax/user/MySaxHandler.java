package user;

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;



/**
 * Náš vlastní content handler pro obsluhu SAX událostí.
 */ 
public class MySaxHandler extends DefaultHandler
{

    // Umožňuje zacílit místo v dokumentu, kde vznikla aktualní událost
    int alba;
    int skladby;
    

    /**
     * Obsluha události "začátek dokumentu"
     */     
    public void startDocument() throws SAXException {
        
        alba = 0;
        skladby = 0;        
    }
    
    /**
     * Obsluha události "konec dokumentu"
     */     
    public void endDocument() throws SAXException 
    { 
    	System.out.print("prumerny pocet pisnicek na albu: ");
    	System.out.println(((double) skladby) / ((double) alba));
    }
    
    /**
     * Obsluha události "začátek elementu".
     * @param uri URI jmenného prostoru elementu (prázdné, pokud element není v žádném jmenném prostoru)
     * @param localName Lokální jméno elementu (vždy neprázdné)
     * @param qName Kvalifikované jméno (tj. prefix-uri + ':' + localName, pokud je element v nějakém jmenném prostoru, nebo localName, pokud element není v žádném jmenném prostoru)
     * @param atts Atributy elementu     
     */     
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
    {
    	if(localName.equals("album"))
    		alba++;
    	else if(localName.equals("skladba"))
    		skladby++;
    }    
}