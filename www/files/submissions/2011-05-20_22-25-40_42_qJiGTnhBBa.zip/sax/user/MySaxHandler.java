package user;

import java.util.ArrayList;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.*;

// Pocita, kolik je v dokumentu o kazde zbrani dostupnych informaci. Tj. pro kazdou zbran secte jeji textove poduzly a atributy
// a textove poduzly a atributy jeji munice a v techto poctech nalezne a vypise minimum, maximum a prumer.
public class MySaxHandler extends DefaultHandler
{
    // Struktura pro data o jedne zbrani zjistena behem cteni.
    protected class gunData
    {
        public String name;
        public int infos;
        public int atts;
        public String ammo;
        public int total;
    }
    
    // Seznam techto struktur pro vsechny zbrane.
    ArrayList<gunData> gData;
    
    // Struktura, do niz se aktualni uklada
    gunData gCurrent;

    // Struktura pro data o jednom druhu streliva zjistena behem cteni.
    protected class ammoData
    {
        public String id;
        public int infos;
        public int atts;
    }
    
    // Seznam techto struktur pro vsechny druhy streliva.
    ArrayList<ammoData> aData;
    
    // Struktura, do niz se aktualni uklada
    ammoData aCurrent;
    
    // Priznka, zda se ma pristi textovy blok zapocitat (tj. jestli nasleduje po elementu, ne po jinem textu)
    boolean increment;
    
    // Priznak, zda jsem v podstrome elementu gun   
    boolean gun;
    
    // Priznak, zda jsem v podstrome elementu ammo
    boolean ammo;
    
    // Priznak, zda jsem v elementu name v podstrome elementu gun
    boolean name;

    @Override
    public void startDocument() throws SAXException
    {
        // Inicializace
        increment = true;
        gCurrent = null;
        aCurrent = null;
        gData = new ArrayList<gunData>();
        aData = new ArrayList<ammoData>();
        gun = false;
        ammo = false;
        name = false;
    }

    @Override
    public void endDocument() throws SAXException
    {
        // Finalni vypis statistik
        
        int max = 0;
        int sum = 0;
        int min = Integer.MAX_VALUE;

        // Dilci statistiky zbrani
        for (int i = 0; i < gData.size(); i++)
        {
            System.out.println(gData.get(i).name);
            System.out.println("---------------------------------");
            System.out.println("textovych uzlu: " + gData.get(i).infos);
            System.out.println("atributu: " + gData.get(i).atts);
            
            int total = gData.get(i).infos + gData.get(i).atts;
            for (int j = 0; j < aData.size(); j++)
            {
                if (aData.get(j).id.equals(gData.get(i).ammo))
                {
                    System.out.println("textovych uzlu munice: " + aData.get(j).infos);
                    System.out.println("atributu munice: " + aData.get(j).atts);
                    total += aData.get(j).infos + aData.get(j).atts;
                    break;
                }
            }
            if (total < min)
            {
                min = total;
            }
            if (total > max)
            {
                max = total;
            }
            sum += total;
            gData.get(i).total = total;
            
            System.out.println("celkem udaju: " + total);
            System.out.println();
        }
        
        // Souhrn
        System.out.println("---------------------------------");
        System.out.println("---------------------------------");
        System.out.println();
        
        // Minimum
        System.out.print("Minimalni pocet udaju: " + min + " (");
        boolean first = true;
        for (int i = 0; i < gData.size(); i++)
        {
            if (gData.get(i).total == min)
            {
                if (!first)
                {
                    System.out.print(", ");
                }
                System.out.print(gData.get(i).name);
                first = false;
            }
        }
        System.out.println(")");
        
        // Prumer
        System.out.println("Prumerny pocet udaju: " + sum / gData.size());
        
        // Maximum
        System.out.print("Maximalni pocet udaju: " + max + " (");
        first = true;
        for (int i = 0; i < gData.size(); i++)
        {
            if (gData.get(i).total == max)
            {
                if (!first)
                {
                    System.out.print(", ");
                }
                System.out.print(gData.get(i).name);
                first = false;
            }
        }
        System.out.println(")");        
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
    {
        // Element ref je uvnitr smiseneho obsahu elementu comment. 
        if (!localName.equals("ref"))
        {
            increment = true;
        }

        // Priprava struktury pro novou zbran.
        if (localName.equals("gun"))
        {
            gCurrent = new gunData();
            gCurrent.name = "";
            gCurrent.infos = 0;
            gCurrent.atts = 0;
            gun = true;
        }

        // Priprava struktury pro novou munici.
        if (localName.equals("ammo"))
        {
            aCurrent = new ammoData();
            aCurrent.infos = 0;
            aCurrent.atts = 0;
            ammo = true;

            // Nalezeni atributu id a ulozeni jeho hodnoty.
            for (int i = 0; i < atts.getLength(); i++)
            {
                if (atts.getLocalName(i).equals("id"))
                {
                    aCurrent.id = atts.getValue(i);
                    break;
                }
            }
        }

        // Sekce CDATA by se jako text nezapocetla, je nutne ji zapocitat zvlast.
        if (localName.equals("logo"))
        {
            if (gun)
            {
                gCurrent.infos++;
            }
            if (ammo)
            {
                aCurrent.infos++;
            }
        }

        // Budu chtit ulozit jmeno zbrane.
        if (localName.equals("name") && gun)
        {
            name = true;
        }

        // Nalezeni a ulozeni id munice aktualni zbrane.
        if (localName.equals("cartridge") && gun)
        {
            for (int i = 0; i < atts.getLength(); i++)
            {
                if (atts.getLocalName(i).equals("id"))
                {
                    gCurrent.ammo = atts.getValue(i);
                    break;
                }
            }
        }

        // Zapocteni atributu.
        if (gun)
        {
            gCurrent.atts += atts.getLength();
        }

        if (ammo)
        {
            aCurrent.atts += atts.getLength();
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException
    {
        if (!localName.equals("ref"))
        {
            increment = true;
        }

        if (localName.equals("gun"))
        {
            gData.add(gCurrent);
            gun = false;
        }

        if (localName.equals("ammo"))
        {
            aData.add(aCurrent);
            ammo = false;
        }

        if (localName.equals("name") && gun)
        {
            name = false;
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException
    {
        // Ulozeni jmena zbrane
        if (name)
        {
            for (int i = start; i < start + length; i++)
            {
                gCurrent.name += ch[i];
            }
        }

        // Pokud tento textovy blok nasleduje po elementu (tzn. ne po jinem textu), nachazi se pod
        // zbrani nebo munici a neobsahuje jen bile znaky, zvysi se pocitadlo textovych uzlu aktualni
        // zbrane resp. munice.
        if (increment && (gun || ammo))
        {
            for (int i = start; i < start + length; i++)
            {
                if (!Character.isWhitespace(ch[i]))
                {
                    if (gun)
                    {
                        gCurrent.infos++;
                    } else
                    {
                        aCurrent.infos++;
                    }
                    increment = false;
                    break;
                }
            }
        }
    }
}