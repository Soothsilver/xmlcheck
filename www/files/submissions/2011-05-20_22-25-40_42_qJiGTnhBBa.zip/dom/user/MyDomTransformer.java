package user;

import org.w3c.dom.*;

public class MyDomTransformer
{
    // Vraci prvni poduzel predaneho uzlu, ktery je typu Element a jeho jmeno se neshoduje s predanym retezcem, jinak vraci null.
    // Slouzi k nalezeni prvni dosud neodstranene kategorie zbrani resp. munice (vim o ni jen to, ze to je podelement elementu
    // firearms resp. ammunition a nejmenuje se gun resp. ammo).
    protected Element getCategory(Element ofWhat, String exclude)
    {
        NodeList children = ofWhat.getChildNodes();
        for (int i = 0; i < children.getLength(); i++)
        {
            Node child = children.item(i);
            if (child instanceof Element && !((Element) child).getTagName().equals(exclude))
            {
                return (Element) child;
            }
        }
        return null;
    }

    // Transformace zbrane nebo munice (vetsina zmen spolecna, nekolik jen pro zbrane).
    protected void transformGunOrAmmo(Element gunOrAmmo, Document xmlDocument)
    {       
        // pridani podelementu pro kategorii
        Element oldCategory = (Element) gunOrAmmo.getParentNode();
        if (oldCategory.getAttributeNode("name") != null)
        {
            Element newCategory = xmlDocument.createElement("category");
            newCategory.appendChild(xmlDocument.createTextNode(oldCategory.getAttribute("name")));
            gunOrAmmo.insertBefore(newCategory, gunOrAmmo.getFirstChild());
        }

        // name z podelementu na atribut
        Element name = (Element) gunOrAmmo.getElementsByTagName("name").item(0);
        if (name != null)
        {
            gunOrAmmo.setAttribute("name", name.getTextContent());
            gunOrAmmo.removeChild(name);
        }

        // id z atributu na podelement
        Attr id = gunOrAmmo.getAttributeNode("id");
        if (id != null)
        {
            Element eid = xmlDocument.createElement("id");
            eid.appendChild(xmlDocument.createTextNode(id.getValue()));
            gunOrAmmo.insertBefore(eid, gunOrAmmo.getFirstChild());
            gunOrAmmo.removeAttributeNode(id);
        }

        // udaje o puvodu z podelementu do atributu
        Element origin = (Element) gunOrAmmo.getElementsByTagName("origin").item(0);
        if (origin != null)
        {
            Element place = (Element) origin.getElementsByTagName("place").item(0);
            if (place != null)
            {
                origin.setAttribute("place", place.getTextContent());
            }
            Element designer = (Element) origin.getElementsByTagName("designer").item(0);
            if (designer != null)
            {
                origin.setAttribute("author", designer.getTextContent());
            }
            Element designed = (Element) origin.getElementsByTagName("designed").item(0);
            if (designed != null)
            {
                origin.setAttribute("year", designed.getTextContent());
            }
            
            // presun elementu logo pod gun resp. ammo
            Element logo = (Element) origin.getElementsByTagName("logo").item(0);
            if (logo != null)
            {
                gunOrAmmo.appendChild(logo);
            }

            while (origin.hasChildNodes())
            {
                origin.removeChild(origin.getFirstChild());
            }
        }
        
        // (pouze pro zbrane) z id munice jako atributu elementu cartridge na nazev munice jako jeho textovy obsah
        Element cartridge = (Element) gunOrAmmo.getElementsByTagName("cartridge").item(0);
        if (cartridge != null)
        {
            Attr aid = cartridge.getAttributeNode("id");
            if (aid != null)
            {
                Element ammo = null;
                NodeList ammos = xmlDocument.getElementsByTagName("ammo");
                for (int i = 0; i < ammos.getLength(); i++)
                {
                    ammo = (Element)ammos.item(i);
                    if (ammo.getAttribute("id").equals(aid.getValue()))
                    {
                        break;
                    }
                    else
                    {
                        ammo = null;
                    }
                }
                if (ammo != null)
                {
                    Element aname = (Element) ammo.getElementsByTagName("name").item(0);
                    if (aname != null)
                    {
                        cartridge.appendChild(xmlDocument.createTextNode(aname.getTextContent()));
                    }
                }
                cartridge.removeAttributeNode(aid);
            }            
        }

        // prejmenovani elementu comment na note
        Element comment = (Element) gunOrAmmo.getElementsByTagName("comment").item(0);
        if (comment != null)
        {
            xmlDocument.renameNode(comment, null, "note");/*.createElement("note");
            note.appendChild(xmlDocument.createTextNode(comment.getTextContent()));
            gunOrAmmo.removeChild(comment);
            gunOrAmmo.appendChild(note);*/
        }

        // adresa obrazku z atributu na textovy obsah
        Element picture = (Element) gunOrAmmo.getElementsByTagName("picture").item(0);
        if (picture != null)
        {
            Element image = xmlDocument.createElement("image");
            if (picture.getAttributeNode("src") != null)
            {
                image.appendChild(xmlDocument.createTextNode(picture.getAttribute("src")));
            }
            gunOrAmmo.removeChild(picture);
            gunOrAmmo.appendChild(image);
        }
        
        // zbytek zustane nezmenen
    }

    // Transformace dokumentu. Zachova puvodni elementy armory, firearms a ammunition, zrusi rozdeleni zbrani a munice do kategorii
    // (kategorie se stanou podlementy zbrani resp. munice) a kompletne zmeni strukturovani obsahu elementu gun a ammo. Transformace
    // je odolna proti nevalidnim dokumentum (ztransformuje jen to, co rozpozna).
    public void transform(Document xmlDocument)
    {
        // Z korenoveho elementu odstranim odkazy na XML Schema, protoze po transformaci mu uz dokument nebude odpovidat.
        Element armory = (Element) xmlDocument.getElementsByTagName("armory").item(0);
        if (armory == null)
        {
            return;
        }
        armory.removeAttribute("xmlns:xsi");
        armory.removeAttribute("xsi:noNamespaceSchemaLocation");

        //--- Preformatovani zbrani -----------------------

        // Vezmu element firearms, pro kazdou kategorii zbrani proberu elementy gun, ty ztransformuji, presunu pod element
        // firearms a prazdnou kategorii smazu.
        Element firearms = (Element) armory.getElementsByTagName("firearms").item(0);
        if (firearms != null)
        {
            Element category;
            while ((category = getCategory(firearms, "gun")) != null)
            {
                while (category.getElementsByTagName("gun").getLength() > 0)
                {
                    Element gun = (Element) category.getElementsByTagName("gun").item(0);
                    transformGunOrAmmo(gun, xmlDocument);
                    firearms.appendChild(gun);
                }
                firearms.removeChild(category);
            }
        }

        //--- Preformatovani munice -----------------------

        // Vezmu element ammunition, pro kazdou kategorii munice proberu elementy ammo, ty ztransformuji, presunu pod element
        // ammunition a prazdnou kategorii smazu.
        Element ammunition = (Element) armory.getElementsByTagName("ammunition").item(0);
        if (ammunition != null)
        {
            Element category;
            while ((category = getCategory(ammunition, "ammo")) != null)
            {
                while (category.getElementsByTagName("ammo").getLength() > 0)
                {
                    Element ammo = (Element) category.getElementsByTagName("ammo").item(0);
                    transformGunOrAmmo(ammo, xmlDocument);
                    ammunition.appendChild(ammo);
                }
                ammunition.removeChild(category);
            }
        }
    }
}
