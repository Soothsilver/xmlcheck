package user;

import java.util.ArrayList;
import java.util.List;
import org.w3c.dom.*;

/**
 * 2nd assignment to the course XML technologies
 * Author: Adam Blazek
 */
public class MyDomTransformer {

    private static final String INPUT_FILE = "c:\\doc\\xml\\du1\\data.xml";
    private static final String OUTPUT_FILE = "c:\\doc\\xml\\du1\\data.out.xml";

    /**
     * Modifies the given document.
     * We will add one employee and remove all orders that are older(created date)
     * than the date specified in 'data-from' processing instruction.
     * @param doc 
     */
    public void transform(Document doc){
        processTree(doc);
    }

    /**
     * The employees node.
     */
    private static Node employees;
    
    /**
     * The orders node.
     */
    private static Node orders;
    
    /**
     * Process document tree.
     * We will create a new employee with fixed name and position. His id will be calculated from actual staff(as e+[max current id]).
     * Moreover we will clean the document which means we will delete orders which were created before the 'data-from'.
     * @param doc Document to be parsed
     */
    private static void processTree(Document doc) {
        try{
            employees = doc.getElementsByTagName("employees").item(0);
            orders = doc.getElementsByTagName("orders").item(0);
            addEmployee(doc);
            cleanOrders(doc);
        }
        catch(Exception ex){
            System.out.println(ex.getMessage());
        }
    }
    
    /**
     * A little helper for obtaining the last child element.
     * @param node Node to be examined
     * @return Last child element of the given node
     */
    private static Element getLastChildElement(Node node)
    {
        node = node.getLastChild();
        while (node != null && node.getNodeType() != Node.ELEMENT_NODE) node = node.getPreviousSibling();
        return (Element)node;
    }
    
    /**
     * Gets the last employee's id.
     * @param doc XML document
     * @return the last employee's id
     */
    private static String getLastEmployeeId(Document doc){
        Node lastEmployee = getLastChildElement(employees);
        NamedNodeMap attrs = lastEmployee.getAttributes();
        Node empAtt = attrs.getNamedItem("employeeId");
        return empAtt.getTextContent();
    }
    
    /**
     * Adds a recently hired employee to the document.
     * @param doc 
     */
    private static void addEmployee(Document doc){
        String employeeId = getLastEmployeeId(doc);
        int employeeIdNum = Integer.parseInt(employeeId.substring(1));//remove leading 'e'
        String nextId = "e"+(employeeIdNum+1);
        Element emp = doc.createElement("employee");
        emp.setAttribute("name", "DOM is cool");
        emp.setAttribute("position","repairman");
        emp.setAttribute("employeeId",nextId);
        
        employees.appendChild(emp);
    }
    
    /**
     * Finds and returns the value of the 'data-from' processing instrucion.
     * @param doc
     * @return The value of the 'data-from' PI or an empty string if the PI wasn't found;
     */
    private static String GetDataFromProcessingInstruction(Document doc){
        NodeList docNodes = doc.getChildNodes();
        for(int i=0;i<docNodes.getLength();i++){
            Node node = docNodes.item(i);
            if(node.getNodeType() == Node.PROCESSING_INSTRUCTION_NODE){
                ProcessingInstruction pi = (ProcessingInstruction)node;
                String data = pi.getData().trim();
                String[] chunks = data.split("=");
                if(chunks.length != 2) continue;
                if(!chunks[0].equals("data-from")) continue;
                String value = chunks[1].substring(1,chunks[1].length() - 1);//removing parenthesis
                return value;
            }
        }
        return "";
    }
    
    /**
     * Deletes every order in the document which was created before the date in 'data-from' processing instruction.
     * Note that we have to check messages and delete all messages with a link to any of deleted orders.
     * @param doc 
     */
    private static void cleanOrders(Document doc)
    {
        List<String> deleted = new ArrayList<String>();//List of ids of deleted orders
        String dataFrom = GetDataFromProcessingInstruction(doc);
        NodeList orderList = orders.getChildNodes();
        for(int i=0;i<orderList.getLength();i++){//processing orders
            Node childNode = orderList.item(i);
            if(childNode.getNodeType() == Node.ELEMENT_NODE){
                Element order = (Element)childNode;
                Node dates = order.getElementsByTagName("dates").item(0);
                NodeList dateList = dates.getChildNodes();
                for(int d=0;d<dateList.getLength();d++){//processing dates
                    if(dateList.item(d).getNodeType() == Node.ELEMENT_NODE){
                        Element date = (Element)dateList.item(d);
                        String type = date.getAttribute("type");
                        if(type.equals("open")){
                            String content = date.getTextContent().trim();
                            if(content.compareTo(dataFrom) < 0){
                                orders.removeChild(order);
                                deleted.add(order.getAttribute("orderId"));
                                break;
                            }
                        }
                    }
                }
            }
        }
        
        Element messages = (Element)doc.getElementsByTagName("messages").item(0);
        NodeList messageList = messages.getChildNodes();
        for(int i=0;i<messageList.getLength();i++){
            Node message = messageList.item(i);
            if(message.getNodeType() != Node.ELEMENT_NODE) continue;
            
            NodeList links = message.getChildNodes();
            for(int l=0;l<links.getLength();l++){
                Node link = links.item(l);
                if(link.getNodeType() != Node.ELEMENT_NODE) continue;
                
                String ref = ((Element)link).getAttribute("ref");
                if(deleted.contains(ref)){
                    messages.removeChild(message);
                }
            }
        }
    }
}
