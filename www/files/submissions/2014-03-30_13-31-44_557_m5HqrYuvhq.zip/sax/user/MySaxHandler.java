package user;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * We will calculate and print:
 * the average salary of the employees(attributes),
 * the most frequent error(element content) and 
 * list of orders which were linked in at least one message and are not finished or canceled(context).
 */
public class MySaxHandler extends DefaultHandler {

    // Helper variable to store location of the handled event
    Locator locator;
    
    private int employeeCount = 0;
    private int salarySum = 0;
    
    private boolean inError = false;
    private Map<String,Integer> errorOccurrences;
    
    private Map<String,String> orderStates;
    
    private List<String> linkedOrders;

    /**
     * Sets the locator
     *
     * @param Locator locator location in the file
     */
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Method to handle "document start"
     *
     * @throws SAXException
     */
    @Override
    public void startDocument() throws SAXException {
        errorOccurrences = new HashMap<String,Integer>();
        orderStates = new HashMap<String,String>();
        linkedOrders = new ArrayList<String>();
    }

    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
        //<editor-fold defaultstate="collapsed" desc="Avarage salary">
        System.out.println("=========================");
        System.out.println("Average salary: "+salarySum/employeeCount);
        System.out.println("Total: " + salarySum);
        System.out.println("=========================\n\n");
        //</editor-fold>
        
        //<editor-fold defaultstate="collapsed" desc="The most frequent errors">
        Integer max = Integer.MIN_VALUE;
        for(String key : errorOccurrences.keySet()){
            Integer val = errorOccurrences.get(key);
            if(val > max){
                max = val;
            }
        }
        System.out.println("=========================");
        System.out.println("Most frequent errors:");
        for(String key : errorOccurrences.keySet()){
            Integer val = errorOccurrences.get(key);
            if(val.equals(max)){
                System.out.println("-------------------");
                System.out.println(key);
                System.out.println("------------------- "+val+" time(s)");
            }
        }
        System.out.println("=========================\n\n");
        //</editor-fold>
        
        //<editor-fold defaultstate="collapsed" desc="Reffered orders">
        System.out.println("=========================");
        System.out.println("Following orders are neither canceled nor finished and were linked at least once from a message:");
        for(String id : linkedOrders){
            System.out.println(id);
        }
        System.out.println("=========================\n\n");
        //</editor-fold>
    }

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        
        //we had a switch here originally but since the XML check system runs on Java 6 or whatever...
        if(localName.equals("employee")){
            employeeCount++;
            String salary = atts.getValue("salary");
            // the salary is 15000 by default
            salarySum += (salary == null ? 15000 : Integer.parseInt(salary));
        }
        if(localName.equals("error")){
            inError = true;
        }
        if(localName.equals("order")){
            String id = atts.getValue("orderId");
            String state = atts.getValue("state");
            orderStates.put(id, state);
        }
        if(localName.equals("link")){
            String refId = atts.getValue("ref");
            String orderState = orderStates.get(refId);
            if(     orderState != null && // the link doesn`t refer to a order
                    !orderState.equals("finished") &&
                    !orderState.equals("canceled")){
                linkedOrders.add(refId);
            }
        }
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if(localName.equals("error")){
            inError = false;
        }
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        if(inError){
            char[] errorChA = new char[length];
            System.arraycopy(chars, start, errorChA, 0, length);
            String error = new String(errorChA);
            Integer current = errorOccurrences.get(error); 
            if(current != null){
                errorOccurrences.put(error, current+1);
            }
            else{
                errorOccurrences.put(error, 1);
            }
        }
    }

    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {}

    @Override
    public void endPrefixMapping(String prefix) throws SAXException {}

    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {}

    @Override
    public void processingInstruction(String target, String data) throws SAXException {}

    @Override
    public void skippedEntity(String name) throws SAXException {}
}
