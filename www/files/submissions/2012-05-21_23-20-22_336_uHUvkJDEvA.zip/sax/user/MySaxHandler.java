/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * @author Jakub
 * 
 * Trida spocita maximalni a prumernou hloubku, pocet jednotlivych elementu, celkovy pocet elementu, celkovy pocet atributu, pocet jednotlivych atributu,
 * maximalni a prumernou delku nazvu elementu a atributu, pocet elementu s textovym obsahem, atributy a podelementy.
 */
public class MySaxHandler extends DefaultHandler { // overrides of DefaultHandler methods

    private static final String filein="../data.xml";
    private Map<String, Integer> attributesCount;
    private Map<String, Integer> elementCount;
    private ArrayList<String> elements;
    private int maxDepth;
    private int avrgDepth;
    private int elementWithText;
    private int elementWithAttributs;
    private int elementWithElements;
    private int elementsCount, attributeCount, elementNameMaxLength, elementNameAvgLength;
    private String nextElement="";
    
    
    /**
     * Konstruktor tridy
     */
    
    public MySaxHandler() {
        attributesCount=new HashMap<String,Integer>();
        elementCount=new HashMap<String,Integer>();
        elementWithText=0;
        elementWithElements=0;
        elementWithAttributs=0;
        elements=new ArrayList<String>();
        maxDepth=0;
        elementsCount=0;
        avrgDepth=0;
        attributeCount=0;
        elementNameAvgLength=0;
        elementNameMaxLength=0;
    
    }

    /**
     *
     */
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        ++elementWithText;
    }

    @Override
    public void endDocument() throws SAXException {
        showStats();
    }
    
    /**
     * Metoda vypise statistiku daneho xml souboru
     */
    protected void showStats(){
        int attributeNameMaxLength=0, attributeNameAvgLength=0;
        for(Map.Entry<String, Integer> e: attributesCount.entrySet()){
            
            System.out.println("Attribute " + e.getKey() + " se opakuje " + e.getValue() + "x" );
            if(attributeNameMaxLength < e.getKey().length()){
                attributeNameMaxLength=e.getKey().length();
            }
            
            attributeNameAvgLength+= e.getKey().length() * e.getValue();
        }
        System.out.println("ATTRIBUTES count: " + attributeCount);
        
        for(Map.Entry<String, Integer> e :elementCount.entrySet()){
            if(e.getKey().length() > elementNameMaxLength){
                elementNameMaxLength=e.getKey().length();
                
            }
            elementNameAvgLength+=e.getKey().length() * e.getValue();
            System.out.println("Element " + e.getKey() + " se opakuje " + e.getValue());
        }
       
        System.out.println("Prumerna delka jmena atributu je: " + attributeNameAvgLength/attributeCount);
        System.out.println("Maximalni delka jmena atributu je: " + attributeNameMaxLength);
        System.out.println("Prumerna delka jmena elementu: " + elementNameAvgLength/elementsCount );
        System.out.println("Maximalni delka jmena elementu: " + elementNameMaxLength);
        System.out.println("Pocet elementu s textovym obsahem: " + elementWithText);
        System.out.println("Pocet elementu s atributy: " + elementWithAttributs);
        System.out.println("Pocet elementu s podelementy: " + (elementsCount-elementWithElements));
        System.out.println("ELEMENTS count: " + elementsCount );
        System.out.println("AVG depth: " + avrgDepth/elementsCount);
        System.out.println("MAX deptj: " + maxDepth);
        System.out.println("End Processing");
    }

    @Override
    public void startDocument() throws SAXException {
        System.out.println("Start processing");
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        int count=0;
        nextElement=qName;
        for (int i = 0; i < attributes.getLength(); i++) {
            if(attributesCount.containsKey(attributes.getQName(i))){
                count= attributesCount.get(attributes.getQName(i));
                attributesCount.remove(attributes.getQName(i));
                attributesCount.put(attributes.getQName(i), ++count);
            }
            else{
            attributesCount.put(attributes.getQName(i), 1);
            }
            
            ++attributeCount;
        }
        if(attributes.getLength()!=0){
            ++elementWithAttributs;
        }
        
        elements.add(qName);
        if(elementCount.containsKey(qName)){
            count=elementCount.get(qName);
            elementCount.remove(qName);
            elementCount.put(qName, ++count);
        }else{
        elementCount.put(qName, 1);
                }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        
        if(nextElement.equals(qName)){
            ++elementWithElements;
            
        }
        nextElement="";
        
        if(elements.contains(qName)){
            int depth=elements.size()-1;
            if(depth>maxDepth){
            maxDepth=depth;
            }
            
            ++elementsCount;
            avrgDepth+=depth;
            
            elements.remove(qName);
        }
        
    }
    
    
    
    
    
}