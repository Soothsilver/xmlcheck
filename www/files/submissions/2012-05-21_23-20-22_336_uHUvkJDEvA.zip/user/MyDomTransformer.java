/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

/**
 *
 * @author Jakub
 */
import org.w3c.dom.Document; 
public class MyDomTransformer { 
    public void transform (Document xmlDocument) { 
        // code transforming xmlDocument object // (method works on the object itself - no return value) 
    } 
}