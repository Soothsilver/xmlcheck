/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;


import java.util.LinkedList;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.*;


/**
 *
 * Trida slouzi k prevedeni XML dokumentu
 * Elementy pretransformuje do opacneho poradi, dale prevede atributy do elementu a nasledne jeste text v elementech kratsi nez 5 do atributu text.
 * @author Jakub
 */
public class MyDomTransformer { 
    private Document d;
    private Element root;
  
    
    /**
     *Konstruktor ktery nic nedela 
     */
    public MyDomTransformer(){
        
    }
    /**
     *Metoda transformuje XML dokument
     * dojde k odstraneni nepotrebnych mezer
     * @param xmlDocument Vstupni xml dokument jenz ma byt transformovan
     * @throws XPathExpressionException
     */
    public void transform (Document xmlDocument) throws XPathExpressionException { 
        // code transforming xmlDocument object // (method works on the object itself - no return value) 
        
        
        XPathFactory xpathFactory=XPathFactory.newInstance();
        XPathExpression xpathExp= xpathFactory.newXPath().compile(
                "//text()[normalize-space(.)=' ']");
        NodeList emptyTextNodes=(NodeList) xpathExp.evaluate(xmlDocument, XPathConstants.NODESET);
        
        for (int i = 0; i < emptyTextNodes.getLength(); i++) {
            Node emptyTextNode= emptyTextNodes.item(i);
            emptyTextNode.getParentNode().removeChild(emptyTextNode);
            
        }
        
        d=xmlDocument;
        root=d.getDocumentElement();
        
        //System.out.println(root.getNodeName());
        reversePosition();
        attributeToElements();
        textToAttributes();
        
        
        
    }
    
    /**
     * Metoda zavola rekurzivni otoceni poradi elementu
     */
    void reversePosition(){
        
       reversePosition(root);
 
    }
    
    /**
     * Metoda zavola rekurzivni prevedeni atributu do elementu
     */
    
    void attributeToElements(){
    
        attributeToElements(root);
    
    }
    /**
     * Metoda vola rekurzivni prevedeni textoveho obsahu mensiho nez 5 znaku do atributu text daneho elementu
     */
    void textToAttributes(){
        textToAttributes(root);
        
    }
    
    /**
     * Metoda projde rekurzivne po jednotlivych hloubkach strom xml dokumentu a prevede textovy obsah elementu do atributu
     * @param item root Element, je na nem vyvolana rekurze
     */
    private void textToAttributes(Element item){
       
        if(item.hasChildNodes()){
            NodeList nl=item.getChildNodes();
            
            
            for(int i=0; i< nl.getLength(); i++){
               
                
                if( nl.getLength()==1 && nl.item(i).getNodeValue()!=null && !"".equals(nl.item(i).getNodeValue().trim()) && nl.item(i).getNodeValue().length() <5){
                    
                    
                    
                    Element e=(Element)item;
                    e.setAttribute("text", nl.item(i).getNodeValue().trim());
                   // e.setTextContent("");
                    e.getFirstChild().setNodeValue("");
                    
                    
                }
                if(nl.item(i).getNodeType()==Node.ELEMENT_NODE){
                textToAttributes((Element)nl.item(i));}
            
            }
            
        }
    
    }
    
    /**
     * Metoda prevede atributy na elementy
     * @param item root element na kterem je volana rekurze
     */
    private void attributeToElements(Node item){
    

        if(item.hasChildNodes()){
            NodeList nl= item.getChildNodes();
            for(int j=0; j < nl.getLength();j++){
                Node node= nl.item(j);
                if(node.hasAttributes()){
                NamedNodeMap attr=node.getAttributes();
                
                LinkedList<Node> attributes=new LinkedList<Node>();
                for (int i = 0; i < attr.getLength(); i++) {
                    attributes.addFirst(attr.item(i));
                    
                }
                for(Node atr:attributes){
                    
                    Node child=d.createElement(atr.getNodeName());
                    
                    child.setTextContent(atr.getNodeValue());
                    node.appendChild(child);
                    try{
                    attr.removeNamedItem(atr.getNodeName().trim());
                    }catch(DOMException e){
                        e.printStackTrace();
                    }
                    
                }
                attributes.clear();
                
            }
                
            attributeToElements(node);
            }
        }
        
    }
    
    
    /**
     * Metoda obrati pozice elementu na dane urovni
     * @param item  Root element na kterem je volana rekurze
     */
    private void reversePosition(Node item){
        //System.out.println("reverse " + item.getNodeName());
        NodeList nodelist= item.getChildNodes();
        LinkedList<Node> nodes= new LinkedList<Node>();
        for (int i = 0; i < nodelist.getLength(); i++) {
            nodes.addFirst(nodelist.item(i));
            
        }
        
        for (Node node:nodes){
        
            item.appendChild(item.removeChild(node));
            
            reversePosition(node);
        }
        
    }
}