package user;

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;

public class MySaxHandler extends DefaultHandler {
   // override metod DefaultHandleru
  
  int pocetElementu = 0;
  int pocetAtributu = 0;
  
  public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
    pocetElementu++;
    pocetAtributu+=atts.getLength();
  }

  public void endDocument() throws SAXException {
    System.out.println("Pocet elementu : "+String.valueOf(pocetElementu));        
    System.out.println("Pocet atributu : "+String.valueOf(pocetAtributu));        
  }
}