package user;

import org.w3c.dom.*;

public class MyDomTransformer {
  
  public void transform (Document xmlDocument) {
     // libovolne transformace objektu 'xmlDocument'
     // (metoda pracuje primo na objektu, nic nevraci)
    Element root = xmlDocument.getDocumentElement();
    transformElement(xmlDocument,root);
  }
  
  private void transformElement(Document doc,Element e)
  {
    // prevedeni atributu na elementy
    NamedNodeMap attr = e.getAttributes();
    for (int i=attr.getLength()-1;i>=0;i--)
    {
      Node it = attr.item(i);
      Node a = doc.createElement(it.getNodeName());
      a.appendChild(doc.createTextNode(it.getNodeValue()));
      e.appendChild(a);
    }
    // smazani atributu
    while (attr.getLength()>0)
      e.removeAttributeNode((Attr)attr.item(0));
    // rekurze
    NodeList l = e.getChildNodes();
    for (int i=0;i<l.getLength();i++)
    {
      Node n = l.item(i);
      if (n instanceof Element)
      {
        Element x = (Element)n;
        transformElement(doc,x);
      }
    }
  }
}