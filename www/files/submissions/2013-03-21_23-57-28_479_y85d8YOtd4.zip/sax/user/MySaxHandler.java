package user;

import java.util.LinkedList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler
{
	//TODO milestone POSITION TOKENS
	Locator locator;
	String cursor						= "";
	String namespace					= "";

    //TODO milestone Helper Classes
    Zakaznik		_zakaznik			= null;
    Evidence		_evidence			= null;
    Faktura			_faktura			= null;
    Zbozi			_zbozi				= null;
    DPH				_dph				= null;
    Banka			_banka				= null;
    Ekonom			_ekonom				= null;
    Odberatel		_odberatel			= null;
    Dodavatel		_dodavatel			= null;
	    
    public void setDocumentLocator(Locator locator)
    { this.locator = locator; }

    public void startDocument() throws SAXException
    {    
    	cursor = "/";
    }
	    
    public void endDocument() throws SAXException
    { }
	    
	public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
	{
		if (namespace.length() > 0) namespace = "";
		cursor += localName + "/";

		if (cursor.equals("/databaze/zakaznici/zakaznik/"))																									_zakaznik	= new Zakaznik();
		if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/"))																						_evidence	= new Evidence();
		if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/"))																		_faktura	= new Faktura();
		if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/"))										_zbozi		= new Zbozi();
		if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/"))									_dph		= new DPH();
		if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/informace_ekonom/"))				_ekonom		= new Ekonom();
		if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/informace_ekonom/penezni_ustav/"))	_banka		= new Banka();
		if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/odberatele/odberatel/"))																	_odberatel	= new Odberatel();
		if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/dodavatele/dodavatel/"))																	_dodavatel	= new Dodavatel();
		
		for (int i = 0; i < atts.getLength(); i++)
		{
			String name		= atts.getQName(i);
			String value	= atts.getValue(i);
				
			//ZBOZI
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/")  && name.equalsIgnoreCase("cislo"))																							_faktura.cislo				= value;
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/") && name.equalsIgnoreCase("oznaceni_dodavky"))											_zbozi.oznaceni_dodavky		= value;
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/") && name.equalsIgnoreCase("ks"))															_zbozi.ks					= value;
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/") && name.equalsIgnoreCase("cena_za_ks"))													_zbozi.cena_za_ks			= value;
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/") && name.equalsIgnoreCase("sleva"))														_zbozi.sleva				= value;
				
			//DPH
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/") && name.equalsIgnoreCase("hodnota"))													_dph.hodnota				= value;
				
			//BANKA
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/informace_ekonom/penezni_ustav/banka/nazev/") && name.equalsIgnoreCase("nazev"))		_banka.nazev				= value;
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/informace_ekonom/penezni_ustav/banka/kod_banky/") && name.equalsIgnoreCase("kod"))		_banka.kod					= value;
			
			//FIXME PCDATA
			//FIXME
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/informace_ekonom/penezni_ustav/cislo_uctu/") && name.equalsIgnoreCase("kod"))			_banka.cislo_uctu			= value;
			//FIXME
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/informace_ekonom/penezni_ustav/specificky_symbol/") && name.equalsIgnoreCase("kod"))	_banka.specificky_symbol	= value;
			//FIXME
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/informace_ekonom/forma_uhrady/") && name.equalsIgnoreCase("kod"))						_banka.kod					= value;
			//FIXME
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/informace_ekonom/casove_udaje/splatnost/") && name.equalsIgnoreCase("kod"))				_banka.kod					= value;
			//FIXME
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/informace_ekonom/casove_udaje/vystaveni/") && name.equalsIgnoreCase("kod"))				_banka.kod					= value;
			//FIXME
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/informace_ekonom/casove_udaje/odeslani/") && name.equalsIgnoreCase("kod"))				_banka.kod					= value;
				
			//ODBERATEL
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/odberatele/odberatel/") && name.equalsIgnoreCase("klic"))																						_odberatel.klic				= value;
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/odberatele/odberatel/identifikace/") && name.equalsIgnoreCase("platce"))																		_odberatel.platce			= value;
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/odberatele/odberatel/odberatel_faktury/odebrana_faktura/") && name.equalsIgnoreCase("cislo_faktury"))											_odberatel.faktury.add(value);
				
			//FIXME
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/odberatele/odberatel/identifikace/ICO/") && name.equalsIgnoreCase("platce"))																	_odberatel.platce			= value;
			//FIXME
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/odberatele/odberatel/identifikace/DIC/") && name.equalsIgnoreCase("platce"))																	_odberatel.platce			= value;
			//FIXME
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/odberatele/odberatel/identifikace/firma/") && name.equalsIgnoreCase("platce"))																	_odberatel.platce			= value;
			//FIXME
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/odberatele/odberatel/identifikace/adresa/ulice/") && name.equalsIgnoreCase("platce"))															_odberatel.platce			= value;
			//FIXME
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/odberatele/odberatel/identifikace/adresa/cp/") && name.equalsIgnoreCase("platce"))																_odberatel.platce			= value;
			//FIXME
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/odberatele/odberatel/identifikace/adresa/mesto/") && name.equalsIgnoreCase("platce"))															_odberatel.platce			= value;
			//FIXME
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/odberatele/odberatel/identifikace/adresa/psc/") && name.equalsIgnoreCase("platce"))															_odberatel.platce			= value;
			//FIXME
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/odberatele/odberatel/identifikace/adresa/stat/") && name.equalsIgnoreCase("platce"))															_odberatel.platce			= value;
			//FIXME
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/odberatele/odberatel/identifikace/tel/") && name.equalsIgnoreCase("platce"))																	_odberatel.platce			= value;
				
			//DODAVATEL
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/dodavatele/dodavatel/") && name.equalsIgnoreCase("klic"))																						_dodavatel.klic				= value;
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/dodavatele/dodavatel/identifikace/") && name.equalsIgnoreCase("platce"))																		_dodavatel.platce			= value;
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/dodavatele/dodavatel/odberatel_faktury/odebrana_faktura/") && name.equalsIgnoreCase("cislo_faktury"))											_dodavatel.faktury.add(value);
				
			//FIXME
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/dodavatele/dodavatel/identifikace/ICO/") && name.equalsIgnoreCase("platce"))																	_dodavatel.platce			= value;
			//FIXME
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/dodavatele/dodavatel/identifikace/DIC/") && name.equalsIgnoreCase("platce"))																	_dodavatel.platce			= value;
			//FIXME
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/dodavatele/dodavatel/identifikace/firma/") && name.equalsIgnoreCase("platce"))																	_dodavatel.platce			= value;
			//FIXME
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/dodavatele/dodavatel/identifikace/adresa/ulice/") && name.equalsIgnoreCase("platce"))															_dodavatel.platce			= value;
			//FIXME
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/dodavatele/dodavatel/identifikace/adresa/cp/") && name.equalsIgnoreCase("platce"))																_dodavatel.platce			= value;
			//FIXME
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/dodavatele/dodavatel/identifikace/adresa/mesto/") && name.equalsIgnoreCase("platce"))															_dodavatel.platce			= value;
			//FIXME
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/dodavatele/dodavatel/identifikace/adresa/psc/") && name.equalsIgnoreCase("platce"))															_dodavatel.platce			= value;
			//FIXME
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/dodavatele/dodavatel/identifikace/adresa/stat/") && name.equalsIgnoreCase("platce"))															_dodavatel.platce			= value;
			//FIXME
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/dodavatele/dodavatel/identifikace/tel/") && name.equalsIgnoreCase("platce"))																	_dodavatel.platce			= value;	
		}
	}
	
	public void endElement(String uri, String localName, String qName) throws SAXException
	{
		if (cursor.equals("/databaze/zakaznici/zakaznik/"))																									zakaznici.add(_zakaznik);
		if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/"))																						_zakaznik.evidence.add(_evidence);
		if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/"))																		_evidence.faktury.add(_faktura);
		if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/"))										_faktura.informace_zbozi.add(_zbozi);
		if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/"))									_zbozi.dane.add(_dph);
		if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/informace_ekonom/penezni_ustav/"))	_ekonom.banky.add(_banka);
		if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/informace_ekonom/"))				_faktura.informace_ekonom.add(_ekonom);
			
		if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/odberatele/odberatel/"))																	_evidence.odberatele.add(_odberatel);
			
		if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/dodavatele/dodavatel/"))																	_evidence.dodavatele.add(_dodavatel);
			
		cursor = cursor.substring(0, cursor.lastIndexOf("/"));
		cursor = cursor.substring(0, cursor.lastIndexOf("/") + 1);
	}
	    
	public void characters(char[] ch, int start, int length) throws SAXException
	{
        // ...
	}
	    
	public void startPrefixMapping(String prefix, String uri) throws SAXException
	{
		//FIXME unused
		namespace += (prefix.length() == 0)?(" xmlns=\"" + uri + "\""):(" xmlns:" + prefix + "=\"" + uri + "\"");    
	}

	public void endPrefixMapping(String prefix) throws SAXException
	{
	        // ...
	}

	public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException
	{    
		// ...
	}

	public void processingInstruction(String target, String data) throws SAXException
	{  
		//...       
	}

	public void skippedEntity(String name) throws SAXException
	{
		// ...
	}
	
	//FIXME milestone HELPER CLASSES /////////////////////////////////////////////////////////////// 

	LinkedList<Zakaznik> zakaznici	= new LinkedList<Zakaznik>();

	class Evidence
	{
		LinkedList<Faktura> faktury			= new LinkedList<Faktura>();
		LinkedList<Odberatel> odberatele	= new LinkedList<Odberatel>();
		LinkedList<Dodavatel> dodavatele	= new LinkedList<Dodavatel>();
	}
	    
	class Odberatel
	{
		LinkedList<String> faktury = new LinkedList<String>();
		String klic			= "";
		String platce		= "";
		String ico			= "";
		String dic			= "";
		String firma		= "";
		String ulice		= "";
		String cp			= "";
		String mesto		= "";
		String psc			= "";
		String stat			= "";
		String tel			= "";
	}

	class Dodavatel
	{
		LinkedList<String> faktury	= new LinkedList<String>();
		String klic					= "";
		String platce				= "";
		String ico					= "";
		String dic					= "";
		String firma				= "";
		String ulice				= "";
		String cp					= "";
		String mesto				= "";
		String psc					= "";
		String stat					= "";
		String tel					= "";
	}
	    
	class Faktura
	{
		String cislo						= "";
		String zpusob_dopravy				= "";
		String cislo_objednavky				= "";
		LinkedList<Zbozi> informace_zbozi	= new LinkedList<Zbozi>();
		LinkedList<Ekonom> informace_ekonom	= new LinkedList<Ekonom>();
    }

	class Ekonom
	{
		LinkedList<Banka> banky	= new LinkedList<Banka>();
		String forma_uhrady		= "";
		String splatnost		= "";
		String vystaveni		= "";
		String odeslani			= "";
	}
	    
	class Banka
	{
		String nazev				= "";
		String kod					= "";
		String cislo_uctu			= "";
		String specificky_symbol	= "";
	}
	    
	class Zbozi
	{
		String oznaceni_dodavky = "";
		String ks				= "";
		String cena_za_ks		= "";
		String sleva			= "";
		LinkedList<DPH> dane	= new LinkedList<DPH>();
	}
	    
	class DPH
	{
		String hodnota="";
	}
	    
	class Zakaznik
	{
		LinkedList<Evidence> evidence = new LinkedList<Evidence>();
	}
	    
	//TODO milestone file-end
	
	//TODO milestone statisic methods
	
	
	public int getNumberOfZakaznici()
	{ return this.zakaznici.size(); }
	
	public int getPrumernaEvidenceNaZakaznika()
	{
		int evidence=0;
		for(Zakaznik z : zakaznici)
				evidence+=z.evidence.size();
		
		return (evidence==0)?0:((int)((float)evidence/(float)getNumberOfZakaznici()));	
	}
	
	public List<String> getDodavateleID()
	{
		LinkedList<String> ids = new LinkedList<String>();
		
		for(Zakaznik z : zakaznici)
			for(Evidence e : z.evidence)
				for(Dodavatel d : e.dodavatele)
					ids.add(d.klic);
		return ids;	
	}
	
	public List<String> getOdberateleID()
	{
		LinkedList<String> ids = new LinkedList<String>();
		
		for(Zakaznik z : zakaznici)
			for(Evidence e : z.evidence)
				for(Odberatel d : e.odberatele)
					ids.add(d.klic);
		return ids;	
	}
	
	public int getAvgFakturNaZakaznika()
	{
		int faktury=0;
		
		for(Zakaznik z : zakaznici)
			for(Evidence e : z.evidence)
				faktury+=e.faktury.size();
					
		return (faktury==0)?0:(((int)((float)faktury/(float)getNumberOfZakaznici())));	
	}
}