package user;

public class MyDomTransformer
{
	//FIXME written in rush
	public void transform (org.w3c.dom.Document xmlDocument)
	{
		if(xmlDocument==null)
		{
			System.out.println("Document is NULL");
			return;
		}

		try
		{
			System.out.println("transforming "+xmlDocument);
			System.out.println("### BEGIN");
			
			System.out.println("### >>> Mapping XML to Helper classes");
		
			org.xml.sax.XMLReader parser		= org.xml.sax.helpers.XMLReaderFactory.createXMLReader();
			SaxTransfHandlerDeepCopy handler	= new SaxTransfHandlerDeepCopy();
			
			parser.setContentHandler(handler);
			parser.parse(xmlDocument.getBaseURI());
		
			System.out.println("### >>> Mapped");
		
			System.out.println("### >>> Calculating prep");
		
			int odberatele_sum	= 0;
			int zakaznici_sum	= 0;
			int dodavatele_sum	= 0;
		
			for(SaxTransfHandlerDeepCopy.Zakaznik z : handler.zakaznici) for(SaxTransfHandlerDeepCopy.Evidence e : z.evidence)
			{
				odberatele_sum += e.odberatele.size();
				dodavatele_sum += e.dodavatele.size();
			}
			
			zakaznici_sum=handler.zakaznici.size();
		
			System.out.println("### >>>>> Counted number of \"Zakaznici\" its "+zakaznici_sum);
			System.out.println("### >>>>> Counted number of \"Odberatele\" its "+odberatele_sum);
			System.out.println("### >>>>> Counted number of \"Dodavatele\" its "+dodavatele_sum);

			System.out.println("### >>> Creating Elements");
		
			org.w3c.dom.Element info			= xmlDocument.createElement("Info");
			xmlDocument.appendChild(info);
			
			org.w3c.dom.Element no_odberatele	= xmlDocument.createElement("PocetOdberatelu");
			org.w3c.dom.Element no_zakaznici	= xmlDocument.createElement("PocetZakazniku");
			org.w3c.dom.Element no_dodavatele	= xmlDocument.createElement("PocetDodavatelu");
			
			System.out.println("### >>> Creating Attributes");
			
			org.w3c.dom.Attr a1 = xmlDocument.createAttribute("pocet");
			a1.setValue(""+odberatele_sum);
			no_odberatele.setAttributeNode(a1);
			
			org.w3c.dom.Attr a2 = xmlDocument.createAttribute("pocet");
			a2.setValue(""+dodavatele_sum);
			no_dodavatele.setAttributeNode(a2);
			
			org.w3c.dom.Attr a3 = xmlDocument.createAttribute("pocet");
			a3.setValue(""+zakaznici_sum);
			no_zakaznici.setAttributeNode(a3);
			
			System.out.println("### >>> Appending new Elements to DOM");
			info.appendChild(no_dodavatele);
			info.appendChild(no_zakaznici);
			info.appendChild(no_odberatele);
		
			System.out.println("### >>> Injectiong Elements to DOM");
			org.w3c.dom.NodeList inj = xmlDocument.getElementsByTagName("dodavatel_faktury");
			
			for(int i=0; i<inj.getLength(); i++)
			{
				inj.item(i).appendChild(createFaktura("F_4",xmlDocument));
				inj.item(i).appendChild(createFaktura("F_5",xmlDocument));
				inj.item(i).appendChild(createFaktura("F_6",xmlDocument));
				inj.item(i).appendChild(createFaktura("F_7",xmlDocument));
				inj.item(i).appendChild(createFaktura("F_8",xmlDocument));
			}
			
			System.out.println("### >>> Sorting XML DOC from: databaze to depth 7 ascenting");
			
			//SORTING
			sortChildNodes(xmlDocument.getElementsByTagName("databaze").item(0),false,7,null);
			
			//FIXME in future possible whitespace removal & trimming
			
			System.out.println("### >>> Done");
		}
		catch (java.io.IOException e)		{ e.printStackTrace();					}
		catch (org.xml.sax.SAXException e)	{ e.printStackTrace();					}
		finally								{ System.out.println("### FINISHED");	}
		
	}

	//TODO milestone helper method
	
	static org.w3c.dom.Element createFaktura(String id,org.w3c.dom.Document doc)
	{
		org.w3c.dom.Element dodana_faktura	= doc.createElement("dodana_faktura");
		org.w3c.dom.Attr cislo_faktury = doc.createAttribute("cislo_faktury");
		cislo_faktury.setValue("F_5");
		dodana_faktura.setAttributeNode(cislo_faktury);
		return dodana_faktura;
	}
	
	//TODO milestone recursive sorter
	
	public static void sortChildNodes(org.w3c.dom.Node node, boolean descending, int depth, java.util.Comparator<Object> comparator)
	{
		java.util.List<Object> nodes		= new java.util.ArrayList<Object>();
		org.w3c.dom.NodeList childNodeList	= node.getChildNodes();
		
		if (depth > 0 && childNodeList.getLength() > 0)
		{
			for (int i = 0; i < childNodeList.getLength(); i++)
			{
				org.w3c.dom.Node tNode = childNodeList.item(i);
				sortChildNodes(tNode, descending, depth - 1, comparator);
				
				if ((!(tNode instanceof org.w3c.dom.Text)) || (tNode instanceof org.w3c.dom.Text && ((org.w3c.dom.Text) tNode).getTextContent().trim().length() > 1))
					nodes.add(tNode);
				
			}
			java.util.Comparator<Object> comp = (comparator != null) ? comparator : new java.util.Comparator<Object>() {  public int compare(Object arg0, Object arg1){return ((org.w3c.dom.Node) arg0).getNodeName().compareTo( ((org.w3c.dom.Node) arg1).getNodeName()); } };
			java.util.Collections.sort(nodes, (descending)?java.util.Collections.reverseOrder(comp):comp);

			for (java.util.Iterator<Object> iter = nodes.iterator(); iter.hasNext();)
				node.appendChild((org.w3c.dom.Node) iter.next());
		}
	}
	
	//TODO milestone SAX handler for precache 
	
	static final class SaxTransfHandlerDeepCopy extends org.xml.sax.helpers.DefaultHandler
	{
		//TODO milestone POSITION TOKENS
		org.xml.sax.Locator locator;
		String cursor						= "";
		String namespace					= "";

	    //TODO milestone Helper Classes
	    Zakaznik		_zakaznik			= null;
	    Evidence		_evidence			= null;
	    Faktura			_faktura			= null;
	    Zbozi			_zbozi				= null;
	    DPH				_dph				= null;
	    Banka			_banka				= null;
	    Ekonom			_ekonom				= null;
	    Odberatel		_odberatel			= null;
	    Dodavatel		_dodavatel			= null;
		    
	    public void setDocumentLocator(org.xml.sax.Locator locator)
	    { this.locator = locator; }

	    public void startDocument() throws org.xml.sax.SAXException
	    {    
	    	cursor = "/";
	    }
		    
	    public void endDocument() throws org.xml.sax.SAXException
	    { }
		    
		public void startElement(String uri, String localName, String qName, org.xml.sax.Attributes atts) throws org.xml.sax.SAXException
		{
			if (namespace.length() > 0) namespace = "";
			cursor += localName + "/";

			if (cursor.equals("/databaze/zakaznici/zakaznik/"))																									_zakaznik	= new Zakaznik();
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/"))																						_evidence	= new Evidence();
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/"))																		_faktura	= new Faktura();
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/"))										_zbozi		= new Zbozi();
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/"))									_dph		= new DPH();
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/informace_ekonom/"))				_ekonom		= new Ekonom();
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/informace_ekonom/penezni_ustav/"))	_banka		= new Banka();
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/odberatele/odberatel/"))																	_odberatel	= new Odberatel();
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/dodavatele/dodavatel/"))																	_dodavatel	= new Dodavatel();
			
			for (int i = 0; i < atts.getLength(); i++)
			{
				String name		= atts.getQName(i);
				String value	= atts.getValue(i);
					
				//ZBOZI
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/")  && name.equalsIgnoreCase("cislo"))																							_faktura.cislo				= value;
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/") && name.equalsIgnoreCase("oznaceni_dodavky"))											_zbozi.oznaceni_dodavky		= value;
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/") && name.equalsIgnoreCase("ks"))															_zbozi.ks					= value;
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/") && name.equalsIgnoreCase("cena_za_ks"))													_zbozi.cena_za_ks			= value;
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/") && name.equalsIgnoreCase("sleva"))														_zbozi.sleva				= value;
					
				//DPH
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/") && name.equalsIgnoreCase("hodnota"))													_dph.hodnota				= value;
					
				//BANKA
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/informace_ekonom/penezni_ustav/banka/nazev/") && name.equalsIgnoreCase("nazev"))		_banka.nazev				= value;
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/informace_ekonom/penezni_ustav/banka/kod_banky/") && name.equalsIgnoreCase("kod"))		_banka.kod					= value;
				
				//FIXME PCDATA
				//FIXME
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/informace_ekonom/penezni_ustav/cislo_uctu/") && name.equalsIgnoreCase("kod"))			_banka.cislo_uctu			= value;
				//FIXME
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/informace_ekonom/penezni_ustav/specificky_symbol/") && name.equalsIgnoreCase("kod"))	_banka.specificky_symbol	= value;
				//FIXME
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/informace_ekonom/forma_uhrady/") && name.equalsIgnoreCase("kod"))						_banka.kod					= value;
				//FIXME
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/informace_ekonom/casove_udaje/splatnost/") && name.equalsIgnoreCase("kod"))				_banka.kod					= value;
				//FIXME
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/informace_ekonom/casove_udaje/vystaveni/") && name.equalsIgnoreCase("kod"))				_banka.kod					= value;
				//FIXME
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/informace_ekonom/casove_udaje/odeslani/") && name.equalsIgnoreCase("kod"))				_banka.kod					= value;
					
				//ODBERATEL
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/odberatele/odberatel/") && name.equalsIgnoreCase("klic"))																						_odberatel.klic				= value;
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/odberatele/odberatel/identifikace/") && name.equalsIgnoreCase("platce"))																		_odberatel.platce			= value;
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/odberatele/odberatel/odberatel_faktury/odebrana_faktura/") && name.equalsIgnoreCase("cislo_faktury"))											_odberatel.faktury.add(value);
					
				//FIXME
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/odberatele/odberatel/identifikace/ICO/") && name.equalsIgnoreCase("platce"))																	_odberatel.platce			= value;
				//FIXME
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/odberatele/odberatel/identifikace/DIC/") && name.equalsIgnoreCase("platce"))																	_odberatel.platce			= value;
				//FIXME
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/odberatele/odberatel/identifikace/firma/") && name.equalsIgnoreCase("platce"))																	_odberatel.platce			= value;
				//FIXME
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/odberatele/odberatel/identifikace/adresa/ulice/") && name.equalsIgnoreCase("platce"))															_odberatel.platce			= value;
				//FIXME
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/odberatele/odberatel/identifikace/adresa/cp/") && name.equalsIgnoreCase("platce"))																_odberatel.platce			= value;
				//FIXME
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/odberatele/odberatel/identifikace/adresa/mesto/") && name.equalsIgnoreCase("platce"))															_odberatel.platce			= value;
				//FIXME
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/odberatele/odberatel/identifikace/adresa/psc/") && name.equalsIgnoreCase("platce"))															_odberatel.platce			= value;
				//FIXME
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/odberatele/odberatel/identifikace/adresa/stat/") && name.equalsIgnoreCase("platce"))															_odberatel.platce			= value;
				//FIXME
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/odberatele/odberatel/identifikace/tel/") && name.equalsIgnoreCase("platce"))																	_odberatel.platce			= value;
					
				//DODAVATEL
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/dodavatele/dodavatel/") && name.equalsIgnoreCase("klic"))																						_dodavatel.klic				= value;
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/dodavatele/dodavatel/identifikace/") && name.equalsIgnoreCase("platce"))																		_dodavatel.platce			= value;
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/dodavatele/dodavatel/odberatel_faktury/odebrana_faktura/") && name.equalsIgnoreCase("cislo_faktury"))											_dodavatel.faktury.add(value);
					
				//FIXME
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/dodavatele/dodavatel/identifikace/ICO/") && name.equalsIgnoreCase("platce"))																	_dodavatel.platce			= value;
				//FIXME
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/dodavatele/dodavatel/identifikace/DIC/") && name.equalsIgnoreCase("platce"))																	_dodavatel.platce			= value;
				//FIXME
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/dodavatele/dodavatel/identifikace/firma/") && name.equalsIgnoreCase("platce"))																	_dodavatel.platce			= value;
				//FIXME
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/dodavatele/dodavatel/identifikace/adresa/ulice/") && name.equalsIgnoreCase("platce"))															_dodavatel.platce			= value;
				//FIXME
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/dodavatele/dodavatel/identifikace/adresa/cp/") && name.equalsIgnoreCase("platce"))																_dodavatel.platce			= value;
				//FIXME
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/dodavatele/dodavatel/identifikace/adresa/mesto/") && name.equalsIgnoreCase("platce"))															_dodavatel.platce			= value;
				//FIXME
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/dodavatele/dodavatel/identifikace/adresa/psc/") && name.equalsIgnoreCase("platce"))															_dodavatel.platce			= value;
				//FIXME
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/dodavatele/dodavatel/identifikace/adresa/stat/") && name.equalsIgnoreCase("platce"))															_dodavatel.platce			= value;
				//FIXME
				if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/dodavatele/dodavatel/identifikace/tel/") && name.equalsIgnoreCase("platce"))																	_dodavatel.platce			= value;	
			}
		}
		
		public void endElement(String uri, String localName, String qName) throws org.xml.sax.SAXException
		{
			if (cursor.equals("/databaze/zakaznici/zakaznik/"))																									zakaznici.add(_zakaznik);
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/"))																						_zakaznik.evidence.add(_evidence);
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/"))																		_evidence.faktury.add(_faktura);
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/"))										_faktura.informace_zbozi.add(_zbozi);
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/"))									_zbozi.dane.add(_dph);
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/informace_ekonom/penezni_ustav/"))	_ekonom.banky.add(_banka);
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/faktury/faktura/informace_zbozi/seznam_zbozi/zbozi/dph/informace_ekonom/"))				_faktura.informace_ekonom.add(_ekonom);
				
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/odberatele/odberatel/"))																	_evidence.odberatele.add(_odberatel);
				
			if (cursor.equals("/databaze/zakaznici/zakaznik/evidence/dodavatele/dodavatel/"))																	_evidence.dodavatele.add(_dodavatel);
				
			cursor = cursor.substring(0, cursor.lastIndexOf("/"));
			cursor = cursor.substring(0, cursor.lastIndexOf("/") + 1);
		}
		    
		public void characters(char[] ch, int start, int length) throws org.xml.sax.SAXException
		{
	        // ...
		}
		    
		public void startPrefixMapping(String prefix, String uri) throws org.xml.sax.SAXException
		{
			//FIXME unused
			namespace += (prefix.length() == 0)?(" xmlns=\"" + uri + "\""):(" xmlns:" + prefix + "=\"" + uri + "\"");    
		}

		public void endPrefixMapping(String prefix) throws org.xml.sax.SAXException
		{
		        // ...
		}

		public void ignorableWhitespace(char[] ch, int start, int length) throws org.xml.sax.SAXException
		{    
			// ...
		}

		public void processingInstruction(String target, String data) throws org.xml.sax.SAXException
		{  
			//...       
		}

		public void skippedEntity(String name) throws org.xml.sax.SAXException
		{
			// ...
		}
		
		//FIXME milestone HELPER CLASSES /////////////////////////////////////////////////////////////// 

		java.util.LinkedList<Zakaznik> zakaznici	= new java.util.LinkedList<Zakaznik>();

		class Evidence
		{
			java.util.LinkedList<Faktura> faktury			= new java.util.LinkedList<Faktura>();
			java.util.LinkedList<Odberatel> odberatele	= new java.util.LinkedList<Odberatel>();
			java.util.LinkedList<Dodavatel> dodavatele	= new java.util.LinkedList<Dodavatel>();
		}
		    
		class Odberatel
		{
			java.util.LinkedList<String> faktury = new java.util.LinkedList<String>();
			String klic			= "";
			String platce		= "";
			String ico			= "";
			String dic			= "";
			String firma		= "";
			String ulice		= "";
			String cp			= "";
			String mesto		= "";
			String psc			= "";
			String stat			= "";
			String tel			= "";
		}

		class Dodavatel
		{
			java.util.LinkedList<String> faktury	= new java.util.LinkedList<String>();
			String klic					= "";
			String platce				= "";
			String ico					= "";
			String dic					= "";
			String firma				= "";
			String ulice				= "";
			String cp					= "";
			String mesto				= "";
			String psc					= "";
			String stat					= "";
			String tel					= "";
		}
		    
		class Faktura
		{
			String cislo						= "";
			String zpusob_dopravy				= "";
			String cislo_objednavky				= "";
			java.util.LinkedList<Zbozi> informace_zbozi	= new java.util.LinkedList<Zbozi>();
			java.util.LinkedList<Ekonom> informace_ekonom	= new java.util.LinkedList<Ekonom>();
	    }

		class Ekonom
		{
			java.util.LinkedList<Banka> banky	= new java.util.LinkedList<Banka>();
			String forma_uhrady		= "";
			String splatnost		= "";
			String vystaveni		= "";
			String odeslani			= "";
		}
		    
		class Banka
		{
			String nazev				= "";
			String kod					= "";
			String cislo_uctu			= "";
			String specificky_symbol	= "";
		}
		    
		class Zbozi
		{
			String oznaceni_dodavky = "";
			String ks				= "";
			String cena_za_ks		= "";
			String sleva			= "";
			java.util.LinkedList<DPH> dane	= new java.util.LinkedList<DPH>();
		}
		    
		class DPH
		{
			String hodnota="";
		}
		    
		class Zakaznik
		{
			java.util.LinkedList<Evidence> evidence = new java.util.LinkedList<Evidence>();
		}
		    
		//TODO milestone file-end
	}
}