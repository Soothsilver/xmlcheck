package user;
 import org.xml.sax.Attributes;
 import org.xml.sax.helpers.DefaultHandler;
 public class MySaxHandler extends DefaultHandler {
   // override metod DefaultHandleru

    int attribCount = 0;

    public void	startElement(String uri, String localName, String qName, Attributes attributes)
    {
           attribCount+= attributes.getLength();
    }

     public void	endDocument()
     {
         System.out.printf("Pocet atributu v dokumentu %d: ", attribCount);

     }
 }
