package user;
 import org.w3c.dom.Document;
 import org.w3c.dom.Element;
 import org.w3c.dom.NamedNodeMap;
 import org.w3c.dom.Node;
 import org.w3c.dom.NodeList;
import static org.w3c.dom.Node.ELEMENT_NODE;

 import java.text.AttributedCharacterIterator;
 import java.text.AttributedString;

public class MyDomTransformer {
 public void transform (Document xmlDocument) {
     // libovolne transformace objektu 'xmlDocument'
     // (metoda pracuje primo na objektu, nic nevraci)

     TransformAttributesToChildElement(xmlDocument.getDocumentElement());
   }

     // prida atributy elementu jako podelementy
     void TransformAttributesToChildElement(Node element)
     {
        // zavola se na potomky
       NodeList children =  element.getChildNodes();

       for(int i=0;i<children.getLength();i++)
       {
           Node node = children.item(i);
           if(node.getNodeType() == ELEMENT_NODE)
            TransformAttributesToChildElement(node);
       }

        // a pak prevede atributy
        NamedNodeMap attribs =  element.getAttributes();
        Document doc = element.getOwnerDocument();
        for(int i=0;i<attribs.getLength();i++)
        {
            Node attr = attribs.item(i);

            Element newEl = doc.createElement(attr.getNodeName());
            newEl.setNodeValue(attr.getNodeValue());

        }
     }
 }