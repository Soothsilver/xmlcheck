package user;

import org.xml.sax.helpers.DefaultHandler;
import java.util.Stack;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.Attributes;

/**
 *
 * @author Petr Maly
 */

public class MySaxHandler extends DefaultHandler {
    
    Stack<String> path;
    String value;
    int sum=0;

    public MySaxHandler() {
        path=new Stack<String>();
    }
    
    /**
     * Nastavi locator
     */     
    public void setDocumentLocator(Locator locator) {
        
    }

    /**
     * Obsluha udalosti "zacatek dokumentu"
     */     
    public void startDocument() throws SAXException {
        // ...
        
    }
    /**
     * Obsluha udalosti "konec dokumentu"
     */     
    public void endDocument() throws SAXException {
        
        System.out.println("Celkovy soucet ceny ukonu je: "+sum);
        
    }
    
    private String getPath(){
        String ret="";
        for(String tmp : path){
            ret+=tmp+"/";
        }
        return ret;
    }
    
    /**
     * Obsluha udalosti "zacatek elementu".
     * @param uri URI jmenneho prostoru elementu (prazdne, pokud element neni v zadnem jmennem prostoru)
     * @param localName Lokalni jmeno elementu (vzdy neprazdne)
     * @param qName Kvalifikovane jmeno (tj. prefix-uri + ':' + localName, pokud je element v nejakem jmennem prostoru, nebo localName, pokud element neni v zadnem jmennem prostoru)
     * @param atts Atributy elementu     
     */     
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        path.push(qName);
        value="";
    }
    
    /**
     * Obsluha udalosti "konec elementu"
     * Parametry maji stejny vyznam jako u @see startElement     
     */     
    public void endElement(String uri, String localName, String qName) throws SAXException {
        int o;
        if(getPath().equals("posta/ukon/platba/cena/")){
            try{
                o=Integer.parseInt(value);
            }
            catch(Exception e){
                o=0;
            }
            sum+=o;
            
        }   
        path.pop();
    }
    
    /**
     * Obsluha udalosti "znakova data".
     * SAX parser muľe znakova data davkovat jak chce. Nelze tedy pocitat s tim, ze je cely text dorucen v ramci jednoho volani.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakovymi daty
     * @param start Index zacatku useku platnych znakovych dat v poli.
     * @param length Delka useku platnych znakovych dat v poli.
     */               
    public void characters(char[] ch, int start, int length) throws SAXException {
        
        for(int i=0;i<length;++i){
            value+=ch[start+i];
        }
        
    }
    
    /**
     * Obsluha udalosti "deklarace jmenneho prostoru".
     * @param prefix Prefix prirazeny jmennemu prostoru.
     * @param uri URI jmenneho prostoru.
     */     
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha udalosti "konec platnosti deklarace jmenneho prostoru".
     */     
    public void endPrefixMapping(String prefix) throws SAXException {
    
        // ...
    
    }

    /**
     * Obsluha udalosti "ignorovane bile znaky".
     * Stejne chovani a parametry jako @see characters     
     */     
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha udalosti "instrukce pro zpracovani".
     */         
    public void processingInstruction(String target, String data) throws SAXException {
      
      // ...
            
    }

    /**
     * Obsluha udalosti "nezpracovana entita"
     */         
    public void skippedEntity(String name) throws SAXException {
    
      // ...
    
    }
}
