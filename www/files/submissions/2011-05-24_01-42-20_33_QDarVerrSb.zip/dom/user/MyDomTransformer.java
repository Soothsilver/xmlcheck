package user;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.*;


public class MyDomTransformer { 
    public void transform (Document doc) {
       XPath xp = XPathFactory.newInstance().newXPath();
        XPathExpression xpe;
        try{
            
            // najdeme si cast xml se zamestnanci pomoci xpath
            
            xpe = xp.compile("/posta/zamestnanci");
        
            Object res= xpe.evaluate(doc, XPathConstants.NODESET);
            NodeList nodes = (NodeList) res;
            Node node = nodes.item(0);
            
            Element zamestnanec;
            Tree tree = new Tree();
            
            // nacteme jednotlive zamestnance a pripravime si 
            // k pozdejsimu vytvoreni stromu
            nodes=node.getChildNodes();
            
            for(int i=0;i<nodes.getLength();++i){
                if(nodes.item(i) instanceof Element){
                    zamestnanec=(Element)nodes.item(i);
                    tree.addElement(zamestnanec);
                }
            }
            
            // vytvorime strom
            List<MyNode> tree2 =tree.build();
            
            
            // transformujeme na skupiny
            List<List<MyNode>> groups = new ArrayList<List<MyNode>>();
            for(int i=0;i<tree2.size();++i){
                tree2.get(i).addToGroup(groups);
            }
            
            // vytvorime novy element zamestnanci 
            // a predelame obsah xml
            Element employers = doc.createElement("zamestnanci");            
            for(int i=0;i<groups.size();++i){
                Element priceClass= doc.createElement("platovatrida");
                priceClass.setAttribute("trida", String.valueOf(i+1));
                
                
                for(int j=0; j<groups.get(i).size();++j){
                    priceClass.appendChild(groups.get(i).get(j).elem);
                }
                employers.appendChild(priceClass);
                
            }
            node.getParentNode().removeChild(node);
            doc.getDocumentElement().appendChild(employers);
            

        }catch(Exception e){
            e.printStackTrace();
        }
     
    }
}

/**
 *
 * @author Petr Maly
 */
class MyNode{
    public Element elem;
    public List<MyNode> children;
    public MyNode parent;
    public int level;
   
    
    public void addChild(MyNode mn){
        children.add(mn);
    }
    
    public MyNode(Element elem){
        children = new ArrayList<MyNode>();
        this.parent=null;
        this.elem=elem;
        level=0;
    }
    
    public String getParentId(){
        return elem.getAttribute("nadrizeny");
    }
    
    public String getId(){
        return elem.getAttribute("id");
    }
    
    public String getName(){
        return elem.getElementsByTagName("jmeno").item(0).getTextContent();
    }
    
    public String getSurname(){
        return elem.getElementsByTagName("prijmeni").item(0).getTextContent();
    }
    
    private void addToGroup(List<List<MyNode>> groups, int l){
        level=l;
        if(groups.size()<=l)groups.add(new ArrayList<MyNode>());
        groups.get(l).add(this);
        
        for(int i=0;i<children.size();++i){
            children.get(i).addToGroup(groups,l+1);
        }
    }
    
    public void addToGroup(List<List<MyNode>> groups){
        addToGroup(groups,0);
    }
    
     
    
    public void print(String prefix){
        System.out.println(prefix+getName()+ " " + getSurname());
        for(int i=0;i<children.size();++i){
            children.get(i).print(prefix+"---");
        }
    }

}

class Tree{
    private Map<String,MyNode> arrElems;
    public Tree(){
        arrElems = new HashMap<String, MyNode>();
       
    }
    
    public void addElement (Element elem){
        String id;
        id = elem.getAttribute("id");
        arrElems.put(id, new MyNode(elem));
    }
    
    public List<MyNode> build(){
        Iterator it = arrElems.entrySet().iterator();
        List<MyNode> res = new ArrayList<MyNode>();
        
        // pospojujeme do stromu
        while(it.hasNext()){
            Map.Entry<String,MyNode> e=(Map.Entry<String,MyNode>)it.next();
            if(arrElems.containsKey(e.getValue().getParentId()))
                arrElems.get(e.getValue().getParentId()).addChild(e.getValue());
        }
        
        // vytvorime vysledny vystup, tj. jenom ty MyNode, ktere nemaji predka
        it = arrElems.entrySet().iterator();
        while(it.hasNext()){
            Map.Entry<String,MyNode> e=(Map.Entry<String,MyNode>)it.next();
            if(e.getValue().getParentId().equals(""))
                res.add(e.getValue());
        }
        return res;
    }

}