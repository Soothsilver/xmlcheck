package tomas;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

public class MyDomTransformer {

	private static final String INPUT_FILE = "data.xml";
	private static final String OUTPUT_FILE = "data.out.xml";

	public static void main(String[] args) {
		try {
            // DocumentBuilderFactory creates DOM parsers
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            // We don't want to validate file
            dbf.setValidating(false);

            // Creating of DOM parser instance
            DocumentBuilder builder = dbf.newDocumentBuilder();

            // Parser processes input file and creates a DOM tree of objects
            Document doc = builder.parse(INPUT_FILE);

            // DOM tree processing
            processTree(doc);

            // TransformerFactory creates an object for DOM serialization
            TransformerFactory tf = TransformerFactory.newInstance();

            // Transformer serializes DOM tree
            Transformer writer = tf.newTransformer();

            // Setting of output file encoding
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            // Run transformation of DOM tree to XML document
            writer.transform(new DOMSource(doc), new StreamResult(new File(OUTPUT_FILE)));
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
	
	private static void processTree(Document doc) {
		// 1. ukon: serazeni hracu kazdeho tymu podle abecedy
		NodeList teams = doc.getElementsByTagName( "players" );
		int len = teams.getLength();
		for ( int i = 0; i < len; ++i ) {
			Element team = (Element)teams.item( i );
			NodeList players = team.getElementsByTagName( "player" );
			ArrayList< String > v = new ArrayList<>();
			for ( int j = players.getLength() - 1; j >= 0; --j ) {
				Element child = (Element)players.item( j );
				String s = child.getAttribute( "id" ) + child.getAttribute( "position" );
				v.add( s );
				team.removeChild( child );
			}
					
			Collections.sort( v );
			for ( int j = 0; j < v.size(); ++j ) {
				Element el = doc.createElement( "player" );
				String s = v.get( j );
				el.setAttribute( "id", s.substring( 0, s.length() - 1 ) );
				el.setAttribute( "position", s.substring( s.length() - 1 ) );
				team.appendChild( el );
			}
		}
		
		// 2. ukon: odebrani zapasu, ktere skoncili remizou
		NodeList matches = doc.getElementsByTagName( "match" );
		int lenS = matches.getLength();
		for ( int i = lenS - 1; i >= 0; --i ) {
			Element match = (Element)matches.item( i );
			Node home = match.getElementsByTagName( "home" ).item( 0 );
			Node away = match.getElementsByTagName( "away" ).item( 0 );
			String sh = home.getTextContent();
			String sa = away.getTextContent();
			int h = Integer.parseInt( sh );
			int a = Integer.parseInt( sa );
			if ( h == a ) {
				Node round = match.getParentNode();
				round.removeChild( match );
			}
		}
	}
	
	public void transform (Document xmlDocument) {
		processTree( xmlDocument );
	}

}
