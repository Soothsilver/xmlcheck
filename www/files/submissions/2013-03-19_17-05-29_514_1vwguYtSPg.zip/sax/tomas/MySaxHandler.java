package tomas;

import java.util.ArrayList;
import java.util.TreeMap;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

public class MySaxHandler extends DefaultHandler {

	private static final String INPUT_FILE = "data.xml";
	
	public static void main(String[] args) {
		try {
			// Create parser instance
			XMLReader parser = XMLReaderFactory.createXMLReader();

			// Create input stream from source XML document
			InputSource source = new InputSource(INPUT_FILE);

			// Set our custom content handler for handling SAX events (it must implements ContentHandler interface)
			parser.setContentHandler(new MySaxHandler());

			// Process input data
			parser.parse(source);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private class teamInfo
	{
		teamInfo () { wins = ties = lost = goalsOut = goalsIn = 0; }
		int wins, ties, lost, goalsOut, goalsIn;
	}
	
	private int ageSum = 0;
	private int coaches = 0;
	private int numChars[] = new int[ 26 ];
	private String lastElemName = "";
	private String lastTeamHome = "";
	private String lastTeamAway = "";
	private int lastGoalsHome = 0;
	private int lastGoalsAway = 0;
	private TreeMap< String, teamInfo > teamsInfo = new TreeMap<>();
	private ArrayList< String > teams = new ArrayList<>();
	
	private TreeMap< String, Integer > goals = new TreeMap<>();
	private ArrayList< String > players = new ArrayList<>();
	
	@Override
	public void startDocument() throws SAXException {
	}

	@Override
	public void endDocument() throws SAXException {	
		// 1. charakteristika: prumerny vek trenera
		if ( coaches == 0 ) {
			System.out.println( "V souboru neni zadny trener!" );
		} else { 
			System.out.println( "Prumerny vek trenera: " + (ageSum / (double)coaches) );
		}
		
		// 2. charakteristika: pocet vyskytu jednotlivych znaku ve jmenech hracu:
		System.out.println( "pocet vyskytu jednotlivych znaku ve jmenech hracu" );
		for ( int i = 0; i < 26; ++i ) {
			System.out.printf( "%c: %d\n", 'a' + i, numChars[ i ] );
		}
		
		// 3. charakteristika: pocet vyher, remiz a proher jednotlivych tymu, skore tymu
		System.out.println( "Tabulka tymu (jmeno, pocet vyher, pocet remiz, pocet proher, golu dali, golu dostali)" );
		for ( int i = 0; i < teams.size(); ++i ) {
			System.out.print( teams.get( i ) );
			teamInfo inf = teamsInfo.get( teams.get( i ) );
			System.out.printf( "\t\t%d\t%d\t%d\t%d\t%d\n", inf.wins, inf.ties, inf.lost, inf.goalsOut, inf.goalsIn );
		}
		
		// 4. seznam hracu, kteri dali gol, ale nedali zadny vlastni gol
		System.out.println( "Hraci, kteri dali alespon nejaky gol a zaroven nedali zadny vlastni gol" );
		for ( int i = 0; i < players.size(); ++i ) {
			String p = players.get( i );
			Integer g = goals.get( p );
			if ( g > 0 ) {
				System.out.println( p + "\t\t" + g );
			}
		}
	}

	@Override
	public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
		lastElemName = localName;
		
		if ( localName.equals( "player" ) ) {
			String name = atts.getValue( "id" );
			for ( int i = 0; i < name.length(); ++i ) {
				if ( Character.isAlphabetic( name.charAt( i ) ) ) {
					char c = Character.toLowerCase( name.charAt( i ) );
					++numChars[ c - 'a' ]; 
				}
			}
		}
		
		if ( localName.equals( "team_home" ) ) {
			lastTeamHome = atts.getValue( "id" );
		}
		if ( localName.equals( "team_away" ) ) {
			lastTeamAway = atts.getValue( "id" );
		}
		
		if ( localName.equals( "team" ) ) {
			teams.add( atts.getValue( "id" ) );
			teamsInfo.put( atts.getValue( "id" ), new teamInfo() );
		}
		
		if ( localName.equals( "goal" ) ) {
			// zapocteme gol:
			String name = atts.getValue( "who" );
			Integer g = goals.get( name );
			if ( g != null && g > 0 ) {
				++g;
			} else if ( g == null ) {
				players.add( name );
				goals.put( name, new Integer( 1 ) );
				g = goals.get( name );
			}
			
			// neni to nahodou vlastni gol?
			if ( g > 0 ) {
				String own = atts.getValue( "own" );
				if ( own != null && own.equals( "A" ) ) {
					g *= -1;
				}
			}
			
			// tohle je opravdu hnusne, ale co taky chtit od Javy ..
			goals.remove( name );
			goals.put( name, g );
		}
   }
	
	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		if ( localName.equals( "match" ) ) {
			teamInfo home = teamsInfo.get( lastTeamHome );
			teamInfo away = teamsInfo.get( lastTeamAway );
			home.goalsOut += lastGoalsHome;
			home.goalsIn += lastGoalsAway;
			away.goalsOut += lastGoalsAway;
			away.goalsIn += lastGoalsHome;
			if ( lastGoalsHome > lastGoalsAway ) {
				++home.wins;
				++away.lost;
			} else if ( lastGoalsHome < lastGoalsAway ) {
				++home.lost;
				++away.wins;
			}
			else {
				++home.ties;
				++away.ties;
			}
		}
	}

	@Override
	public void characters(char[] chars, int start, int length) throws SAXException {
		if ( lastElemName.equals( "age" ) ) {
			int age = Integer.parseInt( String.copyValueOf( chars, start, length ) );
			ageSum += age;
			++coaches;
		}
		
		if ( lastElemName.equals( "home" ) ) {
			lastGoalsHome = Integer.parseInt( String.copyValueOf( chars, start, length ) );
		}
		if ( lastElemName.equals( "away" ) ) {
			lastGoalsAway = Integer.parseInt( String.copyValueOf( chars, start, length ) );
		}
	}
}
