package user;

import org.w3c.dom.*;
/**
 * Reverses all elements and transforms file to show possibilities
 * @author Peter Junos
 */
public class MyDomTransformer {


	public void transform (Document doc) {

        doc.normalize();
            
        Element el = doc.getDocumentElement();
        myNormalize(doc,el);
        
        reverseElements(doc, el);
        
        attributesToElementsRecursive(doc, el);
        textContentToAttributes(doc, el);
        deleteInGivenDepth(doc, el, 3);
        deleteOverFanOutRecursive(doc, el, 4);
        // method works on the object itself - no return value
    }

    /**
     * Recursively reverses order of elements, so first will be last and last 
     *   will be first
     * @param doc document used to create element
     * @param node node, which will have all its subelements reversed
     * @return node with reversed subelements
     */
    private Element reverseElements(Document doc, Element element) {
        NodeList nodes = element.getChildNodes();
        
        final int nodeLen = nodes.getLength();
        
        //adding elements again from end causes reversal
        for (int i=nodeLen-1; i>=0; i--) {
            Node n = nodes.item(i);
            
            Node nReversed;
            if (n.getNodeType() == Node.ELEMENT_NODE) {
                nReversed = reverseElements(doc, (Element)n);
            } else {
                nReversed = n;
            }
            element.removeChild(n);
            element.appendChild(nReversed);
        }
        
        return element;
    }
    
    /**
     * Transforms attributes of given node to its subelements
     * @param doc Document used to create elements
     * @param element Element, which attributes will be inplace replaced with subelements
     */
    private void attributesToElements(Document doc, Element element) {
        NamedNodeMap attrs = element.getAttributes();

        int attrsLen = attrs.getLength();
        for (int i=0; i<attrsLen; i++) {
            Node n = attrs.item(i);

            Element newElement = doc.createElement(n.getNodeName());
            newElement.setTextContent(n.getTextContent());
            
            element.removeAttribute(n.getNodeName());
            i--;
            attrsLen--;
          
            element.appendChild(newElement);
        }
        
    }
    
    /**
     * Recursive version of {@link #attributesToElements(org.w3c.dom.Document, org.w3c.dom.Element) }
     */
    private void attributesToElementsRecursive(Document doc, Element element) {
        // do the work
        attributesToElements(doc, element); 
        
        // recurse to subelements
        NodeList nl = element.getChildNodes();
        int nlLen = nl.getLength();
        for (int i=0; i<nlLen; i++) {
            Node n = nl.item(i);
            if (n.getNodeType() == Node.ELEMENT_NODE) {
                attributesToElementsRecursive(doc, (Element)n);
            }

        }
    }
        
    /**
     * Makes attributes from elements with text content, recursively
     * @param doc Document used to create elements
     * @param node Node, whose children will have subelements rewritten
     */
    private void textContentToAttributes(Document doc, Element el) {
        NodeList children = el.getChildNodes();
        
      
        int childrenLen = children.getLength();
        for (int i=0; i<childrenLen; i++) {
            Node n = children.item(i);
            
            String str = getNodeText(n);
            
            
            if (str == null) {
                if (n.getNodeType() == Node.ELEMENT_NODE) {
                    textContentToAttributes(doc, (Element)n);
                }
                continue;
            }
            if (str.trim().isEmpty()) {
                continue;
            }
            
            Attr newElement = doc.createAttribute(n.getNodeName());
            newElement.setTextContent(str);
            el.removeChild(n);
            
            i--;
            childrenLen--;
            
            el.setAttributeNode(newElement);

        }
    }
    
    private String getNodeText(Node node) {
        NodeList children = node.getChildNodes();
        if (node.getAttributes() != null && node.getAttributes().getLength() != 0) {
            // we won't treat as text node element with attributes
            return null;
        }
        
        if (children.getLength() == 1) {
            Node child = children.item(0);
            if (child.getNodeType() == Node.TEXT_NODE) {
                return child.getTextContent();
            }
        }
        return null;        
    }
    
    /**
     * Deletes all elements in given depth
     * @param doc Document used to create elements
     * @param node Node, where to begin counting depth 
     * @param depth Depth (1 = direct children)
     */
    private void deleteInGivenDepth(Document doc, Node node, int depth) {
        if (depth < 0) throw new IndexOutOfBoundsException("depth negative??");
        
        NodeList children = node.getChildNodes();
        
        int childrenLen = children.getLength();
        final boolean deleting = (depth == 0);
        
        for (int i=0; i<childrenLen; i++) {
            Node n = children.item(i);
            
            if (deleting) {
                node.removeChild(n);
                // decrement pointers - we don't want to point 
                // to inaccessible elements
                i--;
                childrenLen--;
            } else {
                if (n.getNodeType() == Node.ELEMENT_NODE) {
                    deleteInGivenDepth(doc, n, depth - 1);
                }
            }
        }
    }
    
    /**
     * Deletes subelements of given element, if there are more than fanout of them
     * @param doc Document used to create elements
     * @param node Node used as a base
     * @param fanout Max. fanout
     */
    private void deleteOverFanOut(Document doc, Node node, int fanout) {
        if (fanout < 0) throw new IndexOutOfBoundsException("fanout negative??");
        
        NodeList children = node.getChildNodes();
        
        final int childrenLen = children.getLength();
        
        
        for (int i = childrenLen - 1; i>=fanout; i--) {
            
            Node n = children.item(i);
            node.removeChild(n);
        }

    }
    
    /**
     * Recursive version of {@link #deleteOverFanOut(org.w3c.dom.Document, org.w3c.dom.Node, int) }
     */
    private void deleteOverFanOutRecursive(Document doc, Element el, int fanout) {
        // do the work
        deleteOverFanOut(doc,el,fanout);
        
        // recurse to subelements
        NodeList nl = el.getChildNodes();
        int nlLen = nl.getLength();
        for (int i=0; i<nlLen; i++) {
            Node n = nl.item(i);
            if (n.getNodeType() == Node.ELEMENT_NODE) {
                deleteOverFanOutRecursive(doc, (Element)n,fanout);
            }

        }
    }

    /**
     * Normalizes in terms of removing empty text elements
     */
    private void myNormalize(Document doc, Element element) {
        // recurse to subelements
        NodeList nl = element.getChildNodes();
        int nlLen = nl.getLength();
        for (int i=0; i<nlLen; i++) {
            Node n = nl.item(i);
            if (n.getNodeType() == Node.ELEMENT_NODE) {
                myNormalize(doc, (Element)n);
            }
            
            if (n.getNodeType() == Node.TEXT_NODE && n.getNodeValue().trim().isEmpty()) {
                element.removeChild(n);
                i--;
                nlLen--;
            }

        }
    }
}
