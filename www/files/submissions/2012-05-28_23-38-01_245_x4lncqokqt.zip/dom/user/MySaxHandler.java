package user;

import java.io.PrintStream;
import java.util.LinkedList;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Prostřednictvím rozhraní SAX spočítá charakteristiky XML dokumentu
 * @author Peter Junos
 */
public class MySaxHandler extends DefaultHandler  {
    Stats treeDepth = new Stats();
    Stats namesLength = new Stats();
    Stats attrsLength = new Stats();
    Stats fanout = new Stats();
    
    LinkedList<Integer> subelements = new LinkedList<Integer>();
    
    int curDepth;
    
    Locator locator;
    int elemCnt = 0;
    int attrCnt = 0;
    int textCnt = 0;
    int elemWithAttrCnt = 0;
    int elemWithSubElemCnt = 0;
    
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }
    
    @Override
    public void endDocument() throws SAXException {
        printStats(System.out);
    }
    
    private void printStats(PrintStream out) {
        out.println(getStatDescription("Depth of tree", treeDepth));
        out.println(getStatDescription("Length of element names", namesLength));
        out.println(getStatDescription("Length of attribute names", attrsLength));
        out.println(getStatDescription("Fanout", fanout));
        
        out.println("Element count: "+elemCnt);
        out.println("Attributes count: "+attrCnt);
        out.println("Text elements count: "+textCnt);
        out.println("Elements with attributes count: "+elemWithAttrCnt);
        out.println("Elements with subelements count: "+elemWithSubElemCnt);
    }
    
    private String getStatDescription(String descr, Stats stats) {
        return descr + ": max: "+stats.getMax()+"; avg: "+stats.getAvg();
    }

    

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        elemCnt++;
                
        curDepth++;
        
        namesLength.addValue(localName.length());
        parseAttrs(attributes);
        
        if (subelements.size() > 0) {
            subelements.push(subelements.pop() + 1); //add 1 item to fanout stats
        } // 
        subelements.push(0); //push 0, as we have 0 subelements now
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        final int subelems = subelements.pop();
        if (subelems == 0) {
            treeDepth.addValue(curDepth);
            textCnt++;
        } else {
            elemWithSubElemCnt++;            
        }
        
        curDepth--;
        
        
        fanout.addValue(subelems);
    }

    private void parseAttrs(Attributes attrs) {
        final int attrsLen = attrs.getLength();
        for(int i=0; i<attrsLen; i++) {
            final String name = attrs.getLocalName(i);
            attrsLength.addValue(name.length());
        }

        attrCnt += attrsLen;
        elemWithAttrCnt += (attrsLen == 0 ? 0 : 1);
    }
    
    class Stats {
        private int sum = 0;
        private int max  = 0;
        private int count = 0;
        
        public void addValue(int value) {
            this.sum += value;
            count++;
            if (value > max) max = value;
        }
        
        public int getMax() {
            return max;
        }
        
        public double getAvg() {
            return sum/count;
        }
    }
}
