package user;

import java.util.HashSet;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
    
	/**
	 * Množina kvalifikovaných názvů atributů.
	 */
	private final HashSet<String> set = new HashSet<String>();
	
	/**
	 * Začátek dokumentu.
	 * Vymaže množinu atributů.
	 */
	@Override
	public void startDocument() throws SAXException {
		set.clear();
	};
	
	/**
	 * Element.
	 * Přidá názvy atributů do množiny.
	 */
	@Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

    	for(int i=0;i<atts.getLength();++i){
    		set.add(atts.getQName(i));
    	}
    }

	/**
	 * Vypíše počet různých atributů.
	 */
	@Override
	public void endDocument() throws SAXException {
		System.out.println(set.size());
	}
}