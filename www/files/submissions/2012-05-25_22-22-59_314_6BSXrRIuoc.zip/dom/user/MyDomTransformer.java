package user;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

public class MyDomTransformer {
	/**
	 * Transform the document.
	 * Sort all subelements.
	 * This is intended for data-oriented XML files and it ignores non-element child nodes and leaves them at the beginning of 
	 * the child list. That can for example result in very strange formatting because the text nodes with white space are appended together. 
	 * @param xmlDocument
	 */
	public void transform(Document xmlDocument) {
		sortSubelements(xmlDocument.getDocumentElement());
	}

	/**
	 * Get list of attributes of an element.
	 * @param element
	 * @return New instance of List<Attr> containing all attributes of the element.
	 */
	private static List<Attr> getAttributeList(Element element) {
		final ArrayList<Attr> list = new ArrayList<Attr>();
		for (int i = 0; i < element.getAttributes().getLength(); ++i)
			list.add((Attr) element.getAttributes().item(i));
		return list;
	}
	
	/**
	 * Get list of Element children nodes and remove them from the parent.
	 * @param element
	 * @return New instance of List<Element> containing all subelements.
	 */
	private static List<Element> getSubelementListAndRemove(Element element) {
		final List<Element> list = new ArrayList<Element>();
		for (int i = 0; i < element.getChildNodes().getLength(); ++i) {
			Node n = element.getChildNodes().item(i);
			if (n.getNodeType() == Node.ELEMENT_NODE) {
				element.removeChild(n);
				list.add((Element) n);
			}
		}
		return list;
	}
	
	
	/**
	 * Sort subelements of an element and apply recursively on all subelements.
	 * @param element
	 */
	private static void sortSubelements(Element element) {
		//Remove all subelments
		List<Element> subelements = getSubelementListAndRemove(element);
		//Sort them
		Collections.sort(subelements, new ElementComparator());
		//And insert them back again
		for (Element n : subelements) {
			element.appendChild(n);
			//Apply recursively
			sortSubelements(n);
		}
	}

	/**
	 * Compare two attibutes by name.
	 */
	private static class AttributeComparator implements Comparator<Attr> {
		public int compare(Attr o1, Attr o2) {
			return o1.getName().compareTo(o2.getName());
		}
	}
	
	/**
	 * Compare two elements.
	 * <ul>
	 * <li>by tag name</li>
	 * <li>by attribute names and values (use the smallest attribute in which they differ)</li>
	 * </ul>
	 * 
	 * 
	 */

	private static class ElementComparator implements Comparator<Element> {

		public int compare(Element element1, Element element2) {
			//First try comparing the names
			int cp = element1.getTagName().compareTo(element2.getTagName());
			if (cp != 0)
				return cp;

			//Get the attributes as lists
			List<Attr> attributes1 = getAttributeList(element1);
			List<Attr> attributes2 = getAttributeList(element2);

			//Sort the attributes by name
			Collections.sort(attributes1, new AttributeComparator());
			Collections.sort(attributes2, new AttributeComparator());

			for (int i = 0; i < attributes1.size() && i < attributes2.size(); ++i) {
				//Compare the attribute names
				int c = attributes1.get(i).getName().compareTo(attributes2.get(i).getName());
				if (c != 0)
					return c;
				//If both elements contain the same attribute, compare their values
				c = attributes1.get(i).getValue().compareTo(attributes2.get(i).getValue());
				if (c != 0)
					return c;
			}

			//If the elements contain the same attributes and values, compare number of attributes.
			if (attributes1.size() < attributes2.size())
				return -1;
			if (attributes1.size() > attributes2.size())
				return 1;

			return 0;
		}

	}

	

}