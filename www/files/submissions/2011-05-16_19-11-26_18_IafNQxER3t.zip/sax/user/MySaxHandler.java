package user;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler
{
	
	private int _numberOfElements;

	@Override
	public void endDocument() throws SAXException
	{
		System.out.println("Dokument obsahuje presne " + this._numberOfElements + " elementov.");
	}

	@Override
	public void startDocument() throws SAXException
	{
		this._numberOfElements = 0;
	}

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException
	{
		this._numberOfElements++;
	}

}
