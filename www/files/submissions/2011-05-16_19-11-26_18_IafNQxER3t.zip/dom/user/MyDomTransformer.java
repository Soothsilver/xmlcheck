package user;

import java.util.Stack;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

public class MyDomTransformer
{
	public void transform(Document xmlDocument)
	{
		Node root = null;
		Node newRoot = null;
		Node lastProcessed = null;
		
		Stack<Node> depthSearch = new Stack<Node>();
		Stack<Node> newNodes = new Stack<Node>();
		
		if (xmlDocument.getChildNodes().getLength() > 0)
		{
			root = xmlDocument.getChildNodes().item(0);
			depthSearch.push(root);
			newRoot = root.cloneNode(false);
			lastProcessed = newRoot;
			newNodes.push(newRoot);
		}
					
		while (depthSearch.size() > 0)
		{
			Node processedNode = depthSearch.pop();
			lastProcessed = newNodes.pop();
			
			for (int i = 0; i < processedNode.getChildNodes().getLength(); i++)
			{
				Node tmp = processedNode.getChildNodes().item(processedNode.getChildNodes().getLength() - 1 - i);
				depthSearch.push(tmp);
				Node tmp2 = tmp.cloneNode(false);
				lastProcessed.appendChild(tmp2);
				newNodes.push(tmp2);
			}
			
		}
		
		xmlDocument.replaceChild(newRoot, root);
	}
}
