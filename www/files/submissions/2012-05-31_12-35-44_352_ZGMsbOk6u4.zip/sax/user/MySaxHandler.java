/*
 * 
 * Lukas Dolezal
 * 
 * Vypsat kategorie, ktere jsou zastoupeny v alespon jednom okne a maji
 * alespon jeden ukol, ktery ma delku vetsi jak konstanta 
 * Vypsat prumernou delku aktivit v techto kategoriich
 * 
 * Se zadanymi daty vypise kategorie Skola, Prace, Volne aktivity
 * Kategorie Jine nema okno
 * Kategorie Kratke ma okno, ale ma aktivity jen s delkou pod 90 (vychozi nastaveni meze)
 * 
 */

package user;

import java.util.ArrayList;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;


/**
 *
 * @author dolezal3
 */

 enum CasoveOkno_ModKategorii {
            ALL_EXCEPT_DEFINED,
            ONLY_DEFINED
        };


/**
 * Náš vlastní content handler pro obsluhu SAX událostí.
 * Implementuje metody interface ContentHandler. 
 */ 
public class MySaxHandler
extends DefaultHandler {

    // Umožňuje zacílit místo v dokumentu, kde vznikla aktualní událost
    Locator locator;
    
    public int MinimalniDelkaAktivity = 90;
    
    // model casoveho okna
    class CasoveOkno {
        public String id;
        public CasoveOkno_ModKategorii modKategorii;
        public ArrayList<String> seznamKategorii = new ArrayList<String>();
        
        public boolean KategoriePatriDoOkna(String idKategorie)
        {
            boolean vSeznamu = seznamKategorii.contains(idKategorie);
            
            return
                modKategorii == CasoveOkno_ModKategorii.ALL_EXCEPT_DEFINED ?
                    !vSeznamu : vSeznamu;
        }
    }
            
    class Kategorie {
        public String id;
        public String nazev;
        public String popis;
        
        public int maxDelkaAktivity = -1;
        public int pocetAktivit = 0;
        public int sumaDelekAktivit = 0;
        
        public float prumernaDelkaAktivit()
        {
            return sumaDelekAktivit / (float)pocetAktivit;
        }
    }
    
    class Aktivita {
        public String kategorieId;
        public int delka;
    }
    
     // cesta aktualniho elementu v dokumentu
    String path = "";
    
    // instance aktualne nacitaneho objektu (kategorie, aktivita, casoveokno)
    Object aktualniNacitanyObjekt;
    
    // aktivity neni potreba explicitne ukladat. (SAX primo vybizi k pouziti pri omezevani pametove narocnosti)
    // potrebujeme jen vedet, maximalni delku aktivity v ramci kategorie
    // a prumernou delku. To se uklada v ramci kategorie. 
    // Schema dat zarucuje, ze aktivity jsou az posledni. Jinak by se museli ukladat.
    // Trida Aktivita poslousi jako docasny objekt pri nacitani aktivit
    //ArrayList<Aktivita> aktivity;
    
    ArrayList<CasoveOkno> casovaOkna;
    ArrayList<Kategorie> kategorie;
    
    // pomocna promenna pro zaznam textovych obsahu
    StringBuilder text = new StringBuilder();
    
    /**
     * Nastaví locator
     */     
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Obsluha události "začátek dokumentu"
     */     
    public void startDocument() throws SAXException {
        
        // ...
        aktualniNacitanyObjekt = null;
        casovaOkna = new ArrayList<CasoveOkno>();
        kategorie = new ArrayList<Kategorie>();
        
        path = "/";
    }
    /**
     * Obsluha události "konec dokumentu"
     */     
    public void endDocument() throws SAXException {
        
        // projit kategorie a vypsat, ty, ktere splnuji podminku
        for (int i = 0; i < kategorie.size(); i++) {
            Kategorie kat = kategorie.get(i);
            
            if (kat.pocetAktivit > 0 && kat.maxDelkaAktivity >= MinimalniDelkaAktivity)
            {
                System.out.println(kat.nazev);
                System.out.println(kat.popis);
                
                System.out.print("(avg: ");
                System.out.print(String.valueOf(kat.prumernaDelkaAktivit()));
                System.out.print(", count: ");
                System.out.print(kat.pocetAktivit);
                System.out.println(")");
                
                System.out.println();
            }
        }
        
    }
    
    /**
     * Obsluha události "začátek elementu".
     * @param uri URI jmenného prostoru elementu (prázdné, pokud element není v žádném jmenném prostoru)
     * @param localName Lokální jméno elementu (vždy neprázdné)
     * @param qName Kvalifikované jméno (tj. prefix-uri + ':' + localName, pokud je element v nějakém jmenném prostoru, nebo localName, pokud element není v žádném jmenném prostoru)
     * @param atts Atributy elementu     
     */     
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        // pomocne promenne
        path += localName + "/";
        
        // casova okno
        if (path.endsWith("casovaokna/okno/")) {
            // zacit novy objekt okna
            CasoveOkno okno = new CasoveOkno();
            okno.id = atts.getValue("id");
            aktualniNacitanyObjekt = okno;
        }
        if (aktualniNacitanyObjekt instanceof CasoveOkno) {
            // doplni mod seznamu kategorii
            if (path.endsWith("casovaokna/okno/aktivity/")) {
                ((CasoveOkno)aktualniNacitanyObjekt).modKategorii =
                        atts.getValue("mode").equals("including") ? CasoveOkno_ModKategorii.ONLY_DEFINED : CasoveOkno_ModKategorii.ALL_EXCEPT_DEFINED;
            }
            // nacita kategorie okna
            else if (path.endsWith("casovaokna/okno/aktivity/kategorie")) {
                ((CasoveOkno)aktualniNacitanyObjekt).seznamKategorii.add(atts.getValue("kategorieId"));
            }
        }
        
        
        // kategorie. Uz mame casova okna, muzeme rovnou rici, jestli kategorii
        // nacist nebo ne, podle toho, ze je v nejakem okne
        if (path.endsWith("kategorieAktivit/kategorie/")) {
            if (kategoriePatriDoNejakehoOkna(atts.getValue("id"))) {
                Kategorie kat = new Kategorie();
                kat.id = atts.getValue("id");
                aktualniNacitanyObjekt = kat;
            }
        }
        if (aktualniNacitanyObjekt instanceof Kategorie) {
            if (path.endsWith("kategorie/nazev/") ||
                path.endsWith("kategorie/description/"))
            {
                // vynulovat text pro nacitani obsahu elementu
                text.setLength(0);
            }
        }
        
        if (path.endsWith("aktivity/aktivita/")) {
            aktualniNacitanyObjekt = new Aktivita();
        }
        if (aktualniNacitanyObjekt instanceof Aktivita) {
            if (path.endsWith("aktivity/aktivita/kategorie/"))
            {
               ((Aktivita)aktualniNacitanyObjekt).kategorieId = atts.getValue("kategorieId");
            }
            if (path.endsWith("aktivity/aktivita/delka/"))
            {
                text.setLength(0);
            }
        }
    }
    /**
     * Obsluha události "konec elementu"
     * Parametry mají stejný význam jako u @see startElement     
     */     
    public void endElement(String uri, String localName, String qName) throws SAXException {

        
        // pokud behem nacitani nestalo null, tak pridej do seznamu
        if (path.endsWith("casovaokna/okno/") &&
            aktualniNacitanyObjekt instanceof CasoveOkno)
        {
            // vlozit do oken
            casovaOkna.add((CasoveOkno)aktualniNacitanyObjekt);
            aktualniNacitanyObjekt =null;
        }
        if (aktualniNacitanyObjekt instanceof Kategorie)
        {
            // nacteny nazev
            if (path.endsWith("kategorie/nazev/")) {
                ((Kategorie)aktualniNacitanyObjekt).nazev = text.toString();
            }
            // popis
            if (path.endsWith("kategorie/description/")) {
                ((Kategorie)aktualniNacitanyObjekt).popis = text.toString();
            }
            
            // konec elementu kategorie
            if (path.endsWith("kategorieAktivit/kategorie/")) {
                // vlozit do seznamu
                kategorie.add((Kategorie)aktualniNacitanyObjekt);
                aktualniNacitanyObjekt =null;
            }
        }
        if (aktualniNacitanyObjekt instanceof Aktivita)
        {
            Aktivita aktivita = (Aktivita)aktualniNacitanyObjekt;
            
            // konec aktivity, najit kategorii a pripocitat statistiku
            if (path.endsWith("aktivity/aktivita/"))
            {
                for (int i = 0; i < kategorie.size(); i++) {
                    Kategorie kat = kategorie.get(i);
                    if (kat.id.equals(aktivita.kategorieId)) {
                        kat.pocetAktivit++;
                        if (kat.maxDelkaAktivity < aktivita.delka)
                            kat.maxDelkaAktivity = aktivita.delka;
                        kat.sumaDelekAktivit += aktivita.delka;
                    }
                }
            }
            
            // nactena delka
            if (path.endsWith("aktivity/aktivita/delka/")) {
                
                aktivita.delka = Integer.parseInt(text.toString().trim());
            }
        }
        
        // zmena stavu promenych pro sledovani pozice
        path = path.substring(0, path.lastIndexOf("/"));
        path = path.substring(0, path.lastIndexOf("/") + 1);
    }
    
    /**
     * Obsluha události "znaková data".
     * SAX parser muľe znaková data dávkovat jak chce. Nelze tedy počítat s tím, že je celý text dorucen v rámci jednoho volání.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakovými daty
     * @param start Index zacátku úseku platných znakových dat v poli.
     * @param length Délka úseku platných znakových dat v poli.
     */               
    public void characters(char[] ch, int start, int length) throws SAXException {

        if (path.endsWith("kategorie/nazev/") ||
            path.endsWith("kategorie/description/") ||
            path.endsWith("aktivity/aktivita/delka/")) {
            
            text.append(ch, start, length);
        }
        
            
    }
    
    /**
     * Obsluha události "deklarace jmenného prostoru".
     * @param prefix Prefix prirazený jmennému prostoru.
     * @param uri URI jmenného prostoru.
     */     
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha události "konec platnosti deklarace jmenného prostoru".
     */     
    public void endPrefixMapping(String prefix) throws SAXException {
    
        // ...
    
    }

    /**
     * Obsluha události "ignorované bílé znaky".
     * Stejné chování a parametry jako @see characters     
     */     
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha události "instrukce pro zpracování".
     */         
    public void processingInstruction(String target, String data) throws SAXException {
      
      // ...
            
    }

    /**
     * Obsluha události "nezpracovaná entita"
     */         
    public void skippedEntity(String name) throws SAXException {
    
      // ...
    
    }
    
    // pomocne funkce
    
    private boolean kategoriePatriDoNejakehoOkna(String kategorieId) {
        for (int i = 0; i < casovaOkna.size(); i++) {
            if (casovaOkna.get(i).KategoriePatriDoOkna(kategorieId))
                return true;
        }
        
        return false;
    }
}