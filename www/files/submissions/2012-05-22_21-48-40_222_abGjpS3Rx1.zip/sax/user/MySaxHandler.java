package user;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

//Vypocita maximalni a prumerny fan-out v dokumentu.
public class MySaxHandler extends DefaultHandler {
    private int level;
    private List<Integer> fanouts;
    private List<Integer> stack;
    
    @Override
    public void startDocument() {
        level = 0;
        fanouts = new ArrayList<Integer>();
        stack = new ArrayList<Integer>(10);
    }
    
    @Override
    public void endDocument() {
       int sum = 0;
       
       for(Integer i : fanouts) {
           sum += i;
       }
       
       if(fanouts.isEmpty()) {
           System.out.println("Prumer: " + 0);
           System.out.println("Maximum: " + 0);
       }
       else {
           System.out.printf("Prumer: %f%n", (float) sum / fanouts.size());
           
           Collections.sort(fanouts);
           System.out.printf("Maximum: %d%n", fanouts.get(fanouts.size() - 1));
       }
    }
    
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        ++level;
        stack.add(0);
    }
    
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        fanouts.add(stack.get(level - 1));
        stack.remove(level - 1);
        
        if(level > 1) {
            stack.set(level - 2, stack.get(level - 2) + 1);
            --level;
        }
    }
}