package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

//Odstrani elementy presahujici dany fan-out v dane hloubce.
public class MyDomTransformer {
    public static final int depth = 1;
    public static final int maxFanOut = 1;
    
    private int actualDepth = 0;
    
    public void transform(Document xmlDocument) {
        Element root = xmlDocument.getDocumentElement();        
        execTransformation(root);
    }
    
    private void execTransformation(Node n) {
        ++actualDepth;
        
        NodeList list = n.getChildNodes();
        
        int elementCounter = 0;
        
        for(int i = 0; i < list.getLength(); i++) {
            if(list.item(i).getNodeType() == Node.ELEMENT_NODE) {
                ++elementCounter;
            }

            if(actualDepth == depth && elementCounter > maxFanOut) {
                n.removeChild(list.item(i));
            }
            else if(actualDepth < depth) {
                execTransformation(list.item(i));
            }
        }
        
        --actualDepth;
    }
}