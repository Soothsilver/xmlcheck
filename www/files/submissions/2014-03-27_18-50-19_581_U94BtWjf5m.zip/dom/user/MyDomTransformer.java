package user;

import java.io.File;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

public class MyDomTransformer {

    private static final String INPUT_FILE = "data.xml";
    private static final String OUTPUT_FILE = "data-modified.xml";

    /**
     * Main method
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {

        try {

            // DocumentBuilderFactory creates DOM parsers
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            // We don't want to validate file
            dbf.setValidating(false);

            // Creating of DOM parser instance
            DocumentBuilder builder = dbf.newDocumentBuilder();

            // Parser processes input file and creates a DOM tree of objects
            Document doc = builder.parse(INPUT_FILE);

            // DOM tree processing
           new MyDomTransformer().transform(doc);          
            
            // TransformerFactory creates an object for DOM serialization
            TransformerFactory tf = TransformerFactory.newInstance();
            
            // Transformer serializes DOM tree
            Transformer writer = tf.newTransformer();
            
            DocumentType doctype = doc.getDoctype();
            if(doctype != null) {               
                writer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, doctype.getSystemId());
            }

            // Setting of output file encoding
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            // Run transformation of DOM tree to XML document
            writer.transform(new DOMSource(doc), new StreamResult(new File(OUTPUT_FILE)));
            
            

        } catch (Exception e) {

            e.printStackTrace();

        }
    }

    public void transform (Document xmlDocument) {
    	processTree(xmlDocument);
    }
    
    /**
     * Nejprve bude pridan novy zamestnanec.
     * Pote jsou vsichni zakaznici serazeni podle prijmeni
     */
    private static void processTree(Document doc) {
          Node element = doc.getElementsByTagName("list_zamestnanec").item(0);
          Element novyZamestnanec = doc.createElement("zamestnanec");
          novyZamestnanec.setAttribute("id_zamestnananec", "z_3");
          novyZamestnanec.setAttribute("pozice", "slave");
          novyZamestnanec.setAttribute("plat", "10 000");
          novyZamestnanec.setAttribute("pracovni_doba", " 12 hodin");
         
          Element osoba = doc.createElement("osoba");
          osoba.setAttribute("jmeno", "Jan");
          osoba.setAttribute("prijmeni", "Novak");
          osoba.setAttribute("telefon", "789456123");
          osoba.setAttribute("mail", "novak@mail.cz");
          osoba.setAttribute("datum_narozeni", "14-5-1980");
          
          Element adresa = doc.createElement("adresa");
          adresa.setAttribute("zeme", "Cr");
          adresa.setAttribute("mesto", "Praha");
          adresa.setAttribute("ulice", "Prazska");
          adresa.setAttribute("popisne_cislo", "756");
          
          osoba.appendChild(adresa);
          novyZamestnanec.appendChild(osoba);
          element.appendChild(novyZamestnanec);
          
         
          
           Element list_zakaznik =(Element) doc.getElementsByTagName("list_zakaznik").item(0);
           List<Element> zakaznici = getListZakaznik(list_zakaznik.getElementsByTagName("zakaznik"));         
          java.util.Collections.sort(zakaznici, new Comparator<Element>() {
        	 
        	  public int compare(Element a, Element b){
        		return String.CASE_INSENSITIVE_ORDER.compare(((Element)a.getElementsByTagName("osoba").item(0)).getAttribute("prijmeni"),
        		((Element)b.getElementsByTagName("osoba").item(0)).getAttribute("prijmeni")); 	  
        		  
        	  }        	          	  
		});
          
          
          NodeList childNodes = list_zakaznik.getChildNodes();
          for(int i = 0; i < childNodes.getLength(); i++){
        	  list_zakaznik.removeChild(childNodes.item(i));
          }
          
          for(int i = 0; i < zakaznici.size(); i++){
        	  list_zakaznik.appendChild(zakaznici.get(i));
          }
          
    }
    
    private static List<Element> getListZakaznik(NodeList nodelist){
    	ArrayList<Element> navratList = new ArrayList<Element>();
    	
    	for(int i = 0; i < nodelist.getLength(); i++){
    		if("zakaznik".equals(nodelist.item(i).getNodeName()))
    			navratList.add((Element)nodelist.item(i));
    	}
    	return navratList;
    }
}
