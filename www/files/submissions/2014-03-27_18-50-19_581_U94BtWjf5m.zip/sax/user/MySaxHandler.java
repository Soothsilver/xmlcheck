package user;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 * Zpracuje dokument. V prubehu zpracovani spocita prumery zamestnanecky vek. (pristup k atributu)
 * Vytiskne jmena vsech filmu. (pristup k hodnote elementu)
 * Nakonec zjisti a vytiskne jmeno zamestnance, kterz udelal nejvice vypujcek. (data se berou z ruznych casti dokumentu)
 */
public class MySaxHandler extends DefaultHandler {
	
	   private static final String INPUT_FILE = "data.xml";

	    /**
	     * Main method
	     *
	     * @param args command line arguments
	     */
	    public static void main(String[] args) {
	        try {

	            // Create parser instance
	            XMLReader parser = XMLReaderFactory.createXMLReader();

	            // Create input stream from source XML document
	            InputSource source = new InputSource(INPUT_FILE);

	            // Set our custom content handler for handling SAX events (it must implements ContentHandler interface)
	            parser.setContentHandler(new MySaxHandler());

	            // Process input data
	            parser.parse(source);

	        } catch (Exception e) {

	            e.printStackTrace();

	        }

	    }
	

    // Helper variable to store location of the handled event
    Locator locator;

    /**
     * mapa pro urceni zda se program nachazi uvnitr elementu
     */
    HashMap<String, Boolean> map = new HashMap<String, Boolean>();
    String isINListZamestnanec = "list_zamestnanec", isInZamestnanec = "zamestnanec", isInsOsoba = "osoba", 
    		isInAudiovizualni_obsah = "audiovizualni_obsah", isInAddres = "adresa", isInVypujcka = "vypujcka";
    
    String[] pole = new String[]{isINListZamestnanec, isInZamestnanec, isInsOsoba, isInAudiovizualni_obsah, isInAddres, isInVypujcka}; 
   
    int citacZamestnanec = 0, celkovyVek = 0;
    List<String> jmenaFilmu = new ArrayList<String>();   
    
    
    List<String[]> zamestnanci = new ArrayList<String[]>();
    HashMap<String, Integer> zamestnanecVypujcil = new HashMap<String, Integer>();
    
    
    public MySaxHandler(){
    	for(String str : pole){
    		map.put(str,false);
    	}
    }
    
    /**
     * Sets the locator
     *
     * @param Locator locator location in the file
     */
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Method to handle "document start"
     *
     * @throws SAXException
     */
    @Override
    public void startDocument() throws SAXException {
        // ...
    }

    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
        // ...
    	
    	vytiskniPrumernyZamestnaneckyVek();
    	vytiskniJmenaVsechFilmuVdatabazi();
    	vytiskniJmeniZamestnanceKteryUdelalNejviceVypujcek();
    }

    private void vytiskniJmenaVsechFilmuVdatabazi(){
    	System.out.print("jmena vsech filmu: ");
    	for(String str : jmenaFilmu)
    		System.out.print(str + ", ");
    	System.out.println("");
    }
    
    private void vytiskniJmeniZamestnanceKteryUdelalNejviceVypujcek(){
    	String idZamestnanceSnejviceVypujckami = null;
    	
    	Iterator<Entry<String, Integer>> it = zamestnanecVypujcil.entrySet().iterator();
    	
    	while(it.hasNext()){
    		String str = it.next().getKey();
    		if(idZamestnanceSnejviceVypujckami == null)
    			idZamestnanceSnejviceVypujckami = str;
    		if(zamestnanecVypujcil.get(idZamestnanceSnejviceVypujckami) < zamestnanecVypujcil.get(str))
    			idZamestnanceSnejviceVypujckami = str;
    	}
    	if(idZamestnanceSnejviceVypujckami == null) return;
    	for(int i = 0; i < zamestnanci.size(); i++){
    		String[] pole = zamestnanci.get(i);
    		if(pole[0].equals(idZamestnanceSnejviceVypujckami)){
    			System.out.println("Zamestnanec, ktery uskucnil nejvice vypujcek se jmenuje: " + pole[1]);
    		}
    	}
    }
    
    private void vytiskniPrumernyZamestnaneckyVek(){
    	System.out.println("Prumerny zamestnanecky vek je: " + (((double)celkovyVek) / citacZamestnanec));
    }
    
    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
    	aktualizuj(qName, true);
    	
    	if(map.get(isINListZamestnanec) && map.get(isInZamestnanec)){
    		if(!map.get(isInsOsoba)){
    			String[] pole = new String[2];
    			pole[0] = atts.getValue("id_zamestnanec");
    			zamestnanci.add(pole);
    		}
    		else{
    			if(!map.get(isInAddres)){
    				zamestnanci.get(zamestnanci.size() - 1)[1] = atts.getValue("jmeno") + " " + atts.getValue("prijmeni");
    			}
    			
    		}
    	}
    	
    	if(map.get(isInVypujcka)){
    		pridejIdZamestnance(atts.getValue("id_of_zamestnanec"));
    	}
    	
    	String str;
    	if(map.get(isINListZamestnanec) && map.get(isInsOsoba) && (str = atts.getValue("datum_narozeni")) != null){
    		pocitejPrumernyVekZamestnance(str);
    	}
    	
    }
    
    private void pridejIdZamestnance(String idZamestnance){
    	if(!zamestnanecVypujcil.containsKey(idZamestnance))
    		zamestnanecVypujcil.put(idZamestnance, 0);
    	zamestnanecVypujcil.put(idZamestnance, zamestnanecVypujcil.get(idZamestnance) + 1);
    }

    private void pridejJmenaFilmu(String jmenoFilmu){
    	jmenaFilmu.add(jmenoFilmu);
    }
    
   
	private void pocitejPrumernyVekZamestnance(String datumNarozeni){
    	citacZamestnanec++;
    	Calendar now = Calendar.getInstance();   // This gets the current date and time.    	
    	 int rok = now.get(Calendar.YEAR); 
    	 celkovyVek = rok - Integer.parseInt(datumNarozeni.split("-")[2]);
    }
    
    private void aktualizuj(String qName, boolean value){
    	 Iterator<Entry<String, Boolean>> it = map.entrySet().iterator();
    	 while(it.hasNext()){
        	 String str;
        	 if(qName.equals(str = it.next().getKey())){
        		 map.put(str, value);
        	 }
         }
    }
    
    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
    	aktualizuj(qName, false);
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        if(map.get(isInAudiovizualni_obsah)){
        	String str = new String(chars, start,length);
        	str = str.trim();
        	if(!str.equals(""))
        		pridejJmenaFilmu(str);
        }
    }

    /**
     * Method to handle " start of namespace declaration"
     *
     * @param prefix Prefix of the namespace
     * @param uri URI of the namespace
     * @throws SAXException
     */
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    /**
     * Method to handle "end of namespace declaration"
     *
     * @param prefix
     * @throws SAXException
     */
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    /**
     * Method to handle "ignoring of whitespaces" Text is in array 'chars' from
     * position ('start') to ('start' + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     * @throws SAXException
     */
    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
        // ...
    }

    /**
     * Method to handle "processing instructions"
     *
     * @param target The processing instruction target
     * @param data  The processing instruction data
     * @throws SAXException
     */
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

    /**
     * Method to handle "unprocessed entity"
     *
     * @param name
     * @throws SAXException
     */
    @Override
    public void skippedEntity(String name) throws SAXException {
        // ...
    }
}
