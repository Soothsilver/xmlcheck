/*
 * Copyright (C) 2014 Martin Indra <martin.indra at mgn.cz>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package user;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author Martin Indra <martin.indra at mgn.cz>
 */
public class MyDomTransformer {

    private static final String INPUT_FILE = "data.xml";
    private static final String OUTPUT_FILE = "data.out.xml";
    // XML structure
    private static final String ELEMENT_PHOTOS = "photos";
    private static final String ELEMENT_PHOTO = "photo";
    private static final String ELEMENT_NAME = "name";
    private static final String ELEMENT_PHOTO_ATTR_SIZE = "size";
    private static final String ELEMENT_PHOTO_ATTR_AUTHOR = "author";
    private static final String ELEMENT_FILE = "file";
    private static final String ELEMENT_DESCRIPTION = "description";

    /**
     * Main method
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        try {
            // DocumentBuilderFactory creates DOM parsers
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            // We don't want to validate file
            dbf.setValidating(false);

            // Creating of DOM parser instance
            DocumentBuilder builder = dbf.newDocumentBuilder();

            // Parser processes input file and creates a DOM tree of objects
            Document doc = builder.parse(INPUT_FILE);

            // DOM tree processing
            transform(doc);

            // TransformerFactory creates an object for DOM serialization
            TransformerFactory tf = TransformerFactory.newInstance();

            // Transformer serializes DOM tree
            Transformer writer = tf.newTransformer();

            // Setting of output file encoding
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            //writer.setOutputProperty(OutputKeys.INDENT, "yes");

            // Run transformation of DOM tree to XML document
            writer.transform(new DOMSource(doc), new StreamResult(new File(OUTPUT_FILE)));
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(MyDomTransformer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TransformerException ex) {
            Logger.getLogger(MyDomTransformer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SAXException ex) {
            Logger.getLogger(MyDomTransformer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(MyDomTransformer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Process document tree
     *
     * @param doc Document to be parsed
     */
    public static void transform(Document doc) {
        // add some photos
        ArrayList<Photo> photos = new ArrayList<Photo>();
        Photo photo1 = new Photo(2, new Person(2), 2 * 1024, "Photo 2", "photo_2.jpeg", "Lorem ipsum, photo 2");
        photos.add(photo1);
        addPhotos(doc, photos);

        removePhotosOf(doc, 4);
    }

    /**
     * Removes all photos of an author.
     *
     * @param doc document to work with
     * @param authorID ID of the author
     */
    private static void removePhotosOf(Document doc, int authorID) {
        Element photosElement = getElement(doc.getDocumentElement(), ELEMENT_PHOTOS);

        if (photosElement != null) {
            NodeList photos = photosElement.getElementsByTagName(ELEMENT_PHOTO);

            for (int i = 0; i < photos.getLength(); i++) {
                Element photo = (Element) photos.item(i);
                String author = photo.getAttribute(ELEMENT_PHOTO_ATTR_AUTHOR);
                if (("" + authorID).equals(author)) {
                    photo.getParentNode().removeChild(photo);
                    i--;
                }
            }
        }
    }

    /**
     * Adds the photos to the document.
     *
     * @param doc document to work with
     * @param photos list of photos to add
     */
    private static void addPhotos(Document doc, ArrayList<Photo> photos) {
        Element photosElement = getOrCreatePhotosElement(doc);

        for (Photo photo: photos) {
            addPhoto(doc, photo, photosElement);
        }
    }

    /**
     * Adds photo to specified photos element.
     *
     * @param doc document to work with
     * @param photo photo to add
     * @param photosElement element of the photos
     */
    private static void addPhoto(Document doc, Photo photo, Element photosElement) {
        Element photoElement = createPhotoElement(doc, photo);
        photosElement.appendChild(photoElement);
    }

    /**
     * Returns element with photos. If there is not any it creates one and append it to
     * the document.
     *
     * @param doc document to work with
     * @return element with photos
     */
    private static Element getOrCreatePhotosElement(Document doc) {
        return getOrCreateElement(doc, doc.getDocumentElement(), ELEMENT_PHOTOS);
    }

    /**
     * Returns sub-element of specified parent with the passed name. If the element
     * doesn't exist it creates it and append to the parent.
     *
     * @param doc document to work with
     * @param parent parent of searched element
     * @param elementName element name
     * @return the element
     */
    private static Element getOrCreateElement(Document doc, Element parent, String elementName) {
        Element element = getElement(parent, elementName);

        if (element == null) {
            element = doc.createElement(elementName);
            parent.appendChild(element);
        }

        return element;
    }

    /**
     * Get first element with specified name.
     *
     * @param parent node to search in
     * @param elementName searched element name
     * @return first element occurrence or null if there is no such element
     */
    private static Element getElement(Element parent, String elementName) {
        NodeList elements = parent.getElementsByTagName(elementName);
        return (Element) (elements.getLength() > 0 ? elements.item(0) : null);
    }

    /**
     * Creates photo element filled wit its data.
     *
     * @param doc document to work with
     * @param photo it will fill the element with data of this photo
     * @return new element filled with data
     */
    private static Element createPhotoElement(Document doc, Photo photo) {
        Element element = doc.createElement(ELEMENT_PHOTO);

        // set attributes to the photo element
        element.setAttribute("id", "" + photo.getID());
        element.setAttribute(ELEMENT_PHOTO_ATTR_SIZE, "" + photo.getSize());
        element.setAttribute(ELEMENT_PHOTO_ATTR_AUTHOR, "" + photo.getAuthor().getID());

        // add sub-elements with data
        addTextElement(doc, element, ELEMENT_NAME, photo.getName());
        addTextElement(doc, element, ELEMENT_FILE, photo.getPath());
        addTextElement(doc, element, ELEMENT_DESCRIPTION, photo.getDescription());

        return element;
    }

    /**
     * It creates new element wit specified name sets its text contend and append this
     * element to the specified parent.
     *
     * @param doc document to work with
     * @param to to which element should be new element appended
     * @param element new element name
     * @param value new element text value
     */
    private static void addTextElement(Document doc, Element to, String element, String value) {
        Element toAdd = doc.createElement(element);
        toAdd.setTextContent(value);
        to.appendChild(toAdd);
    }

    private static class Person {

        private int id;

        public Person(int id) {
            this.id = id;
        }

        public int getID() {
            return id;
        }
    }

    /**
     * Class representing single photo.
     */
    private static class Photo {

        private Person author;
        private int id;
        private int size;
        private String name;
        private String path;
        private String description;

        public Photo(int id, Person author, int size, String name, String path, String description) {
            this.author = author;
            this.id = id;
            this.size = size;
            this.name = name;
            this.path = path;
            this.description = description;
        }

        public int getID() {
            return id;
        }

        public Person getAuthor() {
            return author;
        }

        public int getSize() {
            return size;
        }

        public String getName() {
            return name;
        }

        public String getPath() {
            return path;
        }

        public String getDescription() {
            return description;
        }
    }
}
