package user;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
	private int attributeCount;
	
	@Override
	public void startDocument() throws SAXException {
		attributeCount = 0;
	}
	
	@Override
	public void startElement(String uri, String localName,
            String qName, Attributes attributes) throws SAXException {
		attributeCount += attributes.getLength();
	}
	
	@Override
	public void endDocument() throws SAXException {
		System.out.println("Total attribute count: " + attributeCount);
	}
}
