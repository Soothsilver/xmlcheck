//
package user;

//
import org.xml.sax.Attributes;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

// 
public class MySaxHandler extends DefaultHandler {
    
    // This SAX handler needs to compute the maximum element 
    // depth for the XML document it is used on.
    //
    // The implementation holds a counter that will increase by one 
    // whenever we receive a startElement event and descrease by one 
    // whenever we receive an endElement event.
    // 
    // The maximum value that the counter will reach throughout the 
    // whole document parsing is the document's maximum element depth.
    // 
    // As soon as the end of the document is reached (endDocument event), 
    // the result maximum element depth is printed to the System output.
    
    //
    protected int maxDepth = 0;
    protected int depth = 0;
    
    //
    public void startElement (String uri, String lName, String ele, Attributes attributes) {
        depth++;
        if (depth > maxDepth) maxDepth = depth;
    }
    
    //
    public void endElement (String uri, String lName, String qName) {
        depth--;
    }
    
    //
    public void endDocument() {
        System.out.println("Finished. Max element depth: " + maxDepth);  
    }

   
}
