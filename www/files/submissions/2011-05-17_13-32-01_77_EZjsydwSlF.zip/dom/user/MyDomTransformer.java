// 
package user;

//
import org.w3c.dom.*;
import static org.w3c.dom.Node.*;

//
public class MyDomTransformer {
    
        
    // Transforms the document so that any text content stored in elements 
    // will be saved in the parent element's attribute or attributes 
    // and then removed. 
    //
    // The elements can contain several text contents that are divided by 
    // sub-elements, like in:
    //
    // <body>One<i>Two</i>Three</body>
    //
    // All the text contents are saved in the 'textVal#' attribute, where 
    // '#' is a counter that starts with 1 and increases with each new text
    // content. The example above would be transformed to:
    // 
    // <body textVal1="One" textVal2="Three"><i textVal1="Two"/></body>
    // 
    // This doesn't handle whitespace that the document might contain, 
    // so with the hand-written, indented XML documents, the result 
    // may be a little chaotic.
    
    public void transform (Document doc) {
        
        // Transform the root node. This will recursively transform
        // all the children nodes as well.
        Node node = doc.getDocumentElement();
        transformEle(node);
        
    }

    // This method handles the given node and recursively all its 
    // children nodes. The provided 'node' parameter needs to be an 
    // element node, otherwise, the call returns immediately.
  
    protected void transformEle (Node node) {
        
        // Check.
        if (node.getNodeType() != ELEMENT_NODE) return;
        Element ele = (Element)node;   
        
        // 
        int textNodeCounter = 0;
        
        //
        NodeList children = ele.getChildNodes();
        for (int n = 0; n < children.getLength(); n++) {
            Node child = children.item(n);
            
            // Save the text node to the next attribute.
            if (child.getNodeType() == TEXT_NODE) {
                
                //
                textNodeCounter++;
                
                //
                ele.setAttribute("textVal" + textNodeCounter, child.getTextContent());
                child.setTextContent("");
                
            }        
            
            // Handle the children.
            if (child.getNodeType() == ELEMENT_NODE) {
                
                transformEle(child);
                
            }    
        }     
        
    }
    
}
