package user;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
	// Pocet textovych elementu (textovy = neobsahuje podelementy, a neobsahuje pouze cele cislo s libovolnym poctem bilych znaku na konci nebo zacatku)
	int elements_text;
	// Pocet textovych atributu (textovy = neobsahuje pouze cele cislo)
	int attributes_text;
	// Promene pro ulozeni info o vrcholu zasobniku prohledavani elementu( taky jenom ten nas zajima, ostatni maji podelementy)
	String last_locName;
	String last_namespace;
	String last_qname;
	// Promena pro textovy obsah elementu
	String cont_chars;
	@Override
	public void characters(char[] arg0, int arg1, int arg2) throws SAXException {
		// Do promenne cont_chars prideme obsah mezi elementy (mimo elementy se nuluje v startElement)
		cont_chars += new String(arg0,arg1,arg2);
	}

	@Override
	public void endDocument() throws SAXException {
		// Vypis poctu a pomeru
		System.out.println(elements_text);
		System.out.println(attributes_text);
		System.out.println(elements_text / (float)attributes_text);
	}

	@Override
	public void endElement(String namespaceURI,String localName,String qName)
			throws SAXException {
		// Diky zmene promenych last_* pri kazdem zanoreni je podminka splnena pouze po ukonceni elementu bez podelementu
		if(last_locName == localName && last_qname == qName && last_namespace == namespaceURI){
			cont_chars = cont_chars.trim(); // Orez bilych znaku na konci/zacatku 
			if(!isInt(cont_chars) && cont_chars.length() > 0) // Pokud i presto neobsahuje cislo a je delsi nez 0 znaku
				elements_text++;
		}		
	}
	@Override
	public void startDocument() throws SAXException {
		elements_text = 0;
		attributes_text = 0;
	}

	@Override
	public void startElement(String namespaceURI,
            String localName,
            String qName,
            Attributes atts) throws SAXException {
		for (int i = 0; i < atts.getLength(); i++) {
			// Spocitame vsechny necislene atributy
			if(!isInt(atts.getValue(i)) && atts.getValue(i).length() > 0){
				++attributes_text;
			}
		}
		// Nastavime promenne last abych odchytili spravne ukonceni posledniho zanoreneho elementu
		last_locName = localName;
		last_namespace = namespaceURI;
		last_qname = qName;
		// Vynulujeme promenou cont_chars aby obsahovala pouze znaky mezi zacatkem a koncem elementu
		cont_chars = "";
	}
	// Test ciselnosti naparsovanim Integeru
	private boolean isInt(String arg){
		try{
			Integer.parseInt(arg);
			return true;
		}catch(NumberFormatException e){
			return false;
		}
	}
}

