package xml.technologie.ukol6;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
	boolean accountsStarted = false;
	int pocetZen = 0;
	int pocetMuzu = 0;
	// celkovy vek zen v poctu dni
	int vekZen = 0;
	// celkovy vek muzu v poctu dni
	int vekMuzu = 0;
	int pocetVdanychZen = 0;

	StringBuilder buffer = null;
	
	// hodnoty aktualne zpracovavanych elementu a atributu
	String jmeno = null;
	String prijmeni = null;
	String rodnePrijmeni = null;
	String clientId = null;
	String pohlavi = null;
	Double balance = null;
	long vek = 0;
	Ucet ucet;
	Klient klient;

	HashMap<String, Klient> prehledKlientu;
	HashMap<String, Ucet> prehledUctu;

	@Override
	public void startDocument() throws SAXException {
		prehledKlientu = new HashMap<String, Klient>();
		prehledUctu = new HashMap<String, Ucet>();
	}

	@Override
	public void endDocument() throws SAXException {
		System.out.println("Statistika klientu:");
		System.out.println("Pocet muzu: " + pocetMuzu + ", Prumerny vek: " + (int)(vekMuzu/pocetMuzu/365.24));
		System.out.println("Pocet zen: " + pocetZen + "(z toho vdanych: " + pocetVdanychZen + "), Prumerny vek: " + (int)(vekZen/pocetZen/365.24));
		for (Klient kl:prehledKlientu.values()) {
			System.out.println(kl.first_name + " " + kl.last_name + " je disponentem na " + kl.pocetUctu + " uctech.");
		}
		System.out.println("\nStatistika uctu:");
		for (Ucet u:prehledUctu.values()) {
			System.out.println("Ucet typu " + u.typUctu + " ma " + u.pocetUctu + "dluznik a dluzi celkem " + u.celkovyDluh.longValue() + 
					(u.celkovyDluh>0? " (nedluzi)": ""));
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		if (qName.equals("client") && klient!=null) {
			if (pohlavi.equals("M")) {
				pocetMuzu++;
				vekMuzu+=vek;
			} else {
				pocetZen++;
				vekZen+=vek;
				if (rodnePrijmeni!=null && !rodnePrijmeni.isEmpty() && !rodnePrijmeni.equals(prijmeni)) {
					pocetVdanychZen++;
				}
			}
			klient.first_name=jmeno;
			klient.last_name=prijmeni;
			prehledKlientu.put(klient.id, klient);
			clearClientAttributes();
		} else if ("first_name".equals(qName)) {
			jmeno = new String(buffer);
		} else if ("last_name".equals(qName)) {
			prijmeni = new String(buffer);
		} else if ("maiden_name".equals(qName)) {
			rodnePrijmeni = new String(buffer);
		} else if ("gender".equals(qName)) {
			pohlavi = new String(buffer);
		} else if ("balance".equals(qName)) {
			balance = Double.parseDouble((buffer.toString()));
		} else if ("birth_date".equals(qName)) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			try {
				Date datumNarozeni = sdf.parse(buffer.toString());
				vek = TimeUnit.DAYS.convert((Calendar.getInstance().getTimeInMillis() - datumNarozeni.getTime()), TimeUnit.MILLISECONDS);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		} else if ("account".equals(qName)) {
			ucet.celkovyDluh+=balance;
			prehledUctu.put(ucet.typUctu, ucet);
			ucet = null;
			balance = null;
		}


		// uzavri buffer at se jedna o jakykoliv element
		buffer = null;
	}

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		if (qName.equals("client")) {
			if ("PERSON".equals(attributes.getValue(uri, "client_type"))) {
				String clientId=attributes.getValue(uri, "client_id");
				klient = new Klient(clientId);
			}
		} else if (qName.equals("account")){
			accountsStarted = true;
			String typUctu = attributes.getValue(uri, "account_type");
			ucet = prehledUctu.get(typUctu);
			if (ucet==null) {
				ucet = new Ucet(typUctu);
			}
			ucet.pocetUctu++;
			prehledUctu.put(typUctu, ucet);
		} else if (qName.equals("client_ref") && accountsStarted){
			Klient disponent = prehledKlientu.get(attributes.getValue(uri, "client_id_ref"));
			if (disponent!=null)
				disponent.pocetUctu++;
		}
		// zacni ukladat textovou hodnotu elementu pomoci metody characters()
		if ("first_name".equals(qName) ||
			"last_name".equals(qName) ||
			"maiden_name".equals(qName) ||
			"gender".equals(qName) ||
			"balance".equals(qName) ||
			"birth_date".equals(qName)
			) {
			buffer=new StringBuilder();
		}
		
	}

	public void characters(char buf[], int offset, int len) throws SAXException {
		String s = new String(buf, offset, len);
		if (buffer != null) {
			buffer.append(s);
		}
	}


	public void clearClientAttributes() {
		prijmeni = null;
		rodnePrijmeni = null;
		clientId = null;
		pohlavi = null;
		balance = null;
		vek = 0;
		klient = null;
	}
	
	public class Klient {
		String id;
		String first_name, last_name;
		int pocetUctu;
		HashSet<String> typyUcty = new HashSet<String>();

		public Klient(String id) {
			this.id = id;
		}
	}


	public class Ucet {
		String typUctu;
		Double celkovyDluh;
		int pocetUctu;

		public Ucet(String typUctu) {
			this.typUctu = typUctu;
			this.pocetUctu = 0;
			this.celkovyDluh = new Double(0.0);
		}
	}
	
	public void run() {
        String filename = "../../data.xml";
        
        try {            
            SAXParserFactory spfactory = SAXParserFactory.newInstance();
            spfactory.setValidating(false);
            
            SAXParser saxparser = spfactory.newSAXParser();
            
            XMLReader xmlreader = saxparser.getXMLReader();
            
            xmlreader.setContentHandler(new MySaxHandler());
            xmlreader.setErrorHandler(new MySaxHandler());
            
            InputSource source = new InputSource(filename);
            xmlreader.parse(source);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
	}

	public static void main(String[] args) {
    	new MySaxHandler().run();
    }
}
