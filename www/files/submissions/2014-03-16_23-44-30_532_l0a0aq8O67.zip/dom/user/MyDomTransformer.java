/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import org.w3c.dom.*;
import java.util.*;


public class MyDomTransformer {
    public void transform(Document xmlDocument) {
        Element doc = xmlDocument.getDocumentElement();
        
        
        Node persons = doc.getElementsByTagName("persons").item(0);
        
        // pridani osoby do databaze
        Element person = xmlDocument.createElement("person");
        Attr idAttr = xmlDocument.createAttribute("id");
        idAttr.setValue("per_100");
        Attr sexAttr = xmlDocument.createAttribute("sex");
        sexAttr.setValue("female");
        person.setAttributeNode(idAttr);
        person.setAttributeNode(sexAttr);
        Element name = xmlDocument.createElement("name");
        name.appendChild(xmlDocument.createTextNode("Ulrike Meinhof"));
        person.appendChild(name);
        
        persons.appendChild(person);
        
        
        // nejaka dalsi uprava (serazeni skupin podle nazvu)
        Node groupsElement = doc.getElementsByTagName("groups").item(0);
        
        NodeList grps = groupsElement.getChildNodes();
        removeChildNodes(groupsElement);
        
        
        ArrayList<Element> groups = new ArrayList<Element>();
        for(int i = 0; i < grps.getLength(); i++) {
            Node n = grps.item(i);
            if (n.getNodeType() == Node.ELEMENT_NODE) {
                groups.add((Element) n);
            }
        }
        
        Comparator<Element> nameComparator = new Comparator<Element>() {
            //@Override
            public int compare(Element a, Element b) {
                String nameA = a.getElementsByTagName("name").item(0).getTextContent();
                String nameB = b.getElementsByTagName("name").item(0).getTextContent();
                return nameA.compareTo(nameB);
            }
        };
        Collections.sort(groups, nameComparator);
        
        
        for(Element n : groups) {
            groupsElement.appendChild(n);
        }
        
        
    }
    
    
    
    
    private void removeChildNodes(Node node) {
        NodeList children = node.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            if (child.hasChildNodes()) {
                removeChildNodes(child);
            }
            node.removeChild(child);
        }
    }
}
