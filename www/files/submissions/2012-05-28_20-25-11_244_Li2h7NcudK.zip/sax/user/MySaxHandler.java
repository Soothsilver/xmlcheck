/*Tento handler prejde XML dokument, spocita pre kazdy element a atribut pocet
 jeho vyskytov. Navyse zisti maximalnu hlbku dokumentu a ako bonus najde element
 s najdlhsim lokalnym menom.
 
 * Autor: Martin Blicha*/

package user;
import java.util.HashMap;
import java.util.Map;
import org.xml.sax.*;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler; 

public class MySaxHandler extends DefaultHandler 
{ // overrides of DefaultHandler methods 
    int maxElementLocalNameLenght=0;
    int currentDepth;
    int maxElementDepth=0;
    String maxElementLocalName;
    Map<String,Integer> elements;
    Map<String,Integer> attributes;
    
    
    
    public void startDocument() {
	elements=new HashMap<String, Integer>();
	attributes=new HashMap<String,Integer>();
	currentDepth=0;
    }
    
    public void startElement(String namespaceURI, String localName, String qName, Attributes atts) throws SAXException {
	//checks if this element's name is the longest 
	if(localName.length()>maxElementLocalNameLenght)
	 {
	     maxElementLocalNameLenght=localName.length();
	     maxElementLocalName=localName;
	 }
	//counting depth
	currentDepth++;
	if(currentDepth>maxElementDepth){maxElementDepth=currentDepth;}
	
	 //counting elements
	 Integer count=elements.get(qName);
	 if(count==null)
	 {
	     count=0;
	 }
	 count++;
	 elements.put(qName, count);
	 
	 //counting attributes
	 for(int i=0;i<atts.getLength();i++)
	 {
	     String aName=atts.getQName(i);
	     count=attributes.get(aName);
	     if(count==null)
	     {
	       count=0;
	     }
	     count++;
	     attributes.put(aName, count);
	 }
    }
    
    public void endElement(String namespaceURI, String localName, String qName)
    {
	currentDepth--;
    }
    
    public void endDocument()
    {
	System.out.println("Statistiky xml dokumentu:");
	System.out.println();
	System.out.println("Tabulka vyskytu elementov");
	for(String key:elements.keySet())
	{
	    System.out.println("Element "+ key + " sa v dokumente vyskytol " + elements.get(key) + " krat.");
	}
	System.out.println();
	System.out.println("Tabulka vyskytu atributov");
	for(String key:attributes.keySet())
	{
	    System.out.println("Atribut "+ key + " sa v dokumente vyskytol " + attributes.get(key) + " krat.");
	}
	System.out.println();
	System.out.println("Element s najdlhsim menom je " + maxElementLocalName + ". Jeho dlzka je " + maxElementLocalNameLenght);
	System.out.println();
	System.out.println("Maximalna hlbka dokumentu je " + maxElementDepth);
    }
}