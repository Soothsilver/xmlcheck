/*Tato transformacia vezme z dokumentu vsetky elementy pocet_hracov a nahradi
 ich podelementy min a max atributmi.
 
 * Autor: Martin Blicha*/


package user;
import org.w3c.dom.Document; 
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class MyDomTransformer 
{ 
    public void transform (Document xmlDocument) 
    { 
	NodeList pocty=xmlDocument.getElementsByTagName("pocet_hracov");
	for(int i=0;i<pocty.getLength();i++)
	{
	    Element pocet=(Element)pocty.item(i);
	    Element min=(Element)pocet.getElementsByTagName("min").item(0);
	    pocet.setAttribute("min",min.getFirstChild().getNodeValue());
	    pocet.removeChild(min);	    
	    Element max=(Element)pocet.getElementsByTagName("max").item(0);
	    pocet.setAttribute("max",max.getFirstChild().getNodeValue());
	    pocet.removeChild(max);
	}
    }
}
