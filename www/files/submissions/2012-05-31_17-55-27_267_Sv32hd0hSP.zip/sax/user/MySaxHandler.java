package user;

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.*;

import java.util.*;

public class MySaxHandler extends DefaultHandler{

	ReadMode readMode;
	String tempValue;
	Set<String> allBrands;
	int numOfProducts;
	int sumOfAllPrices;
	int numOfSoldItems;
	
	// Mod, ktory nam vravi, ci sa prave nachadzame v elemente notebook, 
	// customer alebo sme niekde inde v dokumente
	enum ReadMode {
		Default,
		Notebook,
		Customer
	}
	
	 public MySaxHandler() {
		 try {
	 
		 }
		 catch (Exception e) {
			 e.printStackTrace();
			 System.exit(1);
	     }
	 }
	 
	 public void startDocument() throws SAXException {
		 readMode = ReadMode.Default;
		 allBrands = new HashSet<String>();
		 numOfProducts = 0;
		 sumOfAllPrices = 0;
	 }
	 
	 // Vypis statistiky
	 public void endDocument() throws SAXException {        
	        System.out.println("Statistics: ");
	        
	        
	        System.out.println("\tProducts brands count: \t"  + allBrands.size());
	        System.out.println("\tProducts count: \t" + numOfProducts);
	        System.out.println("\tProducts price sum: \t" + sumOfAllPrices);
	        System.out.println("\tNumber of sold items: \t" + numOfSoldItems);
	    }
	 
	 public void startElement(String namespaceURI, String localName, String qName, 
			 Attributes atts) throws SAXException {
		 tempValue = "";
		 
		 if(qName == "notebook") {
			 readMode = ReadMode.Notebook;
			 numOfProducts++;
		 } else if (qName == "customer") {
			 readMode = ReadMode.Customer;
		 }
	 }
	 
	 public void endElement(String uri, String localName, String qName) throws SAXException {
		 if(qName == "brand") {
			 allBrands.add(tempValue);
		 } else if(readMode == ReadMode.Notebook && qName == "price") {
			 sumOfAllPrices += Integer.parseInt(tempValue);
		 } else if (readMode == ReadMode.Customer && qName == "amount") {
			 numOfSoldItems += Integer.parseInt(tempValue);
		 }
		 
		 if(qName == "notebook" || qName == "customer") {
			 readMode = ReadMode.Default;
		 }
	 }
	 
	 //ulozenie hodnoty elementu do temp hodnoty
	 public void characters(char[] ch, int start, int length) throws SAXException {
			tempValue = new String(ch,start,length);
		}
	 
	 public void showEvent(String s) {
		 System.out.println("showevent: "+s);
	 }
	 
	 public void error (SAXParseException e) {
		 System.out.println("SAXParseException: error");
	        e.printStackTrace();
	 }
	 
	 public void warning (SAXParseException e) {
		 System.out.println("SAXParseException: warning");
	     e.printStackTrace();
	 }
	 
	 public void fatalError (SAXParseException e) {
	        System.out.println("SAXParseException: fatal error");
	        System.exit(1);
	 }
	
}
