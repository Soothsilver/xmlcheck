package user;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.*;

import javax.xml.transform.TransformerFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.OutputKeys;

import org.w3c.dom.Document;


public class MyDomTransformer {
	
	public void transform (Document xmlDocument) { 
    	Element root = xmlDocument.getDocumentElement();        
    	NodeList notebooks = root.getElementsByTagName("notebook");
    	
    	Element newRoot = xmlDocument.createElement("eshop");
    	
    	for(int i = 0; i < notebooks.getLength(); i++){

    		//kazdy notebook vyklonujeme a vymazeme len elementy brand, inStock, images
    		Element notebook = (Element)notebooks.item(i).cloneNode(true);
    		
    		Element brandElement = (Element) notebook.getElementsByTagName("brand").item(0);
    		Element inStock = (Element) notebook.getElementsByTagName("inStock").item(0);
    		Element images = (Element) notebook.getElementsByTagName("images").item(0);
    		
    		String notebookId = notebook.getAttribute("id");
    		notebook.removeAttribute("id");
    		
    		//zistime, kolko sa celkovo danych notebookov predalo
    		int soldAmount = 0;
    		NodeList allCartItems = xmlDocument.getElementsByTagName("cartItem");
    		for (int j = 0; j < allCartItems.getLength(); j++) {
    			Element cartItem = (Element) allCartItems.item(j).cloneNode(true);
    			
				Element productId = (Element)cartItem.getElementsByTagName("productId").item(0);
				String productIdString = productId.getAttribute("id");
				
				if(productIdString.equals(notebookId)) {
					Node amount = cartItem.getElementsByTagName("amount").item(0).cloneNode(true);
					soldAmount += Integer.parseInt(amount.getTextContent());
				}
			}
    		
    		Element soldAmoundElement = xmlDocument.createElement("soldAmount");
    		soldAmoundElement.setTextContent(Integer.toString(soldAmount));
    		
    		notebook.appendChild(soldAmoundElement);
    		
    		//odstranime novy riadok,ktory by nam zanechalo vymazanie vyssie spominanych elementov
    		notebook.removeChild(brandElement.getNextSibling());
    		notebook.removeChild(inStock.getNextSibling());
    		notebook.removeChild(images.getNextSibling());
    		
    		//vymazeme elementy
    		notebook.removeChild(brandElement);
    		notebook.removeChild(inStock);
    		notebook.removeChild(images);
    		
    		newRoot.appendChild(notebook);
		}
    	
    	//vymenime cely prvotny root za novy
    	xmlDocument.replaceChild(newRoot, root);
	}
	
	public void run() {
        
		String filename = "data.xml";
		String outfile = "data.out.xml";
		
		try {

            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setValidating(false);
            DocumentBuilder builder = dbf.newDocumentBuilder();       
            Document doc = builder.parse(filename);

            transform(doc);

            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer writer = tf.newTransformer();
            writer.setOutputProperty(OutputKeys.INDENT, "yes");
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            writer.transform(new DOMSource(doc), new StreamResult(new File(outfile)));

        } catch (Exception e) {
            
            e.printStackTrace();
            
        }
    }    
}
