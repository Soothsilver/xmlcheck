package user;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;


public class MyDomTransformer {

	private Document doc;


	public void transform(Document xmlDocument) {
		doc = xmlDocument;

		// pro kazdy tag 'usecase' transformuje
		// jeho atribut 'title' na podelement 'title'
		// viz transformUCTitle()
		NodeList usecases = doc.getElementsByTagName("usecase");
		for(int i = 0; i < usecases.getLength(); i++) {
			Node uc = usecases.item(i);
			transformUCTitle(uc);
		}

		// pro kazdy tag 'actor' transformuje
		// jeho atribut 'usecases' (seznam IDecek use casu, odd. mezerou)
		// na podelement 'usecases' s podelementy 'idref' pro kazde id v atributu
		// viz transformUsecasesAttr()
		NodeList actors = doc.getElementsByTagName("actor");
		for(int i = 0; i < actors.getLength(); i++) {
			Node actor = actors.item(i);
			transformUsecasesAttr(actor);
		}
	}


	/**
	 * Transformuje atribut 'title' elementu 'usecase' na podlement 'title'
	 * @param uc element 'usecase'
	 */
	private void transformUCTitle(Node uc) {
		// ziskam atributy
		NamedNodeMap attrs = uc.getAttributes();
		if(attrs == null) return;

		// ziskam atribut 'title'
		Node titleAttr = attrs.getNamedItem("title");
		if(titleAttr == null) return;

		// vytvorim novy element 'title' s textovym obsahem rovnym hodnote atributu
		Element titleEl = doc.createElement("title");
		titleEl.setTextContent(titleAttr.getTextContent());

		// aby element 'title' byl prvnim potomkem 'usecase',
		// vlozim ho pred prvniho potomka
		uc.insertBefore(titleEl, uc.getFirstChild());

		// nakonec smazu atribut 'title'
		attrs.removeNamedItem("title");
	}


	/**
	 * Transformuje atribut 'usecases' s IDckama oddelenymi mezerou jako hodnota
	 * atributu na podelement 'usecases' a podlemenety 'idref' pro kazde ID
	 * @param actor element 'actor'
	 */
	private void transformUsecasesAttr(Node actor) {
		// ziskam atributy
		NamedNodeMap attrs = actor.getAttributes();
		if(attrs == null) return;

		// ziskam atribut 'usecases'
		Node ucIds = attrs.getNamedItem("usecases");
		if(ucIds == null) return;

		// hodnotu atributu rozdelim podle bilych znaku na samostatna IDecka
		String[] ids = ucIds.getTextContent().trim().split("\\s+");

		// vytvorim novy element 'usecases'
		Element usecases = doc.createElement("usecases");

		// pro kazde ID v puvodnim atributu
		for(String id : ids) {
			if(id.isEmpty()) continue;

			// vytvorim element 'idref' s tim ID jako text. obsah
			Element ref = doc.createElement("idref");
			ref.setTextContent(id);

			// a vlozim do elementu 'usecases'
			usecases.appendChild(ref);
		}

		// nakonec pridam element 'usecases' jako potomka 'actor'
		actor.appendChild(usecases);

		// nakonec smazu atribut 'usecases'
		attrs.removeNamedItem("usecases");
	}


	public static void main(String[] args) {
		try {

			//DocumentBuilderFactory vytváří DOM parsery
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

			//nebudeme validovat
			dbf.setValidating(false);

			//vytvoříme si DOM parser
			DocumentBuilder builder = dbf.newDocumentBuilder();

			//parser zpracuje vstupní soubor a vytvoří z něj strom DOM objektů
			Document doc = builder.parse("data.xml");

			//zpracujeme DOM strom
			new MyDomTransformer().transform(doc);

			//TransformerFactory vytváří serializátory DOM stromů
			TransformerFactory tf = TransformerFactory.newInstance();

			//Transformer serializuje DOM stromy
			Transformer writer = tf.newTransformer();

			//nastavíme kodování
			writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

			//spustíme transformaci DOM stromu do XML dokumentu
			writer.transform(new DOMSource(doc), new StreamResult(System.out));


		} catch(Exception e) {

			e.printStackTrace();

		}
	}

}