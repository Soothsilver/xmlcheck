package user;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;


/**
 * /////////////////////////////////////////////////////////////////////////////////////////
 * Vypise minimalni, maximalni a prumerny pocet kroku vsech scenaru (vcetne
 * vnorenych kroku)
 * /////////////////////////////////////////////////////////////////////////////////////////
 *
 * @author Radek Ježdík <jezdik.radek@gmail.com>
 */
public class MySaxHandler extends DefaultHandler {

	// nalezene minimum
	private Integer min = null;

	// nalezene maximum
	private Integer max = null;

	// prumer 
	private Double avg = null;

	// pocitadlo kroku
	private int actualCount = 0;


	@Override
	public void startDocument() throws SAXException {
		// vypise info
		System.out.println("Minimalni, maximalni a prumerny pocet kroku vsech scenaru (vcetne vnorenych kroku):");
	}


	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		// pokud se jedna o step nebo include tag, zvysime pocitadlo o 1
		if(qName.equals("step") || qName.equals("include")) {
			actualCount++;
		}
	}


	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		// pokud narazime na konec scenare (tedy jsme spocitali vsechny kroky scenare)
		if(qName.equals("scenario")) {
			// pokud neni minimum nebo jsme nalezli nove minimum, nastavime
			if(min == null || actualCount < min) {
				min = actualCount;
			}

			// pokud neni maximum nebo jsme nalezli nove maximum, nastavime
			if(max == null || actualCount > max) {
				max = actualCount;
			}

			if(avg == null) {
				// pri prvnim pruchodu musime nastavit na aktualni pocet kroku
				avg = (double) actualCount;
			} else {
				// spocitame novy prumer kroku jako:
				// (stary_prumer + akt_pocet) / 2
				avg = (avg + actualCount) / 2d;
			}

			// nastavime akt. pocet na 0 a pokracuje se dalsim scenarem nebo program skonci a vypise info
			actualCount = 0;
		}
	}


	@Override
	public void endDocument() throws SAXException {
		// vypise konecne info o poctech kroku (min, max, avg)
		System.out.println("min:\t" + min);
		System.out.println("max:\t" + max);
		System.out.println("avg:\t" + avg);
	}


	public static void main(String[] args) {
		String filename = "data.xml";

		try {
			SAXParserFactory spfactory = SAXParserFactory.newInstance();
			spfactory.setValidating(false);

			SAXParser saxparser = spfactory.newSAXParser();

			XMLReader xmlreader = saxparser.getXMLReader();

			xmlreader.setContentHandler(new MySaxHandler());
			xmlreader.setErrorHandler(new MySaxHandler());

			InputSource source = new InputSource(filename);
			xmlreader.parse(source);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}