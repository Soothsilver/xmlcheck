/*
 * dom.java
 *
 * Created on 3/24/2007
 *
 * by Jan Konopasek, jjkon@seznam.cz
 *
 * program nacte soubor data.xml, pomoci DOM v nem nalezne vsechny elementy address,
 * vyjme je z mista vyskytu, zavede je jako zvlastni first-class elementy, na predchozi
 * mista vyskytu umisti reference na ne
 *
 */


import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import org.w3c.dom.*;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.FileOutputStream;
import cz.XmlTester.TestJava;


public class TestDom extends TestJava {

    private static void vypis (Node node) {
      System.out.println(node.getNodeName()+" = "+node.getNodeValue());

      for (Node child = node.getFirstChild();
          child != null;
          child = child.getNextSibling())
      {
      vypis(child);
      }
 }

    /**
     * @param args the command line arguments
     */
    public void run() {

        String filename = "../data.xml";
        String outfile = "../data.out.xml";

        File file = new File(filename);
        Document doc = null;

        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setValidating(false);
            DocumentBuilder builder = factory.newDocumentBuilder();
            doc = builder.parse(file);
        } catch (Exception e) {
            e.printStackTrace();
        }

        Node koren = doc.getElementsByTagName("netDB").item(0);
        NodeList adresy = doc.getElementsByTagName("address");
        int i,j;
        for (i=0;i<adresy.getLength();++i)
        {
            //Node nodeCopy = adresy.item(i).cloneNode(true);
            Node nodeCopy = doc.createElement("address-data");
            NodeList children = adresy.item(i).getChildNodes();
            for (j=0;j<children.getLength();++j)
            {
                nodeCopy.appendChild(children.item(j).cloneNode(true));
            }
            String addressId = "address_".concat(Integer.toString(i));

            Attr newId = doc.createAttribute("id");
            newId.setValue(addressId);
            nodeCopy.getAttributes().setNamedItem(newId);

            Node nodeRef = doc.createElement("address-ref");
            Attr idRef = doc.createAttribute("ref");
            idRef.setValue(addressId);
            nodeRef.getAttributes().setNamedItem(idRef);

            Node next = adresy.item(i).getNextSibling();
            Node parent = adresy.item(i).getParentNode();
            parent.insertBefore(nodeRef, next);

           koren.appendChild(nodeCopy);
        }

        for (i=0;i<doc.getElementsByTagName("address").getLength();++i)
        {
            Node old = doc.getElementsByTagName("address").item(i);
            old.getParentNode().removeChild(old);
            --i;
        }

      try {
        DOMSource source = new DOMSource(doc);
        StreamResult result = new StreamResult(new FileOutputStream(new File(outfile)));

        TransformerFactory transFactory = TransformerFactory.newInstance();
        Transformer transformer = transFactory.newTransformer();

        transformer.transform(source, result);
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
}

/* ruzne casti kodu, ktere nakonec nebyly pouzity:
 */      