/*
 * sax.java
 *
 * Created on 30. prosinec 2007, 19:04
 *
 * by Michal Pavlasek, pavlam2@gmail.com
 *
 * zdrojem pro cely program byly tutorialy na IBM developerWorks
 *
 * program nacte soubor data.xml, a pomoci SAX udalosti pro zacatek dokumentu,
 * zacatek elementu a konec dokumentu spocita a vypise pocty urcitych elementu
 */

import cz.XmlTester.TestJava;
import org.xml.sax.helpers.DefaultHandler;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.XMLReader;
import org.xml.sax.InputSource;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

class MyHandler extends DefaultHandler {
    
    int maxChars[];
    int elementCount[];
    int avgChars[];
    boolean openElements[];
    boolean pureText[];
    int currentChars[];
    String elements[];

    /**
     * Obsluha ud�losti "za��tek dokumentu"
     */
    public void startDocument() throws SAXException {

        maxChars = new int[50];
        elementCount = new int[50];
        avgChars = new int[50];
        openElements = new boolean[50];
        pureText = new boolean[50];
        currentChars = new int[50];
        elements = new String[50];
        for (int i=0;i<50;++i)
        {
            maxChars[i] = 0;
            avgChars[i] = 0;
            openElements[i] = false;
            pureText[i] = true;
            currentChars[i] = 0;
            elements[i] = "";
        }

    }
    /**
     * Obsluha ud�losti "konec dokumentu"
     */
    public void endDocument() throws SAXException {

        System.out.print("\nCharacter maxima and averages for pure-text elements:\n\n");
        for (int i=0;i<elements.length;++i)
        {
            if (elements[i].equals("")) break;
            else if (pureText[i])
            {
                System.out.print(elements[i].concat(" (").concat(Integer.toString(elementCount[i])).concat(" occurences) : ").concat(Integer.toString(maxChars[i]).concat(" max., ").concat(Integer.toString(avgChars[i])).concat(" average\n")));

            }
        }
        System.out.print("\nCharacter maxima and averages for other elements:\n\n");
        for (int i=0;i<elements.length;++i)
        {
            if (elements[i].equals("")) break;
            else if (!pureText[i])
            {
                System.out.print(elements[i].concat(" (").concat(Integer.toString(elementCount[i])).concat(" occurences) : ").concat(Integer.toString(maxChars[i]).concat(" max., ").concat(Integer.toString(avgChars[i])).concat(" average\n")));

            }
        }

    }

    /**
     * Obsluha ud�losti "za��tek elementu".
     * @param uri URI jmenn�ho prostoru elementu (pr�zdn�, pokud element nen� v ��dn�m jmenn�m prostoru)
     * @param localName Lok�ln� jm�no elementu (v�dy nepr�zdn�)
     * @param qName Kvalifikovan� jm�no (tj. prefix-uri + ':' + localName, pokud je element v n�jak�m jmenn�m prostoru, nebo localName, pokud element nen� v ��dn�m jmenn�m prostoru)
     * @param atts Atributy elementu
     */
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        boolean firstFind = true;
        int elementIndex = 0, newIndex = 0;
        for (int i=0;i<elements.length;++i)
        {
            if (elements[i].equals(""))
            {
                newIndex = i;
                break;
            }
            else if (elements[i].equals(localName))
            {
                firstFind = false;
                elementIndex = i;
            }
            else if (openElements[i])
            {
                pureText[i] = false;
            }
        }
        if (firstFind)
        {
            elements[newIndex] = localName;
            elementIndex = newIndex;
        }

        openElements[elementIndex] = true;
        currentChars[elementIndex] = 0;
    }
    /**
     * Obsluha ud�losti "konec elementu"
     * Parametry maj� stejn� v�znam jako u @see startElement
     */
    public void endElement(String uri, String localName, String qName) throws SAXException {

        boolean firstFind = true;
        int elementIndex = 0, newIndex = 0;
        for (int i=0;i<elements.length;++i)
        {
            if (elements[i].equals(""))
            {
                newIndex = i;
                break;
            }
            if (elements[i].equals(localName))
            {
                firstFind = false;
                elementIndex = i;
            }
        }
        if (!firstFind)
        {
            openElements[elementIndex] = false;
            if (maxChars[elementIndex] < currentChars[elementIndex]) maxChars[elementIndex] = currentChars[elementIndex];
            avgChars[elementIndex] = (avgChars[elementIndex] * elementCount[elementIndex] + currentChars[elementIndex]) / ++elementCount[elementIndex];
        }

    }

    /**
     * Obsluha ud�losti "znakov� data".
     * SAX parser mu�e znakov� data d�vkovat jak chce. Nelze tedy poc�tat s t�m, �e je cel� text dorucen v r�mci jednoho vol�n�.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakov�mi daty
     * @param start Index zac�tku �seku platn�ch znakov�ch dat v poli.
     * @param length D�lka �seku platn�ch znakov�ch dat v poli.
     */
    public void characters(char[] ch, int start, int length) throws SAXException {

        for (int i=0;i<elements.length;++i)
        {
            if (elements[i].equals("")) break;
            else if (openElements[i])
            {
                currentChars[i] += length;
            }
        }

    }
    
}

public class TestSax extends TestJava {    
   /**
     * main funkce
     */
    public void run() {
        
        String filename = "../data.xml";
        
        try {            
            SAXParserFactory spfactory = SAXParserFactory.newInstance();
            spfactory.setValidating(false);
            
            SAXParser saxparser = spfactory.newSAXParser();
            
            XMLReader xmlreader = saxparser.getXMLReader();
            
            xmlreader.setContentHandler(new MyHandler());
            xmlreader.setErrorHandler(new MyHandler());
            
            InputSource source = new InputSource(filename);
            xmlreader.parse(source);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
