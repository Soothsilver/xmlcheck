package user;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
   double pocetElementu;
   double soucetHodnoceni;
   double prumerneHodnoceni;
   int  hodnoceniVetsiNezDva;
   boolean surovina;
   HashMap<String,Integer> suroviny = new HashMap();
   
   @Override
    public void endDocument()  {
       prumerneHodnoceni = soucetHodnoceni/pocetElementu;
       Iterator it = suroviny.entrySet().iterator();
       int max = 0;
       String maxSurovina = "";
       while (it.hasNext()) {
            Map.Entry pairs = (Map.Entry)it.next();
            if((Integer)pairs.getValue() > max){
                max = (Integer)pairs.getValue();
                maxSurovina = (String)pairs.getKey();
            }
            
            it.remove(); 
        }
        System.out.println("Průměrné hodnocení receptů: " + prumerneHodnoceni);
        System.out.println("Nejčastější surovina v receptech: " + maxSurovina);
        System.out.println("Počet receptů s hodnocením vetším než 2: " + hodnoceniVetsiNezDva);
   }
   
   @Override
   public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
       if (localName.equals("recept")) {  
           if(atts.getValue("hodnoceni") != null){
               pocetElementu++;
               if(Integer.parseInt(atts.getValue("hodnoceni")) > 2){
                    hodnoceniVetsiNezDva++;
               }     
               soucetHodnoceni += Integer.parseInt(atts.getValue("hodnoceni"));  
           }
       }
       if (qName.equalsIgnoreCase("surovina")) {
           surovina = true;
       } 
   }
   
   @Override
   public void characters(char[] ch, int start, int length) throws SAXException {
        if (surovina) {    
            if(!suroviny.containsKey(new String(ch, start, length))){
                suroviny.put(new String(ch, start, length), 1);
            }    
            else{ 
                suroviny.put(new String(ch, start, length), suroviny.get(new String(ch, start, length))+1);
            }    
            surovina = false;
        }
    }
   
}