package user;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class MyDomTransformer {
    
    public void transform (Document xmlDocument) {
        // libovolne transformace objektu 'xmlDocument'
        // (metoda pracuje primo na objektu, nic nevraci)
        addRecept(xmlDocument);
        removeRecept(xmlDocument);
    }
    
    //Přidání nového receptu
    private void addRecept(Document doc){
        NodeList nodes = doc.getElementsByTagName("recepty");
        Element recepty;

        if(nodes.getLength()==0){
            recepty = doc.createElement("recepty");
            doc.getFirstChild().appendChild(recepty);
        } else {
            recepty = (Element)nodes.item(0);
        }
        Element recept = doc.createElement("recept");
        recept.setAttribute("autor", "U1");
        recept.setAttribute("kategorie", "desert");
        recept.appendChild(doc.createElement("titulek")).setTextContent("čokoládová zmrzlina");

        Element doba = doc.createElement("doba-pripravy");
        doba.setAttribute("doba", "1 hodina");
        recept.appendChild(doba);

        Element suroviny = doc.createElement("suroviny");
            Element surovina = doc.createElement("surovina");
            surovina.appendChild(doc.createElement("nazev")).setTextContent("cokolada");
            surovina.appendChild(doc.createElement("mnozstvi")).setTextContent("1ks");
                Element puvod = doc.createElement("puvod");
                    puvod.appendChild(doc.createElement("stat")).setTextContent("CR");
                    puvod.appendChild(doc.createElement("mesto")).setTextContent("Praha");
            surovina.appendChild(puvod);
            suroviny.appendChild(surovina);
        recept.appendChild(suroviny);    
        recept.appendChild(doc.createElement("popis")).setTextContent("čokoládová zmrzlina se dělá tak a tak");
        recept.appendChild(doc.createElement("obtiznost")).setTextContent("Tento recept je lehky");
        recepty.appendChild(recept);
    }
    
    //Smazání receptů s hodnocením 1
    public void removeRecept(Document doc){
        NodeList nodes = doc.getElementsByTagName("recept");
            for(int i=nodes.getLength()-1; i>=0; i--){
                Element recept = (Element)nodes.item(i);
                if(recept.getAttribute("hodnoceni") != null && !recept.getAttribute("hodnoceni").equals("") ){
                    if( Integer.parseInt(recept.getAttribute("hodnoceni")) == 1){
                    Element parent = (Element)recept.getParentNode();
                    parent.removeChild(recept);
                    }
                }    
            }
    }
    
}