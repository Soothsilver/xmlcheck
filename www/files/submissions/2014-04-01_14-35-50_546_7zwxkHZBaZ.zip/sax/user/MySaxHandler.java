package user;

import static java.lang.System.out;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
/*
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
//*/

public class MySaxHandler extends DefaultHandler {

    /*
    private static final String INPUT_FILE = "C:\\Users\\ressfi\\Downloads\\_school\\xml\\data.xml";
    @SuppressWarnings({"BroadCatchBlock", "TooBroadCatch", "UseSpecificCatch", "CallToThreadDumpStack"})
    public static void main(String[] args) {
        try {
            XMLReader parser = XMLReaderFactory.createXMLReader();
            InputSource source = new InputSource(INPUT_FILE);
            parser.setContentHandler(new CustomContentHandler());
            parser.parse(source);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

class CustomContentHandler implements ContentHandler {
//*/
    enum Section
    {
        Default,
        Ability,
        Champion
    }
    abstract class Entry
    {
        public String id;
        public String name;
    }
    class Ability extends Entry
    {
        public String target;
    }    
    class Champion extends Entry
    {
        //public List<Ability> abilities = new ArrayList<Ability>();
        public Ability[] abilities = new Ability[5];
        public int abilitiesLastIdx = 0;
        // Using arrays because generics throws error in http://xmlcheck.projekty.ms.mff.cuni.cz/
    }
    
    Locator locator;

    Section section = Section.Default;
    
    String lastValue = "";
    Entry lastEntry;
    
    int healthTotal;
    int champCount;    
    
    //List<Ability> abilites = new ArrayList<Ability>();
    //List<Champion> champions = new ArrayList<Champion>();
    Ability[] abilities = new Ability[35]; 
    int abilitiesLastIdx = 0;
    Champion[] champions = new Champion[7]; 
    int championsLastIdx = 0;
    // Using arrays because generics throws error in http://xmlcheck.projekty.ms.mff.cuni.cz/
    
    int magicAbilities = 0;
    int physicalAbilities = 0;

    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    @Override
    public void startDocument() throws SAXException {
    }

    @Override
    public void endDocument() throws SAXException {
        out.println("Champions: " + champCount);
        out.println("Average health: " + healthTotal / champCount);
        out.println();
        
        int aoeCount = 0;
        Champion c = null;
        //for (Champion champion : champions) {
        for (int i = 0; i < championsLastIdx; i++)
        {
            int counter = 0;
            //for (Ability ability : champion.abilities)
            for (int j = 0; j <  champions[i].abilitiesLastIdx; j++)
                if ( champions[i].abilities[j].target.equals("area"))
                    counter ++;
            if (c == null || counter > aoeCount)
            {
                c =  champions[i];
                aoeCount = counter;
            }
        }
        
        if (c != null && aoeCount != 0)
        {
            out.println("Champion with the most area-of-effect spells is "+c.name+" with "+aoeCount+" such spells.");
            out.println();
        }
        
        out.println("There are "+physicalAbilities+" abilties dealing physical damage and "+magicAbilities+" abilities dealing magical damage.");
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if (localName.equals("ChampionEntry"))
        {
            champCount++;
            section = Section.Champion;
            Champion c = new Champion();
            //champions.add(c);
            champions[championsLastIdx] = c;
            championsLastIdx++;
            lastEntry = c;
            
            lastEntry.id = atts.getValue("id");
        }                
        else if (localName.equals("AbilityEntry"))
        {
            section = Section.Ability;
            Ability a = new Ability();            
            //abilites.add(a);
            abilities[abilitiesLastIdx] = a;
            abilitiesLastIdx++;
            lastEntry = a;
            
            lastEntry.id = atts.getValue("id");
            ((Ability)lastEntry).target = atts.getValue("target");
        }
        else if (localName.equals("Ability") && section == Section.Champion)
        {
            Champion c = (Champion)lastEntry;
            String abilityId = atts.getValue("ability_id");
            //for (Ability ability : abilites) {
            for (int i = 0; i < abilitiesLastIdx; i++)
                if (abilities[i].id.equals(abilityId))
                {
                    //c.abilities.add(ability);
                    c.abilities[c.abilitiesLastIdx] = abilities[i];
                    c.abilitiesLastIdx++;
                    break;
                }
            
        }
        else if (localName.equals("Damage"))
        {
            if (atts.getValue("type").equals("magical")) magicAbilities++;
            else if (atts.getValue("type").equals("physical")) physicalAbilities++;
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        lastValue = lastValue.trim();
        if (localName.equals("AbilityEntry") || localName.equals("ChampionEntry"))
        {
            section = Section.Default;
            lastEntry = null;
        }
        else if (localName.equals("Health"))
        {
            healthTotal += Integer.valueOf(lastValue);
        }
        else if (localName.equals("Name"))
        {
            lastEntry.name = lastValue;            
        }
                
        lastValue = "";        
    }

    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        lastValue += String.copyValueOf(chars, start, length);
    }

    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
    }

    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
    }

    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
    }

    @Override
    public void processingInstruction(String target, String data) throws SAXException {
    }

    @Override
    public void skippedEntity(String name) throws SAXException {
    }
}
