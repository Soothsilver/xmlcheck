package user;

import org.w3c.dom.*;
/*
import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

//*/
public class MyDomTransformer {
/*
    
    private static final String INPUT_FILE = "C:\\Users\\ressfi\\Downloads\\_school\\xml\\data.xml";
    private static final String OUTPUT_FILE = "C:\\Users\\ressfi\\Downloads\\_school\\xml\\data.out.xml";
    @SuppressWarnings({"BroadCatchBlock", "TooBroadCatch", "UseSpecificCatch", "CallToThreadDumpStack"})
    public static void main(String[] args) {
        try {
            
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setValidating(false);
            DocumentBuilder builder = dbf.newDocumentBuilder();
            
            Document doc = builder.parse(INPUT_FILE);
            
            MyDomTransformer t = new MyDomTransformer();
            t.transform(doc);
            
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer writer = tf.newTransformer();
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            writer.transform(new DOMSource(doc), new StreamResult(new File(OUTPUT_FILE)));
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    } //*/

    public void transform (Document xmlDocument) {
        convertAllDamageTypes(xmlDocument, "physical", "magical");
        String ability = addGenericAbility(xmlDocument, 60);
        assignAbility(xmlDocument, "Lux", ability);
    }

    private void convertAllDamageTypes(Document xmlDocument, String fromType, String toType)
    {
        Node n = (Node)xmlDocument;
        if (null == (n = findFirstElementNode(n, "LeagueOfLegends"))) return;
        if (null == (n = findFirstElementNode(n, "AbilityEntries"))) return;
        
        NodeList abilities = n.getChildNodes();
        
        for (int i = 0; i < abilities.getLength(); i++) {
            Node abilityEntry = abilities.item(i);
            
            if (null == (n = findFirstElementNode(abilityEntry, "Effects"))) continue;            
            NodeList effects = n.getChildNodes();
            
            for (int j = 0; j < effects.getLength(); j++) {
                Node effectEntry = effects.item(j);
                
                if (effectEntry.getNodeType() != Node.ELEMENT_NODE) continue;
                if (!effectEntry.getNodeName().equals("Damage")) continue;                
                if (null == (n = effectEntry.getAttributes().getNamedItem("type"))) continue;
                
                if (n.getTextContent().equals(fromType))
                {
                    ((Element)effectEntry).setAttribute("type", toType);                    
                }
            }
        }
    }
    
    private String addGenericAbility(Document xmlDocument, int dmg)
    {
        // Find proper location
        Node n = (Node)xmlDocument;
        if (null == (n = findFirstElementNode(n, "LeagueOfLegends"))) return null;
        if (null == (n = findFirstElementNode(n, "AbilityEntries"))) return null;

        // Make sure we have unique id among abilities
        String idbase = "aGeneric";
        int counter = 1;
        String id = idbase;
        boolean uniqueAbilityId = false;

        while (!uniqueAbilityId)
        {
            uniqueAbilityId = true;
            NodeList abilities = n.getChildNodes();
            for (int i = 0; i < abilities.getLength(); i++) {

                Node abilityEntry = abilities.item(i);
                if (abilityEntry.getNodeType() != Node.ELEMENT_NODE) continue;
                if (!abilityEntry.getNodeName().equals("AbilityEntry")) continue;

                Node idn;
                if (null == (idn = abilityEntry.getAttributes().getNamedItem("id"))) continue;
                String abilityid = idn.getTextContent();
                
                if (abilityid.equals(id))
                {
                    counter++;
                    id = idbase + String.valueOf(counter);
                    uniqueAbilityId = false;
                    break;
                }
            }
        }
        
        // Build new ability
        Element ability = xmlDocument.createElement("AbilityEntry");
        ability.setAttribute("id", id);
        ability.setAttribute("target", "area");
        ability.appendChild(xmlDocument.createElement("Name")).setTextContent("Generic ability");
        ability.appendChild(xmlDocument.createElement("Description")).setTextContent("Champion uses generic AoE ability.");
        
        Element effects = xmlDocument.createElement("Effects");
        
        Element e = xmlDocument.createElement("Damage");
        e.setTextContent(String.valueOf(dmg));
        e.setAttribute("type", "physical");
        effects.appendChild(e);
        
        ability.appendChild(effects); 
        
        // Append new ability
        n.appendChild(ability);
        
        return id;
    }
    private void assignAbility(Document xmlDocument, String champion, String abilityId)
    {
        Node n = (Node)xmlDocument;
        if (null == (n = findFirstElementNode(n, "LeagueOfLegends"))) return;
        if (null == (n = findFirstElementNode(n, "ChampionEntries"))) return;
        
        NodeList champions = n.getChildNodes();
        for (int i = 0; i < champions.getLength(); i++) {

            Node championEntry = champions.item(i);
            if (championEntry.getNodeType() != Node.ELEMENT_NODE) continue;
            if (!championEntry.getNodeName().equals("ChampionEntry")) continue;

            if (null == (n = findFirstElementNode(championEntry, "Name"))) continue;
            if (!n.getTextContent().equals(champion)) continue;
            
            if (null == (n = findFirstElementNode(championEntry, "Abilities"))) continue;
            
            Element ability = xmlDocument.createElement("Ability");
            ability.setAttribute("ability_id", abilityId);
            n.appendChild(ability);
        }        
    }
    
    private Node findFirstElementNode(Node n, String s)
    {
        NodeList nl = n.getChildNodes();
        for (int i = 0; i < nl.getLength(); i++) {
            Node cn = nl.item(i);
            if (cn.getNodeType() != Node.ELEMENT_NODE) continue;
            if (cn.getNodeName().equals(s))
            {
                return cn;
            }
        }
        return null;
    }
}