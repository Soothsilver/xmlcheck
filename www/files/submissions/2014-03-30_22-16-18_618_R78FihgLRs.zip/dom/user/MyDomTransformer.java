package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

/**
 *
 * @author Eldar.Iosip
 */
public class MyDomTransformer {

    public static void transform(Document xmlDocument) {
        //Prida novy clanek
        Element articles = (Element) xmlDocument.getElementsByTagName("articles").item(0);
        Element article = xmlDocument.createElement("article");
        Element author = xmlDocument.createElement("author");
        Element text = xmlDocument.createElement("text");
        Text authorName = xmlDocument.createTextNode("Ondrej Novak");
        Text articleText = xmlDocument.createTextNode("Space Suit Evolution - NASA's");
        article.appendChild(author);
        article.appendChild(text);
        author.appendChild(authorName);
        text.appendChild(articleText);
        articles.appendChild(article);

        //Odebere vsechny mobily Samsung
        Element androidPhones = (Element) xmlDocument.getElementsByTagName("android").item(0);
        NodeList phones = androidPhones.getElementsByTagName("phone");

        for (int i = 0; i < phones.getLength(); i++) {
            Element phone = (Element) phones.item(i);
            if (phone.getElementsByTagName("brand").item(0).getTextContent().equals("Samsung")) {
                phone.getParentNode().removeChild(phone);
            }
        }
    }
}
