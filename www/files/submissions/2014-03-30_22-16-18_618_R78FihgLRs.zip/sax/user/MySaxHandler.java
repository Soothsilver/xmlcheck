package user;

import java.util.ArrayList;
import java.util.List;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Ukoly. 1) min a max tloustka mobilu; 2) prumerna vaha mobilu v g; 3) pocet
 * mobilu, ktere maji velikost displaye > 5.0 a vyska je mensi nebo rovna 6.3cm
 *
 * @author Eldar.Iosip
 */
public class MySaxHandler extends DefaultHandler {

    double minThickness = Double.MAX_VALUE, maxThickness = Double.MIN_VALUE;

    List<Phone> phones = new ArrayList<Phone>();

    boolean isWeight, isGramms, isDisplay, isSize;

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        if (localName.equals("phone")) {
            phones.add(new Phone());
        } else if (localName.equals("dimensions")) {
            double t = Double.parseDouble(attributes.getValue("t"));
            phones.get(phones.size() - 1).weightInGramms = Double.parseDouble(attributes.getValue("h"));
            if (t > maxThickness) {
                maxThickness = t;
            }
            if (t < minThickness) {
                minThickness = t;
            }
        } else if (localName.equals("weight")) {
            isWeight = true;
        } else if (localName.equals("g")) {
            //Jenom pojistka, ze vytahnu potrebny <g>
            if (isWeight) {
                isGramms = true;
                isWeight = false;
            }
        } else if (localName.equals("display")) {
            isDisplay = true;
        } else if (localName.equals("size")) {
            if (isDisplay) {
                isDisplay = false;
                isSize = true;
            }
        }

    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        isGramms = isDisplay = false;
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        String content = "";

        for (int i = start; i < start + length; i++) {
            content += ch[i];
        }

        if (isGramms) {
            phones.get(phones.size() - 1).weightInGramms = Double.parseDouble(content);
        } else if (isSize) {
            phones.get(phones.size() - 1).displaySize = Double.parseDouble(content);
        }
    }

    @Override
    public void endDocument() throws SAXException {
        double avgWeight = 0;
        int count = 0;

        for (Phone phone : phones) {
            avgWeight += phone.weightInGramms;
            if (phone.displaySize > 5 && phone.heightInCm <= 6.3) {
                count++;
            }
        }

        System.out.println("min thickness = " + minThickness + " and max thickness = " + maxThickness);
        System.out.println("average weight = " + avgWeight);
        System.out.println("number of phones with lcd size > 5.0 and height is less than 6.3cm = " + count);
    }

}

class Phone {

    double weightInGramms = 0;
    double heightInCm = 0;
    double displaySize = 0;
}
