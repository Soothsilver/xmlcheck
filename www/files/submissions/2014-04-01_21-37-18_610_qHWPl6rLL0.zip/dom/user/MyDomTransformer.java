package user; 
import java.util.ArrayList;
import java.util.List;
import org.w3c.dom.*;
import org.w3c.dom.Document; 
public class MyDomTransformer 
{ 
    public void transform (Document xmlDocument) 
    { 
        //put your code here
        Element ZamestnanciRoot = (Element)(xmlDocument.getElementsByTagName("Zamestnanci").item(0));
        
        // (Pridani noveho zamestnance)
        Element NovyZamestnanec = xmlDocument.createElement("Zamestnanec");
        NovyZamestnanec.setAttribute("Jmeno", "Terry");
        NovyZamestnanec.setAttribute("Prijmeni", "Elisnova");
        NovyZamestnanec.setAttribute("Vek", "100");
        Element NovyPlat = xmlDocument.createElement("Plat");
        NovyPlat.setTextContent("40000");
        
        NovyZamestnanec.appendChild(NovyPlat);        
        
        ZamestnanciRoot.appendChild(NovyZamestnanec);
        // (/Pridani noveho zamestnance)
        
        // (Setrizeni zamestnancu podle veku)
        NodeList Zamestnanci = xmlDocument.getElementsByTagName("Zamestnanec");        
        List<Node> Zamestnanci_Vek = new ArrayList<Node>();
        
        for(int i = 0; i< Zamestnanci.getLength(); i++)
        {
            Integer pozice = 0;
            Integer PosledniNejvyssiVek = 0;
            
            Integer Vek_puvodni_seznam = Integer.parseInt(((Element)Zamestnanci.item(i)).getAttribute("Vek"));
            for(int j = 0; j < Zamestnanci_Vek.size(); j++)
            {                
                Integer Vek_novy_seznam = Integer.parseInt(((Element)Zamestnanci_Vek.get(j)).getAttribute("Vek"));
                if(Vek_puvodni_seznam >= Vek_novy_seznam && PosledniNejvyssiVek <= Vek_novy_seznam) 
                {
                    pozice = j;
                    PosledniNejvyssiVek = Vek_novy_seznam;
                }
            }
            
            if(pozice != 0) 
            {
                if(pozice == Zamestnanci_Vek.size() - 1) Zamestnanci_Vek.add(Zamestnanci.item(i));
                else Zamestnanci_Vek.add(pozice + 1, Zamestnanci.item(i));
                continue;
            } 
            Zamestnanci_Vek.add(0, Zamestnanci.item(i)); 
        }
        
        for(int i = 0; i < Zamestnanci_Vek.size(); i++)
        {
            ZamestnanciRoot.removeChild(Zamestnanci_Vek.get(i));
        }        
        
        for(int i = 0; i < Zamestnanci_Vek.size(); i++)
        {
            ZamestnanciRoot.appendChild(Zamestnanci_Vek.get(i));
        }
        // (/Setrizeni zamestnancu podle veku)
    } 
} 






