package user; 
import org.xml.sax.helpers.DefaultHandler; 

import java.util.ArrayList;
import java.util.List;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;

public class MySaxHandler extends DefaultHandler 
{ 
    // overrides of DefaultHandler methods 
    
    // Helper variable to store location of the handled event
    Locator locator;
    
    //Prumer cen zbozi
    private List<Integer> cenaZbozi_AVG = new ArrayList<Integer>(); 
    
    //Minimalni a Maximalni plat
    private Boolean PlatNode = false;
    private Integer MaxPlat = 0;
    private Integer MinPlat = Integer.MAX_VALUE;
        
    //Vypsat zbozi hodnoty nad "OdCenaVyrobku" s prodeji nizsimi nez "MinTrzba"
    private static final Integer OdCenaVyrobku = 15000;
    private static final Integer MinTrzba = 100000;    
    private List<String[]> VyrobkyCenaPocet = new ArrayList<String[]>();
    private Boolean PolozkaNode = false;
    private String PolozkaVyrobekNazev = "";

    
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    @Override
    public void startDocument() throws SAXException {
        
    }

    @Override
    public void endDocument() throws SAXException {        
        //Prumerna cena zbozi - Prace s atributy
        Double AVRG = Double.MIN_NORMAL;
        for (int i = 0; i < cenaZbozi_AVG.size(); i++) 
        {
            AVRG += cenaZbozi_AVG.get(i);
        }
        AVRG = AVRG / cenaZbozi_AVG.size();
        System.out.println("AVRG cena zbozi: " + AVRG.toString());
        
        //MaxPlat, MinPlat - Prace s obsahem elementu
        System.out.println("Maximalni plat: " + MaxPlat);
        
        System.out.println("Minimalni plat: " + MinPlat);
        
        //Kontext - Vyrobek s cenou "OdCenaVyrobku", jehoz trzby jsou mensi nez "MinTrzba"
        for(int i = 0; i < VyrobkyCenaPocet.size(); i++)
        {            
            Integer CenaVyrobku = Integer.parseInt(VyrobkyCenaPocet.get(i)[1]);
            
            if(CenaVyrobku >= OdCenaVyrobku)
            {                
                Integer PocetObjVyrobku = Integer.parseInt(VyrobkyCenaPocet.get(i)[2]);
                Integer Trzba = PocetObjVyrobku * CenaVyrobku;
                if(Trzba < MinTrzba)
                {
                    String NazevVyrobku = VyrobkyCenaPocet.get(i)[0];
                    System.out.println("Neprodava se: " + NazevVyrobku);
                }
            }
        }
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if(localName.equals("Vyrobek")) 
        { 
            cenaZbozi_AVG.add(Integer.parseInt(atts.getValue(1)));
            VyrobkyCenaPocet.add(new String[] { atts.getValue(0), atts.getValue(1), "0" });
        } 
        else if(localName.equals("Plat"))
        {
            PlatNode = true;
        }
        else if(localName.equals("Polozka"))
        {
            PolozkaNode = true;
            PolozkaVyrobekNazev = atts.getValue(0);
        }        
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if(localName.equals("Plat")) 
        {
            PlatNode = false;
        }
        else if(localName.equals("Polozka"))
        {
            PolozkaNode = false;
        }    
    }

    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        if(PlatNode) 
        { 
            Integer plat = Integer.parseInt(new String(chars, start, length));
            if(plat > MaxPlat) MaxPlat = plat;
            if(plat < MinPlat) MinPlat = plat;
        }
        else if(PolozkaNode)
        {
            Integer pocet = Integer.parseInt(new String(chars, start, length));
            String JmenoVyrobku = PolozkaVyrobekNazev;
            
            for(int i = 0; i< VyrobkyCenaPocet.size(); i++)
            {
                if(VyrobkyCenaPocet.get(i)[0].equals(JmenoVyrobku))
                {
                    pocet = Integer.parseInt(VyrobkyCenaPocet.get(i)[2]) + pocet;
                    VyrobkyCenaPocet.get(i)[2] = pocet.toString();
                }
            }            
        }
    }
    
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }
    
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }
    
    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
        // ...
    }
    
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }
    
    @Override
    public void skippedEntity(String name) throws SAXException {
        // ...
    }
}






