package xmlko;

import user.MySaxHandler;
import user.MyDomTransformer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

public class XMLko {

    public static void main(String[] args) {
        
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setValidating(false);
        DocumentBuilder builder;
        try {
            builder = dbf.newDocumentBuilder();
            Document doc = builder.parse("data.xml");

            MyDomTransformer T = new MyDomTransformer();
            T.transform(doc);

        } catch (Exception ex) {
            Logger.getLogger(XMLko.class.getName()).log(Level.SEVERE, null, ex);
        }

        String sourcePath = "data.xml";

        try {

            XMLReader parser = XMLReaderFactory.createXMLReader();
            InputSource source = new InputSource(sourcePath);
            parser.setContentHandler(new MySaxHandler());
            parser.parse(source);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
