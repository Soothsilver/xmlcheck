package user;

import org.xml.sax.SAXException;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
    
    //Spocita prumerny pocet atributu jednotlivych elementu v dokumentu.

    private int elCount; //element count
    private int attCount; //attribute count

    Locator locator;
    
   
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }
    
    @Override
    public void startDocument() throws SAXException {
        elCount = 0;
        attCount = 0;
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        attCount += atts.getLength();
        elCount++;
    }

    @Override
    public void endDocument() throws SAXException {
        double average = (double)attCount/elCount;
        System.out.println("Average attribute count of an element is: " + average);
    }
}
