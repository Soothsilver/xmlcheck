package user;

import java.io.File;
import org.w3c.dom.Document;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class MyDomTransformer {


    public void transform(Document doc) {
        //elementy, ktere maji jenom kratke textove hodnoty odstran a pridej je jako atributy rodicu
        try {

            Element e = doc.getDocumentElement();
            if (e.getChildNodes().getLength() > 0) {
                processElement(e);
            }

            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer writer = tf.newTransformer();
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            writer.transform(new DOMSource(doc), new StreamResult(new File("data.out.xml")));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private static void processElement(Element e) {
        NodeList nl = e.getChildNodes();
        Element child;
        if (e.getTagName().equals("recept")) {
            return; //do receptu nesahej, tam jsou dlouhe textove uzly
        }
        for (int i = 0; i < nl.getLength(); i++) {
            if (nl.item(i) instanceof Element) {
                child = (Element) nl.item(i);
                if (child.hasChildNodes()) {
                    processElement(child);
                }
                //pro uzly s max jednim childem bez atributu
                if (!child.hasAttributes() && child.getChildNodes().getLength() <= 1) {
                    e.setAttribute(child.getTagName(), child.getTextContent());
                    e.removeChild(child);
                }
            }
        }
        e.normalize();
    }
}
