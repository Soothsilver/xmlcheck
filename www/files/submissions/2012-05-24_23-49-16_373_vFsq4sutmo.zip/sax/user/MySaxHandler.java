package user;

import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;


public class MySaxHandler extends DefaultHandler {
    

    public static void main(String[] args) {

        String sourcePath = "data.xml";

        try {
            
            XMLReader parser = XMLReaderFactory.createXMLReader();
            
            InputSource source = new InputSource(sourcePath);
            
            parser.setContentHandler(new MujContentHandler());
            
            parser.parse(source);            
            
        } catch (Exception e) {
        
            e.printStackTrace();
            
        }
        
    }
    
}
class MujContentHandler implements ContentHandler {

    private int pocetElementuStextObsahem = 0;;
    private int pocetElementuSatributy = 0;
    private boolean element = false;
    private float soucetDelek = 0;    
    
    Locator locator;
         
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }
    
    public void startDocument() throws SAXException {
        
        
    }
 
    public void endDocument() throws SAXException {

        float avgDelka = this.soucetDelek/this.pocetElementuStextObsahem;
        
        System.out.println("Pocet elementu s textovym obsahem: " + this.pocetElementuStextObsahem);
        System.out.println("Prumerna delka retezcu uvnitr elementu s textovym obsahem: " + avgDelka);
        System.out.println("Pocet elementu s atributy: " + this.pocetElementuSatributy);
        
        
    }
    
    
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        this.element = true;
        
        if (atts.getLength() > 0)
            this.pocetElementuSatributy++;
        

    }
 
    public void endElement(String uri, String localName, String qName) throws SAXException {

        this.element = false;

    }
    
       
    public void characters(char[] ch, int start, int length) throws SAXException {

        if (this.element == true) {
            String text = "";
            for (int i = start; i < start+length; i++) {
                text += ch[i];
            }
            text = text.replace("\n", "");
            text = text.replace("\t", "");
            if (text.length() > 0) {
                this.pocetElementuStextObsahem++;
                this.soucetDelek += text.length();
            }
        }
        
    }
    
  
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
        // ...
        
    }

     
    public void endPrefixMapping(String prefix) throws SAXException {
    
        // ...
    
    }

   
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
        // ...
        
    }

     
    public void processingInstruction(String target, String data) throws SAXException {
      
      // ...
            
    }
    
    public void skippedEntity(String name) throws SAXException {
    
      // ...
    
    }
}