package user;

import java.io.File;

import java.util.LinkedList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

/**
 * ZADANI:
 * Upravte program tak, aby transformoval vstupní XML dokument na výstupní pomocí akcí
 * uvedených v komentářích metody processTree(doc).
 */
public class MyDomTransformer {

    private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "data.out.xml";

    public static void main(String[] args) {
        
        try {
            
            //DocumentBuilderFactory vytváří DOM parsery
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            //nebudeme validovat
            dbf.setValidating(false);

            //vytvoříme si DOM parser
            DocumentBuilder builder = dbf.newDocumentBuilder();

            //parser zpracuje vstupní soubor a vytvoří z něj strom DOM objektů
            Document doc = builder.parse(VSTUPNI_SOUBOR);

            MyDomTransformer mdt = new MyDomTransformer();
            
            //zpracujeme DOM strom
            mdt.transform(doc);

            //TransformerFactory vytváří serializátory DOM stromů
            TransformerFactory tf = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer = tf.newTransformer();

            //nastavíme kodování
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spustíme transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


        } catch (Exception e) {
            
            e.printStackTrace();
            
        }
    }

    /**
     * Zpracuje DOM strom
     */
    public void transform (Document xmlDocument) {
        
        //tento kod vybere pouze treninkove zaznamy pro vybraneho uzivatele
        //uzivatel se urci pres atribut id u elementu <uzivatel>
        
        String idUzivatele = "m1"; //zde id uzivatele, pro ktereho chci vybrat treninky
        
        NodeList uzivatele = xmlDocument.getElementsByTagName("uzivatel");
    
        for (int i = 0; i < uzivatele.getLength(); i++) {
            NamedNodeMap mapa = uzivatele.item(i).getAttributes();
            boolean pom = false;
            for (int j = 0; j < mapa.getLength(); j++) {
                if (mapa.item(j).getNodeValue().equals(idUzivatele))
                    pom = true;
            }
            if (pom == false)
                 uzivatele.item(i).getParentNode().removeChild(uzivatele.item(i));
        }
        
        
  }
}

