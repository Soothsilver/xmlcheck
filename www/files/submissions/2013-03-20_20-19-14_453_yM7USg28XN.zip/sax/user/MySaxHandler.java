package user;

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

public class MySaxHandler extends DefaultHandler {

    /*
     * zkouma tyto charakteristiky:
     * pocet bodovych a casovych skipassu(zavysi na atributu)
     * celkovou delku sjezdovek(zavysi na elementu)
     * prumerny plat zamestnance na pozici udrzba(zavysi na kontextu)
     */

    //booleanovske promenne urcujuci, zda se nachazime uvnitr daneho elementu
    boolean sjezdovka, delka, zamestnanec, pozice, plat;
    //ciselne hodnoty zkoumanych charakteristik
    int celkovaDelka, casovych, bodovych, pocetZamestnancu, celkovyPlat;
    //string obsahujici informaci o pozici na ktere pracuje aktualne zkoumany zamestnanec
    String poziceAkt;

    @Override
    public void startDocument() throws SAXException {
        //na zacatku dokumentu nastavim vsechny promenne
        sjezdovka = false;
        delka = false;
        celkovaDelka = 0;
        casovych = 0;
        bodovych = 0;
        pocetZamestnancu = 0;
        zamestnanec = false;
        pozice = false;
        plat = false;
        poziceAkt = "";
    }
    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
        //na konci dokumentu vypisi zjistene charakteristiky
        System.out.println("Bylo vystaveno " + bodovych + " bodovych skipassu a " + casovych + " casovych skipassu.");
        System.out.println("Celkova delka sjezdovek je: " + celkovaDelka);
        System.out.println("Prumerny plat zamestnancu na pozici udrzba je: " + celkovyPlat/pocetZamestnancu);
    }

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        //v elementu skipass
        if(qName.equals("skipass")){
            //prochazim atributy
            for(int i=0; i<atts.getLength(); ++i){
                if(atts.getQName(i).equals("typ")){
                    //u atributu typ zvysim pocitadlo v zavyslosti na jeho hodnote
                    String value = atts.getValue(i);
                    if(value.equals("casovy")){
                        ++casovych;
                    }
                    if(value.equals("bodovy")){
                        ++bodovych;
                    }
                }
            }
        }
        if(qName.equals("sjezdovka")){
            sjezdovka=true;
        }
        if(sjezdovka && qName.equals("delka")){
            delka = true;
        }
        if(qName.equals("zamestnanec")){
            zamestnanec = true;
        }
        if(zamestnanec && qName.equals("pozice")){
            pozice = true;
        }
        if(zamestnanec && qName.equals("plat")){
            plat = true;
        }
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if(qName.equals("lanovka")){
            sjezdovka=false;
        }
        if(qName.equals("delka")){
            delka=false;
        }
        if(qName.equals("zamestanenc")){
            //kdyz opoustim element zamestnanec nuluji i informaci o jeho pozici
            zamestnanec = false;
            poziceAkt = "";
        }
        if(qName.equals("pozice")){
            pozice = false;
        }
        if(qName.equals("plat")){
            plat = false;
        }
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        if(delka){
            //pokud jsem uvnitr elementu delka prictu delku k celkove
            celkovaDelka += Integer.parseInt(new String(chars, start, length));
        }
        if(pozice){
            //ulozim pozici aktualne zkoumaneho zamestnance
            poziceAkt = new String(chars, start, length);
        }
        if(plat && poziceAkt.equals("udrzba")){
            //pokud je aktualne zkoumany zamestnanec na pozici udrzba a jsem v elementu plat prictu plat do celkoveho a zvysim pocitadlo zamestnancu na zkoumane pozici
            celkovyPlat += Integer.parseInt(new String(chars, start, length));
            ++pocetZamestnancu;
        }
    }
}
