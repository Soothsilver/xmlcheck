package user;

import org.w3c.dom.Document;
import org.w3c.dom.*;

/**
 *
 * @author Pavel
 */
public class MyDomTransformer {

    public void transform(Document xmlDocument){
        //pridava jednoho zamestnance se vsemi parametry
        pridejZamestnance(xmlDocument);
        //maze skipassy, ktery uz nemaji zadne body
        smazNeplatneSkipassy(xmlDocument);
    }

    private void pridejZamestnance(Document doc){
        NodeList list = doc.getElementsByTagName("zamestnanci");
        Element zamestnanci;
        //ziskam element zamestnanci pokud neexistuje tak ho vytvorim:
        if(list.getLength()>0){
            zamestnanci = (Element)list.item(0);
        } else{
            zamestnanci = doc.createElement("zamestnanci");
        }
        //vytvorim noveho zamestnance a nastavim mu parametry:
        Element zamestnanec = doc.createElement("zamestnanec");
        zamestnanec.setAttribute("id", "zid_6");
        zamestnanec.appendChild(doc.createElement("rodne_cislo")).setTextContent("8606214586");
        zamestnanec.appendChild(doc.createElement("jmeno")).setTextContent("Frantisek");
        zamestnanec.appendChild(doc.createElement("prijmeni")).setTextContent("Tichy");
        zamestnanec.appendChild(doc.createElement("pozice")).setTextContent("kasa");
        zamestnanec.appendChild(doc.createElement("plat")).setTextContent("21000");
        Element pouziva = doc.createElement("pouziva");
        pouziva.setAttribute("id_ref", "kid_2");
        zamestnanec.appendChild(pouziva);

        //pridam zamestnance do elementu zamestnanci
        zamestnanci.appendChild(zamestnanec);
    }

    private void smazNeplatneSkipassy(Document doc){
        //najdu vsechny elementy skipass:
        NodeList skipassy = doc.getElementsByTagName("skipass");
        //a prochazim je:
        for(int i=0; i<skipassy.getLength(); ++i){
            Element skipass = (Element)skipassy.item(i);
            //pokud je skipass bodovy:
            if(skipass.getAttribute("typ").equals("bodovy")){
                //a nema jiz zadne body:
                if(Integer.parseInt(skipass.getElementsByTagName("pocet_bodu").item(0).getTextContent())<=0){
                    Element parent = (Element)skipass.getParentNode();
                    //odstranim ho z dokumentu:
                    parent.removeChild(skipass);
                }
            }
        }
    }
}
