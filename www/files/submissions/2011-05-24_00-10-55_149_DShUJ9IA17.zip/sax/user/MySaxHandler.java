/*
* Spocita prumernou delku nazvu vzoru. 
* (hodnot attributu 'name' elementu 'pattern')
*/

package user;

import java.io.File;
import java.util.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import org.w3c.dom.*;
import org.xml.sax.*;
import org.xml.sax.helpers.*;

public class MySaxHandler extends DefaultHandler {

    private int sum;

    private int count;

    @Override
    public void startDocument() throws SAXException {
        this.sum = 0;
        this.count = 0;
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes)
            throws SAXException {
        if (qName.equals("pattern") == false) {
            return;
        }
        for (int i = 0; i < attributes.getLength(); i++) {
            if (attributes.getQName(i).equals("name")) {
                this.sum += attributes.getValue(i).length();
                this.count++;
            }
        }
    }

    @Override
    public void endDocument() throws SAXException {
        System.out.println(
                "Prumerna delka attributu 'name' u elementu 'pattern': " +
                this.sum / this.count);
    }
}
