/*
* Odstrani z dokumentu vzory (elementy 'pattern') a nebo role (elementy 'role'), 
* ktere budto vubec nemaji child element description/summary a nebo textovy obsah 
* child elementu description/summary neni dostatecne dlouhy. 
* (parametr je nastaveny na 120).
*/

package user;

import java.io.File;
import java.util.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import org.w3c.dom.*;
import org.xml.sax.*;
import org.xml.sax.helpers.*;

public class MyDomTransformer {
	public void transform (Document xmlDocument) {
		DomTransformer.Transform(xmlDocument, 120);	
	}
}

class DomTransformer {
    public static void Transform(Document doc, int minSummaryLength) {
        List<Node> elements = new ArrayList<Node>();
        AddElements(doc, elements, "pattern");
        AddElements(doc, elements, "role");
        
        List<Node> children = new ArrayList<Node>();
        for (Node node : elements) {
            boolean remove = true;
            Node description = GetChild(node, "description");
            if (description != null) {
                Node summary = GetChild(description, "summary");
                if (summary != null) {
                    remove = summary.getTextContent().length() < minSummaryLength;
                }
            }

            if (remove) {
                node.getParentNode().removeChild(node);
            }
        }
    }

    public static Node GetChild(Node parent, String name) {
        NodeList nodeList = parent.getChildNodes();
        for(int i = 0; i < nodeList.getLength(); i++) {
            if (nodeList.item(i).getNodeName().equals(name)) {
                return nodeList.item(i);
            }
        }

        return null;
    }

    public static void AddElements(Document doc, List<Node> result, String name) {
        NodeList patterns = doc.getElementsByTagName(name);
        for (int i = 0; i < patterns.getLength(); i++) {
            result.add(patterns.item(i));
        }
    }
}



