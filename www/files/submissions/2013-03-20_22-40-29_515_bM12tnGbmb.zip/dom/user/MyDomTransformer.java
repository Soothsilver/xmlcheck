/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package user;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
/**
 *
 * @author pardot
 */
public class MyDomTransformer
{
    private static final String REGISTRATION = "Registration";
    /**
     * Process document tree
     *
     * @param doc Document to be parsed
     */
    public void transform (Document xmlDocument) {
        //put your code here
        /************************** Order Rims **************************/
        Node RimsNode = xmlDocument.getElementsByTagName("Rims").item(0);
        NodeList Rims = xmlDocument.getElementsByTagName("Rim");
        //java.util.TreeMap<String, Node> sortedRims = new java.util.TreeMap<>();
        Node [] sortedRims = new Node[Rims.getLength()];

        //for(int i = 0; i < Rims.getLength(); i++)
        while(Rims.getLength() > 0)        {
            Node rim = RimsNode.removeChild(Rims.item(0));
            NamedNodeMap att = rim.getAttributes();
            String id = att.getNamedItem("id").getTextContent();
            id = id.substring(1);
            int idx = Integer.parseInt(id);
            sortedRims[idx - 1] = rim;
        }

        for(int i = 0; i < sortedRims.length; i++)
        {
            RimsNode.appendChild(sortedRims[i]);
        }
        /*
        while(!sortedRims.isEmpty())
        {
            String key = sortedRims.firstKey();
            Node rim = sortedRims.remove(key);
            RimsNode.appendChild(rim);
        }
        */
        /*********************** Add new Registration *************************/
        Node carRegistration = xmlDocument.getElementsByTagName("CarRegistrations").item(0);

        String maxId = "tp0";

        NodeList registrations = xmlDocument.getElementsByTagName(REGISTRATION); //carRegistrations.item(0).getChildNodes();

        //Get max ID
        for (int i = 0; i < registrations.getLength(); i++)
        {
            NamedNodeMap att = registrations.item(i).getAttributes();
            String id = att.getNamedItem("id").getTextContent();
            if(maxId.compareToIgnoreCase(id) < 0)
            {
                maxId = id;
            }
        }

        /*
        Element XXX = xmlDocument.createElement("");
        XXX.appendChild(xmlDocument.createTextNode(""));
        */
        //Add new Registration
        maxId = getNextId(maxId);
        Element newRegistration = xmlDocument.createElement(REGISTRATION);
        newRegistration.setAttribute("id", maxId);
        newRegistration.setIdAttribute("id", true);
        newRegistration.setAttribute("issued", "yes");

        /************ TP section ***********/
        Element VIN = xmlDocument.createElement("VIN");
        VIN.appendChild(xmlDocument.createTextNode("WDD123456XL123456"));

        Element Color = xmlDocument.createElement("Color");
        Color.appendChild(xmlDocument.createTextNode("Red"));

        Element YearOfManufacture = xmlDocument.createElement("YearOfManufacture");
        YearOfManufacture.appendChild(xmlDocument.createTextNode("2001"));

        Element RegistrationNumber = xmlDocument.createElement("RegistrationNumber");
        RegistrationNumber.appendChild(xmlDocument.createTextNode("UA45678"));

        Element DateOfRegistration = xmlDocument.createElement("DateOfRegistration");
        DateOfRegistration.appendChild(xmlDocument.createTextNode("01.10.2002"));

        Element EngineNo = xmlDocument.createElement("EngineNo");
        EngineNo.appendChild(xmlDocument.createTextNode("EG5555555"));

        Element TakedDate = xmlDocument.createElement("TakedDate");
        TakedDate.appendChild(xmlDocument.createTextNode("11.10.2002"));

        Element TakedBy = xmlDocument.createElement("TakedBy");
        TakedBy.appendChild(xmlDocument.createTextNode("DISPO"));

        Element IssuedBy = xmlDocument.createElement("IssuedBy");
        IssuedBy.appendChild(xmlDocument.createTextNode(""));       //ENTITY Issuer

        Element dateCreated = xmlDocument.createElement("dateCreated");
        dateCreated.appendChild(xmlDocument.createTextNode("01.10.2002"));

        Element TP = xmlDocument.createElement("TP");
        TP.appendChild(VIN);
        TP.appendChild(Color);
        TP.appendChild(YearOfManufacture);
        TP.appendChild(RegistrationNumber);
        TP.appendChild(DateOfRegistration);
        TP.appendChild(EngineNo);
        TP.appendChild(TakedDate);
        TP.appendChild(TakedBy);
        TP.appendChild(IssuedBy);
        TP.appendChild(dateCreated);
        /************ TP section END ***********/

        /************ ZTP section ***********/
        Element Manufacturer = xmlDocument.createElement("Manufacturer");
        Manufacturer.appendChild(xmlDocument.createTextNode("Daimler - Afalterbach"));

        Element ECWVTA = xmlDocument.createElement("ECWVTA");
        ECWVTA.appendChild(xmlDocument.createTextNode("e1*2001/101*0512*02"));

        Element VehicleCategory = xmlDocument.createElement("VehicleCategory");
        VehicleCategory.setAttribute("category", "N1");

        Element VehicleType = xmlDocument.createElement("VehicleType");
        VehicleType.appendChild(xmlDocument.createTextNode("901.12"));

        Element VehicleVariant = xmlDocument.createElement("VehicleVariant");
        VehicleVariant.appendChild(xmlDocument.createTextNode("FDGD135A"));

        Element VehicleVersion = xmlDocument.createElement("VehicleVersion");
        VehicleVersion.appendChild(xmlDocument.createTextNode("XXXA1456"));

        Element MarketingName = xmlDocument.createElement("MarketingName");
        MarketingName.appendChild(xmlDocument.createTextNode("DOM_TEST"));

        Element ZTP = xmlDocument.createElement("ZTP");
        ZTP.appendChild(Manufacturer);
        ZTP.appendChild(ECWVTA);
        ZTP.appendChild(VehicleCategory);
        ZTP.appendChild(VehicleType);
        ZTP.appendChild(VehicleVariant);
        ZTP.appendChild(VehicleVersion);
        ZTP.appendChild(MarketingName);
        /************ ZTP section END ***********/

        /************ TechnicalData section ***********/
        Element Capacity = xmlDocument.createElement("Capacity");
        Capacity.setAttribute("total", "4");
        Capacity.setAttribute("sittingPositions", "2");
        Capacity.setAttribute("beds", "2");

        Element Dimensions = xmlDocument.createElement("Dimensions");
        Dimensions.setAttribute("height", "2100");
        Dimensions.setAttribute("length", "3400");
        Dimensions.setAttribute("width", "2050");

        Element AxlesSpacing = xmlDocument.createElement("AxlesSpacing");
        AxlesSpacing.setAttribute("axle12", "2300");
        AxlesSpacing.setAttribute("axle23", "850");

        Element VehicleWeight = xmlDocument.createElement("VehicleWeight");
        VehicleWeight.setAttribute("min", "4500");
        VehicleWeight.setAttribute("max", "5000");

        Element AxleWeight1 = xmlDocument.createElement("AxleWeight");
        AxleWeight1.setAttribute("min", "2000");
        AxleWeight1.setAttribute("max", "2500");
        AxleWeight1.setAttribute("AxleNo", "1");

        Element AxleWeight2 = xmlDocument.createElement("AxleWeight");
        AxleWeight2.setAttribute("min", "2000");
        AxleWeight2.setAttribute("max", "3000");
        AxleWeight2.setAttribute("AxleNo", "2");

        Element AxleWeight3 = xmlDocument.createElement("AxleWeight");
        AxleWeight3.setAttribute("min", "2000");
        AxleWeight3.setAttribute("max", "3000");
        AxleWeight3.setAttribute("AxleNo", "3");

        Element Wieghts = xmlDocument.createElement("Wieghts");
        Wieghts.appendChild(VehicleWeight);
        Wieghts.appendChild(AxleWeight1);
        Wieghts.appendChild(AxleWeight2);
        Wieghts.appendChild(AxleWeight3);


        Element TechnicalData = xmlDocument.createElement("TechnicalData");
        TechnicalData.appendChild(Capacity);
        TechnicalData.appendChild(Dimensions);
        TechnicalData.appendChild(AxlesSpacing);
        TechnicalData.appendChild(Wieghts);
        /************ TechnicalData section END ***********/

        /************ Chassis section ***********/
        Element VehicleTyres1 = xmlDocument.createElement("VehicleTyres");
        VehicleTyres1.setAttribute("idTyre", "t5");

        Element VehicleRims1 = xmlDocument.createElement("VehicleRims");
        VehicleRims1.setAttribute("idRim", "r4");

        Element Axle1 = xmlDocument.createElement("Axle");
        Axle1.setAttribute("axleNo", "1");
        Axle1.appendChild(VehicleTyres1);
        Axle1.appendChild(VehicleRims1);

        Element VehicleTyres2 = xmlDocument.createElement("VehicleTyres");
        VehicleTyres2.setAttribute("idTyre", "t6");

        Element VehicleRims2 = xmlDocument.createElement("VehicleRims");
        VehicleRims2.setAttribute("idRim", "r4");

        Element Axle2 = xmlDocument.createElement("Axle");
        Axle2.setAttribute("axleNo", "2");
        Axle2.appendChild(VehicleTyres2);
        Axle2.appendChild(VehicleRims2);

        Element VehicleTyres3 = xmlDocument.createElement("VehicleTyres");
        VehicleTyres3.setAttribute("idTyre", "t6");

        Element VehicleRims3 = xmlDocument.createElement("VehicleRims");
        VehicleRims3.setAttribute("idRim", "r4");

        Element Axle3 = xmlDocument.createElement("Axle");
        Axle3.setAttribute("axleNo", "3");
        Axle3.appendChild(VehicleTyres3);
        Axle3.appendChild(VehicleRims3);

        Element Axles = xmlDocument.createElement("Axles");
        Axles.appendChild(Axle1);
        Axles.appendChild(Axle2);
        Axles.appendChild(Axle3);

        Element Brakes = xmlDocument.createElement("Brakes");
        Brakes.setAttribute("emergency", "yes");
        Brakes.setAttribute("operational", "yes");
        Brakes.setAttribute("parking", "yes");
        Brakes.setAttribute("relieving", "yes");

        Element Chassis = xmlDocument.createElement("Chassis");
        Chassis.appendChild(Axles);
        Chassis.appendChild(Brakes);
        /************ Chassis section END ***********/

        /************ Engine section ***********/
        Element Fuel = xmlDocument.createElement("Fuel");
        Fuel.setAttribute("type", "NM");

        Element Power = xmlDocument.createElement("Power");
        Power.appendChild(xmlDocument.createTextNode("135kW"));
        Power.setAttribute("revolutions", "4500");

        Element MaxSpeed = xmlDocument.createElement("MaxSpeed");
        MaxSpeed.appendChild(xmlDocument.createTextNode("150"));

        Element GearBox = xmlDocument.createElement("GearBox");
        GearBox.setAttribute("type", "MAN");

        Element Engine = xmlDocument.createElement("Engine");
        Engine.appendChild(Fuel);
        Engine.appendChild(Power);
        Engine.appendChild(MaxSpeed);
        Engine.appendChild(GearBox);
        /************ Engine section END ***********/

        Element Note = xmlDocument.createElement("Note");
        Note.appendChild(xmlDocument.createTextNode("Poznamka"));

        newRegistration.appendChild(TP);
        newRegistration.appendChild(ZTP);
        newRegistration.appendChild(TechnicalData);
        newRegistration.appendChild(Chassis);
        newRegistration.appendChild(Engine);
        newRegistration.appendChild(Note);

        carRegistration.appendChild(newRegistration);


    }

    private static String getNextId(String id)
    {
        try
        {
        String num = id.substring(2);
        int idx = Integer.parseInt(num);
        idx++;
        return "tp" + idx;
        }
        catch(Exception ex)
        {

        }

        return null;
    }
}
