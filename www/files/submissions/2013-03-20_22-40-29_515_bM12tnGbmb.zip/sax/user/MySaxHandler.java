/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package user;

import java.util.TreeMap;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * 1) Find three most common vehicle types                              DONE
 * 2) Find average weight for every vehicle category                    DONE
 * 3) Find old Cars (YearOfManufacture < 2003) with Automatic gearbox   ALMOST
 * @author pardot
 */
public class MySaxHandler extends DefaultHandler
{
    private static final int OLD_CAR_YEAR = 2003;
    private static final int DEFAULT_YEAR = Integer.MAX_VALUE;
    private static final String AUTOMATIC_TRANSMISSION = "AUT";

    private String actualVIN = "";
    private boolean VINelement = false;
    private String actualVehicleCategory = "";
    private boolean VehicleTypeElement = false;
    private String VehicleType = "";
    private boolean YearOfManufactureElement = false;
    private String YearOfManufactureStr = "";
    private int YearOfManufacture = DEFAULT_YEAR;
    private boolean hasAutomaticTransmission = false;
    //private TreeMap<String, Integer> vehicleTypes = new TreeMap<>();
    //private TreeMap<String, AvgWeight> categoryAvgWeights = new TreeMap<>();
    private String[] oldCars = new String[10];
    private VehicleType[] vehicleTypes = new VehicleType[10];
    private AvgWeight[] categoryAvgWeights = new AvgWeight[10];


    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        super.startElement(uri, localName, qName, attributes);

        //Proccess element start and Attributes here
        if(localName.equals("YearOfManufacture"))
        {
                YearOfManufactureElement = true;
        }
        else if(localName.equals("VehicleType"))
        {
                VehicleTypeElement = true;
        }
        else if(localName.equals("VIN"))
        {
                VINelement = true;
        }
        else if(localName.equals("GearBox"))
        {
                hasAutomaticTransmission = AUTOMATIC_TRANSMISSION.equals(attributes.getValue("type"));
        }
        else if(localName.equals("VehicleCategory"))
        {
                actualVehicleCategory = attributes.getValue("category");
        }
        else if(localName.equals("VehicleWeight"))
        {
                int min = Integer.parseInt(attributes.getValue("min"));
                int max = Integer.parseInt(attributes.getValue("max"));

                int i = 0;
                while(categoryAvgWeights[i] != null && i < categoryAvgWeights.length)
                {
                    if(actualVehicleCategory.equals(categoryAvgWeights[i].category))
                    {
                        categoryAvgWeights[i].count++;
                        categoryAvgWeights[i].weight += Math.round((min + max) / 2);
                        break;
                    }
                    i++;
                }

                if(categoryAvgWeights[i] == null)
                {
                    categoryAvgWeights[i] = new AvgWeight();
                    categoryAvgWeights[i].count = 1;
                    categoryAvgWeights[i].weight = Math.round((min + max) / 2);
                    categoryAvgWeights[i].category = actualVehicleCategory;
                }

//                if(categoryAvgWeights.containsKey(actualVehicleCategory))
//                {
//                    categoryAvgWeights.get(actualVehicleCategory).count++;
//                    categoryAvgWeights.get(actualVehicleCategory).weight += Math.round((min + max) / 2);
//                }
//                else
//                {
//                    AvgWeight avgWeight = new AvgWeight();
//                    avgWeight.count = 1;
//                    avgWeight.weight = Math.round((min + max) / 2);
//                    categoryAvgWeights.put(actualVehicleCategory, avgWeight);
//                }
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        super.endElement(uri, localName, qName);

        if(localName.equals("Registration"))
        {
                //Check if Car is old and has Automatic transmission
                if(YearOfManufacture < OLD_CAR_YEAR && hasAutomaticTransmission)
                {
                    //What should I store here??? VIN + ID? maybe
                    int idx = 0;
                    while(oldCars[idx] != null && !"".equals(oldCars[idx]))
                        idx++;
                    oldCars[idx] = actualVIN;
                }

                //Reset all vehicle values
                actualVehicleCategory = "";
                YearOfManufacture = DEFAULT_YEAR;
                hasAutomaticTransmission = false;
                actualVIN = "";
        }
        else if (localName.equals("YearOfManufacture"))
        {
                YearOfManufacture = Integer.parseInt(YearOfManufactureStr);

                YearOfManufactureElement = false;
                YearOfManufactureStr = "";
        }
        else if (localName.equals("VehicleType"))
        {
                int i = 0;
                while(vehicleTypes[i] != null && i < vehicleTypes.length)
                {
                    if(VehicleType.equals(vehicleTypes[i].type))
                    {
                        vehicleTypes[i].count++;
                        break;
                    }
                    i++;
                }

                if(vehicleTypes[i] == null)
                {
                    vehicleTypes[i] = new VehicleType();
                    vehicleTypes[i].count = 1;
                    vehicleTypes[i].type = VehicleType;
                }

//                if(vehicleTypes.containsKey(VehicleType))
//                {
//                    int incr = vehicleTypes.get(VehicleType).intValue();
//                    ++incr;
//                    vehicleTypes.put(VehicleType, incr);
//                }
//                else
//                {
//                    vehicleTypes.put(VehicleType, 1);
//                }

                VehicleTypeElement = false;
                VehicleType = "";
        }
        else if (localName.equals("VIN"))
        {
                VINelement = false;
        }
        //Process element leaving here
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        super.characters(ch, start, length);

        //Process content of element here
        if(YearOfManufactureElement)
        {
            YearOfManufactureStr += new String(ch, start, length);
        }

        if(VehicleTypeElement)
        {
            VehicleType += new String(ch, start, length);
        }

        if(VINelement)
        {
            actualVIN += new String(ch, start, length);
        }
    }

    @Override
    public void endDocument() throws SAXException {
        super.endDocument();

        //Print results here
        System.out.println("******* 1. Task *******");
        for(VehicleType vt : vehicleTypes)
        {
            if(vt != null)
            {
                System.out.print("\t" + vt.type + "\t");
                System.out.println(vt.count);
            }
        }

        System.out.println("******* 2. Task *******");
        for(AvgWeight weight : categoryAvgWeights)
        {
            if(weight != null)
            {
                System.out.print("\t" + weight.category + "\t");
                System.out.println(weight.avgWeight());
            }
        }
        
        System.out.println("******* 3. Task *******");
        for(String oldcar : oldCars)
        {
            if(oldcar != null)
                System.out.println("\t" + oldcar);
        }
        
    }

    private class AvgWeight
    {
        public int count = 0;
        public int weight = 0;  //in kg
        public String category = null;

        public double avgWeight()
        {
            return Math.round(weight / count);
        }
    }

    private class VehicleType
    {
        public int count = 0;
        public String type = null;
    }


}



