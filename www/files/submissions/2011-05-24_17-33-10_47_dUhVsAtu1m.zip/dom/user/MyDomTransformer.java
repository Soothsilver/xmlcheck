package user;

import java.util.ArrayList;
import java.util.Iterator;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer {

    public void transform(Document xmlDocument) {
        NodeList kytary = xmlDocument.getElementsByTagName("kytara");
        ArrayList<Node> vymazat = new ArrayList<Node>();

        for (int i = 0; i < kytary.getLength(); i++) {
            Element aktualniKytara = (Element) kytary.item(i);

            for (Node elementyKytary = aktualniKytara.getFirstChild(); elementyKytary != null; elementyKytary = elementyKytary.getNextSibling()) {

                if ("barva".equals(elementyKytary.getNodeName())) {
                    Attr barva = xmlDocument.createAttribute("barva");
                    barva.setValue(elementyKytary.getFirstChild().getNodeValue());
                    aktualniKytara.setAttributeNode(barva);
                    vymazat.add(elementyKytary);
                } else if ("material".equals(elementyKytary.getNodeName())) {
                    Attr material = xmlDocument.createAttribute("material");
                    material.setValue(elementyKytary.getFirstChild().getNodeValue());
                    aktualniKytara.setAttributeNode(material);
                    vymazat.add(elementyKytary);
                } else if ("pocetStrun".equals(elementyKytary.getNodeName())) {
                    if ("6".equals(elementyKytary.getFirstChild().getNodeValue())) {
                        Attr pocetStrun = xmlDocument.createAttribute("pocetStrun");
                        pocetStrun.setValue("standardni");
                        aktualniKytara.setAttributeNode(pocetStrun);
                    } else {
                        Attr pocetStrun = xmlDocument.createAttribute("pocetStrun");
                        pocetStrun.setValue("nestandardni");
                        aktualniKytara.setAttributeNode(pocetStrun);
                    }
                }
            }

            for (Iterator<Node> it = vymazat.iterator(); it.hasNext();) {
                Node node = it.next();

                if (node != null) {
                    aktualniKytara.removeChild(node);

                }
            }

            vymazat.clear();
        }
    }
}