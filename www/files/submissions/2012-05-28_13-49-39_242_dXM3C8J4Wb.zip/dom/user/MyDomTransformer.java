package user;

import org.w3c.dom.*;

public class MyDomTransformer {
	/* Doplni k elementum atribut "numberOfChildElements",
	 * ktery obsahuje pocet jeho deti(vnorenych elementu).
	 * Pokud element nema zadne deti(je prazdny/ma textovy obsah),
	 * element je vynechan. */
	
	
	public void transform (Document xmlDocument) {
	
		Element root = xmlDocument.getDocumentElement();
		process(root, xmlDocument);
		
	}
	
	
	private void process(Element e, Document doc)	{
		
		int children = 0;
		
		
		for (Node node = e.getFirstChild(); node != null; node = node.getNextSibling())
		{
			if (node instanceof Element)
			{
				++children;
				process((Element)node, doc);
			}
		}
		
		if (children > 0)
			e.setAttribute("numberOfChildElements", Integer.toString(children));
	
	}

}
