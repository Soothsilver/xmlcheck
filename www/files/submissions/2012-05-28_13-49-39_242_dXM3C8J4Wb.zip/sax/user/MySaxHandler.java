package user;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
	/* Spocita prumerny pocet atributu na jeden element */
	
	
	int numberOfElements = 0;
	int numberOfAttributes = 0;
	
    /**
     * Obsluha ud�losti "konec dokumentu"
     */     
    public void endDocument() throws SAXException {
        
        System.out.println("Pocet elementu: " + numberOfElements);
        System.out.println("Pocet atributu: " + numberOfAttributes);
        System.out.println("Prumerny pocet atributu u elementu: " + ((double)numberOfAttributes/(double)numberOfElements));
        
    }
    
    /**
     * Obsluha ud�losti "za��tek elementu".
     * @param uri URI jmenn�ho prostoru elementu (pr�zdn�, pokud element nen� v ��dn�m jmenn�m prostoru)
     * @param localName Lok�ln� jm�no elementu (v�dy nepr�zdn�)
     * @param qName Kvalifikovan� jm�no (tj. prefix-uri + ':' + localName, pokud je element v n�jak�m jmenn�m prostoru, nebo localName, pokud element nen� v ��dn�m jmenn�m prostoru)
     * @param atts Atributy elementu     
     */     
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        ++numberOfElements;
        numberOfAttributes += atts.getLength();

    }    

}
