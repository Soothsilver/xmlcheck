package user;

import static org.w3c.dom.Node.ELEMENT_NODE;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.io.Writer;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.traversal.DocumentTraversal;
import org.w3c.dom.traversal.NodeFilter;
import org.w3c.dom.traversal.TreeWalker;
import org.xml.sax.SAXException;

import com.sun.org.apache.xml.internal.serialize.OutputFormat;
import com.sun.org.apache.xml.internal.serialize.XMLSerializer;

public class MyDomTransformer {
	
	private Document document;
	private int minDepth = 0;
	private int nodeMaxDepth = 0;
	private Node max = null;
	private int maxLevel = 0;
	
	/**
	 * transform XML document using DOM
	 * @see getMaxDepth for more info
	 * @param xmlDocument
	 */
	public void transform(Document xmlDocument) {
		if(xmlDocument != null) {
			System.out.println("\nTransforming following document:\n");
			debugDocument(xmlDocument);
			
			Node root = xmlDocument.getDocumentElement();
			
			this.nodeMaxDepth = 0;
			this.max = root;
			this.maxLevel = 0;
			
			this.getMaxDepth(root, 0);
			//System.out.println(root.getNodeName() + ": " + this.nodeMaxDepth);
				
			System.out.println("\nTransformed document:\n");
			debugDocument(xmlDocument);
		}
		else {
			System.out.println("Supplied document was not successfully parsed (either its empty or malformed).");
		}
	}
	
	/**
	 * find recursively deepest path to leaf from node and if its lower than required minimal depth, add to this node (partial) copy from root
	 * @param parent
	 * @param level
	 */
	private void getMaxDepth(Node parent, int level) {
		if(this.nodeMaxDepth < level)
		{
			this.nodeMaxDepth = level;
			this.max = parent;
			this.maxLevel = level;
		}
		
		boolean rootOnly = true;
		NodeList children = parent.getChildNodes();
		for(int i = 0; i < children.getLength(); i++) {
			if(children.item(i).getNodeType() == ELEMENT_NODE) {
				rootOnly = false;
				//System.out.println(children.item(i).getNodeName() + " level = " + level + " this.nodeMaxDepth = " + this.nodeMaxDepth);
				
				this.getMaxDepth(children.item(i), level + 1);
				
				if(level == 0) {
					//System.out.println(children.item(i).getNodeName() + ": " + this.nodeMaxDepth);
					
					if(this.nodeMaxDepth < this.minDepth) {
						//System.out.println(children.item(i).getNodeName() + " NENI");
						//children.item(i).appendChild(children.item(i).getOwnerDocument().importNode(this.copyMin(level + 1), true));
						//this.getMaxDepth(parent, 0);
						
						this.max.appendChild(this.max.getOwnerDocument().importNode(this.copyMin(this.maxLevel), true));
						this.getMaxDepth(parent, 0);
					}
					this.nodeMaxDepth = 0;
				}
			}
		}
		
		// only root node in document
		if(level == 0 && rootOnly) {
			parent.appendChild(parent.getOwnerDocument().importNode(this.copyMin(level), true));
			this.getMaxDepth(parent, 0);
		}
	}
	
	/**
	 * create new (partial) tree to add to elements that dont have required min depth
	 * @param parentDepth
	 * @return
	 */
	private Node copyMin(int parentDepth) {
		Node xmlDocument = this.document.cloneNode(true);
		Node root = ((Document) xmlDocument).getDocumentElement();
		
		DocumentTraversal traversal = (DocumentTraversal) ((Document) xmlDocument);
	    TreeWalker walker = traversal.createTreeWalker(root, NodeFilter.SHOW_ELEMENT, null, true);
	    cut(walker, 0, (this.minDepth - parentDepth - 1));
	    
	    //debug(root);
	    
		return root;
	}
	
	/**
	 * cuts all nodes from document with depth > maxDepth
	 * @param walker
	 * @param depth
	 * @param maxDepth
	 */
	private static final void cut(TreeWalker walker, int depth, int maxDepth) {
		Node parend = walker.getCurrentNode();
		
		//System.out.println("walk " + parend.getNodeName());
		
		Node[] remove = new Node[1000];
		int i = 0;
		
		for(Node n = walker.firstChild(); n != null; n = walker.nextSibling()) {
			if(depth >= maxDepth) {
				remove[i] = n;
				i++;
			}
			else {
				cut(walker, depth + 1, maxDepth);
			}
		}
		
		for(int j = 0; j < i; j++) {
			parend.removeChild(remove[j]);
		}
		
		walker.setCurrentNode(parend);
	}
	
	/**
	 * debug print serialized node
	 * @param node
	 */
	@SuppressWarnings("unused")
	private static final void debug(Node node) {
		StringWriter sw = new StringWriter();
		try {
			Transformer t = TransformerFactory.newInstance().newTransformer();
			t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
			t.transform(new DOMSource(node), new StreamResult(sw));
		} catch (TransformerException e) {
			System.out.println(e.getMessage());
		}
		
        System.out.println(sw.toString());
	}
	
	/**
	 * pretty print serialized document
	 * @param doc
	 */
	private static final void debugDocument(Document doc) {
		OutputFormat format = new OutputFormat(doc);
        format.setLineWidth(65);
        format.setIndenting(true);
        format.setIndent(2);
        Writer out = new StringWriter();
        XMLSerializer serializer = new XMLSerializer(out, format);
        try {
			serializer.serialize(doc);
			System.out.println(out.toString());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("WHAT DO I DO?");
		System.out.println("I transform supplied XML document using DOM so that for each child of root node, ");
		System.out.println("there is a path where lead has at least minimum required depth.");
		System.out.println("Root has depth 0, children of root have depth 1 etc.");
		System.out.println("WHAT DO I REQUIRE?");
		System.out.println("1) XML file (passed as program param, default is example.xml)");
		System.out.println("2) int specifying minimum required depth");
		System.out.println("--------------------------------------------------------------------------------");
		
		MyDomTransformer t = new MyDomTransformer();
		
		String line = null;
		System.out.println("\nPlease enter minimum required depth:");
		try {
			BufferedReader is = new BufferedReader(new InputStreamReader(System.in));
			line = is.readLine();
			t.minDepth = Integer.parseInt(line);
		} catch (NumberFormatException ex) {
			System.err.println("Not a valid number: " + line);
		} catch (IOException e) {
			System.err.println("Unexpected IO ERROR: " + e.getMessage());
		}
		
		t.transform(t.parse(args));
	}
	
	/**
	 * parse XML file
	 * @param args
	 * @return
	 */
	public Document parse(String[] args) {
		Document doc = null;
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = null;
		
		try {
			builder = factory.newDocumentBuilder();
			
			if(args.length > 0) {
				doc = builder.parse(new File(args[0]));
			}
			else {
				doc = builder.parse(new File(".." + System.getProperty("file.separator") + "example.xml"));
			}
		} catch (ParserConfigurationException e) {
			System.out.println("Chyba: " + e.getMessage());
		} catch (SAXException e) {
			System.out.println("Chyba: " + e.getMessage());
		} catch (IOException e) {
			System.out.println("Chyba: " + e.getMessage());
		}
		
		this.document = doc;
		
		return doc;
	}
}
