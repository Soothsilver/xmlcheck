package user;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
	
	private TreeMap<Integer, HashMap<String, Integer>> elements;
	private int level = 0;
	
	public void startElement(String namespaceURI, String lName, String qName, Attributes attrs) throws SAXException {
		String elementName = qName;
		
		if(this.elements.containsKey(new Integer(this.level))) {
			HashMap<String, Integer> map = this.elements.get(new Integer(this.level));
			if(map.containsKey(elementName)) {
				Integer occurences = map.get(elementName);
				map.remove(elementName);
				map.put(elementName, new Integer(occurences.intValue() + 1));
			}
			else {
				map.put(elementName, new Integer(1));
			}
		}
		else {
			HashMap<String, Integer> tag = new HashMap<String, Integer>();
			tag.put(elementName, new Integer(1));
			this.elements.put(new Integer(this.level), tag);
		}
		
		this.level++;
	}
	
	public void endElement(String uri, String localName, String qName) throws SAXException {
		this.level--;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("WHAT DO I DO?");
		System.out.println("I count occurences of element names in each depth level in supplied XML document using SAX.");
		System.out.println("I ommit the root from statistics (there is no need to write Level 0: [root] 1x)");
		System.out.println("WHAT DO I REQUIRE?");
		System.out.println("1) XML file (passed as program param, default is example.xml)");
		System.out.println("-------------------------------------------------------------------------------------------\n");
		
		MySaxHandler handler = new MySaxHandler();
		handler.elements = new TreeMap<Integer, HashMap<String,Integer>>();
		
		SAXParserFactory factory = SAXParserFactory.newInstance();
        factory.setNamespaceAware(false);
        try {
            SAXParser saxParser = factory.newSAXParser();
            
            if(args.length > 0) {
            	saxParser.parse(new File(args[0]), handler);
            }
            else {
            	saxParser.parse(new File(".." + System.getProperty("file.separator") + "example.xml"), handler);
            }
        } catch (Throwable t) {
            System.out.println(t.getMessage());
        }
        
        // print levels and contents of levels
        if(!handler.elements.isEmpty()) {
        	Set<Integer> keys = handler.elements.keySet();
        	for(Integer level : keys) {
        		if(level != 0) {
	        		HashMap<String, Integer> value = handler.elements.get(level);
	        		System.out.println("Level " + level + ":");
	        		if(!value.isEmpty()) {
	        			Set<String> lkeys = value.keySet();
	        			Iterator<String> it = lkeys.iterator();
	        			System.out.print('\t');
	        			while(it.hasNext()) {
	        				String tag = it.next();
	        				System.out.print(tag + ": " + value.get(tag) + "x");
	        				if(it.hasNext()) {
	        					System.out.print(", ");
	        				}
	        			}
	        		}
	        		System.out.println();
        		}
        	}
        }
	}
}
