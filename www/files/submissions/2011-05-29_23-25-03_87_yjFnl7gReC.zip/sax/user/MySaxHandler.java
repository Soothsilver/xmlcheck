package user;

/*
 * 
 * Radek Strnad
 * 
 * SAX - pocitani zvolene charakteristiky
 * Program pocita prumernou cenu pneumatiky pro kazdeho vyrobce
 * - tedy pro kazdeho vyrobce secte ceny vyrobku a vydeli poctem vyrobku
 *  
 */

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

public class MySaxHandler extends DefaultHandler {
            
	public String current = "";
	public String vyrobce = "";
	public int sum = 0;
	public int divideby = 0;
	
    /**
     * konstruktor tridy sax (parser musi byt objekt)
     */
    public MySaxHandler() {
        try {
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
         // System.out.println("sax vytvoren");
    }
    
    public void showEvent(String s) {
        System.out.println("showevent: "+s);
    }
    
    /**
     * zacatek xml documentu
     * @throws org.xml.sax.SAXException chyba rozhrani sax
     */
    public void startDocument() throws SAXException {
        //System.out.println("soubor byl pocat");
    	System.out.println("Prumerna cena pneumatik pro kazdeho vyrobce");
    }
    
    /**
     * zacatek elementu
     */
    public void startElement(String namespaceURI, String localName, String qName, Attributes atts) throws SAXException {
    	current = current + "/" + qName;
    	if (current.equals("/pneumatiky/vyrobce"))
    	{
    		sum = 0;
    		divideby = 0;
    		vyrobce = atts.getValue("nazev");
    	}
    }
    
    public void endElement(String namespaceURI, String localName, String qName) throws SAXException {
    	int avgcena = 0;
    	current = current.substring(0, current.lastIndexOf('/'));
    	if (current.equals("/pneumatiky"))
    	{
    		if (divideby > 0)
    			avgcena = sum/divideby;
    		else 
    			avgcena = 0;
    		System.out.println(vyrobce + " - " + String.valueOf(avgcena));
    	}
    }
    
    
    public void characters(char[] ch, int start, int length) throws SAXException {
    	if (current.endsWith("pneumatika/cena"))
    	{
    		String s = new String (ch, start, length);
    		sum += Integer.parseInt(String.valueOf(s));
    		divideby++ ;
    	}
    }
    
    
    /**
     * konec dokumentu
     */
    public void endDocument() throws SAXException {
    }
    
    /**
     * chyba
     */
    public void error (SAXParseException e) {
        System.out.println("SAXParseException: error");
        e.printStackTrace();
   }

    /**
     * varovani
     */
   public void warning (SAXParseException e) {
        System.out.println("SAXParseException: warning");
        e.printStackTrace();
   }

    /**
     * selhani
     */
   public void fatalError (SAXParseException e) {
        System.out.println("SAXParseException: fatal error");
        e.printStackTrace();
        System.exit(1);
   }
}


