package user;

/*
 * 
 * Radek Strnad
 * 
 * DOM - transformace dokumentu
 * Program prevede atributy pneumatik - sirka, profil, rozmer na elementy a v pripade
 * chybejici reference na DTD, by se atributy mohly smazat - viz zakomentovany pneumatika.removeChild.
 * 
 */

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.FileOutputStream;

public class MyDomTransformer {
	
    public static void transform (Document xmlDocument) {
        Element root = xmlDocument.getDocumentElement();
        
        NodeList pneumatiky = root.getElementsByTagName("pneumatika");
        
        for (int x=0; x<pneumatiky.getLength(); x++)
        {

        	Node pneumatika = pneumatiky.item(x);
        	NamedNodeMap atributy = pneumatika.getAttributes();
        	
        	Node sirka = xmlDocument.createElement("sirka");
        	sirka.setTextContent(atributy.getNamedItem("sirka").getNodeValue());
        	pneumatika.appendChild(sirka);

        	Node rozmer = xmlDocument.createElement("rozmer");
        	rozmer.setTextContent(atributy.getNamedItem("rozmer").getNodeValue());
        	pneumatika.appendChild(rozmer);

        	Node profil = xmlDocument.createElement("profil");
        	profil.setTextContent(atributy.getNamedItem("profil").getNodeValue());
        	pneumatika.appendChild(profil);
        	
            //pneumatika.removeChild(atributy.getNamedItem("sirka"));
            //pneumatika.removeChild(atributy.getNamedItem("rozmer"));
            //pneumatika.removeChild(atributy.getNamedItem("profil"));        	

        }        
    }        
}
      
