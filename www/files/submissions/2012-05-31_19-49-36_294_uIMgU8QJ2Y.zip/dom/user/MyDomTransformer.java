package user;

import org.w3c.dom.*;

/**
 * Zpracuje DOM strom: Ke kazdemu koncertu se vyhleda prislusny kontakt (tj. najde se kapela s
 * odpovidajicim id, zjisti se leader skupiny a vyhleda se email na tohoto clena kapely 
 * V ramci elementu "concert" se vytvori novy element "contact_to_leader" s kontaktem na kapelu
 * (konkretne na hlavniho clena kapely)
 */

public class MyDomTransformer { 
	public void transform (Document xmlDocument) {
		
		//vytvoreni seznamu kapel
        NodeList bands = xmlDocument.getElementsByTagName("band");
        //inicializace:
        String leader = "";
        String contact = "";
        //vytvorim si seznam vsech koncertu, postupne je prochzim
        NodeList concerts = xmlDocument.getElementsByTagName("concert");
        
        for (int j = 0; j < concerts.getLength(); j ++){
            Node conc = concerts.item(j);
            NodeList childs = conc.getChildNodes();
            String id = "";
            //zjistim id kapely, ktera koncert porada
            for (int i = 0; i < childs.getLength(); i++){
                if (childs.item(i).getNodeName().equals("band")){
                    id = childs.item(i).getChildNodes().item(0).getNodeValue();
                    break;
                }
            }
            //pokud je id neprazdne, pokracujeme:
            if (!id.equals("")){
                //prochazime seznam kapel a hledame tu, ktera se shoduje s nalezenym id
                for (int k = 0; k < bands.getLength(); k++){
                    Node band = bands.item(k);
                    if (band.hasAttributes()){
                        String bandID = band.getAttributes().getNamedItem("id").getFirstChild().getNodeValue();
                        //pokud se obe ID shoduji, pokracujeme:
                        if (bandID.equals(id)){
                            //list podelementu elementu "band", prochazime ho
                            NodeList band_content = band.getChildNodes();
                            
                            for (int i = 0; i < band_content.getLength(); i++){
                                Node n = band_content.item(i);
                                if (n.hasChildNodes()){
                                    //je-li nazev elementu "leader", priradime ho do nasi promenne
                                    if (n.getNodeName().equals("leader")){
                                        
                                        leader = n.getFirstChild().getNodeValue();
                                        
                                        
                                    }
                                    //je-li nazev elementu "members", budeme prochazet jeho podelementy a hledat 
                                    //informace o hlavniho clena kapely
                                    if (n.getNodeName().equals("members")){
                                        NodeList memebers = n.getChildNodes();
                                        for (int l = 0; l < memebers.getLength(); l++){
                                            Node m = memebers.item(l);
                                            NodeList memberInfo = memebers.item(l).getChildNodes();
                                            
                                            boolean getContact = false;
                                            for (int p = 0; p < memberInfo.getLength(); p++){
                                                if (memberInfo.item(p).getNodeName().equals("full_name")){
                                                    String name = memberInfo.item(p).getFirstChild().getNodeValue();
                                                    //pokud je jmeno jmenem leadera, oznacime si, ze mame zjisit na nej kontakt
                                                    if (name.equals(leader)){
                                                        getContact = true;
                                                    }else{
                                                        getContact = false;
                                                        contact="";
                                                        
                                                    }
                                                    
                                                }
                                                //je-li promenna getContact true, zjistime contact leadera
                                                if (getContact){
                                                    if (memberInfo.item(p).getNodeName().equals("contact")){
                                                        contact = memberInfo.item(p).getFirstChild().getNodeValue();
                                                        //a vytvorime novy element v dokumetu
                                                        Element el = xmlDocument.createElement("contatct_to_leader");
                                                        el.appendChild(xmlDocument.createTextNode(contact));
                                                        conc.appendChild(el);
                                                        
                                                        getContact = false;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
				
            }
        }
		
		
		
		
	}
} 