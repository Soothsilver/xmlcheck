package user; 


import java.util.ArrayList;
import javax.xml.parsers.SAXParser;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

public class MySaxHandler extends DefaultHandler { 
	//prepsani jedotlivych metod
    
    int hloubka = 0;
    int pocet_elementu = 0;
    int pocet_atributu = 0;
    int max_hloubka = 0;
    
    int pocet_koncertu = 0;
    int koncert_student = 0;
    
    int delky_nazvu_atributu = 0;
    
	
    ArrayList<Uroven> seznamUrovni = new ArrayList<Uroven>();
    
    //na zacatku kazdeho elementu se upravi hloubka, na ktere se nachazime,
    //pocet elementu, atributu, koncertu(je-li nazev elementu "concert"
    //a upravi se prehled "seznamUrovni"
    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes){
        pocet_elementu++;
        hloubka++;
        
        //ma-li element atributy, pricteme jejich pocet k pocet_elementu
        if (attributes.getLength() > 0){
            pocet_atributu += attributes.getLength();
            for (int i = 0; i < attributes.getLength(); i++) {
                String s = attributes.getLocalName(i);
                delky_nazvu_atributu += s.length();
            }
        }
        
        //prirazeni hloubky do maximalni hloubky (pokud je vetsi)
        if (hloubka > max_hloubka){
            max_hloubka = hloubka;
        }
        
        //upraveni poctu koncertu
        if (localName.equals("concert")){
            pocet_koncertu++;
        }
        //upraveni poctu studentkych cen na koncerty
        if (localName.equals("price")){
            if (attributes.getLength() != 0){
                if (attributes.getValue(0).equals("student_price")){
                    koncert_student++;
                }
            }
        }
        
        
        boolean nalezen = false;
        
        //prochazime seznam - udrzuje se pocet elementu a atributu na danou uroven
        for (Uroven u : seznamUrovni) {
            if (u.uroven == hloubka){
                nalezen = true;
                u.elementu++;
                if (attributes.getLength() != 0){
                    u.parametru += attributes.getLength();
                }
                break;
            }
        }
        //pokud v seznamu dana uroven jeste neni, vytvorime ji
        if (!nalezen){
            nalezen = true;
            Uroven u = new Uroven(hloubka);
            u.elementu++;
            if (attributes.getLength() != 0){
                u.parametru += attributes.getLength();
            }
            seznamUrovni.add(u);
        }
        
    }
    
    
    //u kazdeho konce elementu se upravi hloubka, v ktere se nachazime
    @Override
    public void	endElement(String uri, String localName, String qName){
        hloubka--;
    } 
    
    
    //na konci dokumentu se vypisi zjistene statistiky:
    @Override
    public void	endDocument(){
        //zakladni udaje
        System.out.println("pocet elementu v dokumentu = "+pocet_elementu);
        System.out.println("pocet atributu v dokumentu = "+pocet_atributu);
        System.out.println("maximalni hloubka dokumentu = "+max_hloubka);
        System.out.println();
        
        //vypocet prumerneho poctu atributu na element
        Float prumer = Float.parseFloat(String.valueOf(pocet_atributu)) / Float.parseFloat(String.valueOf(pocet_elementu));
        System.out.println("prumerny pocet atributu na elelment = "+ prumer);
        System.out.println();
        
        prumer = Float.parseFloat(String.valueOf(delky_nazvu_atributu)) / Float.parseFloat(String.valueOf(pocet_atributu));
        int p = Integer.parseInt(String.valueOf(delky_nazvu_atributu)) / Integer.parseInt(String.valueOf(pocet_atributu));
        System.out.println("prumerna delka nazvu atributu (cca) = "+ p);
        System.out.println("prumerna delka nazvu atributu (presne) = "+ prumer);
        System.out.println();
        
        
        //pocet koncertu + kolik z nich ma slevu pro studenty
        System.out.println("pocet koncertu: "+ (pocet_koncertu) + "; z toho "+koncert_student+" nabizi studentske ceny");
        System.out.println();
        
        //vypsani udaju ze seznamu urovni
        for (Uroven u : seznamUrovni) {
            System.out.println("uroven "+u.uroven+" obsahuje "+u.elementu+" elementu a "+u.parametru+" atributu");
        }
    }
    
    
    //privatni trida reprezentujici uroven dokumentu - udrzuje si pocet elementu a atributu v urovni
    private class Uroven{
        int uroven;
        int elementu;
        int parametru;
        public Uroven(int u){
            this.uroven = u;
            this.elementu = 0;
            this.parametru = 0;
            
        }
    }
    
}