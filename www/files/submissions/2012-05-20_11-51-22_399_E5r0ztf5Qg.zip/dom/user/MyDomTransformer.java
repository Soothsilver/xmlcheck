package user;


import org.w3c.dom.*;


/**
 *
 * @author cernylu5
 * 
 * Zmeni vsechny atributy na elementy
 */
public class MyDomTransformer {
    
    private Document doc;
    
    public void transform(Document doc){
        this.doc = doc;
        attribToElement(doc);
    }
    
    private void attribToElement(Node n){
        
        NodeList list = n.getChildNodes();
        for (int i = 0; i < list.getLength(); i++) {
            attribToElement(list.item(i));
        }
        
        if(n.hasAttributes()){
            NamedNodeMap map = n.getAttributes();
            
            while(map.getLength()>0){
                Attr attrib =(Attr) map.item(0);
                addElement(n, attrib);  
                ((Element)n).removeAttributeNode(attrib);
            }
            
        }
    }
    
    private void addElement(Node parentNode, Attr attribute){
        Element newElement =  doc.createElement(attribute.getName());
        newElement.appendChild(doc.createTextNode(attribute.getValue()));
        parentNode.appendChild(newElement);
    }
    
}
