package user;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * @author cernylu5
 * 
 * vrati pocet elementu, ktere maji alespon jeden atribut
 */
public class MySaxHandler extends DefaultHandler{

    private long counter;
    
    @Override
    public void endDocument() throws SAXException {
        System.out.println("Number of elements is: " + counter);
    }

    @Override
    public void startDocument() throws SAXException {
        counter=0;
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        if(attributes.getLength()>0)counter++;
//        counter++;
    }
    
    
    
}
