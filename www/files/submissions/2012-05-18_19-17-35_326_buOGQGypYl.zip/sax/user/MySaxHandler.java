package user;

import java.text.DecimalFormat;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 * Vypis statistik xml dokumentu viz funkce endDocument() obsahujici okomentovane vypisy
 * @author Kokosac
 */
public class MySaxHandler extends DefaultHandler {

    
    public static void main(String[] args) {
       
        // Cesta ke zdrojovému XML dokumentu  
        String sourcePath = "data.xml";

        try {
            
            // Vytvoríme instanci parseru.
            XMLReader parser = XMLReaderFactory.createXMLReader();
            
            // Vytvoríme vstupní proud XML dat.
            InputSource source = new InputSource(sourcePath);
            
            // Nastavíme náą vlastní content handler pro obsluhu SAX událostí.
            parser.setContentHandler(new MujContentHandler());
            
            // Zpracujeme vstupní proud XML dat.
            parser.parse(source);
            
        } catch (Exception e) {
        
            e.printStackTrace();
            
        }
        
    }
}


/**
 * Náš vlastní content handler pro obsluhu SAX událostí.
 * Implementuje metody interface ContentHandler. 
 */ 
class MujContentHandler implements ContentHandler {

    // Umožňuje zacílit místo v dokumentu, kde vznikla aktualní událost
    Locator locator;

    double purchasePrice;
    boolean productStart;
    String priceValue;
    int productCount;
    
    //double rezervationPrice;
    //double rezervationPriceStr;
    boolean productOpen;
    boolean containDate;
    String productNames;
    String productName;
    boolean nameOpen;
    
    int customerCount;
    
    boolean rezervaceOpen;
    boolean priceOpen;
    double rezervationSumPrice;
    int rezervationCount;
    String rezervationPrice;
    
    /**
     * Nastaví locator
     */     
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
          
    }

    /**
     * Obsluha události "začátek dokumentu"
     */     
    public void startDocument() throws SAXException {
        purchasePrice = 0;
        productStart = false;
        productCount = 0;
        
        //rezervationPrice = 0;
        containDate = false;
        productNames = "";
        nameOpen = false;
        
        customerCount = 0;
        
        rezervaceOpen = false;
        priceOpen = false;
        rezervationSumPrice = 0;
        rezervationCount = 0;
        rezervationPrice = "";
    }
    /**
     * Obsluha události "konec dokumentu"
     */     
    public void endDocument() throws SAXException {
        System.out.println("-----Statistika pujcovny kol-----");
        
        System.out.println("Pocet zakazniku: " + customerCount);    
        System.out.println("Pocet rezervaci: " + rezervationCount);
        
        System.out.println("Nakupni cena veskereho zbozi: " + (int)purchasePrice + "Kc");
        System.out.println("Prumerna nakupni cena zbozi:  " + (int)purchasePrice/productCount + "Kc");
        if(productNames.length() > 0)
            System.out.println("Nazvy zbozi obsahujici alespon jednu servisni prohlidku: " + productNames.substring(0, productNames.length()-2));
        else
            System.out.println("Zbozi s alespon jednou servisni prohlidkou neexistuje.");
         
        //rounding
        int pi = (int)Math.round(rezervationSumPrice / rezervationCount * 100);
        System.out.println("Prumerne zaplacena cena za rezervaci: " + pi/100.0 + "Kc");
    }
    
    /**
     * Obsluha události "začátek elementu".
     * @param uri URI jmenného prostoru elementu (prázdné, pokud element není v žádném jmenném prostoru)
     * @param localName Lokální jméno elementu (vždy neprázdné)
     * @param qName Kvalifikované jméno (tj. prefix-uri + ':' + localName, pokud je element v nějakém jmenném prostoru, nebo localName, pokud element není v žádném jmenném prostoru)
     * @param atts Atributy elementu     
     */     
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if(localName.compareTo("nakupniCena") == 0)
        {
          priceValue = "";
          productStart = true;
          productCount++;
        }
        
        if(localName.compareTo("zbozi") == 0)
        {  
          productName = "";  
          productOpen = true;
          containDate = false;
        }
        if(localName.compareTo("datum") == 0 && productOpen)
          containDate = true;
        if(localName.compareTo("nazev") == 0 && productOpen)
          nameOpen = true;
        
        if(localName.compareTo("zakaznik") == 0)
          customerCount++;
        
        if(localName.compareTo("rezervace") == 0)
        {
          rezervaceOpen = true;
          rezervationCount++;
        }
        if(localName.compareTo("cena") == 0 && rezervaceOpen)
          priceOpen = true;
    }
    /**
     * Obsluha události "konec elementu"
     * Parametry mají stejný význam jako u @see startElement     
     */     
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if(localName.compareTo("nakupniCena") == 0)
        {
            purchasePrice += Integer.valueOf(priceValue);
            productStart = false;
        }
        
        if(localName.compareTo("zbozi") == 0)
        {
            if(containDate)
                productNames += productName + ", ";
            productOpen = false;
        }
        if(localName.compareTo("nazev") == 0 && productOpen)
          nameOpen = false;
        
        
        if(localName.compareTo("rezervace") == 0)
          rezervaceOpen = false;
        if(localName.compareTo("cena") == 0 && priceOpen)
          rezervationSumPrice += Integer.parseInt(rezervationPrice);
          rezervationPrice = "";
          priceOpen = false;
    }
    
    /**
     * Obsluha události "znaková data".
     * SAX parser muľe znaková data dávkovat jak chce. Nelze tedy počítat s tím, že je celý text dorucen v rámci jednoho volání.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakovými daty
     * @param start Index zacátku úseku platných znakových dat v poli.
     * @param length Délka úseku platných znakových dat v poli.
     */               
    public void characters(char[] ch, int start, int length) throws SAXException {
        
        if(productStart)
        {
            for (int i = start; i < start+length; i++) 
            {
                priceValue += ch[i];    
            } 
        }
        if(nameOpen)
        {
            for (int i = start; i < start+length; i++) 
            {
                productName += ch[i];    
            } 
        }
        if(priceOpen)
        {
            for (int i = start; i < start+length; i++) 
            {
                rezervationPrice += ch[i];    
            } 
        }
    }
    
    /**
     * Obsluha události "deklarace jmenného prostoru".
     * @param prefix Prefix prirazený jmennému prostoru.
     * @param uri URI jmenného prostoru.
     */     
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha události "konec platnosti deklarace jmenného prostoru".
     */     
    public void endPrefixMapping(String prefix) throws SAXException {
    
        // ...
    
    }

    /**
     * Obsluha události "ignorované bílé znaky".
     * Stejné chování a parametry jako @see characters     
     */     
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha události "instrukce pro zpracování".
     */         
    public void processingInstruction(String target, String data) throws SAXException {
      
      // ...
            
    }

    /**
     * Obsluha události "nezpracovaná entita"
     */         
    public void skippedEntity(String name) throws SAXException {
    
      // ...
    
    }
}