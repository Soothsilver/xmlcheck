
package user;

import java.io.File;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;
/**
 *
 * @author Kokosac
 */
public class MyDomTransformer {
   
    private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "data.out.xml";

    public static void main(String[] args) {
        
        try {
            MyDomTransformer transformer = new MyDomTransformer();
            
            //DocumentBuilderFactory vytváří DOM parsery
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            //nebudeme validovat
            dbf.setValidating(false);

            //vytvoříme si DOM parser
            DocumentBuilder builder = dbf.newDocumentBuilder();

            //parser zpracuje vstupní soubor a vytvoří z něj strom DOM objektů
            Document doc = builder.parse(VSTUPNI_SOUBOR);

            //zpracujeme DOM strom
            transformer.transform(doc);

            //TransformerFactory vytváří serializátory DOM stromů
            TransformerFactory tf = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer = tf.newTransformer();

            //nastavíme kodování
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spustíme transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


        } catch (Exception e) {
            
            e.printStackTrace();
            
        }
    }

    /**
     * - puvodni dokument obsahuje seznam zakazniku, zbozi a rezervaci
     * - transformace spociva ve zruseni tri seznamu a zachovani pouze seznamu rezervaci, kde misto 
     *   odkazu na zamestnance a zbozi budou primo uvedene data techto polozek (bude dochazet k duplicitam v zaznamu, ale jako skolni priklad by to melo byt jedno)
     * - u kazde rezervace se vytvori novy element, ktery bude obsahovat nakupni cenu pujceneho zbozi
     */
    public void transform(Document xmlDocument) {
        
        //nalezeni vsech zakazniku
        NodeList clientAll = xmlDocument.getElementsByTagName("zakaznik");
        int clientLength = clientAll.getLength();
        
        //nalezeni veskereho zbozi
        NodeList productAll = xmlDocument.getElementsByTagName("zbozi");  
        int productLength = productAll.getLength();
        
        //nalezeni vsech rezervaci
        NodeList reservationsAll = xmlDocument.getElementsByTagName("rezervace");
        
        for (int i = 0; i < reservationsAll.getLength(); i++) {
            Node res = reservationsAll.item(i);
            
            if(res instanceof Element)
            {
                Element reservation = (Element)res;
                
                //nalezeni id zbozi
                NodeList resProducts = reservation.getElementsByTagName("polozka"); 
                
                //nalezeni id zakaznika
                String clientID = reservation.getAttribute("idZakaznika");
                reservation.removeAttribute("idZakaznika");
                
                //nalezeni spravneho zakaznika
                for (int j = 0; j < clientLength; j++) {
                    Node cl = clientAll.item(j);
               
                    if(cl instanceof Element)
                    {
                        Element client = (Element)cl;
                        if(client.getAttribute("id").compareTo(clientID) == 0)
                            //zkopirovani a pridani uzlu zakaznika do rezervace
                            reservation.appendChild(cl.cloneNode(true));
                    }

                }
                
                //vytvoreni noveho seznamu pujceneho zbozi
                Element pz = xmlDocument.createElement("pujceneZbozi");
                reservation.appendChild(pz);
                
                //nakupni cena vsech polozek rezervace
                double productsPrice = 0;
                
                //pro vsechny polozky hledame zbozi podle id
                for (int k = 0; k < resProducts.getLength(); k++) {
                    Node item = resProducts.item(k);
                    
                    if(item instanceof Element)
                    {
                        Element itemElement = (Element)item;
                        String itemID = itemElement.getTextContent();
                        
                        //nalezeni spravneho zbozi
                        for (int j = 0; j < productLength; j++) {
                            Node pr = productAll.item(j);

                            if(pr instanceof Element)
                            {
                                Element prod = (Element)pr;
                                if(prod.getAttribute("id").compareTo(itemID) == 0)
                                {
                                    NodeList n = prod.getElementsByTagName("nakupniCena");
                                    if(n.item(0) instanceof Element)
                                    {
                                        Element elem = (Element)n.item(0);
                                        productsPrice += Integer.valueOf(elem.getTextContent());
                                    }
                                    
                                    //zkopirovani a pridani uzlu zbozi do rezervace
                                    pz.appendChild(pr.cloneNode(true));
                                }
                            }
                        }
                    }  
                }
                
                //odstraneni puvodniho seznamu pujceneho zbozi
                NodeList tmp = reservation.getElementsByTagName("pujceneZbozi");
                reservation.removeChild(tmp.item(0));
                
                //vytvoreni elementu obsahujici nakupni cenu pujceneho zbozi
                Element price = xmlDocument.createElement("nakupniCenaZbozi");
                price.setTextContent(String.valueOf(productsPrice));
                reservation.appendChild(price);
            }
            
        }
        
        //odstraneni seznamu zakazniku a zbozi
        NodeList root = xmlDocument.getElementsByTagName("pujcovna"); 
        Element r = (Element)root.item(0);
        NodeList clientList = r.getElementsByTagName("seznamZakazniku");   
        NodeList productList = r.getElementsByTagName("seznamZbozi");
        int l  = clientList.getLength();
        int l2 = productList.getLength();
        
        for (int i = 0; i < l; i++) {
            r.removeChild(clientList.item(i));
        }
        for (int i = 0; i < l2; i++) {
            r.removeChild(productList.item(i));
        }
        
    }
}
