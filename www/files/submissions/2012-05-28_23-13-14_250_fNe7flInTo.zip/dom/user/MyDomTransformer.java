package user;

import java.io.File;
import java.util.Iterator;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * 
 * Replaces //album/lineup/ref with
 * 
 * <lineup>
 * 	<perf>
 * 		<id>idValue</id>
 * 		<name>NameOfAPerformer</name>
 * 		<surname>SurnameOfAPerformer</surname>
 * 	</perf>
 *  <perf> ...
 *  
 *  </lineup>
 *  
 *  
 *  based on lookup of a performer by its ID (/encyclopedia/performers/performer/@id)
 * 
 * 
 * 
 * 
 * 
 * @author Martin Sixta
 * 
 */
public class MyDomTransformer {


	private static final String ELEM_ALBUM = "album";
	private static final String ELEM_PERF = "performer";
	private static final String ELEM_NAME = "name";
	private static final String ELEM_TITLE = "title";
	private static final String ELEM_LINEUP = "lineup";
	private static final String ELEM_REF = "ref";

	private static final String ATTR_ID = "id";

	public void transform(Document xmlDocument) {
		NodeList albums = xmlDocument.getElementsByTagName(ELEM_ALBUM);
		NodeList performers = xmlDocument.getElementsByTagName(ELEM_PERF);

		for (Node album : new NodeIterable(albums)) {
			Node title = getChildByName(album, ELEM_TITLE);
			// System.out.printf("Processing album %s \n",
			// title.getTextContent());

			Node lineup = getChildByName(album, ELEM_LINEUP);
			if (lineup == null) {
				// System.out.println("\tNo lineup!");
				continue;
			}

			for (Node ref : new NodeIterable(lineup.getChildNodes(), ELEM_REF)) {

				String id = getAttrText(ref, ATTR_ID);

				Element performer = (Element) getNodeById(performers, id);
				lineup.removeChild(ref);

				Element perf = createPerf(xmlDocument, performer);
				lineup.appendChild(perf);

			}
		}
	}

	private Element createPerf(Document doc, Element performer) {

		String idValue = getAttrText(performer, ATTR_ID);
		
		String performerName =  getChildByName(performer, ELEM_NAME).getTextContent().trim();
		
		int index = performerName.lastIndexOf(" ");
		
		String nameValue;
		String surnameValue;
		
		if (index == -1) {
			nameValue = "";
			surnameValue = performerName;
		} else {
			nameValue = performerName.substring(0, index);
			surnameValue = performerName.substring(index + 1);
			
		}
		
		
		Element perf = doc.createElement("perf");
		
		Element id = doc.createElement("id");
		id.setTextContent(idValue);
		
		Element name = doc.createElement("name");
		name.setTextContent(nameValue);
		
		Element surname = doc.createElement("surname");
		surname.setTextContent(surnameValue);
		
		perf.appendChild(id);
		perf.appendChild(name);
		perf.appendChild(surname);
		
		
		return perf;
		
	}

	/**
	 * 
	 * Returns the first child of {@code node} with name {@code  childName}, or
	 * null if no such child is found.
	 * 
	 * @param node
	 * @param childName
	 * @return
	 */
	private Node getChildByName(Node node, String childName) {
		NodeList children = node.getChildNodes();

		for (int i = 0; i < children.getLength(); ++i) {
			if (children.item(i).getNodeName().equals(childName)) {
				return children.item(i);
			}
		}

		return null;
	}

	private Node getNodeById(NodeList nodeList, String id) {
		for (Node node : new NodeIterable(nodeList)) {
			NamedNodeMap attrs = node.getAttributes();
			if (attrs == null) {
				continue;
			}

			Node attrId = attrs.getNamedItem(ATTR_ID);

			if (attrId == null) {
				continue;
			}

			if (attrId.getTextContent().equals(id)) {
				return node;
			}

		}

		return null;
	}

	private String getAttrText(Node node, String name) {
		return node.getAttributes().getNamedItem(ATTR_ID).getTextContent();
	}

	static class NodeIterable implements Iterable<Node> {

		private NodeList nodeList;
		private String name;

		public NodeIterable(NodeList nodeList) {
			this.nodeList = nodeList;
			this.name = null;
		}

		public NodeIterable(NodeList nodeList, String nodeName) {
			this.nodeList = nodeList;
			this.name = nodeName;
		}

		
		public Iterator<Node> iterator() {
			return new Iterator<Node>() {

				int index = 0;

				
				public boolean hasNext() {
					findNext();

					return (index < nodeList.getLength());
				}

				
				public Node next() {
					return nodeList.item(index++);
				}

				
				public void remove() {
					throw new UnsupportedOperationException();
				}

				private void findNext() {
					if (name == null) {
						return;
					}

					do {
						Node current = nodeList.item(index);
						if (current.getNodeName().equals(name)) {
							break;
						} else {
							++index;
						}
					} while (index < nodeList.getLength());

				}

			};
		}

	}

	public static void main(String[] args) {

		MyDomTransformer mdt = new MyDomTransformer();

		String filename = "data.xml";
		String outfile = "data.out.xml";

		try {

			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

			dbf.setValidating(false);

			DocumentBuilder builder = dbf.newDocumentBuilder();

			Document doc = builder.parse(filename);

			mdt.transform(doc);

			TransformerFactory tf = TransformerFactory.newInstance();

			Transformer writer = tf.newTransformer();

			writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

			writer.transform(new DOMSource(doc), new StreamResult(new File(
					outfile)));

		} catch (Exception e) {

			e.printStackTrace();

		}
	}

}
