package user;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 * 
 * Displays basic information about the Encyclopedia, such as total number of
 * bands, songs, albums, average number of songs per albums and statistics about
 * each band (albums, songs, average number of songs per album, average number
 * of performers on an album)
 * 
 * 
 * 
 * 
 * @author Martin Sixta
 * 
 */
public class MySaxHandler extends DefaultHandler {

	// ------------------------------------------------------------------------
	// Elements
	// ------------------------------------------------------------------------
	private static final String ELEM_BAND = "band";
	private static final String ELEM_ALBUM = "album";
	private static final String ELEM_SONG = "song";
	private static final String ELEM_PERF = "performer";
	private static final String ELEM_GENRE = "genre";
	private static final String ELEM_NAME = "name";
	private static final String ELEM_TITLE = "title";
	private static final String ELEM_LINEUP = "lineup";
	private static final String ELEM_REF = "ref";

	/* Album info aggregation */
	static class Album {
		String name;
		int songs;
		int lineup;
	}

	// ------------------------------------------------------------------------
	// Global counts
	// ------------------------------------------------------------------------
	private int bandsCount;
	private int albumsCount;
	private int songsCount;
	private int perfCount;
	private int genresCount;

	// name of the currently processed band
	private String currentBand;

	// list of albums of the currently processed band
	List<Album> currentAlbums;

	// info about currently processed album
	Album currentAlbum;

	// bands
	Map<String, List<Album>> bands;

	// whether to store characters
	private boolean storeCharacters = false;

	// characters accumulator
	private StringBuilder characters;

	// are we processing a band?
	boolean inBand = false;

	// an album?
	boolean inAlbum = false;

	// lineup ?
	boolean inLineup = false;

	// ------------------------------------------------------------------------

	Locator locator;

	@Override
	public void setDocumentLocator(Locator locator) {

		this.locator = locator;

	}

	@Override
	public void startDocument() throws SAXException {
		bandsCount = 0;
		albumsCount = 0;
		songsCount = 0;
		perfCount = 0;
		genresCount = 0;

		bands = new HashMap<String, List<Album>>();

		characters = new StringBuilder();
		storeCharacters = false;

	}

	@Override
	public void endDocument() throws SAXException {
		printf("--------- Music Encyclopedia Statistics ---------\n");
		printf("Bands: %d\n", bandsCount);
		printf("Albums: %d\n", albumsCount);
		printf("Songs: %d\n", songsCount);
		printf("Avg. songs: %.1f\n", (double) songsCount / albumsCount);
		printf("Performers: %d\n", perfCount);
		printf("Genres: %d\n", genresCount);

		printf("\n-------------- Per Band Statistics --------------\n");
		for (Entry<String, List<Album>> band : bands.entrySet()) {

			int songs = 0;
			int lineup = 0;

			for (Album album : band.getValue()) {
				songs += album.songs;
				lineup += album.lineup;
			}

			int albums = band.getValue().size();
			printf("%s [albums: %d, songs: %d, ", band.getKey(), albums, songs);
			printf("avg. songs: %.1f, ", (double) songs / albums);
			printf("avg. lineup: %.1f]\n", (double) lineup / albums);

		}

	}

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes atts) throws SAXException {

		if (localName.equals(ELEM_BAND)) {
			startBand();

		} else if (localName.equals(ELEM_ALBUM)) {
			startAlbum();
		} else if (localName.equals(ELEM_SONG)) {
			startSong();
		} else if (localName.equals(ELEM_PERF)) {
			startPerformer();
		} else if (localName.equals(ELEM_GENRE)) {
			startGenre();
		} else if (localName.equals(ELEM_NAME)) {
			startName();
		} else if (localName.equals(ELEM_TITLE)) {
			startTitle();
		} else if (localName.equals(ELEM_LINEUP)) {
			startLineup();
		} else if (localName.equals(ELEM_REF)) {
			startRef();

		}

	}

	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {

		// No Java 7 String switch :(
		if (localName.equals(ELEM_BAND)) {
			endBand();
		} else if (localName.equals(ELEM_ALBUM)) {
			endAlbum();
		} else if (localName.equals(ELEM_NAME)) {
			endName();
		} else if (localName.equals(ELEM_TITLE)) {
			endTitle();
		} else if (localName.equals(ELEM_LINEUP)) {
			endLineup();

		}

	}

	@Override
	public void characters(char[] ch, int start, int length)
			throws SAXException {

		if (storeCharacters) {
			characters.append(ch, start, length);

		}

	}

	// ------------------------------------------------------------------------
	// AUXILIARY PRIVATE FUNCTIONS
	// ------------------------------------------------------------------------

	// returns accumulated characters, resetting the accumulator
	private String getChars() {
		String result = characters.toString();
		characters = new StringBuilder();
		return result;
	}

	// just printf wrapper
	private void printf(String format, Object... args) {
		System.out.printf(format, args);
	}

	// ------------------------------------------------------------------------
	// ON START ELEMENT
	// ------------------------------------------------------------------------
	private void startRef() {
		if (inLineup) {
			++(currentAlbum.lineup);
		}
	}

	private void startLineup() {
		if (inAlbum) {
			inLineup = true;
		}
	}

	private void startTitle() {
		if (inAlbum) {
			storeCharacters = true;
		}
	}

	private void startName() {
		if (inBand) {
			storeCharacters = true;
		}
	}

	private void startGenre() {
		++genresCount;
	}

	private void startPerformer() {
		++perfCount;
	}

	private void startSong() {
		++songsCount;

		if (inAlbum) {
			++(currentAlbum.songs);
		}
	}

	private void startAlbum() {
		inAlbum = true;
		currentAlbum = new Album();
		++albumsCount;
	}

	private void startBand() {
		++bandsCount;
		inBand = true;
		currentAlbums = new LinkedList<Album>();
	}

	// ------------------------------------------------------------------------
	// ON END ELEMENT
	// ------------------------------------------------------------------------
	private void endLineup() {
		if (inAlbum) {
			inLineup = false;
		}
	}

	private void endTitle() {
		storeCharacters = false;

		if (inAlbum) {
			currentAlbum.name = getChars();
		}
	}

	private void endName() {
		storeCharacters = false;

		if (inBand) {
			currentBand = getChars();
		}
	}

	private void endAlbum() {
		inAlbum = false;
		currentAlbums.add(currentAlbum);
	}

	private void endBand() {
		inBand = false;
		bands.put(currentBand, currentAlbums);
	}

	// ------------------------------------------------------------------------
	// MAIN (for debugging)
	// ------------------------------------------------------------------------
	public static void main(String[] args) {
		String sourcePath = "data.xml";

		try {
			XMLReader parser = XMLReaderFactory.createXMLReader();

			InputSource source = new InputSource(sourcePath);

			parser.setContentHandler(new MySaxHandler());

			parser.parse(source);

		} catch (Exception e) {

			e.printStackTrace();

		}

	}
}
