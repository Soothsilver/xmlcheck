package user;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer {

    private Element findComponent(String id, String name, Element components) {
        NodeList list = components.getElementsByTagName(name);
        for (int i = 0; i < list.getLength(); ++i) {
            Element c = (Element) list.item(i);
            if (c.getAttribute("id").equals(id)) {
                Element clone =  (Element) c.cloneNode(true);
                clone.removeAttribute("id");
                return clone;
            }
        }
        throw new DOMException(DOMException.NOT_FOUND_ERR, "Cannot find " + name + " component with id '" + id + "'");
    }

    private void replaceComponents(String name, Element machine, Element components) {
        NodeList machineComponent = machine.getElementsByTagName(name);
            for (int h = 0; h < machineComponent.getLength(); ++h) {
                Element hdd = (Element) machineComponent.item(h);
                hdd.getParentNode().replaceChild(findComponent(hdd.getAttribute("ref_id"), name, components), hdd);
            }
    }

    public void transform(Document xmlDocument) {
        NodeList machines = xmlDocument.getElementsByTagName("machine");
        Element components = (Element) xmlDocument.getElementsByTagName("components").item(0);

        for (int i = 0; i < machines.getLength(); ++i) {
            Element machine = (Element) machines.item(i);
            replaceComponents("hard-drive", machine, components);
            replaceComponents("graphic-card", machine, components);
        }
        components.getParentNode().removeChild(components);
    }

}
