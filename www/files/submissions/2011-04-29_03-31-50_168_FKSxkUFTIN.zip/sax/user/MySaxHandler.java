package user;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler
{
	private int MaxDepth;
	private int AverageDepth;
	
	private int ElementCount;
	
	private int tempMaxDepth;
	private int accDepth;
	
	public MySaxHandler()
	{
		 this.ElementCount = 0;
		 this.MaxDepth = 0;
		 this.AverageDepth = 0;
		 
		 this.tempMaxDepth = 0;
		 this.accDepth = 0;
		 
	}
	
	//pri kazdem novem elementu prictu pocet elementu a aktualni hloubku zanoreni
	public void startElement(String namespaceURI, String localName, String qName, Attributes atts) throws SAXException
	{
		this.ElementCount++;
		this.tempMaxDepth++;
    }
	
	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException
	{
		//vynorime se o jedna, protoze skocil jeden element
		this.tempMaxDepth--;
		
		//ulozime max hloubku
		if(this.tempMaxDepth > this.MaxDepth)
		{
			this.MaxDepth = this.tempMaxDepth;
		}
		
		//pricteme hloubku uzlu ktery sme opustili, pro prumernou hloubku uzlu
		accDepth += tempMaxDepth;
		
	}
	
	@Override
	 public void endDocument() throws SAXException
	 {        
		this.AverageDepth = this.accDepth / this.ElementCount;
		
        System.out.println("Pocet elementu : "+ this.ElementCount);
        System.out.println("Maximalni hloubka dokumentu : "+this.MaxDepth);
        System.out.println("Prumerna hloubka elementu : "+this.AverageDepth);
	 }

}