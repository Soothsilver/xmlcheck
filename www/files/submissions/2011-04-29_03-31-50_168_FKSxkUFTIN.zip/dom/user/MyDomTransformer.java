package user;

import java.io.File;
import java.util.LinkedList;
import java.util.List;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer
{
	public void transform (Document xmlDocument)
	{
		  try
		  {
			  NodeList nodes = xmlDocument.getChildNodes();
			  
			  for(int i = 0 ; i < nodes.getLength();i++)
			  {
				  //vememe si root node
				  if(nodes.item(i).getNodeName() == "nemocnice")
				  {
					  transformAttributesToElements(nodes.item(i),xmlDocument);
					  break;
				  }
			  }
			  		  
			 
	      }
		  catch (Exception e)
		  {      
	            e.printStackTrace();     
	      }
	}
	
	private void transformAttributesToElements(Node n,Document doc)
	{
		//root node ma atributy pro schema, proto ho nebudeme menit
		if(n.getNodeName() != "nemocnice")
		{
			NamedNodeMap attributes = n.getAttributes();
			
			//pokud jsou nejake atributy
			if(attributes != null)
			{
				int count = attributes.getLength();
				List<String> attrs = new LinkedList<String>();
				
				//projdu atributy a zmenim je na elemnty
				for(int i=0;i<count;i++)
				{
					Element elem = doc.createElement(((Attr)attributes.item(i)).getName());
					elem.setTextContent(((Attr)attributes.item(i)).getValue());
					
					n.appendChild(elem);
					
					attrs.add(((Attr)attributes.item(i)).getName());
				}
				//odstranim atributy
				for(int i=0;i<count;i++)
				{
										
					Element nodeElem = (Element)n;
					nodeElem.removeAttribute(attrs.get(i));
				}
			}
		}
		
		NodeList childrens = n.getChildNodes();
		//rekurze na potomky
		for(int i=0;i<childrens.getLength();i++)
		{
			transformAttributesToElements(childrens.item(i),doc);
		}
	}
}
