package user;

import java.util.LinkedList;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
	int level, fanout, maxLevel, maxFanout, elecount, maxAttrcount, attrcount;
	double sumElename, sumAttrname;
	
	protected class Eleinfo {
		int fanout;
		
		Eleinfo () {
			fanout = 0;
		}		
	}
	
	LinkedList<Eleinfo> ele;
	
	public void startDocument() throws SAXException {
		level = 0;
		elecount = 0;
		attrcount = 0;
		maxLevel = 0;
		maxAttrcount = 0;
		sumElename = 0;
		sumAttrname = 0;
		ele = new LinkedList<Eleinfo>();
		System.out.println("start document   : ");
	}

	public void endDocument() throws SAXException {
		System.out.println("end document     : ");
		System.out.println("maxFanout = " + maxFanout);
		System.out.println("maxLevel = " + maxLevel);
		System.out.println("maxAttributes = " + maxAttrcount);
		System.out.println("cntAttributes = " + attrcount);
		System.out.println("cntElements = " + elecount);
		if (elecount > 0)
			System.out.println("avgElementName = " + sumElename/elecount);
		if (attrcount > 0)
			System.out.println("avgAttributeName = " + sumAttrname/attrcount);
		
	}

	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {

		if (! ele.isEmpty()) {
			ele.getFirst().fanout ++;			
		}
		sumElename += qName.length();
		Eleinfo e = new Eleinfo ();
		ele.push(e);
		level ++;
		if (level > maxLevel) maxLevel = level;
		elecount ++;
		if (attributes.getLength() > maxAttrcount) maxAttrcount = attributes.getLength();
		
		for (int i = attributes.getLength() - 1; i >= 0; i --) {
			sumAttrname += attributes.getQName(i).length();			
		}
		attrcount += attributes.getLength();
 	}

	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		Eleinfo e = ele.getFirst();
		ele.pop ();
		if (e.fanout > maxFanout) maxFanout = e.fanout;
		level --;
  	}

	public void characters(char ch[], int start, int length)
			throws SAXException {
 
	}

}
