package user;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

public class MyDomTransformer {

	private void attrsToElements(Element e) {
		Node a = e.getFirstChild();
		while (a != null) {
			switch (a.getNodeType()) {

			case Node.ATTRIBUTE_NODE:
				break;
			case Node.ELEMENT_NODE:
				NamedNodeMap nm = a.getAttributes();
				int i = nm.getLength();

				Node aa,
				la;

				la = a.getFirstChild();

				while (i > 0) {

					aa = nm.item(i - 1);
					Node na = e.getOwnerDocument().createElement(
							aa.getNodeName());
					na.appendChild(e.getOwnerDocument().createTextNode(
							aa.getNodeValue()));

					a.insertBefore(na, la);
					la = na;
					((Element) a).removeAttributeNode((Attr) aa);

					i--;
				}
				attrsToElements((Element) a);
				break;
			default:

			}

			a = a.getNextSibling();
		}
	}

	protected void attrsToElements(Document doc) {
		attrsToElements(doc.getDocumentElement());
	}

	protected void invertContent(Node n) {
		Node last = n.getFirstChild();
		while (true) {
			Node la = n.getLastChild();
			if (la == last)
				break;
			n.removeChild(la);
			invertContent(la);

			n.insertBefore(la, last);
		}
	}

	protected void invertContent(Document doc) {
		invertContent(doc.getDocumentElement());

	}

	public void transform(Document doc) {

		/* prevadi atributy na elementy */
		attrsToElements(doc);

		invertContent(doc);

	}

}
