/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import org.w3c.dom.Document;
import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

/**
 * @author Chuong
 */
public class MyDomTransformer {

  /**
   * Process document tree
   *
   * @param doc Document to be parsed
   */
  private static void transform(Document doc) {


	NodeList zbozi = doc.getElementsByTagName("zbozi");

	for (int i = 0; i < zbozi.getLength(); i++) {
	  Element zb = (Element) zbozi.item(i);
	  Element cena = (Element) zb.getElementsByTagName("cena").item(0);
	  Integer hodnota = new Integer(cena.getTextContent());
	  Double novaHodnota = hodnota * 1.20;
	  cena.setAttribute("vcetne_dph", "20");
	  cena.setTextContent(novaHodnota.toString());
	  //System.out.println("elzbozi = " + cena.getTextContent());
	}


  }
}
