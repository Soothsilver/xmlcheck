package user;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import org.w3c.dom.*;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.OutputKeys;
import java.io.FileOutputStream;
import java.util.Date;
import java.util.Locale;
import java.text.DateFormat;
import java.util.ArrayList;

/**
 * deletes the elemenents that are deeper than 4 elements
 * @author xxxxx
 */
public class MyDomTransformer  {
    
 
    private static void transform2(Node elem){
        NodeList children = elem.getChildNodes();
        for (int i = 0; i <children.getLength(); i++) {
            Node t = children.item(i);
            if(t.getNodeType() == Node.ELEMENT_NODE)
                elem.removeChild(t);
        }
        
    }
    private static void process(Node elem, int depth)
    {
       
                if(depth == 4)
                {
                    transform2(elem);
                    System.out.println("transformed ..");
                    
                }
                ++depth;
                 NodeList children = elem.getChildNodes();
                for(int i = 0; i < children.getLength(); i++){
                        Node t = children.item(i);
			if(t.getNodeType() == Node.ELEMENT_NODE)
                            process(t, depth);   
                } 
           
    }
    private static void transform(Document doc){
        NodeList list = doc.getChildNodes();
        //System.out.println(list.item(0).getNodeName());
        Element root = doc.getDocumentElement();
        System.out.println(root.getNodeName());          
          
                int depth = 2;
		for(int i = 0; i < root.getChildNodes().getLength(); i++){
                    if(root.getChildNodes().item(i).getNodeType() == Node.ELEMENT_NODE)
                        process(root.getChildNodes().item(i), depth);        	
		}
                
               
     
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
                
		String filename = "C:/Users/xxxxx/Documents/Altova/XMLSpy2012/Examples/data.xml";
		String outfile = "C:/Users/xxxxx/Documents/Altova/XMLSpy2012/Examples/datanew.xml";
		
		try {
            
            //DocumentBuilderFactory vytvoøí DOM parsery
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

         
            dbf.setValidating(false);

           
            DocumentBuilder builder = dbf.newDocumentBuilder();

                      
            Document doc = builder.parse(filename);
            

          
            transform(doc);

            TransformerFactory tf = TransformerFactory.newInstance();

           
            Transformer writer = tf.newTransformer();

           
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            
            writer.transform(new DOMSource(doc), new StreamResult(new File(outfile)));


        } catch (Exception e) {
            
            e.printStackTrace();
            
        }
    }    
}