package user;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

public class MySaxHandler extends DefaultHandler
{ 
	private static double sum;
	private static int count;
	private static int max;
	
	public void startDocument() throws SAXException
	{
		sum = 0;
		count = 0;
		max = 0;
	}      
	public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
	{
		int l = localName.length();
		sum += l;
		count++;
		if (max < l) max = l;
    }
	
	public void endDocument() throws SAXException {
		System.out.print("The XML document contained ");
        System.out.print(count);
        System.out.println(" elements.");
        System.out.print("The longest element name was ");
        System.out.print(max);
        System.out.println(" letters long.");
        System.out.print("The average element name length was ");
        System.out.print(sum/count);
        System.out.println(" letters.");
    }
}