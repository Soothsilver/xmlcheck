package user;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

public class MyDomTransformer
{ 

    private static final int DEPTH_LIMIT = 5;


	public void transform (Document xmlDocument) 
	{
		Node koren = xmlDocument.getFirstChild();
		enter(koren,1);
	}
	public void enter(Node n, int depth)
	{
			NodeList nodi = n.getChildNodes();
			for (int i = 0; i<nodi.getLength(); i++)
			{
				if (depth==DEPTH_LIMIT && nodi.item(i).getNodeType()==Node.ELEMENT_NODE )	n.removeChild(nodi.item(i));
				else enter(nodi.item(i), depth+1);
			}
	}
}