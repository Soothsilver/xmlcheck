package user;

import java.util.LinkedList;
import java.util.List;

/*
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;*/

import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;



/**
 * 
 * Do každého netextového elementu vložím element, určující počet v tomto elementu
 * vnořených elementů.
 * 
 * @author Ondra Kudlacek
 *
 */
public class MySaxHandler extends DefaultHandler {

	/*private static final String INPUT = "data.xml";*/
	
	private int depth = 0;
	private List<Integer> list = null;

	
	/*
	 * Drzim si aktualni hodnotu zanoreni. Pri vynoreni si v
	 * listu zvysim pocet nalezenych elementu a vypisu pocet
	 * nalezenych elementu vnorenych elementu.
	 */
	/*public static void main(String[] args) {
		try {
			SAXParserFactory factory = SAXParserFactory.newInstance();

			SAXParser parser = factory.newSAXParser();

			XMLReader reader = parser.getXMLReader();

			MySaxHandler test = new MySaxHandler();

			reader.setContentHandler(test);
			reader.setErrorHandler(test);
			reader.parse(INPUT);

		} catch (Exception ex) {
			System.out.println("chyba: " + ex.getMessage());
		}

	}*/

	@Override
	public void startDocument() throws SAXException {
		//System.out.println("Zacatek dokumentu");
		depth = 0;
		list = new LinkedList<Integer>();
		list.add(0);
	}

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {
		
		list.set(depth, list.get(depth) + 1);
		
		++depth;
		
		if(list.size() <= depth){
			list.add(0);
		}
		
		System.out.print("<" + qName + attributes(attributes) + ">");
	}

	private String attributes(Attributes attributes) {
		
		StringBuffer buffer = new StringBuffer();
		for (int i = 0; i < attributes.getLength(); i++) {
			buffer.append(" ");
			buffer.append(attributes.getQName(i));
			buffer.append("=\"");
			buffer.append(attributes.getValue(i));
			buffer.append("\"");
		}
		return buffer.toString();
	}

	@Override
	public void characters(char[] ch, int start, int length)
			throws SAXException {

		System.out.print(new String(ch, start, length));
	}
	
	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {

		int pocet = list.get(depth);
		if(pocet > 0){
			System.out.print("\t"+"<pocitadlo>"+pocet+"</pocitadlo>"+"\n");
			writeSpaces(depth -1);
		}
		
		System.out.print("</" + qName + ">");
		
		list.set(depth, 0);
		--depth;
	}
	private void writeSpaces(int howMany){
		for(int i=0; i < howMany; ++i){
			System.out.print("\t");
		}
	}

	@Override
	public void endDocument() {
		//System.out.println("\nKonec dokumentu");
	}

	//errors###################################################################
	@Override
	public void error(SAXParseException e) {
		
		System.out.println(e.getMessage());
	}
	
	@Override
	public void warning(SAXParseException e) {
		
		System.out.println(e.getMessage());
	}

	@Override
	public void fatalError(SAXParseException e) {
		
		System.out.println(e.getMessage());
	}
}
