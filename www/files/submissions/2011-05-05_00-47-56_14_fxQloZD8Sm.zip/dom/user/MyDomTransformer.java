package user;

/*
import java.io.File;*/
import java.util.ArrayList;
import java.util.List;

/*
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;*/

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


/**
 * Prepisuje ze seznamu knih na seznam vydavatelstvi v knihovne.
 * Pro kazde vydavatelstvi vytvori seznam knih od tohoto vydavatelstvi
 * v knihovne a seznam tiskaren, ktere pro toto vydavatelsvi tiskly
 * knihy v knihovne.
 */

public class MyDomTransformer {
	private static final String LIBRARY = "library";
	
	private static final String PUBLISHED = "published";
	private static final String PUBLISHER = "publisher";
	private static final String PRINTER = "printer";
	private static final String BOOK = "book";
	
	//elementy vydavatele
	//NAME
	private static final String ADDRESS = "address";
	private static final String PHONE = "phone";
	
	//elementy tiskarny
	//NAME
	//ADDRESS
	private static final String PRINTERS = "printers";
	
	//atribut telefonu
	private static final String COMMENTARY = "commentary";
	private static final String PHONES = "phones";
	
	//elementy adresy
	private static final String STREET = "street";
	private static final String NUMBER = "num";
	private static final String CITY = "city";
	private static final String STATE = "state";
	private static final String POSTAL_CODE = "postalCode";
	
	
	//elementy knihy
	private static final String BOOKS = "books";
	private static final String NAME = "name";
	private static final String AUTHORS = "authors";
	private static final String LANGUAGE = "language";
	private static final String TRANSLATION = "translation";
	private static final String TRANSLATOR = "translator";
	private static final String ISBN = "ISBN";
	//COMMENTARY
	private static final String OTHER_EDITIONS = "otherEditions";
	private static final String CATEGORY = "category";
	//COMMENTARY
	private static final String PRINTS_IN_LIB = "printsInLib";
	private static final String LOCATION_IN_LIB = "locationInLib";
	private static final String YEAR = "year";
	
	//elementy pod autors
	private static final String AUTHOR = "author";
	
	//elementy pozici knih
	private static final String DEPOSITARY = "depositary";
	private static final String ROW = "row";
	private static final String LINE = "line";
	private static final String BORROWED = "borrowed";
	//ROW
	//LINE
	private static final String PRESENT = "present";
	private static final String DAY = "day";
	private static final String MONTH = "month";
	//YEAR
	
	
	/*public static void main(String[] args){
		try{
			// DocumentBuilderFactory vytvari DOM parsery
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			// nebudeme validovat
			dbf.setValidating (false);
			// vytvorime si DOM parser
			DocumentBuilder builder = dbf.newDocumentBuilder();
			// parser zpracuje soubor a vytvori strom DOM objektu
			Document doc = builder.parse("data.xml");
			// zpracujeme DOM strom
			
			new MyDomTransformer().transform(doc);
			
			// TransformerFactory vytvari serializatory DOM stromu
			TransformerFactory tf = TransformerFactory.newInstance ();
			// Transformer serializuje DOM stromy
			Transformer writer = tf.newTransformer ();
			// nastavime kodovani
			writer.setOutputProperty
			(OutputKeys.ENCODING, "UTF-8");
			// spustime transformaci DOM stromu do XML dokumentu
			writer.transform(new DOMSource(doc),
					new StreamResult(new File("output.xml")));

			
		} catch(Exception ex){
			System.out.println("chyba: "+ex.getMessage());
		}
	}*/
	
	public void transform(Document xmlDocument){
		
		/*
		 * po tom, co jsem napsal celou nacitaci cast a vsechny
		 * pomocne tridy pro uchovani dat, jesem si uvedomil,
		 * ze tohle asi neni nejlepsi zpusob jak pouzivat
		 * DOM (ale taky to jde)...uz jsem tu nekolikahodinouvou
		 * praci nechtel mazat a psat znova...
		 */

		//get ready
		Document doc = xmlDocument;
		Node library = getChildElement(LIBRARY, doc); //element library
		if(library == null){
			return;
		}
		
		if(library.getChildNodes().getLength() < 1){
			//existuji nejake knihy v knihovne
			return;
		}
		//ready
		
		Node firstBookInList = getChildElement(BOOK, library);
		
		//load all
		List<Publisher> publishers = remDuplicPubs(
				createPublisherList(firstBookInList));
		List<List<Printer>> printers = new ArrayList<List<Printer>>();
		List<List<Book>> books = new ArrayList<List<Book>>();
		
		for(Publisher p : publishers){
			
			printers.add(remDuplicPris(
					createPrinterList(firstBookInList, p.getName())));
			books.add(createBookList(firstBookInList, p.getName()));
		}
		
		//clean up
		NodeList nList = library.getChildNodes();
		while(nList.getLength() != 0){
			library.removeChild(nList.item(0));
		}
		
		//write it back;
		createNewDocument(doc, publishers, printers, books);
	}
	
	//zapisovani dat do DOMu v novem formatu#############################################
	
	private void createNewDocument(Document doc, List<Publisher> publishers,
			List<List<Printer>> printers, List<List<Book>> books){
		Node library = doc.getChildNodes().item(0);
		
		for(int i = 0; i < publishers.size(); ++i){
			library.appendChild(
					constructPublisher(doc, publishers.get(i),
							printers.get(i), books.get(i)));
		}
	}
	private Element constructPublisher(Document doc, Publisher publisher,
			List<Printer> printers, List<Book> books){
		
		Element ePublish = doc.createElement(PUBLISHER);
		
		Element ePName = doc.createElement(NAME);
		ePName.setTextContent(publisher.getName());
		ePublish.appendChild(ePName);
		
		ePublish.appendChild(constructAddress(doc, publisher.getAddress()));
		
		ePublish.appendChild(constructPhones(doc, publisher.getPhones()));
		
		ePublish.appendChild(constructPrinters(doc, printers));
		
		ePublish.appendChild(constructBooks(doc, books));
		
		return ePublish;
	}
	private Element constructBooks(Document doc, List<Book> books){
		Element eBooks = doc.createElement(BOOKS);
		
		for(Book book : books){
			Element eBook = doc.createElement(BOOK);
			
			//element name
			Element eName = doc.createElement(NAME);
			eName.setTextContent(book.getName());
			eBook.appendChild(eName);
			
			//element authors
			Element eAuthors = doc.createElement(AUTHORS);
			for(String authorName : book.getAuthors()){
					
				Element eAuthor = doc.createElement(AUTHOR);
				eAuthor.setTextContent(authorName);
				eAuthors.appendChild(eAuthor);
			}
			eBook.appendChild(eAuthors);
			
			//element translation
			if(!book.getBLang().getTranslator().equals("")){
				Element eTranslation = doc.createElement(TRANSLATION);
				
				Element eOrigName = doc.createElement(NAME);
				eOrigName.setTextContent(book.getBLang().getOriginalName());
				eTranslation.appendChild(eOrigName);
				
				Element eTranslator = doc.createElement(TRANSLATOR);
				eTranslator.setTextContent(book.getBLang().getTranslator());
				eTranslation.appendChild(eTranslator);
				
				eBook.appendChild(eTranslation);
			}
			
			//element language
			Element eLanguage = doc.createElement(LANGUAGE);
			eLanguage.setTextContent(book.getBLang().getLanguage());
			eBook.appendChild(eLanguage);
			
			//element isbn
			Element eIsbn = doc.createElement(ISBN);
			eIsbn.setTextContent(book.getIsbns().get(0).getCode());
			if(!book.getIsbns().get(0).getCommentary().equals("")){
				eIsbn.setAttribute(COMMENTARY,
						book.getIsbns().get(0).getCommentary());
			}
			eBook.appendChild(eIsbn);
			
			//other isbns
			if(book.getIsbns().size() > 1){
				Element eOtherE = doc.createElement(OTHER_EDITIONS);
				
				List<Isbn> isbns = book.getIsbns();
				
				for(int i=1; i<isbns.size(); ++i){
					Element eOtherI = doc.createElement(ISBN);
					eOtherI.setTextContent(isbns.get(i).getCode());
					if(!isbns.get(i).getCommentary().equals("")){
						eOtherI.setAttribute(COMMENTARY, isbns.get(i).getCommentary());
					}
					
					eOtherE.appendChild(eOtherI);
				}
				
				eBook.appendChild(eOtherE);
			}
			
			//categories
			for(String cat : book.getCategories()){
				Element eCat = doc.createElement(CATEGORY);
				eCat.setTextContent(cat);
				eBook.appendChild(eCat);
			}
			
			//commentary
			if(!book.getCommentary().equals("")){
				Element eCom = doc.createElement(COMMENTARY);
				eCom.setTextContent(book.getCommentary());
				eBook.appendChild(eCom);
			}
			
			//printsInLib
			Element ePrintsIntLib = doc.createElement(PRINTS_IN_LIB);
			ePrintsIntLib.setTextContent(book.getPrintsInLib());
			eBook.appendChild(ePrintsIntLib);
			
			//locationInLib
			Element eLocationInLib = doc.createElement(LOCATION_IN_LIB);
			for(Location loc : book.getLocations()){
				if(loc instanceof Borrowed){
					
					Element eBorrowed = doc.createElement(BORROWED);
					eBorrowed.setAttribute(DAY, ((Borrowed)loc).getDay());
					eBorrowed.setAttribute(MONTH, ((Borrowed)loc).getMont());
					eBorrowed.setAttribute(YEAR, ((Borrowed)loc).getYear());
					eLocationInLib.appendChild(eBorrowed);
				} else if(loc instanceof Depositary){
					
					Element eDepositary = doc.createElement(DEPOSITARY);
					eDepositary.setAttribute(ROW, ((Depositary)loc).getRow());
					eDepositary.setAttribute(LINE, ((Depositary)loc).getLine());
					eLocationInLib.appendChild(eDepositary);
				} else if(loc instanceof Present){
					
					Element ePresent = doc.createElement(PRESENT);
					ePresent.setAttribute(ROW, ((Present)loc).getRow());
					ePresent.setAttribute(LINE, ((Present)loc).getLine());
					eLocationInLib.appendChild(ePresent);
				}
				/*
				 * else fail() :-D
				 */
			}
			
			eBooks.appendChild(eBook);
		}
		
		return eBooks;
	}
	private Element constructPrinters(Document doc, List<Printer> printers){
		Element ePrinters = doc.createElement(PRINTERS);
		
		for(Printer printer : printers){
			Element ePrinter = doc.createElement(PRINTER);
			
			Element eName = doc.createElement(NAME);
			eName.setTextContent(printer.getName());
			ePrinter.appendChild(eName);
			
			if(!printer.getAddress().getCity().equals("")){ //je adresa prazdna?
				ePrinter.appendChild(constructAddress(doc, printer.getAddress()));
			}
			
			ePrinters.appendChild(ePrinter);
		}
		
		return ePrinters;
	}
	private Element constructPhones(Document doc, List<Phone> phones){
		Element ePhones = doc.createElement(PHONES);
		
		for(Phone phone : phones){
			Element ePhone = doc.createElement(PHONE);
			if(!phone.getCommentary().equals("")){
				ePhone.setAttribute(COMMENTARY, phone.getCommentary());
			}
			ePhone.setTextContent(phone.getNumber());
			
			ePhones.appendChild(ePhone);
		}
		
		return ePhones;
	}
	private Element constructAddress(Document doc, Address address){
		Element eAddress = doc.createElement(ADDRESS);
		
		Element eStreet = doc.createElement(STREET);
		eStreet.setTextContent(address.getStreet());
		eAddress.appendChild(eStreet);
		
		Element eNum = doc.createElement(NUMBER);
		eNum.setTextContent(address.getNumber());
		eAddress.appendChild(eNum);
		
		Element eCity = doc.createElement(CITY);
		eCity.setTextContent(address.getCity());
		eAddress.appendChild(eCity);
		
		if(!address.getState().equals("")){
			Element eState = doc.createElement(STATE);
			eState.setTextContent(address.getState());
			eAddress.appendChild(eState);
		}
		
		if(!address.getPostalCode().equals("")){
			Element ePostC = doc.createElement(POSTAL_CODE);
			ePostC.setTextContent(address.getPostalCode());
			eAddress.appendChild(ePostC);
		}
		
		return eAddress;
	}
	
	
	//nacteni dat do pameti##############################################################
	
	/**
	 * Vytvori strukturu objektu na zaklade struktury DOM 
	 * @param nList seznam knih
	 */
	private List<Publisher> createPublisherList(Node firstChild){
		//pro kazdou knihu vezmu jejiho vydavatele a pridam do seznamu
		List<Publisher> publishers = new ArrayList<MyDomTransformer.Publisher>();
		Node pNode = null;
		
		for(Node node = firstChild;	node != null; node = node.getNextSibling()){
			
			if(node.getNodeType() != Node.ELEMENT_NODE){
				continue;
			}
			
			pNode = getChildElement(PUBLISHER, getChildElement(PUBLISHED, node));
			
			String name = getChildElement(NAME, pNode).getTextContent();
			Address address = constructAddress(pNode);
			List<Phone> phones = constructPhoneList(pNode);
			
			Publisher publisher = new Publisher(name, address, phones);
			publishers.add(publisher);
		}
		
		return publishers;
	}
	private List<Publisher> remDuplicPubs(List<Publisher> publishers){
		
		for(int i = 0; i < publishers.size(); ++i){
			for(int j = i + 1; j < publishers.size(); ++j){
				if(publishers.get(i).getName().equals(
						publishers.get(j).getName())){
					
					publishers.remove(j);
					--j;
				}
			}
		}
		
		return publishers;
	}
	
	/**
	 * ocekavam printer nebo publisher node
	 * @param node printer nebo publisher
	 * @return
	 */
	private Address constructAddress(Node node){
		String street = "";
		String number = "";
		String city = "";
		String state = "";
		String postalCode = "";
		
		Node adNode = getChildElement(ADDRESS, node);
		if(adNode == null){
			return new Address(street, number, city, postalCode, state);
		}
		
		
		street = getChildElement(STREET, adNode).getTextContent();
		number = getChildElement(NUMBER, adNode).getTextContent();
		city = getChildElement(CITY, adNode).getTextContent();
		
		Node stateNode = getChildElement(STATE, adNode);
		if(stateNode != null){
			state = stateNode.getTextContent();
		}
		
		Node postalNode = getChildElement(POSTAL_CODE, adNode);
		if(postalNode != null){
			postalCode = postalNode.getTextContent();
		}
		
		return new Address(street, number, city, postalCode, state);
	}
	private List<Phone> constructPhoneList(Node node){
		ArrayList<Phone> phones = new ArrayList<MyDomTransformer.Phone>();
		
		Node phoneNode = getChildElement(PHONE, node);
		if(phoneNode == null){
			return phones;
		}
		
		for(Node n = phoneNode; n != null; n = getSiblingElement(PHONE, n)){
			String number = n.getTextContent();
			String commentary = "";
			if(n.hasAttributes()){
				commentary = n.getAttributes().item(0).getTextContent();
			}
			
			Phone phone = new Phone(number, commentary);
			phones.add(phone);
		}
		
		return phones;
	}
	
	
	/**
	 * Vytvori seznam tiskaren tisknoucich pro daneeho vydavatele
	 * @param sibling first book in list
	 * @param publisherName jmeno vydavatele
	 */
	private List<Printer> createPrinterList(Node sibling, String publisherName){
		List<Printer> printers = new ArrayList<MyDomTransformer.Printer>();
		
		for(Node node = sibling; node != null; node = getSiblingElement(BOOK, node)){
			
			Node published = getChildElement(PUBLISHED, node);
			
			Node printer = getChildElement(PRINTER, published);
			if(printer == null){
				continue; //kniha nema uvedenou tiskarnu
			}
			
			if(!getChildElement(NAME,
					getChildElement(PUBLISHER, published)).
					getTextContent().equals(publisherName)){
				
				continue; //kniha nema vydavatele, ktereho hledam
			}
			
			String name = getChildElement(NAME, printer).getTextContent();
			Address address = constructAddress(printer);
			
			printers.add(new Printer(name, address));
		}
		
		return printers;
	}
	private List<Printer> remDuplicPris(List<Printer> printers){
		
		for(int i = 0; i < printers.size(); ++i){
			for(int j = i + 1; j < printers.size(); ++j){
				if(printers.get(i).getName().equals(
						printers.get(j).getName())){
					
					printers.remove(j);
					--j;
				}
			}
		}
		
		return printers;
	}
	/**
	 * vytvorim seznam knih vydane nakladatelstvim, ktere ma jmeno podle
	 * vstupniho parametru
	 * @param nList seznam knih
	 * @param publisherName jmeno nakladatelstvi
	 */
	private List<Book> createBookList(Node sibling, String publisherName){
		List<Book> books = new ArrayList<MyDomTransformer.Book>();
		
		for(Node node = sibling; node != null; node = node.getNextSibling()){
			
			if(node.getNodeType() != Node.ELEMENT_NODE || 
					!node.getNodeName().equals(BOOK)){
				continue;
			}
			
			if(!getChildElement(NAME, 
					getChildElement(PUBLISHER, 
							getChildElement(PUBLISHED, node))).
							getTextContent().equals(publisherName)){
				
				continue; //kniha nema vydavatele, ktereho hledam
			}
			
			String name = getChildElement(NAME, node).getTextContent();
			List<String> authors = constructAuthorList(node);
			BookLangueage bLang = constructBookLanguage(node);
			List<Isbn> isbns = constructIsbns(node);
			List<String> categories = constructCategories(node);
			String printsInLib = getChildElement(PRINTS_IN_LIB, node).getTextContent();
			List<Location> locations = constructLocations(node);
			
			String commentary = "";
			Node comm = getChildElement(COMMENTARY, node);
			if(comm != null){
				commentary = comm.getTextContent();
			}
			
			books.add(
					new Book(name, authors, bLang, isbns, categories,
							printsInLib, locations, commentary));
		}
		
		return books;
	}
	private List<String> constructAuthorList(Node book){
		List<String> authors = new ArrayList<String>();
		
		//prvni autor je druhy v seznamu elementu knihy
		for(Node author = getChildElement(AUTHOR, book);
				author != null; author = getSiblingElement(AUTHOR, author)){
			authors.add(author.getTextContent());
		}
		
		return authors;
	}
	private BookLangueage constructBookLanguage(Node book){
		String originalName = "";
		String translator = "";
		String language = "";
		
		language = getChildElement(LANGUAGE, book).getTextContent();
		Node translation = getChildElement(TRANSLATION, book);
		if(translation != null){
			originalName = getChildElement(NAME, translation).getTextContent();
			translator = getChildElement(TRANSLATOR, translation).getTextContent();
		}
		
		return new BookLangueage(originalName, language, translator);
	}
	private List<Isbn> constructIsbns(Node book){
		List<Isbn> isbns = new ArrayList<MyDomTransformer.Isbn>();
		
		Node firstIsbn = getChildElement(ISBN, book);
		String code = firstIsbn.getTextContent();
		String commentary = "";
		if(firstIsbn.hasAttributes()){
			commentary = firstIsbn.getAttributes().item(0).getTextContent();
		}
		isbns.add(new Isbn(code, commentary));
		
		Node otherIsbns = getSiblingElement(OTHER_EDITIONS, firstIsbn);
		if(otherIsbns != null){
			
			for(Node nextIsbn = getChildElement(ISBN, otherIsbns);
				nextIsbn != null; nextIsbn = getSiblingElement(ISBN, nextIsbn)){
				
				code = nextIsbn.getTextContent();
				commentary = "";
				if(nextIsbn.hasAttributes()){
					commentary = nextIsbn.getAttributes().item(0).getTextContent();
				}
				isbns.add(new Isbn(code, commentary));
			}
		}
		return isbns;
	}
	private List<String> constructCategories(Node book){
		List<String> categories = new ArrayList<String>();		
		
		for(Node category = getChildElement(CATEGORY, book);
			category != null; category = getSiblingElement(CATEGORY, category)){
			categories.add(category.getTextContent());
		}
		
		return categories;
	}
	private List<Location> constructLocations(Node book){
		List<Location> locations = new ArrayList<MyDomTransformer.Location>();
		
		for(Node loc = getChildElement(LOCATION_IN_LIB, book).getFirstChild();
			loc != null; loc = loc.getNextSibling()){
			if(loc.getNodeName().equals(PRESENT)){
				
				String row = loc.getAttributes().item(0).getTextContent();
				String line = loc.getAttributes().item(1).getTextContent();
				
				locations.add(new Present(row, line));
			} else if(loc.getNodeName().equals(DEPOSITARY)){
				
				String row = loc.getAttributes().item(0).getTextContent();
				String line = loc.getAttributes().item(1).getTextContent();
				
				locations.add(new Depositary(row, line));
			} else if(loc.getNodeName().equals(BORROWED)){
				
				String day = loc.getAttributes().item(0).getTextContent();
				String month = loc.getAttributes().item(1).getTextContent();
				String year = loc.getAttributes().item(2).getTextContent();
				
				locations.add(new Borrowed(day, month, year));
			}
			/*
			 * else {
			 * 	continue;
			 * }
			 */
		}
		
		return locations;
	}
	
	//funkce pro ziskavani spravnych elementu z DOM struktury############################
	
	private Node getChildElement(String elementName, Node parent){
		for(Node node = parent.getFirstChild(); node != null; node = node.getNextSibling()){
			if(node.getNodeName().equals(elementName)){
				return node;
			}
		}
		
		return null;
	}
	private Node getSiblingElement(String elementName, Node sibling){
		for(Node node = sibling.getNextSibling(); node != null;
			node = node.getNextSibling()){
			
			if(node.getNodeName().equals(elementName)){
				return node;
			}
		}
		
		return null;
	}
	
	//tridy pro uchovavani dat v pameti##################################################
	
	class Publisher{
		private String name;
		private Address address;
		private List<Phone> phones;
		
		public Publisher(String name, Address address, List<Phone> phones){
			this.name = name;
			this.address = address;
			this.phones = phones;
		}
		
		public String getName(){
			return name;
		}
		public Address getAddress(){
			return address;
		}
		public List<Phone> getPhones(){
			return phones;
		}
	}
	class Printer{
		private String name;
		private Address address;
		
		public Printer(String name, Address address){
			this.name = name;
			this.address = address;
		}
		public String getName(){
			return name;
		}
		public Address getAddress(){
			return address;
		}
	}
	class Phone{
		private String number;
		private String commentary;
		
		public Phone(String number, String commentary){
			this.number = number;
			this.commentary = commentary;
		}
		
		public String getNumber(){
			return number;
		}
		public String getCommentary(){
			return commentary;
		}
	}
	class Address{
		private String street;
		private String number;
		private String city;
		private String postalCode;
		private String state;
		
		public Address(String street, String number, String city,
				String postalCode, String state){
			
			this.street = street;
			this.number = number;
			this.city = city;
			this.postalCode = postalCode;
			this.state = state;
		}
		public String getStreet(){
			return street;
		}
		public String getNumber(){
			return number;
		}
		public String getCity(){
			return city;
		}
		public String getPostalCode(){
			return postalCode;
		}
		public String getState(){
			return state;
		}
	}
	class Book{
		private String name;
		private List<String> authors;
		private BookLangueage bLang;
		private List<Isbn> isbns;
		private List<String> categories;
		private String commentary;
		private String printsInLib;
		private List<Location> locations;
		
		public Book(String name, List<String> authors, BookLangueage bLang,
				List<Isbn> isbns, List<String> categories,
				String printsInLib, List<Location> locations,
				String commentary){
			
			this.name = name;
			this.authors = authors;
			this.bLang = bLang;
			this.isbns = isbns;
			this.categories = categories;
			this.commentary = commentary;
			this.printsInLib = printsInLib;
			this.locations = locations;
		}
		public String getName(){
			return name;
		}
		public List<String> getAuthors(){
			return authors;
		}
		public BookLangueage getBLang(){
			return bLang;
		}
		public List<Isbn> getIsbns(){
			return isbns;
		}
		public List<String> getCategories(){
			return categories;
		}
		public String getCommentary(){
			return commentary;
		}
		public String getPrintsInLib(){
			return printsInLib;
		}
		public List<Location> getLocations(){
			return locations;
		}
		
	}
	class BookLangueage{
		private String originalName;
		private String language;
		private String translator;
		
		public BookLangueage(String originalName,
				String language, String translator){
			
			this.originalName = originalName;
			this.language = language;
			this.translator = translator;
		}
		public String getLanguage(){
			return language;
		}
		public String getTranslator(){
			return translator;
		}
		public String getOriginalName(){
			return originalName;
		}
	}
	interface Location{}
	class Depositary implements Location{
		private String row;
		private String line;
		
		public Depositary(String row, String line){
			this.row = row;
			this.line = line;
		}
		public String getRow(){
			return row;
		}
		public String getLine(){
			return line;
		}
	}
	class Present implements Location{
		private String row;
		private String line;
		
		public Present(String row, String line){
			this.row = row;
			this.line = line;
		}
		public String getRow(){
			return row;
		}
		public String getLine(){
			return line;
		}
	}
	class Borrowed implements Location{
		private String day;
		private String month;
		private String year;
		
		public Borrowed(String day, String month, String year){
			this.day = day;
			this.month = month;
			this.year = year;
		}
		public String getDay(){
			return day;
		}
		public String getMont(){
			return month;
		}
		public String getYear(){
			return year;
		}
	}
	class Isbn{
		private String code;
		private String commentary;
		
		public Isbn(String code, String commentary){
			this.code = code;
			this.commentary = commentary;
		}
		public String getCommentary(){
			return commentary;
		}
		public String getCode(){
			return code;
		}
	}
	
}
