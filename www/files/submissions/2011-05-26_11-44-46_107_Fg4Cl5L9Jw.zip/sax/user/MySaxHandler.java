package user;

import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;


public class MySaxHandler extends DefaultHandler {
 
	// Umo��uje zac�lit m�sto v dokumentu, kde vznikla aktualn� ud�lost
    Locator locator;
    
    int aktualniHloubka;
    int celkovaHloubka;
    int pocetElementu;
    int maximalniHloubka;
    
    int celkovaDelkaNazvu;
    int delkaNejdelsihoNazvu;
    String nejdelsiNazev;
    
    int pocetAtributu;
    int maximalniPocetAtributu;
    
    /**
     * Nastav� locator
     */     
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Obsluha ud�losti "za��tek dokumentu"
     */   
    @Override
    public void startDocument() throws SAXException {
        
       aktualniHloubka = 0;
       celkovaHloubka = 0;
       pocetElementu = 0;
       maximalniHloubka = 0;
       
       celkovaDelkaNazvu = 0;
       delkaNejdelsihoNazvu = 0;
       
       pocetAtributu = 0;
       maximalniPocetAtributu = 0;
        
    }
    /**
     * Obsluha ud�losti "konec dokumentu"
     */     
    @Override
    public void endDocument() throws SAXException {

    	double prumernaHloubka = -1;
    	double prumernaDelkaNazvu = -1; 
    	double prumerneAtributu =  -1; 
    	
    	if(pocetElementu > 0) {
    		
    		prumernaHloubka = (double)celkovaHloubka / (double)pocetElementu;
    		prumernaDelkaNazvu = (double)celkovaDelkaNazvu / (double)pocetElementu;
    		prumerneAtributu = (double)pocetAtributu / (double)pocetElementu;
    	}
    	
    	System.out.println("PocetElementu: " + pocetElementu);
    	System.out.println("CelkovaHloubka: " + celkovaHloubka);
    	System.out.println("Prumerna hloubka: " + prumernaHloubka);
    	System.out.println("Maximalni hloubka: " + maximalniHloubka);
    	System.out.println("Prumerna delka nazvu: " + prumernaDelkaNazvu);
    	System.out.println("Nejdelsi nazev: " + nejdelsiNazev);
    	System.out.println("Prumerny pocet atributu: " + prumerneAtributu);
    	System.out.println("Pocet atributu: " + pocetAtributu);
    	System.out.println("Maximalni pocet atributu: " + maximalniPocetAtributu);
    	
    	
        
    }
    
    /**
     * Obsluha ud�losti "za��tek elementu".
     * @param uri URI jmenn�ho prostoru elementu (pr�zdn�, pokud element nen� v ��dn�m jmenn�m prostoru)
     * @param localName Lok�ln� jm�no elementu (v�dy nepr�zdn�)
     * @param qName Kvalifikovan� jm�no (tj. prefix-uri + ':' + localName, pokud je element v n�jak�m jmenn�m prostoru, nebo localName, pokud element nen� v ��dn�m jmenn�m prostoru)
     * @param atts Atributy elementu     
     */     
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

    	aktualniHloubka++;
    	pocetElementu++;
    	
    	if(aktualniHloubka > maximalniHloubka)
    		maximalniHloubka = aktualniHloubka;
    	
    	celkovaHloubka += aktualniHloubka;
    	
    	celkovaDelkaNazvu += localName.length();
    	if(localName.length() > delkaNejdelsihoNazvu)
    	{
    		delkaNejdelsihoNazvu = localName.length();
    		nejdelsiNazev = localName;
    	}
    	
    	if(atts.getLength() > maximalniPocetAtributu)
    		maximalniPocetAtributu = atts.getLength();
    	
    	pocetAtributu += atts.getLength();
    	
    	

    }
    /**
     * Obsluha ud�losti "konec elementu"
     * Parametry maj� stejn� v�znam jako u @see startElement     
     */     
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {

        aktualniHloubka--;

    }
    
    /**
     * Obsluha ud�losti "znakov� data".
     * SAX parser mu�e znakov� data d�vkovat jak chce. Nelze tedy po��tat s t�m, �e je cel� text dorucen v r�mci jednoho vol�n�.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakov�mi daty
     * @param start Index zac�tku �seku platn�ch znakov�ch dat v poli.
     * @param length D�lka �seku platn�ch znakov�ch dat v poli.
     */      
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {

        // ...
        
    }
    
    /**
     * Obsluha ud�losti "deklarace jmenn�ho prostoru".
     * @param prefix Prefix prirazen� jmenn�mu prostoru.
     * @param uri URI jmenn�ho prostoru.
     */     
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha ud�losti "konec platnosti deklarace jmenn�ho prostoru".
     */     
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
    
        // ...
    
    }

    /**
     * Obsluha ud�losti "ignorovan� b�l� znaky".
     * Stejn� chov�n� a parametry jako @see characters     
     */     
    @Override
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha ud�losti "instrukce pro zpracov�n�".
     */      
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
      
      // ...
            
    }

    /**
     * Obsluha ud�losti "nezpracovan� entita"
     */   
    @Override
    public void skippedEntity(String name) throws SAXException {
    
      // ...
    
    }
	
	
}