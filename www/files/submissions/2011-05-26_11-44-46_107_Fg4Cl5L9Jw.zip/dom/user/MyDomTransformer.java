package user;

import org.w3c.dom.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


public class MyDomTransformer {
	
	public void transform (Document xmlDocument) {
    
		Document doc = xmlDocument;
		
		NodeList hristeNodeList = doc.getElementsByTagName("Hriste");
		
		List<Element> hristeList = new ArrayList<Element>();
		
		while(hristeNodeList.getLength() > 0)
		{
			Node n = hristeNodeList.item(0);
			n.getParentNode().removeChild(n);
			Element h = (Element) n;
			
			transformHriste(h, doc);
			
			hristeList.add(h);
			
			
		}
		
		////////////// Setrideni seznamu hrist lexikograficky podle id
		Collections.sort(hristeList, new HristeComparator());
		
		// Napushovani hrist zpatky
		Element seznamHrist = (Element)doc.getElementsByTagName("SeznamHrist").item(0);
		for( Element h : hristeList)
		{
			seznamHrist.appendChild(h);
		}
		
		//////// Prevod elementu Hodnoceni na atributy
		NodeList listHodnoceni = doc.getElementsByTagName("Hodnoceni");
		
		while(listHodnoceni.getLength() > 0) {
			Element hodnoceni = (Element)listHodnoceni.item(0);
			resolveHodnoceni(hodnoceni, doc);
		}
		
		
  }
	
	/**
	 * Transformuje Element hriste - smaze atributy nazev a kapacita.
	 * Vytvori elementy nazev a kapacita s odpovidajicim obsahem a pripoji
	 * je jako prvni potomky elementu hriste
	 * @param hriste transformovany element
	 * @param doc dokument ke kteremu element nalezi
	 */
  private void transformHriste(Element hriste, Document doc) {
	  String nazevVal = hriste.getAttribute("nazev");
	  String kapacitaVal = hriste.getAttribute("kapacita");
	  
	  hriste.removeAttribute("nazev");
	  hriste.removeAttribute("kapacita");
	  
	  Element nazev = doc.createElement("Nazev");
	  nazev.setTextContent(nazevVal);
	  
	  Element kapacita = doc.createElement("Kapacita");
	  kapacita.setTextContent(kapacitaVal);
	  
	  hriste.insertBefore(kapacita, hriste.getFirstChild());
	  hriste.insertBefore(nazev, kapacita);
	  
  }

  /**
   * Prevede element hodnoceni na atribut nadrazeneho elementu
   * @param h element Hodnoceni
   * @param doc dokument, do nehoz element nalezi
   */
  private void resolveHodnoceni(Element h, Document doc) {
	  
	  Element parent =  (Element)h.getParentNode();
	  
	  String hodnoceniVal = h.getTextContent();
	  
	  parent.removeChild(h);
	  
	  parent.setAttribute("hodnoceni", hodnoceniVal);
  }
  
  /**
   * Comparator porovavani hrist podle atributu id
   * @author VFiklik
   *
   */
  class HristeComparator implements Comparator<Element> {

	public int compare(Element h1, Element h2) {
		
		String h1Id = h1.getAttribute("id");
		String h2Id = h2.getAttribute("id");
		
		return h1Id.compareToIgnoreCase(h2Id);
	}

  }
}