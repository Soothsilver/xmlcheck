package user;

import java.util.*;

import org.xml.sax.*;
import org.xml.sax.helpers.*;

/**
 * Lists top 25 text elements by length and computes min/med/max text length
 * 
 * @author Matej Snoha
 */
public class MySaxHandler extends DefaultHandler {

	static StringBuilder textContent = new StringBuilder();;

	static Map<String, Integer> textElementLength = new HashMap<String, Integer>();

	/**
	 * Sorts Map by value
	 * */
	public static <K, V extends Comparable<V>> List<K> sortByValue(final Map<K, V> m) {
		List<K> keys = new ArrayList<K>();
		keys.addAll(m.keySet());
		Collections.sort(keys, new Comparator<K>() {
			public int compare(K k1, K k2) {
				V v1 = m.get(k1);
				V v2 = m.get(k2);
				if (v1 == null) {
					return (v2 == null) ? 0 : 1;
				} else if (v1 instanceof Comparable) {
					return (v1).compareTo(v2);
				} else {
					return 0;
				}
			}
		});
		return keys;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.xml.sax.helpers.DefaultHandler#startElement(java.lang.String,
	 * java.lang.String, java.lang.String, org.xml.sax.Attributes)
	 */
	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		super.startElement(uri, localName, qName, attributes);
		// textContent = new StringBuilder();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.xml.sax.helpers.DefaultHandler#endElement(java.lang.String,
	 * java.lang.String, java.lang.String)
	 */
	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		super.endElement(uri, localName, qName);

		String textContentTrimmed = textContent.toString().trim();
		int length = textContentTrimmed.length();

		if (length > 0) {
			// System.out.println("Element\t\"" + textContentTrimmed +
			// "\"\n\twith length " + length + "\n");
			textElementLength.put(textContentTrimmed, length);
		}
		textContent = new StringBuilder();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.xml.sax.helpers.DefaultHandler#characters(char[], int, int)
	 */
	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		super.characters(ch, start, length);

		for (int i = start; i < start + length; i++)
			textContent.append(ch[i]);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.xml.sax.helpers.DefaultHandler#endDocument()
	 */
	@Override
	public void endDocument() throws SAXException {
		super.endDocument();

		List<String> textElementLengthSorted = sortByValue(textElementLength);

		System.out.println("Top 25 text elements by length:\n");

		try {
			for (int i = textElementLengthSorted.size() - 1; i > textElementLengthSorted.size() - 26; i--) {
				String key = textElementLengthSorted.get(i);
				System.out.println("\"" + key + "\" (length " + key.length() + ")");
			}

			System.out.println("\nMaximum length: "
					+ textElementLengthSorted.get(textElementLengthSorted.size() - 1).length() + " (i.e. \""
					+ textElementLengthSorted.get(textElementLengthSorted.size() - 1) + "\")");

			System.out.println("Median length: "
					+ textElementLengthSorted.get(textElementLengthSorted.size() / 2).length() + " (i.e. \""
					+ textElementLengthSorted.get(textElementLengthSorted.size() / 2) + "\")");

			System.out.println("Minimum length: " + textElementLengthSorted.get(0).length() + " (i.e. \""
					+ textElementLengthSorted.get(0) + "\")");

		} catch (IndexOutOfBoundsException unused) {
		}

	}

}
