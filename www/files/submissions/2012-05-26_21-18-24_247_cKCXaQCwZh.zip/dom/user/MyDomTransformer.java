package user;

import org.w3c.dom.*;

/**
 * Zmaze z databazy vsetkych ludi s emailami na spam.ru . Vsetky atributy s
 * nazvami <i>jazyk, zanry, stav</i> zmeni na elementy
 * 
 * @author Matej Snoha
 */
public class MyDomTransformer {

	static Document doc;

	public static void transform(Document xmlDocument) {

		doc = xmlDocument;

		NodeList childNodes = xmlDocument.getChildNodes();

		for (int i = 0; i < childNodes.getLength(); i++) {
			procesNode(childNodes.item(i));
		}

		xmlDocument = doc;

	}

	private static void procesNode(Node node) {

		NodeList childNodes = node.getChildNodes();

		// odstranit ludi s mailom na @spam.ru
		if (node.getNodeName() == "ctenar") {
			for (int i = 0; i < childNodes.getLength(); i++) {
				if (childNodes.item(i).getNodeName() == "email") {
					if (childNodes.item(i).getTextContent().contains("@spam.ru")) {
						node.getParentNode().removeChild(node);
					}
					return;
				}
			}
		}

		// atributy jazyk / zanry / stav previest na elementy
		NamedNodeMap attributes = node.getAttributes();
		Node jazykItem = null;
		Node zanryItem = null;
		Node stavItem = null;
		if (attributes != null) {
			jazykItem = attributes.getNamedItem("jazyk");
			zanryItem = attributes.getNamedItem("zanry");
			stavItem = attributes.getNamedItem("stav");
		}

		if (jazykItem != null) {
			((Element) node).removeAttribute("jazyk");
			Element jazyk = doc.createElement("jazyk");
			jazyk.appendChild(doc.createTextNode(jazykItem.getNodeValue()));
			node.appendChild(jazyk);
		}

		if (zanryItem != null) {
			((Element) node).removeAttribute("zanry");
			Element zanry = doc.createElement("zanry");
			zanry.appendChild(doc.createTextNode(zanryItem.getNodeValue()));
			node.appendChild(zanry);
		}

		if (stavItem != null) {
			((Element) node).removeAttribute("stav");
			Element stav = doc.createElement("stav");
			stav.appendChild(doc.createTextNode(stavItem.getNodeValue()));
			node.appendChild(stav);
		}

		// spracovat podelementy
		for (int i = 0; i < childNodes.getLength(); i++) {
			procesNode(childNodes.item(i));
		}

	}
}
