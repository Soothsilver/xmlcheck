package user;

import java.util.ArrayList;
import java.util.List;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

//DOM transformer bude transformovat datumy
public class MyDomTransformer 
{
    //ziskame vsetky datumy a casy a zavolame na ne prislusne transformacie
    public void transform(Document xmlDoc) 
    {
        NodeList dates = xmlDoc.getElementsByTagName("date");
        
        for (int i = 0; i < dates.getLength(); i++) 
        {
            AlterDate(dates.item(i));
        }      
        
        NodeList times = xmlDoc.getElementsByTagName("time");
        
        for (int i = 0; i < dates.getLength(); i++) 
        {
            AlterTime(times.item(i));
        }                    
    }
    
    private void AlterDate(Node date)
    {
        NodeList childs = date.getChildNodes();
        
        String den="";
        String mesiac="";
        String rok="";
        
        for (int i = 0; i < childs.getLength(); i++) 
        {
            if(childs.item(i).getNodeName() == "day")
            {
                den = childs.item(i).getTextContent();
            }
            if(childs.item(i).getNodeName() == "month")
            {
                mesiac = childs.item(i).getTextContent();
            }
            if(childs.item(i).getNodeName() == "year")
            {
                rok = childs.item(i).getTextContent();
            }
        } 

        //format datumu bude dd.mm.rr
        String newDate = den + "." + mesiac + "." + rok;

        ((Element)date).setAttribute("date", newDate);
        
        while(date.hasChildNodes())
        {
            date.removeChild(date.getFirstChild());
        }
    }
    
    private void AlterTime(Node time)
    {
        NodeList childs = time.getChildNodes();
        
        String hodina="";
        String minuta="";
        String sekunda="";
        
        for (int i = 0; i < childs.getLength(); i++) 
        {
            if(childs.item(i).getNodeName() == "hours")
            {
                hodina = childs.item(i).getTextContent();
            }
            if(childs.item(i).getNodeName() == "minutes")
            {
                minuta = childs.item(i).getTextContent();
            }
            if(childs.item(i).getNodeName() == "seconds")
            {
                sekunda = childs.item(i).getTextContent();
            }
        }

        // cas ve format hh:mm:ss
        String newTime = hodina + ":" + minuta + ":" + sekunda;
        
        ((Element)time).setAttribute("time", newTime);
        
        while(time.hasChildNodes())
        {
            time.removeChild(time.getFirstChild());
        }  
    }
}