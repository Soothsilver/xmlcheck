package user;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

/**
 * ASSIGNMENT: Update document to be able to transform input XML document to
 * output document by actions mentioned in comments of processTree method.
 */
public class MyDomTransformer {

    private static void processTree(Document doc) {
        addProdukt(doc);
        delete(doc);
    }
    
    public void transform (Document xmlDocument) {
        processTree(xmlDocument);
    }
    
    //prida novy produkt
    private static void addProdukt(Document doc) {
        Element produkty = (Element)doc.getElementsByTagName("produkty").item(0);
        Element produkt = doc.createElement("produkt");
        produkt.setAttribute("id", "evo3d");
        produkt.appendChild(doc.createElement("nazev")).setTextContent("Mobilni telefon HTC EVO 3D");
        produkt.appendChild(doc.createElement("mnozstvi")).setTextContent("1");
        produkt.appendChild(doc.createElement("cena_ks")).setTextContent("999");
        produkty.appendChild(produkt);
    }
    
    //smaze produkty drazsi nez 1000
    private static void delete(Document doc) {
        int a = 0;
        NodeList produkty = doc.getElementsByTagName("produkt");
        for(int i = 0; i < produkty.getLength(); i++) {
            NodeList elementyProduktu = produkty.item(i).getChildNodes();
            for(int j = 0; j < elementyProduktu.getLength(); j++) {
                if(elementyProduktu.item(j).getNodeName().equals("cena_ks")) {
                    if(Integer.parseInt(elementyProduktu.item(j).getTextContent()) > 1000) {
                        produkty.item(i).getParentNode().removeChild(produkty.item(i));
                        i--;
                    }
                }
            }
        }
    }
}
