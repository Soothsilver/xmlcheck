/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * tranformacia odstrani vsetky vyrobky ktore podla atributu "naskalde "uz nie su na sklade
 * a prida novy vyrobok s kompletnou strukturou a udajmi
 * @author Michal Hanzeli
 */
public class MyDomTransformer {
    
    public static void transform (Document xmlDocument){
        
        Element elpredajna= xmlDocument.getDocumentElement();
        delete(elpredajna);
        String[] text = new String[10];
        text[0] = "Staropramen tmavy";
        text[1] = "Pivovary Staropramen a.s, Praha";
        text[2] = "CZ";
        text[3] = "0,5l";
        text[4] = "4%";
        text[5] = "10,90";
        text[6] = "25";
        text[7] = "10";
        text[8] = "15";       
        text[9] = "tmavé, láhev";               
        add(xmlDocument,text);
        
    }

    public static void delete(Node node){
        NodeList list = node.getChildNodes();
        for (int i=0; i<list.getLength(); i++){
            Node listNode = list.item(i);
            if (listNode instanceof Element){
                
                    if(listNode.getNodeName().equals("vyrobok")){
                        Element el = (Element) listNode;
                        if(el.getAttribute("skladom").equals("nie")){
                            node.removeChild(listNode);
                        }
                    }
                delete(listNode);
            }
        }
        
        
    }
    public static void add(Document xmlDocument,String[] text){
        xmlDocument.getDocumentElement().normalize();
        NodeList list = xmlDocument.getElementsByTagName("vyrobok");
        Element last = (Element) list.item(list.getLength()-1);
        String value = last.getAttribute("vid");
        int i = Integer.parseInt(value.substring(3));
        NodeList insertList = xmlDocument.getElementsByTagName("tovar");
        Element tovar = (Element) insertList.item(0);
        Element newVyrobok = xmlDocument.createElement("vyrobok");
        newVyrobok.setAttribute("vid", "alk" + ++i);
        newVyrobok.setAttribute("skladom", "ano");
            Element newNazov = xmlDocument.createElement("nazov");
            newNazov.setTextContent(text[0]);
            newVyrobok.appendChild(newNazov);
            
            Element newVyrobca = xmlDocument.createElement("vyrobca");
            newVyrobca.setTextContent(text[1]);
                Element newStat = xmlDocument.createElement("stat");
                newStat.setTextContent(text[2]);
                newVyrobca.appendChild(newStat);
                
            newVyrobok.appendChild(newVyrobca);
            
            Element newObjem = xmlDocument.createElement("objem");
            newObjem.setTextContent(text[3]);
            newVyrobok.appendChild(newObjem);
            
            Element newObj_alk = xmlDocument.createElement("obj_alk");
            newObj_alk.setTextContent(text[4]);
            newVyrobok.appendChild(newObj_alk);
            
            Element newCena = xmlDocument.createElement("cena");
            newCena.setTextContent(text[5]);
            newVyrobok.appendChild(newCena);
            
            Element newStatis = xmlDocument.createElement("statistika");
                Element newSklad = xmlDocument.createElement("sklad");
                    Element newZac = xmlDocument.createElement("zaciatok");
                    newZac.setTextContent(text[6]);
                    newSklad.appendChild(newZac);
                    
                    Element newKon = xmlDocument.createElement("koniec");
                    newKon.setTextContent(text[7]);
                    newSklad.appendChild(newKon);
                newStatis.appendChild(newSklad);
                
                Element newPredane = xmlDocument.createElement("predane");
                newPredane.setTextContent(text[8]);
                newSklad.appendChild(newPredane);
            newVyrobok.appendChild(newStatis);
            
            Element newPozn = xmlDocument.createElement("poznamka");
            newPozn.setTextContent(text[9]);
            newVyrobok.appendChild(newPozn);
        tovar.appendChild(newVyrobok);
    }
}
