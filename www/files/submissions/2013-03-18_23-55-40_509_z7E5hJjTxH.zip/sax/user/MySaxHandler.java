/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Handler ktory zisti pocet typov vyrobkov ktore su na sklade podla atributu "nasklade",
 * dalej spocita pocet predanych kusov tovaru podla obsahu elementu "predane".
 * Spocita cenu za jednotlive nakupy a vypise oznacenia tych dokladov ktorych suma presahuje 1000 korun
 * @author Michal Hanzeli
 */
public class MySaxHandler extends DefaultHandler{
        
        Locator locator;
        private int cntVyrobky;
        private int cntPredane;
        private double[] array = new double[20];
        private boolean elemPredane;
        private boolean elemCena;
        private boolean elemKs; 
        private String doklad;
        private int numAtt;
        private int numPoloz;
        private double cenaDoklad;
        
        
        @Override
        public void setDocumentLocator(Locator locator) {
            this.locator=locator;
        }


        @Override
        public void endDocument() throws SAXException {
            System.out.println(cntVyrobky); //vypis poctu vyrobkov
            System.out.println(cntPredane); //vypis poctu predanych kusov
        }


        @Override
        public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
            cntPredane++;
            switch (localName) {
                case "vyrobok":
                    numAtt = Integer.parseInt(atts.getValue("vid").substring(3));
                    if(atts.getValue("skladom").equals("ano")){
                        cntVyrobky++;
                    }
                break;
                case "predane":
                    elemPredane=true;
                break;
                case "cena":
                    elemCena=true;
                break;
                case "doklad":
                    doklad=atts.getValue("did");
                break;
                case "polozka":
                    //poznacim si cislo aktualnej polozky v doklade
                    numPoloz=Integer.parseInt(atts.getValue("vid_ref").substring(3));
                break;
                case "ks":
                    elemKs=true;
                    break;
                    
            }
        }

        @Override
        public void endElement(String uri, String localName, String qName) throws SAXException {
        switch (localName) {
            case "predane":
                elemPredane=false;
                break;
            case "cena":
                elemCena=false;
                break;
            case "ks":
                elemKs=false;
                break;
            case "doklad":
                if(cenaDoklad>1000){
                    System.out.println(doklad); //vypis sumy pre dany doklad
                    cenaDoklad=0;
                }
        }
                
        }

        @Override
        public void characters(char[] ch, int start, int length) throws SAXException {
            String str="";
            if(elemPredane){
                //spocitanie predanych kusov
                for(int i = start; i<start + length;i++){
                    str+=ch[i];
                }
                cntPredane+=Integer.parseInt(str);
            }
            else if (elemCena){
                //do pola array si poznacim cenu daneho vyrobku
                for(int i = start; i<start + length;i++){
                    str+=ch[i];
                }
                array[numAtt]=Double.parseDouble(str);
            }
            else if (elemKs){
                //pripocitanie sumy ya nakupene polozky k cene pre dany doklad
                for(int i = start; i<start + length;i++){
                    str+=ch[i];
                }
                cenaDoklad+=array[numPoloz]*Integer.parseInt(str);
            }
        }
        
    
}
