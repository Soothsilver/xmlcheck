package sax.user;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 * Main class for SAX parsing
 *
 * @author XML Technologies
 */
public class MySaxHandler {

    // Path to input file
    private static final String INPUT_FILE = "data.xml";

    /**
     * Main method
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {



        try {

            // Create parser instance
            XMLReader parser = XMLReaderFactory.createXMLReader();

            // Create input stream from source XML document
            InputSource source = new InputSource(INPUT_FILE);

            // Set our custom content handler for handling SAX events (it must implements ContentHandler interface)
            parser.setContentHandler(new CustomContentHandler());

            // Process input data
            parser.parse(source);

        } catch (Exception e) {

            e.printStackTrace();

        }

    }
}

/**
 * Out custom content handler for managing SAX events Implements methods of the
 * abstract class ContentHandler.
 * @see http://www.saxproject.org/apidoc/org/xml/sax/ContentHandler.html#processingInstruction%28java.lang.String,%20java.lang.String%29
 */
class CustomContentHandler implements ContentHandler {

    // Helper variable to store location of the handled event
    Locator locator;
    enum state { VENKU, ZAKOS, AP, ZAKPLA, ZAKMAIL, APZARI, APZARISW };
    state s;
    HashMap<String, List<Integer>> platby;
    HashMap<String, Integer> maily_v_tld;
    int wokynka = 0;

    // aktualni stav, kde sem
    String zak, ap;

    /**
     * Sets the locator
     *
     * @param Locator locator location in the file
     */
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Method to handle "document start"
     *
     * @throws SAXException
     */
    @Override
    public void startDocument() throws SAXException {
        // ...
	s = state.VENKU;
	platby = new HashMap<String, List<Integer>>();
	maily_v_tld = new HashMap<String, Integer>();
    }

    /**
     * Method to handle "document end"
     *
     * Na konci dokumentu se vyprintfa, co se z nej spocitalo.
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
    	System.out.println("HODNOTY ATRIBUTU: Jaka je prumerna velikost jedne zakaznikovy platby?");
	for (String z: platby.keySet()) {
		Integer avg = 0;
		List<Integer> l = platby.get(z);
		for (Integer i: l)
			avg += i;

	 	if (l.size() > 0)
			avg/=l.size();

		System.out.printf("zakaznik %s plati prumerne %d kc\n", z, avg);
	}
    	System.out.println("OBSAH ELEMENTU: Pod jakym TLD maji zakaznici kolik mailu?");
	for (String tld: maily_v_tld.keySet()) {
		System.out.printf("v TLD %s ma %d zakazniku sve maily\n", tld, maily_v_tld.get(tld));
	}
	System.out.printf("KONTEXT ZARIZENI V PRISTUPOVEM BODE: Windows ma celkem %d zarizeni na pristupovych bodech.\n", wokynka);
    }

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
    	int i;
	switch (s) {
	case VENKU:
		if (localName == "zakaznik") {
			List<Integer> l = new ArrayList<Integer>();
			s = state.ZAKOS;
			for (i = 0; i < atts.getLength(); ++i) {
				if (atts.getQName(i) != "id")
					continue;
				zak = atts.getValue(i);
				break;
			}
			platby.put(zak, l);
		}
		else if (localName == "pristupovy_bod") {
			s = state.AP;
			for (i = 0; i < atts.getLength(); ++i) {
				if (atts.getQName(i) != "id")
					continue;
				ap = atts.getValue(i);
			}
			//platby.add(zak, new List<Integer>());
		}
		else return;
		break;
	case AP:
		if (localName == "zarizeni") {
			s = state.APZARI;
		}
		break;
	case APZARI:
		String system = "";
		if (localName == "software") {
			s = state.APZARISW;
			for (i = 0; i < atts.getLength(); ++i) {
				if (atts.getQName(i) != "nazev")
					continue;
				system = atts.getValue(i);
				break;
			}
			if (system.equals("Windows"))
				wokynka++;
		}
		break;
	case ZAKOS:
		if (localName == "platba") {
			s = state.ZAKPLA;
			for (i = 0; i < atts.getLength(); ++i) {
				if (atts.getQName(i) != "castka")
					continue;
				platby.get(zak).add(Integer.parseInt(atts.getValue(i)));
				break;
			}
		}
		else if (localName == "ekontakt") {
			// kontaktu muze byt vic druhu, nas zajima jen mail
			String typ = "email";
			
			for (i = 0; i < atts.getLength(); ++i) {
				if (atts.getQName(i) == "typ")
					typ = atts.getValue(i);
			}
			if (! typ.equals("email"))
				return;
			s = state.ZAKMAIL;
		}
		break;
	}
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        switch (s) {
	case ZAKOS:
		if (localName == "zakaznik") {
			s = state.VENKU;
			zak = "";
		}
		break;
	case AP:
		if (localName == "pristupovy_bod") {
			s = state.VENKU;
			ap = "";
		}
		break;
	case APZARI:
		if (localName == "zarizeni") {
			s = state.AP;
		}
		break;
	case APZARISW:
		if (localName == "software") {
			s = state.APZARI;
		}
		break;
	case ZAKPLA:
		if (localName == "platba") {
			s = state.ZAKOS;
		}
		break;
	case ZAKMAIL:
		if (localName == "ekontakt") {
			s = state.ZAKOS;
		}
	}	
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
	int i, lim;
	String str = "";
        switch (s) {
	case ZAKMAIL:
		lim = start + length;
		for (i = start; i < lim ; ++i)
			str += chars[i];

		String[] spl = str.split("\\.");
		String tld = spl[spl.length - 1];

		if (maily_v_tld.containsKey(tld)) {
			Integer n = maily_v_tld.get(tld) + 1;
			maily_v_tld.remove(tld);
			maily_v_tld.put(tld, n);
		}
		else
			maily_v_tld.put(tld, 1);

		s = state.ZAKOS;
		break;
	}
    }

    /**
     * Method to handle " start of namespace declaration"
     *
     * @param prefix Prefix of the namespace
     * @param uri URI of the namespace
     * @throws SAXException
     */
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    /**
     * Method to handle "end of namespace declaration"
     *
     * @param prefix
     * @throws SAXException
     */
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    /**
     * Method to handle "ignoring of whitespaces" Text is in array 'chars' from
     * position ('start') to ('start' + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     * @throws SAXException
     */
    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
        // ...
    }

    /**
     * Method to handle "processing instructions"
     *
     * @param target The processing instruction target
     * @param data  The processing instruction data
     * @throws SAXException
     */
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

    /**
     * Method to handle "unprocessed entity"
     *
     * @param name
     * @throws SAXException
     */
    @Override
    public void skippedEntity(String name) throws SAXException {
        // ...
    }
}
