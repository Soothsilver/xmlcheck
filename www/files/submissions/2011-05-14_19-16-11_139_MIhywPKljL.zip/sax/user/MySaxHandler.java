/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package user;

import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
/**
 *
 * @author Venda
 */
public class MySaxHandler extends DefaultHandler {

    int maxDepth;
    int curDepth;
    int sumDepth;
    int elemCount;

    @Override
    public void setDocumentLocator(Locator locator) {
        
    }

    @Override
    public void startDocument() throws SAXException {
        maxDepth = 0;
        curDepth = 0;
        sumDepth = 0;
        elemCount = 0;
    }

    @Override
    public void endDocument() throws SAXException {
        System.out.println("Max. depth: " + maxDepth);
        System.out.println("Avg. depth: " + (float)sumDepth/elemCount);
    }

    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        maxDepth = Math.max(++curDepth, maxDepth);
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        sumDepth += curDepth--;
        elemCount++;
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void skippedEntity(String name) throws SAXException {
        //throw new UnsupportedOperationException("Not supported yet.");
    }
    
}
