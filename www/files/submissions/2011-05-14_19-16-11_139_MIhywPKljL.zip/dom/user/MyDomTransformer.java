/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package user;

import org.w3c.dom.*;




/**
 *
 * @author Venda
 */
public class MyDomTransformer {
    private Node reverseElements(Node el) {
        NodeList childNodes = el.getChildNodes();
        Node cloneNode = el.cloneNode(false);

            for (int i = childNodes.getLength()-1; i >= 0; i--) {
                   cloneNode.appendChild(reverseElements(childNodes.item(i)));
            }
       // el=cloneNode;
        return cloneNode;
    }

    public void transform(Document xmlDocument) {
        Element root = xmlDocument.getDocumentElement();

       // xmlDocument.removeChild(root);
        Node r = reverseElements(root);
        xmlDocument.removeChild(root);
        xmlDocument.appendChild(r);
        //root.replaceChild(root.getLastChild(), r);
        //xmlDocument.getFirstChild();
        //xmlDocument.replaceChild(xmlDocument.getFirstChild(), reverseElements(root));
        //xmlDocument.replaceChild(root, reverseElements(root));
    }
}
