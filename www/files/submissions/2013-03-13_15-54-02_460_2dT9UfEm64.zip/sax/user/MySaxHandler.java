package user;

import java.util.HashMap;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 * The handler prints:
 * 1. for each packager how many packages he/she added
 * 2. the packager with the longest name
 * 3. author which the largest number of the packed programs
 *    (each package is one program (with some author) packed and added by some packager)
 *
 */
public class MySaxHandler extends DefaultHandler {
	
	private static void die(String msg) {
		System.err.println(msg);
		System.exit(-1);
	}

	public static void main(String[] args) {

		if (args.length != 1) {
			die("Bad arguments.\nThe program expects one argument which is a name of a file containing an xml document.");
		}

		try {
			
			// Create parser instance
			XMLReader parser = XMLReaderFactory.createXMLReader();

			// Create input stream from source XML document
			InputSource source = new InputSource(args[0]);

			// Set our custom content handler for handling SAX events (it must
			// implements ContentHandler interface)
			parser.setContentHandler(new MySaxHandler());

			// Process input data
			parser.parse(source);

		} catch (Exception e) {

			e.printStackTrace();

		}

	}
	
	private static class Packager {
		public String name = "";
		public int packageCount = 0;
	}
	
	// overridden methods of DefaultHandler

	// hash table of packagers: packager string id -> packager
	private HashMap<String, Packager> packagers = new HashMap<String, MySaxHandler.Packager>();
	
	// hash table storing number of packages for each author (packager is not an author)
	private HashMap<String, Integer> authorsCount = new HashMap<String, Integer>();
	
	@Override
	public void startDocument() {
		packagers.clear();
		authorsCount.clear();
		inAuthor = false;
	}
	
	@Override
	public void endDocument() {
		System.out.println("Number of packages added by each packager:");
		String longestName = "";
		for (Packager p : packagers.values()) {
			System.out.println(p.name + ": " + Integer.toString(p.packageCount));
			if (p.name.length() > longestName.length()) {
				longestName = p.name;
			}
		}
		System.out.println("Packager with the longest name: " + longestName);
		
		
		String bestAuthor = "";
		int bestAuthorsCount = Integer.MIN_VALUE;
		for (String name : authorsCount.keySet()) {
			int count = authorsCount.get(name);
			if (count > bestAuthorsCount) {
				bestAuthor = name;
				bestAuthorsCount = count;
			}
		}
		System.out.println("Author with the largest number of programs is: " + bestAuthor);
	}
	
	/**
	 * Adds packager if one with given id does not exist yet,
	 * returns existing packager otherwise.
	 * @param id Id of a packager, compulsory.
	 * @param name Name of a packager, may be null.
	 * @return Packager.
	 */
	private Packager addPackager(String id, String name) {
		assert(id != null);
		Packager packager = packagers.get(id);
		if (packager == null) {
			packager = new Packager();
			packagers.put(id, packager);
		}
		if (name != null) {
			packager.name = name;
		}
		return packager;
	}
	
	private void addAuthor(String name) {
		Integer count = authorsCount.get(name);
		if (count == null) {
			count = 0;
		}
		authorsCount.put(name, count + 1);
	}
	
	private boolean inAuthor = false;
	
	@Override
	public void startElement (String uri, String localName, String qName, Attributes atts) {
		if (localName.equals("packager")) {
			addPackager(atts.getValue("id"), atts.getValue("name"));
		} else if (localName.equals("package")) {
			addPackager(atts.getValue("packager"), null).packageCount++;
		} else if (localName.equals("author")) {
			inAuthor = true;
			authorBuilder.setLength(0);
		}
	}
	
	private StringBuilder authorBuilder = new StringBuilder();
	
	@Override
	public void endElement (String uri, String localName, String qName) {
		if (localName.equals("author") && inAuthor) {
			inAuthor = false;
			addAuthor(authorBuilder.toString());
			authorBuilder.setLength(0);
		}
	}
	
	@Override
	public void characters (char[] ch, int start, int length) {
		if (inAuthor) {
			authorBuilder.append(ch, start, length);
		}
	}

}