package user;

import org.w3c.dom.*;

import java.io.File;
import java.util.Calendar;
import java.util.HashMap;

import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class MyDomTransformer {
	
	private static void die(String msg) {
		System.err.println(msg);
		System.exit(-1);
	}
	
	public static void main(String[] args) {
		if (args.length != 2) {
			die("Bad arguments.\nFirst argument shall be the input file and the second the output file.");
		}
		
		try {

			// DocumentBuilderFactory creates DOM parsers
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

			// We don't want to validate file
			dbf.setValidating(false);

			// Creating of DOM parser instance
			DocumentBuilder builder = dbf.newDocumentBuilder();

			// Parser processes input file and creates a DOM tree of objects
			Document doc = builder.parse(args[0]);

			MyDomTransformer transformer = new MyDomTransformer();
			// DOM tree processing
			transformer.transform(doc);

			// TransformerFactory creates an object for DOM serialization
			TransformerFactory tf = TransformerFactory.newInstance();

			// Transformer serializes DOM tree
			Transformer writer = tf.newTransformer();

			// Setting of output file encoding
			writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

			// Run transformation of DOM tree to XML document
			writer.transform(new DOMSource(doc), new StreamResult(new File(args[1])));

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Tag name of the element package.
	 */
	private static String PACKAGE_TAG_NAME = "package";
	
	/**
	 * Fills a pkg_list element with references to all packages
	 * in the document.
	 * @param xmlDocument
	 * @return Id that is not an id of any package (and should not be an id of any other
	 * package as it is prefixed with "package").
	 */
	private String fillPackageListOfAll(Document xmlDocument, Element pkgList) {
		if (xmlDocument.getDocumentElement() == null) {
			return null;
		}
		NodeList nodeList = xmlDocument.getElementsByTagName(PACKAGE_TAG_NAME);
		
		IdGenerator generator = new IdGenerator("pkg");
		
		for (int i = 0; i < nodeList.getLength(); ++i) {
				
			Element e = (Element)nodeList.item(i);
			// add the package to out list of all packages
			Element packageReference = xmlDocument.createElement("pkg_ref");
			String id = e.getAttribute("id");
			packageReference.setAttribute("idref", id);
			pkgList.appendChild(packageReference);
			
			// try to set the new id as the highest
			generator.setHighest(id);
		}
		
		return generator.generate();
	}
	
	/**
	 * Adds a new package to the document, the new package will compose
	 * all other packages if there are any.
	 * @param xmlDocument Document to add the package to.
	 */
	private void createConjiontPackage(Document xmlDocument) {
		Element packages = xmlDocument.getDocumentElement();
		if (packages == null || !packages.getTagName().equals("packages")) {
			return;
		}
		
		Element pkgList = xmlDocument.createElement("pkg_list");
		
		String id = fillPackageListOfAll(xmlDocument, pkgList);
		
		// don't create the new package if there are no other packages
		if (id == null || pkgList.getChildNodes().getLength() == 0) {
			return;
		}
		
		Element conjointPackage = xmlDocument.createElement(PACKAGE_TAG_NAME);
		conjointPackage.setAttribute("id", id);
		conjointPackage.setAttribute("name", "all");
		conjointPackage.setAttribute("packager", "packager0");
		
		Element version = xmlDocument.createElement("version");
		version.setAttribute("primary", "0");
		version.setAttribute("secondary", "0");
		conjointPackage.appendChild(version);
		
		Element description = xmlDocument.createElement("description");
		description.setTextContent("Conjoint package of all packages.");
		conjointPackage.appendChild(description);
		
		Calendar calendar = Calendar.getInstance();
		Element date = xmlDocument.createElement("date");
		date.setAttribute("day", Integer.toString(calendar.get(Calendar.DAY_OF_MONTH)));
		date.setAttribute("month", Integer.toString(calendar.get(Calendar.MONTH)));
		date.setAttribute("year", Integer.toString(calendar.get(Calendar.YEAR)));
		conjointPackage.appendChild(date);
		
		conjointPackage.appendChild(pkgList);
		
		packages.appendChild(conjointPackage);
	}
	
	/**
	 * Detects version of a given package.
	 * @param packageElement A package element to extract the version from.
	 * @return Version of the given package or null if it is not a package.
	 */
	private Version getPackageVersion(Element packageElement) {
		if (!packageElement.getTagName().equals(PACKAGE_TAG_NAME)) {
			return null;
		}
		
		NodeList nodeList = packageElement.getElementsByTagName("version");
		if (nodeList.getLength() != 1) {
			// if it is a composite package or a bad package, it may not have a version at all
			return null;
		}
		Element e = (Element)nodeList.item(0);
		try {
			return new Version(Integer.parseInt(e.getAttribute("primary")), Integer.parseInt(e.getAttribute("secondary")));
		} catch (NumberFormatException ee) {
			return null;
		}
	}
	
	/**
	 * Removes old versions of packages.
	 * @param xmlDocument
	 */
	private void removeOldPackages(Document xmlDocument) {
		NodeList packagesList = xmlDocument.getElementsByTagName("packages");
		if (packagesList.getLength() != 1) {
			return;
		}
		Element packages = (Element)packagesList.item(0);
		
		// hash map of the newest versions of all packages
		HashMap<String, Version> versions = new HashMap<String, Version>();
		
		NodeList packageList = packages.getElementsByTagName(PACKAGE_TAG_NAME);
		
		// detect newest versions of packages
		for (int i = 0; i < packageList.getLength(); ++i) {
				
			Element e = (Element)packageList.item(i);
			Version pkgVersion = getPackageVersion(e);
			if (pkgVersion != null) {
				String name = e.getAttribute("name");
				Version newestVersion = versions.get(name);
				
				if (newestVersion == null || pkgVersion.isNewerThan(newestVersion)) {
					versions.put(name, pkgVersion);
				}
			}
		}
			
		// remove packages with old versions
		for (Node child = packages.getFirstChild(); child != null;) {
				
			if (child instanceof Element) {
				Element e = (Element)child;
				if (e.getTagName().equals("package")) {
					Version pkgVersion = getPackageVersion(e);
					if (pkgVersion != null) {
						String name = e.getAttribute("name");
						Version newestVersion = versions.get(name);
						
						// this shall never be null
						if (newestVersion == null) {
							throw new NullPointerException();
						}
						
						// remove the package if it is not the newest
						if (newestVersion.isNewerThan(pkgVersion)) {
							child = child.getNextSibling();
							packages.removeChild(e);
						}
					}
				}
			}
			child = child.getNextSibling();
		}
	}
	
	/**
	 * Performs transformations on a document.
	 * @param xmlDocument
	 */
	public void transform(Document xmlDocument) {
		// libovolne transformace objektu 'xmlDocument'
		// (metoda pracuje primo na objektu, nic nevraci)
		
		// removes packages that have newer versions
		removeOldPackages(xmlDocument);
		
		// adds package comprising of all other packages
		createConjiontPackage(xmlDocument);
		
	}
	
	/**
	 * Class for generating unique ids when they are in the form: prefix<id-number>.
	 * It remembers the highest used id and uses it for generating new ids.
	 * It is also possible inform an instance of this class about existing ids
	 * (by setHighest() method) in a document and then generate additional ids.
	 */
	private static class IdGenerator {
		final String prefix;
		int highestId = 0;
		
		public IdGenerator(String prefix) {
			this.prefix = prefix;
		}
		
		public void setHighest(String id) {
			if (id.matches(prefix + "[0-9]+")) {
				
				int newHighest = Integer.parseInt(id.substring(prefix.length()));
				if (newHighest > highestId) {
					highestId = newHighest;
				}
			}
		}
		
		public String generate() {
			return prefix + Integer.toString(++highestId);
		}
	}
	
	/**
	 * Class representing a version of a package.
	 */
	private static class Version {
		public int primary = 0;
		public int secondary = 0;
		
		public Version() {}
		
		public Version(int primary, int secondary) {
			this.primary = primary;
			this.secondary = secondary;
		}
		
		public boolean isNewerThan(Version v) {
			return (primary > v.primary) || (primary == v.primary && secondary > v.secondary);
		}
	}
}
