package user;

import java.util.Random;
import java.util.TreeMap;

import org.w3c.dom.*;

public class MyDomTransformer {
 
	public void transform (Document xmlDocument) {
		NodeList nodes = xmlDocument.getChildNodes();
    	for (int i=0; i<nodes.getLength(); i++) {
    		Node child = nodes.item(i);
    		if (child instanceof Element)
    			sort((Element)child);
    	}
	} 
	    
    private static void sort(Element e) {
    	 TreeMap<String, Element> treemap = new TreeMap<String, Element>();
         NodeList nodes = e.getChildNodes();
         
         for (int i=0; i<nodes.getLength(); i++) {
        	 Node child = nodes.item(i);
     		 if (child instanceof Element) {
	     			
     				String key;
	        		key = child.getTextContent();
	        		if (key == null || key == "")
	        			if (child.hasAttributes())
	        				key = child.getAttributes().item(0).getTextContent();
	        			else
	        				key = Integer.toString(new Random().nextInt());
	        	 	
	        	 
	        	
	        	 sort((Element)child);
	        	 treemap.put(key, (Element) child);
	        	 e.removeChild(child);
     		}
         }
         
         for (Element el : treemap.values()) {
        	 e.appendChild(el);
         }
         
    }
}