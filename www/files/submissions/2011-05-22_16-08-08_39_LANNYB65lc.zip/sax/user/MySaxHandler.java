package user;

import java.util.HashMap;
import java.util.Map;

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

public class MySaxHandler extends DefaultHandler { 
	
	Map<Integer, Integer> sirky = new HashMap<Integer, Integer>();
    int hloubka = 0;
	    
    public void endDocument() throws SAXException {
        
        Integer sirka = 0;
        int maxValue = 0;
        int maxIndex = 0;
        for(int i=1; ; i++) {
        	sirka = sirky.get(i);
        	if (sirka == null)
        		break;
        	if (sirka > maxValue) {
        		maxValue = sirka;
        		maxIndex = i;
        	}
        }
        
        System.out.printf("Nejvetsi sirku ma patro c. %1d (sirka %2d).\n", maxIndex, maxValue);
        
    }
	 
	public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        hloubka++;
        Integer s = sirky.get(hloubka);
        if (s == null)
        	s = 0;
        s++;
        sirky.put(hloubka, s);
    }
	  
    public void endElement(String uri, String localName, String qName) throws SAXException {
        hloubka--;
    }
}