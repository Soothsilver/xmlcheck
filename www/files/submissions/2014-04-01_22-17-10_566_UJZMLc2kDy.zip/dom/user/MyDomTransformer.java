package user;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import org.w3c.dom.*;

public class MyDomTransformer
{
    public void transform(Document xmlDocument) 
    {
        //Pridani noveho receptu
        Element novyRecept = xmlDocument.createElement("Recept");
        Element name = xmlDocument.createElement("Jmeno");
        Element autor = xmlDocument.createElement("Autor");
        Element ingredience = xmlDocument.createElement("Ingredience");
        Element popisPostupu = xmlDocument.createElement("PopisPostupu");
        Element dobaPripravy = xmlDocument.createElement("DobaPripravy");
        Element minuty = xmlDocument.createElement("Minut");
        Element slozitost = xmlDocument.createElement("Slozitost");
        Element hodnoceni = xmlDocument.createElement("Hodnoceni");
        
        name.appendChild(xmlDocument.createTextNode("Novy Recept"));
        autor.setAttribute("RefKuch", "K1");
        ingredience.appendChild(xmlDocument.createTextNode("1 mamut"));
        popisPostupu.appendChild(xmlDocument.createTextNode("Prodejte mamuta a kupte si neco v obchode."));
        minuty.appendChild(xmlDocument.createTextNode("50"));
        dobaPripravy.appendChild(minuty);
        slozitost.appendChild(xmlDocument.createTextNode("snadna"));
        hodnoceni.appendChild(xmlDocument.createTextNode("1.15"));
        
        novyRecept.appendChild(name);
        novyRecept.appendChild(autor);
        novyRecept.appendChild(ingredience);
        novyRecept.appendChild(popisPostupu);
        novyRecept.appendChild(dobaPripravy);
        novyRecept.appendChild(slozitost);
        novyRecept.appendChild(hodnoceni);

        xmlDocument.getElementById("kat_1").appendChild(novyRecept);
        
        //serazeni receptu v jednotlivych kategoriich dle hodnoceni
        NodeList recepty = xmlDocument.getElementsByTagName("Recept");
        ArrayList<Node> nodesHodnoceni = new ArrayList<Node>();
        for (int i = 0; i < recepty.getLength(); i++) 
        {
            nodesHodnoceni.add(((Element)recepty.item(i)).getElementsByTagName("Hodnoceni").item(0));
        }
        Collections.sort(nodesHodnoceni, new compar());
        
        for (Node node : nodesHodnoceni) 
        {
            Node nodeRecept = node.getParentNode();
            Node nodeKategorie = nodeRecept.getParentNode();
            nodeKategorie.removeChild(nodeRecept);
            nodeKategorie.appendChild(nodeRecept);
        }
    }
}

class compar implements Comparator<Node>
{
    public int compare(Node o1, Node o2) 
    {
        double doub = Double.parseDouble(o1.getTextContent().trim())-Double.parseDouble(o2.getTextContent().trim());
        return doub > 0 ? 1 : doub == 0 ? 0 : -1;
    }
}