package user;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler 
{
    //-- Pocet receptu, ktere maji jako ingredienci chleba
    boolean recept,ingredience;
    int pocetChlebu = 0, pocetReceptu = 0;
    //--
    
    //-- 3 kuchari s nejvice recepty
    HashMap<String,Integer> refToCount = new HashMap<String,Integer>();
    HashMap<String,String> refToName = new HashMap<String,String>();
    // boolean recept
    String currCook;
    boolean kuchar = false;
    //--
    
    //-- Prumerna doba pripravy snadnych receptu od kucharu typu User
    boolean rec,minuty,hodiny,slozitost,kuch,dobaPripravy;
    String currRec,currC;
    HashMap<String, String> recIDtoKuchID = new HashMap<String, String>();
    HashMap<String, Double> recIDtoTime = new HashMap<String, Double>();
    HashMap<String, String> recIDtoDiff = new HashMap<String, String>();
    HashMap<String, String> kuchIDtoName = new HashMap<String, String>();
    HashMap<String, Double> nametoTime = new HashMap<String, Double>();
    ArrayList<String> userKuchID = new ArrayList<String>();
    HashMap<String, Integer> nametorecsCount = new HashMap<String, Integer>();
    
    Locator locator;

    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }
    public void startDocument() throws SAXException {
        // ...
    }
    public void endDocument() throws SAXException {
        //-- Pocet receptu, ktere maji jako ingredienci chleba
        System.out.println("Chleba je potreba u "+pocetChlebu+" z "+pocetReceptu+" receptu");
        
        //-- 3 kuchari s nejvice recepty
        BestThree BT = new BestThree();
        Set<String> keys = refToCount.keySet();
        for (String string : keys) 
        {
            BT.add(refToName.get(string), refToCount.get(string));
        }
        System.out.println("\nNejvice receptu maji:\n"+BT.toString());
        
        //-- Prumerna doba pripravy snadnych receptu od kucharu typu User
        Set<String> recs = recIDtoDiff.keySet();
        for (String string : recs) 
        {
            
            if(recIDtoDiff.get(string).equals("snadna"))
            {
                String thisCook = recIDtoKuchID.get(string);
                if(userKuchID.contains(thisCook))
                {
                    double time = recIDtoTime.get(string);
                    String cookName = kuchIDtoName.get(thisCook);
                    if(!nametorecsCount.containsKey(cookName))
                        nametorecsCount.put(cookName, 0);
                    
                    nametorecsCount.put(cookName, nametorecsCount.get(cookName)+1);
                    
                    if(!nametoTime.containsKey(cookName))
                        nametoTime.put(cookName, 0.0);
                    nametoTime.put(cookName, (nametoTime.get(cookName)*(nametorecsCount.get(cookName)-1)+time)/(nametorecsCount.get(cookName)));
                }
            }
        }
        Set<String> outCook = nametoTime.keySet();
        System.out.println("\nPrumerna doba pripravy lehkych receptu od kucharu typu User:");
        for (String string : outCook) {
            System.out.println(string + ":  " + nametoTime.get(string) + "minut");
        }
    }

    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        //-- Pocet receptu, ktere maji jako ingredienci chleba
        if(localName.equals("Recept"))
        {
            recept=true;
            pocetReceptu++;
        }
        if(localName.equals("Ingredience"))
            ingredience=true;
        
        
        //-- 3 kuchari s nejvice recepty
        
        if(recept && localName.equals("Autor"))
        {
            currCook = atts.getValue("RefKuch");
            if(!refToCount.containsKey(currCook))
                refToCount.put(currCook, 0);

            refToCount.put(currCook, refToCount.get(currCook) + 1);
        }
        
        if(localName.equals("Kuchar") && refToCount.containsKey(atts.getValue("IDKuch")))
        {
            kuchar = true;
            currCook = atts.getValue("IDKuch");
        }
        
        //-- Prumerna doba pripravy snadnych receptu od kucharu typu User
        if(localName.equals("Recept"))
        {
            rec = true;
            currRec = atts.getValue("idRec");
        }
        if(rec && localName.equals("Autor"))
        {
            recIDtoKuchID.put(currRec, atts.getValue("RefKuch"));
        }
        if(rec && localName.equals("Minut"))
            minuty = true;
        if(rec && localName.equals("Hodin"))
            hodiny = true;    
        if(rec && localName.equals("Slozitost"))
            slozitost = true;  
        if(dobaPripravy && localName.equals("Hodin"))
            hodiny = true;    
        if(dobaPripravy && localName.equals("Kuchar"))
            hodiny = true;    
        if(rec && localName.equals("DobaPripravy"))
            dobaPripravy = true;
        if(localName.equals("Kuchar"))
        {
            if("User".equals(atts.getValue("typKuch")))
            {
                currC = atts.getValue("IDKuch");
                userKuchID.add(currC);
                kuch = true;
            }
        }
    }

    public void endElement(String uri, String localName, String qName) throws SAXException {
        //-- Pocet receptu, ktere maji jako ingredienci chleba
        if(localName.equals("Recept"))
            recept=false;
        if(localName.equals("Ingredience"))
            ingredience=false;
        //-- 3 kuchari s nejvice recepty
        if(localName.equals("Kuchar"))
            kuchar = false;
        //-- Prumerna doba pripravy lehkych receptu od kucharu typu User
        if(localName.equals("Recept"))
            rec = false;
        if(localName.equals("Minut"))
            minuty = false;
        if(localName.equals("Hodin"))
            hodiny = false;
        if(localName.equals("Slozitost"))
            slozitost = false;
        if(localName.equals("Kuchar"))
            kuch = false;
        if(localName.equals("DobaPripravy"))
            dobaPripravy = false;
    }

    public void characters(char[] chars, int start, int length) throws SAXException {
        //-- Pocet receptu, ktere maji jako ingredienci chleba
        if(ingredience)
        {
            String a = new String(chars,start,length).toLowerCase();
            if(a.contains("chleba"))
            {
                pocetChlebu++;
            }
        }
        //-- 3 kuchari s nejvice recepty
        if(kuchar)
        {
            refToName.put(currCook, new String(chars,start,length).trim());
        }
        //-- Prumerna doba pripravy lehkych receptu od kucharu typu User
        if(dobaPripravy && minuty)
        {
            recIDtoTime.put(currRec, Double.parseDouble(new String(chars,start,length).trim()));
        }
        if(dobaPripravy && hodiny)
        {
            recIDtoTime.put(currRec, 60 * Double.parseDouble(new String(chars,start,length).trim()));
        }
        if(slozitost)
        {
            recIDtoDiff.put(currRec, new String(chars,start,length).trim());
        }
        if(kuch)
        {
            kuchIDtoName.put(currC, new String(chars,start,length).trim());
        }
    }

    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
        // ...
    }

    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

    public void skippedEntity(String name) throws SAXException {
        // ...
    }
}


class BestThree
{
    private Object[][] dat = new Object[3][2];
    
    public void add(String name, Integer val)
    {
        for (int i = 0; i < dat.length; i++) 
        {
            if(dat[i][0] == null)
            {
                dat[i][0] = name;
                dat[i][1] = val;
                return;
            }
        }
        
        if((Integer)dat[1][1] > val)
        {
            if((Integer)dat[2][1] > val)
                return;
            dat[2][1] = val;
            dat[2][0] = name;
        }
        else
        {
            if((Integer)dat[0][1] > val)
            {
                dat[1][1] = val;
                dat[1][0] = name;
            }
            else
            {
                dat[0][1] = val;
                dat[0][0] = name;
            }
        }
        
    }
    
    public String toString()
    {
        return dat[0][0] + " : " + dat[0][1] + " receptu\n" + dat[1][0] + " : " + dat[1][1] + " receptu\n" + dat[2][0] + " : " + dat[2][1] + " receptu";
    }
}