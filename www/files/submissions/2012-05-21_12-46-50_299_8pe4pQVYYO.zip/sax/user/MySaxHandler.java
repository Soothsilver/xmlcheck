package user;

import java.util.HashMap;
import java.util.LinkedList;
import org.xml.sax.helpers.DefaultHandler;

import org.xml.sax.SAXException;

import org.xml.sax.Attributes;

 public class MySaxHandler extends DefaultHandler {
     
   
        String content="";
    Data data=new Data();
   
   
    @Override
    public void endDocument() throws SAXException {
        for(int i=0;i<data.dat.size();i++){
            System.out.println("Auto s poznavaci znackou "+data.dat.get(data.get(i)).spz+" bylo pujceno "+data.dat.get(data.get(i)).count);
        }
        
            
    }
    
     
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

            
           //  System.out.println("localName "+localName);
            //System.out.println( atts.getType(localName));
             

    }
    
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if(!content.matches("")){
        if(localName.equalsIgnoreCase("SPZ") ){
       //System.out.println(content);
           data.add(content);
        }
        
   }
    }
    
            
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        content="";
for (int i = start; i < start + length; i++) {
	    switch (ch[i]) {
	    case '\\':
		
		break;
	    case '"':
		
		break;
	    case '\n':
		
		break;
	    case '\r':
		
		break;
	    case '\t':
		
		break;
	    default:
		content+=ch[i];
		break;
	    }
	}
       // System.out.println(content);
	    }

   
	

    
}

    class Data {
        
   HashMap<String,Auto> dat = new HashMap<String,Auto>();
   LinkedList<String> list = new LinkedList();
    public void add(String spz){
    if(dat.containsKey(spz)){
    dat.get(spz).count++;
    }else{
    dat.put(spz, new Auto(spz));
    list.add(spz);
    }
    }
    public String get(int i){
    return list.get(i);
    }
    
    }
class Auto{

    public Auto(String spz) {
        this.spz = spz;
    }
    
int count=0;
String spz;
}