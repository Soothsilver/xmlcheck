package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;


public class MyDomTransformer {

    public void transform(Document xmlDocument) {
 Element root=  xmlDocument.getDocumentElement();
 
     NodeList pujcovna =xmlDocument.getElementsByTagName("Pobocka");
     NodeList auta=xmlDocument.getElementsByTagName("Auta");
     Element katalogAut =xmlDocument.createElement("Katalog_vozu");
     root.appendChild(katalogAut);
       // System.out.println(auta.getLength());
     for(int i=0;i<pujcovna.getLength();i++){
         for(int j=0;j<auta.getLength();j++){
     if(auta.item(j).getParentNode().isSameNode(pujcovna.item(i))){
         katalogAut.appendChild(auta.item(j).cloneNode(true));
         pujcovna.item(i).removeChild(auta.item(j));
        // System.out.println("node smazan");
          //System.out.println(auta.getLength());
          j--;
     }}
     }
     
    }
}