package user;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import org.w3c.dom.*;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.OutputKeys;
import java.io.FileOutputStream;
import java.util.Date;
import java.util.Locale;
import java.text.DateFormat;


public class MyDomTransformer {

public void transform (Document xmlDocument) {
   
 // projit vsechny ceny
   NodeList ceny = xmlDocument.getElementsByTagName("ceny");
   int i = 0;
   while (i < ceny.getLength()) {
   Node n = ceny.item(i);
   String[] refDid = new String[ceny.getLength()];
   String[] cenyText = new String[ceny.getLength()];
   refDid[i] = n.getAttributes().getNamedItem("did_ref").getTextContent();  //ulozit v poli hodnoty atributa
   cenyText[i] = n.getTextContent(); //ulozit v poli text elementu
	
	// projit vsechny desky
		NodeList deska = xmlDocument.getElementsByTagName("deska");
		int j = 0;
		   while (j < deska.getLength()) {
				Node k = deska.item(j);
				String[] Did = new String[deska.getLength()];
				Did[j] = k.getAttributes().getNamedItem("did").getTextContent(); //ulozit v poli hodnoty atributa
				if(refDid[i] == Did[j]) { //kdyz hodnoty atributu v elementach ceny a deska jsou stejne,
                                          //vlozim do elementu deska atribut cena, ktery raven hodnote v tekstovem uzlu elementu ceny			
				Attr cena = xmlDocument.createAttribute("cena"); 
				cena.setValue(cenyText[i]);
				Element kc = (Element) xmlDocument.getElementsByTagName("deska").item(j);
				kc.setAttributeNode(cena);
				n.getParentNode().removeChild(n);
				}
            }
  }
  // projit vsechny recenze
		NodeList recenze = xmlDocument.getElementsByTagName("recenze");
		int q = 0;
		   while (q < recenze.getLength()) {
				Node r = recenze.item(q);
				Element text = xmlDocument.createElement("text"); //vytvoreni elementu text a vlozeni do neho teksta racenze
				text.appendChild(xmlDocument.createTextNode(r.getTextContent()));	
				r.appendChild(text);				
				Attr datum = xmlDocument.createAttribute("datum"); //vytvoreni atributu datum
				datum.setValue("");
				Element rc = (Element) xmlDocument.getElementsByTagName("recenze").item(q);
            	rc.setAttributeNode(datum);
				Element recenzent = xmlDocument.createElement("recenzent");//vytvoreni elementu recenzent
				r.appendChild(recenzent);
				
  }
}
}