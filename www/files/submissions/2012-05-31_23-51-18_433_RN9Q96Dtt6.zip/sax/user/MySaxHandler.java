package user;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.ContentHandler;

import org.xml.sax.InputSource;

import org.xml.sax.Locator;

import org.xml.sax.SAXException;

import org.xml.sax.XMLReader;

import org.xml.sax.helpers.XMLReaderFactory;

import org.xml.sax.Attributes;



public class MySaxHandler extends DefaultHandler {
String thisElement = "";
int i=0, j=0, k=0, l=0, p=0;
String[][] attD = new String[1000][1000]; //poli pro ulozeni atributu desek
String[] attC = new String[1000]; //poli pro ulozeni atributu cen
int[][] rl = new int[1000][1000]; //poli pro ulozeni poctu symbolu v recenzich

public static void main(String[] args) {
        // Cesta ke zdrojovemu XML dokumentu  
        String sourcePath = "data.xml";

        try {

           XMLReader parser = XMLReaderFactory.createXMLReader();
           InputSource source = new InputSource(sourcePath);
           parser.setContentHandler(new MySaxHandler());
           parser.parse(source);
             } catch (Exception e) {
               e.printStackTrace();

              }
}
//obsluha udalosti "zacatek dokumentu"
 public void startDocument() throws SAXException {

    }
//obsluha udalosti "konec dokumentu"
    public void endDocument() throws SAXException {
 
	  	for(j=0; j<1000; j++){
			for(i=0; i<1000; i++){
				if(attD[j][i]== attC[j]){ // je-li attribut did elementu "deska" se rovna atributu  did_ref elementu "ceny"
				//pocet prumernou delky recenze
				k=k + rl[j][i]; 
				l++;
				p=k/l;
			    }
		    }
	    }
	 System.out.println("prumerna delka : "+ p);
 
	 }
	 
//obsluha udalosti "zacatek elementu"
   public void startElement(String namespaceURI, String localName, String qName, Attributes atts) throws SAXException {
  thisElement = qName; 
if (thisElement.equals("artist")){ // je-li element ktery zpracovava = "artist"
 j++; //zvysuji prvni index masivu
 i=0; //vynuluji se druhy
  }
  
 if (thisElement.equals("deska")){ // je-li element ktery zpracovava = "deska"
 i++; //zvysuji druhy index masivu
 attD[j][i]=atts.getValue("did"); //znaceni atributu did se uklada do poli
// System.out.println("Attribut_desky #" + j + i + ":" + attD[j][i]);
 
 }
  if (thisElement.equals("ceny")){  // je-li element ktery zpracovava = "ceny"

 attC[j]=atts.getValue("did_ref"); //znaceni atributu did_ref se uklada do poli
// System.out.println("Attribut_ceny # " + j + ": " + attC[j] );
 
 }

}
//obsluha udalosti "konec elementu"
    public void endElement(String namespaceURI, String localName, String qName) throws SAXException {
  thisElement = "";
}
//obsluha udalosti "znakova data"
    public void characters(char ch[], int start, int length) throws SAXException {
   
		if (thisElement.equals("recenze")){  // je-li element ktery zpracovava = "recenze"
	     String rec = new String(ch, start, length);
         rl[j][i]=rec.length(); //znaceni delky textu se uklada do poli
//		   System.out.println("length of recenze #  " + j + i + ": " + rl[j][i]);
		}
		
		 if (thisElement.equals("ceny")){ // je-li element ktery zpracovava = "ceny"
	      String cen = new String(ch, start, length);
              if (cen!="zlata-deska") // je-li v textovem uzlu elementu "ceny" hodnota neni zlata-deska
		     attC[j] = "neni"; //do poli hodnoty atributu ceny se uklada hodnota "neni" aby se ne mohla porovnat s 
								// hodnotou atributu deska 
		 }


}
}
