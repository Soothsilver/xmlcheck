/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.util.ArrayList;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 *
 * @author Martin
 */
public class MySaxHandler extends DefaultHandler {
    static String sourcePath = "data.xml";
    String currentElement;
    String maxBand;
    String currentBand;
    boolean isSponsor = false;
    boolean isConcert = false;
    ArrayList<String> sponsors = new ArrayList();
    String sponsorName;
    String id;
    int sponsorCount;
    int maxCount;
    int totalPlaces;
    int eventCount;
    
    public static void main(String[] args) {
        
        try {
            XMLReader parser = XMLReaderFactory.createXMLReader();
            InputSource source = new InputSource(sourcePath);
            parser.setContentHandler(new MySaxHandler());
            parser.parse(source);
        } catch (Exception e) { 
            e.printStackTrace();           
        }
        
    }
    
    @Override
    public void startDocument() throws SAXException {
    }
    
    @Override
    public void endDocument() throws SAXException {
        System.out.print("Pocet sponzoru s tel. cislem zacinajicim cislici 7: "+ sponsors.size() + " (");
        for (int i = 0; i < sponsors.size(); i++) {
            System.out.print(sponsors.get(i));
            if (i+1 < sponsors.size()) {
                System.out.print(", ");
            }
            
        }
        System.out.println(")");
        
        System.out.println("");
        System.out.println("Skupina, jejiz koncert mel nejvice sponzoru: " + maxBand + " ("+maxCount+" sponzoru)");
        
        System.out.println("");
        System.out.println("Prumerny pocet mist na udalosti: " + (int)(totalPlaces/eventCount));
    }
    
       @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        currentElement = localName;
        if (localName.equals("sponzor")) {
            isSponsor = true;
            sponsorCount++;
        }
        
        
        if (isSponsor && localName.equals("telefon")) {
            if (atts.getValue("cislo").startsWith("7") && !sponsors.contains(sponsorName)) {
                sponsors.add(sponsorName);
            }
        }
        if (localName.equals("udalost")) {
            eventCount++;
            if (atts.getValue("typ").equals("koncert")) {
                isConcert = true;
            } else {
                isConcert = false;
            }
        }
    }


    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (localName.equals("sponzor")) {
            isSponsor = false;
        }
        if (localName.equals("udalost")) {
            if (isConcert) {
                if (sponsorCount > maxCount) {
                    maxCount = sponsorCount;
                    maxBand = currentBand;
                }
            }
            sponsorCount = 0;
        }
    }

    
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        if (currentElement.equals("jmeno") && isSponsor) {
            sponsorName = String.copyValueOf(chars, start, length);
        }
        else if (currentElement.equals("skupina")) {
            currentBand = String.copyValueOf(chars, start, length);
        }
        
        else if (currentElement.equals("pocetMist")) {
            totalPlaces += Integer.parseInt(String.copyValueOf(chars, start, length));
        }
    }


}
