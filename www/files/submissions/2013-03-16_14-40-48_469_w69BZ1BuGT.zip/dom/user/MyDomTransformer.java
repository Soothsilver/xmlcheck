/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

/**
 *
 * @author Martin
 */
import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer {
        private static final String INPUT_FILE = "data.xml";
        private static final String OUTPUT_FILE= "data.out.xml";

    /**
     * Main method
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {

        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setValidating(false);
            DocumentBuilder builder = dbf.newDocumentBuilder();
            Document doc = builder.parse(INPUT_FILE);
            
            MyDomTransformer transformer = new MyDomTransformer();
            transformer.transform(doc);
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer writer = tf.newTransformer();
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            // Run transformation of DOM tree to XML document
            writer.transform(new DOMSource(doc), new StreamResult(new File(OUTPUT_FILE)));
        } catch (Exception e) {

            e.printStackTrace();

        }
        
    }
    public void transform (Document xmlDocument) { 
        // vymazani sponzora se jmenem Karel Novy ze vsech udalosti
        NodeList jmena = xmlDocument.getElementsByTagName("jmeno");
        for (int i = 0; i < jmena.getLength(); i++) {
            Element parent = (Element)jmena.item(i).getParentNode();
            if (parent.getNodeName().equals("sponzor")) {
                if (jmena.item(i).getTextContent().equals("Karel Novy")) {
                    parent.getParentNode().removeChild(parent);
                    i--;
                }
            }
        }
               
        // zmena terminu konani koncertu U2
        NodeList terminy = xmlDocument.getElementsByTagName("termin");
        for (int i = 0; i < terminy.getLength(); i++) {
            Element parent = (Element) terminy.item(i).getParentNode();
            if (parent.getAttribute("id").equals("u2")) {
                Element termin = (Element) terminy.item(i);
                Element day = (Element)termin.getElementsByTagName("den").item(0);
                day.setTextContent("29.8.2013");
                Element from = (Element)termin.getElementsByTagName("od").item(0);
                from.setTextContent("21:00");
                Element to = (Element)termin.getElementsByTagName("do").item(0);
                to.setTextContent("24:00");
            }
        }
    }
}