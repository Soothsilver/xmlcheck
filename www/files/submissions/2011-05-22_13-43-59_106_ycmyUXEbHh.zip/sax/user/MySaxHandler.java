package user;

import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;


// Jedna se o jednoduchou statistiku - program pocita celkovy pocet lodi, tedy pocet elementu ship a carrier (carrier je prvkem subst. skupiny pro ship) v dokumentu.
public class MySaxHandler extends DefaultHandler {
    public int shipCount;
    Locator locator;
       
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

     
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if(localName.equals("ship") || localName.equals("carrier"))
        {
            ++shipCount;
        }        
    }
    
    @Override
    public void endDocument() throws SAXException {
        System.out.println("Number of ships and carriers in the navy: " + shipCount);
    }
}

