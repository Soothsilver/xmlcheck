package user;
import org.w3c.dom.*;


// Transformace provadi modernizaci flotily - vyhledava lode tridy venator a prepisuje je na novou tridu venator2. 
// Program rovnez pridava tento novy typ do databaze typu lodi (schematics). K tomu slouzi rada metod CreateX.
public class MyDomTransformer
{
    private static Element CreateWeapon(Document doc, int count, String name)
    {
        Element weapon = doc.createElement("weapon");
        weapon.setAttribute("count", String.valueOf(count));
        weapon.setTextContent(name);
        return weapon;
    }
    
    private static Element CreateArmament(Document doc)
    {
        Element armament = doc.createElement("armament");     
        armament.appendChild(CreateWeapon(doc, 8, "Heavy laser battery"));
        armament.appendChild(CreateWeapon(doc, 20, "Light cannon"));
        armament.appendChild(CreateWeapon(doc, 2, "Megaton cannon"));        
        return armament;        
    }
    
    private static Element CreateShield(Document doc, String type, int capacity, float rechargeRate)
    {
        Element shield = doc.createElement("shield");
        shield.setAttribute("type", type);
        
        Element capacityElement = doc.createElement("capacity");
        capacityElement.setTextContent(String.valueOf(capacity));
        shield.appendChild(capacityElement);
        
        Element rechargeElement = doc.createElement("rechargeRate");
        rechargeElement.setTextContent(String.valueOf(rechargeRate));
        shield.appendChild(rechargeElement);
        
        return shield;        
    }
    
    private static Element CreateShielding(Document doc)
    {
        Element shielding = doc.createElement("shielding");
        shielding.appendChild(CreateShield(doc, "energy", 350, 1.1f));
        shielding.appendChild(CreateShield(doc, "projectile", 350, 1.1f));
        shielding.appendChild(CreateShield(doc, "energy", 100, 4f));
        return shielding;
    }
    
    private static Element CreateShipType(Document doc)
    {
        Element type = doc.createElement("shipType");
        type.setAttribute("class", "venator2");
        
        Element name = doc.createElement("name");
        name.setTextContent("Venator II class");
        type.appendChild(name);        
        
        Element manufacturer = doc.createElement("manufacturer");
        manufacturer.setTextContent("Meandred Ship Systems");
        type.appendChild(manufacturer);
        
        type.appendChild(CreateArmament(doc));
        
        Element maxSpeed = doc.createElement("maxSpeed");
        maxSpeed.setTextContent("110");
        type.appendChild(maxSpeed);        
        
        type.appendChild(CreateShielding(doc));
        
        return type;        
    }
    
    public void transform(Document xmlDocument) {
        NodeList list = xmlDocument.getElementsByTagName("ship");
        for(int i=0; i < list.getLength(); ++i)
        {
            Element ship = (Element) list.item(i);
            String shipClass = ship.getAttribute("class");
            
            if(shipClass.equals("venator"))
                ship.setAttribute("class", "venator2");
        }
        
        Element schematics = (Element) xmlDocument.getElementsByTagName("schematics").item(0);
        
        schematics.appendChild(CreateShipType(xmlDocument));
    }
}
