package user;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

/*
 * Trida rekurzivne prevrati poradi vsech podelementu elementu katalog. 
 * 
 * 
 * Takze z
 * 
 * <katalog>
 *      <notebook>
 *          <znacka>LENOVO</znacka>
 *          <model>Ideapad</model>
 *      </notebook>
 *      <notebook>
 *          <znacka>ACER</znacka>
 *          <model>Aspire</model>
 *      </notebook>
 * </katalog>
 * 
 * udela:
 * 
 * <katalog>
 *      <notebook>
 *          <model>Aspire</model>
 *          <znacka>ACER</znacka>
 *      </notebook>
 *      <notebook>
 *          <model>Ideapad</model>
 *          <znacka>LENOVO</znacka>
 *      </notebook>
 * </katalog>
 * 
 * 
 */
public class MyDomTransformer {

    public void transform(Document xmlDocument) {
        NodeList katalogList = xmlDocument.getElementsByTagName("katalog");
        if (katalogList.getLength() == 1) {
            Node katalog = katalogList.item(0);
            trasformNode(katalog, 0);
        }
    }

    private Node trasformNode(Node node, int depth) {
        for (int i = node.getChildNodes().getLength() - 1; i >= 0; i--) {
            Node originalNode = node.removeChild(node.getChildNodes().item(i));
            if (isNotEmptyText(originalNode)) {
                node.appendChild(trasformNode(originalNode, depth + 1));
            }
        }
        return node;
    }

    private boolean isNotEmptyText(Node node) {
        return (!(node instanceof Text))
                || (node instanceof Text && ((Text) node)
                        .getTextContent().trim().length() > 1);
    }
}
