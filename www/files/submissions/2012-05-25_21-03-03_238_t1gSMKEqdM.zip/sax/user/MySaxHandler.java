package user;

import java.util.ArrayList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Pocita maximalni/minimalni/prumernou delku nazvu elementu a atributu
 * 
 * @author jfaryad
 * 
 */
public class MySaxHandler extends DefaultHandler {

    private final List<String> elementNames = new ArrayList<String>();

    private final List<String> attributeNames = new ArrayList<String>();

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        elementNames.add(qName);
        for (int i = 0; i < attributes.getLength(); i++) {
            attributeNames.add(attributes.getQName(i));
        }
    }

    @Override
    public void endDocument() throws SAXException {
        System.out.println("Pocet elementu: " + elementNames.size());
        if (!elementNames.isEmpty()) {
            System.out.println("Element s nejdelsim nazvem " + longestName(elementNames) + " ma delku "
                    + longestName(elementNames).length());
            System.out.println("Element s nejkratsim nazvem " + shortestName(elementNames) + " ma delku "
                    + shortestName(elementNames).length());
            System.out.println("Prumerna delka nazvu elementu je " + averageNameLength(elementNames));
        }

        System.out.println();

        System.out.println("Pocet atributu" +
                "ibutu: " + attributeNames.size());
        if (!elementNames.isEmpty()) {
            System.out.println("Atribut s nejdelsim nazvem " + longestName(attributeNames) + " ma delku "
                    + longestName(attributeNames).length());
            System.out.println("Atribut s nejkratsim nazvem " + shortestName(attributeNames) + " ma delku "
                    + shortestName(attributeNames).length());
            System.out.println("Prumerna delka nazvu atributu je " + averageNameLength(attributeNames));
        }

    }

    private String longestName(List<String> names) {
        String max = "";
        for (String name : names) {
            if (name != null && name.length() > max.length()) {
                max = name;
            }
        }
        return max;
    }

    private String shortestName(List<String> names) {
        String min = null;
        for (String name : names) {
            if (name != null && (min == null || name.length() < min.length())) {
                min = name;
            }
        }
        return min;
    }

    private double averageNameLength(List<String> names) {
        int average = 0;
        for (String name : names) {
            if (name != null) {
                average += name.length();
            }
        }
        return (double) average / names.size();
    }

}
