package user;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import org.w3c.dom.*;

public class MyDomTransformer {
    private Element addSimpleChild(Document xmlDocument, Element parent, String name, String value) {
        Element newElement = xmlDocument.createElement(name);
        newElement.setTextContent(value);
        parent.appendChild(newElement);
        return newElement;
    }

    private void createNewProduct(Document xmlDocument) {
        NodeList nodes = xmlDocument.getElementsByTagName("products");
        Element products = (Element)nodes.item(0);        
        
        Element newProduct = xmlDocument.createElement("product");
        newProduct.setAttribute("id", "p4");
        addSimpleChild(xmlDocument, newProduct, "name", "NetBeans IDE");
        addSimpleChild(xmlDocument, newProduct, "category_ref", null).setAttribute("id", "c3");
        addSimpleChild(xmlDocument, newProduct, "vendor_ref", null).setAttribute("id", "v1");
        Element versions = addSimpleChild(xmlDocument, newProduct, "versions", null);
        Element version = addSimpleChild(xmlDocument, versions, "version", null);
        addSimpleChild(xmlDocument, version, "name", "7.1");
        addSimpleChild(xmlDocument, version, "publishDate", "2011-05-07");
        addSimpleChild(xmlDocument, version, "size", "137 MB");
        
        products.appendChild(newProduct);
    }
    
    private void orderCategories(Document xmlDocument) {
        NodeList nodes = xmlDocument.getElementsByTagName("category");
        ArrayList<Element> list = new ArrayList<Element>();
        for (int i = 0; i < nodes.getLength(); i++) {
            Element category = (Element)nodes.item(i);
            list.add(category);
        }
        
        Element parent = (Element)xmlDocument.getElementsByTagName("categories").item(0);
        NodeList children = parent.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            parent.removeChild(children.item(i));
        }
        
        Collections.sort(list, new Comparator<Element>() {
            public int compare(Element o1, Element o2) {
                String t1 = o1.getElementsByTagName("name").item(0).getTextContent();
                String t2 = o2.getElementsByTagName("name").item(0).getTextContent();
                return t1.compareTo(t2);
            }
        });
        
        for (int i = 0; i < list.size(); i++) {
            parent.appendChild(list.get(i));
        }
    }
    
    public void transform (Document xmlDocument) {
        // 1. transformace: vytvoreni noveho produktu
        createNewProduct(xmlDocument);

        // 2. transformace: serazeni seznamu kategorii podle jmena
        orderCategories(xmlDocument);
    }
}
