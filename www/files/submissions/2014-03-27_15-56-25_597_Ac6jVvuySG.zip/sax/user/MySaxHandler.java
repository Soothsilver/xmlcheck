package user;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import java.util.HashMap;
import java.util.Map;

public class MySaxHandler extends DefaultHandler {
    public MySaxHandler() {
        abilities.put("Windfury", 0);
        abilities.put("Charge", 0);
        abilities.put("DivineShield", 0);
        abilities.put("Taunt", 0);
        abilities.put("Frozen", 0);
        abilities.put("SpellDamage", 0);
        abilities.put("Stealth", 0);
        abilities.put("Enrage", 0);
        abilities.put("ImmuneToMagic", 0);
        abilities.put("Poison", 0);
        abilities.put("Battlecry", 0);
        abilities.put("Deathrattle", 0);
    }

    int sumMinionCost = 0;
    int sumMinionValue = 0;
    int countMinions = 0;

    Map<String, Integer> abilities = new HashMap<String, Integer>();

    boolean inDescription = false;
    boolean hasDescription = false;
    boolean allHaveDescription = true;

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        //Average value
        if (localName.equals("Minion")) {
            int cost = Integer.parseInt(atts.getValue("Cost"));
            int attack = Integer.parseInt(atts.getValue("Attack"));
            int health = Integer.parseInt(atts.getValue("Health"));

            countMinions++;
            sumMinionValue += attack + health;
            sumMinionCost += cost;
        }

        //Most common ability
        if (abilities.containsKey(localName)) {
            abilities.put(localName, abilities.get(localName) + 1);
        }

        if (localName.equals("Description")) {
            inDescription = true;
            hasDescription = false;
        }
    }


    @Override
    public void characters(char ch[], int start, int length) throws SAXException {
        if (inDescription) {
            String value = new String(ch).substring(start, start + length).trim();
            if (!value.isEmpty())
                hasDescription = true;
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (localName.equals("Description")) {
            inDescription = false;
            if (!hasDescription)
                allHaveDescription = false;
        }
    }


    @Override
    public void endDocument() throws SAXException {
        /*Average Minion Value*/
        double averageMinionValue = (double) sumMinionValue / sumMinionCost;

        /*Most Common Ability*/
        int maxOccurences = 0;
        String mostCommonAbility = "";
        for (String key : abilities.keySet()) {
            if (maxOccurences < abilities.get(key)) {
                mostCommonAbility = key;
                maxOccurences = abilities.get(key);
            }
        }

        /*Do all description elements have content */
        boolean allDescriptionElementsHaveContent = allHaveDescription;
    }

}