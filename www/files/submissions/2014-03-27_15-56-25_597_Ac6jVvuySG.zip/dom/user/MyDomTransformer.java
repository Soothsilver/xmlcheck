package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Text;

public class MyDomTransformer {
    public void transform(Document xmlDocument) {
        //1) Pridat kartu
        //Minion
        Element newMinion = xmlDocument.createElement("Minion");
        newMinion.setAttribute("Title", "Bloodmage Thalnos");
        newMinion.setAttribute("Subtype", "General");
        newMinion.setAttribute("Rarity", "Legendary");
        newMinion.setAttribute("Cost", "2");
        newMinion.setAttribute("Attack", "1");
        newMinion.setAttribute("Health", "1");
        newMinion.setAttribute("Id", "id_Bloodmage");

        //Minion/Description
        Element newMinionDescription = xmlDocument.createElement("Description");

        Text newMinionDescriptionText = xmlDocument.createTextNode("Spell Damage +1. Deathrattle: Draw a card.");
        newMinionDescription.appendChild(newMinionDescriptionText);

        newMinion.appendChild(newMinionDescription);

        //Minion/Abilities
        Element newMinionAbilities = xmlDocument.createElement("Abilities");

        Element newMinionAbilitiesSpellDamage = xmlDocument.createElement("SpellDamage");
        newMinionAbilitiesSpellDamage.setAttribute("Amount", "1");
        newMinionAbilities.appendChild(newMinionAbilitiesSpellDamage);

        Element newMinionAbilitiesDeathrattle = xmlDocument.createElement("Deathrattle");
        Element newMinionAbilitiesDeathrattleAction = xmlDocument.createElement("Action");
        Element newMinionAbilitiesDeathrattleActionDraw = xmlDocument.createElement("Draw");
        newMinionAbilitiesDeathrattleAction.appendChild(newMinionAbilitiesDeathrattleActionDraw);
        newMinionAbilitiesDeathrattle.appendChild(newMinionAbilitiesDeathrattleAction);
        newMinionAbilities.appendChild(newMinionAbilitiesDeathrattle);

        newMinion.appendChild(newMinionAbilities);

        xmlDocument.getDocumentElement().appendChild(newMinion);

        //2) Smazat vsechny karty ktere jsou moc drahe (cost>5)
        for (Node child = xmlDocument.getDocumentElement().getFirstChild(); child != null; child = child.getNextSibling())
            if (child instanceof Element) {
                Element childElement = (Element) child;
                if (childElement.hasAttribute("Cost"))
                    if (Integer.parseInt(childElement.getAttribute("Cost")) > 5)
                        xmlDocument.getDocumentElement().removeChild(childElement);
            }
    }
}