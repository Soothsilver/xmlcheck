package user;

import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;

/*
 *  Zobrazen� adres��ov� struktury soubor� v katalogu
 *  s po�tem soubor� a celkovou velikost� v ka�d�m adres��i
 *
 *  Pro po�et soubor� a sou�et jejich velikost� je nutn� nejprve
 *  proj�t podadres��e a soubory, a teprve pot� vypsat tyto �daje
 */


public class MySaxHandler extends DefaultHandler {    

    // Pomocn� t��da udr�uje informace o podadres���ch a souborech pro pozd�j�� v�pis
    private class Adresar {
        int velikost;
        int souboru;
        StringBuilder text;
        Adresar otec;

        public Adresar(Adresar o) {
            otec = o;
            text = new StringBuilder();
        }
    }

    // Pointer na aktu�ln� zpracovan� adres��, do kter�ho se p�ipo��t�vaj� soubory p��mo v n�m um�st�n�
    Adresar aktualni;
    boolean root;

    // V�pis m� form�t html dokumentu
    @Override
    public void startDocument() throws SAXException {

        System.out.println("<html>\n<head>\n<title>V�pis soubor�</title>\n</head>\n<body>\n<ul>");

    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        // ��dek s informaceni o souboru je p�id�n do v�pisu adres��e, ve kter�m p��mo le��
        if(localName.equals("soubor")) {
            aktualni.text.append("<li><b>");
            aktualni.text.append(atts.getValue("nazev_souboru"));
            aktualni.text.append("</b> <i>(");
            aktualni.text.append(atts.getValue("velikost"));
            aktualni.text.append("kB)</i></li>\n");
            aktualni.velikost += Integer.parseInt(atts.getValue("velikost"));
            aktualni.souboru++;
        }

        // Pro adres�� se vytvo�� nov� uzel stromu
        if(localName.equals("adresar")) {            
            aktualni.text.append("<li>");
            String s = root ? "Disk" : "Adres��";
            root = false;
            aktualni.text.append(s);
            aktualni.text.append(" <b>");
            aktualni.text.append(atts.getValue("nazev_adresare"));
            Adresar a = new Adresar(aktualni);
            aktualni = a;
        }

        // Ka�d� disk obsahuje ko�enov� adres��, ten je vyps�n zvl᚝
        if(localName.equals("disk")) {
            root = true;
            aktualni = new Adresar(null);
        }

    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {

        // Po ukon�en� adres��e m�me v�pis v�ech jeho soubor� a podadres���
        // Zn�me celkov� po�et soubor� a jejich velikost
        // Tyto �daje (a p�ipraven� v�pis podadres���) vlo��me do v�pisu nad�azen�ho adres��e
        if(localName.equals("adresar")) {
            Adresar posledni = aktualni;
            aktualni = posledni.otec;
            aktualni.velikost += posledni.velikost;
            aktualni.souboru += posledni.souboru;
            aktualni.text.append("</b> <i>(Po�et soubor�: ");
            aktualni.text.append(posledni.souboru);
            aktualni.text.append(", celkem ");
            aktualni.text.append(posledni.velikost);
            aktualni.text.append("kB)</i>\n<ul>");
            aktualni.text.append(posledni.text.toString());
            aktualni.text.append("\n</ul>\n</li>\n");
        }

        // Po ukon�en� disku vyp�eme na v�stup p�ipraven� v�pis jeho ko�enov�ho adres��e
        if(localName.equals("disk")) {
            System.out.println(aktualni.text.toString());
        }
    }
    
    @Override
    public void endDocument() throws SAXException {
        System.out.println("</ul>\n</body>\n</html>");
    }
}

