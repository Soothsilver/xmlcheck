package user;

import org.w3c.dom.*;
import java.util.Hashtable;
import java.util.ArrayList;

/*
 *  Transformace katalogu e-knih
 *
 *  P�vodn� soubor obsahuje:
 *
 *  Z�znamy e-knih
 *      - reference na jejich autory, tagy a soubor
 *  Adres��ov� struktura se soubory
 *  Z�znamy autor� a tag�
 *
 *  Nov� soubor obsahuje:
 *
 *  Z�znamy e-knih, kter� nen�le�� ��dn�mu souboru
 *  Adres��ov� struktura se soubory a pod nimi p��slu�n� z�znamy e-knih
 *      - m�sto referenc� na autory a tagy obsahuj� z�znamy cel� elementy autor� a tag�
 *  Z�znamy autor� a tag�
 *
 */

public class MyDomTransformer
{

    public void transform(Document xmlDocument) {
        
        Hashtable<String,Node> slovnik = new Hashtable<String,Node>();

        // Do slovn�ku vlo��me v�echny z�znamy, aby je podle ID bylo mo�n� p�i�adit k soubor�m
        NodeList zaznamy = xmlDocument.getElementsByTagName("zaznam");
        for(int i = 0; i < zaznamy.getLength(); ++i)
        {
            Node zaznam = zaznamy.item(i);
            if(zaznam.getAttributes().getNamedItem("ref_soubor") != null) {
                slovnik.put("Z�znam:"+zaznam.getAttributes().getNamedItem("ref_soubor").getTextContent(), zaznam);
            }
            ((Element)zaznam).removeAttribute("ref_soubor");
        }

        // Do elementu ka�d�ho souboru p�id�me z�znam e-knihy kter� mu podle ID n�le��
        NodeList soubory = xmlDocument.getElementsByTagName("soubor");
        for(int i = 0; i < soubory.getLength(); ++i)
        {
            Node soubor = soubory.item(i);
            soubor.appendChild(slovnik.get("Z�znam:"+soubor.getAttributes().getNamedItem("soubor_id").getTextContent()));
        }

        // Do slovn�ku vlo��me v�echny autory, aby je podle ID bylo mo�n� p�i�adit k z�znam�m
        NodeList autori = xmlDocument.getElementsByTagName("autor");
        for(int i = 0; i < autori.getLength(); ++i)
        {
            slovnik.put("Autor:"+autori.item(i).getAttributes().getNamedItem("autor_id").getTextContent(), autori.item(i));
        }

        // Do slovn�ku vlo��me v�echny tagy, aby je podle ID bylo mo�n� p�i�adit k z�znam�m
        NodeList tagy = xmlDocument.getElementsByTagName("tag");
        for(int i = 0; i < tagy.getLength(); ++i)
        {
            slovnik.put("Tag:"+tagy.item(i).getAttributes().getNamedItem("tag_id").getTextContent(), tagy.item(i));
        }

        // Vytvo��me seznam uzl� kter� budeme mazat, proto�e NodeList reaguje na zm�ny dokumentu, co� vad� iterov�n� p�es n�j
        ArrayList<Node> smazat = new ArrayList<Node>();

        // Reference na autory u z�znam� nahrad�me cel�m elementem autora s odpov�daj�c�m ID
        NodeList autorrefy = xmlDocument.getElementsByTagName("ref_autor");
        for(int i = 0; i < autorrefy.getLength(); ++i)
        {
            Node autorref = autorrefy.item(i);
            smazat.add(autorref);
            autorref.getParentNode().insertBefore(slovnik.get("Autor:"+autorref.getAttributes().getNamedItem("autor_id").getTextContent()).cloneNode(true), autorref);
        }

        // Reference na tagy u z�znam� nahrad�me cel�m elementem tagu s odpov�daj�c�m ID
        NodeList tagrefy = xmlDocument.getElementsByTagName("ref_tag");
        for(int i = 0; i < tagrefy.getLength(); ++i)
        {
            Node tagref = tagrefy.item(i);
            smazat.add(tagref);
            tagref.getParentNode().insertBefore(slovnik.get("Tag:"+tagref.getAttributes().getNamedItem("tag_id").getTextContent()).cloneNode(true), tagref);
        }

        // Sma�eme elementy referenc�
        for(Node n : smazat)
            n.getParentNode().removeChild(n);

    }
}
