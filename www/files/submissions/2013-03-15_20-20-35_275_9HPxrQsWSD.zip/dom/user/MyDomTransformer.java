/*
 * 1. uprava dokumentu:
 *      zalozeni noveho stitku a jeho prirazeni ke vsem fotografiim
 *      zadane galerie
 * 
 * 2. uprava dokumentu:
 *      odstraneni vybraneho stitku, a to vcetne vsech fotografii,
 *      ktere jej maji aktualne prirazeny
 */

package user;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

/**
 * ASSIGNMENT: Update document to be able to transform input XML document to
 * output document by actions mentioned in comments of transform method.
 */
public class MyDomTransformer {

    private static final String INPUT_FILE = "data.xml";
    private static final String OUTPUT_FILE = "data.out.xml";

    /**
     * Main method
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        try {

            // DocumentBuilderFactory creates DOM parsers
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            // We don't want to validate file
            dbf.setValidating(false);

            // Creating of DOM parser instance
            DocumentBuilder builder = dbf.newDocumentBuilder();

            // Parser processes input file and creates a DOM tree of objects
            Document doc = builder.parse(INPUT_FILE);

            // DOM tree processing
            MyDomTransformer transformer = new MyDomTransformer();
            transformer.transform(doc);

            // TransformerFactory creates an object for DOM serialization
            TransformerFactory tf = TransformerFactory.newInstance();

            // Transformer serializes DOM tree
            Transformer writer = tf.newTransformer();

            // Setting of output file encoding
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            // Run transformation of DOM tree to XML document
            writer.transform(new DOMSource(doc), new StreamResult(new File(OUTPUT_FILE)));


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Process document tree
     *
     * @param doc Document to be parsed
     */
    public void transform(Document document) {
        this.assignNewTagToGallery(document, "Novy stitek", "g1g");
        this.removeTagAndAllAssignedPhotographs(document, "s3s");
    }
    
    /**
     * TASK 1: creates new tag of the given name and assigns it to all photographs of the selected gallery
     */
    private void assignNewTagToGallery(Document document, String newTagName, String galleryId) {
        
        Element tagsWrapper = this.getChild(document.getDocumentElement(), "soubor-stitku");
        List<Element> tags = this.getChilds(tagsWrapper, "stitek");
        
        int maxIdNumber = 0;
        for (Element tag : tags)
        {
            String tagId = tag.getAttributes().getNamedItem("id").getNodeValue();
            int tagIdNumber = Integer.parseInt(tagId.substring(1, tagId.length() - 1));
            if (maxIdNumber < tagIdNumber) {
                maxIdNumber = tagIdNumber;
            }
        }

        Element newTag = document.createElement("stitek");
        newTag.setAttribute("id", String.format("s%ds", maxIdNumber + 1));
        newTag.setAttribute("jmeno", newTagName);
     
        tagsWrapper.appendChild(newTag);
        
        Element gallery = document.getElementById(galleryId);
        
        if (gallery != null) {
            List<Element> photographs = this.getChilds(gallery, "fotografie");

            for (Element photograph : photographs) {
                StringBuilder photographTagsAttribute = new StringBuilder(photograph.getAttribute("stitky"));
                if (photographTagsAttribute.length() > 0) {
                    photographTagsAttribute.append(' ');
                }
                photographTagsAttribute.append(newTag.getAttribute("id"));
                photograph.setAttribute("stitky", photographTagsAttribute.toString());
            }
        }
    }
    
    /**
     * TASK 2: removes tag with the given id including all photographs assigned to it
     */
    private void removeTagAndAllAssignedPhotographs(Document document, String tagId) {
        
        Element tag = document.getElementById(tagId);
        
        if (tag != null) {
            List<Element> galleries = this.getChilds(
                    this.getChild(document.getDocumentElement(), "soubor-galerii"), "galerie");

            for (Element gallery : galleries) {
                for (Element photograph : this.getChilds(gallery, "fotografie")) {
                    if (photograph.getAttribute("stitky").contains(tagId)) {
                        gallery.removeChild(photograph);
                    }
                }
            }

            tag.getParentNode().removeChild(tag);
        }
    }
    
    /**
     * Finds and returns first immediate child of the given element and of the given name, if no suitable
     * child exists, method returns null value
     */
    private Element getChild(Element parent, String name) {
        
        for (Node child = parent.getFirstChild(); child != null; child = child.getNextSibling()) {
            if ((child instanceof Element) && child.getNodeName().equals(name)) {
                return ((Element) child);
            }
        }

        return null;
    }
    
    /**
     * Returns all immediate children of the given element and of the given name, if no suitable
     * children exist, returned list will be empty
     */
    private List<Element> getChilds(Element parent, String name) {
        
        List<Element> list = new ArrayList<Element>();
        
        for (Node child = parent.getFirstChild(); child != null; child = child.getNextSibling()) {
            if ((child instanceof Element) && child.getNodeName().equals(name)) {
                list.add((Element) child);
            }
        }
        
        return list;
    }
}
