/*
 * 1. charakteristika vztazena k atributum:
 *      vypsat tabulku se vsemi v databazi definovanymi stitky a u kazdeho z nich
 *      spocitat pocet jeho uziti pri oznacovani fotografii napric celou databazi
 *
 * 2. charakteristika vztazena k obsahu elementu:
 *      spocitat pocet slov a znaku + prumerny pocet znaku na slovo napric vsemi
 *      popisnymi elementy, ktere se vztahuji bud k jednotlivym fotografiim nebo
 *      k celym galeriim
 * 
 * 3. charakteristika vztazena ke kontextu:
 *      nalezeni nejproduktivnejsiho autora, tj. takoveho, ktery vlastni nejvice
 *      fotografii (tedy je bud primo jejich autorem nebo nemaji primo nastaveneho
 *      autora, ale nachazi se v galerii vlastnene danym autorem) a vypsani vsech
 *      detailu o jeho osobe
 */

package user;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.atomic.AtomicInteger;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 * Main class for SAX parsing
 *
 * @author XML Technologies
 */
public class MySaxHandler extends DefaultHandler {
    
    // TASK 1: keeps usage frequencies of all tags assignable to photographs
    private TreeMap<String, AtomicInteger> tagsFrequencies = new TreeMap<String, AtomicInteger>();
    
    // TASK 2: tells whether this handler is currently inside of some description element or not
    private boolean insideDescriptionElement = false;
    
    // TASK 2: allows to count words and letters of description elements
    private MyWordAndLetterCountingFSM descriptionWordAndLettercounter = new MyWordAndLetterCountingFSM();
    
    // TASK 3: tells whether this handler is currently inside of an author element or not
    private boolean insideAuthorElement = false;
    
    // TASK 3: contains ID or IDREF value of last encountered attribute related to author
    private String lastEncounteredAuthorId = "";
    
    // TASK 3: stores name, email etc. for each author determined by author's id
    private TreeMap<String, StringBuilder> authorDetails = new TreeMap<String, StringBuilder>();
    
    // TASK 3: keeps number of photographs belonging to an appropriate author
    private TreeMap<String, AtomicInteger> authorFrequencies = new TreeMap<String, AtomicInteger>();
    
    // Helper variable to store location of the handled event
    private Locator locator;

    // Path to input file
    private static final String INPUT_FILE = "data.xml";

    /**
     * Main method
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        try {
            
            // Create parser instance
            XMLReader parser = XMLReaderFactory.createXMLReader();

            // Create input stream from source XML document
            InputSource source = new InputSource(INPUT_FILE);

            // Set our custom content handler for handling SAX events (it must implements ContentHandler interface)
            parser.setContentHandler(new MySaxHandler());

            // Process input data
            parser.parse(source);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Sets the locator
     *
     * @param Locator locator location in the file
     */
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Method to handle "document start"
     *
     * @throws SAXException
     */
    public void startDocument() throws SAXException {
        // ...
    }

    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    public void endDocument() throws SAXException {
        
        // TASK 1: print out sorted usage frequency of each tag within all photographs of the database
        System.out.println("TAGS USAGE FREQUENCIES:");

        List<Map.Entry<String, AtomicInteger>> results =
                new ArrayList<Map.Entry<String, AtomicInteger>>(this.tagsFrequencies.entrySet());
        
        Collections.sort(results,
                new Comparator<Map.Entry<String, AtomicInteger>>() {
                    public int compare(Map.Entry<String, AtomicInteger> a, Map.Entry<String, AtomicInteger> b) {
                        int ai = a.getValue().get();
                        int bi = b.getValue().get();
                        if (ai > bi) { // reversed
                            return -1;
                        } else if (ai == bi) {
                            return 0;
                        } else {
                            return 1;
                        }
                    }
                });
        
        for (Map.Entry<String, AtomicInteger> result : results) {
            System.out.println(result.getKey() + ": " + result.getValue() + "x");
        }
        
        // TASK 2: print out some gathered text statistics about all description elements
        System.out.println("\nDESCRIPTION ELEMENT TEXT STATISTICS:");
        System.out.println("number of words: " + this.descriptionWordAndLettercounter.getNumberOfWords());
        System.out.println("number of letters: " + this.descriptionWordAndLettercounter.getNumberOfLetters());
        System.out.println("average number of letters per word: "
            + ((float) this.descriptionWordAndLettercounter.getNumberOfLetters()
                / this.descriptionWordAndLettercounter.getNumberOfWords()));
        
        // TASK 3: prints out info about an author who has the biggest number of pohotographs in the database
        System.out.println("\nDETAILS OF THE MOST PRODUCTIVE AUTHOR:");
        
        int maxFrequency = 0;
        String maxFrequencyAuthorId = null;
        for (Map.Entry<String, AtomicInteger> authorFrequency : this.authorFrequencies.entrySet()) {
            if (authorFrequency.getValue().get() > maxFrequency) {
                maxFrequency = authorFrequency.getValue().get();
                maxFrequencyAuthorId = authorFrequency.getKey();
            }
        }
        
        if (maxFrequencyAuthorId != null) {
            String maxFrequencyAuthorDetails = this.authorDetails.get(maxFrequencyAuthorId).toString();
            if (maxFrequencyAuthorDetails != null) {
                System.out.println(maxFrequencyAuthorDetails);
            } else {
                throw new SAXException("Database id references seem to be mismatched.");
            }
        } else {
            System.out.println("there is none");
        }
    }

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        
        // TASK 1: calculates usage frequency of each tag within all photographs of the database
        if (localName.equals("stitek")) {
            String tagName = atts.getValue("id");
            if (!this.tagsFrequencies.containsKey(tagName)) {
                this.tagsFrequencies.put(tagName, new AtomicInteger(0));
            }
        } else if (localName.equals("fotografie")) {
            String tagsAttribute = atts.getValue("stitky");
            if (tagsAttribute != null) {
                String[] tagsArray = tagsAttribute.split(" ");
                for (String tagName : tagsArray) {
                    if (tagName.matches("^s[0-9]+s$")) {
                        AtomicInteger tagFrequency = this.tagsFrequencies.get(tagName);
                        if (tagFrequency != null) {
                            tagFrequency.incrementAndGet();
                        } else {
                            this.tagsFrequencies.put(tagName, new AtomicInteger(1));
                        }
                    }
                }
            }
        }
        
        // TASK 2: tracks entering some description element
        if (!this.insideDescriptionElement && localName.equals("popis")) {
            this.insideDescriptionElement = true;
        }
        
        // TASK 3: tracks entering an author element
        if (!this.insideAuthorElement && localName.equals("autor")) {
            this.insideAuthorElement = true;
            this.lastEncounteredAuthorId = atts.getValue("id");
        }
        
        // TASK 3: calculates number of photographs belonging to encountered authors
        if (localName.equals("galerie")) {
            this.lastEncounteredAuthorId = atts.getValue("autor");
        } else if (localName.equals("fotografie")) {
            String photographyAuthorId = atts.getValue("autor");
            if (photographyAuthorId == null) {
                photographyAuthorId = this.lastEncounteredAuthorId;
            }
            AtomicInteger authorFrequency = this.authorFrequencies.get(photographyAuthorId);
            if (authorFrequency != null) {
                authorFrequency.incrementAndGet();
            } else {
                this.authorFrequencies.put(photographyAuthorId, new AtomicInteger(1));
            }
        }
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    public void endElement(String uri, String localName, String qName) throws SAXException {
        
        // TASK 2: tracks leaving some description element
        if (this.insideDescriptionElement && localName.equals("popis")) {
            this.insideDescriptionElement = false;
        }
        
        // TASK 3: tracks leaving an author element
        if (this.insideAuthorElement && localName.equals("autor")) {
            this.insideAuthorElement = false;
        }
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    public void characters(char[] chars, int start, int length) throws SAXException {
        
        // TASK 2: count all words and letters inside any description element
        if (this.insideDescriptionElement) {
            this.descriptionWordAndLettercounter.runMachine(chars, start, length);
        }
        
        // TASK 3: gather and serialize all details about authors
        if (this.insideAuthorElement) {
            StringBuilder details = this.authorDetails.get(this.lastEncounteredAuthorId);
            if (details != null) {
                details.append(' ');
                details.append(chars, start, length);
            } else {
                this.authorDetails.put(this.lastEncounteredAuthorId,
                        new StringBuilder(new String(chars, start, length)));
            }
        }
    }

    /**
     * Method to handle " start of namespace declaration"
     *
     * @param prefix Prefix of the namespace
     * @param uri URI of the namespace
     * @throws SAXException
     */
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    /**
     * Method to handle "end of namespace declaration"
     *
     * @param prefix
     * @throws SAXException
     */
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    /**
     * Method to handle "ignoring of whitespaces" Text is in array 'chars' from
     * position ('start') to ('start' + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     * @throws SAXException
     */
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
        // ...
    }

    /**
     * Method to handle "processing instructions"
     *
     * @param target The processing instruction target
     * @param data  The processing instruction data
     * @throws SAXException
     */
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

    /**
     * Method to handle "unprocessed entity"
     *
     * @param name
     * @throws SAXException
     */
    public void skippedEntity(String name) throws SAXException {
        // ...
    }
}

/**
 * TASK 2: class inmplenting finite state machine able to count words and letters of some text
 */
class MyWordAndLetterCountingFSM {
    
    private enum State { OUTSIDE_OF_WORD, INSIDE_OF_WORD }
    private State state = State.OUTSIDE_OF_WORD;
    
    private int wordCounter = 0;
    private int letterCounter = 0;
    
    public int getNumberOfWords() {
        return this.wordCounter;
    }
    
    public int getNumberOfLetters() {
        return this.letterCounter;
    }
    
    public void runMachine(char[] text, int start, int length) throws SAXException {
        for (int i = start, end = (start + length); i < end; ++i)
            this.runMachine(text[i]);
    }
    
    public void runMachine(char symbol) throws SAXException {
        switch (this.state) {
            case OUTSIDE_OF_WORD:
                if (Character.isLetterOrDigit(symbol)) {
                    this.state = State.INSIDE_OF_WORD;
                    this.wordCounter += 1;
                    this.letterCounter += 1;
                }
                break;

            case INSIDE_OF_WORD:
                if (Character.isLetterOrDigit(symbol)) {
                    this.letterCounter += 1;
                } else {
                    this.state = State.OUTSIDE_OF_WORD;
                }
                break;
                
            default:
                throw new SAXException("FSM has reached an undefined state.");
        }
    }
}
