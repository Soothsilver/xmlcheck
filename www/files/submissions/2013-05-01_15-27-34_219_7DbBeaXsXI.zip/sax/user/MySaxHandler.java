package user;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
    
    class Vendor {
        String id;
        String name;
        int numberOfProducts;

        @Override
        public String toString() {
            return id + ": " + name;
        }
    }
    
    class Category {
        String id;
        String name;
        int numberOfProducts;

        @Override
        public String toString() {
            return id + ": " + name;
        }
    }
    
    Map<String, Vendor> vendors = new HashMap<String, Vendor>();
    Map<String, Category> categories = new HashMap<String, Category>();
    
    String vendorId;
    String vendorName;
    
    String productId;
    String productName;
    String maxProductId;
    String maxProductName;
    int maxProductSize;
    
    String categoryId;
    String categoryName;
    
    String currentString = "";

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        if (localName.equals("vendor")) {
            vendorId = attributes.getValue("id");
        }
        
        if (localName.equals("category")) {
            categoryId = attributes.getValue("id");
        }
        
        if (localName.equals("category_ref")) {
            String id = attributes.getValue("id");
            categories.get(id).numberOfProducts++;
        }
        
        if (localName.equals("product")) {
            productId = attributes.getValue("id");
        }
        
        if (localName.equals("vendor_ref")) {
            String id = attributes.getValue("id");
            vendors.get(id).numberOfProducts++;
        }
        
        currentString = "";
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        currentString = currentString.trim();
        
        if (localName.equals("vendor")) {
            Vendor v = new Vendor();
            v.name = vendorName;
            v.id = vendorId;
            vendors.put(vendorId, v);
        }
        
        if (localName.equals("category")) {
            Category c = new Category();
            c.name = categoryName;
            c.id = categoryId;
            categories.put(categoryId, c);
        }
        
        if (localName.equals("name")) {
            vendorName = currentString;
            productName = currentString;
            categoryName = currentString;
        }
        
        if (localName.equals("size")) {
            int size = Integer.parseInt(currentString.replace("MB", "").trim());
            if (size > maxProductSize) {
                maxProductSize = size;
                maxProductId = productId;
                maxProductName = productName;
            }
        }

    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        currentString = currentString + new String(ch, start, length);
    }

    @Override
    public void endDocument() throws SAXException {
        
        String maxKey = null;
        int maxProducts = -1;
        for(Entry<String, Vendor> entry : vendors.entrySet()) {
            String key = entry.getKey();
            Vendor value = entry.getValue();
            
            if (value.numberOfProducts > maxProducts) {
                maxKey = key;
                maxProducts = value.numberOfProducts;
            }
        }
        
        System.out.println("Vyrobce, ktery ma nejvice produktu:");
        System.out.println(vendors.get(maxKey));
        
        System.out.println("Software, ktery ma nejvetsi velikost:");
        System.out.println(maxProductId + ": " + maxProductName + " - " + maxProductSize + " MB");
        
        System.out.println("Kategorie, ktere v sobe nemaji zadne produkty:");
        for(Entry<String, Category> entry : categories.entrySet()) {
            String key = entry.getKey();
            Category value = entry.getValue();
            
            if (value.numberOfProducts == 0) {
                System.out.println(value);
            }
        }
    }
    
    
    
}
