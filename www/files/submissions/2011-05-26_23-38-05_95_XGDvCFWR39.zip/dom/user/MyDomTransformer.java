package user;

//import java.io.File;
import java.util.Stack;

//import javax.xml.parsers.DocumentBuilder;
//import javax.xml.parsers.DocumentBuilderFactory;
//import javax.xml.transform.OutputKeys;
//import javax.xml.transform.Transformer;
//import javax.xml.transform.TransformerFactory;
//import javax.xml.transform.dom.DOMSource;
//import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;


public class MyDomTransformer {

//    private static final String VSTUPNI_SOUBOR = "D:/Programovani/XML/data.xml";
//    private static final String VYSTUPNI_SOUBOR = "D:/Programovani/XML/data_out.xml";
//
//    public static void main(String[] args) {
//
//        try {
//            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
//            dbf.setValidating(false);
//            DocumentBuilder builder = dbf.newDocumentBuilder();
//            Document doc = builder.parse(VSTUPNI_SOUBOR);
//            processTree(doc);
//            TransformerFactory tf = TransformerFactory.newInstance();
//            Transformer writer = tf.newTransformer();
//            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
//            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

    public void transform(Document xmlDocument) {
        Element root = xmlDocument.getDocumentElement();
        reverse(root); 
    }

    private static void reverse(Node root){
        Stack<Node> stack = new Stack<Node>();
        for(Node n = root.getFirstChild(); n!=null; n=n.getNextSibling()){
            stack.add(n);
        }

        while(root.hasChildNodes()){
            root.removeChild(root.getFirstChild());
        }

        for(Node n : stack){
            reverse(n);
        }

        while(!stack.empty()){
            root.appendChild(stack.pop());
        }

    }
}
