package user;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
    // overrides of DefaultHandler methods
    private int numElements,
                attElements,
                depth,
                maxDepth,
                sumDepth,
                numAtts,
                maxElemName,
                sumElemName,
                numTextElems,
                numComplexElems;

    private boolean hasElems;

    @Override
    public void startDocument(){
        numElements = 0;
        attElements = 0;
        depth = 0;
        maxDepth = 0;
        sumDepth = 0;
        numAtts = 0;
        maxElemName = 0;
        sumElemName = 0;
        numTextElems = 0;
        numComplexElems = 0;
        hasElems = false;

    }

    @Override
    public void endDocument(){
        System.out.println("Pocet elementu je: "+numElements);
        System.out.println("Z toho elementu s atributy je: "+attElements);
        System.out.println("Elementu s podelementy je: "+numComplexElems);
        System.out.println("Celkem atributu je: "+numAtts);
        System.out.println("Maximalni� hloubka elementu je: "+maxDepth);
        System.out.println("Prumenra hloubka elementu je: "+sumDepth/numElements);
        System.out.println("Maximalni delka nazvu elementu je: "+maxElemName);
        System.out.println("Prumerna delka nazvu elementu je: "+sumElemName/numElements);
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts){
        numElements++;
        if(atts.getLength()>0) attElements++;
        depth++;
        if(depth>maxDepth) maxDepth = depth;
        numAtts+= atts.getLength();
        if(localName.length()>maxElemName) maxElemName = localName.length();
        sumElemName += localName.length();        
        hasElems = false;
    }


    @Override
    public void endElement(String uri, String localName, String qName){
        sumDepth+= depth;
        depth--;
        if(hasElems) numComplexElems++;
        hasElems = true;
    }

    @Override
    public void characters(char[] ch, int start, int length){
    }

    @Override
    public void processingInstruction(String target, String data){

    }

    @Override
    public void ignorableWhitespace(char[] ch, int start, int lenght){

    }

    @Override
    public void startPrefixMapping(String prefix, String uri){

    }

    @Override
    public void endPrefixMapping(String prefix){

    }

    @Override
    public void skippedEntity(String name){

    }

    @Override
    public void setDocumentLocator(Locator locator){

    }
}
