package user;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.*;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
/**
 *
 * @author gorgi
 */

/*
 * maximální/průměrnou hloubku, počet elementů, počet atributů,
 * maximální/průměrnou délku názvů elementů/atributů, počet elementů s 
 * textovým obsahem/s atributy/s podelementy
 */
public class MySaxHandler extends DefaultHandler{
    int pocetElementu = 0;
    int pocetAtributu = 0;
    int pocetAttributu = 0;
    int pocetSoftwaru = 0;
    int pocetVedenychVyvojaru = 0;
    int pocetTextovychdokumentu = 0;
    List<Integer> delkyElementu;
    List<Integer> delkaAtributu;
    List<String> idJazyku;
    
    /**
     * zacatek xml documentu. Alokujeme pamet pro Datove struktury
     * @throws org.xml.sax.SAXException chyba rozhrani sax
     */
    public void startDocument() throws SAXException {
    	 delkyElementu = new ArrayList<Integer>();
         delkaAtributu = new ArrayList<Integer>();
         idJazyku = new ArrayList<String>();
    }
    
    /**
     * zacatek elementu
     */
    public void startElement(String namespaceURI,String localName, String qName, Attributes atts) throws SAXException {
        /*
         * Pri nacteni elemntu zvysujeme promenou pocetElemntu. Tim ziskame pocet vsech elementu,
         * ktere se nachazeji v dokumentu
         */
        pocetElementu++;
        /*
         * Porovnavame jmeno elementu s retezcem "Software". Ziskame tak
         * pocet elemetu nesouci nazev Software a tim i pocet vsech vedenych softwaru
         * v dokumentu
         */
        if(qName.equals("Software")){  
            pocetSoftwaru++;
        }
        /*
         * Porovnavame jmeno elementu s retezcem "Developer". Ziskame tak
         * pocet elemetu nesouci nazev Developer a tim i pocet vsech vedenych vyvojaru
         * v dokumentu.
         */
        if(qName.equals("Developer")){
            pocetVedenychVyvojaru++;
        }
        /*
         * Do arrayListu pridavame delky nazvu vsech elementu pro pozdejsi vypocty
         */
        delkyElementu.add(qName.length());
       /*
        *Pro kazdy elemt, ktery ma nejake atributy(neni treba osetrovat, pokud ma
         * 0 atributu cyklus se neprovede) nejprve inkremtujeme promenou, ktera
         * pocita pocet atrbutu. Dale pak do arrayListu vkladamedelku tohoto atributu
         * pro pozdejsi vypocet.
        */
         for (int i = 0; i < atts.getLength(); i++) {
              pocetAtributu++;
              delkaAtributu.add(atts.getValue(i).length());
         }
        
        /*
         * Nejprve kontorlujeme zda ma elemnt nejake atributy. Dale pres substring
          * zjistujeme zda se nejedna o id programovaciho jazyka. Pokud ano, pak
          * do arrayListu pridavame id tohoto programovaciho jazyka
         */
        if(atts.getLength() != 0){
          if(atts.getValue(0).substring(0, 3).equals("idJ")){
              if(idJazyku.contains(atts.getValue(0))) return;
              idJazyku.add(atts.getValue(0));
          }
        }    
    }
    /*
     * Overrida metoda characterw
     */
    public void characters(char[] ch, int start, int length) throws SAXException  { 
        String chars = "";
        /*
         * z pole vytvorime jeden string
         */
        for (int i = start; i < start + length; i++){
            chars = chars + ch[i];
        }
        /*
         * zbavyme se bilich znaku
         */
        if ((chars.trim()).length() > 0)
        /*
         * pokud je element neprazdny, jedna se o elemnt s textovym obsahem, 
         * inkremtujem tedy prislusnou promenou
         */
        if(!chars.isEmpty()) pocetTextovychdokumentu++;
        
    } 
    
   /* 
    * Metoda na spocitani prumeru
    */
    public double spoctiPrumer(List<Integer> list){
        int celkem = 0;
        for (int i = 0; i < list.size(); i++) {
            celkem += list.get(i);
        }
        return celkem/list.size();
    }
    
    /*
     * Vypis spocitanych casti dokumentu a vypsani na standardni vystup
     */
    public void endDocument() throws SAXException {        
        System.out.println("Pocet elementu: " + pocetElementu);
        System.out.println("Pocet atributu: " + pocetAtributu);
        System.out.println("Pocet textovych elementu: " + pocetTextovychdokumentu);
        System.out.println("Prumerna delka vsech elemetu: " + spoctiPrumer(delkyElementu));
        System.out.println("Prumerna delka vsech atributu: " + spoctiPrumer(delkaAtributu));
        System.out.println("Pocet vedenych softwaru: " + pocetSoftwaru);
        System.out.println("Pocet vedenych vyvojaru: " + pocetVedenychVyvojaru);
        for (int i = 0; i < idJazyku.size(); i++) {
            System.out.println("id Vedeneho jazyka: " + idJazyku.get(i));
        }
        System.out.println("Pocet vsech vedenych programovacich jazyku: " + idJazyku.size());
   
    }
    
    public static void main(String[] args) {
        String fileName = "data.xml";
        
        try {            
            SAXParserFactory spfactory = SAXParserFactory.newInstance();
            spfactory.setValidating(false);
            
            SAXParser saxparser = spfactory.newSAXParser();
            
            XMLReader xmlreader = saxparser.getXMLReader();
            
            xmlreader.setContentHandler(new MySaxHandler());
            xmlreader.setErrorHandler(new MySaxHandler());
            
            InputSource source = new InputSource(fileName);
            xmlreader.parse(source);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
