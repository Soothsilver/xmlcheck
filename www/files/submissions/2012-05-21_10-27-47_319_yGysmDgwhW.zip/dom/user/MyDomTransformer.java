package user;
import java.io.File;
import javax.xml.parsers.DocumentBuilder; 
import javax.xml.parsers.DocumentBuilderFactory; 

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document; 
import org.w3c.dom.Element;  
import org.w3c.dom.NodeList;
/**
 *
 * @author gorgi
 */

/*
 * obrátit pořadí elementů, převést atributy na elementy, převést elementy s textovým
 * obsahem na atributy, smazat elementy v zadané hloubce/přesahující povolený fan-out/s
 * danou hloubkou, doplnit fan-out na dané minimum, doplnit max. hloubku na dané minimum apod
 */
public class MyDomTransformer {
    
    public void transform (Document xmlDocument) {
        createNewElement(xmlDocument);
        /*
         * Smazani elementu nazev a nasatveni tohoto nazvu do atributu elemntu Software
         */
        for (int i = 0; i < 3; i++) {
            Element element = (Element)xmlDocument.getElementsByTagName("Nazev").item(i);
            Element element2 = (Element)xmlDocument.getElementsByTagName("Software").item(i);
            element2.setAttribute(element.getTagName(), element.getTextContent());
            element.getParentNode().removeChild(element);
        }
        /*
         * Meni prvni dva softwary na placenou verzi
         */
        Element el = (Element)xmlDocument.getElementsByTagName("Licence").item(0);
        el.setAttribute("druh", "placena");
        Element el2 = (Element)xmlDocument.getElementsByTagName("Licence").item(1);
        el2.setAttribute("druh", "placena");
        /*
         * 
         */
        NodeList nl = xmlDocument.getElementsByTagName("Vyrobce");
        for (int i = 0; i < nl.getLength(); i++) {
         
        }
    }
    
    /*
     * Vytvori novy element software
     */
    private void createNewElement(Document doc){
        //nacteni korenoveho elemntu
        Element rootElement = doc.getDocumentElement();
        //Vytvoreni noveho elementi Software
        Element soft = doc.createElement("Software");
        soft.setAttribute("idS", "idS_6"); //nastaveni atributu
        
        //Software ma deti Nazev, Popis, Vyrobce a Licence
        Element nazev = doc.createElement("Nazev");
        nazev.setTextContent("Office");
        
        Element popis = doc.createElement("Popis");
        popis.setTextContent("Zakladni kancelarsky balik");
        
        Element vyrobce = doc.createElement("Vyrobce");
        vyrobce.setAttribute("idV", "idV_4");
        vyrobce.setAttribute("jmenoSpolecnosti", "Acenture");
        vyrobce.setAttribute("sidlo", "Beroun");
        
        Element licence = doc.createElement("Licence");
        licence.setAttribute("druh", "freeware");
        
        
        
        soft.appendChild(nazev);
        soft.appendChild(popis);
        soft.appendChild(vyrobce);
        soft.appendChild(licence);
        rootElement.appendChild(soft);
    }
    
    public MyDomTransformer(){
        String fileName = "data.xml";
        String outFile = "data.out.xml";
        
        try {
            
            //DocumentBuilderFactory vytvoří DOM parsery
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            //vypne validaci
            dbf.setValidating(false);

            //vytvoří si DOM parser
            DocumentBuilder builder = dbf.newDocumentBuilder();

            //parser zpracuje vstupní soubor a vytvoří z něj strom DOM objektů           
            Document doc = builder.parse(fileName);

            //zpracuje DOM strom
            transform(doc);

            TransformerFactory tf = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer = tf.newTransformer();

            //spustí transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(new File(outFile)));


        } catch (Exception e) {
            
            e.printStackTrace();
            
        }
    }
    
    private void list(Document doc) { 
       //Element root = doc.getDocumentElement();
        NodeList list = doc.getChildNodes();
        
       
    }
    
    
    public static void main(String[] args) {
        new MyDomTransformer();
    }
}
