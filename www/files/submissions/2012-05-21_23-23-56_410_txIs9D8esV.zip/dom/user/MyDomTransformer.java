/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

/**
 *
 * @author Pavel
 */
import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class MyDomTransformer {

    Document input;
    Document output;
    Element root;
    Element newRoot;

    public void transform(Document xmlDocument) throws TransformerConfigurationException, TransformerException, ParserConfigurationException {

        this.input = xmlDocument;
        root = input.getDocumentElement();

        prepareDocument();
        browse(newRoot);


    }

    public void prepareDocument() {
// 1) nahrazeni korenoveho elementu elementem Generic.
        newRoot = input.createElement("Generic");
        NodeList childs = root.getChildNodes();
        for (int i = 0; i < childs.getLength(); i++) {
             newRoot.appendChild(childs.item(i).cloneNode(true));
        }
        input.replaceChild(newRoot, root);

    }

    public void browse(Node source) {

        NodeList childs = source.getChildNodes();
        for (int i = 0; i < childs.getLength(); i++) {
            browse(childs.item(i));
        }
// 2) elementy jsou do dokumentu ulozeny v opacnem poradi.
        for (int i = (childs.getLength()-1); (i !=-1); i--) {
           source.appendChild(childs.item(i)); 
        }
        NamedNodeMap map = source.getAttributes();
        if (map != null) {
            if (map.getLength() > 0) {
                for (int j = 0; j < map.getLength(); j++) {
// 3) kazdy atribut je do elementu zaroven zapsan jako podelement.
                    Element child = input.createElement(map.item(j).getNodeName());
                    child.setTextContent(map.item(j).getNodeValue());
                    source.appendChild(child);
                }
            }
        }
    }

}