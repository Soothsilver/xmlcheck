package user;

import java.io.IOException;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {

    int currHeight;
    int totalHeight;
    int sumOfHeights;
    int sumOfAtts;
    int elementsTotal;
    int maxLengthOfAtt;
    int maxLengthOfElement;
    int elementsWithText;
    int elementsWithAtts;
    int maxAtts;
    int longestElementName;
    String elementNames;
    String attNames;

    /*
    
    Třída reprezentující SaxHandler, procházi dokument data.xml a vypisuje 
    informace o dokumentu. Konkrétně se jedná o informace popsané 
    v metodě endDocument().
    
     */
    // konstruktor třídy
 

    @Override
    public void startDocument() {
        System.out.println("------- SAX -------");

    }
// výpis

    @Override
    public void endDocument() {
        System.out.println("Maximální hloubka: " + totalHeight);
        System.out.println("Pocet Elementu: " + elementsTotal);
        System.out.println("Prumerna delka nazvu elementu: " + elementNames.length() / elementsTotal);
        System.out.println("Prumerna delka nazvu atributu: " + attNames.length() / sumOfAtts);
        System.out.println("Prumerna hloubka dokumentu: " + sumOfHeights / elementsTotal);
        System.out.println("Počet elementů s atributy: " + elementsWithAtts);
        System.out.println("Počet atributů: " + sumOfAtts);
        System.out.println("Maximalní délka názvu elementu: " + maxLengthOfElement);
        System.out.println("Maximalní délka názvu atributu: " + maxLengthOfAtt);
        System.out.println("Počet elementů s textem: " + elementsWithText);
    }

    @Override
    public void startElement(String uri, String localName,
            String qName, Attributes attributes) {
        // porovnání max. hloubky
        if (qName.length() > maxLengthOfElement) {
            maxLengthOfElement = qName.length();
        }
        currHeight++;
        sumOfHeights += currHeight;
        elementNames += qName;
        if (currHeight > totalHeight) {
            totalHeight = currHeight;
        }
        // pricteni elementu
        elementsTotal++;


        filler();
        System.out.print("Element " + qName + "\n");



        // práce s atributy

        Attributes atributy = attributes;
        int attCount = atributy.getLength();

        // pokud existuje delsi atribut, nastavi se promena
        if (attCount > maxAtts) {

            maxAtts = attCount;
        }
        if (atributy.getLength() > 0) {
            elementsWithAtts++;
            for (int i = 0; i < atributy.getLength(); i++) {
                filler();
                attNames += atributy.getQName(i);
                sumOfAtts++;
                if (atributy.getQName(i).length() > maxLengthOfAtt) {
                    maxLengthOfAtt = atributy.getQName(i).length();
                }
                System.out.print("Atribut " + atributy.getQName(i) + ": " + atributy.getValue(i) + "\n");
            }
        }

    }

    public void filler() {
        for (int i = 0; i < currHeight; i++) {
            System.out.print(" ");
        }
    }

    @Override
    public void endElement(String uri, String localName,
            String qName) {

        currHeight--;
    }

    @Override
    public void ignorableWhitespace(char[] ch, int start, int length) {
        if (length == 0) {
            elementsWithText++;
        }
    }

    @Override
    public void processingInstruction(String target, String data) {
        System.out.println("Procesní instrukce: " + target + " data: " + data);
    }

    @Override
    public void characters(char[] ch, int start, int length) {
    }
}
