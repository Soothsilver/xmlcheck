 package user;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
 import org.xml.sax.helpers.DefaultHandler;
 
 //Computes the average sellery
 
 public class MySaxHandler extends DefaultHandler {   // Helper variable to store location of the handled event
    Locator locator;
    private String element = "";
    private float sum;
    private int count;
    private String[] bosses;

    /**
     * Sets the locator
     *
     * @param Locator locator location in the file
     */
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Method to handle "document start"
     *
     * @throws SAXException
     */
    @Override
    public void startDocument() throws SAXException {
        System.out.println("Document started.");
    }

    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
        System.out.println(this.sum);
        System.out.println(this.count);
        System.out.println("average sellery: "+(sum/count));
        System.out.println("Document ended");
    }

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        this.element = localName;
        if ("relation".equals(this.element)) {
            for (int i = 0; i < atts.getLength(); i++) {
                System.out.println(atts.getLocalName(i));
                System.out.println(atts.getValue(i));
            }
            System.out.println("_______________________________");
        }
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        if ("sellery".equals(this.element)) {
            String text = new String(chars, start, length);
            Integer sellery = new Integer(text);
//            System.out.println(sellery);
            sum+=sellery;
            count++;
        }
    }

    /**
     * Method to handle " start of namespace declaration"
     *
     * @param prefix Prefix of the namespace
     * @param uri URI of the namespace
     * @throws SAXException
     */
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    /**
     * Method to handle "end of namespace declaration"
     *
     * @param prefix
     * @throws SAXException
     */
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    /**
     * Method to handle "ignoring of whitespaces" Text is in array 'chars' from
     * position ('start') to ('start' + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     * @throws SAXException
     */
    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
        // ...
    }

    /**
     * Method to handle "processing instructions"
     *
     * @param target The processing instruction target
     * @param data  The processing instruction data
     * @throws SAXException
     */
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

    /**
     * Method to handle "unprocessed entity"
     *
     * @param name
     * @throws SAXException
     */
    @Override
    public void skippedEntity(String name) throws SAXException {
        // ...
    }
}