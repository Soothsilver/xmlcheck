package user; 
import org.w3c.dom.Document; 
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
public class MyDomTransformer { 
    public void transform (Document xmlDocument) {        //deleting gender information
        NodeList emps = xmlDocument.getElementsByTagName("employee");
            for (int i = 0; i < emps.getLength(); i++) {
                Node emp = emps.item(i);
                NodeList childs = emp.getChildNodes();
                for (int j = 0; j < childs.getLength(); j++) {
                    Node child = childs.item(i);
                    if (child.getNodeType()==Node.ELEMENT_NODE) {
                        if ("gender".equals(child.getNodeName())) {
                            child.getParentNode().removeChild(child);
                        }
                    }
                }
            }
        
        //removing employee with ID 0002
        Element deletedEmployee = xmlDocument.getElementById("_0002");
        NodeList relations = deletedEmployee.getElementsByTagName("relation");
        for (int i = 0; i < relations.getLength(); i++) {
            //modifying relations of employees from 0002's relations 
            //- from superior relation
            Node superior = relations.item(i).getAttributes().getNamedItem("superior");
            if (superior!=null) {
                String superiorV = superior.getNodeValue();
                String[] supSplit = superiorV.split(" ");
                for (int j = 0; j < supSplit.length; j++) {
                    Element modified = xmlDocument.getElementById(supSplit[j]);
                    NodeList relations2 = modified.getElementsByTagName("relation");
                    for (int k = 0; k < relations2.getLength(); k++) {
                        Node subModified = relations2.item(i).getAttributes().getNamedItem("subordinates");
                        if (subModified != null) {
                            String value = subModified.getNodeValue();
                            value = value.replaceFirst("_0002", "");
                            value = value.replaceFirst("  ", " ");
                            value = value.trim();
                            subModified.setNodeValue(value);
                        }
                    }
                }
            }
            //- from suborinates relation
            Node subordinates = relations.item(i).getAttributes().getNamedItem("subordinates");
            if (subordinates!=null) {
                String subordinatesV = subordinates.getNodeValue();
                String[] subSplit = subordinatesV.split(" ");
                for (int j = 0; j < subSplit.length; j++) {
                    Element modified = xmlDocument.getElementById(subSplit[j]);
                    NodeList relations2 = modified.getElementsByTagName("relation");
                    for (int k = 0; k < relations2.getLength(); k++) {
                        Node supModified = relations2.item(i).getAttributes().getNamedItem("superior");
                        if (supModified != null) {
                            String value = supModified.getNodeValue();
                            value = value.replaceFirst("_0002", "");
                            value = value.replaceFirst("  ", " ");
                            value = value.trim();
                            supModified.setNodeValue(value);
                        }
                    }
                }
            }
        }
        //deleting employee 0002 node
        NodeList employees = xmlDocument.getElementsByTagName("employees");
        for (int i = 0; i < employees.getLength(); i++) {
            employees.item(i).removeChild(xmlDocument.getElementById("_0002"));
        }
    } 
}