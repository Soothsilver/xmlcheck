package user;
import org.xml.sax.helpers.DefaultHandler;

import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;

public class MySaxHandler extends DefaultHandler {

    // Prumerna hloubka dokumentu
    protected int hloubka_prumer = 0;

    // Maximalni hloubka
    protected int hloubka_max = 0;

    // Pocet elementu
    protected int elementy_pocet = 0;

    // Prumerna delka jmena elementu
    protected int elementy_jmeno_prumer = 0;

    // Maximalni delka jmena elementu
    protected int elementy_jmeno_max = 0;

    // Pocet atributu
    protected int atributy_pocet = 0;

    // Prumerna delka jmena atributu
    protected int atributy_jmeno_prumer = 0;

    // Maximalni delka jmena atributu
    protected int atributy_jmeno_max = 0;

    // Aktualni hloubka
    protected int hloubka;


    
    public void startDocument() throws SAXException {
        // ...
    }

    
    public void endDocument() throws SAXException {
        // Dopocitame prumerne hodnoty
        this.hloubka_prumer = this.hloubka_prumer / this.elementy_pocet;
        this.elementy_jmeno_prumer = this.elementy_jmeno_prumer / this.elementy_pocet;
        this.atributy_jmeno_prumer = this.atributy_jmeno_prumer / this.atributy_pocet;
        // Vypis
        System.out.print("Pocet elementu: "); System.out.println(this.elementy_pocet);
        System.out.print("Prumerna delka jmena elementu: "); System.out.println(this.elementy_jmeno_prumer);
        System.out.print("Maximalni delka jmena elementu: "); System.out.println(this.elementy_jmeno_max);
        System.out.print("Prumerna hloubka dokumentu: "); System.out.println(this.hloubka_prumer);
        System.out.print("Maximalni hloubka dokumentu: "); System.out.println(this.hloubka_max);
        System.out.print("Pocet atributu:"); System.out.println(this.atributy_pocet);
        System.out.print("Prumerna delka jmena atributu: "); System.out.println(this.atributy_jmeno_prumer);
        System.out.print("Maximalni delka jmena atributu: "); System.out.println(this.atributy_jmeno_max);
    }

    
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        this.elementy_pocet++;
        this.hloubka++;
        // Porovnani na maximalni hloubku
        if(this.hloubka > this.hloubka_max)
        {
            this.hloubka_max = hloubka;
        }
        // Pricteni za prumernou hloubku
        this.hloubka_prumer += hloubka;
        // Maximalni delka nazvu
        if(this.elementy_jmeno_max < qName.length())
        {
            this.elementy_jmeno_max = qName.length();
        }
        // Pricteni do prumerne delky
        this.elementy_jmeno_prumer += qName.length();
        // Prumerna a maximalni delka jmena atributu
        this.atributy_pocet += atts.getLength();
        for(int i = 0;i < atts.getLength();i++)
        {
            if(this.atributy_jmeno_max < atts.getLocalName(i).length())
            {
                this.atributy_jmeno_max = atts.getLocalName(i).length();
            }
            this.atributy_jmeno_prumer += atts.getLocalName(i).length();
        }
    }
    
    public void endElement(String uri, String localName, String qName) throws SAXException {
        this.hloubka--;
    }

    
    public void characters(char[] ch, int start, int length) throws SAXException {

            String temp = "";
            for(int i = start; i < start + length; i++)
            {
                temp += ch[i];
            }
            temp = temp.replace(',', '.');

    }

    
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
    }

    
    public void endPrefixMapping(String prefix) throws SAXException {
    }

    
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
    }

    
    public void processingInstruction(String target, String data) throws SAXException {
    }

    
    public void skippedEntity(String name) throws SAXException {
    }
}