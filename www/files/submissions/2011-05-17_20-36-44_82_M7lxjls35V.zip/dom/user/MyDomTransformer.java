package user;


import java.io.Console;
import java.io.File;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

public class MyDomTransformer {
public void transform (Document xmlDocument) {
    //transformuje vstupni dokument tak, aby pod korenovym elementem vysel seznam reziseru a pod nimi filmy, ktere natocili
        
        NodeList films = xmlDocument.getElementsByTagName("film");
        NodeList directors = xmlDocument.getElementsByTagName("reziser");
        ArrayList<String> directorsList = new ArrayList<String> ();
        
        //get distinct names of directors
        for (int i = 0; i < directors.getLength(); i++){
            if (!directorsList.contains(directors.item(i).getFirstChild().getNodeValue()))
                directorsList.add(directors.item(i).getFirstChild().getNodeValue());
        }
            
        HashMap<String, Node> slovnik = new HashMap<String, Node>();
        
        //create new node for each director with films he/she made
        for (String director : directorsList){
            slovnik.put(director, xmlDocument.createElement("reziser"));
            Node e = xmlDocument.createElement("jmeno");
            e.appendChild(xmlDocument.createTextNode(director));
            slovnik.get(director).appendChild(e);
            for (int i = 0; i < films.getLength(); i++){
                Node r = films.item(i).getFirstChild();
                while (!r.getNodeName().equalsIgnoreCase("obsazeni")) r = r.getNextSibling();
                r = r.getFirstChild();
                while (!r.getNodeName().equalsIgnoreCase("reziser")) r = r.getNextSibling();
                
                if (!r.getFirstChild().getNodeValue().equalsIgnoreCase(director)) continue;
                
                slovnik.get(director).appendChild(films.item(i).cloneNode(true));
            }
        }
        
        Node rodic = xmlDocument.getFirstChild();
        while (!rodic.getNodeName().equalsIgnoreCase("databaze")) rodic = rodic.getNextSibling();
        
        for (String s : slovnik.keySet()){
            rodic.appendChild(slovnik.get(s));
        }
        
        //deleting unusable nodes
        NodeList nl = xmlDocument.getElementsByTagName("filmy");
        rodic.removeChild(nl.item(0));
        nl = xmlDocument.getElementsByTagName("hodnoceni");
        rodic.removeChild(nl.item(0));
        nl = xmlDocument.getElementsByTagName("komentare");
        rodic.removeChild(nl.item(0));
        
        nl = xmlDocument.getElementsByTagName("obsazeni");
        for (int i = 0; i < nl.getLength(); i++){
            Node odstranit = nl.item(i).getFirstChild();
            while (!odstranit.getNodeName().equals("reziser")) odstranit = odstranit.getNextSibling();
            nl.item(i).removeChild(odstranit);
        }
  }
}