package user;

import org.w3c.dom.*;

public class MyDomTransformer 
{
	public void transform (Document xmlDocument) 
	{
		NodeList elements = xmlDocument.getElementsByTagName ("*");
		for (int i = 0; i < elements.getLength (); i++)
		{
			Element element = (Element) elements.item (i);
			while (element.hasAttributes ())
			{
				Attr attribute = element.removeAttributeNode ((Attr) element.getAttributes ().item (0));
				Element attributeElement = xmlDocument.createElement (attribute.getName ());
				attributeElement.appendChild (xmlDocument.createTextNode (attribute.getValue ()));
				element.appendChild (attributeElement);
			}
		}
	}
}