package user;

import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler 
{
	private int _currentDepth = 0;
	private int _elementsProcessed = 0;
	private double _averageDepth = 0;
	
	public void startElement (String uri, String localName, String qName, Attributes atts) throws SAXException 
    {
		System.out.println ("Processing element '" + qName + "' with depth '" + _currentDepth + "'.");
		_averageDepth = ((_averageDepth * _elementsProcessed) + _currentDepth) / (++_elementsProcessed);
		_currentDepth++;
    }
    
    public void endElement (String uri, String localName, String qName) throws SAXException 
    {
		_currentDepth--;
    }
	
	public void endDocument () throws SAXException 
    {
   		System.out.println ("Average depth of an element in the input XML document is: " + _averageDepth);
    }
}
