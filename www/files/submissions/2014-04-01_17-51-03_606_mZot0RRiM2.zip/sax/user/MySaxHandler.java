package user;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;


public class MySaxHandler extends DefaultHandler {
    
    /*
     * Three examples:
     * 1. Element content -> Example one -> count average age from text content
     * 2. Attributes content -> Example two -> get Disciplines from Olympic games, where attributes = "Summer" && "2012"
     * 3. Context -> get Sportsman, who are not referenced in Dopping message
     * 
     * 
     */

    // Helper variable to store location of the handled event
    
    Locator locator;
    
    //1.********Prints average age of all sportsman*********************************
    //1.1**************************Total SUM of all sportsmen age*******************
    
    double totalAge = 0;
    
    //1.2**************************Total sportsmen count****************************
    
    int sportsmanCount = 0;
    
    //1.3**********Handler is inside element age************************************
    
    boolean isAge;
    
    //2.**********Prints disciplines from Summer Olympics 2012**********************
    //2.1**Handler is inside element Olympics with attribues:
    // a) type = "Summer"
    // b) year = "2012"
    
    boolean isSummer2012;
    
    //2.2**********List of disciplines on Summer Olympiscs 2012*********************
    
    ArrayList<String> disciplinesSummer2012 = new ArrayList<>();
    
    //3.**Prints surname of athletes on Summer Olympics 2012 who didnt use dopping**
    //3.1*******************Handler is inside element Sportsman*********************
    
    boolean isSportsman;
    
    //3.2*******************Handler is inside element Surname***********************
    
    boolean isSurname;
    
    //3.3************Stores id of proceeded athlete*********************************
    
    String manID;
    
    //3.4************List of all sportsmen on Summer Olympics 2012******************
    
    Map<String, String> sportsmenSummer2012 = new HashMap<>();
    
    //3.5************List of sportmen IDs who use dopping on Summer 2012 Olympics***
    
    ArrayList<String> doppingSummer2012 = new ArrayList<>();    
    /**
     * Sets the locator
     *
     * @param Locator locator location in the file
     */
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Method to handle "document start"
     *
     * @throws SAXException
     */
    @Override
    public void startDocument() throws SAXException {
        //
    }

    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
        
        //*********************Prints average age***********************************
        
        System.out.println("Average age = "+totalAge/sportsmanCount);
        System.out.println("\n**************************************************************\n");
        System.out.println("Disciplines on Summer Olympics 2012:");
        
        //**********************Prints disciplines on Summer Olympics 2012**********
        
        for (String disc : disciplinesSummer2012) {
            System.out.println(disc);
        }
        System.out.println("\n**************************************************************\n");
        System.out.println("Sportsmen who were not on dopping list on Summer Olympics 2012:");
        
        //*********************Prints sportsmen on summer 2012 who didnt use dopping
        
        for (String str: sportsmenSummer2012.keySet()) {
               if(!doppingSummer2012.contains(str)) System.out.println(sportsmenSummer2012.get(str));
            }
    }

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        //******If handler is in element Olympiade, Summer 2012, sets true**********
        
        if(localName.equals("Olympiade")){
             if(atts.getValue("type").equals("Summer") && atts.getValue("year").equals("2012")){
                 isSummer2012 = true;
             }
        }
        //******If handler is in element Discipline, Summer 2012, adds to list******
        
        if(localName.equals("Discipline") && isSummer2012){
            disciplinesSummer2012.add(atts.getValue("name"));
        }
        
        //******If handler is in element Sportsman, Summer 2012, set true***********
        //*******Have to rember sportsman id to make Pair<id, surname>**************
        
        if(localName.equals("Sportsman") && isSummer2012){
            isSportsman = true;
            manID = atts.getValue("id");
        }
        
        //******If handler is in element Surname, Summer 2012, set true*************
        
        if(localName.equals("Surname") && isSummer2012){
            isSurname = true;
        }
        
        //If handler is in element Dopping message, Summer 2012, add Sportsman ID to List
        
        if(localName.equals("DoppingMessage") && isSummer2012){
            doppingSummer2012.add(atts.getValue("sportsman_ID"));
        }
        
        //If handler is in element Age, set true, increment Sportsmen count********* 
        
        if(localName.equals("Age")){
            sportsmanCount++;
            isAge = true;
        }  
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        
        //*****************Handler is out of element********************************
        
         if(isAge) isAge = false;
         if(localName.equals("Olympiade")) isSummer2012 = false;
         if(localName.equals("Sportsman")) isSportsman = false;
         if(localName.equals("Surname")) isSurname = false;
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        
        //******************Parse age from text content*****************************
        
        if(isAge){
            totalAge += Integer.parseInt(new String(chars, start, length));
        }
        
        //********************Match surname with sportsman ID***********************
        
        if(isSurname){
            sportsmenSummer2012.put(this.manID, new String(chars, start, length));
        }
    }

    /**
     * Method to handle " start of namespace declaration"
     * @param prefix Prefix of the namespace
     * @param uri URI of the namespace
     * @throws SAXException
     */
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    /**
     * Method to handle "end of namespace declaration"
     *
     * @param prefix
     * @throws SAXException
     */
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    /**
     * Method to handle "ignoring of whitespaces" Text is in array 'chars' from
     * position ('start') to ('start' + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     * @throws SAXException
     */
    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
        // ...
    }

    /**
     * Method to handle "processing instructions"
     *
     * @param target The processing instruction target
     * @param data The processing instruction data
     * @throws SAXException
     */
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

    /**
     * Method to handle "unprocessed entity"
     *
     * @param name
     * @throws SAXException
     */
    @Override
    public void skippedEntity(String name) throws SAXException {
        // ...
    }
}

