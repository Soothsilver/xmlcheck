/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author Grim
 */
public class MyDomTransformer {

    public static final String PLATFORM_PC = "PLATFORM_PC";
    public static final String PLATFORM_PS3 = "PLATFORM_PS3";
    public static final String PLATFORM_PS4 = "PLATFORM_PS4";
    public static final String PLATFORM_X360 = "PLATFORM_X360";
    public static final String PLATFORM_XONE = "PLATFORM_XONE";
    public static final String PLATFORM_OSX = "PLATFORM_OSX";

    private Document doc;

    public void transform(Document doc) {
        this.doc = doc;
        //adding new game to document
        doc.getElementsByTagName("games").item(0).appendChild(createNewTestGame());

        // removes specified platforms and all references to them(requirements, platformreft). 
        //after that if there is a game without any platform also removes that game
        //Pole platforem na odstraneni
        String platformsToDelete[] = {PLATFORM_OSX, PLATFORM_PC};
        deletePlatformsAndAllReferences(platformsToDelete);
    }

    public void deletePlatformsAndAllReferences(String[] platformIDs) {
        for (String s : platformIDs) {
            deletePlatformAndAllReferences(s);
        }
    }

    public void deletePlatformAndAllReferences(String platformID) {
        List<Node> nodesToDelete = new ArrayList<Node>();

        NodeList platforms = doc.getElementsByTagName("platform");
        //delete platforms
        for (int i = 0; i < platforms.getLength(); i++) {
            if (platforms.item(i).getAttributes().getNamedItem("platformID").getTextContent().equals(platformID)) {
                nodesToDelete.add(platforms.item(i));
            }
        }

        //delete platform referencesfromGames
        platforms = doc.getElementsByTagName("platformRef");
        //delete platforms
        for (int i = 0; i < platforms.getLength(); i++) {
            if (platforms.item(i).getAttributes().getNamedItem("platformRef").getTextContent().equals(platformID)) {
                nodesToDelete.add(platforms.item(i));
            }
        }

        //delete requirements referencing this platform
        platforms = doc.getElementsByTagName("requirement");
        //delete platforms
        for (int i = 0; i < platforms.getLength(); i++) {
            if (platforms.item(i).getAttributes().getNamedItem("forPlatform").getTextContent().equals(platformID)) {
                nodesToDelete.add(platforms.item(i));
            }
        }
        for (Node n : nodesToDelete) {
            n.getParentNode().removeChild(n);
        }
        deleteGamesWithoutPlatform();
    }

    public void deleteGamesWithoutPlatform() {
        List<Node> nodesToDelete = new ArrayList<Node>();

        NodeList platforms = doc.getElementsByTagName("platformRefs");
        for (int i = 0; i < platforms.getLength(); i++) {
            int noOfRefs = 0;
            NodeList platformRefsNodes = platforms.item(i).getChildNodes();
            for (int j = 0; j < platformRefsNodes.getLength(); j++) {
                if (platformRefsNodes.item(j).getNodeName().equals("platformRef")) {
                    noOfRefs++;
                }
            }
            if (noOfRefs <= 0) {
                nodesToDelete.add(platforms.item(i).getParentNode());
            }
        }
        for (Node n : nodesToDelete) {
            n.getParentNode().removeChild(n);
        }
    }

    //Creates new TestGame using the createNewGame method
    public Element createNewTestGame() {
        //Just preparing variables for new game, creation is on the last line.
        String gameID = "GAME_000011";
        boolean forChildren = false;
        String czechTitle = "GTA V";
        String originalTitle = "Grand Theft Auto V";
        String[] platforms = {PLATFORM_PS3, PLATFORM_X360};
        String description = "Dockame se nejvetsi herni mapy, dosud nejvetsiho poctu dopravnich prostredku, "
                + "zbrani a nejpropracovanejsiho pribehu. Velkym lakadlem je take hra vice hracu, a moznost " 
                + "hrat za vice charakteru, ktera se v patnactilete historii znacky objevuje uplne poprve. " 
                + "Hrac bude moct prepinat mezi Michaelem, Franklinem a Trevorem. Kazda z postav ma sva " 
                + "specifika a hraje se za ni jinak. Samozrejmosti bude takrka dokonale graficke zpracovani " 
                + "a propracovany funkcni svet.";
        String author = "hlavavi1";

        //calling the game creation method with set variables.
        return createNewGame(gameID, forChildren, czechTitle, originalTitle, platforms, description, null, author);
    }

    //Creation of a new Game
    public Element createNewGame(String gameId, boolean childFriendly, String titleCzech,
            String titleOriginal, String platforms[], String description,
            Node requirement[], String author) {
        //creation of game element
        Element game = doc.createElement("game");
        game.setAttribute("gameID", gameId);
        if (childFriendly) {
            game.setAttribute("childrenFriendly", "yes");
        } else {
            game.setAttribute("childrenFriendly", "no");
        }

        //adding czech title
        Element titleCzechElement = doc.createElement("title_czech");
        titleCzechElement.setTextContent(titleCzech);
        game.appendChild(titleCzechElement);

        //adding original title
        Element titleOriginalElement = doc.createElement("title_original");
        titleOriginalElement.setTextContent(titleOriginal);
        game.appendChild(titleOriginalElement);

        //Adding supported platforms
        Element platformRefs = doc.createElement("platformRefs");
        for (String s : platforms) {
            Element platformRef = doc.createElement("platformRef");
            platformRef.setAttribute("platformRef", s);
            platformRefs.appendChild(platformRef);
        }
        game.appendChild(platformRefs);

        //Adding Description
        Element descriptionElement = doc.createElement("description");
        descriptionElement.setTextContent(description);
        game.appendChild(descriptionElement);

        //Adding ReQuirements
        Element requirements = doc.createElement("requirements");
        if (requirement != null && requirement.length > 0) {
            for (Node n : requirement) {
                requirements.appendChild(n);
            }
        }
        game.appendChild(requirements);

        //Adding LastModifies
        Element lastModifiedBy = doc.createElement("lastModifiedBy");
        Date now = new Date();
        DateFormat df = new SimpleDateFormat("dd.MM.yyyy");
        lastModifiedBy.setAttribute("on", df.format(now));
        lastModifiedBy.setTextContent(author);
        game.appendChild(lastModifiedBy);

        return game;
    }
}
