/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Stack;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {

    private Locator locator;
    private Stack<String> currentElement;
    private HashMap<String, Integer> platformsStatistics;
    private double sizeSum;
    private int countSum;
    private List<Game> games;
    private Game game;

    public MySaxHandler() {
        currentElement = new Stack<String>();
        platformsStatistics = new HashMap<String, Integer>();
        sizeSum = 0;
        countSum = 0;
        games = new ArrayList<Game>();
    }

    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    @Override
    public void startDocument() throws SAXException {

    }

    @Override
    public void endDocument() throws SAXException {
        printPlatformStatistics();
        printAverageGameSize();
        printChildFriendlyGamesOnOSX();
    }
    private void printChildFriendlyGamesOnOSX(){
        System.out.println("---------------------Mac OSX hry pro deti---------------------");
        for(Game g : games){
            if(g.isChildFiendlyAndSupportsOSX()){
                System.out.println(g.getName());
            }
        }
        System.out.println("--------------------------------------------------------------");
        System.out.println();
    
    }
    private void printPlatformStatistics() {
        List<Entry<String, Integer>> platforms = new ArrayList<Entry<String, Integer>>(platformsStatistics.entrySet());
        Collections.sort(platforms, new Comparator<Entry<String, Integer>>() {

            public int compare(Entry<String, Integer> o1, Entry<String, Integer> o2) {
                if (o1.getValue() < o2.getValue()) {
                    return 1;
                }
                if (o1.getValue() > o2.getValue()) {
                    return -1;
                }
                return 0;
            }
        });
        /*
        platforms.sort(new Comparator<Entry<String, Integer>>() {

            public int compare(Entry<String, Integer> o1, Entry<String, Integer> o2) {
                if (o1.getValue() < o2.getValue()) {
                    return 1;
                }
                if (o1.getValue() > o2.getValue()) {
                    return -1;
                }
                return 0;
            }
        });
        */
        System.out.println("-------------------Nejpouzivanesi Platformy-------------------");
        for (Entry<String, Integer> entry : platforms) {
            String space = "";
            for (int i = 54; i > entry.getKey().length(); i--) {
                space += " ";
            }
            System.out.println(entry.getKey() + space + "Her: " + entry.getValue());
        }
        System.out.println("--------------------------------------------------------------");
        System.out.println();
    }

    private void printAverageGameSize() {
        System.out.println("--------------------Prumerna velikost hry---------------------");
        double number = ((double) (int) (sizeSum / countSum * 100)) / 100;
        System.out.println("Prumerna velikost na Disku                           " + number + "GB");
        System.out.println("--------------------------------------------------------------");
        System.out.println();
    }

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override

    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        currentElement.push(localName);
        if (localName.equals("platformRef")) {
            String platform = atts.getValue("platformRef");
            Integer uses = platformsStatistics.get(platform);
            if (uses == null) {
                uses = 0;
            }
            uses++;
            platformsStatistics.put(platform, uses);
        }
        if (localName.equals("game")) {
            game = new Game();
            if (atts.getValue("childrenFriendly").equals("yes")) {
                game.setChildFriendly(true);
            } else {
                game.setChildFriendly(false);
            }
        }
        if (localName.equals("platformRef")) {
            if (atts.getValue("platformRef").equals("PLATFORM_OSX")) {
                game.setSupportsOSX(true);
            }
        }
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (!currentElement.pop().equals(localName)) {
            throw new SAXException("Spatne uzavreni");
        }
        if (localName.equals("game")) {
            games.add(game);
            game = null;
        }

    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        String content = "";
        for (int i = start; i < start + length; i++) {
            content += chars[i];
        }
        if (currentElement.peek().equals("space")) {
            content = content.replace(',', '.');
            content = content.replaceAll("[^\\d.]", "");
            sizeSum += Double.parseDouble(content);
            countSum++;
        }
        if (currentElement.peek().equals("title_czech")) {
            game.setName(content.trim());
        }
    }

    class Game {

        private String name;
        private boolean childFriendly = false;
        private boolean supportsOSX = false;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public boolean isChildFiendlyAndSupportsOSX() {
            return isChildFriendly() && isSupportsOSX();
        }

        public boolean isChildFriendly() {
            return childFriendly;
        }

        public void setChildFriendly(boolean childFriendly) {
            this.childFriendly = childFriendly;
        }

        public boolean isSupportsOSX() {
            return supportsOSX;
        }

        public void setSupportsOSX(boolean supportsOSX) {
            this.supportsOSX = supportsOSX;
        }

    }
}
