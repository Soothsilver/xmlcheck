package user;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created with IntelliJ IDEA. User: vita Date: 18.3.13 Time: 22:12 To change this template use File
 * | Settings | File Templates.
 */
public class MySaxHandler extends DefaultHandler{


  public static void main(String[] args)
  {

    // Cesta ke zdrojovému XML dokumentu
    String sourcePath = "data.xml";

    try
    {

      XMLReader parser = XMLReaderFactory.createXMLReader();
      InputSource source = new InputSource(sourcePath);
      parser.setContentHandler(new MySaxHandler());
      parser.parse(source);

    } catch (Exception e)
    {

      e.printStackTrace();

    }

  }

         ArrayList<Integer> hraci = new ArrayList();
         ArrayList<String> loga = new ArrayList<String>();
         ArrayList<String> datumy = new ArrayList<String>();
         Map<String, Integer> pozice = new HashMap<String,Integer>();
         String pointer;

  @Override
  public void startElement(String uri, String localName, String qName, Attributes attributes)
      throws SAXException
  {

    pointer = localName;
    if(localName.equals("HRAC")){
      for(int i = 0; i< attributes.getLength(); i++){
        if(attributes.getLocalName(i).equals("VEK")){
          hraci.add(Integer.parseInt(attributes.getValue(i)));
        }
        if(attributes.getLocalName(i).equals("POZICE")){
          if(pozice.containsKey(attributes.getValue(i))){
            pozice.put(attributes.getValue(i),(pozice.get(attributes.getValue(i))+1));
          } else{
            pozice.put(attributes.getValue(i),1);
          }
        }
      }
    }

    if(localName.equals("ZAPAS")){

      for(int i = 0; i< attributes.getLength(); i++){
        if(attributes.getLocalName(i).equals("DATUM")){
          datumy.add(attributes.getValue(i));
        }
      }
    }




  }

  StringBuilder sb = new StringBuilder();
  @Override
  public void characters(char[] ch, int start, int length) throws SAXException
  {

    if(pointer.equals("LOGO_NA_DRESU")){
    for(int i = start; i< start+length; i++){
      sb.append(ch[i]);
    }
    loga.add(sb.toString());
    sb.delete(0,sb.length());
    }

  }

  @Override
  public void endDocument() throws SAXException
  {
    String [] pozice = {"SMEC","BLOK","NAHRAVKA","LIB","UNIVERZAL"};

    int sum = 0;
    int _25 = 0;
    int pocet = 0;

    for(int a : hraci){
      sum += a;
      if(a >= 25) _25++;
    }

    System.out.println(String.format("Prumerny vek hracu je: %.2f",(sum/(float)hraci.size())));
    System.out.println(String.format("Pocet hracu s vekem 25 a vic: %d",_25));
    System.out.println("Data odehranych zapasu: "+ datumy.toString());
    System.out.println("Loga na potisk dresu:" + loga.toString());

    System.out.println("Pocet hracu na pozicich: ");
    for(int i = 0; i<pozice.length;i++){
      pocet = this.pozice.get(pozice[i]) == null? 0:this.pozice.get(pozice[i]);
      System.out.println(pozice[i] +" "+pocet);
    }


  }
}


