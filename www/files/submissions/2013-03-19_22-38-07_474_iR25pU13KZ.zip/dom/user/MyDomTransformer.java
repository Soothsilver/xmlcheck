package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.File;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

/**
 * Created with IntelliJ IDEA. User: vita Date: 18.3.13 Time: 13:32 To change this template use File
 * | Settings | File Templates.
 */
public class MyDomTransformer
{

public static String INPUT_FILE = "data.xml";
  public static String OUTPUT_FILE = "data_out.xml";



  public static  void transform(Document xmlDocument)
  {

          novyHrac(xmlDocument,"Josef","Con",22,"_1","NAHRAVAC");
          novySponzor(xmlDocument,"Zahradni technika",10000000,"Pro vaci zahradu");
          smazSponzora(xmlDocument);

  }


  public static void novyHrac(Document doc,String jmeno, String prijmeni, int vek, String tym, String pozice)
  {
    NodeList hraci = doc.getElementsByTagName("HRAC");
    System.out.println("Pocet hracu: "+hraci.getLength());
    String nextId = "_"+(hraci.getLength()+1);


    Element newElement = doc.createElement("HRAC");
    newElement.setAttribute("JMENO",jmeno);
    newElement.setAttribute("PRIJMENI",prijmeni);
    newElement.setAttribute("VEK",Integer.toString(vek));
    newElement.setAttribute("TYM",tym);
    newElement.setAttribute("ID_HRACE",nextId);
    newElement.setAttribute("POZICE",pozice);

    NodeList parent = doc.getElementsByTagName("HRACI");

    if(parent.getLength() != 0){
      parent.item(0).appendChild(newElement);
    }
    else{
      Element e = doc.createElement("HRACI");
      doc.getDocumentElement().appendChild(e);
      e.appendChild(newElement);
    }

  }


  public static void novySponzor(Document doc, String NAZEV, int ROCNI_CASTKA,String LOGO){
    String newId = "_400"+(doc.getElementsByTagName("SPONZOR").getLength()+1);
    Element e = doc.createElement("SPONZOR");
    e.setAttribute("NAZEV",NAZEV);
    e.setAttribute("ID_SPONZORA",newId);
    e.setAttribute("ROCNI_CASTKA",Integer.toString(ROCNI_CASTKA));
    Element logo = doc.createElement("LOGO_NA_DRESU");
    logo.setTextContent(LOGO);
    e.appendChild(logo);

    NodeList parent = doc.getElementsByTagName("SPONZORI");
    if(parent.getLength() != 0){
      parent.item(0).appendChild(e);
    }
    else{
       Element sp = doc.createElement("SPONZORI");
      doc.getDocumentElement().appendChild(sp) ;
      sp.appendChild(e);
    }
  }

  public static void smazSponzora(Document doc){
    int castka = 150000;
    NodeList sponzori = doc.getElementsByTagName("SPONZOR");

    for(int i = 0; i < sponzori.getLength();i++){
      Node n = sponzori.item(i);
      for(int j = 0;j <n.getAttributes().getLength(); j++){
        if(n.getAttributes().item(j).getNodeName().equals("ROCNI_CASTKA")){
          int tmp = Integer.parseInt(n.getAttributes().item(j).getNodeValue());
          if(tmp < castka) n.getParentNode().removeChild(n);

        }
      }
    }
  }

  public static void main(String[] args)
  {

    try{

    DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
    dbf.setValidating(false);
    DocumentBuilder builder = dbf.newDocumentBuilder();
    Document doc = builder.parse(INPUT_FILE);


    transform(doc);


    TransformerFactory tf = TransformerFactory.newInstance();
    Transformer writer = tf.newTransformer();
    writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
    writer.transform(new DOMSource(doc), new StreamResult(new File(OUTPUT_FILE)));


  } catch (Exception e)
  {

    e.printStackTrace();

  }
  }

}
