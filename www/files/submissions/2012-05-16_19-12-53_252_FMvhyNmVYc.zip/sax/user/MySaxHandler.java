/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

/**
 *
 * @author EHead
 */
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
    
    // Statisticke promenne
    private int elementCount, 
            maxFanout, 
            attElementCount, 
            maxTagNameLength,
            minTagNameLength;
    
    private String maxTagName = null;
    private String minTagName = null;
    
    // Stavove promenne
    private int currentFanout;
    
    
    @Override
    public void startDocument(){
        // Start promennych
        elementCount = 0;
        maxFanout = 0;
        attElementCount = 0;
        maxTagNameLength = 0;
        minTagNameLength = Integer.MAX_VALUE;
        
        currentFanout = 0;
    }
    
    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes){
        currentFanout++;
        elementCount++;
        
        if(attributes.getLength() > 0){
            attElementCount++;
        }
        
        if(localName.length() > maxTagNameLength){
            maxTagNameLength = localName.length();
            maxTagName = localName;
        }
        
        if(localName.length() < minTagNameLength){
            minTagNameLength = localName.length();
            minTagName = localName;
        }
    }
    
    @Override
    public void endElement(String uri, String localName, String qName){
        if(currentFanout > maxFanout){
            maxFanout = currentFanout;
        }
        currentFanout--;
        
    }
    
    @Override
    public void endDocument(){
        // Hotovo - vystup
        System.out.println("Pruchod dokumentu je kompletni.");
        System.out.println("Statistiky:");
        System.out.println("Pocet elementu: "+elementCount);
        System.out.println("Elementy s atributy: "+attElementCount+" ("+(attElementCount/(elementCount/100.0))+"%)");
        System.out.println("Maximalni hloubka: "+maxFanout);
        System.out.println("Nejmensi pocet znaku v nazvu elementu: "+minTagNameLength+" ("+minTagName+")");
        System.out.println("Nejvetsi pocet znaku v nazvu elementu: "+maxTagNameLength+" ("+maxTagName+")");
        
    }
}
