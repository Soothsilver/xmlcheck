/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedList;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer {

    public void transform(Document xmlDocument) {
        // Provedu rekurzivni serazeni vsech elementu podle jejich ID, pokud ho maji
        sortChildrenById(xmlDocument.getDocumentElement(), true);
    }

    private void sortChildrenById(Element e, boolean recursive) {
        //System.out.println("Prochazim element: "+e.getTagName());
        NodeList children = null;
        if (e.hasChildNodes()) {
            // Pokud ma element potomky, tak je ziskam
            children = e.getChildNodes();
        } else {
            //System.out.println("Nema potomky");
            return;
        }
        // Rozdelim potomky podle nazvu tagu
        LinkedList<NodeList> sortedChildren = new LinkedList<NodeList>();
        HashSet<String> usedTags = new HashSet<String>();
        for (int i = 0; i < children.getLength(); i++) {
            //System.out.println("Prochazim poduzel");
            Node currentNode = children.item(i);
            if (currentNode.getNodeType() != Node.ELEMENT_NODE) {
                //System.out.println("Neni to element");
                // Uzly ktere nejsou elementy dokuentu nas nezajimaji
                continue;
            }
            Element currentElement = (Element) currentNode;
            String currentTag = currentElement.getTagName();
            //System.out.println("Je to element: "+currentElement.getTagName());
            if (!usedTags.contains(currentTag)) {
                //System.out.println("Nazev je novy");
                // Pokud jsem jeste nenarazil na tento tag a tag ma atribut id, tak vsechny pridam
                    usedTags.add(currentTag);
                    sortedChildren.add(e.getElementsByTagName(currentTag));
            }else{
                //System.out.println("Nazev je stary");
            }
        }

        // Mam seznam vsech potomku typu element, roztrizene podle nazvu

        if (sortedChildren.isEmpty()) {
            //System.out.println("Nemam zadne podelementy");
            return;
        }
        for (NodeList currentNodes : sortedChildren) {
            //System.out.println("Prochazim seznam podle jmena");
            Element[] elements = new Element[currentNodes.getLength()];
            // Naplnim pole
            for(int i = 0; i < elements.length; i++){
                elements[i] = (Element) currentNodes.item(i);
            }
            // Seradim pole
            Arrays.sort(elements, new idComparator());
            
            // Prvky pole nejdrive odstranim a pak je pridam na konec
            for(int i = 0; i< elements.length; i++){
                if(recursive){
                    //System.out.println("Volam rekurzi");
                    //System.out.println("");
                    // Pro rekurzivni prubeh nejdrive seradim potomky
                    sortChildrenById(elements[i],true);
                }
                //System.out.println("Pridavam prvek na konec");
                e.appendChild(elements[i]);
            }
        }


    }
    
    private class idComparator implements Comparator {

        public int compare(Object o1, Object o2) {
            // Budu slepe predpokadat spravne tridy
            Element e1 = (Element) o1;
            Element e2 = (Element) o2;
            
            String id1 = null;
            String id2 = null;
            
            if(e1.hasAttribute("id")){
                id1 = e1.getAttribute("id");
            }
            if(e2.hasAttribute("id")){
                id2 = e2.getAttribute("id");
            }
            
            // Okrajove pripady pri neexistenci atributu
            // Prvky bez attributu budu radit vzdy na konec
            
            if(id1 == null && id2 == null){
                return 0;
            }
            
            if(id1 == null){
                return 1;
            }
            
            if(id2 == null){
                return -1;
            }
            
            // Oba prvky urcite maji attribut. Vratim porovnani hodnot atributu
            return id1.compareTo(id2);
        }
        
    }
}
