package user;

import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Tento handler pocita statistiky nad data.xml.
 * Spocita, kolko % pouzivatelov, ktori pisu komentare do diskusii,
 * pouziva android a iOS.
 *
 * Tak isto spocita popularnost webovych prehliadacov, so zameranim
 * na chrome a firefox.
 */
public class MySaxHandler extends DefaultHandler {

    /**
     * Trieda obsahujuca informacie o jednom clanku.
     * Budeme ratat pocet prispevkov v diskusiach, ktore su bud
     * z iOS alebo z Androidu.
     */
    private class Article {

        public static final double STO_PERCENT = 100.0;
        private String name;
        private int totalCount;

        // mobile OSs
        private int androidCount;
        private int iosCount;

        // browsers
        private int webKitcount;
        private int geckoCount;

        private Article(String name) {
            this.name = name;
        }

        @Override
        public String toString() {
            double ioses = STO_PERCENT * iosCount / totalCount;
            double androids = STO_PERCENT * androidCount / totalCount;
            double otherOs = Math.abs(STO_PERCENT - androids - ioses);

            double chromes = STO_PERCENT * webKitcount / totalCount;
            double firefoxes = STO_PERCENT * geckoCount / totalCount;
            double otherBrowsers = Math.abs(STO_PERCENT - chromes - firefoxes);

            // pekny vypis statistiky OS a browserov
            return String.format("%10s:\n" +
                    "  Operating systems: [iOs: %.2f %%] [Android: %.2f %%] [Other: %.2f %%]" +
                    "\n  Web browsers: [Chrome: %.2f %%] [Firefox: %.2f %%] [Other: %.2f %%]",
                    name.trim(), ioses, androids, otherOs, // OS stats
                    chromes, firefoxes, otherBrowsers);  // browser stats
        }
    }

    private List<Article> articles = new ArrayList<Article>();
    private Article currentArticle;

    // pozicne flagy
    private boolean articleStart;
    private boolean osStart;
    private boolean browserStart;


    /**
     * Vypise hlavicku statistiky
     * @throws SAXException
     */
    @Override
    public void startDocument() throws SAXException {
        System.out.println("Prints statistics for most used operating systems" +
                "and browser in discussions ...");
    }

    /**
     * Pre vsetky vytvorene clanky vypise ich statistiku
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
        for (Article article : articles) {
            // print info about each article
            System.out.println(article.toString());
        }
    }

    /**
     * Zapamata si flagy, podla ktorych sa budu spracovavat texty v metode characters.
     *
     * @param uri       URI jmenného prostoru elementu (prázdné, pokud element není v žádném jmenném prostoru)
     * @param localName Lokální jméno elementu (vždy neprázdné)
     * @param qName     Kvalifikované jméno (tj. prefix-uri + ':' + localName, pokud je element v nějakém jmenném prostoru, nebo localName, pokud element není v žádném jmenném prostoru)
     * @param atts      Atributy elementu
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        articleStart = "heading".equals(localName);
        osStart = "os".equals(localName);
        browserStart = "browser-type".equals(localName);
    }

    /**
     * Ak je na elemente </article> tak ho ulozi k ostatnym articlom,
     * aby mohol pozdeji zacat s novym article.
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if ("article".equals(localName)) {
            articles.add(currentArticle);
        }
    }

    /**
     * Podla jedneho zo zpamatanych flagov sleduje, ci momentalne netreba skladat
     * meno operacneho systemu alebo web browsera. Ak ano, upravuje aktualne pouzivany
     * currentArticle.
     *
     * @param ch     Pole se znakovými daty
     * @param start  Index zacátku úseku platných znakových dat v poli.
     * @param length Délka úseku platných znakových dat v poli.
     */
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        if (articleStart) {
            currentArticle = new Article(new String(ch, start, length));
            articleStart = false;
        }

        if (osStart) {
            currentArticle.totalCount++;
            String os = new String(ch, start, length);

            if ("android".equalsIgnoreCase(os)) {
                currentArticle.androidCount++;
            }
            if ("ios".equalsIgnoreCase(os)) {
                currentArticle.iosCount++;
            }

            osStart = false;
        }

        if (browserStart) {
            String browser = new String(ch, start, length);

            if ("webkit".equalsIgnoreCase(browser)) {
                currentArticle.webKitcount++;
            }
            if ("gecko".equalsIgnoreCase(browser)) {
                currentArticle.geckoCount++;
            }

            browserStart = false;
        }
    }
}
