package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Transformuje v pamati DOM strom (viz pravidla v metode transform)
 * a ulozi do vystupneho suboru.
 */
public class MyDomTransformer {

    /**
     * Spojime tagy author a co-author do authors.
     * Element published zmenime na atribut article.
     * Element value zmenime na atribut tagu.
     * Vyhodime element preview.
     * Elementy browser-type zmenime na atributy user-agent s tym, ze:
     * <ul>
     *     <li>Ak je browser-type Gecko alebo Webkit vypiseme <b>supported browser</b></li>
     *     <li>Ak je operacny system iOS alebo Android vypiseme <b>mobile client</b></li>
     * </ul>
     */
    public void transform(Document doc) {
        Node blogger = doc.getElementsByTagName("blogger").item(0);

        // spoji starych autorov, zmaze ich a prilepsi novy authors element
        Element authors = mergeAuthors(doc);
        removeOldAuthors(doc);
        blogger.appendChild(authors);

        changePublished(doc);
        changeValueToAttribute(doc.getElementsByTagName("tag"));
        removePreviews(doc.getElementsByTagName("article"));
        changeUserAgent(doc.getElementsByTagName("user-agent"));
    }

    /**
     * Zmeni value (sub-element tagu) na jeho atribut
     * @param tags Vsetky tagy
     */
    private void changeValueToAttribute(NodeList tags) {
        for (int i = 0; i < tags.getLength(); i++) {
            Element tag = (Element) tags.item(i);
            Element value = (Element) findChildByName(tag, "value");

            tag.setAttribute("value", value.getAttribute("value"));
            tag.removeChild(value);
        }
    }

    /**
     * Odstrani elementy author a co-author
     * @param doc Root XML
     */
    private void removeOldAuthors(Document doc) {
        Element blogger = (Element) doc.getElementsByTagName("blogger").item(0);
        blogger.removeChild(findChildByName(blogger, "author"));
        blogger.removeChild(findChildByName(blogger, "co-author"));
    }

    /**
     * Spoji author a co-author elementy do authors elementu.
     * Ich relevantne podelementy name a mail prerobi na atributy.
     * @param doc Root XML
     * @return Novy authors element
     */
    private Element mergeAuthors(Document doc) {
        List<Element> authors = createAuthors(doc.getElementsByTagName("author"), doc);
        authors.addAll(createAuthors(doc.getElementsByTagName("co-author"), doc));

        Element authorsElement = doc.createElement("authors");
        for (Element author : authors) {
            authorsElement.appendChild(author);
        }

        return authorsElement;
    }

    /**
     * Preskuma bud element author alebo co-author a spoji ho do elementu
     * author s atributmi name a mail.
     * @param someAuthors Bud list authorov alebo co-authorov
     * @param doc Root XML
     * @return Zoznam novych author elementov
     */
    private List<Element> createAuthors(NodeList someAuthors, Document doc) {
        List<Element> authors = new ArrayList<Element>();

        for (int i = 0; i < someAuthors.getLength(); i++) {
            Element author = doc.createElement("author");
            for (int j = 0; j < someAuthors.item(i).getChildNodes().getLength(); j++) {
                Node node = someAuthors.item(i).getChildNodes().item(j);

                if ("name".equalsIgnoreCase(node.getNodeName())) {
                    author.setAttribute("name", node.getTextContent());
                }

                if ("mail".equalsIgnoreCase(node.getNodeName())) {
                    author.setAttribute("mail", node.getTextContent());
                }
            }
            authors.add(author);
        }

        return authors;
    }

    /**
     * Odstrani element published a spravi z neho atribut elementu article
     * @param doc Root XML
     */
    private void changePublished(Document doc) {
        NodeList articles = doc.getElementsByTagName("article");
        for (int i = 0; i < articles.getLength(); i++) {
            Element article = (Element) articles.item(i);
            // vzdy je iba jeden published element
            Node published = findChildByName(article, "published");

            // pridat atribut & odstranit stary element
            article.setAttribute("published", published.getTextContent().trim());
            article.removeChild(published);
        }
    }

    /**
     * Najde node medzi detmi rodica podla jeho mena
     * @param parent rodicovsky node
     * @param nodeName meno hladaneho node
     * @return najdeny node, alebo hodi {@link IllegalArgumentException}
     * ak taky node neexistuje
     */
    private Node findChildByName(Node parent, String nodeName) {
        NodeList childNodes = parent.getChildNodes();
        for (int i = 0; i < childNodes.getLength(); i++) {
            if (nodeName.equals(childNodes.item(i).getNodeName())) {
                return  childNodes.item(i);
            }
        }
        throw new IllegalArgumentException("No such node with name: " + nodeName);
    }

    /**
     * Odstrani preview elementy z article
     * @param articles Vsetky article elementy
     */
    private void removePreviews(NodeList articles) {
        for (int i = 0; i < articles.getLength(); i++) {
            Node article = articles.item(i);
            article.removeChild(findChildByName(article, "preview"));
        }
    }

    /**
     * Zmeni user agenta a to tak, ze podla typu OS (android, ios) prilepi atribut
     * mobile-client resp. desktop-client.
     *
     * Podla typu browsera prilepi atribut browser a to bud supported browser (chrome, firefox)
     * alebo unsupported browser (ostatne).
     *
     * Stare elementy browser a os budu odstranene.
     * @param userAgents Vsetky elementy user-agent
     */
    private void changeUserAgent(NodeList userAgents) {
        for (int i = 0; i < userAgents.getLength(); i++) {
            Element agent = (Element) userAgents.item(i);

            // resolve browser
            Node browser = findChildByName(agent, "browser-type");
            if ("gecko".equalsIgnoreCase(browser.getTextContent())
                    || "webkit".equalsIgnoreCase(browser.getTextContent())) {
                agent.setAttribute("browser", "supported browser");
            } else {
                agent.setAttribute("browser", "unsupported browser");
            }

            // resolve OS
            Node os = findChildByName(agent, "os");
            if ("android".equalsIgnoreCase(os.getTextContent())
                    || "ios".equalsIgnoreCase(os.getTextContent())) {
                agent.setAttribute("os", "mobile-client");
            } else {
                agent.setAttribute("os", "desktop-client");
            }

            agent.removeChild(browser);
            agent.removeChild(os);
        }
    }

}
