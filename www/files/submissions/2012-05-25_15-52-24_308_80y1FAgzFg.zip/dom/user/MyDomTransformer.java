package user;

import java.io.File;
import java.util.TreeMap;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class MyDomTransformer {

    public void transform(Document xmlDocument) {
        NodeList elementsByTagName = xmlDocument.getElementsByTagName("movie");
        java.util.TreeMap<String, Element> movieTitles = new TreeMap<>();
        for (int i = 0; i < elementsByTagName.getLength(); i++) {
            Element movieElement = (Element) elementsByTagName.item(i);
            NodeList titles = movieElement.getElementsByTagName("title");
            String movieTitle = ((Element) titles.item(0)).getTextContent();

            if (movieTitle != null) {
                movieTitles.put(movieTitle, movieElement);
                System.out.println("movie title added: " + movieTitle);
            }
        }

        Element movieParent = (Element) elementsByTagName.item(0).getParentNode();
        for (int i = 0; i < elementsByTagName.getLength(); i++) {
            Element movieElement = (Element) elementsByTagName.item(i);
            movieParent.removeChild(movieElement);
        }
        for (Element movie : movieTitles.values()) {
            movieParent.appendChild(movie);
        }

    }
    private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "data.out.xml";

    public static void main(String[] args) {

        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            dbf.setValidating(false);

            DocumentBuilder builder = dbf.newDocumentBuilder();

            Document doc = builder.parse(VSTUPNI_SOUBOR);

            MyDomTransformer domTransformer = new MyDomTransformer();
            domTransformer.transform(doc);

            TransformerFactory tf = TransformerFactory.newInstance();

            Transformer writer = tf.newTransformer();

            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));

        } catch (Exception e) {

            e.printStackTrace();

        }
    }
}