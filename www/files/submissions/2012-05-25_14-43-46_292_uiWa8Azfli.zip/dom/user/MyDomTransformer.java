package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

/* Nahradi vsetky atributy elementmi. Vytvoreny element je umiestneny na poziciu prveho dietata elementu, z ktoreho atribut pochadza. */

public class MyDomTransformer {
	
	public void transform (Document xmlDocument) {
		
		for (Node child = xmlDocument.getFirstChild(); child!= null; child = child.getNextSibling()) 
		{	
			processChild(child,xmlDocument);
			transformNode(child,xmlDocument);
		}
	}
	
	public void transformNode (Node n, Document doc)
	{
		for (Node child = n.getFirstChild(); child!= null; child = child.getNextSibling()) 
		{	
			processChild(child,doc);
			transformNode(child,doc);
		}
	}
	
	public void processChild(Node child, Document doc)
	{
		if (child.hasAttributes())
		{
			NamedNodeMap atts = child.getAttributes();
			while(atts.getLength() > 0)
			{
				Node n = atts.item(0);
				Element e = doc.createElement(n.getNodeName());
				e.appendChild(doc.createTextNode(n.getTextContent()));
		        ((Element)child).removeAttribute(n.getNodeName());
		        //child.appendChild(e);
		        if (child.hasChildNodes()) 
		        {
		        	Node firstChild = child.getFirstChild();
		        	child.insertBefore(e,firstChild);
		        }
		        else
		        	child.appendChild(e);
			}

		}
		
	}
}