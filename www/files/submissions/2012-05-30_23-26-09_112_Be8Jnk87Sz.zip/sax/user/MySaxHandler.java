package user;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

import java.util.Stack;
import java.util.Enumeration;

/**
 * Creates and outputs statistics about xml document.
 * 
 * Implementation of DefaultHandler interface for handling
 * events created while parsing document.
 */
public class MySaxHandler extends DefaultHandler {
	/**
	 * Class holds information about element.
	 */
	public static class ElementInfo {
		public enum ElementType {
			EMPTY,
			CDATA,
			MIXED,
			ELEMENTS
		}

		public String name = null;
		public int fanout = 0;
		public ElementType type = ElementType.EMPTY;
		public int size = 0;
		public int attributesCount = 0;
	}
	
	// Variables holding information about deep.
	private int deepTotal = 0;
	private int deepMax = 0;
	private int deep = 0;

	// Variables holding information about elements.
	private int elementsTotal = 0;
	private int elementsAttributesTotal = 0;
	private int elementsAttributesMax = -1;
	private int elementsAttributesMin = -1;
	private int elementsNameTotal = 0;
	private int elementsNameMax = -1;
	private int elementsNameMin = -1;
	private int elementsFanoutTotal = 0;
	private int elementsFanoutMax = -1;
	private int elementsFanoutMin = -1;
	private int elementsEmpty = 0;
	private int elementsMixed = 0;
	private int elementsCdata = 0;
	private int elementsElementsOnly = 0;

	// Miscellanous information.
	private int documentSize = 0;
	
	// Well-formed document.
	private boolean wellFormed = true;

	// Help variables.
	private Stack<ElementInfo> elementsStack = null;
	
	/**
	 * "Start Document" event handler.
	 */
	@Override
	public void startDocument() throws SAXException
	{
		this.elementsStack = new Stack<ElementInfo>();
	}

	/**
	 * "End Document" event handler.
	 */
	@Override
	public void endDocument() throws SAXException
	{
		System.out.print("XML document statistics");
		if (this.wellFormed) {
		 	System.out.println(" - WELL formed");
		} else {
			System.out.println(" - BAD formed");
		}
		
		System.out.println("-------------------------------------------");
		System.out.println("ELEMENTS");
		System.out.println("Empty  : " + this.elementsEmpty + " [" + (this.elementsEmpty * 100.0) / this.elementsTotal + "%]");
		System.out.println("Characters .: " + this.elementsCdata + " [" + (this.elementsCdata * 100.0) / this.elementsTotal + "%]");
		System.out.println("Mixed *: " + this.elementsMixed + " [" + (this.elementsMixed * 100.0) / this.elementsTotal + "%]");
		System.out.println("Elements only -: " + this.elementsElementsOnly + " [" + (this.elementsElementsOnly * 100.0) / this.elementsTotal + "%]");
		System.out.println("Total: " + this.elementsTotal);
		
		double empty = (this.elementsEmpty * 40.0) / this.elementsTotal;
		double chars = empty + (this.elementsCdata * 40.0) / this.elementsTotal;
		double mixed = chars + (this.elementsMixed * 40.0) / this.elementsTotal;
				
		System.out.println();
		System.out.print('[');
		for (int i = 0; i < 40; i++) {
			if (i > mixed) {
				System.out.print('-');
				continue;
			}
			
			if (i > chars) {
				System.out.print('*');
				continue;
			}
			
			if (i > empty) {
				System.out.print('.');
				continue;
			}
			
			System.out.print(' ');
		}
		System.out.println(']');
		System.out.println();
		
		System.out.println("DEEP");
		System.out.println("Maximal: " + this.deepMax);
		System.out.println("Average: " + (double)this.deepTotal / this.elementsTotal);
		System.out.println();
		
		System.out.println("FANOUT");
		System.out.println("Maximal: " + this.elementsFanoutMax);
		System.out.println("Minimal: " + this.elementsFanoutMin);
		System.out.println("Average: " + (double)this.elementsFanoutTotal / this.elementsTotal);
		System.out.println();
		
		System.out.println("ATTRIBUTES");
		System.out.println("Maximal: " + this.elementsAttributesMax);
		System.out.println("Minimal: " + this.elementsAttributesMin);
		System.out.println("Average: " + (double)this.elementsAttributesTotal / this.elementsTotal);
		System.out.println();
		
		System.out.println("ELEMENTS NAMES");
		System.out.println("Maximal: " + this.elementsNameMax);
		System.out.println("Minimal: " + this.elementsNameMin);
		System.out.println("Average: " + (double)this.elementsNameTotal / this.elementsTotal);
		System.out.println();
		
		System.out.println("SIZE");
		System.out.println("Total: " + this.documentSize + " bytes");
		System.out.println("Average: " + (double)this.documentSize / this.elementsTotal + " bytes");
	}

	/**
	 * "Start of the Element" event handler.
	 */
	@Override
	public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
	{
		// counters information updating.
		this.elementsTotal++;
		
		this.elementsAttributesTotal += atts.getLength();
		if ((this.elementsAttributesMin > atts.getLength()) || (this.elementsAttributesMin == -1)) {
			this.elementsAttributesMin = atts.getLength();
		}

		if (this.elementsAttributesMax < atts.getLength()) {
			this.elementsAttributesMax = atts.getLength();
		}

		this.elementsNameTotal += localName.length();
		if (this.elementsNameMin > localName.length() || (this.elementsNameMin == -1)) {
			this.elementsNameMin = localName.length();
		}

		if (this.elementsNameMax < localName.length()) {
			this.elementsNameMax = localName.length();
		}
		
		this.deep++;
		this.deepTotal += this.deep;
		if (this.deep > this.deepMax) {
			this.deepMax = this.deep;
		}

		// stack handling.
		if (!this.elementsStack.empty()) {
			ElementInfo peek = this.elementsStack.peek();
			peek.fanout++;
			
			if (peek.type == ElementInfo.ElementType.EMPTY) {
				peek.type = ElementInfo.ElementType.ELEMENTS;
			}
			
			if (peek.type == ElementInfo.ElementType.CDATA) {
				peek.type = ElementInfo.ElementType.MIXED;
			}
		}

		ElementInfo info = new ElementInfo();
		info.name = localName;
		info.attributesCount += atts.getLength();
		this.elementsStack.push(info);
	}

	/**
	 * "End of the Element" event handler.
	 */
	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException
	{
		ElementInfo info = this.elementsStack.pop();
		
		switch (info.type) {
		case EMPTY:
			this.elementsEmpty++;
			break;
		case CDATA:
			this.elementsCdata++;
			break;
		case MIXED:
			this.elementsMixed++;
			break;
		case ELEMENTS:
			this.elementsElementsOnly++;
			break;
		}
		
		if ((this.elementsFanoutMin > info.fanout) || (this.elementsFanoutMin == -1)) {
			this.elementsFanoutMin = info.fanout;
		}
		
		if (this.elementsFanoutMax < info.fanout) {
			this.elementsFanoutMax = info.fanout;
		}
			
		this.elementsFanoutTotal += info.fanout;
		
		if (!localName.equals(info.name)) {
			this.wellFormed = false;
		}
		
		this.deep--;
		
		Enumeration<ElementInfo> e = this.elementsStack.elements();
		while (e.hasMoreElements()) {
			e.nextElement().size += info.size;
		}
	}

	/**
	 * "Characters Data" event handler.
	 */
	@Override
	public void characters(char[] ch, int start, int length) throws SAXException
	{
		ElementInfo peek = this.elementsStack.peek();
		peek.size += length;
		this.documentSize += length;

		if (peek.type == ElementInfo.ElementType.EMPTY) {
		 	peek.type = ElementInfo.ElementType.CDATA;
		}
		
		if (peek.type == ElementInfo.ElementType.ELEMENTS) {
		 	peek.type = ElementInfo.ElementType.MIXED;
		}
	}
}