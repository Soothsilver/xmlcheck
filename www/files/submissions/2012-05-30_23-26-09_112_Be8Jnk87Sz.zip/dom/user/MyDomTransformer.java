package user;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

/**
 * Problems:
 *  - Extract attribute name of <team> element into new subelement.
 *  - Convert date from attributes day, month, year to single attribute value.
 *  - Remove all empty periods in <scoring_summary> and <penalty_summary> elements.
 *  - Swap host and visitor teams in each game.
 */
public class MyDomTransformer {
	
	// i/o:
	private static final String INPUT_FILE = "data.xml";
	private static final String OUTPUT_FILE = "data.out.xml";
	
	// elements/attributes names:
	private static final String TEAM_ELEMENT_NAME = "team";
	private static final String TEAM_NAME_ATTRIBUTE_NAME = "name";
	private static final String SCORING_ELEMENT_NAME = "scoring_summary";
	private static final String PENALTY_ELEMENT_NAME = "penalty_summary";
	private static final String PERIOD_ELEMENT_NAME = "period";
	private static final String DATE_ELEMENT_NAME = "date";
	private static final String DATE_DAY_ATTRIBUTE_NAME = "day";
	private static final String DATE_MONTH_ATTRIBUTE_NAME = "month";
	private static final String DATE_YEAR_ATTRIBUTE_NAME = "year";
	private static final String DATE_VALUE_ATTRIBUTE_NAME = "value";
	private static final String GAME_ELEMENT_NAME = "game";
	private static final String GAME_HOST_ATTRIBUTE_NAME = "host";
	private static final String GAME_VISITOR_ATTRIBUTE_NAME = "visitor";
	private static final String HOST_ELEMENT_NAME = "host";
	private static final String VISITOR_ELEMENT_NAME = "visitor";

	/**
	 * Extract name attibute from <team> element to new element.
	 * 
	 * @param node <team> element from document.
	 */
	private static void extractName(Node node)
	{
		assert(node.getNodeName().equals(TEAM_ELEMENT_NAME));
		
		// gather attribute.
		NamedNodeMap attributes = node.getAttributes();
		Node nameAttribute = attributes.getNamedItem(TEAM_NAME_ATTRIBUTE_NAME);
		if (nameAttribute == null) {
			return;
		}
		
		// create element.
		Element nameElement = node.getOwnerDocument().createElement(TEAM_NAME_ATTRIBUTE_NAME);
		nameElement.setTextContent(nameAttribute.getNodeValue());
		
		// remove attribute & append element.
		attributes.removeNamedItem(TEAM_NAME_ATTRIBUTE_NAME);
		node.insertBefore(nameElement, node.getFirstChild());
	}
	
	/**
	 * Remove empty period elements. Node is whose children are <period>
	 * elements.
	 * 
	 * @param node <scoring_summary> or <penalty_summary> elements from document.
	 */
	private static void removeEmptyPeriod(Node node)
	{
		boolean done = false;
		while (!done) {
			done = true;
			
			// find empty period child.
			Node child = node.getFirstChild();
			while (child != null) {
				if (child.getNodeName().equals(PERIOD_ELEMENT_NAME) && !child.hasChildNodes()) {
					node.removeChild(child);
					done = false;
					break;
				}
				child = child.getNextSibling();
			}
			
		}
	}
	
	/**
	 * Convert all dates to format dd.mm.yyyy into one attribute called value.
	 * 
	 * @param node <name> element from document.
	 */
	private static void convertDate(Node node)
	{
		assert(node.getNodeName().equals(DATE_ELEMENT_NAME));
		
		// gather values.
		NamedNodeMap attributes = node.getAttributes();
		String day = attributes.getNamedItem(DATE_DAY_ATTRIBUTE_NAME).getTextContent();
		String month = attributes.getNamedItem(DATE_MONTH_ATTRIBUTE_NAME).getTextContent();
		String year = attributes.getNamedItem(DATE_YEAR_ATTRIBUTE_NAME).getTextContent();
		
		// remove attributes.
		attributes.removeNamedItem(DATE_DAY_ATTRIBUTE_NAME);
		attributes.removeNamedItem(DATE_MONTH_ATTRIBUTE_NAME);
		attributes.removeNamedItem(DATE_YEAR_ATTRIBUTE_NAME);
		
		// set result.
		String result = String.format("%s.%s.%s", day, month, year);
		((Element)node).setAttribute(DATE_VALUE_ATTRIBUTE_NAME, result);
	}
	
	/**
	 * Swap host and visitor teams in all games. America uses
	 * Visitor at. Host format. Europe uses Host vs. Visitor format.
	 */
	private static void swapTeams(Node node)
	{
		assert(node.getNodeName().equals(GAME_ELEMENT_NAME));
		
		// swap host and visitor attributes values.
		NamedNodeMap attributes = node.getAttributes();
		Node hostAttribute = attributes.getNamedItem(GAME_HOST_ATTRIBUTE_NAME);
		Node visitorAttribute = attributes.getNamedItem(GAME_VISITOR_ATTRIBUTE_NAME);

		String temp = hostAttribute.getTextContent();
		hostAttribute.setTextContent(visitorAttribute.getTextContent());
		visitorAttribute.setTextContent(temp);
		
		// recursively find all nodes that has its children <host> and
		// <visitor> elements and swap contents.
		swapTeamsInternal(node);
	}
	
	/**
	 * Recursively swap all <host> and <visitor> subelements.
	 * @param node currently processed node.
	 */
	private static void swapTeamsInternal(Node node)
	{
		if (node == null) {
			return;
		}
		
		// find host/visitor child nodes.
		Node visitor = null;
		Node host = null;
		Node child = node.getFirstChild();
		while (child != null) {
			if (child.getNodeName().equals(HOST_ELEMENT_NAME)) {
				assert(host == null);
				host = child;
			}
			
			if (child.getNodeName().equals(VISITOR_ELEMENT_NAME)) {
				assert(visitor == null);
				visitor = child;
			}
			
			child = child.getNextSibling();
		}
		
		// if there are, just swap content.
		if ((visitor != null) && (host != null)) {
			
			// rename nodes.
			node.getOwnerDocument().renameNode(visitor, null, HOST_ELEMENT_NAME);
			node.getOwnerDocument().renameNode(host, null, VISITOR_ELEMENT_NAME);
			
			// swap positions.
			node.insertBefore(visitor, host);
		}
		
		child = node.getFirstChild();
		while (child != null) {
			swapTeamsInternal(child);
			child = child.getNextSibling();
		}
	}

	/**
	 * Process DOM tree.
	 * Just get root element and process it.
	 */
	public void transform(Document doc)
	{
		// extract name attribute from teams node.
		NodeList teams = doc.getElementsByTagName(TEAM_ELEMENT_NAME);
		for (int i = 0; i < teams.getLength(); ++i) {
			extractName(teams.item(i));
		}
				
		// erase all empty period elements inside <scoring_summary>
		// and <penalty_summary> nodes.
		NodeList scorings = doc.getElementsByTagName(SCORING_ELEMENT_NAME);
		for (int i = 0; i < scorings.getLength(); ++i) {
			removeEmptyPeriod(scorings.item(i));
		}
		
		NodeList penalties = doc.getElementsByTagName(PENALTY_ELEMENT_NAME);
		for (int i = 0; i < penalties.getLength(); ++i) {
			removeEmptyPeriod(penalties.item(i));
		}
		
		// convert all dates to special format.
		NodeList dates = doc.getElementsByTagName(DATE_ELEMENT_NAME);
		for (int i = 0; i < dates.getLength(); ++i) {
			convertDate(dates.item(i));
		}
		
		// swap teams.
		NodeList games = doc.getElementsByTagName(GAME_ELEMENT_NAME);
		for (int i = 0; i < games.getLength(); ++i) {
			swapTeams(games.item(i));
		}
	}
}