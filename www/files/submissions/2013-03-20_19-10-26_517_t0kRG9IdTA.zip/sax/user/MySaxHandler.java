package user;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.jar.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
public class MySaxHandler extends DefaultHandler {
  // override metod DefaultHandleru
  
  // 1. zjistí vrátí jména všech žen
  ArrayList<String> females=new ArrayList();
  boolean waitForName=false;
  boolean grabFemaleName=false;
  
  // 2. poměr výher s černými a bílými
  int winsWithBlack=0;
  int winsWithWhite=0;
  boolean grabResult=false;
  
  // 3. počty výher hráčů
  String lastBlack="";
  String lastWhite="";
  boolean grabBlack=false;
  boolean grabWhite=false;
  HashMap<String,Integer> standings=new HashMap<>();
  
  
  public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        
    if(localName.equals("hrac")&&atts.getValue("pohlavi").equals("Z")){waitForName=true ; }
    
    if(waitForName&&localName.equals("jmeno")){
      grabFemaleName=true;
      waitForName=false;
    }
    
    if(localName.equals("vysledek")){grabResult=true;}
    
    if(localName.equals("cerny")){grabBlack=true;}
    else if(localName.equals("bily")){grabWhite=true;}
    
    }
  @Override
   public void characters(char[] chars, int start, int length) throws SAXException {
        if(grabFemaleName){
          String name=new String(chars);
          name=name.substring(start, start+length);
          females.add(name);
          grabFemaleName=false;
          return;
        }
        if(grabResult){
          String res=new String(chars);
          res=res.substring(start, start+length);
          if(res.equals("C")){
            addWinToPlayer(lastBlack);
            winsWithBlack++;
          }
          if(res.equals("B")){
            addWinToPlayer(lastWhite);
            winsWithWhite++;
          }
          grabResult=false;
          return;
        }
        if(grabBlack){
          String name=new String(chars);
          name=name.substring(start, start+length);
          lastBlack=name;
          grabBlack=false;
          return;
        }
        if(grabWhite){
          String name=new String(chars);
          name=name.substring(start, start+length);
          lastWhite=name;
          grabWhite=false;
          return;
        }
    }
  private void addWinToPlayer(String name){
    if(standings.containsKey(name)){standings.put(name, standings.get(name)+1);}
    else{standings.put(name,1);}
  }
}