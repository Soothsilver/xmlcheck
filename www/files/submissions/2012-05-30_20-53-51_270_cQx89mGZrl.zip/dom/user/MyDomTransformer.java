/*
  Program upravi vstupni soubor tak, ze vsechny potomku uzlu, ktery je na treti vrstve seserializuje a vlozi je do podelementu potomci.
*/
package user;

import org.w3c.dom.*;
import java.util.*;

public class MyDomTransformer {

    public void transform(Document doc) {
        Node root=doc.getDocumentElement();
        processNode(doc,(Element)root, 0);
    }
    
    private void processNode(Document doc,Element element, int level)
    {
        NodeList l = element.getChildNodes();
        if (l != null)
        {
            for (int i = 0; i < l.getLength(); i++)
            {
                if (l.item(i) instanceof Element)
                {
                    if(level < 2)
                    {
                        processNode(doc, (Element) l.item(i),level + 1);
                    }
                    else
                    {
                        serializeNodes(doc, (Element) l.item(i));
                    }
                }
            }
        }
    }
    
    private void serializeNodes(Document doc, Element element)
    {
        StringBuilder text = new StringBuilder();
        NodeList l = element.getChildNodes();
        Boolean subNode = false;
        if (l != null)
        {
            for (int i = 0; i < l.getLength(); i++)
            {
                if (l.item(i) instanceof Element)
                {
                    subNode = true;
                    serializeNode((Element)l.item(i),text);
                    l.item(i).getParentNode().removeChild(l.item(i));
                }
                text.append(l.item(i).getNodeValue());
            }
        }
        
        if(subNode)
        {
            Element child = doc.createElement("potomci");
            child.appendChild(doc.createTextNode(text.toString()));
            element.appendChild(child);
        }
    }
    
    private void serializeNode(Element element, StringBuilder text)
    {
        text.append(" Potomek - nazev : " + element.getNodeName() + ", obsah : " + ((element.getNodeValue() != null) ? element.getNodeValue() + ", " : ""));

        NamedNodeMap atts = element.getAttributes();
        for(int i = 0; i < atts.getLength(); i++)
        {
            text.append("Atribut - nazev : "+atts.item(i).getNodeName()+", obsah : "+atts.item(i).getNodeValue()+"; ");
            
        }
        NodeList l = element.getChildNodes();
        if (l != null)
        {
            for (int i = 0; i < l.getLength(); i++)
            {
                if (l.item(i) instanceof Element)
                {
                    serializeNode((Element)l.item(i),text);
                    l.item(i).getParentNode().removeChild(l.item(i));
                }
                text.append(l.item(i).getNodeValue()+"; ");
            }
        }
    }
}
