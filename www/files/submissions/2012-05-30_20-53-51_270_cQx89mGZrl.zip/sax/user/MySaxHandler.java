/*
  Program vypise seznam uzlu, ktere se vyskytuji v souboru nejcasteji. 
*/
package user;

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;  
import java.util.*;

public class MySaxHandler extends DefaultHandler {

    Locator locator;
    
    HashMap nodeMap;
    int maxCount;
    
    public void setDocumentLocator(Locator locator)
    {
        this.locator = locator;
    }

    public void startDocument() throws SAXException
    {
        this.nodeMap = new HashMap();
        this.maxCount = 0;
    }
    
    public void endDocument() throws SAXException
    {
        //projdu seznam a najdu si prvky s maximalnim poctem vyskytu
        Iterator iter = this.nodeMap.entrySet().iterator();
        iter = this.nodeMap.entrySet().iterator();
        while (iter.hasNext())
        {
            Map.Entry mEntry = (Map.Entry) iter.next();
            if(this.maxCount == Integer.parseInt(mEntry.getValue().toString()))
                System.out.println(mEntry.getValue()+" : "+mEntry.getKey());
            
        }
    }
    
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
    {
        int count = 1;
        if (this.nodeMap.containsKey(localName))
        {
            count = Integer.parseInt(this.nodeMap.get(localName).toString()) + 1;
        }
        if(count > this.maxCount)
            this.maxCount = count;
        this.nodeMap.put(localName,count);
    }
}
