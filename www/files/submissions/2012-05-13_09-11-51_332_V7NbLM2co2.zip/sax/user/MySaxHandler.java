/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
    
    /* clenske promenne */
    
    private HashMap<String, List<Element>> attributes;
    
    /* prekryte clenske metody */
    @Override
    public void startDocument () throws SAXException {
        attributes = new HashMap<String, List<Element>>();
    }
    @Override
    public void endDocument() throws SAXException {
        Set<String> keySet = attributes.keySet();
        List<Element> elements = null;
        for(String s : keySet) {
            elements = attributes.get(s);
            if(elements.size() > 1) {
                System.out.println("Matches found on value: " + s);
                for(Element e: elements) {
                    System.out.println("\tElement name: " + e.getEleName() + ", Attribute name: " + e.getAttName());
                }
            }
        }
    }
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) {
        String attName = null;
        String attValue = null;
        List<Element> hashValue = null;
        for(int i = 0; i < atts.getLength(); i++) {
            attName = atts.getQName(i);
            attValue = atts.getValue(i);
            hashValue = attributes.get(attValue);
            if(hashValue == null) {
                List<Element> list = new ArrayList<Element>();
                list.add(new Element(attName, qName));
                attributes.put(attValue, list);
            } else {
                hashValue.add(new Element(attName, qName));
            }
        }
    }
}

class Element {
    
    private String attName;
    private String eleName;
    
    public String getAttName() {
        return attName;
    }
    
    public String getEleName() {
        return eleName;
    }
    
    public Element(String attName, String eleName) {
        this.attName = attName;
        this.eleName = eleName;
    }
    
}