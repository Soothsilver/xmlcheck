/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.util.HashMap;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer {

    public void transform(Document xmlDocument) {
        Element root = xmlDocument.getDocumentElement();
        NodeList photos = root.getElementsByTagName("photo");
        HashMap<String,String> sizeInfo = null;
        for(int i = 0; i < photos.getLength(); i++) {
            Element photo = (Element)photos.item(i);
            Node size = photo.getElementsByTagName("size").item(0); // we know that there is only one element size
            photo.removeChild(size);
            sizeInfo = extractImageSizeInfo(size);
            photo.setAttribute("width", sizeInfo.get("width") + " " + sizeInfo.get("measurement"));
            photo.setAttribute("height", sizeInfo.get("height") + " " + sizeInfo.get("measurement"));
        }
    }
    
    /* HELPER METHODS */
    
    private HashMap<String, String> extractImageSizeInfo(Node node) {
        HashMap<String, String> map = new HashMap<String, String>(3);
        NodeList list = node.getChildNodes();
        for(int i = 0; i < list.getLength(); i++) {
            Node n = list.item(i);
            map.put(n.getNodeName(), n.getTextContent());
        }
        return map;
    }
    
}