package user;

import java.io.IOException;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Map;
import org.xml.sax.*;
import org.xml.sax.helpers.*;

public class MySaxHandler extends org.xml.sax.helpers.DefaultHandler {
   // Data for "Point of Conflict"
   int NumberOfPositionsSoFar = 0;
   float PositionSumNorth = 0;
   float PositionSumEast = 0;
   // Data for "Vehicle count"
   Map<String, Integer> vehicleCounts = new HashMap<String, Integer>();
   // Data for commander names
   Map<String, String> persons = new HashMap<String, String>();
   // Context data
   String currentArmyId;
   boolean iamWithinLeaderTag;
   boolean iamWithinArmyTag;
   boolean iamWithinTypeTag;
   
   /* 
   public static void main(String[] args) throws IOException, SAXException {
        System.out.println("Test of SAX: ");
        // Create parser instance
        XMLReader parser = XMLReaderFactory.createXMLReader();
        // Create input stream from source XML document
        InputSource source = new InputSource("data.xml");
        // Set our custom content handler for handling SAX events (it must implements ContentHandler interface)
        parser.setContentHandler(new MySaxHandler());
        // Process input data
        parser.parse(source);
   }
   */
   
   // Helper variable to store location of the handled event
    Locator locator;

    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }
    @Override
    public void startDocument() throws SAXException {
        //System.out.println("1. Army Leaders: ");
    }
    @Override
    public void endDocument() throws SAXException {
        //System.out.println("2. Number of vehicles participating in battle:");
        for(Map.Entry<String, Integer> vehicleEntry : vehicleCounts.entrySet())
        {
        //    System.out.println(vehicleEntry.getKey() + ": " + vehicleEntry.getValue() + "x");
        }
        //System.out.println("3. Expected point of conflict (arithmetic mean of all army positions:");
        //System.out.println("North: " + (PositionSumNorth / NumberOfPositionsSoFar));
        //System.out.println("East: " + (PositionSumEast / NumberOfPositionsSoFar));
    }
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if (localName.equals("position") && iamWithinArmyTag)
        {
            NumberOfPositionsSoFar++;
            PositionSumNorth += Float.parseFloat(atts.getValue("north"));
            PositionSumEast += Float.parseFloat(atts.getValue("east"));
        }
        if (localName.equals("person"))
        {
            persons.put(atts.getValue("id"),
                    atts.getValue("name"));
            if (iamWithinLeaderTag)
            {
          //      System.out.println(currentArmyId + ": " + atts.getValue("name"));
            }
        }
        if (localName.equals("person_reference"))
        {
            if (iamWithinLeaderTag)
            {
          //      System.out.println(currentArmyId + ": " + persons.get(atts.getValue("ref")));
            }
        }
        if (localName.equals("army"))
        {
            iamWithinArmyTag = true;
            currentArmyId = atts.getValue("id");
        }
        if (localName.equals("leader"))
        {
            iamWithinLeaderTag = true;
        }
        if (localName.equals("type"))
        {
            iamWithinTypeTag = true;
        }
    }
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (localName.equals("army"))
        {
            iamWithinArmyTag = false;
        }
        if (localName.equals("leader"))
        {
            iamWithinLeaderTag = false;
        }
        if (localName.equals("type"))
        {
            iamWithinTypeTag = false;
        }
    }
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        if (iamWithinTypeTag)
        {
            // It is only about 20 characters what we need. Let's suppose it all comes in the same chunk
            String s = new String(chars, start, length).trim();
            if (vehicleCounts.containsKey(s))
            {
                vehicleCounts.put(s,
                        vehicleCounts.get(s) + 1);
            }
            else
            {
                vehicleCounts.put(s,
                        1);
            }
        }        
    }
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }
    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
        // ...
    }
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }
    @Override
    public void skippedEntity(String name) throws SAXException {
        // ...
    }
}
