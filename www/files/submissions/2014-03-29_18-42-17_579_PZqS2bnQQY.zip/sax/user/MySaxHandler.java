package user;
import java.util.Hashtable;
import java.util.LinkedList;

import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
public class MySaxHandler extends DefaultHandler{
	
	private enum Stav{
		STABLE("stable"),TESTING("testing"),UNSTABLE("unstable"),NEW("new");
		
		String stav;
		
		Stav(String s){
			this.stav=s;
		}
		
		public String toString(){
			return this.stav;
		}
	}
	
	int modulyVeStavuNew;
	String moduleName,moduleId;
	boolean zpracujAdmina,stavStable;
	Locator locator;
	Hashtable<String,LinkedList<String>> adminModuly=new Hashtable<String,LinkedList<String>>();
	Hashtable<String,LinkedList<String>> stableDepend=new Hashtable<String,LinkedList<String>>();
	Hashtable<String,Stav> stavModulu=new Hashtable<String,Stav>();
	Hashtable<String,String> modIdName=new Hashtable<String,String>();
	
	
	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		if(zpracujAdmina){
			boolean bylaWS=false;
			String admin="";
			int i=start;
			while(Character.isWhitespace(ch[i]))i++;
			while(i<(start+length)){
				if(!Character.isWhitespace(ch[i])){
					if(bylaWS) admin=admin+" ";
					admin=admin+ch[i];
					bylaWS=false;
				}
				else bylaWS=true;
				i++;
			}
			if(adminModuly.containsKey(admin))adminModuly.get(admin).add(moduleName);
			else{
				LinkedList<String> pom=new LinkedList<String>();
				pom.add(moduleName);
				adminModuly.put(admin, pom);
			}
			zpracujAdmina=false;
		}
		
	}

	@Override
	public void endDocument() throws SAXException {
		System.out.println("Modulu ve stavu new: "+modulyVeStavuNew+"\n");
		
		System.out.println("Administratori a jimi spravovane moduly:");
		for(String admin:adminModuly.keySet()){
			LinkedList<String> moduly=adminModuly.get(admin);
			int vel=moduly.size();
			System.out.print(admin+" ("+vel+"): ");
			for(int i=2;i<vel;i++){
				String modul=moduly.pollFirst();
				System.out.print(modul+",");
			}
			System.out.println(moduly.pollFirst());
		}
		
		System.out.println("\nModuly ve stavu stable, ktere zavisi na modulu ve stavu new, testing nebo unstable:");
		for(String s_modul:stableDepend.keySet()){
			LinkedList<String> deps=stableDepend.get(s_modul);
			for(String d_modul:deps){
				Stav stavmod=stavModulu.get(d_modul);
				if (!stavmod.equals(Stav.STABLE)){
					System.out.println("Modul: "+modIdName.get(s_modul)+"\tZavislost: "+modIdName.get(d_modul)+" ("+stavmod+")");
				}
			}
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		if(localName.equals("module")){
			moduleName=null;
			moduleId=null;
			zpracujAdmina=false;
			stavStable=false;
		}	
	}

	@Override
	public void setDocumentLocator(Locator arg0) {
		this.locator=arg0;		
	}

	@Override
	public void startDocument() throws SAXException {
		modulyVeStavuNew=0;
	}

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes atts) throws SAXException {
		zpracujAdmina=false;
		
		//1. Spocitat pocet modulu ve stavu new (pokud neni uvedeny status, povazuji za new)
		if(localName.equals("module")){
			moduleName=atts.getValue(atts.getIndex("name"));
			moduleId=atts.getValue(atts.getIndex("id"));
			modIdName.put(moduleId, moduleName);
			
			Stav stav;
			String status=atts.getValue(atts.getIndex("status"));
			if(status.equals("new")){
				modulyVeStavuNew++;
				stav=Stav.NEW;
			}else if(status.equals("unstable")) stav=Stav.UNSTABLE;
			else if(status.equals("testing")) stav=Stav.TESTING;
			else if(status.equals("stable")){
				stav=Stav.STABLE;stavStable=true;
			}else stav=null;
			stavModulu.put(moduleId, stav);
		}
		//2. Ke kazdemu administratorovi vypsat seznam modulu (kde je administrator)
		else if(localName.equals("administrator")){
			zpracujAdmina=true;
		}
		//3. Moduly ve stavu stable, majici zavislost na modulu, ktery neni stable s oznacenim stavu
		else if(stavStable&localName.equals("dependency")){
			if(stableDepend.containsKey(moduleId))
				stableDepend.get(moduleId).add(atts.getValue(atts.getIndex("module")));
			else{
				LinkedList<String> pom=new LinkedList<String>();
				pom.add(atts.getValue(atts.getIndex("module")));
				stableDepend.put(moduleId, pom);
			}
		}
	}
}
