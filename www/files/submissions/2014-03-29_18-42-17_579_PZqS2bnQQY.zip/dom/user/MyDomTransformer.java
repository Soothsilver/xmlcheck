package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
public class MyDomTransformer {
public void transform (Document xmlDocument) {
    // libovolne transformace objektu 'xmlDocument'
    // (metoda pracuje primo na objektu, nic nevraci)
	
	
	//a) odstrani vsechny moduly, ktere maji vice jak 3 zavislosti
	//b) odstrani moduly, ktere zavisi na odstranenych modulech
	//c) odstrani tagy neexistujicich modulu (jen atribut)
	//d) prida modul, ktery zavisi na vsech zbylych modulech
	
	//a
	NodeList deps=xmlDocument.getElementsByTagName("dependencies");
	for(int i=0;i<deps.getLength();i++){
		Element dependencies=(Element)deps.item(i);
		if(dependencies.getChildNodes().getLength()>3) disposeParent(dependencies);
			//dependencies obsahuje 3 podelementy (zavislosti)
	}
	
	//b
	boolean zmena=false,pokracovat=true;
	while(pokracovat){
		int i=0,zmen=0;
		deps=xmlDocument.getElementsByTagName("dependencies");
		while(i<deps.getLength()&!zmena){
			Element dependencies=(Element)deps.item(i);
			NodeList dep=dependencies.getElementsByTagName("dependency");
			int j=0;
			while(j<dep.getLength()&!zmena){
				Element dependency=(Element)dep.item(j);
				if(xmlDocument.getElementById(dependency.getAttribute("module"))==null){
					//zavislost neexistuje - odstranit modul - rodic dependencies
					disposeParent(dependencies);
					zmena=true;
					zmen++;
				}
				j++;
			}
			i++;
		}
		if(zmen==0)pokracovat=false;
		else zmen=0;
	}
	//c
	NodeList tags=xmlDocument.getElementsByTagName("tag");
	for(int i=0;i<tags.getLength();i++){
		Element tag=(Element)tags.item(i);
		if(xmlDocument.getElementById(tag.getAttribute("module"))==null) tag.removeAttribute("module");
			//tag na neexistujici modul
	}
	//d
	NodeList modules=xmlDocument.getElementsByTagName("module");
	Element dependencies=xmlDocument.createElement("dependencies");
	for(int i=0;i<modules.getLength();i++){
		Element dep=xmlDocument.createElement("dependency");
		dep.setAttribute("module", modules.item(i).getAttributes().getNamedItem("id").getNodeValue());
		dependencies.appendChild(dep);
	}
	
	Element module=xmlDocument.createElement("module");
	module.setAttribute("name", "critical");
	int n=0;
	while(module.hasAttribute("m_critical"+n)) n++;
	module.setAttribute("id","m_critical"+n);
	module.appendChild(dependencies);
	xmlDocument.getElementsByTagName("modules").item(0).appendChild(module);
}


	void disposeParent(Element e){
		Element parent=(Element)e.getParentNode();
		Element grandparent=(Element)parent.getParentNode();
		grandparent.removeChild(parent);
	}
}
