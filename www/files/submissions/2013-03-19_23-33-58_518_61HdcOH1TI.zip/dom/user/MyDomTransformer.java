/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;


import java.util.HashSet;
import java.util.Set;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.NodeList;
/**
 *
 * @author Ghost
 */
public class MyDomTransformer {

    public void transform(Document xmlDocument) {
        // libovolne transformace objektu 'xmlDocument'
        // (metoda pracuje primo na objektu, nic nevraci)

        
        Element newPlayer = NewPlayer(xmlDocument, "Rio", "NCo", "true", "PG", "Mario", "Chalmers", "yesterday", "Chris Bosh");
        SetStats(xmlDocument, newPlayer, 17.0f, 8.4f, 1.1f, 0.1f, 3.1f, 15, 9, 0, 0, 4);
        xmlDocument.getElementsByTagName("TEAM").item(0).appendChild(newPlayer);
        
        
        
        NodeList players = xmlDocument.getElementsByTagName("PLAYER");
        for (int i = 0; i < players.getLength(); i++) {
            Element e = (Element)players.item(i);
            if (e.getAttribute("position").equals("C")) {
                xmlDocument.getElementsByTagName("TEAM").item(1).removeChild(xmlDocument.getElementsByTagName("PLAYER").item(i));               
            }
        }
    }
    
    private Element NewPlayer(Document xDoc, String nickname, String bestBuddy, String active, String position,
            String name, String surname, String lastCheckUp, String coop) {
        
        Element newPlayer = xDoc.createElement("PLAYER");
        newPlayer.setAttribute("playerID", nickname);
        newPlayer.setAttribute("bestBuddy", bestBuddy);
        newPlayer.setAttribute("active", active);
        newPlayer.setAttribute("position", position);
        
        Element eCoop = xDoc.createElement("COOP");
        eCoop.setTextContent(coop);
        newPlayer.appendChild(eCoop);
        
        Element eName = xDoc.createElement("NAME");
        eName.setTextContent(name);
        newPlayer.insertBefore(eName, newPlayer.getLastChild());
        
        Element eSurname = xDoc.createElement("SURNAME");
        eSurname.setTextContent(surname);
        newPlayer.insertBefore(eSurname, newPlayer.getLastChild());
        
        Element eDopping = xDoc.createElement("DOPPING");
        eDopping.setAttribute("lastCheckUp", lastCheckUp);        
        newPlayer.insertBefore(eDopping, newPlayer.getLastChild());
        
        
        
        return newPlayer;
    }
    
    private Element SetStats(Document xDoc, Element e, float ppg, float apg, float rpg, float bpg, float spg,
            int plg, int alg, int rlg, int blg, int slg) {
        
        Element stats = xDoc.createElement("STATS");
        
        Element eSLG = xDoc.createElement("SLG");
        eSLG.setTextContent(String.valueOf(slg));
        stats.appendChild(eSLG);
        
        
        Element ePPG = xDoc.createElement("PPG");
        ePPG.setTextContent(String.valueOf(ppg));
        stats.insertBefore(ePPG, stats.getLastChild());
        
        Element eAPG = xDoc.createElement("APG");
        eAPG.setTextContent(String.valueOf(apg));
        stats.insertBefore(eAPG, stats.getLastChild());
        
        Element eRPG = xDoc.createElement("RPG");
        eRPG.setTextContent(String.valueOf(rpg));
        stats.insertBefore(eRPG, stats.getLastChild());
        
        Element eBPG = xDoc.createElement("BPG");
        eBPG.setTextContent(String.valueOf(bpg));
        stats.insertBefore(eBPG, stats.getLastChild());
        
        Element eSPG = xDoc.createElement("SPG");
        eSPG.setTextContent(String.valueOf(spg));
        stats.insertBefore(eSPG, stats.getLastChild());
        
        
        Element ePLG = xDoc.createElement("PLG");
        ePLG.setTextContent(String.valueOf(plg));
        stats.insertBefore(ePLG, stats.getLastChild());
        
        Element eALG = xDoc.createElement("ALG");
        eALG.setTextContent(String.valueOf(alg));
        stats.insertBefore(eALG, stats.getLastChild());
        
        Element eRLG = xDoc.createElement("RLG");
        eRLG.setTextContent(String.valueOf(rlg));
        stats.insertBefore(eRLG, stats.getLastChild());
        
        Element eBLG = xDoc.createElement("BLG");
        eBLG.setTextContent(String.valueOf(blg));
        stats.insertBefore(eBLG, stats.getLastChild());
        
        e.insertBefore(stats, e.getLastChild());
        
        
        return e;
    }
}
