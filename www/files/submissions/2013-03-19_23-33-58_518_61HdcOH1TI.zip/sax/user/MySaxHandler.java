/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;


import java.io.IOException;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;
/**
 *
 * @author Ghost
 */
public class MySaxHandler extends DefaultHandler {
    // override metod DefaultHandleru
    
    Locator locator;
    int playerCount = 0;
    boolean getFirstName = false;
    boolean getLastName = false;
    int sf = 0;
    boolean getPPG = false;
    float sumOfPPG = 0;
    float averagePPG = 0;
    boolean getCheckUp = false;
    int activeCleanPlayers = 0;

    @Override
    public InputSource resolveEntity(String publicId, String systemId) throws IOException, SAXException {
        return null;
    }

    @Override
    public void notationDecl(String name, String publicId, String systemId) throws SAXException {
        super.notationDecl(name, publicId, systemId);
    }

    @Override
    public void unparsedEntityDecl(String name, String publicId, String systemId, String notationName) throws SAXException {
        super.unparsedEntityDecl(name, publicId, systemId, notationName);
    }

    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    @Override
    public void startDocument() throws SAXException {
        super.startDocument();
    }

    @Override
    public void endDocument() throws SAXException {
        averagePPG = sumOfPPG / playerCount;
        
        System.out.println("Pocet hracu v cele lize: " + playerCount);
        System.out.println("Pocet small forwardu v cele lize: " + sf);
        System.out.println("Pocet k dnesnimu dni cistych hracu: " + activeCleanPlayers);
        System.out.println("Prumerne nastrilene body za zapas v cele lize: " + averagePPG);      
    }

    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        super.startPrefixMapping(prefix, uri);
    }

    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        super.endPrefixMapping(prefix);
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        if (localName.equals("PPG")) {
            getPPG = true;
        } else if(localName.equals("PLAYER")) {
            playerCount++;
                for (int i = 0; i < attributes.getLength(); i++) {
                    String obsah = attributes.getValue(i);
                    if (obsah.equals("SF")) {
                        System.out.print("Nalezen SF (small forward), prezdivka: " + attributes.getValue(0));
                        sf++;
                        getFirstName = true;
                        getLastName = true;
                    }
                    if (attributes.getLocalName(i).equals("active") && obsah.equals("true")) {
                        getCheckUp = true;
                    }
                }
        } else if (localName.equals("DOPPING")) {
            if (getCheckUp) {
                    if (attributes.getValue(0).equals("today")) {
                        activeCleanPlayers++;
                    }
                    getCheckUp = false;
                }   
        }              
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        super.endElement(uri, localName, qName);
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        if (getFirstName) {
            System.out.print(", jmeno: " + String.copyValueOf(ch, start, length));
            getFirstName = false;
        } else if (getLastName) {
            System.out.println(", prijmeni: " + String.copyValueOf(ch, start, length));
            getLastName = false;
        } else if (getPPG) {
            sumOfPPG+= Float.parseFloat(String.copyValueOf(ch, start, length));
            getPPG = false;
        }    
    }

    @Override
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        super.ignorableWhitespace(ch, start, length);
    }

    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        super.processingInstruction(target, data);
    }

    @Override
    public void skippedEntity(String name) throws SAXException {
        super.skippedEntity(name);
    }

    @Override
    public void warning(SAXParseException e) throws SAXException {
        super.warning(e);
    }

    @Override
    public void error(SAXParseException e) throws SAXException {
        super.error(e);
    }

    @Override
    public void fatalError(SAXParseException e) throws SAXException {
        super.fatalError(e);
    }
  
}