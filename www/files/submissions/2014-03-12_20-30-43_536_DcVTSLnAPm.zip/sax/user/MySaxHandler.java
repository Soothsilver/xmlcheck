package user;

import java.util.HashMap;
import java.util.StringTokenizer;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

//Vybere maxim�ln� po�adov� ��slo mezi psy.
//3 slova, kter� se nej�ast�ji vyskytuj� v posudku 
//pocet psu hodnocenych "vyborna" a mlad�� 2 let

public class MySaxHandler extends DefaultHandler{

	int poradi=-1;
	HashMap<String, Integer> slova=new HashMap<String, Integer>();
	boolean vPosudku=false;
	int pocet=0;
	boolean mladsi=false;
	
	@Override
	public void characters(char[] ch, int start, int length)
			throws SAXException {
		if(vPosudku){
			int misto=start;
			StringBuffer sb=new StringBuffer();
			for(int i=0;i<length;++i){
				if(ch[misto]==' '||i==length-1){
					String slovo=sb.toString();
					sb=new StringBuffer();
					slovo=slovo.trim();
					if(!slovo.equals(""))
						if(!slova.containsKey(slovo))
							slova.put(slovo, 1);
						else
							slova.put(slovo, slova.get(slovo)+1);
				}
				else
					sb.append(ch[misto]);
				++misto;
			}
		}
	}

	@Override
	public void endDocument() throws SAXException {
		if(poradi==-1)
			System.out.println("��dn� psi nenalezeni.");
		else
			System.out.println("Nejvy��� po�adov� ��slo je: "+poradi);
		int a=0;
		String co="";
		for(String slovo:slova.keySet())
			if(slova.get(slovo)>a){
				a=slova.get(slovo);
				co=slovo;
			}
		if(co.equals(""))
			System.out.println("Nanalezeny ��dn� posudky.");
		else{
			System.out.println("V posudku se nej�ast�ji vyskytuje: "+co);
			slova.remove(co);
			a=0;
			co="";
			for(String slovo:slova.keySet())
				if(slova.get(slovo)>a){
					a=slova.get(slovo);
					co=slovo;
				}
			if(!co.equals("")){
				System.out.println("V posudku se druh� nej�ast�ji vyskytuje: "+co);
				slova.remove(co);
				a=0;
				co="";
				for(String slovo:slova.keySet())
					if(slova.get(slovo)>a){
						a=slova.get(slovo);
						co=slovo;
					}
				if(!co.equals(""))
					System.out.println("V posudku se t�et� nej�ast�ji vyskytuje: "+co);
			}
		}
		System.out.println("Po�et ps� mlad��ch 2 let s hodnocem�m v�born� je: "+pocet);
	}

	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		vPosudku=false;
		mladsi=false;
	}

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {
		if(localName.equals("posudek")&&mladsi)
			if(attributes.getLength()!=0&&attributes.getValue("hodnoceni").equals("Vyborna"))
				++pocet;
		if(localName.equals("pes")||localName.equals("fena")){
			int por=Integer.parseInt(attributes.getValue("poradi"));
			if(por>poradi)
				poradi=por;
			StringTokenizer st=new StringTokenizer(attributes.getValue("datum_narozeni"), ".");
			int den=Integer.parseInt(st.nextToken());
			int mesic=Integer.parseInt(st.nextToken());
			int rok=Integer.parseInt(st.nextToken());
			if(rok>2012||(rok==2012&&(mesic>3||(mesic==3&&den>12))))
				mladsi=true;
		}
		if(localName.equals("posudek"))
			vPosudku=true;
	}

}
