package user;

import org.w3c.dom.*;

public class MyDomTransformer {
	
	public void transform (Document xmlDocument) {
	    //p�id� psa k rase Tibetsk� �pan�l
		Element pes=xmlDocument.createElement("pes");
		pes.setAttribute("registracni_cislo", "CMKU/TS/1539/-12/12");
		pes.setAttribute("poradi", "8503");
		pes.setAttribute("jmeno", "Holm-hansens alpha");
		pes.setAttribute("datum_narozeni", "12.4.2012");
		pes.setAttribute("otec", "Kham-pa zeus sommerlysts");
		pes.setAttribute("matka", "Tantra tsamo vom Summestarn");
		pes.setAttribute("majitel", "Lucie Jelinkova");
		pes.setAttribute("chovatel", "Holm-hansen Julie a Morten R.");
		Element posudek=xmlDocument.createElement("posudek");
		posudek.setTextContent("Hezk� pes.");
		pes.appendChild(posudek);
		NodeList rasy=xmlDocument.getElementsByTagName("rasa");
		for(int i=0;i<rasy.getLength();++i){
			if(((Element)rasy.item(i)).getAttribute("jmeno").equals("tibetsky_spanel")){
				NodeList tridy=((Element)rasy.item(i)).getElementsByTagName("trida");
				boolean maTridu=false;
				for(int j=0;j<tridy.getLength();++j){
					if(((Element)tridy.item(j)).getAttribute("nazev").equals("mezitrida")){
						if(((Element)tridy.item(j)).getElementsByTagName("fena").getLength()==0){
							maTridu=true;
							tridy.item(j).appendChild(pes);
							break;
						}
					}
				}
				if(!maTridu){
					Element trida=xmlDocument.createElement("trida");
					trida.setAttribute("nazev", "mezitrida");
					rasy.item(i).appendChild(trida);
					trida.appendChild(pes);
					break;
				}
			}
		}
		
		//odebere psa, kter� m� v posudku "o�kliv� pes"
		NodeList posudky=xmlDocument.getElementsByTagName("posudek");
		for(int i=posudky.getLength()-1;i>-1;--i){
			if(posudky.item(i).getTextContent().contains("o�kliv� pes")){
				pes=(Element) posudky.item(i).getParentNode();
				Element trida=(Element) pes.getParentNode();
				Element rasa=(Element) trida.getParentNode();
				Element kruh=(Element)rasa.getParentNode();
				Element vystava=(Element)kruh.getParentNode();
				trida.removeChild(pes);
				if(trida.getElementsByTagName("pes").getLength()==0&&trida.getElementsByTagName("fena").getLength()==0){
					rasa.removeChild(trida);
					if(rasa.getElementsByTagName("trida").getLength()==0){
						kruh.removeChild(rasa);
						if(kruh.getElementsByTagName("rasa").getLength()==0)
							vystava.removeChild(kruh);
					}
				}
			}
		}
	}
}
