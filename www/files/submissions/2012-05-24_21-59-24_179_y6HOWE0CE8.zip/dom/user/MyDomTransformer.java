package user;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

/**
 * ZADANI:
 * Upravte program tak, aby transformoval vstupní XML dokument na výstupní pomocí akcí
 * uvedených v komentářích metody processTree(doc).
 */
public class MyDomTransformer {

   
    public void transform (Document doc) {
        reverseNodes(doc.getChildNodes().item(0).getChildNodes());
    }
    
    private void reverseNodes(NodeList nl){
	
	for(int index = nl.getLength() - 1; index >= 0; index--){
	    Node n  = nl.item(index);
	    
	    NamedNodeMap attrs = n.getAttributes();
	    if(attrs != null){
		String[] rem = new String[attrs.getLength()];
		for(int i = 0; i < attrs.getLength(); i++){
		    Node attr = attrs.item(i);
		    if(attr != null){
			rem[i] = attr.getNodeName();
			
			Element e = n.getOwnerDocument().createElement(attr.getNodeName());
			e.setTextContent(attr.getTextContent());
			n.appendChild(e);
		    }
		}
		
		for(int i = 0; i < rem.length; i++){
		    attrs.removeNamedItem(rem[i]);
		}
	    }
	    reverseNodes(n.getChildNodes());
	    Node pnode = n.getParentNode();
	    pnode.appendChild(n);
	}
    }
}
