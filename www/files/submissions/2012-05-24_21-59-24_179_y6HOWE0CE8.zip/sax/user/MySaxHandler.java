package user;

import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler  {

    // Umožňuje zacílit místo v dokumentu, kde vznikla aktualní událost
    Locator locator;
    int pocet_atributu;
    int pocet_elementu;
    int pocet_podelementu;
    int max_pocet_podelementu;
    int max_pocet_atributu;
    int max_delka_nazvu;
    int celkova_delka_nazvu;
    int pocet_elementu_s_potomky;
    int actual_faOut;
    int max_fanOut;
    /**
     * Nastaví locator
     */     
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Obsluha události "za�?átek dokumentu"
     */     
    @Override
    public void startDocument() throws SAXException {
        
        System.out.println("READING STARTED");
	pocet_atributu = 0;
	pocet_elementu = 0;
	pocet_podelementu = 0;
	max_pocet_podelementu = 0;
	max_pocet_atributu = 0;
	max_delka_nazvu = 0;
	celkova_delka_nazvu = 0;
	pocet_elementu_s_potomky = 0;
        this.actual_faOut = 0;
	max_fanOut = 0;
    }
    /**
     * Obsluha události "konec dokumentu"
     */     
    @Override
    public void endDocument() throws SAXException {
        
	System.out.println("maximalne pocet atributu: " + max_pocet_atributu);
	double p1 = (double)pocet_atributu / (double)pocet_elementu;
	double p2 = (double)celkova_delka_nazvu / (double)pocet_elementu;
	System.out.println("prumerny pocet atributu: " + p1);
	System.out.println("maximalni delka nazvu: " + max_delka_nazvu);
	System.out.println("prumerna delka nazvu: " + p2);
	System.out.println("pocet elementu celkem: " + pocet_elementu);
        System.out.println("pocet atributu celkem: " + pocet_atributu);
	System.out.println("maximalni fan out: " + max_fanOut);
	System.out.println("READING END");
        
    }
    
    /**
     * Obsluha události "za�?átek elementu".
     * @param uri URI jmenného prostoru elementu (prázdné, pokud element není v žádném jmenném prostoru)
     * @param localName Lokální jméno elementu (vždy neprázdné)
     * @param qName Kvalifikované jméno (tj. prefix-uri + ':' + localName, pokud je element v nějakém jmenném prostoru, nebo localName, pokud element není v žádném jmenném prostoru)
     * @param atts Atributy elementu     
     */     
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        // ...
	this.actual_faOut++;
	pocet_elementu ++;
	pocet_atributu += atts.getLength();
	//pocet_podelementu = locator;
	//max_pocet_podelementu = 0;
	if(max_pocet_atributu < atts.getLength()){
	    max_pocet_atributu = atts.getLength();
	}
	
	if(max_delka_nazvu < localName.length()){
	    max_delka_nazvu = localName.length();
	}
	
	celkova_delka_nazvu += localName.length();
	
	if(actual_faOut > max_fanOut){
	    max_fanOut = actual_faOut;
	}
	
	//pocet_elementu_s_potomky = 0;
    }
    /**
     * Obsluha události "konec elementu"
     * Parametry mají stejný význam jako u @see startElement     
     */     
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
	this.actual_faOut--;
        // ...

    }
    
    /**
     * Obsluha události "znaková data".
     * SAX parser muľe znaková data dávkovat jak chce. Nelze tedy po�?ítat s tím, že je celý text dorucen v rámci jednoho volání.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakovými daty
     * @param start Index zacátku úseku platných znakových dat v poli.
     * @param length Délka úseku platných znakových dat v poli.
     */               
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {

        // ...
        
    }
    
    /**
     * Obsluha události "deklarace jmenného prostoru".
     * @param prefix Prefix prirazený jmennému prostoru.
     * @param uri URI jmenného prostoru.
     */     
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha události "konec platnosti deklarace jmenného prostoru".
     */     
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
    
        // ...
    
    }

    /**
     * Obsluha události "ignorované bílé znaky".
     * Stejné chování a parametry jako @see characters     
     */     
    @Override
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha události "instrukce pro zpracování".
     */         
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
      
      // ...
            
    }

    /**
     * Obsluha události "nezpracovaná entita"
     */         
    @Override
    public void skippedEntity(String name) throws SAXException {
    
      // ...
    
    }
}