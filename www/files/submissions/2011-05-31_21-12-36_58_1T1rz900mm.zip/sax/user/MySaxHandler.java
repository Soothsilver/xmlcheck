package user;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler
{
	
	/**
	 * @param args
	 * @throws SAXException 
	 * @throws ParserConfigurationException 
	 * @throws IOException 
	 */
	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException
	{
		SAXParserFactory spf = SAXParserFactory.newInstance();
		spf.setValidating(false);
		SAXParser sp = spf.newSAXParser();
		InputSource input = new InputSource(new FileReader(args[0]));
		input.setSystemId("file://" + new File(args[0]).getAbsolutePath());
		MySaxHandler handler = new MySaxHandler();
		sp.parse(input, handler);
		handler.output();
	}
	
	private Map<String, Integer> element_counts;
	
	public MySaxHandler()
	{
		this.element_counts = new HashMap<String, Integer>();
	}
	
	public void startElement (String uri, String localName, String qName, Attributes attributes)
		throws SAXException
	{
		Integer current_count = this.element_counts.get(qName);
		if (current_count == null)
		{
			current_count = 1;
		}
		else
		{
			current_count++;
		}
		this.element_counts.put(qName, current_count);
	}
	
	public void output()
	{
		System.out.println("Element count stats:");
		Iterator<Entry<String, Integer>> it = this.element_counts.entrySet().iterator();
		while (it.hasNext())
		{
			Entry<String, Integer> current_stats = it.next();
			System.out.println("Element '"+current_stats.getKey()+"': "+current_stats.getValue()+" occurences");
		}
	}
}
