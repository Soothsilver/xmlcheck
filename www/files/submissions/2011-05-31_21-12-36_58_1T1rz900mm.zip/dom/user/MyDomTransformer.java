package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer
{
	
	public void transform(Document xmlDocument)
	{
		NodeList tasks = xmlDocument.getElementsByTagName("task");
		int n = tasks.getLength();
		for (int i = 0; i < n; i++)
		{
			Element current = (Element) tasks.item(i);
			String task_text = current.getTextContent();
			current.setTextContent("");
			current.setAttribute("text", task_text);
		}
	}
}
