package user;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {

    class Tym {

        String nazev;
        String id;
        int body;
    }

    class Hrac {

        String jmeno, prijmeni;
        int rok;
    }
    // buffer na textove elementy
    boolean textovyElement = false;
    StringBuilder buffer = new StringBuilder();
    // 1
    int pocet100Procentnich;
    int pocetVHospode;
    // 2
    ArrayList<Hrac> hraci = new ArrayList<Hrac>();
    Hrac aktualniHrac;
    // 3
    HashMap<String, Tym> tymyVHospode;
    ArrayList<Tym> tabulka;
    ArrayList<Tym> dobreTymyVHospode = new ArrayList<Tym>();
    Tym aktualniTym;

    @Override
    public void endDocument() throws SAXException {
        // 1. hodnoty atributu
        System.out.println("Pocet tymu, ktere hraji v hospode: " + pocetVHospode);
        System.out.println("Pocet tymu, ktere maji 100% uspesnost: " + pocet100Procentnich);
        System.out.println();

        // 2. obsah elementu
        Collections.sort(hraci, new Comparator<Hrac>() {
            public int compare(Hrac o1, Hrac o2) {
                return o1.rok - o2.rok;
            }
        });
        System.out.println("Pocet registrovanych hracu: " + hraci.size());
        double prumer = 0;
        int rok = Calendar.getInstance().get(Calendar.YEAR);
        for (Hrac h : hraci) {
            prumer += rok - h.rok;
        }
        if (hraci.size() > 0) {
            prumer /= hraci.size();
        }
        System.out.println("Prumerny vek hracu: " + prumer);
        System.out.println("Tri nejstarsi hraci:");
        for (int i = 0; i < 3 && i < hraci.size(); i++) {
            Hrac h = hraci.get(i);
            System.out.format("    %s %s (%d)\n", h.jmeno, h.prijmeni, rok - h.rok);
        }
        System.out.println("Tri nejmladsi hraci:");
        for (int i = 0; i < 3 && i < hraci.size(); i++) {
            Hrac h = hraci.get(hraci.size() - i - 1);
            System.out.format("    %s %s (%d)\n", h.jmeno, h.prijmeni, rok - h.rok);
        }
        System.out.println();

        // 3. kontext
        System.out.println("Tymy, ktere hraji v hospode a jsou mezi prvnimi tremi v tabulce:");
        for (Tym t : dobreTymyVHospode) {
            System.out.println("    " + t.nazev);
        }
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        // <soutez>
        if ("soutez".equals(localName)) {
            tymyVHospode = new HashMap<String, Tym>();
        } // <tym>
        else if ("tym".equals(localName)) {
            aktualniTym = new Tym();
            // nazev a id
            for (int i = 0; i < atts.getLength(); i++) {
                if ("nazev".equals(atts.getLocalName(i))) {
                    aktualniTym.nazev = atts.getValue(i);
                }

                if ("tid".equals(atts.getLocalName(i))) {
                    aktualniTym.id = atts.getValue(i);
                }
            }
        } // <herna>
        else if ("herna".equals(localName) && aktualniTym != null) {

            // nazev
            for (int i = 0; i < atts.getLength(); i++) {
                if ("nazev".equals(atts.getLocalName(i))) {
                    String herna = atts.getValue(i);
                    if (herna.contains("hospoda")) {
                        ++pocetVHospode;
                    } else {
                        aktualniTym = null;
                    }
                }
            }
        } // <tabulka>
        else if ("tabulka".equals(localName)) {
            tabulka = new ArrayList<Tym>();
        } // <radek>
        else if ("radek".equals(localName)) {

            aktualniTym = new Tym();

            for (int i = 0; i < atts.getLength(); i++) {
                if ("prohry".equals(atts.getLocalName(i))) {
                    if (Integer.parseInt(atts.getValue(i)) == 0) {
                        ++pocet100Procentnich;
                    }
                }
                if ("tidr".equals(atts.getLocalName(i))) {
                    aktualniTym.id = atts.getValue(i);
                }
                if ("body".equals(atts.getLocalName(i))) {
                    aktualniTym.body = Integer.parseInt(atts.getValue(i));
                }
            }

        } // <hrac>
        else if ("hrac".equals(localName)) {
            aktualniHrac = new Hrac();
        } // <krestni>
        else if ("krestni".equals(localName) && aktualniHrac != null) {
            textovyElement = true;
            buffer.delete(0, buffer.length());
        } // <prijmeni>
        else if ("prijmeni".equals(localName) && aktualniHrac != null) {
            textovyElement = true;
            buffer.delete(0, buffer.length());
        } // <rok>
        else if ("rok".equals(localName) && aktualniHrac != null) {
            textovyElement = true;
            buffer.delete(0, buffer.length());
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {

        // <soutez>
        if ("soutez".equals(localName) && tymyVHospode != null) {
            tymyVHospode = null;
        } // <tym>
        else if ("tym".equals(localName) && aktualniTym != null && tymyVHospode != null) {
            tymyVHospode.put(aktualniTym.id, aktualniTym);
            aktualniTym = null;
        } // <hrac>
        else if ("hrac".equals(localName) && aktualniHrac != null) {
            hraci.add(aktualniHrac);
            aktualniHrac = null;
        } // <krestni>
        else if ("krestni".equals(localName) && aktualniHrac != null) {
            aktualniHrac.jmeno = buffer.toString();

            textovyElement = false;
            buffer.delete(0, buffer.length());
        } // <prijmeni>
        else if ("prijmeni".equals(localName) && aktualniHrac != null) {
            aktualniHrac.prijmeni = buffer.toString();

            textovyElement = false;
            buffer.delete(0, buffer.length());
        } // <rok>
        else if ("rok".equals(localName) && aktualniHrac != null) {
            aktualniHrac.rok = Integer.parseInt(buffer.toString());

            textovyElement = false;
            buffer.delete(0, buffer.length());
        } // <radek>
        else if ("radek".equals(localName) && aktualniTym != null && tabulka != null) {
            tabulka.add(aktualniTym);
            aktualniTym = null;
        } // <tabulka>
        else if ("tabulka".equals(localName) && tabulka != null) {
            Collections.sort(tabulka, new Comparator<Tym>() {
                public int compare(Tym o1, Tym o2) {
                    return o2.body - o1.body;
                }
            });
            for (int i = 0; i < 3 && i < tabulka.size(); i++) {
                Tym t = tabulka.get(i);
                if (tymyVHospode.containsKey(t.id)) {
                    dobreTymyVHospode.add(tymyVHospode.get(t.id));
                }
            }
            tabulka = null;
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        if (textovyElement) {
            buffer.append(ch, start, length);
        }
    }
}
