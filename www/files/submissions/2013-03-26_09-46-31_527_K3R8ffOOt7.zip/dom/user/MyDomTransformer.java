package user;

import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer {

    class Hrac {

        public Hrac(String krestni, String prijmeni) {
            this.krestni = krestni;
            this.prijmeni = prijmeni;
            Random rnd = new Random();
            this.rok = 1950 + rnd.nextInt(50);
            this.umisteni = "kraj " + (1 + rnd.nextInt(1000));
        }
        String krestni, prijmeni;
        int rok;
        String umisteni;
    }

    public void transform(Document xmlDocument) {
        prepisJmena(xmlDocument);
        pridatHrace(xmlDocument, new Hrac("Petr", "Pavel"));
        pridatHrace(xmlDocument, new Hrac("Robert", "Rodriguez"));
        pridatHrace(xmlDocument, new Hrac("Quentin", "Tarantino"));
        seraditTabulky(xmlDocument);
    }

    /**
     * Prepise elementy <krestni> a <prijmeni> na atributy
     *
     * @param doc
     */
    private void prepisJmena(Document doc) {
        NodeList list = doc.getElementsByTagName("jmeno");
        for (int i=0; i<list.getLength(); i++) {
            Element e = (Element) list.item(i);
            while (e.hasChildNodes()) {
                Node p = e.getFirstChild();
                if ("krestni".equals(p.getNodeName())) {
                    e.setAttribute("krestni", p.getTextContent());
                } else if ("prijmeni".equals(p.getNodeName())) {
                    e.setAttribute("prijmeni", p.getTextContent());
                }
                e.removeChild(p);
            }
        }
    }

    /**
     * Prida hrace s danymi udaji do nahodneho tymu
     *
     * @param doc
     * @param h hrac
     */
    private void pridatHrace(Document doc, Hrac h) {
        // najdeme nejmensi mozne neobsazene id hrace
        NodeList list = doc.getElementsByTagName("hrac");
        int id = 1;
        for (int i=0; i<list.getLength(); i++) {
            Element e = (Element) list.item(i);
            int hid = 0;
            try {
                hid = Integer.parseInt(e.getAttribute("hid").substring(1));
            } catch (Exception ex) {
            }
            if (hid >= id) {
                id = hid + 1;
            }
        }

        Element jmeno = doc.createElement("jmeno");
        jmeno.setAttribute("krestni", h.krestni);
        jmeno.setAttribute("prijmeni", h.prijmeni);
        Element rok = doc.createElement("rok");
        rok.setTextContent("" + h.rok);
        Element umisteni = doc.createElement("umisteni");
        umisteni.setTextContent(h.umisteni);

        Element hrac = doc.createElement("hrac");
        hrac.setAttribute("hid", "h" + (id < 10 ? "0" : "") + id);
        hrac.appendChild(jmeno);
        hrac.appendChild(rok);
        hrac.appendChild(umisteni);

        // pridame jej do nejakeho tymu
        NodeList sestavy = doc.getElementsByTagName("sestava");
        Random rnd = new Random();
        Element sestava = (Element) sestavy.item(rnd.nextInt(sestavy.getLength()));
        sestava.appendChild(hrac);
    }

    /**
     * Seradi radky v tabulkach podle poctu bodu
     * @param doc 
     */
    private void seraditTabulky(Document doc) {

        NodeList list = doc.getElementsByTagName("tabulka");
        for (int i=0; i<list.getLength(); i++) {
            Element e = (Element) list.item(i);
            ArrayList<SimpleEntry<Integer, Node>> tabulka = new ArrayList<SimpleEntry<Integer, Node>>();
            while (e.hasChildNodes()) {
                Node r = e.getFirstChild();
                if(r.getNodeType() == Node.ELEMENT_NODE){
                    int body = Integer.parseInt(((Element) r).getAttribute("body"));
                    tabulka.add(new SimpleEntry<Integer, Node>(body, r));
                }
                e.removeChild(r);
            }
            Collections.sort(tabulka, new Comparator<SimpleEntry<Integer, Node>>() {
                public int compare(SimpleEntry<Integer, Node> o1, SimpleEntry<Integer, Node> o2) {
                    return o2.getKey() - o1.getKey();
                }
            });
            for (SimpleEntry<Integer, Node> en : tabulka) {
                e.appendChild(en.getValue());
            }
        }
    }

    
}
