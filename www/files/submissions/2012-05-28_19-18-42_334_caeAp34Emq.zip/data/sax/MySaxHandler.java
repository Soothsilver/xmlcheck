package user;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
	
	int count = 0;
	int depth = 0;
	int maxDepth = 0;

	public void startElement(String namespaceURI, String localName, String qName, Attributes atts) throws SAXException {
		if(qName.equals("artist")) {
			count++;
		}
		if(depth++>maxDepth) {
			maxDepth=depth;
		}
	}
	
	public void endElement(String uri, String localName, String qName) {
		depth--;
	}
	
	public void endDocument() throws SAXException {       
		System.out.println("Arists count: " + count);
		System.out.println("Max depth of document: " + maxDepth);
	}
	
	/*public static void main(String[] args) {
		String filename = "C:/testy/xml/data.xml";
        
        try {            
            SAXParserFactory spfactory = SAXParserFactory.newInstance();
            spfactory.setValidating(false);
            
            SAXParser saxparser = spfactory.newSAXParser();
            
            XMLReader xmlreader = saxparser.getXMLReader();
            
            xmlreader.setContentHandler(new MySaxHandler());
            xmlreader.setErrorHandler(new MySaxHandler());
            
            InputSource source = new InputSource(filename);
            xmlreader.parse(source);
            
        } catch (Exception e) {
            e.printStackTrace();
        }

	}*/

}
