/*
 * ----------------------------------------------------------------------------
 * "THE BEER-WARE LICENSE" (Revision 42):
 * <petr.kalivoda@gmail.com> wrote this file. As long as you retain this notice you
 * can do whatever you want with this stuff. If we meet some day, and you think
 * this stuff is worth it, you can buy me a beer in return.
 * ----------------------------------------------------------------------------
 */
package user;
import java.util.HashMap;
import java.util.HashSet;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * @author cypher
 */
public class MySaxHandler extends DefaultHandler {
    
    //[1]
    private HashMap<String, Integer> genres = new HashMap<String, Integer>();
    
    //[2]
    private int songlength = 0;
    private int songcount = 0;
    private String lengthbuffer = new String();
    private boolean parsing_length = false;
    
    //[3]
    private boolean parsing_interpret = false;
    private boolean has_description;
    private boolean sings_country;
    private String curname;
    private HashSet<String> interprets = new HashSet<String>();
    
  @Override
  public void startElement(String uri, String localName, String qName, Attributes attributes) {
      if(qName.equals("žánr")) {
          String name = attributes.getValue("název");
          if(name.toLowerCase().equals("country")) {
              sings_country = true;
          }
          
          if(genres.containsKey(name)) {
              genres.put(name, genres.get(name)+1);
              
          }else {
              genres.put(name, 1);
          }
      }
      
      if(qName.equals("délka")) {
          parsing_length = true;
          lengthbuffer = "";
      }
      
      if(qName.equals("interpret")) {
          has_description = false;
          sings_country = false;
      }
      
      if(qName.equals("název")) {
          parsing_interpret = true;
          curname = "";
      }
      
      if(qName.equals("popis")) {
          has_description = true;
      }
  }
  
  @Override
  public void endElement(String uri, String localName, String qName) {
      if(qName.equals("délka")) {
          parsing_length = false;
          //zpracovat délku
          String[] buf = lengthbuffer.split(":");
          songlength += (Integer.parseInt(buf[0]) * 60);
          songlength += Integer.parseInt(buf[1]);
          songcount += 1;
      }
      
      if(qName.equals("název")) {
          parsing_interpret = false;
      }
      
      if(qName.equals("interpret")) {
          if(sings_country && !has_description) {
              interprets.add(curname);
          }
      }
  }
  
  @Override
  public void characters(char[] ch, int start, int length) {
      if(parsing_interpret) {
          for (int i = 0; i < length; i++) {
              char c = ch[i+start];
              curname += c;
          }
      }
      
      if(parsing_length) {
          for (int i = 0; i < length; i++) {
              char c = ch[i+start];
              lengthbuffer += c;
          }
      }
  }
  
  @Override
  public void endDocument() {
      System.out.println("[1]: žánry hudby s výpisem četností:");
      for(String name : genres.keySet()) {
          Integer count = genres.get(name);
          System.out.println(" - "+name+ " "+count+ " krát.");
      }
      
      System.out.printf("[2]: Průměrná délka písničky: %.2f vteřin.\n", ((double)songlength/songcount));
      System.out.println("[3]: Seznam interpretů, kteří zpívají country, ale nemají <popis>:");
      for(String name: interprets) {
          System.out.println(" - "+ name);
      }
      
  }
}