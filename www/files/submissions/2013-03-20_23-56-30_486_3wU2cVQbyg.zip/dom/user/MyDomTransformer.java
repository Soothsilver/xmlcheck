/*
 * ----------------------------------------------------------------------------
 * "THE BEER-WARE LICENSE" (Revision 42):
 * <petr.kalivoda@gmail.com> wrote this file. As long as you retain this notice you
 * can do whatever you want with this stuff. If we meet some day, and you think
 * this stuff is worth it, you can buy me a beer in return.
 * ----------------------------------------------------------------------------
 */
package user;

/**
 *
 * @author cypher
 */
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
public class MyDomTransformer {
    public void transform (Document xmlDocument) {
        //[1]: přidám nového interpreta
         NodeList nodes = xmlDocument.getElementsByTagName("interpreti");
         Element interprets;
         Integer id = 0;
         
         if(nodes.getLength() == 0) {
             interprets = xmlDocument.createElement("interpreti");
             xmlDocument.getFirstChild().appendChild(interprets);
             
         }else {
             //hledám ID
             interprets = (Element)nodes.item(0);
             NodeList intr = xmlDocument.getElementsByTagName("interpret");
             for (int i = 0; i < intr.getLength(); i++) {
                 Node n = intr.item(i);
                 Integer nid = Integer.parseInt(n.getAttributes().getNamedItem("id").getNodeValue().split("-")[1]);
                 if(nid > id) {
                     id = nid;
                 }
             }
         }
         
         Element interpret = xmlDocument.createElement("interpret");
         interpret.setAttribute("id", "in-"+(id+1)); //nový ID
         
         //název
         Element name = xmlDocument.createElement("název");
         name.setTextContent("The Rolling Stones");
         interpret.appendChild(name);
         
         //žánr
         Element genre = xmlDocument.createElement("žánr");
         genre.setAttribute("název", "RockAndRoll");
         genre.setAttribute("textový-popis", "Rock &amp; roll");
         interpret.appendChild(genre);
         
         //popis
         Element description = xmlDocument.createElement("popis");
         description.setTextContent("The Rolling Stones je britská rokenrolová skupina"
                 + " v čele se zpěvákem Mickem Jaggerem. Vznikla v Londýně v roce "
                 + "1962 a hraje dodnes. Skupina se proslavila počátkem 60. let "
                 + "jako protipól skupiny The Beatles.");
         interpret.appendChild(description);
         
         //a celej interpret 
         interprets.appendChild(interpret);
         
         //[2] seřadim interprety abecedně podle jména
         //[2.1] načtu stávající interprety, hodim do listu
         NodeList current_interprets = xmlDocument.getElementsByTagName("interpret");
         ArrayList<Node> nodeslist = new ArrayList<Node>();
         for (int i = 0; i < current_interprets.getLength(); i++) {
            nodeslist.add(current_interprets.item(i));
         }
         
         //[2.2] seřadím list
         Collections.sort(nodeslist, new Comparator<Node>(){
             @Override
             public int compare(Node one, Node two) {
                 if(!one.getNodeName().equals("interpret") || !two.getNodeName().equals("interpret")) {
                     throw new IllegalArgumentException("Neni interpret.");
                 }
                 
                 Node nameA = one.getFirstChild(), nameB = two.getFirstChild();
                 while(nameA.getNodeType() != Node.ELEMENT_NODE) {
                     nameA = nameA.getNextSibling();
                 }
                 
                 while(nameB.getNodeType() != Node.ELEMENT_NODE) {
                     nameB = nameB.getNextSibling();
                 }
                 
                 return nameA.getTextContent().compareToIgnoreCase(nameB.getTextContent());
             }
         });
         
         //[2.3] smažu všechny interprety v dokumentu
         for (int i = 0; i < interprets.getChildNodes().getLength(); i++) {
            interprets.removeChild(interprets.getChildNodes().item(i));
         }
         
         //[2.4] hodim je tam zpátky seřazený
         for(Node n : nodeslist) {
             Node q = n.getFirstChild();
             while(q.getNodeType() != Node.ELEMENT_NODE) {
                 q = q.getNextSibling();
             }
             
             interprets.appendChild(n);
         }
         
         //[2.5] profit
      }
}