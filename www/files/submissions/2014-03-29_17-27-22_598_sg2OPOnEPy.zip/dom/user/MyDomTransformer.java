package user;
import org.w3c.dom.*;

public class MyDomTransformer {
	public void transform (Document xmlDocument) {
		
		// Add new hero to the list
		if(xmlDocument.getElementsByTagName("dota") == null)
		{
			// Create
		}
		
		Element dota = (Element)xmlDocument.getElementsByTagName("dota").item(0);
		if(dota.getChildNodes().getLength() == 0)
		{
			// Create heroes element
		}
		
		Element heroes = (Element)xmlDocument.getElementsByTagName("heroes").item(0);
		NodeList heroList = xmlDocument.getElementsByTagName("hero");
		
		// Find new unique ID
		int idNo = 1;
		String idPrefix = "h_";
		int i = 0;
		while(i < heroList.getLength())
		{
			if(((Element)heroList.item(i)).getAttribute("id").compareTo(idPrefix  + idNo) == 0)
			{
				++idNo;
				i = 0;
			}
			else
				++i;
		}
		
		Element newHero = (Element)heroes.appendChild(xmlDocument.createElement("hero"));
		newHero.setAttribute("id", idPrefix + idNo);
		((Element)newHero.appendChild(xmlDocument.createElement("type"))).setAttribute("id", "t_1");
		((Element)newHero.appendChild(xmlDocument.createElement("name"))).setTextContent("Crixalis");
		((Element)newHero.appendChild(xmlDocument.createElement("class"))).setTextContent("Sand King");
		((Element)newHero.appendChild(xmlDocument.createElement("moveSpeed"))).setTextContent("300");
		// Stats
		Element str = (Element)newHero.appendChild(xmlDocument.createElement("strength"));
		str.setTextContent("18");
		str.setAttribute("growth", "2.6");
		Element agi = (Element)newHero.appendChild(xmlDocument.createElement("agility"));
		agi.setTextContent("19");
		agi.setAttribute("growth", "2.1");
		Element intel = (Element)newHero.appendChild(xmlDocument.createElement("intelligence"));
		intel.setTextContent("16");
		intel.setAttribute("growth", "1.8");
		((Element)newHero.appendChild(xmlDocument.createElement("hp"))).setTextContent("492");
		((Element)newHero.appendChild(xmlDocument.createElement("mana"))).setTextContent("208");
		((Element)newHero.appendChild(xmlDocument.createElement("damage"))).setTextContent("51");
		((Element)newHero.appendChild(xmlDocument.createElement("armor"))).setTextContent("2.66");
		// Attack
		Element attack = (Element)newHero.appendChild(xmlDocument.createElement("attack"));
		Element speed = (Element)attack.appendChild(xmlDocument.createElement("speed"));
		((Element)speed.appendChild(xmlDocument.createElement("attacksPerSecond"))).setTextContent("0.7");
		((Element)speed.appendChild(xmlDocument.createElement("baseAttackTime"))).setTextContent("1.7");
		Element range = (Element)attack.appendChild(xmlDocument.createElement("attackRange"));
		range.setAttribute("type", "melee");
		range.setTextContent("100");
		((Element)newHero.appendChild(xmlDocument.createElement("lore"))).setTextContent("The sands of the Scintillant Waste are alive and sentient ...");
		
		// Remove all heroes with range > 300
		i = 0;
		while(i < heroList.getLength())
		{
			Element hero = (Element)heroList.item(i);
			if(Integer.parseInt(hero.getElementsByTagName("attackRange").item(0).getTextContent()) > 300)
			{
				heroes.removeChild(hero);
			}
			else
				++i;
		}
	}
}