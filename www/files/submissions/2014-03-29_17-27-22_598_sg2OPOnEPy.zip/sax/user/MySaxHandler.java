package user;

import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
	// Helper variable to store location of the handled event
    Locator locator;

    // Statistics
    float avgStrGrowth;        // what is the average strength growth?
    String bestStrGrowthHero;  // who has the biggest str growth?
    StringBuffer maxRangeHero; // who is the hero with max range?
    int goodAgiHeroes;        // how many non-agi heroes have base agility >= 20?
    
    // Helpers and context 
    int heroCountAll;
    float strGrowthSum;
    float bestStrGrowth;
    
    int maxRange;
    StringBuffer range;
    StringBuffer currentHero;
    boolean getHero;
    boolean getRange;
    
    boolean isAgi;
    boolean getAgility;
    StringBuffer currentAgility;
   
    
    /**
     * Sets the locator
     *
     * @param Locator locator location in the file
     */
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Method to handle "document start"
     *
     * @throws SAXException
     */
    @Override
    public void startDocument() throws SAXException {
    	// Initialize
    	avgStrGrowth = 0;
    	goodAgiHeroes = 0;
    	heroCountAll = 0;
    	strGrowthSum = 0;
    	maxRange = 0;
    	isAgi = false;
    	getHero = false;
    	getRange = false;
    	bestStrGrowth = 0;
    	getAgility = false;
    }

    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
        // Output all the statistics
    	System.out.println("Average strength growth is: " + strGrowthSum / heroCountAll);
    	System.out.println("Hero with the highest strength growth is: " + bestStrGrowthHero);
    	System.out.println("Hero with maximum range is: " + maxRangeHero);
    	System.out.println("Non-agility heroes with base agility higher or equal to 20 cout: " + goodAgiHeroes);
    }

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        // Avg strength grow
    	if(localName.equals("strength"))
    	{
    		for(int i = 0; i < atts.getLength(); ++i)
    		{
    			if(atts.getLocalName(i).equals("growth"))
    			{
    				float strGrowth = Float.parseFloat(atts.getValue(i));
    				strGrowthSum += strGrowth;
    				++heroCountAll;
    				if(strGrowth > bestStrGrowth)
    				{
    					bestStrGrowth = strGrowth;
    					bestStrGrowthHero = new String(currentHero);
    				}
    			}
    		}
    	}
    	// Max range hero
    	else if(localName.equals("name"))
    	{
    		getHero = true;
    		currentHero = new StringBuffer();
    	}
    	else if(localName.equals("attackRange"))
    	{
    		getRange = true;
    		range = new StringBuffer();
    	}
    	// Good agi heroes
    	else if(localName.equals("type"))
    	{
    		isAgi = false;
    		if(atts.getLength() > 0 && 
    				atts.getLocalName(0).equals("id") && 
    				atts.getValue(0).equals("t_2"))
    			isAgi = true;
    	}
    	else if(localName.equals("agility") && !isAgi)
    	{
    		getAgility = true;
    		currentAgility = new StringBuffer();
    	}
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
    	// Max range hero
    	if(localName.equals("name"))
    		getHero = false;
    	else if(localName.equals("attackRange"))
    	{
    		getRange = false;
    		int currentRange = Integer.parseInt(range.toString());
    		if(currentRange > maxRange)
    		{
    			maxRange = currentRange;
				maxRangeHero = currentHero;
    		}
    	}
    	else if(localName.equals("agility") && !isAgi)
    	{
    		getAgility= false;
    		if(Integer.parseInt(currentAgility.toString()) >= 20)
    			++goodAgiHeroes;
    	}
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        // Max range hero
    	if(getHero)
    	{
    		currentHero.append(chars, start, length);
    	}
    	else if(getRange)
    	{
    		range.append(chars, start, length);
    	}
    	else if(getAgility)
    	{
    		currentAgility.append(chars, start, length);
    	}
    }

    /**
     * Method to handle " start of namespace declaration"
     *
     * @param prefix Prefix of the namespace
     * @param uri URI of the namespace
     * @throws SAXException
     */
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    /**
     * Method to handle "end of namespace declaration"
     *
     * @param prefix
     * @throws SAXException
     */
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    /**
     * Method to handle "ignoring of whitespaces" Text is in array 'chars' from
     * position ('start') to ('start' + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     * @throws SAXException
     */
    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
        // ...
    }

    /**
     * Method to handle "processing instructions"
     *
     * @param target The processing instruction target
     * @param data  The processing instruction data
     * @throws SAXException
     */
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

    /**
     * Method to handle "unprocessed entity"
     *
     * @param name
     * @throws SAXException
     */
    @Override
    public void skippedEntity(String name) throws SAXException {
        // ...
    }
}