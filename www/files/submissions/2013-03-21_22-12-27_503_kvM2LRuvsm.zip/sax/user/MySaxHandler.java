/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.ext.Attributes2Impl;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 *
 * @author hefay
 */
public class MySaxHandler {
    private static final String INPUT_FILE = "data.xml";
    
    
    public static void main(String[] args) {
        try {
            XMLReader r = XMLReaderFactory.createXMLReader();
            InputSource s = new InputSource(INPUT_FILE);
            
            MyHand mh = new MyHand();
            r.setContentHandler(mh);
            r.parse(s);
            
            System.out.println("Prumerne ma Anime "+mh.getPrumerneEpizod()+" epizod.");
            System.out.println("Nejdelsi nazvy projektu (Maximalne 5)");
            mh.printTitleOrderByLength();
            System.out.println("");
            System.out.println("Projekty ktere jsou dokoncene, vysilali se pred rokem 2007 a maji vice jak 50 epizod");
            System.out.println(" * Tomu odpovida "+mh.getCountOfMayNodes()+" projektu.");
            mh.printProject();
        
        } catch (SAXException ex) {
            Logger.getLogger(MySaxHandler.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(MySaxHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    
}

class ProjectTitleSet {
    private SortedSet<ProjectTitle> ps = new TreeSet<>();
    
    public void addTitle(ProjectTitle t){
        ps.add(t);
    }
    public Iterator<ProjectTitle> getTitles(){
        return ps.iterator();
    }
}


class ProjectTitle implements Comparable<ProjectTitle>{
    private String title;

    public ProjectTitle(String title) {
        this.title = title;
    }

    public int getLenght(){
        return title.length();
    }
    @Override
    public int compareTo(ProjectTitle t) {
        return t.getLenght()-title.length();
    }
    
    public String getTitle(){
        return title;
    }
    
    
}

class Node {
    private String name;
    private Attributes att;
    private HashMap<String,Node> childerns = new HashMap<>();
    private String text;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Node(String name, Attributes att) {
        this.name = name;
        this.att = att;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Attributes getAtt() {
        return att;
    }

    public void setAtt(Attributes att) {
        this.att = att;
    }

    public void addChild(Node n){
        childerns.put(n.getName(), n);
    }
    public Node getChild(String name){
        return (Node) childerns.get(name);
    }
    
    public Collection<Node> getChildern(){
        return childerns.values();
    }
    
    


    
    
}
class Prumer {
    int x;
    int y;
    
    void addValue(int v){
        x+=v;
    }
    void removeValue(int v){
        x-=v;
    }
    void addNodes(int n){
        y+=n;
    }
    void addNode(){
        y++;
    }
    void removeNodes(int n){
        y-=n;
    }
    double prumer(){
        return x/y;
    }
}
class MyHand implements ContentHandler {
    Prumer prelozenoEpizod = new Prumer();
    ProjectTitleSet pts = new ProjectTitleSet();
    Node projectNode=null;
    Node mayNodes=new Node("May node", null);
    String lastLastNode;
    String lastNode;
    String text;
    Node nLastNode=null;
    
    public Node getMayNodes(){
        return mayNodes;
    }
    public int getCountOfMayNodes(){
        return mayNodes.getChildern().size();
    }
    
    public void printProject(){
        Collection<Node> childern = mayNodes.getChildern();
        for(Node n : childern){
            System.out.println(" - "+n.getChild("projekt").getChild("nazevOfficial").getText());
        }
    }
    public double getPrumerneEpizod(){
        return prelozenoEpizod.prumer();
    }
    public void printTitleOrderByLength(){
        Iterator<ProjectTitle> titles = pts.getTitles();
        for(int i=0;titles.hasNext() && i<5;i++){
            System.out.println(" - "+titles.next().getTitle());
        }
    }
    
    @Override
    public void setDocumentLocator(Locator lctr) {
        
    }

    @Override
    public void startDocument() throws SAXException {
        
    }

    @Override
    public void endDocument() throws SAXException {

    }

    @Override
    public void startPrefixMapping(String string, String string1) throws SAXException {
        
    }

    @Override
    public void endPrefixMapping(String string) throws SAXException {

    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atrbts) throws SAXException {
        if(lastNode !=null && lastNode.equals("nazevOfficial") && text!=null){
            pts.addTitle(new ProjectTitle(text));
        }
        
        switch (localName){
            case "projekt":
                projectNode=new Node(localName, atrbts);
                break;
            case "animeProjekt":
                prelozenoEpizod.addNode();
                prelozenoEpizod.addValue(Integer.parseInt(atrbts.getValue("epizod")));
            default:
                if(projectNode!=null){
                    Node n =new Node(localName, new Attributes2Impl(atrbts));
                    nLastNode=n;
                    projectNode.addChild(n);
                }
                break;
        }
        
        lastLastNode=lastNode;
        lastNode=localName;
    }
    
    

    @Override
    public void endElement(String string, String string1, String string2) throws SAXException {
        switch(string1){
            case "projekt":
                may();
                projectNode=null;
                break;
            default:
                break;
        }
    }
    
    private void may(){
        if(projectNode != null && projectNode.getChild("stavProjektu").getText().equals("Dokonceno")){
            if(pi(pic("vysilano","od")) < 2007
                    && ((!pin("animeProjekt") && pi(pic("animeProjekt","epizod")) > 50)
                    || (!pin("doramaProjekt") && pi(pic("doramaProjekt","epizod")) > 50) 
                    )){
                
                Node mm = new Node(projectNode.toString(), null);
                mm.addChild(projectNode);
                mayNodes.addChild(mm);
            }
            
        }
    }
    
    private int pi(String s){
        return Integer.parseInt(s);
    }
    private boolean pin (String child){
        return projectNode.getChild(child)==null;
    }
    private String pic (String child, String at){
        return projectNode.getChild(child).getAtt().getValue(at);
   }

    @Override
    public void characters(char[] chars, int i, int i1) throws SAXException {
        if(chars!=null){
            
            text = String.copyValueOf(chars, i, i1);
            
            if(nLastNode!=null){
                nLastNode.setText(text);
            }
            
        }
    }

    @Override
    public void ignorableWhitespace(char[] chars, int i, int i1) throws SAXException {

    }

    @Override
    public void processingInstruction(String string, String string1) throws SAXException {
 
    }

    @Override
    public void skippedEntity(String string) throws SAXException {
  
    }
    
}
