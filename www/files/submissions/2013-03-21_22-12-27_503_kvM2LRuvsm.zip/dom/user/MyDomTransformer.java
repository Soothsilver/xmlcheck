/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author hefay
 */
public class MyDomTransformer {
    private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "data.out.xml";

    public static void main(String[] args) {
        
        try {
            //DocumentBuilderFactory vytvari DOM parsery
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            //nebudeme validovat
            dbf.setValidating(false);

            //vytvorime si DOM parser
            DocumentBuilder builder = dbf.newDocumentBuilder();

            //parser zpracuje vstupni soubor a vytvori z nej strom DOM objektu
            Document doc = builder.parse(VSTUPNI_SOUBOR);

            //zpracujeme DOM strom
            processTree(doc);

            //TransformerFactory vytvari serializatory DOM stromu
            TransformerFactory tf = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer = tf.newTransformer();

            //nastavime kodovani
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spustime transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


        } catch (Exception e) {
            
            e.printStackTrace();
            
        }
    }

    /**
     * Zpracuje DOM strom
     */
    private static void processTree(Document doc) {
        addClen(doc);
        editAnime(doc);
    }
    
    private static void editAnime(Document doc){
        NodeList zanry = doc.getElementsByTagName("zanry");
        
        for(int i=0; i < zanry.getLength();i++){
            NodeList zanr = zanry.item(i).getChildNodes();
            int cou=0;
            for(int k=0; k < zanr.getLength(); k++){
                String cont = zanr.item(k).getTextContent();
                if(cont.equals("Akcni") || cont.equals("Sci-fi")){
                    cou++;
                }
            }
            
            if(cou==2){
                editujTenhleNode(doc, zanry.item(i));
            }
        }
    }
    
    private static void addClen(Document doc){
        Element clen = doc.createElement("clen");
        
        
        int id = 1;
        NodeList cleni = doc.getElementsByTagName("clen");
        for(int i=0; i < cleni.getLength();i++){
            int x = Integer.parseInt(cleni.item(i).getAttributes().getNamedItem("id").getTextContent().substring(4));
            if(id<x){
                id=x;
            }
        }
        id++;
        NodeList cl = doc.getElementsByTagName("cleni");
        cl.item(0).appendChild(clen);

        clen.appendChild(doc.createElement("jmeno")).setTextContent("Hayaki");
        clen.appendChild(doc.createElement("prijmeni")).setTextContent("Hayaki");
        clen.appendChild(doc.createElement("nick")).setTextContent("Hayaki");
        Element pc = doc.createElement("popisClena");
        pc.setAttribute("pouzit", "ano");
        pc.appendChild(doc.createCDATASection("Nejaky text v CDATA"));
        clen.appendChild(pc);
        Element pozice = doc.createElement("pozice");
        Element post = doc.createElement("post");
        post.setAttribute("name", "uploader");
        pozice.appendChild(post);
        clen.appendChild(pozice);
    }

    private static void editujTenhleNode(Document d, Node parentNode) {
        NodeList ch = parentNode.getChildNodes();
        
        for(int i=0;i<ch.getLength();i++){
            if(ch.item(i).getTextContent().equals("Sci-fi")){
                ch.item(i).setTextContent("Kultovni Sci-fi");
            }
        }
        Element createElement = d.createElement("zanr");
        createElement.setTextContent("shouen");
        parentNode.appendChild(createElement);
    }
}