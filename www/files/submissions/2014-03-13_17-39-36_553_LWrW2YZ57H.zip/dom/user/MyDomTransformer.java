package user;

import org.w3c.dom.*;

public class MyDomTransformer {

    public void transform(Document xmlDocument) {
        //removing all fast songs - all songs with tempo greater than 100 bpm
        NodeList songs = xmlDocument.getElementsByTagName("song");
        for (int i = songs.getLength() - 1; i >= 0; i--) {
            Element ssong = (Element) songs.item(i);
            int ttempo = Integer.parseInt(ssong.getAttribute("tempo"));
            if (ttempo > 100) {
                ssong.getParentNode().removeChild(ssong);
            }
        }

        //creating a new song called Take the Time
        Element name = xmlDocument.createElement("name");
        name.appendChild(xmlDocument.createTextNode("Take The Time"));

        Attr id = xmlDocument.createAttribute("songID");
        id.setValue("takeTheTime");
        Attr tempo = xmlDocument.createAttribute("tempo");
        tempo.setValue("110");
        Attr key = xmlDocument.createAttribute("key");
        key.setValue("D");
        Attr length = xmlDocument.createAttribute("length");
        length.setValue("8:21");
        Attr music = xmlDocument.createAttribute("musicBy");
        music.setValue("petrucci portnoy myung");
        Attr lyricsBy = xmlDocument.createAttribute("lyricsBy");
        lyricsBy.setValue("petrucci");

        String lyr = " \"Hold it now...\n"
                + " wait a minute...\n"
                + " come on... whew...\"\n"
                + "\n"
                + " Just let me catch my breath...\n"
                + " I've heard the promises\n"
                + " I've seen the mistakes\n"
                + " I've had my fair share of tough breaks\n"
                + " I need a new voice, a new law, a new way\n"
                + " Take the time, reevaluate\n"
                + " It's time to pick up the pieces,\n"
                + " Go back to square one\n"
                + " I think it's time for a change\n"
                + "\n"
                + " There is something that I feel\n"
                + " To be something that is real\n"
                + " I feel the heat within my mind\n"
                + " And craft new changes with my eyes\n"
                + " Giving freely wandering promises\n"
                + " A place with decisions I'll fashion\n"
                + " I won't waste another breath\n"
                + "\n"
                + " [Chorus:]\n"
                + " You can feel the waves coming on\n"
                + " (It's time to take the time)\n"
                + " Let them destroy you or carry you on\n"
                + " (It's time to take the time)\n"
                + " You're fighting the weight of the world\n"
                + " But no one can save you this time\n"
                + " Close your eyes\n"
                + " You can find all you need in your mind\n"
                + "\n"
                + " The unbroken spirit\n"
                + " Obscured and disquiet\n"
                + " Finds clearness this trial demands\n"
                + " And at the end of this day sighs an anxious relief\n"
                + " For the fortune lies still in his hands\n"
                + "\n"
                + " If there's a pensive fear, a wasted year\n"
                + " A man must learn to cope\n"
                + " If his obsession's real,\n"
                + " Suppression that he feels must turn to hope\n"
                + "\n"
                + " Life is no more assuring than love\n"
                + " (It's time to take the time)\n"
                + " There are no answers from voices above\n"
                + " (It's time to take the time)\n"
                + " You're fighting the weight of the world\n"
                + " And no one can save you this time\n"
                + " Close your eyes\n"
                + " You can find all that you need in your mind\n"
                + "\n"
                + " I close my eyes\n"
                + " And feel the water rise around me\n"
                + " Drown the beat of time\n"
                + " Let my senses fall away\n"
                + " I can see much clearer now, I'm blind\n"
                + "\n"
                + " \"Ora che ho perso la vista,\n"
                + " Ci vedo di più \"\n"
                + "\n"
                + " [Chorus]\n"
                + "\n"
                + " Find all you need in your mind\n"
                + " If you take the time\n"
                + " Find all you need in your mind\n"
                + " If you take the time";
        Element lyrics = xmlDocument.createElement("lyrics");
        lyrics.appendChild(xmlDocument.createTextNode(lyr));

        Element song = xmlDocument.createElement("song");
        song.setAttributeNode(id);
        song.setAttributeNode(tempo);
        song.setAttributeNode(key);
        song.setAttributeNode(length);
        song.setAttributeNode(music);
        song.setAttributeNode(lyricsBy);
        song.appendChild(name);
        song.appendChild(lyrics);

        //adding the song to Dream Theater album called Systematic Chaos
        NodeList artists = xmlDocument.getElementsByTagName("artist");
        for (int i = 0; i < artists.getLength(); i++) {
            Element artist = (Element) artists.item(i);
            if (artist.getAttribute("artistID").compareTo("dreamTheater") == 0) {
                NodeList albums = artist.getElementsByTagName("album");
                for (int j = 0; j < albums.getLength(); j++) {
                    Element album = (Element) albums.item(j);
                    if (album.getAttribute("albumID").compareTo("systematicChaos") == 0) {
                        album.appendChild(song);
                    }
                }
            }
        }


    }
}
