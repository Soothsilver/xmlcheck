package user;

import java.util.*;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {

    //map of writers with number of songs, to which they wrote lyrics
    Map<String, Integer> authors;
    
    //if current text is inside an element <lyrics>
    boolean isLyrics = false;
    //if current album was published after year 2000
    boolean isNewAlbum = false;
    //number of songs published after 2000 longer than 5 minutes
    int numLongSongs = 0;
    //building lines of lyrics until </lyrics>
    StringBuilder lyrics = new StringBuilder();
    //list of lengths of lyrics for all found songs
    List<Integer> lyricsLength;

    public MySaxHandler() {
        this.authors = new HashMap();
        lyricsLength = new ArrayList<Integer>();
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        //for each found song we look for its writer and raise his song count in our map
        if (qName.compareTo("song") == 0) {
            if(isNewAlbum){
                //parsing length of the song in seconds
                String[] ss = attributes.getValue("length").split(":");
                int seconds = 0;
                for(String s : ss){
                    seconds = seconds * 60 + Integer.parseInt(s);
                }
                if (seconds > 300){
                    numLongSongs++;
                }
            }
            
            String s = attributes.getValue("lyricsBy");
            int value = 1;
            if (authors.containsKey(s)) {
                value += authors.get(s);
            }
            authors.put(s, value);
        }
        //indicator that we are inside lyrics 
        if (qName.compareTo("lyrics") == 0) {
            isLyrics = true;
        }
        //we are inside album published after year 2000
        if (qName.compareTo("album") == 0){
            int year = Integer.parseInt(attributes.getValue("year"));
            if ( year > 2000){
                isNewAlbum = true;
            }
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        //stepping outside lyrics, we count the number of lines and flush the StringBuilder
        if (qName.compareTo("lyrics") == 0) {
            isLyrics = false;
            int len = (lyrics.toString().split("\r\n|\r|\n")).length;
            lyricsLength.add(len);
            lyrics = new StringBuilder();
        }
        if (qName.compareTo("album")==0){
            isNewAlbum = false;
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        //if we are inside lyrics, we add this line to StringBuilder
        if (isLyrics) {
            String txt = new String(ch, start, length);
            lyrics.append(txt);
        }
    }

    //returns author with the greatest number of songs to which he contributed
    String getMostActiveSongwriter() {
        String author = "";
        int max = 0;
        for (Map.Entry<String, Integer> e : authors.entrySet()) {
            if (e.getValue() > max) {
                max = e.getValue();
                author = e.getKey();
            }
        }
        return author;
    }

    //counts and returns average number of lines in lyrics
    int getAverageLyricsLegth() {
        int sum = 0;
        for (int i : lyricsLength) {
            sum += i;
        }
        return (int) ((double) sum) / lyricsLength.size();
    }
    
    //returns number of songs longer than 5 minutes published after year 2000
    int getNumLongSoongsAfter2000(){
        return numLongSongs;
    }
}
