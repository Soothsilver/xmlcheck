package user;

import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import java.util.HashMap;
import java.util.Map;

public class MySaxHandler extends DefaultHandler {

    private Locator locator;
    private Map<String, Integer> genre = new HashMap<String, Integer>();
    private Map<String,String> novels = new HashMap<String, String>();
    private String actualName, oldestBookName,actualId;
    private Integer oldestYear = new Integer(Integer.MAX_VALUE);
    private boolean book, year, name, isOldest,isNovel;

    @Override
    public void startDocument() throws SAXException {
        super.startDocument();
    }

    @Override
    public void endDocument() throws SAXException {
        super.endDocument();
        Map.Entry<String,Integer> result=null;
        for (Map.Entry<String, Integer> e : this.genre.entrySet()) {
            if(result!=null && result.getValue()>e.getValue()){

            }else{
                result=e;
            }

        }

        System.out.print("Theese novels have never been borrowed: ");
        for (Map.Entry<String, String> e : this.novels.entrySet()) {
            System.out.print(e.getValue() + ", ");
        }
        System.out.println(".");


        System.out.println("Most common genre is "+result.getKey()+" with "+result.getValue()+" occurences.");
        System.out.println("Oldest book is " + oldestBookName + " from year " + oldestYear);
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        checkGenre(localName, attributes);

        if (localName.equals("book")) {
            this.book = true;
        }

        if (this.book && localName.equals("year")) {
            this.year = true;
        }

        if (this.book && localName.equals("name")) {
            this.name = true;
        }

        if(localName.equals("rental")){
            for (int i = 0; i < attributes.getLength(); i++) {
                if(attributes.getLocalName(i).equals("book")){
                    String id = attributes.getValue(i);
                    this.novels.remove(id);
                }
            }
        }

    }

    private void checkGenre(String localName, Attributes attributes) {
        if (localName.equals("book")) {
            for (int i = 0; i < attributes.getLength(); i++) {
                String att = attributes.getLocalName(i);
                if (att.equals("genre")) {
                    String genre = attributes.getValue(i);

                    if(genre.equals("Novel"))this.isNovel=true;

                    if (this.genre.containsKey(genre)) {
                        Integer cnt = this.genre.get(genre);
                        cnt++;
                        this.genre.remove(genre);
                        this.genre.put(genre, cnt);
                    } else {
                        this.genre.put(genre, 1);
                    }


                }else if(att.equals("id")){
                    this.actualId=attributes.getValue(i);
                }
            }

        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (localName.equals("book")) {
            this.book = false;
            if (this.isOldest) this.oldestBookName = this.actualName;
            this.isOldest = false;

            if(this.isNovel){
                this.novels.put(this.actualId,this.actualName);
                this.isNovel=false;
            }

        }

        if (this.book && localName.equals("year")) {
            this.year = false;
        }

        if (this.book && localName.equals("name")) {
            this.name = false;
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        if (this.year) {
            StringBuilder sb = new StringBuilder();
            sb.append(ch, start, length);
            String ns = sb.toString();
            ns.replaceAll("\\s+", "");
            Integer newYear = Integer.parseInt(ns);
            if (newYear < this.oldestYear) {
                this.oldestYear = newYear;
                this.isOldest = true;
            }

        }
        if (this.name) {
            StringBuilder sb = new StringBuilder();
            sb.append(ch, start, length);
            this.actualName = sb.toString();
        }
    }

    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }
}