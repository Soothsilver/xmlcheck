package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

/**
 * Prevadi elementy man, woman na id elemntu pair s textovym obsahem ve formatu:
 * "prijmeni_partnera - prijmeni_partnerky"
 */
public class MyDomTransformer {

    public void transform (Document xmlDocument) {
        NodeList pairs = xmlDocument.getElementsByTagName("pair");

        for( int i = 0; i < pairs.getLength(); i++ ) {
            Element pair = (Element) pairs.item( i );

            Element man = (Element) pair.getElementsByTagName( "man" ).item( 0 );
            String surnameMan = getSurname( man );
            pair.removeChild( man );

            Element woman = (Element) pair.getElementsByTagName( "woman" ).item( 0 );
            pair.removeChild( woman );
            String surnameWoman = getSurname( woman );

            pair.setAttribute( "id", surnameMan + " - " + surnameWoman );
        }
    }


    private String getSurname( Element people ) {
        if ( people != null ) {
            String name = people.getTextContent();

            return name.substring( name.lastIndexOf(" ") + 1 );
        } else {
            return "";
        }
    }
}