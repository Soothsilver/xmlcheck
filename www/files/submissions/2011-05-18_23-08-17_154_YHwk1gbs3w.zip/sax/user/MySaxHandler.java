package user;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Vypise prumerne znamky za kazdy tanec pro kazdy finalovy par.
 */
public class MySaxHandler extends DefaultHandler {

    private boolean finalRound = false;

    private boolean man = false;

    private boolean woman = false;

    private boolean rating = false;


    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        if ( localName.equals( "round" ) ) {
            finalRound = attributes.getValue("name").equals( "final" );
        }

        if ( finalRound && localName.equals( "man" ) ) {
            man = true;
        }

        if ( finalRound && localName.equals( "woman" ) ) {
            woman = true;
        }

        if ( finalRound && localName.equals("rating") ) {
            rating = true;
            System.out.print("Rating for " + attributes.getValue( "dance" ) + ": " );
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if ( localName.equals( "man" ) ) {
            man = false;
        }

        if ( localName.equals( "woman" ) ) {
            woman = false;
        }

        if ( localName.equals("rating") ) {
            rating = false;
        }

        if ( localName.equals( "ratings" ) ) {
            System.out.println("");
        }
    }


    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        String buffer = String.copyValueOf(ch)
                .substring(start, start + length)
                .trim();

        if( man || woman ) {
            System.out.println( buffer );
        }

        if( rating ) {
            int sum = 0;
            for( char mark : buffer.trim().toCharArray() ) {
                sum += Integer.valueOf( "" + mark );
            }

            System.out.println( (double) sum / buffer.length() );
        }
    }
    
}
