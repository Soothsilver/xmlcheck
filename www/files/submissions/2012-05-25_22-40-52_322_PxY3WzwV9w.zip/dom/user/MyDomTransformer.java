package user;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.xml.parsers.*;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

public class MyDomTransformer {

	private static Map<String, List<Node>> pozickyCitatelov;
	
	/*
	public static void main(String[] args) {
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			dbf.setValidating(false);
			DocumentBuilder builder = dbf.newDocumentBuilder();
			Document doc = builder.parse("data.xml");

			transform(doc);

			TransformerFactory tf = TransformerFactory.newInstance();
			Transformer writer = tf.newTransformer();
			writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

			writer.transform(new DOMSource(doc), new StreamResult(new File(
					"out.xml")));

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	*/
	

	/**
	 * Vytvori publikacie podla Autorov - kazdy autor ma svoju publikaciu
	 */
	public void transform(Document xmlDocument) {

		Map<String, Element> autorMap = new HashMap<String, Element>();

		NodeList nodesList = xmlDocument.getElementsByTagName("publikacia-info");
		pozickyCitatelov = getPozickyCitatelov(xmlDocument);

		// prejde cez vsetky elementy publikacia-info a vytvori cez ne element
		// autor ak este neexistuje
		for (int i = 0; i < nodesList.getLength(); i++) {
			Node publikacia_info = nodesList.item(i);
			Element autor = getAutor(autorMap, publikacia_info, xmlDocument);

			// autorovi vytvori publikaciu
			// pretvori publikaciu
			Element publikacia = getPublikacia(publikacia_info, xmlDocument);
			autor.appendChild(publikacia);

			// kazdej publikacii najde pozicku
			publikacia.appendChild(getPozicky(publikacia_info, xmlDocument));// TODO
		}

		// povodne elementy zmaze
		Node kniznica = xmlDocument.getElementsByTagName("kniznica").item(0);
		for (Node node = kniznica.getFirstChild(); node != null;) {
			Node nextChild = node.getNextSibling();
			kniznica.removeChild(node);
			node = nextChild;
		}

		// prida element autori
		Element autoriElement = xmlDocument.createElement("autori");
		for (Element element : autorMap.values()) {
			autoriElement.appendChild(element);
		}
		kniznica.appendChild(autoriElement);
	}

	/**
	 * vyhlada vsetky pozicky a ulozi ich do mapy, kde klucom je id publikacie danej pozicky
	 * a hodnota je list poziciek publikacie 
	 * @return vrati hore popisovanu mapu
	 */
	private static Map<String, List<Node>> getPozickyCitatelov(Document doc) {
		Map<String, List<Node>> pulikaciePozickyMap = new HashMap<String, List<Node>>();

		NodeList pozickyList = doc.getElementsByTagName("poz-publikacia");
		for (int i = 0; i < pozickyList.getLength(); i++) {
			Node pozickaNode = pozickyList.item(i);
			String pubId = pozickaNode.getAttributes().getNamedItem("pub-ref")
					.getTextContent();

			if (pulikaciePozickyMap.containsKey(pubId)) {
				pulikaciePozickyMap.get(pubId).add(pozickaNode);
			} else {
				List<Node> nodes = new ArrayList<Node>();
				nodes.add(pozickaNode);
				pulikaciePozickyMap.put(pubId, nodes);
			}
		}
		return pulikaciePozickyMap;
	}

	/**
	 * Vytvori pre vlozenu publikaciu element pozicky a ak pre danu
	 * publikaciu nejake pozicky existuju, vytvori ich ako podelement
	 */
	private static Node getPozicky(Node publikaciaInfo, Document doc) {
		Element pozicky = doc.createElement("pozicky");

		// najdi id publikacie
		String idPozicky = publikaciaInfo.getParentNode().getAttributes()
				.getNamedItem("id").getTextContent();

		// najdi v pozickach
		List<Node> pozickaList = pozickyCitatelov.get(idPozicky);

		// ziadne pozicky sa nenasli
		if (pozickaList == null) {
			return pozicky;
		}

		// vytvor pozicky
		for (Node pozicka : pozickaList) {
			pozicky.appendChild(createPozickaNode(pozicka, doc));
		}
		return pozicky;
	}

	/**
	 * Vytvori element pozicka podla vlozenej pozicky. Z elementu datum-prevzatia a termin-vratenia
	 * urobi atributy, z atributu stav urobi element, spoji 2 elementy predsavujuce meno do jedneho
	 */
	private static Node createPozickaNode(Node pozPublikacia, Document doc) {
		Element pozickaElement = doc.createElement("pozicka");

		pozickaElement.setAttribute("datum-prevzatia",
				findChildElement(pozPublikacia, "datum-prevzatia")
						.getTextContent());
		pozickaElement.setAttribute("datum-vratenia",
				findChildElement(pozPublikacia, "termin-vratenia")
						.getTextContent());

		Element menoElement = doc.createElement("Meno");
		
		Node ou = findChildElement(pozPublikacia.getParentNode().getParentNode(), "osobne-udaje");
		String m = findChildElement(ou, "meno").getTextContent();
		String p = findChildElement(ou, "priezvisko").getTextContent();

		menoElement.setTextContent(m + " " + p);
		pozickaElement.appendChild(menoElement);

		Element stavElement = doc.createElement("stav");
		String stav = pozPublikacia.getAttributes().getNamedItem("stav")
				.getTextContent();
		stavElement.setTextContent(stav);
		pozickaElement.appendChild(stavElement);

		return pozickaElement;
	}

	/**
	 * z elementu publikacia-info vytiahne najzakladnejsie udaje (aj z rodica) a vrati
	 * novy element o publikacii. 
	 */
	private static Element getPublikacia(Node publikacia_info, Document doc) {
		NamedNodeMap attributes = publikacia_info.getParentNode()
				.getAttributes();
		String id = attributes.getNamedItem("id").getTextContent();

		Element publikaciaElement = doc.createElement("publikacia");
		publikaciaElement.setAttribute("id", id);

		String name = findChildElement(publikacia_info, "nazov")
				.getTextContent();
		publikaciaElement.setAttribute("nazov", name);
		return publikaciaElement;
	}

	/**
	 * z elementu publikacia-info vytvori element autor kde z elementu meno spravi atribut
	 * a prida ho do mapy autorov ak tam este nieje.  
	 */
	private static Element getAutor(Map<String, Element> autorMap,
			Node publikacia_info, Document doc) {
		
		Element autor;
		String meno = findChildElement(publikacia_info, "meno-autora")
				.getTextContent();
		
		if (autorMap.containsKey(meno)) {
			autor = autorMap.get(meno);
		} else {
			autor = doc.createElement("autor");
			autor.setAttribute("meno-autora", meno);
			autorMap.put(meno, autor);
		}
		return autor;
	}

	/**
	 * z potomkov (child) vlozeneho nodu skusi najst podla vlozeneho stringu 
	 * rovnomenny Node. Ak najde vrati ho, ak sa nepodari najst, vrati null.  
	 */
	private static Node findChildElement(Node node, String name) {
		NodeList nodeList = node.getChildNodes();

		for (int i = 0; i < nodeList.getLength(); i++) {
			if (nodeList.item(i).getNodeName().equals(name)) {
				return nodeList.item(i);
			}
		}

		return null;
	}
}
