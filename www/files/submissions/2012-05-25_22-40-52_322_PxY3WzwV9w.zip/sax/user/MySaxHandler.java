package user;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

public class MySaxHandler extends DefaultHandler { 
	private Publikacia publikaciaTemp;
	private boolean komentarHodnotenieFlag = false;
	private boolean nazovFlag = false;
	private List<Publikacia> publikaciaList = new ArrayList<Publikacia>();
	private static String xmlFile = "data.xml";
	
	/*
	public static void main(String[] args) {
		try {
			MySaxHandler handler = new MySaxHandler();
			XMLReader xr = XMLReaderFactory.createXMLReader();
			xr.setContentHandler(handler);

			FileReader r = new FileReader(xmlFile);
			xr.parse(new InputSource(r));
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	*/
	@Override
	public void startDocument() throws SAXException {
		System.out.println("Vypis publikacii s ich hodnotenim");
		super.startDocument();
	}
	
	@Override
	public void endDocument() throws SAXException {
		for (Publikacia pub : publikaciaList) {
			System.out.println(pub.toString());
		}
	}
	
	/**
	 * ked najde zaciatok prislusneho elementu, nastavy mu flag na true
	 */
	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {
		if ("publikacia".equals(localName)) {
			publikaciaTemp = new Publikacia();
		}
		
		// ak parser nepracuje s publikaciami, koniec..
		if (publikaciaTemp == null) {
			return;
		}
		
		if ("nazov".equals(localName)) {
			nazovFlag = true;
		}else if ("komentar-hodnotenie".equals(localName)) {
			komentarHodnotenieFlag = true;
		}
	}
	
	/**
	 * ked najde koniec prislusneho elementu, nastavi mu flag na false
	 */
	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		if ("publikacia".equals(localName)) {
			publikaciaList.add(publikaciaTemp);
			publikaciaTemp = null;
		}else if ("nazov".equals(localName)) {
			nazovFlag = false;
		}else if ("komentar-hodnotenie".equals(localName)) {
			komentarHodnotenieFlag = false;
		}
	}
	
	/**
	 * Podla nastavenych flagov zapise hodnotu
	 */
	@Override
	public void characters(char[] ch, int start, int length)
			throws SAXException {
		if (publikaciaTemp == null) {
			return;
		}
		
		String string = String.copyValueOf(ch, start, length);
		
		if (nazovFlag) {
			publikaciaTemp.setNazov(string);
		}else if (komentarHodnotenieFlag) {
			publikaciaTemp.addHodnotenie(string);
		}
	}
}

class Publikacia {
	
	private String nazov;
	private List<Integer> hodnotenieList;
	
	public Publikacia() {
		hodnotenieList = new ArrayList<Integer>(); 
	}
	
	@Override
	public String toString() {
		return getNazov() + " (" +getHodnotenie() + "%) pocet hodnoteni: " + hodnotenieList.size();
	}

	private String getHodnotenie() {
		double hodnotenie = 0.0;
		int count = 0;
		for (int h : hodnotenieList) {
			count++;
			hodnotenie += h;
		}
		
		if (count == 0) {
			return "0";
		}
		
		hodnotenie /= count * 5;
		hodnotenie *= 100;
		
		return Integer.toString((int)hodnotenie);
	}

	public String getNazov() {
		return nazov;
	}

	public void setNazov(String nazov) {
		this.nazov = nazov;
	}
	
	public void addHodnotenie(String hodnotenie){
		int i = Integer.parseInt(hodnotenie.substring(0, 1));
		hodnotenieList.add(i);
	}
}
