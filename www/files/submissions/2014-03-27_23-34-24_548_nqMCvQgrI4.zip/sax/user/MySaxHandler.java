/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package user;

import java.util.*;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Determines the following statistics about the data:
 *
 *  1) Number of cards of a given quality (specified by the "quality" attribute)
 *  2) Number of cards of a given mana cost (specified by the "cost" subelement)
 *  3) Names of all mage spell cards that cost 5 or more mana
 */
class MySaxHandler extends DefaultHandler {
    
    /*
     * Rarity:
     *   0 - basic
     *   1 - common
     *   2 - rare
     *   3 - epic
     *   4 - legendary
     */
    int[] rarityCount = new int[5];
    
    /*
     * Most expensive card currently costs 20 mana.
     */
    int[] manaCost = new int[21];
    
    boolean inCard = false;
    boolean inSpell = false;
    
    // Mana cost of currently examined card. -1 means invalid card.
    int currentCost = -1;
    
    // Name of currently examined card.
    String currentName;
    
    // Class id of currently examined card.
    String currentClassId;
    
    List<String> selectedCards = new ArrayList<>();
    
    // StringBuilder for text content.
    StringBuilder builder = new StringBuilder();
    
    String mageClassId = "h1";

    private String stars(int len, int max, int cur)
    {
        int st = (int)Math.ceil((double)len * cur / max);
        int em = len - st;
        
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < em; i++)
        {
            b.append(' ');
        }
        
        for (int i = 0; i < st; i++)
        {
            b.append('*');
        }
        
        return b.toString();
    }
    
    /**
     * Sets the locator
     *
     * @param Locator locator location in the file
     */
    @Override
    public void setDocumentLocator(Locator locator) {
        // ...
    }

    /**
     * Method to handle "document start"
     *
     * @throws SAXException
     */
    @Override
    public void startDocument() throws SAXException {
        // ...
    }

    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
        System.out.println(
                "Rarity count:\n" +
                "Basic:     " + rarityCount[0] + "\n" +
                "Common:    " + rarityCount[1] + "\n" +
                "Rare:      " + rarityCount[2] + "\n" +
                "Epic:      " + rarityCount[3] + "\n" +
                "Legendary: " + rarityCount[4] + "\n");
        
        int max = 0;
        for (int i = 0; i < manaCost.length; i++)
        {
            if (manaCost[i] > max) max = manaCost[i];
        }
         
        System.out.println("Mana cost distribution:");
        
        for (int i = 0; i < manaCost.length; i++)
        {
            System.out.println(stars(10, max, manaCost[i]) + " " + i);
        }
        
        System.out.println();
        System.out.println("Mage spells that cost 5 or more:");
        
        for (int i = 0; i < selectedCards.size(); i++)
        {
            System.out.println(selectedCards.get(i));
        }
    }

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        builder = new StringBuilder();        

        if (inCard && localName.equals("class"))
        {
            currentClassId = atts.getValue("id");
        }
        
        // Check for card types.
        if (localName.equals("minion") ||
            localName.equals("weapon") ||
            localName.equals("spell"))
        {
            inCard = true;
            
            currentCost = -1;
            currentName = null;
            currentClassId = null;
            
            if (localName.equals("spell"))
            {
                inSpell = true;              
            }
            
            int ix = 0;
            switch (atts.getValue("quality"))
            {
                case "basic":     ix = 0; break;
                case "common":    ix = 1; break;
                case "rare":      ix = 2; break;
                case "epic":      ix = 3; break;
                case "legendary": ix = 4; break;
                    
                default: throw new SAXException("Invalid XML file.");
            }
            
            rarityCount[ix]++;      
        }
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (inCard && localName.equals("cost"))
        {
            int cost = Integer.parseInt(builder.toString());
            currentCost = cost;
            manaCost[cost]++;
        }
        
        if (inCard && localName.equals("name"))
        {
            currentName = builder.toString();
        }
        
        if (localName.equals("minion") ||
            localName.equals("weapon") ||
            localName.equals("spell"))
        {
            if (inSpell)
            {
                if (currentClassId == null)
                {
                    throw new SAXException("No class element inside a card element!");
                }
                
                if (currentCost == -1)
                {
                    throw new SAXException("No cost element inside a card element!");
                }
                
                if (currentName == null)
                {
                    throw new SAXException("No name element inside a card element!");
                }
                
                if (currentClassId.equals(mageClassId) && currentCost >= 5)
                {
                    selectedCards.add(currentName);
                }
            }
            
            inCard = false;
            inSpell = false;
        }
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        builder.append(chars, start, length);
    }

    /**
     * Method to handle " start of namespace declaration"
     *
     * @param prefix Prefix of the namespace
     * @param uri URI of the namespace
     * @throws SAXException
     */
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    /**
     * Method to handle "end of namespace declaration"
     *
     * @param prefix
     * @throws SAXException
     */
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    /**
     * Method to handle "ignoring of whitespaces" Text is in array 'chars' from
     * position ('start') to ('start' + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     * @throws SAXException
     */
    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
        // ...
    }

    /**
     * Method to handle "processing instructions"
     *
     * @param target The processing instruction target
     * @param data  The processing instruction data
     * @throws SAXException
     */
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

    /**
     * Method to handle "unprocessed entity"
     *
     * @param name
     * @throws SAXException
     */
    @Override
    public void skippedEntity(String name) throws SAXException {
        // ...
    }
}
