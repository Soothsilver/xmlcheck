/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package user;

import java.util.*;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

public class MyDomTransformer {
    static List<Node> allCards = new ArrayList<>();
    
    /*
     * Adds a new card and then sorts all cards alphabetically.
     */
    private void transform(Document doc) {
        // We assume that the XML document is valid (according to the
        // DTD).

        // Adds a new minion card to the XML.
        Element card = doc.createElement("minion");
        card.setAttribute("id", "c12");
        card.setAttribute("quality", "basic");
        card.setAttribute("type", "Beast");
        card.appendChild(doc.createElement("name")).setTextContent("Bloodfen Raptor");
        card.appendChild(doc.createElement("cost")).setTextContent("2");
        card.appendChild(doc.createElement("attack")).setTextContent("3");
        card.appendChild(doc.createElement("health")).setTextContent("2");      
        card.appendChild(doc.createElement("description"));
           
        Node cardsRoot = doc.getElementsByTagName("cards").item(0);
        cardsRoot.appendChild(card);
        
        // Remove all cards from "cards" element.
        NodeList cards = cardsRoot.getChildNodes();
        while (cards.getLength() > 0)
        {
            Node removed = cardsRoot.removeChild(cards.item(0));
            
            // Do not add whitespace between elements.
            if (removed.getNodeName().equals("minion") ||
                removed.getNodeName().equals("weapon") ||
                removed.getNodeName().equals("spell"))
            {
                allCards.add(removed);
            }
        }
        
        // Sort by content of the name subelement (see CardComparator
        // below).
        Collections.sort(allCards, new CardComparator());

        // Add all removed cards back.
        for (int i = 0; i < allCards.size(); i++)
        {
            cardsRoot.appendChild(allCards.get(i));
        }
    }
}

class CardComparator implements Comparator<Node>
{
    private String getName(Node n)
    {
        NodeList nl = n.getChildNodes();
        for (int i = 0; i < nl.getLength(); i++)
        {           
            if (nl.item(i).getNodeName().equals("name"))
            {
                return nl.item(i).getTextContent();
            }
        }
        
        return null;
    }
    
    @Override
    public int compare(Node a, Node b)
    {
        return getName(a).compareTo(getName(b));
    }
}
