package user;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

/*
Zadani: Doplneni ceny bez DPH pro zbozi, pokud je zbozi na predpis a cenu
uvedenu nema, tak doplnime prazdny element.
*/

public class MyDomTransformer  {



    private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "data.out.xml";

    public static void main(String[] args) {

        try {

            //DocumentBuilderFactory vytvĂˇĹ™Ă­ DOM parsery
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            //nebudeme validovat
            dbf.setValidating(false);

            //vytvoĹ™Ă­me si DOM parser
            DocumentBuilder builder = dbf.newDocumentBuilder();

            //parser zpracuje vstupnĂ­ soubor a vytvoĹ™Ă­ z nÄ›j strom DOM objektĹŻ
            Document doc = builder.parse(VSTUPNI_SOUBOR);

            //zpracujeme DOM strom
            transform(doc);

            //TransformerFactory vytvĂˇĹ™Ă­ serializĂˇtory DOM stromĹŻ
            TransformerFactory tf = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer = tf.newTransformer();

            //nastavĂ­me kodovĂˇnĂ­
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spustĂ­me transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


        } catch (Exception e) {

            e.printStackTrace();

        }
    }

public static void transform (Document xmlDocument) {

// code transforming xmlDocument object // (method works on the object itself - no return value)

int pole_dph[] = new int [5];
int pole_cena[] = new int [5];

// zjistime kolik je DPH a ulozime do pole
NodeList dph_list = xmlDocument.getElementsByTagName("dph");
int k=0;
int l=0;
int dph_int;

for(int i=0;i<dph_list.getLength();i++) {
Element dph_elem = (Element) dph_list.item(i);

Node text_dph = hodnotaUzlu(dph_elem,"#text");
// prevod textove hodnoty uzly na cislo
dph_int = Integer.parseInt(text_dph.getNodeValue());
pole_dph[k]=dph_int;

k++;
}

// zjistime kolik je cena a ulozime do pole
NodeList cena_list = xmlDocument.getElementsByTagName("cena");

for (int i=0;i<cena_list.getLength();i++) {
Element cena_elem = (Element) cena_list.item(i);

Node text_cena = hodnotaUzlu(cena_elem,"#text");

int cena_int;
// prevod textove hodnoty uzlu na cislo
cena_int = Integer.parseInt(text_cena.getNodeValue());
pole_cena[l]=cena_int;

l++;

}


// vyrobime pole s vypocitanou cenou bez DPH
int cena_bez_dph[] = new int[5];
int i=0;
// spocitej cenu bez dph
for(int n=0;pole_cena[n]!=0;n++) {
  cena_bez_dph[i] = pole_cena[n] - ((pole_cena[n]/100)*pole_dph[n]);
  i++;
}


// Vlozime vypocitanou hodnotu na spravne misto -
// to je v elementu zbozi pred prvni element kategorie

NodeList zbozilist = xmlDocument.getElementsByTagName("zbozi");
Element zbozin;

int index=0;

// projdeme elementy zbozi
for(int r=0;r<zbozilist.getLength();r++) {

NodeList nl =zbozilist.item(r).getChildNodes();

int d=0;
boolean nodecena=false;

// projdeme vsechny potomky uzlu zbozi
for(int b=0;b<nl.getLength();b++){
Node e = nl.item(b);
d++;
// pokud je mezi nimi element cena, pridame element s vypocitanou cenou
// bez DPH
if(e.getNodeName().equals("cena")) {

nodecena=true;

zbozin = (Element) zbozilist.item(r);

NodeList kategorielist = zbozin.getElementsByTagName("kategorie");
Element kategorien = (Element) kategorielist.item(0);

// novy element

Element insertCenaBezDph = xmlDocument.createElement("cenabezdph");
//prevod ceny na string
String cena_textova = Integer.toString(cena_bez_dph[index]);

Text text = xmlDocument.createTextNode(cena_textova);
insertCenaBezDph.appendChild(text);
zbozin.insertBefore(insertCenaBezDph,kategorien);

index++;
}

}

// pokud mezi potomky elementu zbozi neni cena, tak vlozim prazdny element
if(nodecena==false) {

zbozin = (Element) zbozilist.item(r);

NodeList kategorielist = zbozin.getElementsByTagName("kategorie");
Element kategorien = (Element) kategorielist.item(0);
// vloz prazdny element
Element insertCenaBezDph = xmlDocument.createElement("cenabezdph");
zbozin.insertBefore(insertCenaBezDph,kategorien);

}

}


}


// pomocna metoda, vraci textovy obsah elementu
private static Node hodnotaUzlu(Node parent,String name) {

NodeList nl = parent.getChildNodes();
for(int i=0;i<nl.getLength();i++) {
Node e = nl.item(i);
if(e.getNodeName().equals(name)==true) {return e;}
}
    return null;
}


}