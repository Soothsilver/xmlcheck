package user;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

/*
Zadani: Spocitani poctu uvedenych kategorii pro kazde zbozi
*/

public class MySaxHandler extends DefaultHandler {

    public static void main(String[] args)  {
    
        // Cesta ke zdrojovĂ©mu XML dokumentu
        String sourcePath = "data.xml";

        try {

            // VytvorĂ­me instanci parseru.
            XMLReader parser = XMLReaderFactory.createXMLReader();

            // VytvorĂ­me vstupnĂ­ proud XML dat.
            InputSource source = new InputSource(sourcePath);

            // NastavĂ­me nĂˇÄ… vlastnĂ­ content handler pro obsluhu SAX udĂˇlostĂ­.
            parser.setContentHandler(new MujContentHandler());

            // Zpracujeme vstupnĂ­ proud XML dat.
            parser.parse(source);

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

}

/**
 * NĂˇĹˇ vlastnĂ­ content handler pro obsluhu SAX udĂˇlostĂ­.
 * Implementuje metody interface ContentHandler.
 */
class MujContentHandler implements ContentHandler  {

    // UmoĹľĹuje zacĂ­lit mĂ­sto v dokumentu, kde vznikla aktualnĂ­ udĂˇlost
    Locator locator;
    boolean uvnitrzbozi;
    int pocet_kategorii;
    String aktualnizbozi;
    String aktualnizbozibezmezer;
    FileWriter fstream;
    BufferedWriter out;
    
    private StringBuffer nazev = new StringBuffer(1000);

    /**
     * NastavĂ­ locator
     */
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Obsluha udĂˇlosti "zaÄŤĂˇtek dokumentu"
     */
    public void startDocument() throws SAXException {

        try {
            fstream = new FileWriter("sax.output.txt");
        } catch (IOException ex) {
            Logger.getLogger(MujContentHandler.class.getName()).log(Level.SEVERE, null, ex);
        }

        
        out = new BufferedWriter(fstream);
    }
    /**
     * Obsluha udĂˇlosti "konec dokumentu"
     */
    public void endDocument() throws SAXException {
        try {
            out.close();
        } catch (IOException ex) {
            Logger.getLogger(MujContentHandler.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    /**
     * Obsluha udĂˇlosti "zaÄŤĂˇtek elementu".
     * @param uri URI jmennĂ©ho prostoru elementu (prĂˇzdnĂ©, pokud element nenĂ­ v ĹľĂˇdnĂ©m jmennĂ©m prostoru)
     * @param localName LokĂˇlnĂ­ jmĂ©no elementu (vĹľdy neprĂˇzdnĂ©)
     * @param qName KvalifikovanĂ© jmĂ©no (tj. prefix-uri + ':' + localName, pokud je element v nÄ›jakĂ©m jmennĂ©m prostoru, nebo localName, pokud element nenĂ­ v ĹľĂˇdnĂ©m jmennĂ©m prostoru)
     * @param atts Atributy elementu
     */
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        if(qName.equals("zbozi")) {
          uvnitrzbozi=true;
        }

        if(qName.equals("kategorie")) {
          pocet_kategorii++;
        }



    }
    /**
     * Obsluha udĂˇlosti "konec elementu"
     * Parametry majĂ­ stejnĂ˝ vĂ˝znam jako u @see startElement
     */
    public void endElement(String uri, String localName, String qName) throws SAXException {

       if(qName.equals("zbozi")) {
           System.out.println("Pocet kategorii zbozi "+aktualnizbozibezmezer+" "
                 + "je: "+pocet_kategorii);
            try {
                // vypis do souboru sax.output.txt
                write(out,"Pocet kategorii zbozi "+aktualnizbozibezmezer+":"+pocet_kategorii+"\n");
                
            } catch (IOException ex) {
                Logger.getLogger(MujContentHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
           pocet_kategorii=0;
          
        }



       if(qName.equals("nazev_z")) {
            uvnitrzbozi=false;
         
            aktualnizbozi=nazev.toString();
            nazev.delete(0, nazev.length());
            aktualnizbozibezmezer=aktualnizbozi.trim();
        }




    }

    /**
     * Obsluha udĂˇlosti "znakovĂˇ data".
     * SAX parser muÄľe znakovĂˇ data dĂˇvkovat jak chce. Nelze tedy poÄŤĂ­tat s tĂ­m, Ĺľe je celĂ˝ text dorucen v rĂˇmci jednoho volĂˇnĂ­.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakovĂ˝mi daty
     * @param start Index zacĂˇtku Ăşseku platnĂ˝ch znakovĂ˝ch dat v poli.
     * @param length DĂ©lka Ăşseku platnĂ˝ch znakovĂ˝ch dat v poli.
     */
    public void characters(char[] ch, int start, int length) throws SAXException {

         if(uvnitrzbozi==true) {
            nazev.append(ch,start,length);
         }

    }

    /**
     * Obsluha udĂˇlosti "deklarace jmennĂ©ho prostoru".
     * @param prefix Prefix prirazenĂ˝ jmennĂ©mu prostoru.
     * @param uri URI jmennĂ©ho prostoru.
     */
    public void startPrefixMapping(String prefix, String uri) throws SAXException {

        // ...

    }

    /**
     * Obsluha udĂˇlosti "konec platnosti deklarace jmennĂ©ho prostoru".
     */
    public void endPrefixMapping(String prefix) throws SAXException {

        // ...

    }

    /**
     * Obsluha udĂˇlosti "ignorovanĂ© bĂ­lĂ© znaky".
     * StejnĂ© chovĂˇnĂ­ a parametry jako @see characters
     */
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {



    }

    /**
     * Obsluha udĂˇlosti "instrukce pro zpracovĂˇnĂ­".
     */
    public void processingInstruction(String target, String data) throws SAXException {

      // ...

    }

    /**
     * Obsluha udĂˇlosti "nezpracovanĂˇ entita"
     */
    public void skippedEntity(String name) throws SAXException {

      // ...

    }

private void write(BufferedWriter out, String s) throws SAXException, IOException {
  
    try{
    
    out.write(s); 
    
    }catch (Exception e){
      System.err.println("Chyba: " + e.getMessage());
    }
    
}

}