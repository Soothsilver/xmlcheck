/**
 * @author Vladimír Matěna
 */

package user;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;
import java.util.HashMap;
import java.util.Map;

class SaxTester {
	/** Main - spusti handler na testovacim vstupu **/
	public static void main(String [] args) {
		// Cesta ke zdrojovému XML dokumentu
        String sourcePath = "data.xml";

        try {
            // Vytvoríme instanci parseru.
            XMLReader parser = XMLReaderFactory.createXMLReader();

            // Vytvoríme vstupní proud XML dat.
            InputSource source = new InputSource(sourcePath);

            // Nastavíme náą vlastní content handler pro obsluhu SAX událostí.
            parser.setContentHandler(new MySaxHandler());

            // Zpracujeme vstupní proud XML dat.
            parser.parse(source);

        } catch (Exception e) {
            e.printStackTrace();
        }
	}
}

/** SAX handler ktery spocita pocty vyskytu jednotlivych elementu **/
public class MySaxHandler extends DefaultHandler {
	Map<String,Integer> elements = new HashMap<String, Integer>();

	/** zapocita element **/
	@Override public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
		Object value = elements.get(localName);

		if(value == null) {
			elements.put(localName, 1);
		} else {
			elements.put(localName, ((Integer)value) + 1);
		}
    }

	/** Vypise zaverecnou statistiku **/
	@Override public void endDocument() throws SAXException {
        for(Map.Entry<String, Integer> i: elements.entrySet()) {
			System.out.println(String.format("Element \"%s\" nalezen: %d krat.", i.getKey(), i.getValue()));
		}
    }
}
