/**
 * @author Vladimír Matěna
 */

package user;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

/** otestuje transformaci **/
class DomTester {
	private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "data.out.xml";

	/** Otestuje transformaci na testovacim souboru **/
    public static void main(String[] args) {
        try {
			
            //DocumentBuilderFactory vytváří DOM parsery
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            //nebudeme validovat
            dbf.setValidating(false);

            //vytvoříme si DOM parser
            DocumentBuilder builder = dbf.newDocumentBuilder();

            //parser zpracuje vstupní soubor a vytvoří z něj strom DOM objektů
            Document doc = builder.parse(VSTUPNI_SOUBOR);

            //zpracujeme DOM strom
			MyDomTransformer myTransformer = new MyDomTransformer();
            myTransformer.transform(doc);

            //TransformerFactory vytváří serializátory DOM stromů
            TransformerFactory tf = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer = tf.newTransformer();

            //nastavíme kodování
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            //spustíme transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

/* Transformace ktera odstrani z kazdeho elementu vsechny jeho potomky ktere maji
 * stejne jmeno az na ten prvni. */
public class MyDomTransformer {
	public void transform (Document xmlDocument)
	{
		Element root = xmlDocument.getDocumentElement();

		stripChilds(root);
	}

	/** odstrani vicenasobne vyskyty elementu **/
	void stripChilds(Element element)
	{
		NodeList nodes = element.getChildNodes();

		for(int i = 0; i < nodes.getLength(); ++i) {
			if(nodes.item(i).getNodeType() == Node.ELEMENT_NODE) {
				Element e = ((Element)nodes.item(i));
				
				if(i + 1 < nodes.getLength()) {
					for(int j = i + 1; j < nodes.getLength(); ++j) {
						if(nodes.item(j).getNodeType() == Node.ELEMENT_NODE) {
							Element l = ((Element)nodes.item(j));
							if(l.getTagName().equals(e.getTagName()))
							{
								element.removeChild(nodes.item(j));
								nodes = element.getChildNodes();
							}
						}
					}
				}
			}
		}

		for(int i = 0; i < nodes.getLength(); ++i) {
			if(nodes.item(i).getNodeType() == Node.ELEMENT_NODE) {
				Element e = ((Element)nodes.item(i));
				stripChilds(e);
			}
		}
	}
}
