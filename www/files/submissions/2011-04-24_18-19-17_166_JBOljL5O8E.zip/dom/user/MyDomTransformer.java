/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package user;

import java.io.File;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

//import cz.XmlTester.TestJava;

public class MyDomTransformer// extends TestJava
{
    private static final String launcherNode = "launcher";
    private static final String launchersNode = "launchers";
    private static final String launcherName = "name";
    private static final String launcherID = "launcherID";

    private static final String inputFile = "../data.xml";
    private static final String outputFile = "../data.out.xml";


    private static final String UTF_8 = "utf-8";

    /**
    * main funkce
    */
    public void run()
    {

        DocumentBuilderFactory factory
                = DocumentBuilderFactory.newInstance();

        factory.setValidating(false);

        try
        {
            DocumentBuilder builder = factory.newDocumentBuilder();

            //parser zpracuje vstupni soubor a vytvori z nej strom DOM objektu
            Document doc = builder.parse(inputFile);

            transform(doc);

            //TransformerFactory vytvari serializatory DOM stromu
            TransformerFactory transformerFactory = TransformerFactory.newInstance();

            //Transformer serializuje DOM stromy
            Transformer writer = transformerFactory.newTransformer();

            //nastavime kodovani
            writer.setOutputProperty(OutputKeys.ENCODING, UTF_8);

            //spustime transformaci DOM stromu do XML dokumentu
            writer.transform(new DOMSource(doc), new StreamResult(new File(outputFile)));
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

    }

    /**
     * Vo vstupnom XML dokumente nahradi podrobne elementy 'launcherNode'
     * ich zjednodusenou verziou obsahujucou len atribut 'launcherID'.
     * Toto ID odkazuje do zoznamu unikatnych elementov 'launcherNode',
     * ktory je umiestneny v novovytvorenom elemente 'launchersNode'
     * v ramci bazoveho elementu dokumentu.
     * @param document - spracovavany dokument
     */
    public void transform(Document document)
    {
        NodeList launcherNodes = document.getElementsByTagName(launcherNode);
             
        int launcherNodeCount = launcherNodes.getLength();
        Vector<Element> launcherElements = new Vector<Element>(launcherNodeCount);

        //skopiruje vsetky elementy <launcher> do pracovneho pola launcherElements
        for (int i = 0; i < launcherNodeCount; ++i)
        {
            launcherElements.add((Element)launcherNodes.item(i));
        }

        Element launcherListNode = document.createElement(launchersNode);
        document.getDocumentElement().appendChild(launcherListNode);

        //pole obsahujuce len rozdielne elementy <launcher>
        Vector<Element> uniqueLaunchers = new Vector<Element>();
        
        for (Element launcher : launcherElements)
        {
            //vytvori skrateny element <launcher> obsahujuci len ID
            Element newLauncher = document.createElement(launcherNode);

            //z mena utvori ID
            String newID = makeUniqueID(launcher.getAttribute(launcherName));
            newLauncher.setAttribute(launcherID, newID);

            //zo stromu odstrani stary a doplni novy element <launcher>
            Node mission = launcher.getParentNode();
            mission.removeChild(launcher);
            mission.appendChild(newLauncher);

            //ak je element novym typom <launcher>, prida ho do zoznamu nosicov
            boolean isLauncherUnique = isSuccessfullInsertToUniqueVector(uniqueLaunchers,launcher);
            if (isLauncherUnique)
            {
                launcher.setAttribute(launcherID, newID);
                launcherListNode.appendChild(launcher);
            }
        }
    }

    /**
     * Do pola elementList prida newElement, ak tam uz rovnaky Element nie je.
     * Porovnanie vykonava podla atributu 'launcherName' (globalna konstanta).
     * @param elementList - zoznam unikatnych
     * @param newElement - vkladany element
     * @return true - element vlozeny, false - nevlozeny (uz v poli je)
     */
    private boolean isSuccessfullInsertToUniqueVector
            (Vector<Element> elementList, Element newElement)
    {
        boolean isMatched = false;
        for (Element element : elementList)
        {
            if (element.getAttribute(launcherName).equals(newElement.getAttribute(launcherName)))
            {
                isMatched = true;
                break;
            }
        }

        if (isMatched)
        {            
            return false;
        }
        else
        {
            elementList.add(newElement);
            return true;
        }
    }

    /**
     * Z uniqueName vytvori ID.
     * Ponecha len pismena a cislice, pred nazov prida znak '_'.
     * @param uniqueName unikatne meno (v zmysle pismen a znakov)
     * @return ID
     */
    private String makeUniqueID(String uniqueName)
    {
        String uniqueID = "_";

        int nameLength = uniqueName.length();
        for (int i=0;i<nameLength;++i)
        {
            if (Character.isLetterOrDigit(uniqueName.charAt(i)))
            {
                uniqueID = uniqueID.concat(uniqueName.substring(i, i+1));
            }
        }

        return uniqueID;
    }



}

