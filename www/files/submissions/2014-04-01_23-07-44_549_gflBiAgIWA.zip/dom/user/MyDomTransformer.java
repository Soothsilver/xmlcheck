/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package user;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * 1. uprava - Pridani noveho filmu
 * 2. uprava - Serazeni uzivatelu abecedne podle prezdivky
 * @author Patrik Pastercik
 */
public class MyDomTransformer {
    public void transform(Document xmlDocument) {
        processTree1(xmlDocument);
        processTree2(xmlDocument);
    }
    
    // Vytvori element s textem
    private static Element CreateElementWithText(Document doc, String elementName, String text) {
        Element temp = doc.createElement(elementName);
        temp.setTextContent(text);
        return temp;
    }
    
    // Vytvori element s jednim atributem
    private static Element CreateElementWithAttr(Document doc, String elementName, String attrName, String text) {
        Element temp = doc.createElement(elementName);
        temp.setAttribute(attrName, text);
        return temp;
    }
    
    // Vytvori element s jednim atributem a textem
    private static Element CreateElementWithAttrAndText(Document doc, String elementName, String attrName, String attrText, String text) {
        Element temp = doc.createElement(elementName);
        temp.setAttribute(attrName, attrText);
        temp.setTextContent(text);
        return temp;
    }
    
    // 1. uprava - Pridani noveho filmu
    private static void processTree1(Document doc) {
        Element novyFilm = doc.createElement("Film");
        novyFilm.setAttribute("id", "film000005");
        novyFilm.setAttribute("datumVytvoreni", "2014-03-31 12:00:00");
        
        novyFilm.appendChild(CreateElementWithText(doc, "Nazev", "Titanic"));
        
        novyFilm.appendChild(CreateElementWithText(doc, "RokUvedeni", "1997"));
        
        Element mistaNataceniFilmu = doc.createElement("MistaNataceni");
        mistaNataceniFilmu.appendChild(CreateElementWithAttr(doc, "StatNataceni", "stat", "USA"));
        novyFilm.appendChild(mistaNataceniFilmu);
        
        novyFilm.appendChild(CreateElementWithText(doc, "Zanr", "Drama | Historicky | Katastroficky | Romanticky"));
        
        Element delkaFilmu = doc.createElement("Delka");
        delkaFilmu.appendChild(CreateElementWithAttr(doc, "DelkaVerze", "minut", "194"));
        novyFilm.appendChild(delkaFilmu);
        
        Element zapojeniLideFilmu = doc.createElement("ZapojeniLide");
        
        Element rezieFilmu = doc.createElement("RezieFilmu");
        rezieFilmu.appendChild(CreateElementWithAttrAndText(doc, "ClovekRef", "ref", "clovek000001", "James Cameron"));
        zapojeniLideFilmu.appendChild(rezieFilmu);
        
        Element scenarFilmu = doc.createElement("RezieFilmu");
        scenarFilmu.appendChild(CreateElementWithAttrAndText(doc, "ClovekRef", "ref", "clovek000001", "James Cameron"));
        zapojeniLideFilmu.appendChild(scenarFilmu);
        
        Element kameraFilmu = doc.createElement("RezieFilmu");
        kameraFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Russell Carpenter"));
        zapojeniLideFilmu.appendChild(kameraFilmu);
        
        Element hudbaFilmu = doc.createElement("RezieFilmu");
        hudbaFilmu.appendChild(CreateElementWithText(doc, "Clovek", "James Horner"));
        zapojeniLideFilmu.appendChild(hudbaFilmu);
        
        Element hrajiVeFilmu = doc.createElement("RezieFilmu");
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Leonardo DiCaprio"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Kate Winslet"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Billy Zane"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Kathy Bates"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Bill Paxton"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Gloria Stuart"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Frances Fisher"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Bernard Hill"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Jonathan Hyde"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "David Warner"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Victor Garber"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Danny Nucci"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Suzy Amis"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Ewan Stewart"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Ioan Gruffudd"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Richard Graham"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Ron Donachie"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Bernard Fox"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Eric Braeden"));
        hrajiVeFilmu.appendChild(CreateElementWithAttrAndText(doc, "ClovekRef", "ref", "clovek000001", "James Cameron"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Seth Adkins"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Tricia O'Neil"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Anne Fletcher"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Jenette Goldstein"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Mark Lindsay Chapman"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Lewis Abernathy"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Simon Crane"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Mike Butters"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Camilla Overbye Roos"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "John Walcutt"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Charlotte Chatton"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Martin Jarvis"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Jason Barry"));
        hrajiVeFilmu.appendChild(CreateElementWithText(doc, "Clovek", "Greg Ellis"));
        zapojeniLideFilmu.appendChild(hrajiVeFilmu);
        
        novyFilm.appendChild(zapojeniLideFilmu);
        
        novyFilm.appendChild(CreateElementWithText(doc, "Popis", "Byl obrovsky a luxusni. Lide o nem ve sve pyse rikali, ze je nepotopitelny. Kdyz vyplouval Titanic na svou prvni plavbu, byli na jeho palube take chudy Jack a bohata Rose. On vyhral listek v pokeru, ona mela pronajato jedno z nejluxusnejsich apartma. Prozili spolu nejkrasnejsi chvile zivota a slibili si, ze uz se nikdy nerozejdou - az do one osudne noci, kdy pycha lidstva narazila v Severnim mori do ledovce, ktery Titanic neuprosne poslal ke dnu. Krasna romance se zmenila ve zbesily a tragicky boj o zachranu. Kolik jim zbyva? Hodina, mozna dve...(oficialni text distributora)"));
        
        Element zajimavostiFilmu = doc.createElement("Zajimavosti");
        novyFilm.appendChild(zajimavostiFilmu);
        
        Element webyFilmu = doc.createElement("Weby");
        Element cdataWebyFilmu = CreateElementWithAttr(doc, "Web", "webPageName", "CSFD");
        cdataWebyFilmu.appendChild(doc.createCDATASection("http://www.csfd.cz/film/1250-titanic/"));
        webyFilmu.appendChild(cdataWebyFilmu);
        cdataWebyFilmu = CreateElementWithAttr(doc, "Web", "webPageName", "IMDb");
        cdataWebyFilmu.appendChild(doc.createCDATASection("http://www.imdb.com/title/tt0120338/"));
        webyFilmu.appendChild(cdataWebyFilmu);
        novyFilm.appendChild(webyFilmu);
        
        Element hodnoceniFilmu = doc.createElement("HodnoceniUzivateli");
        novyFilm.appendChild(hodnoceniFilmu);
        
        doc.getElementsByTagName("Filmy").item(0).appendChild(novyFilm);
    }
    
    // Ziska textovy retezec z elementu 'Prezdivka' elementu 'Uzivatel'
    private static String ZiskaniPrezdivky(Node node) {
        NodeList nodeList = node.getChildNodes();
        for (int i = 0; i < nodeList.getLength(); i++) {
            if ("Prezdivka".equals(nodeList.item(i).getNodeName())) {
                return nodeList.item(i).getTextContent();
            }
        }
        return null;
    }
    
    // 2. uprava - Serazeni uzivatelu abecedne podle prezdivky
    private static void processTree2(Document doc) {
        List<Node> uzivatele = new ArrayList<Node>();
        Node nodeUzivatele = doc.getElementsByTagName("Uzivatele").item(0);
        NodeList nodeList = doc.getElementsByTagName("Uzivatel");
        
        // Smazani uzivatelu a vlozeni do Listu
        while(nodeList.getLength() > 0) {
            uzivatele.add(nodeUzivatele.removeChild(nodeList.item(0)));
        }
        
        // Setrideni uzivatelu
        Collections.sort(uzivatele, new Comparator<Node>(){
            public int compare(Node node1, Node node2) {
                String temp1 = ZiskaniPrezdivky(node1);
                String temp2 = ZiskaniPrezdivky(node2);
                return temp1.compareTo(temp2);
            }
        });
        
        // Vlozeni setridenych uzivatelu do stromu
        for (int i = 0; i < uzivatele.size(); i++) {
            nodeUzivatele.appendChild(uzivatele.get(i));
        }
    }
}
