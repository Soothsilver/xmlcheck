/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package user;
import java.util.HashMap;
import java.util.Map;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * 1. charakteristika - pocita kolik uzivatelu shledlo jaky film (pres atrubut 'ref' elementu 'ShlednutoRef')
 * 2. charakteristika - pocita prumerne hodnoceni filmu uzivateli (pres obsah elementu 'HodnoceniUzivatelem')
 * 3. charakteristika - vyhleda filmy s podminkou (rokUvedeni >= 2009 AND StatNataceni != 'GB' AND Zanr != 'Horor')
 * @author Patrik Pastercik
 */
public class MySaxHandler extends DefaultHandler {
    
    // Promenne 1. charakteristiky
    Map<String, Integer> pocetShlednutiPodleId;
    Map<String, Integer> pocetShlednutiPodleNazvu;
    String idFilmu;
    
    // Promenne 2. charakteristiky
    Map<String, Double> hodnoceniPodleNazvu;
    double soucetHodnoceni;
    int pocetHodnoceni;
    String tempHodnoceni;
    boolean zpracovaniHodnoceni;
    
    // Promenne 3. charakteristiky
    Map<String, String> hledaneFilmy;
    String idHledanehoFilmu;
    boolean rokUvedeni;
    boolean mistoNataceni;
    boolean zanr;
    String tempText;
    boolean zpracovaniRokVzniku;
    boolean zpracovaniZanr;
    
    
    // Pomocne promenne pro ziskani nazvu filmu
    String nazevFilmu="";
    String tempNazev="";
    boolean zpracovaniNazvu=false;
    
    
    // Helper variable to store location of the handled event
    Locator locator;

    /**
     * Sets the locator
     *
     * @param locator locator location in the file
     */
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }
    
    /**
     * Method to handle "document start"
     *
     * @throws SAXException
     */
    @Override
    public void startDocument() throws SAXException {
        // Inicializace promennych 1. charakteristiky
        pocetShlednutiPodleId = new HashMap<String, Integer>();
        pocetShlednutiPodleNazvu = new HashMap<String, Integer>();
        idFilmu="";
        
        // Inicializace promennych 2. charakteristiky
        hodnoceniPodleNazvu = new HashMap<String, Double>();
        soucetHodnoceni=0;
        pocetHodnoceni=0;
        tempHodnoceni="";
        zpracovaniHodnoceni=false;
        
        // Inicializace promennych 3. charakteristiky
        hledaneFilmy = new HashMap<String, String>();
        idHledanehoFilmu="";
        rokUvedeni=true;
        mistoNataceni=true;
        zanr=true;
        tempText="";
        zpracovaniRokVzniku=false;
        zpracovaniZanr=false;
        
        
        // Inicializace pomocnych promennych pro ziskani nazvu filmu
        nazevFilmu="";
        tempNazev="";
        zpracovaniNazvu=false;
    }
    
    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
        // Vypis 1. charakteristiky
        System.out.println("Jaky film videlo kolik uzivatelu:");
        for (String string : pocetShlednutiPodleNazvu.keySet()) {
            System.out.println("Film '" + string + "' videlo " + pocetShlednutiPodleNazvu.get(string) + " uzivatelu.");
        }
        System.out.println();
        
        // Vypis 2. charakteristiky
        System.out.println("Jaky film ma jake hodnoceni (prumer od uzivatelu):");
        for (String string : hodnoceniPodleNazvu.keySet()) {
            System.out.println("Film '" + string + "' ma hodnoceni " + String.format("%.2f",hodnoceniPodleNazvu.get(string)) + "%.");
        }
        System.out.println();
        
        // Vypis 3. charakteristiky
        System.out.println("Seznam filmu (rokUvedeni >= 2009, StatNataceni != 'GB', Zanr != 'Horor')");
        System.out.println("Pocet nalezenych filmu: " + hledaneFilmy.size() + ".");
        for (String string : hledaneFilmy.keySet()) {
            System.out.println("Id filmu '" + string + "', nazev '" + hledaneFilmy.get(string) + "'.");
        }
        System.out.println();
    }
    
    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        // Kod 1. charakteristiky
        if ("ShlednutoRef".equals(localName)) {
            Integer tempint = 0;
            if (pocetShlednutiPodleId.containsKey(atts.getValue("ref"))) {
                tempint = pocetShlednutiPodleId.get(atts.getValue("ref"));
            }
            pocetShlednutiPodleId.put(atts.getValue("ref"), tempint + 1);
        }
        if ("Film".equals(localName)) {
            if (!pocetShlednutiPodleId.containsKey(atts.getValue("id"))) {
                pocetShlednutiPodleId.put(atts.getValue("id"), 0);
            }
            idFilmu = atts.getValue("id");
        }
        
        // Kod 2. charakteristiky
        if ("Film".equals(localName)) {
            soucetHodnoceni=0;
            pocetHodnoceni=0;
        }
        if ("HodnoceniUzivatelem".equals(localName)) {
            tempHodnoceni="";
            zpracovaniHodnoceni=true;
        }
        
        // Kod 3. charakteristiky
        if ("Film".equals(localName)) {
            rokUvedeni = true;
            mistoNataceni = true;
            zanr = true;
            idHledanehoFilmu=atts.getValue("id");
        }
        if ("RokUvedeni".equals(localName)) {
            tempText = "";
            zpracovaniRokVzniku = true;
        }
        if ("StatNataceni".equals(localName)) {
            if ("GB".equals(atts.getValue("stat"))) {
                mistoNataceni=false;
            }
        }
        if ("Zanr".equals(localName)) {
            tempText = "";
            zpracovaniZanr = true;
        }
        
        
        // Pomocny kod pro ziskani nazvu filmu
        if ("Film".equals(localName)) {
            nazevFilmu="";
        }
        if ("Nazev".equals(localName) && ("".equals(nazevFilmu) || "cs".equals(atts.getValue("jazyk")))) {
            tempNazev="";
            zpracovaniNazvu=true;
        }
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        // Kod 1. charakteristiky
        if ("Film".equals(localName)) {
            String nazev=nazevFilmu.trim();
            pocetShlednutiPodleNazvu.put(nazev, pocetShlednutiPodleId.get(idFilmu));
        }
        
        // Kod 2. charakteristiky
        if ("HodnoceniUzivatelem".equals(localName) && zpracovaniHodnoceni==true) {
            soucetHodnoceni+=Double.parseDouble(tempHodnoceni);
            pocetHodnoceni++;
            zpracovaniHodnoceni=false;
        }
        if ("Film".equals(localName)) {
            String nazev=nazevFilmu.trim();
            hodnoceniPodleNazvu.put(nazev, soucetHodnoceni/pocetHodnoceni);
        }
        
        // Kod 3. charakteristiky
        if ("Film".equals(localName)) {
            if (rokUvedeni==true && mistoNataceni==true && zanr==true) {
                String nazev=nazevFilmu.trim();
                hledaneFilmy.put(idHledanehoFilmu, nazev);
            }
        }
        if ("RokUvedeni".equals(localName) && zpracovaniRokVzniku==true) {
            if (Integer.parseInt(tempText)<2009) {
                rokUvedeni=false;
            }
            zpracovaniRokVzniku=false;
        }
        if ("Zanr".equals(localName) && zpracovaniZanr==true) {
            if (tempText.contains("Horor")) {
                zanr=false;
            }
            zpracovaniZanr=false;
        }
        
        
        // Pomocny kod pro ziskani nazvu filmu
        if ("Nazev".equals(localName) && zpracovaniNazvu==true) {
            nazevFilmu=tempNazev;
            zpracovaniNazvu=false;
        }
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        // Kod 2. charakteristiky
        if (zpracovaniHodnoceni==true) {
            tempHodnoceni += new String(chars, start, length);
        }
        
        // Kod 3. charakteristiky
        if (zpracovaniRokVzniku==true || zpracovaniZanr==true) {
            tempText += new String(chars, start, length);
        }
        
        
        // Pomocny kod pro ziskani nazvu filmu
        if (zpracovaniNazvu==true) {
            tempNazev += new String(chars, start, length);
        }
    }
}
