
package user;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/*
* Omlouvam se za tento kod. Je to velky neporadek, receno slusne.
*/
public class MyDomTransformer {
    
    public void transform (Document xml) {
        addHero(xml);
        sortTeamsAlphabetically(xml);
    }
    
    private void addHero(Document xml){
        
        Element hero = xml.createElement("hero");
        
        hero.setAttribute("name", "Einarion");
        hero.setAttribute("race", "High Elf");
        
        Element item = xml.createElement("uses");
        item.setAttribute("item_id", "i_1");
        
        hero.appendChild(item);
        
        NodeList heroes = xml.getElementsByTagName("heroes");
        Element hrs;

        hrs = (Element) heroes.item(0);

        hrs.appendChild(hero);
    }
    
    private void sortTeamsAlphabetically(Document xml){
        
        NodeList teamNodes = xml.getElementsByTagName("team");
        
        List<Node> teams = new ArrayList<Node>(); 
        
        for(int i = 0; i < teamNodes.getLength(); i++){
            teams.add(teamNodes.item(i));
        }

        Collections.sort(teams, new Comparator<Node>(){

            public int compare(Node node1, Node node2) {
                Element n1 = (Element) node1;
                Element n2 = (Element) node2;

                String one = n1.getElementsByTagName("name").item(0).getTextContent();
                String two = n2.getElementsByTagName("name").item(0).getTextContent();

                return one.compareToIgnoreCase(two);
            }
        });
        
        Element league = (Element) xml.getElementsByTagName("league").item(0);
        
        for(Node n : teams){
              league.appendChild(n);
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
