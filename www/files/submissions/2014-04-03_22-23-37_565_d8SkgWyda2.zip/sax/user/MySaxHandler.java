
package user;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

//Monstrosity.
public class MySaxHandler extends DefaultHandler {
    
    public static final String lineSeparator = System.getProperty("line.separator");
    
    private String currentElement = "";
    private String currentAttribute = "";
    private String currentItemType = "";
    private String currentTeamName = "";
    
    private Hero currentHero;
    private Item currentItem;
    
    private Set<Hero> heroes = new HashSet<Hero>();
    private Set<Item> items = new HashSet<Item>();

    class Hero {
        private String name = "";
        private Set<String> items = new HashSet<String>();
        private String race = "";
        private String currentTeamName = "";

        public void setCurrentTeamName(String currentTeamName) {
            this.currentTeamName = currentTeamName;
        }

        public String getCurrentTeamName() {
            return currentTeamName;
        }
        
        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Set<String> getItems() {
            return items;
        }
        
        public void addItem(String id){
            this.items.add(id);
        }
        

        public String getRace() {
            return race;
        }

        public void setRace(String race) {
            this.race = race;
        }
    }
    
    class Item {
        private String name = "";
        private String type = "";
        private String id = "";
        private int damage = 0;
        private int bonus = 0;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public int getDamage() {
            return damage;
        }

        public void setDamage(int damage) {
            this.damage = damage;
        }

        public int getBonus() {
            return bonus;
        }

        public void setBonus(int bonus) {
            this.bonus = bonus;
        }
    }

    @Override
    public void setDocumentLocator(Locator locator) {
        
    }

    @Override
    public void startDocument() throws SAXException {
        
    }

    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
    }

    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        
       if(localName.toLowerCase().equals("name")){
           
                this.currentTeamName = qName;
                return;
       }
       if(localName.toLowerCase().equals("hero")){
                if(this.currentHero != null) heroes.add(this.currentHero);
                this.currentHero = new Hero();
                this.currentHero.setName(atts.getValue("name"));
                this.currentHero.setRace(atts.getValue("race"));
                this.currentHero.setCurrentTeamName(this.currentTeamName);
                return;
       }
       if(localName.toLowerCase().equals("item")){
                
                this.currentItem = new Item();
                if(this.currentItemType.equals("offense")) {
                    this.currentItem.setType("offense");
                    this.currentItem.setDamage(Integer.parseInt(atts.getValue("damage")));
                }
                if(this.currentItemType.equals("defense")){
                    this.currentItem.setType("defense");
                    this.currentItem.setBonus(Integer.parseInt(atts.getValue("bonus")));
                }
                if(this.currentItemType.equals("armour")) this.currentItem.setType("armour");
                this.currentItem.setId(atts.getValue("item_id"));
                this.currentItem.setName(atts.getValue("name"));
                this.items.add(this.currentItem);
                return;
       }
       if(localName.toLowerCase().equals("uses")){
                this.currentHero.addItem(atts.getValue("item_id"));
                return;
       }
       if(localName.toLowerCase().equals("offense")){
                this.currentItemType = "offense";
                return;
       }
       if(localName.toLowerCase().equals("defense")){
                this.currentItemType = "defense";
                return;
       }
       
       if(localName.toLowerCase().equals("armour")){
                this.currentItemType = "armour";
                return;
       }

    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        
    }

    @Override
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
    }

    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        
    }

    @Override
    public void skippedEntity(String name) throws SAXException {
        
    }
    
    @Override
    public void endDocument() throws SAXException {
        if(this.currentHero != null) this.heroes.add(this.currentHero);
        resolveData();
    }
    
    private void resolveData(){
        List<String> results = new ArrayList<String>();
        results.add(getAverageDamage());
        results.add(getMostFrequentRace());
        results.add(findHeroesUnderCriteria());
        printResults(results);
    }
    
    
    private String getAverageDamage(){
        int average = 0;
        float offenseItems = 0;
        for(Item item : items){
            if (item.getType().toLowerCase().equals("offense")){
                average += item.damage;
                offenseItems++;
            }
            
        }
        return "Average damage for offensive items: " + (average / offenseItems);
    }
    
    private String getMostFrequentRace(){
        Map<String, Integer> raceFreq = new HashMap<String, Integer>();
        for(Hero hero : heroes){
            if(raceFreq.containsKey(hero.getRace().toLowerCase())) raceFreq.put(hero.getRace().toLowerCase(), 1+raceFreq.get(hero.getRace().toLowerCase()));
            else raceFreq.put(hero.getRace().toLowerCase(), 1);
        }
        
        String winnerRace = "";
        int raceCount = 0;
        
        for(String key : raceFreq.keySet()){
            int i = raceFreq.get(key);
            if(i > raceCount) {
                winnerRace = key;
                raceCount = i;
            }
        }
        return "Race with the most representatives (" + raceCount + ") is " + winnerRace;
    }
    
    private String findHeroesUnderCriteria(){
        String result = "Heroes who are not darkefls and wield a longsword: " + lineSeparator;
        String longswordId = "";
        for (Item item : items){
            if(item.getName().toLowerCase().equals("longsword")){
                longswordId = item.getId();
                break;
            }
        }
        for(Hero hero : heroes){
            if(!hero.getRace().toLowerCase().equals("darkelf") && hero.items.contains(longswordId)) result += hero.name + " (" + hero.race + ")"+ lineSeparator;
        }
        return result;
    }
    
    
    private void printResults(List<String> results){
        for (String result : results){
            System.out.println(result);
        }
    }
    
    
    
    
    
    
    
    
    
    
}