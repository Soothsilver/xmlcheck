/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.util.Hashtable;
import org.w3c.dom.*;



/**
 *
 * @author Kirrie
 */
public class MyDomTransformer {
    static Hashtable<String,String> autory = new Hashtable<String,String>();
    static Hashtable<String,String> products = new Hashtable<String, String>();
    static Hashtable<String,Integer> ckomentare = new Hashtable<String, Integer>();
    
    /**
     * @param args the command line arguments
     */
                   
    //pridavanie mien k prvkom a autorom
    public static void part1(NodeList n1,NodeList n2,Document doc) {
        for (int i = 0;i<n1.getLength();i++) {           
            NodeList nodeChilds = n1.item(i).getChildNodes();
            for (int j = 0;j<nodeChilds.getLength();j++) {
                if (nodeChilds.item(j).getNodeName().equals("autor_komentara")) {                       
                    Element e1 = (Element)nodeChilds.item(j); //stary tag s autorom               
                    increm(e1.getAttribute("id"));
                    Element e2 = doc.createElement("autor_komentara");  //novy tag rovnako nazvany
                    e2.setTextContent(autory.get(e1.getAttribute("id")));   // nastavi takeho autora ktory pasuje k id
                    n1.item(i).replaceChild(e2, e1);
                }
            }
        }
        for (int i = 0;i<n2.getLength();i++) {           
            String serv = parent(n2.item(i),"server");
            Element e2 =(Element)n2.item(i);            
            Element e1 = doc.createElement("meno_suroviny");
            e1.setTextContent(products.get(serv+"_"+e2.getAttribute("number")));   // nastavi taky produkt ktory pasuje k id
            
            e2.appendChild(e1);
            }                    
    }
    
    // Funkcia spocita kolko komentarov pridal uzivatel s id
    public static void increm(String id) {
        int value;
        try {
            value = ckomentare.get(id);
        } catch (Exception e) {
            value = 0;
        }
        ckomentare.put(id, value+1);
    }
    
    public static String parent(Node n,String m) {
        
        Element e = (Element)n;
        if (e.getNodeName().equals(m)) {
            return e.getAttribute("id");
        }
        Element parent = (Element)e.getParentNode();
        
        return parent(parent,m);
    }
    
    // vypis kolko komentarov napisal autor z premennej ckomentare
    public static void part2(NodeList n1,Document doc) {
        for (int i = 0;i<n1.getLength();i++) {
            Element e1 = (Element)n1.item(i);
            Element e2 = doc.createElement("pocet_komentarov");
            Integer value = ckomentare.get(e1.getAttribute("id"));
            if (value == null) value=0;                
            e2.setTextContent(String.valueOf(value));
            e1.appendChild(e2);
        }
    }
    
    public static void transform(Document doc) {
        String meno ="";
        String id ="";
        
        NodeList np = doc.getElementsByTagName("product");
        NodeList nd = doc.getElementsByTagName("druh_suroviny");
        NodeList nk = doc.getElementsByTagName("komentar");
        NodeList na = doc.getElementsByTagName("autor");
        
        for (int i = 0;i<na.getLength();i++) {
            Element autor = (Element)na.item(i);
            id = autor.getAttribute("id");
            NodeList autorChild = autor.getChildNodes();
            for (int j = 0;j<autorChild.getLength();j++) {
                if (autorChild.item(j).getNodeName().equals("meno")) {
                    meno = autorChild.item(j).getTextContent();         
                    break;
                }
            }
            autory.put(id, meno);                      
        }
        
        for (int i = 0;i<np.getLength();i++) {
            Element product = (Element)np.item(i);
            String typserv = parent(product,"server");
            NodeList autorChild = product.getChildNodes();
            for (int j = 0;j<autorChild.getLength();j++) {
                if (autorChild.item(j).getNodeName().equals("number")) {
                    id = autorChild.item(j).getTextContent();                                                                    
                }
                if (autorChild.item(j).getNodeName().equals("name")) {
                    meno = autorChild.item(j).getTextContent();                                                                    
                }
            }
            products.put(typserv+"_"+id, meno);                      
        }
        
        part1(nk,nd,doc);
        part2(na,doc);                                                                            
        
    }
    
 
    
} 
