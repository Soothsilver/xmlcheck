/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.util.ArrayList;
import java.util.Hashtable;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * @author Kirrie
 */
public class MySaxHandler extends DefaultHandler {
    static ArrayList<recept> recepty = new ArrayList<recept>();
    static ArrayList<String> productss = new ArrayList<String>();
    static Hashtable<String,String> products = new Hashtable<String, String>();
    
    /**
     * Trieda s receptami ktore splnuju poziadavku na keyword.
     */
    class recept {
        double vyrobna = 0;
        double predajna = 0;   
        String name = "";
        String srv = "";
        ArrayList<String> suroviny = new ArrayList<String>();
        
        
        public recept(double pred) {
            this.predajna = pred;           
        }
        public void addSurov(ArrayList<String> s) {
            suroviny.addAll(s);
        }
        public void setNameSrv(String s,String srv) {
            this.name = s;
            this.srv = srv;
        }
        
        public void zistit(Hashtable<String,String> products) {                    
            for (String s : suroviny) {
                if (products.containsKey(s)) {
                vyrobna+=Double.parseDouble(products.get(s));
                }
            }
        }
    }
    
    String KEYWORD = "Tul";
    // UmoĹľĹuje zacĂ­lit mĂ­sto v dokumentu, kde vznikla aktualnĂ­ udĂˇlost
    Locator locator;
    String srv = "";
    double tempvyr = 0;
    double temppred = 0;   
    String temp = "";
    String name = "";
    
    String idnumber = "";
    String price = "";
    

        @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Obsluha udĂˇlosti "zaÄŤĂˇtek dokumentu"
     */     
        @Override
    public void startDocument() throws SAXException {
        
        // ...
        
    }
    /**
     * Obsluha udĂˇlosti "konec dokumentu"
     */     
        @Override
    public void endDocument() throws SAXException {
        
        for (recept r:recepty) {
            if (r.vyrobna>=r.predajna*0.9)   {   //predajna cena je vzdy vacsia ako vyrobna 
            System.out.println("----------------------------------------------------\n");
            System.out.println("--- meno: "+r.name+" ---\n--- server: "+r.srv);
            System.out.println("--- predajna cena: "+r.predajna+"---\n--- vyrobna cena: "+r.vyrobna);
            System.out.println("----------------------------------------------------\n");
            }
        }
        
    }
    
    /**
     * Obsluha udĂˇlosti "zaÄŤĂˇtek elementu".
     * @param uri URI jmennĂ©ho prostoru elementu (prĂˇzdnĂ©, pokud element nenĂ­ v ĹľĂˇdnĂ©m jmennĂ©m prostoru)
     * @param localName LokĂˇlnĂ­ jmĂ©no elementu (vĹľdy neprĂˇzdnĂ©)
     * @param qName KvalifikovanĂ© jmĂ©no (tj. prefix-uri + ':' + localName, pokud je element v nÄ›jakĂ©m jmennĂ©m prostoru, nebo localName, pokud element nenĂ­ v ĹľĂˇdnĂ©m jmennĂ©m prostoru)
     * @param atts Atributy elementu     
     */     
        @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {           
            String line = "";
            temp = "";
            if (qName.equalsIgnoreCase("server")) {
                srv = atts.getValue("id");
            }
            if (qName.equalsIgnoreCase("recept")) {
                line = atts.getValue("cena");
                temppred= Double.parseDouble(line.split(" ")[0]);
                name = atts.getValue("name");                                                  
            }

            if (qName.equalsIgnoreCase("druh_suroviny")) {
                productss.add(atts.getValue("number"));
            }
       
                
    }
    /**
     * Obsluha udĂˇlosti "konec elementu"
     * Parametry majĂ­ stejnĂ˝ vĂ˝znam jako u @see startElement     
     */     
        @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
            if (qName.equalsIgnoreCase("recept")) {
                if (name.matches(".*"+KEYWORD+".*")) {
                recept rec = new recept(temppred);
                rec.addSurov(productss);
                rec.setNameSrv(name, srv);
                recepty.add(rec);
                tempvyr = 0;
                temppred = 0;                
                }
                productss.clear();
            }
            
            if (qName.equalsIgnoreCase("server")) {
                
                for (recept r:recepty) {
                    if (r.srv.equals(srv))
                        r.zistit(products);
                }
                srv = "";
                products.clear();
            }
            
            if (qName.equalsIgnoreCase("number")) {
                idnumber = temp;
            }
            
            if (qName.equalsIgnoreCase("price")) {
                price = temp;
                products.put(idnumber, price);
            }
            
            if (qName.equalsIgnoreCase("product")) {
                idnumber = "";
                price = "";
            }
        // ...

    }
    
    /**
     * Obsluha udĂˇlosti "znakovĂˇ data".
     * SAX parser muÄľe znakovĂˇ data dĂˇvkovat jak chce. Nelze tedy poÄŤĂ­tat s tĂ­m, Ĺľe je celĂ˝ text dorucen v rĂˇmci jednoho volĂˇnĂ­.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakovĂ˝mi daty
     * @param start Index zacĂˇtku Ăşseku platnĂ˝ch znakovĂ˝ch dat v poli.
     * @param length DĂ©lka Ăşseku platnĂ˝ch znakovĂ˝ch dat v poli.
     */               
        @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
            temp = new String (ch,start,length);
        // ...
        
    }
    
    /**
     * Obsluha udĂˇlosti "deklarace jmennĂ©ho prostoru".
     * @param prefix Prefix prirazenĂ˝ jmennĂ©mu prostoru.
     * @param uri URI jmennĂ©ho prostoru.
     */     
        @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha udĂˇlosti "konec platnosti deklarace jmennĂ©ho prostoru".
     */     
        @Override
    public void endPrefixMapping(String prefix) throws SAXException {
    
        // ...
    
    }

    /**
     * Obsluha udĂˇlosti "ignorovanĂ© bĂ­lĂ© znaky".
     * StejnĂ© chovĂˇnĂ­ a parametry jako @see characters     
     */     
        @Override
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha udĂˇlosti "instrukce pro zpracovĂˇnĂ­".
     */         
        @Override
    public void processingInstruction(String target, String data) throws SAXException {
      
      // ...
            
    }

    /**
     * Obsluha udĂˇlosti "nezpracovanĂˇ entita"
     */         
        @Override
    public void skippedEntity(String name) throws SAXException {
    
      // ...
    
    }
}
     