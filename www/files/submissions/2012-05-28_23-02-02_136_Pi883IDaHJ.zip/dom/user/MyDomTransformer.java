package user;
import org.w3c.dom.*;

// prevod atributu na podelementy

public class MyDomTransformer
{
    public void transform (Document xmlDocument)
    {
        transformNode(xmlDocument, xmlDocument.getDocumentElement());
    }
    
    public void transformNode(Document doc, Node xmlNode)
    {
        NodeList nl = xmlNode.getChildNodes();
        for (int i = 0; i < nl.getLength(); i++)
        {
            if (nl.item(i).getNodeType() == Node.ELEMENT_NODE)
            {
                transformNode(doc, nl.item(i));
            }
        }
        
        for (int i = 0; i < nl.getLength(); i++)
        {
            if (nl.item(i).getNodeType() == Node.ATTRIBUTE_NODE)
            {
                xmlNode.appendChild(doc.createTextNode(nl.item(i).getNodeValue()));
            }
        }
    }
}