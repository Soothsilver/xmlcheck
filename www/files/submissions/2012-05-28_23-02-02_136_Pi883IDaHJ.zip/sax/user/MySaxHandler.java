package user;

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.*;
public class MySaxHandler extends DefaultHandler
{
    private int elementsN = 0;
    private int attrN = 0;
    
    @Override
    public void startElement(String uri, String local, String qualified, Attributes attributes) throws SAXException
    {
        elementsN++;
        attrN += attributes.getLength();
    }
    
    @Override
    public void endDocument() throws SAXException
    {
        System.out.println("elementu: " + elementsN);
        System.out.println("attributu: " + attrN);
    }
}