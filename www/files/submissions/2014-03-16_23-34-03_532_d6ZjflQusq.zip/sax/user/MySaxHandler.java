package user;
import org.xml.sax.helpers.*;
import org.xml.sax.*;

import java.util.*;

class MySaxHandler extends DefaultHandler {
    java.io.PrintStream out;
    Stack<String> elementStack;
    String currentPersonId;
    
    Map<String, Integer> personRefCount;
    Map<String, String> personNames;
    String longestName;
    Set<String> bossPersonRef;
    Set<String> bossNames;
    
    @Override
    public void startDocument(){
        this.out = System.out;
        personRefCount = new TreeMap<String, Integer>();
        elementStack = new Stack<String>();
        bossPersonRef = new TreeSet<String>();
        bossNames = new TreeSet<String>();
        personNames = new TreeMap<String, String>();        
    }
    @Override
    public void endDocument() {
        // nejvice zminovana osoba (na kterou je nejvice referenci)
        String id = "none";
        Integer count = 0;
        for (Map.Entry<String, Integer> personRef : personRefCount.entrySet()) {
            if (personRef.getValue() > count) {
                count = personRef.getValue();
                id = personRef.getKey();
            }
        }
        String name = personNames.get(id);
        if (name != null) {
            out.println("the most mentioned person: " + name);
        }
        else out.println("the most mentioned person: " + id + " (name unknown)");
        
        // osoba s nejdelsim jmenem
        out.println("longest personal name: " + longestName);
        
        
        // jmena osob, ktere sefuji teroristickym organizacim
        for (String personRef : bossPersonRef) {
            bossNames.add(personNames.get(personRef));
        }
        for (String bossName : bossNames) {
            out.println("boss: "+ bossName);
        }
        
    }
    
    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) {
        if ("personRef".equals(qName)) {
                // nejcasteji zminovana osoba (nebo jedna z nich)
                String ref = attributes.getValue("ref");
                Integer c = personRefCount.get(ref);
                if (c == null) {
                    personRefCount.put(ref, 1);
                }
                else {
                    personRefCount.put(ref, c + 1);
                }
                // reference na bosse
                if ("boss".equals(elementStack.peek())) bossPersonRef.add(ref);
        }
        else if ("person".equals(qName)) {
                currentPersonId = attributes.getValue("id");
        }
        elementStack.push(qName);
    }
    @Override
    public void endElement(String uri, String localName, String qName) {
        String el = elementStack.pop();
        if ("person".equals(el)) {
                currentPersonId = null;
        }
    }
    @Override
    public void characters(char[] chars, int start, int length) {
        String str = String.valueOf(chars, start, length);
        out.println(str);
        String current = elementStack.pop();
        if ("name".equals(current)) {
                String current_1 = elementStack.pop();
                if("person".equals(current_1)) {
                    if (longestName == null) {
                        longestName = str;
                    }
                    else {
                        if (longestName.length() < str.length()) longestName = str;
                    }
                    // namapuj id na jmeno
                    if (currentPersonId != null) {
                        personNames.put(currentPersonId, str);
                    }
                    // ctes-li sefa, pridej jeho jmeno
                    if ("boss".equals(elementStack.peek())) {
                        bossNames.add(str);
                    }
                };
                elementStack.push(current_1);
        }
        elementStack.push(current);
    }
}
