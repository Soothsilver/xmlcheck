/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.util.Set;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;


/**
 * Tema: Vypisu z data.xml informace a pak spocitam pocet atributy a lementy,
 * 
 * @author Tran Danh Thang
 * 
 */
public class MySaxHandler extends DefaultHandler {

    public static void main(String[] args) {
        String sourcePath = "data.xml";
        try {
            XMLReader parser = XMLReaderFactory.createXMLReader();


            InputSource source = new InputSource(sourcePath);


            parser.setContentHandler(new MujContentHandler());

            parser.parse(source);

        } catch (Exception e) {
        }
    }
}

class MujContentHandler implements ContentHandler {

    Locator locator;
    int countElements;
    int countAttributes;
    Set namesBook;
    Set countTypPub;
    int pocetFilmu;
    int podtrhnout = 0;

    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    public void startDocument() throws SAXException {
        System.out.println("--------------------------------------");
        System.out.println("----------  Knihovna  ----------------");
        System.out.println("--------------------------------------");
    }

    public void endDocument() throws SAXException {
        System.out.println("--------------------------------------");
        System.out.println("Count elements: " + countElements);
        System.out.println("Count attributes: " + countAttributes);
        System.out.println("--------------------------------------");



    }

    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        countAttributes += atts.getLength();
        countElements++;
        for (int i = 0; i < atts.getLength(); i++) {
            System.out.println(atts.getQName(i) + ": " + atts.getValue(i));
        }
    }

    public void endElement(String uri, String localName, String qName) throws SAXException {
    }

    public void characters(char[] ch, int start, int length) throws SAXException {
    }

    public void startPrefixMapping(String prefix, String uri) throws SAXException {
    }

    public void endPrefixMapping(String prefix) throws SAXException {
    }

    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
    }

    public void processingInstruction(String target, String data) throws SAXException {
    }

    public void skippedEntity(String name) throws SAXException {
    }
}