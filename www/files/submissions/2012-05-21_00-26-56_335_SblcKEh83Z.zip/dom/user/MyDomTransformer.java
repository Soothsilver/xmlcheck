/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;
/**
 * Tema: najit knihu se cenou pod 100 a zmenit na 100kc a pokud je cena vic nez 200
 * tak k te knize pridam element topKniha. Taky odstranim vsechny elementy language
 * ktery nema obsah CZECH
 *
 * @author Tran Danh Thang
 */
public class MyDomTransformer {

    private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "data.out.xml";

    public static void main(String[] args) {

        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setValidating(false);
            DocumentBuilder builder = dbf.newDocumentBuilder();
            Document doc = builder.parse(VSTUPNI_SOUBOR);
            MyDomTransformer mdt = new MyDomTransformer();
            mdt.transform(doc);
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer writer = tf.newTransformer();
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


        } catch (Exception e) {

            e.printStackTrace();

        }
    }

    public void transform(Document doc) {

        //V sekci languages odstranim vsechno krome element s obsahem CZECH
        NodeList seznamLang = doc.getElementsByTagName("language");
        for (int i = 0; i < seznamLang.getLength(); i++) {
            Element language = (Element) seznamLang.item(i);
            Node languages = language.getParentNode();
            if (!language.getTextContent().startsWith("Czech")) {
                languages.removeChild(language);
            }
        }

        // Pokud cena kniha je pod 110 tak zmenim na 100 kc
        // Pokud cena kniha je vic nez 200kc, vytvorim element TOPKNIHA
        NodeList ceny = doc.getElementsByTagName("cena");
        for (int i = 0; i < ceny.getLength(); i++) {
            Element cena = (Element) ceny.item(i);
            Element topkniha = doc.createElement("topKniha");
            topkniha.setTextContent("Ano");
            Node kniha = cena.getParentNode();    
            int cenaKniha = Integer.parseInt(cena.getTextContent());
            if (cenaKniha< 100) {
                cena.setTextContent("100");             
            }
            if(cenaKniha>200){
                kniha.appendChild(topkniha);
            }
        }

        
    }
}
