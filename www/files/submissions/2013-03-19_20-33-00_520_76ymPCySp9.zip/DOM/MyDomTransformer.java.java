﻿/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;
import java.text.Collator; //pro porovnavani ceskych znaku
import java.util.Locale;    //pro porovnavani ceskych znaku

/**
 * ASSIGNMENT: Update document to be able to transform input XML document to
 * output document by actions mentioned in comments of processTree method.
 */
public class MyDomTransformer{
/**
 * vstupem je ukazkovy soubor movies.xml
 * /
 */
    private static final String INPUT_FILE = "data.xml";
    private static final String OUTPUT_FILE = "data.out.xml";

    /**
     * Main method
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
         try {

            // DocumentBuilderFactory creates DOM parsers
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            // We don't want to validate file
            dbf.setValidating(false);

            // Creating of DOM parser instance
            DocumentBuilder builder = dbf.newDocumentBuilder();

            // Parser processes input file and creates a DOM tree of objects
            Document doc = builder.parse(INPUT_FILE);

            // DOM tree processing
            processTree(doc);

            // TransformerFactory creates an object for DOM serialization
            TransformerFactory tf = TransformerFactory.newInstance();

            // Transformer serializes DOM tree
            Transformer writer = tf.newTransformer();

            // Setting of output file encoding
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            // Run transformation of DOM tree to XML document
            writer.transform(new DOMSource(doc), new StreamResult(new File(OUTPUT_FILE)));


        } catch (Exception e) {

            e.printStackTrace();
        }
         
    }
    /**
     * Process document tree
     *
     * @param doc Document to be parsed
     */
 private static void processTree(Document doc) {
    
    //ziskame odkaz na korenovy uzel
    Element root = doc.getDocumentElement();
    /**
     * procedura pridavajici film, libovolny parametr muze
     * byt null, element se pak neprida , vzdy se prida 
     * element name
     */
    addMovie(doc,"m10","Áčkový film","Dobrodružný","110","150",
            null,"Německo","1972","Klaus von Deutschland","cs",null,null);
    addMovie(doc,"m11","Řešeto",null,"120","150",
            "12","Írán","2012","Rezá Pahlaví","per","cs","True");
    //seznam elementu pojmenovanych "movie"
    NodeList movies = root.getElementsByTagName("movie");
    /**
     * implementace QuickSortu(co, od, do)
     * setridi filmy podle jmena
     */
    QuickSort(movies,0, movies.getLength()-1);
    
} 
 //rekurzivni QuickSort: Pavel Töper, Algoritmy a programovací techniky
 //porovnani uzlu podle jmena: funkce FirstIsSmaller
 private static void QuickSort(NodeList nodes,int from, int to) {
 Node X;
 Node cloneI;
 Node cloneJ;
 int I,J;
 I = from;
 J = to;
 X = nodes.item( (from + to) / 2);
 do { 
    while (FirstIsSmaller(nodes.item(I),X))I++;
    while (FirstIsSmaller(X,nodes.item(J))) J--;
    if(I< J){
        //asi trochu nesikovne prohozeni elementu
        cloneI = nodes.item(I).cloneNode(true);
        cloneJ = nodes.item(J).cloneNode(true);
        nodes.item(I).getParentNode().replaceChild(cloneI, nodes.item(J));
        nodes.item(J).getParentNode().replaceChild(cloneJ, nodes.item(I));
        I++;
        J--;
    }
    else if(I == J){
        I++;
        J--;
    }
 } while (!(I > J));
 if(from < J)QuickSort(nodes,from,J); 
 if(I < to)QuickSort(nodes,I,to);   
 }
 //funkce na porovnani elementu podle textoveho obsahu
 private static boolean FirstIsSmaller(Node node1, Node node2){
     //procedura neni moc obecna predpoklada znamou strukturu XML dokumentu
     //vyzvedne text z obou elementu name a porovna je
     String name1;
     String name2;
     //konverze z typu Node na typ Element
     //kvuli moznosti vyvolat metodu getElementByTagName
     Element movie1 = (Element) node1;
     Element movie2 = (Element) node2;
     //sestav seynam elementu, vyzvedni nulty(prvni) prvek , jeho prvni syn je textovy
     //uzel, vem jeho hodnotu (text v elementu)
     name1 = movie1.getElementsByTagName("name").item(0).getFirstChild().getNodeValue();
     name2 = movie2.getElementsByTagName("name").item(0).getFirstChild().getNodeValue();
     //trida Collator se pouziva pro porovnavani ceskych znaku
     Collator c = Collator.getInstance(new Locale("cs", "CZ"));
     if (c.compare(name1, name2)<0) {
         return true;
     }
     else{
         return false;  
     }    
 }
 //pridani filmu jako podelementu elementu movies
 //predpoklada se konkretni struktura XML dokumentu
 private static void addMovie(Document doc,String strID,String strName,
         String strCategory, String strLength, String strPrice,String strSuitableFrom,
         String strCountry,String strYear,String strDirector,String strLanguage,
         String strSubtitles, String strIs3d){
  Element tempElement;
  //vytvor novy element, kteremu pridas podelementy a pridas ho jako
  //podelement elementu movies
  Element newMovie = doc.createElement("movie");
  if(!(strID == null))
  //nastaveni atributu elementu
  newMovie.setAttribute("id", strID);
  
  String elementName ;
  String elementValue;
  
  //nasleduje pridavani jednotlivych podelementu elementu movie
  //element name je pridan vzdy, ostatni jen kdyz je prislusny
  //vstupni parametr nenull
  elementName = "name";
  elementValue = strName;
  if((strName == null))
  elementValue = ""; 
  //prida se podelement
  newMovie.appendChild(doc.createElement(elementName));
  //odkaz na prave pridany element
  tempElement = (Element)newMovie.getElementsByTagName(elementName).item(0);
  //pridani textoveho uzlu a prislusne nastaveni jeho hodnoty
  tempElement.appendChild(doc.createTextNode(elementValue));
  
  if(!(strCategory == null)){
  elementName = "category";
  elementValue = strCategory;
  newMovie.appendChild(doc.createElement(elementName));
  tempElement = (Element)newMovie.getElementsByTagName(elementName).item(0);
  tempElement.appendChild(doc.createTextNode(elementValue));
  }
  
  if(!(strLength == null)){
  elementName = "length";
  elementValue = strLength;
  newMovie.appendChild(doc.createElement(elementName));
  tempElement = (Element)newMovie.getElementsByTagName(elementName).item(0);
  tempElement.appendChild(doc.createTextNode(elementValue));
  }
  
  if(!(strPrice == null)){
  elementName = "price";
  elementValue = strPrice;
  newMovie.appendChild(doc.createElement(elementName));
  tempElement = (Element)newMovie.getElementsByTagName(elementName).item(0);
  tempElement.appendChild(doc.createTextNode(elementValue));
  }
  
  if(!(strSuitableFrom == null)){
  elementName = "suitableFrom";
  elementValue = strSuitableFrom;
  newMovie.appendChild(doc.createElement(elementName));
  tempElement = (Element)newMovie.getElementsByTagName(elementName).item(0);
  tempElement.appendChild(doc.createTextNode(elementValue));
  }
  
  if(!(strCountry == null)){
  elementName = "country";
  elementValue = strCountry;
  newMovie.appendChild(doc.createElement(elementName));
  tempElement = (Element)newMovie.getElementsByTagName(elementName).item(0);
  tempElement.appendChild(doc.createTextNode(elementValue));
  }
  
  if(!(strYear == null)){
  elementName = "year";
  elementValue = strYear;
  newMovie.appendChild(doc.createElement(elementName));
  tempElement = (Element)newMovie.getElementsByTagName(elementName).item(0);
  tempElement.appendChild(doc.createTextNode(elementValue));
  }
  
  if(!(strDirector == null)){
  elementName = "director";
  elementValue = strDirector;
  newMovie.appendChild(doc.createElement(elementName));
  tempElement = (Element)newMovie.getElementsByTagName(elementName).item(0);
  tempElement.appendChild(doc.createTextNode(elementValue));
  }
  
  if(!(strLanguage == null)){
  elementName = "language";
  elementValue = strLanguage;
  newMovie.appendChild(doc.createElement(elementName));
  tempElement = (Element)newMovie.getElementsByTagName(elementName).item(0);
  tempElement.appendChild(doc.createTextNode(elementValue));
  }
  
  if(!(strSubtitles == null)){
  elementName = "subtitles";
  elementValue = strSubtitles;
  newMovie.appendChild(doc.createElement(elementName));
  tempElement = (Element)newMovie.getElementsByTagName(elementName).item(0);
  tempElement.appendChild(doc.createTextNode(elementValue));
  }
  
  if(!(strIs3d == null)){
  elementName = "is3d";
  elementValue = strIs3d;
  newMovie.appendChild(doc.createElement(elementName));
  tempElement = (Element)newMovie.getElementsByTagName(elementName).item(0);
  tempElement.appendChild(doc.createTextNode(elementValue));
  }
  //pridani nove vytvoreneho elementu movie jako podelementu elementu movies
  Element rootElement = doc.getDocumentElement();
  Node movies = rootElement.getElementsByTagName("movies").item(0);
  if(!(movies == null)){
      movies.appendChild(newMovie);
  }
 }

}
