package user;

/*
 * Převede všechny atributy elementů na jejich přímé podelementy.
 *
 * Václav Brodec - cvičení Technologie XML (6. úkol)
 */

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Attr;
import org.w3c.dom.NamedNodeMap;

public class MyDomTransformer {
  /*
   * Vlastní rekurzivní průchod spojený s převodem atributů na podelementy.
   */

  private void preved(NodeList seznamUzlu, Document doc) {
    for (int i = 0; i < seznamUzlu.getLength(); i++) {
      Node uzel = seznamUzlu.item(i);

      NamedNodeMap atributy = uzel.getAttributes();

      if (atributy != null) { // Pokud nejsou atributy null, víme, že jde o element.
        Element rodic = (Element) uzel;

        while (atributy.getLength() > 0) { // Postupně užíráme atributy.
          Attr atribut = (Attr) atributy.item(0);

          Element prevedenyAtribut = doc.createElementNS(atribut.getNamespaceURI(), atribut.getName());
          prevedenyAtribut.appendChild(doc.createTextNode(atribut.getValue()));

          rodic.insertBefore(prevedenyAtribut, rodic.getFirstChild()); // Zařadíme na začátek.
          rodic.removeAttributeNode(atribut); // Pokud by se validovalo, mohlo by selhat na povinném atributu.

          atributy = rodic.getAttributes();
        }
      }

      NodeList seznamSynu = uzel.getChildNodes();
      preved(seznamSynu, doc);
    }
  }

  public void transform (Document xmlDocument) {
    // libovolne transformace objektu 'xmlDocument'
    // (metoda pracuje primo na objektu, nic nevraci)
	
	Element root = xmlDocument.getDocumentElement();

    preved(root.getChildNodes(), xmlDocument); // Vlastní převod.
  }
}
