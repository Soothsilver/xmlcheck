package user;

/*
 * Spocita prumerny pocet atributu pro kazdy typ elementu zvlast i celkove.
 *
 * Vaclav Brodec - cviceni Technologie XML (6. ukol)
 */

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

public class MySaxHandler extends DefaultHandler {

  private class ZaznamElementu {

    private int pocetVyskytu = 0;
    private int pocetZaznamenanychAtributu = 0;

    private float prumer() {
      return (float) this.pocetZaznamenanychAtributu / (float) pocetVyskytu;
    }
  }
  private Map<String, ZaznamElementu> udajeOElementech = new HashMap<String, ZaznamElementu>();

  /**
   * zacatek elementu
   */
  public void startElement(String namespaceURI, String localName, String qName, Attributes atts) throws SAXException {
    ZaznamElementu aktualniZaznam;

    if (!udajeOElementech.containsKey(qName)) {
      aktualniZaznam = new ZaznamElementu();
    } else {
      aktualniZaznam = udajeOElementech.get(qName);
    }

    aktualniZaznam.pocetVyskytu++;
    aktualniZaznam.pocetZaznamenanychAtributu += atts.getLength();

    udajeOElementech.put(qName, aktualniZaznam);
  }

  /**
   * konec dokumentu
   */
  public void endDocument() throws SAXException {
    int celkovyPocetElementu = 0;
    int celkovyPocetAtributu = 0;

    for (Entry<String, ZaznamElementu> elementData : udajeOElementech.entrySet()) {
      String jmeno = elementData.getKey();
      ZaznamElementu hodnota = elementData.getValue();

      System.out.print("Prumerny pocet atributu elementu " + jmeno + ": ");
      System.out.println(hodnota.prumer());
      celkovyPocetElementu += hodnota.pocetVyskytu;
      celkovyPocetAtributu += hodnota.pocetZaznamenanychAtributu;
    }

    System.out.print("Prumerny pocet atributu bez ohledu na nazev elementu: ");
    System.out.println((float) celkovyPocetAtributu / (float) celkovyPocetElementu);
  }
}