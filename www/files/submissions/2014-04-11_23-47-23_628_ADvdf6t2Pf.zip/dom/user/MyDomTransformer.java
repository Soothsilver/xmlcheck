package user;
import java.util.HashSet;

import org.w3c.dom.*;

public class MyDomTransformer {
	public void transform(Document doc){
		//pridej noveho autora
		Element newAuthor = doc.createElement("Autor");
		newAuthor.setAttribute("Id",findUnusedBookId(doc));
		newAuthor.setAttribute("DatumNarozeni", "24-08-1977");
		Element jmenoAutora = doc.createElement("JmenoAutora");
		jmenoAutora.setTextContent("John Green");
		newAuthor.appendChild(jmenoAutora);
		doc.getElementsByTagName("Autori").item(0).appendChild(newAuthor);
		
		//smaz vsechny svazky pujcene vicekrat nez 200x
		NodeList svazky = doc.getElementsByTagName("InstanceKnihy");
		Element svazkyElement = (Element)doc.getElementsByTagName("Svazky").item(0);
		for(int i = 0; i < svazky.getLength(); i++)
		{
			Element svazek = (Element)svazky.item(i);
			Element kolikratVypujceno = (Element)(svazek.getElementsByTagName("KolikratVypujceno").item(0));
			String kolikratVypujcenoString = kolikratVypujceno.getTextContent().replaceFirst("^\\s*", "").replaceFirst("\\s*$", "");			
			if(Integer.parseInt(kolikratVypujcenoString) > 200)
			{
				svazkyElement.removeChild(svazek);
			}
		}	
		
	}
	private String findUnusedBookId(Document d)
	{
		NodeList svz = d.getElementsByTagName("Autor");
		HashSet<String> usedIds = new HashSet<String>();
		for(int i = 0; i < svz.getLength(); i++)
		{
			usedIds.add(((Element)svz.item(i)).getAttribute("Id"));
		}
		int toTry = 1;
		String stringToTry = "";
		do
		{
			stringToTry = "A" + toTry;
			toTry++;
		}
		while(usedIds.contains(stringToTry));
		return stringToTry;
	}
}
