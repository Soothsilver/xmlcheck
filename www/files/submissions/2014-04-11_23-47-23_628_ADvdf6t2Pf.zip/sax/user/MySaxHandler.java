package user;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.*;
import java.util.*;

public class MySaxHandler extends DefaultHandler {
	private HashMap<String,Integer> authorToBookCount = new HashMap<String,Integer>();//id autora -> pocet titulu
	private HashMap<String,String> authorToName = new HashMap<String,String>(); //id autora -> jmeno autora
	private HashSet<String> authorsAlive = new HashSet<String>();
	private HashMap<String,String> bookToName = new HashMap<String,String>();
	private HashMap<String,Integer> bookToYear = new HashMap<String,Integer>();
	private HashMap<String,String> bookToAuthor = new HashMap<String,String>();
	private String currentAuthor = "";
	private String currentReading = "";
	private String currentBook = "";
	private Reading reading = null;
	private enum Reading
	{
		AUTHOR_NAME, BOOK_NAME, BOOK_YEAR;
	}
	/*
	 * Program pri behu sax parseru uklada vybrana data do slovniku atd.
	 * Na jejich ziskani po skonceni cteni xml souboru slouzi metody:
	 * 		getAuthorWithMostTitles()
	 * 			vrati autora s nejvetsim poctem titulu v knihovne, pokud je jich vice se stejnym poctem titulu, seradi je podle jmena a vrati prvniho
	 * 		getThisMilleniumBooks()
	 * 			vrati knihy vydane v roce 2000 a pozdeji
	 * 		getLivingAuthorsWithNoBookInstances()
	 * 			vrati zijici autory, od kterych knihovna nenabizi zadne jejich svazky
	 * 	 
	 */
	public String getAuthorWithMostTitles()
	{		
		List<String> l = new ArrayList<String>();
		int bestCount = 0;
		for(String authorid : authorToBookCount.keySet())
		{
			if(authorToBookCount.get(authorid) > bestCount)
			{
				l.clear();
				l.add(authorid);
				bestCount = authorToBookCount.get(authorid);
			}
			if(authorToBookCount.get(authorid) == bestCount)
			{
				l.add(authorid);
			}
		}
		if(l.size() == 0)
		{
			return null;
		}
		Collections.sort(l);
		return authorToName.get(l.get(0));
	}
	public List<String> getThisMilleniumBooks()
	{
		ArrayList<String> noveKnihy = new ArrayList<String>();
		for(String idKnihy : bookToYear.keySet())
		{
			if(bookToYear.get(idKnihy) >= 2000)
			{
				noveKnihy.add(bookToName.get(idKnihy));
			}
		}
		return noveKnihy;
	}
	public List<String> getLivingAuthorsWithNoBookInstances()
	{
		List<String> l = new ArrayList<String>();
		for(String id : this.authorsAlive)
		{
			l.add(authorToName.get(id));
		}
		return l;
	}
	
	private void endReading()//pokud byl program ve stavu kdy cekal nejaky text, zajisti jeho precteni ze zasobniku (currentReading) a ulozeni na prislusne misto
	{		
		if(reading != null && currentReading.length() > 0)
		{
			currentReading = currentReading.replaceFirst("^\\s*", "");
			currentReading = currentReading.replaceFirst("\\s*$", "");
			switch(reading)
			{
			case AUTHOR_NAME:
				authorToName.put(currentAuthor, currentReading);
				break;
			case BOOK_NAME:				
				bookToName.put(currentBook, currentReading);
				break;
			case BOOK_YEAR:
				int titleYear = Integer.parseInt(currentReading);
				bookToYear.put(currentBook, titleYear);
				break;
			}
		}
		currentReading = "";
		reading = null;
	}
	public void characters(char[] chs, int start, int length)
	{
		for(int i = start; i < start + length; i++)
		{
			currentReading += chs[i];
		}
	}
	public void endElement(String uri, String localName, String qName)
	{
		endReading();
	}
	public void startElement(String uri, String localName, String qName, Attributes atts)
	{
		endReading();
		if(qName.equals("Autor")){
			currentAuthor = atts.getValue("Id");
			authorToBookCount.put(currentAuthor,0);
			if(atts.getValue("DatumUmrti") == null)
			{
				authorsAlive.add(currentAuthor);
			}
		}else if(qName.equals("JmenoAutora")){
			reading = Reading.AUTHOR_NAME;
		}else if(qName.equals("Kniha")){
			String authorId = atts.getValue("Autor");
			authorToBookCount.put(authorId,authorToBookCount.get(authorId)+1);
			this.currentBook = atts.getValue("Id");
		}else if(qName.equals("NazevKnihy")){
			reading = Reading.BOOK_NAME;
		}else if(qName.equals("RokVydani")){
			reading = Reading.BOOK_YEAR;
		}else if(qName.equals("InstanceKnihy")){
			this.authorsAlive.remove(this.bookToAuthor.get(atts.getValue("Kniha")));			
		}		
	}
	public void endDocument()
	{
		endReading();
	}
}
