
package user;
import java.io.File;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

/**
 * ZADANI:
 * Upravte program tak, aby transformoval vstupní XML dokument na výstupní pomocí akcí
 * uvedených v komentářích metody processTree(doc).
 */
public class MyDomTransformer {

    private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "data.out.xml";
    

    /**
     * Zpracuje DOM strom, najde aliance a v kazde obrati poradi gubernatoru
     */
    private void transform(Document doc) {
        NodeList aliance =doc.getElementsByTagName("aliance");
        for (int i = 0; i < aliance.getLength(); i++) {
            Node ali = aliance.item(i);
            reverseOrderInAliance(ali);
        }
        
    }

     /**
     * V alianci obrati poradi gubernatoru pouzitim zasobniku.
      * Nejdrive vsechny gubernatory da pryc a pak je opacne vklada
     */
    private static void reverseOrderInAliance(Node aliance){
        if (aliance==null) return;
        if (aliance.getChildNodes().getLength()>0) {
            ArrayList<Node> zasobnikGubernatu = new ArrayList<Node>();
            for (int i = 0; i < aliance.getChildNodes().getLength(); i++) {
                Node item = aliance.getChildNodes().item(i);
                if(item==null) continue;
                if(item.getNodeName().equals("gubernator")){
                    zasobnikGubernatu.add(aliance.removeChild(item));
                }

            }
            while (zasobnikGubernatu.isEmpty()==false) {
                int count = zasobnikGubernatu.size();
                aliance.appendChild(zasobnikGubernatu.remove(count-1));
            }
        }
    }
}
