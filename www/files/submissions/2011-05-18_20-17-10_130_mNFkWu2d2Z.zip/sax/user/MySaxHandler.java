package user;



import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;


/**
 * Náš vlastní content handler pro obsluhu SAX událostí.
 * Implementuje metody interface ContentHandler. 
 */ 
class MySaxHandler extends DefaultHandler {

    // Umožňuje zacílit místo v dokumentu, kde vznikla aktualní událost
    Locator locator;
    
    /**
     * Nastaví locator
     */
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Obsluha události "začátek dokumentu"
     */
    int pocetGubernatu =0, maxSila=0, minSila=Integer.MAX_VALUE, soucetSil = 0;
    boolean vGubernatu = false;
    boolean vSileGubernatu = false;
    @Override
    public void startDocument() throws SAXException {
        
        // ...
        
    }
    /**
     * Vypise ziskane vysledky
     */
    @Override
    public void endDocument() throws SAXException {
        int prumernaSila = soucetSil/pocetGubernatu;
        System.out.println("Prumerna sila je "+ prumernaSila);
        System.out.println("Maximalni sila je "+ minSila);
        System.out.println("Minimalni sila je "+ maxSila);
        // ...
        
    }
    
    /**
     * Obsluha události "začátek elementu".
     * @param uri URI jmenného prostoru elementu (prázdné, pokud element není v žádném jmenném prostoru)
     * @param localName Lokální jméno elementu (vždy neprázdné)
     * @param qName Kvalifikované jméno (tj. prefix-uri + ':' + localName, pokud je element v nějakém jmenném prostoru, nebo localName, pokud element není v žádném jmenném prostoru)
     * @param atts Atributy elementu     
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        // ...
        if (qName.equals("gubernator")) {
            vGubernatu=true;
        }
        if (vGubernatu && qName.equals("sila")) {
            vSileGubernatu=true;
        }
        //detekuji, zda budu cist spravna textova data, tj pokud jsem v sile
        // a predtim jsem byl v gubernatu


    }
    /**
     * Obsluha události "konec elementu"
     * Parametry mají stejný význam jako u @see startElement     
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {

        // ...
         if (qName.equals("gubernator")) {
            vGubernatu=false;
        }
        if (vGubernatu && qName.equals("sila")) {
            vSileGubernatu=false;
        }

    }
    
    /**
     * Obsluha události "znaková data".
     * SAX parser muľe znaková data dávkovat jak chce. Nelze tedy počítat s tím, že je celý text dorucen v rámci jednoho volání.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakovými daty
     * @param start Index zacátku úseku platných znakových dat v poli.
     * @param length Délka úseku platných znakových dat v poli.
     */
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        //ziskam ze stringu cislo -hledanou silu - a zpracuji
        if (vSileGubernatu) {
            String text = new String(ch,start,length);
            Integer sila = Integer.parseInt(text);
            if(sila>maxSila) maxSila=sila;
            if(sila<minSila) minSila=sila;
            pocetGubernatu++;
            soucetSil+=sila;
        }
               
    }
    
    /**
     * Obsluha události "deklarace jmenného prostoru".
     * @param prefix Prefix prirazený jmennému prostoru.
     * @param uri URI jmenného prostoru.
     */
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha události "konec platnosti deklarace jmenného prostoru".
     */
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
    
        // ...
    
    }

    /**
     * Obsluha události "ignorované bílé znaky".
     * Stejné chování a parametry jako @see characters     
     */
    @Override
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha události "instrukce pro zpracování".
     */
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
      
      // ...
            
    }

    /**
     * Obsluha události "nezpracovaná entita"
     */
    @Override
    public void skippedEntity(String name) throws SAXException {
    
      // ...
    
    }
}