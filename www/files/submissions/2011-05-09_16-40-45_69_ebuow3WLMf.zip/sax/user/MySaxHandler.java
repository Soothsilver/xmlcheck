package user;

import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;

import org.xml.sax.helpers.DefaultHandler;

/*
 * Counts:
 * 		number of elements
 * 		number of attributes
 * 		ratio of elements with attributes
 * 		average length of attributes (in characters)
 */

public class MySaxHandler extends DefaultHandler {
	int numOfElements = 0, numOfAttributes = 0, numOfChars = 0, elementsWithAttr = 0;
	
	
	@Override
	public void characters(char[] ch, int start, int length)
			throws SAXException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void endDocument() throws SAXException {
		System.out.println("Number of elements : " + numOfElements);
		System.out.println("Number of attributes : " + numOfAttributes);
		
		/*
		 * round the percent of elements with attributes to 1 decimal place
		 */
		double ratio = (double)elementsWithAttr/numOfElements * 1000;
		ratio = Math.round(ratio);
		ratio /= 10;
		
		System.out.println(ratio + "% of elements has attributes");
		
		/*
		 * round the average length of attributes to 1 decimal place
		 */
		double chars = (double)numOfChars/numOfAttributes * 10;
		chars = Math.round(chars);
		chars /= 10;
		
		System.out.println(	"Average length of attributes : " +
							chars +
							" characters");
		
	}

	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void endPrefixMapping(String prefix) throws SAXException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void ignorableWhitespace(char[] ch, int start, int length)
			throws SAXException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void processingInstruction(String target, String data)
			throws SAXException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setDocumentLocator(Locator locator) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void skippedEntity(String name) throws SAXException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void startDocument() throws SAXException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes atts) throws SAXException {
	/*
	 * counts elements, attributes and their length
	 */
		++numOfElements;
		if (atts.getLength() != 0)
			++elementsWithAttr;
		numOfAttributes += atts.getLength();
		for(int i = 0; i < atts.getLength(); ++i) {
			numOfChars += atts.getValue(i).length();
		}
	
	}

	@Override
	public void startPrefixMapping(String prefix, String uri)
			throws SAXException {
		// TODO Auto-generated method stub
		
	}
		
}
