package user;

import org.w3c.dom.*;

/*
 * This DOM parser transforms all attributes into empty child
 * nodes with one attribute (name : "value", value is the former
 * attribute's value)
 */
public class MyDomTransformer {
	//List of namespaces whiches member attributes should not be flattened
	static String[] protectedNamespaces = {"xmlns","xsi"};
	//List of attribute's names which should not be flattened
	static String[] protectedNames = {"id"};
	
	
	// checks if the attribute's name is protected (not to be flattened)
	private static boolean isProtected(String ns) {
			for (String pns : protectedNamespaces) {
				if (ns.startsWith(pns + ":"))
					return true;
			}
			
			for (String pns : protectedNames) {
				if (ns.equals(pns))
					return true;
			}
		return false;
	}

	public void transform (Document doc) {
		Node root = doc.getDocumentElement();
		flattenNode(doc,root);
	}
	
	//flatten the unprotected attributes
	private static void flattenNode(Document doc, Node node) {
		
		NamedNodeMap atts = node.getAttributes();
		Node firstNode = node.getFirstChild();
		int numOfAt = 0;
		
		if (atts != null) { // if it has attributes flatten them
			numOfAt = atts.getLength();
			for (int i = 0; i < numOfAt; ++i) {
				String name = atts.item(i).getNodeName();
				if (isProtected(name)) // if it is protected skip it
					continue;
				String value = atts.item(i).getNodeValue();
				Element newNode = doc.createElement(name); // new child element
				newNode.setAttribute("value", value); // give it a attribute
				
				// insert child at the beggining of child nodes
				node.insertBefore(newNode, firstNode);
			}
			
			int index = 0;
			while (atts.getLength() > index) { // deletes the original attributes
				String name = atts.item(index).getNodeName();
				if (isProtected(name)) { // if it is protected skip it
					++index;
					continue;
				}
			    // delete the unprotected attribute
				atts.removeNamedItem(atts.item(index).getNodeName());
			}
		}
		
		NodeList children = node.getChildNodes();
		
		if (children != null) { // if it has children recursively flatten them
			for (int i = numOfAt; i < children.getLength(); ++i) {
				flattenNode(doc, children.item(i));
			}
		}
	}

}