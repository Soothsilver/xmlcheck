package user;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
public class MyDomTransformer {
public void transform (Document xmlDocument) {
    NodeList El = xmlDocument.getElementsByTagName("*");

    // Smrsteni vice elementu do jednoho.
    
    for (int i = 0; i < El.getLength();i++){
    	Node uzel = El.item(i);
    	if (uzel.hasAttributes()){
    		NamedNodeMap atributy = uzel.getAttributes();
    		String newAttrValue = ""; // sem hromadim atributy 
    		
    		//dokud jsou atributy, vyberu atribut, poznamenam jmeno hodnotu, odstranim ho.
    		while (atributy.getLength() > 0){
    			Node atribut = atributy.item(0);
    			String Name = atribut.getNodeName();
    			String Value = atribut.getNodeValue();
    			newAttrValue+= Name + ":" + Value + "; ";
    			atributy.removeNamedItem(Name);
    		}
    		
    		// vytvorim novy atribut s hodnoutou vsech predchozich.
    		Node newAttr =	xmlDocument.createAttribute("attrib");
    		newAttr.setNodeValue(newAttrValue);
    		atributy.setNamedItem(newAttr);
    	
    	}
    	        	
    }
    
	 	// usporadani potomku podle abecedy
    
    for (int i = 0; i < El.getLength();i++){
    	Element uzel = (Element)El.item(i);
    	
    	// v n pruchodech vybere nejmensi string, a zaradi na konec, v dalsi iteraci 
    	// pri vybirani zanedba prvky, ktere uz byli pridany na konec.
    	// n je pocet Nodu. 
    	
    	
    	if (uzel.hasChildNodes()){
    		NodeList uzelPots = uzel.getChildNodes(); 

    		// Test zda li je uzel s smisenym obsahem
    		Boolean doSort=true;
    		for (int j = 0; j < uzelPots.getLength();j++){
    			//pokud je uzel textovy	
    			if (uzelPots.item(j).getNodeName().equals("#text")) {
    				
    				if (!uzelPots.item(j).getNodeName().trim().equals("")){
    					//prazdny text, pokracuji
    					continue;
    				} else {
    					// uzel je textovy ale neprazdny obsah. NETRIDIM
    					doSort = false;
    					break;
    				}
    			}
    		}
    		// Netridim, tak preskakuji na dalsi Uzel
    		if (!doSort){continue;}
    		        		
    		// cnt udava kolik prvku uz je na konci seznamu zatrizeno
    		for (int cnt = 0; cnt < uzelPots.getLength();cnt++){
    			
    			// vybiram minimalni uzel.
    			Node minNode = null;
    			for (int j = 0 ; j < uzelPots.getLength()-cnt;j++){
    				Node actNode = uzelPots.item(j);
    				String actNodeName = actNode.getNodeName();	
    				
    				// doposud nemam minimum, tak za nej vezmu prvni uzel, nebo jdu na dalsi iteraci
    				if (minNode == null){
    					if (!actNodeName.equals("#text")){ // je element.. 
    						minNode = uzelPots.item(j);
    					} else {
    						continue;
    					}
    				}
    				
 					String minNodeName = minNode.getNodeName();
 					// Neni li text, a min je vetsi nez actNode, 
   					if (!actNodeName.equals("#text") && (minNodeName.compareTo(actNodeName) > 0)){
   						minNode = actNode;
   					}
    			}
    			// odstranim uzel a pridam ho na konec seznamu
    			if (minNode != null){
    				uzel.removeChild(minNode);
    				uzel.appendChild(minNode);
    			}

    		}
    		

    	}
	 
	 	}
    
	
	}
}