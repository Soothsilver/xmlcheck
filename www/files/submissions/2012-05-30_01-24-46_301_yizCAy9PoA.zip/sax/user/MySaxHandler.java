package user;
import java.util.Vector;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
  // override metod DefaultHandleru
	
	int actDepth = 0;
	int elementCount = 0; // pocet elementu bez atributu
	int atributeCount = 0;// pocet atributu
	int elementAtrCount = 0; // pocet elementu s atributy
	
	Vector<Integer> vector = new Vector<Integer>();
	

    /**
     * Obsluha ud�losti "konec dokumentu"
     */     
    public void endDocument() throws SAXException {
        
    	System.out.println("Pocet elementu (bez atributu): " + elementCount );
    	System.out.println("Pocet atributu: " + atributeCount );
    	System.out.println("Pocet elementu s atributy: " + elementAtrCount );
    	System.out.println();
    	
    	System.out.println("Po�et elementu v jednotlivych urovnich:");
    	for (int i =0 ; i < vector.size();i++){
        	int x = vector.get(i);
        	System.out.println("Uroven " + i + ": " + x);
        	
    	}
        
    }
    
    /**
     * Obsluha ud�losti "za��tek elementu".
     * @param uri URI jmenn�ho prostoru elementu (pr�zdn�, pokud element nen� v ��dn�m jmenn�m prostoru)
     * @param localName Lok�ln� jm�no elementu (v�dy nepr�zdn�)
     * @param qName Kvalifikovan� jm�no (tj. prefix-uri + ':' + localName, pokud je element v n�jak�m jmenn�m prostoru, nebo localName, pokud element nen� v ��dn�m jmenn�m prostoru)
     * @param atts Atributy elementu     
     */     
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
    		
    		// pocitam elementy v dane hloubce 
    		if (actDepth >= vector.size()){
    			vector.add(1);
    		} else {
    			vector.set(actDepth, vector.get(actDepth)+1);
    		}
    		actDepth++;
    		
    		// pocitam typy tributu
    		if (atts.getLength() > 0)
    		{
    			elementAtrCount++; // 
    			atributeCount = atributeCount + atts.getLength();
    			
    		} else {
    			elementCount++;
    		
    		}
    }
    
    
    /**
     * Obsluha ud�losti "konec elementu"
     * Parametry maj� stejn� v�znam jako u @see startElement     
     */     
    public void endElement(String uri, String localName, String qName) throws SAXException {
    	actDepth--;
    }
                 

    
   






       


        

	
	
}