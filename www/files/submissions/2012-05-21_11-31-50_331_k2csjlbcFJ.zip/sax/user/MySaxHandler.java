package user;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {

    int numElements = 0;
    int numAttributes = 0;
    int level = 0;
    int maxDepth = 0;
    int minDepth = 1000;
    int averageDepth = 0;
    Map<String, Integer> attributes;
    Map<String, Integer> elements;
    ArrayList<String> names;

    /**
     * konstruktor tridy sax (parser musi byt objekt)
     */
    public MySaxHandler() {
        try {
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    public void showEvent(String s) {
        System.out.println("showevent: " + s);
    }

    /**
     * zacatek xml documentu
     *
     * @throws org.xml.sax.SAXException chyba rozhrani sax
     */
    public void startDocument() throws SAXException {
        attributes = new HashMap<String, Integer>();
        elements = new HashMap<String, Integer>();
        names = new ArrayList<String>();
    }

    /**
     * zacatek elementu
     */
    @Override
    public void startElement(String namespaceURI, String localName, String qName, Attributes atts) throws SAXException {
        numElements++;
        level++;
        numAttributes += atts.getLength();
        Integer count = 0;
        String aName = "";
        for (int i = 0; i < atts.getLength(); i++) {
            aName = atts.getLocalName(i);
            count = attributes.get(atts.getLocalName(i));
            if (count == null) {
                count = 0;
            }
            count++;
            attributes.put(aName, count);
        }

        count = elements.get(qName);
        if (count == null) {
            count = 0;
        }
        count++;
        elements.put(qName, count);

        names.add(qName);
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (level > maxDepth) {
            maxDepth = level;
        }
        if (level < minDepth) {
            minDepth = level;
        }
        averageDepth += level;
        level--;
    }

    /**
     * konec dokumentu
     */
    @Override
    public void endDocument() throws SAXException {
        Integer maxCount = 0;
        String attrib = "";
        String elem = "";
        Integer maxElemCount = 0;
        Integer count = 0;
        String longestAttr = "";
        String shortestAttr = "";
        int averageAttr = 0;
        for (String key : attributes.keySet()) {
            averageAttr += key.length();
            if (shortestAttr.length() == 0) {
                shortestAttr = key;
            }
            if (shortestAttr.length() > key.length()) {
                shortestAttr = key;
            }
            if (longestAttr.length() < key.length()) {
                longestAttr = key;
            }
            count = attributes.get(key);
            if (count > maxCount) {
                attrib = key;
                maxCount = count;
            }
        }

        for (String key : elements.keySet()) {
            count = elements.get(key);
            if (count > maxElemCount) {
                elem = key;
                maxElemCount = count;
            }
        }
        averageAttr = averageAttr / attributes.size();

        String longestName = "";
        String shortestName = names.get(0);
        int averageName = 0;
        for (int i = 0; i < names.size(); i++) {
            averageName += names.get(i).length();
            if (names.get(i).length() > longestName.length()) {
                longestName = names.get(i);
            }
            if (names.get(i).length() < shortestName.length()) {
                shortestName = names.get(i);
            }
        }
        averageName = averageName / names.size();
        averageDepth = averageDepth / numElements;

        System.out.println("Statistika XML dokumentu: ");
        System.out.println("Maximalni hloubka dokumentu je: " + maxDepth);
        System.out.println("Minimalni hloubka dokumentu je: " + minDepth);
        System.out.println("Prumerna hloubka dokumentu je: " + averageDepth);
        System.out.println("");
        System.out.println("Pocet elementu: " + numElements);
        System.out.println("Pocet ruznych elementu: " + elements.size());
        System.out.println("Nejcastejsi nazev elementu je '" + elem + "', ktery se v dokumentu vyskytuje " + maxElemCount + "x");
        System.out.println("Nejdelsi nazev elementu: " + longestName);
        System.out.println("Nejkratsi nazev elementu: " + shortestName);
        System.out.println("Prumerna delka nazvu elementu: " + averageName);
        System.out.println("");
        System.out.println("Pocet attributu: " + numAttributes);
        System.out.println("Pocet ruznych attributu: " + attributes.size());
        System.out.println("Nejcastejsi nazev attributu je '" + attrib + "', ktery se v dokumentu vyskytuje " + maxCount + "x");
        System.out.println("Nejdelsi nazev atributu: " + longestAttr);
        System.out.println("Nejkratsi nazev atributu: " + shortestAttr);
        System.out.println("Prumerna delka nazvu atributu: " + averageAttr);
        System.out.println("");
    }

    /**
     * chyba
     */
    @Override
    public void error(SAXParseException e) {
        System.out.println("SAXParseException: error");
        e.printStackTrace();
    }

    /**
     * varovani
     */
    @Override
    public void warning(SAXParseException e) {
        System.out.println("SAXParseException: warning");
        e.printStackTrace();
    }

    /**
     * selhani
     */
    @Override
    public void fatalError(SAXParseException e) {
        System.out.println("SAXParseException: fatal error");
        System.exit(1);
    }
}

//public class MySaxHandler {
//
//    /**
//     * main funkce
//     */
//    public static void main(String[] args) {
//
//        String filename = "data.xml";
//
//        try {
//            SAXParserFactory spfactory = SAXParserFactory.newInstance();
//            spfactory.setValidating(false);
//
//            SAXParser saxparser = spfactory.newSAXParser();
//
//            XMLReader xmlreader = saxparser.getXMLReader();
//
//            xmlreader.setContentHandler(new MyHandler());
//            xmlreader.setErrorHandler(new MyHandler());
//
//            InputSource source = new InputSource(filename);
//            xmlreader.parse(source);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//}
