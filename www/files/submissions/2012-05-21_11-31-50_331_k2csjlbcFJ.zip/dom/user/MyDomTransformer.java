package user;

import org.w3c.dom.*;

public class MyDomTransformer {

    private static void csfdTransform(Node csfd, Document doc) {

        //      textovy obsah nodu csfd presune do nove vytvoreneho elementu link
        String web = csfd.getFirstChild().getTextContent();
        Element eWeb = doc.createElement("link");
        Text eWebText = doc.createTextNode(web);
        eWeb.appendChild(eWebText);
        //    textovy obsah elementu csfd se odstrani
        csfd.removeChild(csfd.getFirstChild());
        //   nove vytvoreny element se vlozi jako prvni potomek elementu csfd
        csfd.insertBefore(eWeb, csfd.getFirstChild());

        //      z textoveho obsahu elementu rating odstrani znak procent
        String rating = csfd.getFirstChild().getTextContent().replace("%", "");
        csfd.getFirstChild().setTextContent(rating);
    }

    public void transform(Document doc) {
        NodeList csfd = doc.getElementsByTagName("csfd");
        for (int i = 0; i < csfd.getLength(); i++) {
            csfdTransform(csfd.item(i), doc);
        }

        //  zmeni hodnotu atributu lang na velka pismena (atribut lang se nachazi v ruznych elementech)
        changeAttrValue(doc);

//         vsechny elementy channel presune do nadrazeneho elementu channels a 
//        vsechny elementy programme presune do jednoho elementu allProgrammes
        Element echannels = doc.createElement("channels");
        NodeList channels = doc.getElementsByTagName("channel");
        for (int i = 0; i < channels.getLength(); i++) {
            echannels.appendChild(channels.item(i));
        }
        Element eAllProgrammes = doc.createElement("allProgrammes");
        NodeList programmes = doc.getElementsByTagName("programme");
        for (int i = 0; i < programmes.getLength(); i++) {
            eAllProgrammes.appendChild(programmes.item(i));
        }
        doc.removeChild(doc.getDocumentElement());
        doc.appendChild(doc.createElement("tv"));
        Element root = doc.getDocumentElement();
        root.appendChild(echannels);
        root.appendChild(eAllProgrammes);

    }

    //  rekurzivne prochazi celym stromem a hleda atribut lang, jehoz hodnotu zmeni na velka pismena
    public static void changeAttrValue(Node node) {
        if (node.getFirstChild() != null) {
            changeAttrValue(node.getFirstChild());
        }
        if (node.getNextSibling() != null) {
            changeAttrValue(node.getNextSibling());
        }
        if (node.hasAttributes()) {
            NamedNodeMap attr = node.getAttributes();
            for (int j = 0; j < attr.getLength(); j++) {
                if (attr.item(j).getNodeName().equals("lang")) {
                    attr.item(j).setNodeValue(attr.item(j).getNodeValue().toUpperCase());
                }
            }
        }
    }
}
/**
 * @param args the command line arguments
 */
//    public static void main(String[] args) {
//
//        String filename = "data.xml";
//        String outfile = "data.out.xml";
//
//        try {
//
//            //DocumentBuilderFactory vytvori DOM parsery
//            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
//
//            //vypne validaci
//            dbf.setValidating(false);
//
//            //vytvori si DOM parser
//            DocumentBuilder builder = dbf.newDocumentBuilder();
//
//            //parser zpracuje vstupni soubor a vytvori z nej strom DOM objektu           
//            Document doc = builder.parse(filename);
//
//            //zpracuje DOM strom
//            transform(doc);
//
//            TransformerFactory tf = TransformerFactory.newInstance();
//
//            //Transformer serializuje DOM stromy
//            Transformer writer = tf.newTransformer();
//
//            //nastaveni kodovani
//            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
//
//            //spusti transformaci DOM stromu do XML dokumentu
//            writer.transform(new DOMSource(doc), new StreamResult(new File(outfile)));
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
