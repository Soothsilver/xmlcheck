package user;

import java.util.ArrayList;
import java.util.List;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

// nazev tymu presune z elementu do atributu a vymaze nahradniky, kteri nezasahli do hry
public class MyDomTransformer {
    
    public void transform(Document xmlDocument) {
         NodeList tymy = xmlDocument.getElementsByTagName("tym");
         for (int i = 0; i < tymy.getLength(); i++)
         {
            ZpracujTym(tymy.item(i));
         }
              
        
    }
    
    private void ZpracujTym(Node tym)
    {
      // vezme uzel s nazvem tymu
      Node nazevNode = ((Element)tym).getElementsByTagName("nazev").item(0);
      
      // zjisti nazev tymu
      String nazev = nazevNode.getTextContent();
      
      // ulozi jej jako novy atribut elementu tym
      ((Element)tym).setAttribute("nazev",nazev);
      
      // vymaze podelement s nazvem
      tym.removeChild(nazevNode);
      
      ZpracujNahradniky(((Element)tym).getElementsByTagName("nahradnici").item(0));
    }
    
    private void ZpracujNahradniky(Node nahradnici)
    {
      NodeList hraci = nahradnici.getChildNodes();
      for(int i = 0; i < hraci.getLength();i++)
      {
        boolean vyhodit = true;
        NodeList children = hraci.item(i).getChildNodes();
        for(int j = 0;j < children.getLength();j++)
        {
          if(children.item(j).getNodeName() == "stridani") // hrac stridal, nebudeme jej vyhazovat
          {
            vyhodit = false;
            break;
          }
        }
        if(vyhodit)
        {
          nahradnici.removeChild(hraci.item(i));
        }
      } 
    }
    
    
}