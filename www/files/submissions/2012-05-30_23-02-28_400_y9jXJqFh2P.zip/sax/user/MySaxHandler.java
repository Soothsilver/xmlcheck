package user;

import java.util.ArrayList;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

// spocita vsechny hrace (vcetne nahradniku), jejich prumerne cislo dresu a prumernou delku jejich jmen
public class MySaxHandler extends DefaultHandler {
     private int delka_jmen;
     private int delka_prijmeni;

     private int pocet_jmen;
     private int pocet_prijmeni;
     
     private boolean inHrac;
     private boolean inJmeno;
     private boolean inPrijmeni;
     
     private int pocet_hracu;
     private int cisla_dresu;
    
    @Override
    public void startDocument() throws SAXException {
      delka_jmen = 0;
      delka_prijmeni = 0;
      pocet_jmen = 0;
      pocet_prijmeni = 0;
      cisla_dresu = 0;

      pocet_hracu = 0;
      inHrac = false;
      inJmeno = false;
      inPrijmeni = false;
    }

    @Override
    public void endDocument() throws SAXException {
      System.out.println("Celkov� po�et hr��� v z�pase (v�etn� n�hradn�k�): " + pocet_hracu);
      System.out.println("Pr�m�rn� ��slo dresu: " + cisla_dresu / pocet_hracu);
      int prumer_jmeno = delka_jmen / pocet_jmen;
      int prumer_prijmeni = delka_prijmeni / pocet_prijmeni;    
      System.out.println("Pr�m�rn� d�lka jejich k�estn�ho jm�na: " + prumer_jmeno);
      System.out.println("Pr�m�rn� d�lka jejich p��jmen�: " + prumer_prijmeni);
      System.out.println("Pr�m�rn� d�lka jejich cel�ho jm�na (k�estn� + p��jmen�): " + prumer_jmeno + prumer_prijmeni);
    }    
    

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
      if(inJmeno)
      {
        delka_jmen += length; 
        pocet_jmen++;
        
      }
      else if(inPrijmeni)
      {
        delka_prijmeni += length;
        pocet_prijmeni++;
      }
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
      if(localName == "hrac")
      {
        inHrac = true;
        pocet_hracu++; 
        cisla_dresu += Integer.parseInt(attributes.getValue("cislo"));
      }
      else if(localName == "jmeno" && inHrac)
      {
        inJmeno = true;   
      }
      else if(localName == "prijmeni" && inHrac)
      {
        inPrijmeni = true;
      }
    } 
    
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
      if(localName == "hrac")
      {
        inHrac = false;
      }
      else if(localName == "jmeno")
      {
        inJmeno = false;
      }
      else if(localName == "prijmeni")
      {
        inPrijmeni = false;
      }
    }

}