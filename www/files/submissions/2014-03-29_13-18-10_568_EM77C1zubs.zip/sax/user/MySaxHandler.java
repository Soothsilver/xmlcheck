package user;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

import java.util.*;

/**
 * Author: Kuba Spatny
 * Web: kubaspatny.cz
 * E-mail: kuba.spatny@gmail.com
 * Date: 3/27/14
 * Time: 7:42 PM
 Copyright 2014 Jakub Spatny

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

 http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
 */


public class MySaxHandler extends DefaultHandler {

    private Stack<String> mStack = new Stack<String>();
    private Stack<String> mMovies = new Stack<String>();
    private ArrayList<Double> mRatings = new ArrayList<Double>();
    private HashMap<String, AwardHolder> mAwards = new HashMap<String, AwardHolder>();

    // -- movies filter flags -----------
    private boolean isFantasy = false;
    private boolean isOtherwiseOK = true;
    // ----------------------------------

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attrs) throws SAXException {
        mStack.push(localName);

        if(localName.equals("award")){
            for (int i = 0; i < attrs.getLength(); i++) {
                if(attrs.getLocalName(i).equals("name")){
                    String awardName = attrs.getValue(i);
                    AwardHolder a = mAwards.get(awardName);
                    if(a == null){
                        mAwards.put(awardName, new AwardHolder(awardName));
                    } else {
                        a.inc();
                    }
                    break;
                }
            }
        }

        if(localName.equals("genre") && !isFantasy){
            for (int i = 0; i < attrs.getLength(); i++) {
                if(attrs.getLocalName(i).equals("type")){
                    isFantasy = attrs.getValue(i).equals("Fantasy");
                    break;
                }
            }
        }

        if(localName.equals("ranking")){
            for (int i = 0; i < attrs.getLength(); i++) {
                if(attrs.getLocalName(i).equals("type")){
                    isOtherwiseOK = attrs.getValue(i).equals("PG-13");
                    break;
                }
            }
        }

    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        mStack.pop();
        if(localName.equals("movie")){
            if(!isOtherwiseOK || !isFantasy){
                mMovies.pop();
            }

            isFantasy = false;
            isOtherwiseOK = true;
        }

    }

    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        String s = new String(chars, start, length);
        if (s.trim().length() == 0) return;

        if (mStack.peek().equals("value") && mStack.get(mStack.size() - 2).equals("rating")) {
            mRatings.add(Double.parseDouble(s));
        }

        if (mStack.peek().equals("title") && mStack.get(mStack.size() - 2).equals("movie")) {
            mMovies.push(s);
        }

        if (mStack.peek().equals("year") && mStack.get(mStack.size() - 2).equals("premiere_date") && isOtherwiseOK) {
            isOtherwiseOK = s.equals("2014");
        }


    }

    @Override
    public void endDocument() throws SAXException {
        double avg = 0;
        for (int i = 0; i < mRatings.size(); i++) {
            avg += mRatings.get(i);
        }
        avg /= mRatings.size();
        System.out.println("------- Rating Average from elements -------"); // prints rating average from all movies in the DB
        if(mRatings.size() == 0){
            System.out.println("There are no movies in the database.");
        } else {
            System.out.println("Rating average: " + avg);
        }
        System.out.println("--------------------------------------------");

        System.out.println("------- Most common from attributes --------"); // prints 3 most common awards (with the number of times they've been awarded)
        List<AwardHolder> sortedAwards = new ArrayList<AwardHolder>();
        sortedAwards.addAll(mAwards.values());
        Collections.sort(sortedAwards);
        int num = 1;
        for(int i = 0; i < sortedAwards.size() && i < 3; i++){
            System.out.println((num++) + ". " + sortedAwards.get(i));
        }
        if(sortedAwards.size() == 0) System.out.println("There are no award in the database.");
        System.out.println("--------------------------------------------");
        System.out.println("------------- Filtered movies --------------"); // prints Fantasy movies that came out in 2014 and were rated PG-13
        for (int i = 0; i < mMovies.size(); i++) {
            System.out.println(mMovies.get(i));
        }
        if(mMovies.size() == 0) System.out.println("No movies in the database fulfil filter criteria.");
        System.out.println("--------------------------------------------");

    }

    class AwardHolder implements Comparable<AwardHolder> {

        public final String name;
        public int num = 1;

        AwardHolder(String name) {
            this.name = name;
        }

        public void inc(){
            num++;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            AwardHolder that = (AwardHolder) o;

            if (!name.equals(that.name)) return false;

            return true;
        }

        @Override
        public int hashCode() {
            return name.hashCode();
        }

        //@Override
        public int compareTo(AwardHolder o) {
            if (this.num > o.num) return -1;
            if (this.num < o.num) return 1;
            return 0;
        }

        @Override
        public String toString() {
            return name + " (" + num + ")";
        }
    }

}

/*
class SAXSupport {

    // Path to input file
    private static final String INPUT_FILE = "data.xml";


    public static void main(String[] args) {


        try {

            XMLReader parser = XMLReaderFactory.createXMLReader();
            InputSource source = new InputSource(INPUT_FILE);
            parser.setContentHandler(new MySaxHandler());
            parser.parse(source);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
*/