package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

/**
 * Author: Kuba Spatny
 * Web: kubaspatny.cz
 * E-mail: kuba.spatny@gmail.com
 * Date: 3/27/14
 * Time: 11:07 PM
 * Copyright 2014 Jakub Spatny
 * <p/>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p/>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p/>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


public class MyDomTransformer {

    public void transform(Document doc) {

           deleteRussianActors(doc);
           addActor(doc, "Charles", "Xavier", 1, 1, 1970, "Oxford", "UK","M");



    }

    /**
     * Adds a new node named @childName and with text content of value @textContent to Element @e.
     * @param doc
     * @param e
     * @param childName
     * @param textContent
     */
    private static void addElementWithTextContent(Document doc, Element e, String childName, String textContent){

        Element childElement = doc.createElement(childName);
        childElement.appendChild(doc.createTextNode(textContent));
        e.appendChild(childElement);

    }

    /**
     * After Russia's Annexation Of Crimea, the American CEO decided we don't want Russian actors in our database.
     * This methods deletes all Russian actors.
     * @param doc
     */
    private void deleteRussianActors(Document doc){
        NodeList actors = doc.getElementsByTagName("actor");
        HashMap<String, Element> toBeDeleted = new HashMap<String, Element>();
        for (int i = 0; i < actors.getLength(); i++) {

            Element e = (Element)actors.item(i);
            String country = ((Element)((Element) e.getElementsByTagName("pob").item(0)).getElementsByTagName("country").item(0)).getTextContent();
            if(country.equals("Russia")){
                toBeDeleted.put(e.getAttribute("id"), e);
            }

        }

        for(Element e : toBeDeleted.values()){
            e.getParentNode().removeChild(e);
        }

        // delete movie roles with this actor's id
        NodeList roles = doc.getElementsByTagName("role");
        for (int i = roles.getLength() - 1; i >= 0; i--) {
            Element role = (Element) roles.item(i);
            Node child = role.getFirstChild();
            while(!child.getNodeName().equals("role_actor")) child = child.getNextSibling();
            if(toBeDeleted.containsKey(((Element)child).getAttribute("id"))){
                role.getParentNode().removeChild(role);
            }
        }
    }

    private void addActor(Document doc, String firstName, String lastName, int day, int month, int year, String city, String country, String gender){

        NodeList actors = doc.getElementsByTagName("actors");
        if(actors.getLength() == 0){ // create "actors" element if it doesn't exist

            NodeList people = doc.getElementsByTagName("people");
            Node ch1 = people.item(0).getFirstChild();
            Element e = doc.createElement("actors");
            people.item(0).insertBefore(e, ch1);

        }

        Node actorsElement = actors.item(0);
        Element lastActor = null;
        NodeList l = actorsElement.getChildNodes();
        for (int i = l.getLength() - 1; i >= 0; i--) {
            if(l.item(i).getNodeName().equals("actor")){
                lastActor = (Element) l.item(i);
                break;
            }
        }


        String new_id = "actor1";
        if(lastActor != null){
            new_id = "actor" + (Integer.parseInt(lastActor.getAttribute("id").replace("actor","")) + 1);
        }

        Element actor = doc.createElement("actor");
        actor.setAttribute("id", new_id);

        Element name = doc.createElement("name");
        addElementWithTextContent(doc, name, "first_name",firstName);
        addElementWithTextContent(doc, name, "last_name",lastName);

        Element dob = doc.createElement("dob");
        addElementWithTextContent(doc, dob, "day",day + "");
        addElementWithTextContent(doc, dob, "month",month + "");
        addElementWithTextContent(doc, dob, "year",year + "");

        Element pob = doc.createElement("pob");
        addElementWithTextContent(doc, pob, "city",city);
        addElementWithTextContent(doc, pob, "country",country);

        Element genderEl = doc.createElement("gender");
        genderEl.setAttribute("type",gender);

        actor.appendChild(name);
        actor.appendChild(dob);
        actor.appendChild(pob);
        actor.appendChild(genderEl);

        actorsElement.appendChild(actor);


        // test what happens if some elements are missing - no actor in actors, no actors at all
        // the same thing for the first one - no Russians, no actors element
        // the same for SAX HW



    }

}

/*
class Main {

    public static void main(String[] args) {

        try {

            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setValidating(false);
            DocumentBuilder builder = dbf.newDocumentBuilder();
            Document doc = builder.parse("data.xml");

            new MyDomTransformer().transform(doc);

            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer writer = tf.newTransformer();
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            writer.transform(new DOMSource(doc), new StreamResult(new File("data_output.xml")));

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

}
*/