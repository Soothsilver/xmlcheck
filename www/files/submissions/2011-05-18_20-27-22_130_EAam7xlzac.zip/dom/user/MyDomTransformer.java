
package user;
import java.util.ArrayList;
import org.w3c.dom.Document;
import org.w3c.dom.*;

/**
 * ZADANI:
 * Upravte program tak, aby transformoval vstupní XML dokument na výstupní pomocí akcí
 * uvedených v komentářích metody processTree(doc).
 */
public class MyDomTransformer {  
    /**
     * Zpracuje DOM strom, najde aliance a v kazde obrati poradi gubernatoru
     */
    public void transform(org.w3c.dom.Document doc) {
        NodeList aliance =doc.getElementsByTagName("aliance");
        for (int i = 0; i < aliance.getLength(); i++) {
            Node ali = aliance.item(i);
            reverseOrderInAliance(ali);
        }
        
    }

     /**
     * V alianci obrati poradi gubernatoru pouzitim zasobniku.
      * Nejdrive vsechny gubernatory da pryc a pak je opacne vklada
     */
    private static void reverseOrderInAliance(Node aliance){
        if (aliance==null) return;
        if (aliance.getChildNodes().getLength()>0) {
            ArrayList<Node> zasobnikGubernatu = new ArrayList<Node>();
            for (int i = 0; i < aliance.getChildNodes().getLength(); i++) {
                Node item = aliance.getChildNodes().item(i);
                if(item==null) continue;
                if(item.getNodeName().equals("gubernator")){
                    zasobnikGubernatu.add(aliance.removeChild(item));
                }

            }
            while (zasobnikGubernatu.isEmpty()==false) {
                int count = zasobnikGubernatu.size();
                aliance.appendChild(zasobnikGubernatu.remove(count-1));
            }
        }
    }
}
