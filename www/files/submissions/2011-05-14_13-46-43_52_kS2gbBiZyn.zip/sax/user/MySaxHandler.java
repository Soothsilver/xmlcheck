/** 
 * Zadani: Projedeme cely XML dokument a zjistime nazvy vsech polozek sushi, 
 * ktere se nachazeji v jidelnim listku. Nasledne vypiseme na konzoli 
 * vsechna jmena sushi polozek a ke kazde polozce kolikkrat se vyskytuje 
 * v nejakem sushi menu.
 */
 
package user;

import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;
import java.util.HashMap;

public class MySaxHandler extends DefaultHandler {
	
	HashMap<String, Integer> mapa = new HashMap<String, Integer>();
    String kod;
    boolean sushiMOD;
    boolean menuMOD;
    boolean polozkaMOD;
	
    // udalost zacatku dokumentu
    public void startDocument() throws SAXException {
    	// ..
    }
    
    // udalost konce dokumentu
    public void endDocument() throws SAXException {
    	// vypiseme obsah hashmapy na konzoli
    	for (String s : mapa.keySet()) { 
            System.out.println(s + ": " + mapa.get(s));
        }
    }
    
    // udalost zacatku elementu
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
    	// nastaveni modu (v jakem elementu zrovna jsem)
    	if (localName == "sushi")
    		sushiMOD = true;
    	if (sushiMOD == true && localName == "polozka_menu")
    		menuMOD = true;
    	if (menuMOD == true && localName == "polozka_sushi")
    		polozkaMOD = true;

    	// podle modu urcim, jakou akci mam provest
    	
    	// pokud ctu polozku sushi
    	if (polozkaMOD == true) {
    		// ziskam jmeno pokrmu
    		String pokrm = atts.getValue("pokrm");
    		
    		// pokud pokrm neni v hashmape
    		if (mapa.containsKey(pokrm) == false)
    			// zapisu prvni vyskyt
    			mapa.put(pokrm, 1);
    		else
    			mapa.put(pokrm, mapa.get(pokrm) + 1);
    	}
    }

    // udalost konce elementu
    public void endElement(String uri, String localName, String qName) throws SAXException {
        // nastavujeme mody na false
    	if (localName == "sushi")
        	sushiMOD = false;
        if (localName == "polozka_menu")
        	menuMOD = false;
        if (localName == "polozka_sushi")
        	polozkaMOD = false;
    }

}