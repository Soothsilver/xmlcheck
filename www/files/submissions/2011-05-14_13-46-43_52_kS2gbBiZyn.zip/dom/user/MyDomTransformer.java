/**
 * ZADANI:
 * Najde vsechny polozky v jidelnim menu a prepocita ceny v Kc na Eura.
 * Navic zmenime strukturu elementu cena tak, ze jeho textovy obsah prevedeme na atribut.
 */

package user;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;
import org.w3c.dom.Document;

public class MyDomTransformer {
	public void transform (Document xmlDocument) {
	    
		Element root = xmlDocument.getDocumentElement();
	    
		// najdeme vsechny elementy cena
		NodeList ceny = root.getElementsByTagName("cena");
	
		// projedeme vsechny elementy cena
		for (int i = 0; i < ceny.getLength(); i++) {
			
			// ziskani ceny v korunach
			double koruny = Double.parseDouble(ceny.item(i).getFirstChild().getNodeValue());
			// prepocet ceny na eura
			double eura = koruny / 24;
		
			// nastavit rodcie
			Node rodic = ceny.item(i).getParentNode();
			
			// smazat starou cenu v Kc
			rodic.removeChild(ceny.item(i));
			
			// vytvorime novy element cena
			Element novaCena = xmlDocument.createElement("cena");
			// priradime ji prislusnou hodnotu v eurech
			
			// zaokrouhleni eur na 2 desetinna mista
			int r = (int)(eura * 100);
			double cena = r / 100.0;
			
			// nastaveni atributu pro element cena
			novaCena.setAttribute("eu", Double.toString(cena));
			novaCena.setAttribute("kc", Double.toString(koruny));
			
			// pripojime element k rodici
			rodic.appendChild(novaCena);
		}
	}
}