package user;

import java.util.HashMap;
import java.util.Map;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;
//1.)Vypise statistiku narodnosti
//2.)Vezme jednotlive casti jmena a vypise ty nejcastejsi
//3.)Statistika hodnosti v senatorskem stavu
/**
 * Main class for SAX parsing
 *
 * @author XML Technologies
 */
/*class  Main{

    // Path to input file
    private static final String INPUT_FILE = "data.xml";

    
    public static void main(String[] args) {



        try {

            // Create parser instance
            XMLReader parser = XMLReaderFactory.createXMLReader();

            // Create input stream from source XML document
            InputSource source = new InputSource(INPUT_FILE);

            // Set our custom content handler for handling SAX events (it must implements ContentHandler interface)
            parser.setContentHandler(new MySaxHandler());

            // Process input data
            parser.parse(source);

        } catch (Exception e) {

            e.printStackTrace();

        }

    }
}*/
/**
 * Out custom content handler for managing SAX events Implements methods of the
 * abstract class ContentHandler.
 * @see http://www.saxproject.org/apidoc/org/xml/sax/ContentHandler.html#processingInstruction%28java.lang.String,%20java.lang.String%29
 */
public class MySaxHandler extends DefaultHandler {

    // Helper variable to store location of the handled event
    Locator locator;
    
    /**
     * Sets the locator
     *
     * @param Locator locator location in the file
     */
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Method to handle "document start"
     *
     * @throws SAXException
     */
    
    @Override
    public void startDocument() throws SAXException {
        // ...
    }

    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
        // ...     
        System.out.println("Statistika narodnosti");
        for (Map.Entry<String, Integer> entry : narodnosti.entrySet())
        {
            System.out.println(entry.getKey()+" "+entry.getValue());
        }
        System.out.println("************************************");
        System.out.println("Nejcasteji pojmenovany vojak (ruzne casti jmena zvlast)");
        String praenomenM=null;
        int max=0;
        for (Map.Entry<String, Integer> entry : praenomen.entrySet())
        {
            if(max<entry.getValue())
            {
                max=entry.getValue();
                praenomenM=entry.getKey();
            }
        }
        String nomenM=null;
        max=0;
        for (Map.Entry<String, Integer> entry : nomen.entrySet())
        {
            if(max<entry.getValue())
            {
                max=entry.getValue();
                nomenM=entry.getKey();
            }
        }
        String cognomenM=null;
        max=0;
        for (Map.Entry<String, Integer> entry : cognomen.entrySet())
        {
            if(max<entry.getValue())
            {
                max=entry.getValue();
                cognomenM=entry.getKey();
            }
        }
        
        System.out.println(praenomenM+" "+nomenM+" "+cognomenM);
        System.out.println("************************************");
        System.out.println("Vypise statistiku hodnosti v senatorskem stavu");
        for (Map.Entry<String, Integer> entry : stavyHodnosti.entrySet())
        {
            System.out.println(hodnosti.get(entry.getKey())+" "+entry.getValue());
            //System.out.println(entry.getKey()+" "+entry.getValue());
        }
    }
    
    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    
    Map<String,Integer> narodnosti=new HashMap<String,Integer>();
    Map<String,Integer> praenomen=new HashMap<String,Integer>();
    Map<String,Integer> nomen=new HashMap<String,Integer>();
    Map<String,Integer> cognomen=new HashMap<String,Integer>();
    Map<String,String> hodnosti=new HashMap<String,String>();
    Map<String,Integer> stavyHodnosti=new HashMap<String,Integer>();
    
    boolean praenomenB=false;
    boolean nomenB=false;
    boolean cognomenB=false;
    boolean hodnost=false;
    String idhod;
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        // ...
        if(localName.equals("hodnost"))
        {
            hodnost=true;
            idhod=atts.getValue(0);
            return;
        }
        if(localName.equals("praenomen"))
        {
            praenomenB=true;
            return;
        }
        if(localName.equals("nomen"))
        {
            nomenB=true;
            return;
        }
        if(localName.equals("cognomen"))
        {
            cognomenB=true;
            return;
        }
        if(localName.equals("vojak"))
        {
            for(int i=0;i<atts.getLength();i++)
            {
                
                String s=atts.getValue(i);
                if(atts.getLocalName(i).equals("narodnost"))
                {
                    if(narodnosti.containsKey(s))
                    {
                        narodnosti.put(s, narodnosti.get(s)+1);
                    }else
                    {
                        narodnosti.put(s, 1);
                    }
                }
                if(atts.getLocalName(i).equals("stav"))
                {
                    if(atts.getValue(i).equals("senator"))
                    {
                        for(int j=0;j<atts.getLength();j++)
                        {
                            if(atts.getLocalName(j).equals("hodnost"))
                            {
                                s=atts.getValue(j);
                                if(stavyHodnosti.containsKey(s))
                                {
                                    stavyHodnosti.put(s, stavyHodnosti.get(s)+1);
                                }else
                                {
                                    stavyHodnosti.put(s, 1);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        // ...
    }

    
    String read(char[] chars, int start)
    {
        String s="";  
        for(int i=start;chars[i]!='<'&&i<chars.length;i++)s+=chars[i];
        return s;
    }
    
    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        // ...
        if(hodnost)
        {
            hodnosti.put(idhod, read(chars, start));
            hodnost=false;
            return;
        }
        if(praenomenB)
        {
            praenomenB=false;
            String s=read(chars, start);
            if(praenomen.containsKey(s))
            {
                praenomen.put(s, praenomen.get(s)+1);
            }else
            {
                praenomen.put(s, 1);
            }
            return;
        }
        
        if(nomenB)
        {
            nomenB=false;
            String s=read(chars, start);
            if(nomen.containsKey(s))
            {
                nomen.put(s, nomen.get(s)+1);
            }else
            {
                nomen.put(s, 1);
            }
            return;
        }
        
        if(cognomenB)
        {
            cognomenB=false;
            String s=read(chars, start);
            if(cognomen.containsKey(s))
            {
                cognomen.put(s, cognomen.get(s)+1);
            }else
            {
                cognomen.put(s, 1);
            }
            return;
        }
    }

    /**
     * Method to handle " start of namespace declaration"
     *
     * @param prefix Prefix of the namespace
     * @param uri URI of the namespace
     * @throws SAXException
     */
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        // ...
    }

    /**
     * Method to handle "end of namespace declaration"
     *
     * @param prefix
     * @throws SAXException
     */
    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
        // ...
    }

    /**
     * Method to handle "ignoring of whitespaces" Text is in array 'chars' from
     * position ('start') to ('start' + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     * @throws SAXException
     */
    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
        // ...
    }

    /**
     * Method to handle "processing instructions"
     *
     * @param target The processing instruction target
     * @param data  The processing instruction data
     * @throws SAXException
     */
    @Override
    public void processingInstruction(String target, String data) throws SAXException {
        // ...
    }

    /**
     * Method to handle "unprocessed entity"
     *
     * @param name
     * @throws SAXException
     */
    @Override
    public void skippedEntity(String name) throws SAXException {
        // ...
    }
}