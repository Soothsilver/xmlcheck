package user;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;
//1.)Smaze vojaka rimske narodnosti jmenem Markus
//2.)Prida vojaka (resi neexistenci kohorty a centurie)
/**
 * ASSIGNMENT: Update document to be able to transform input XML document to
 * output document by actions mentioned in comments of processTree method.
 */
public class MyDomTransformer {

    private static final String INPUT_FILE = "data.xml";
    private static final String OUTPUT_FILE = "data.out.xml";

    /**
     * Main method
     *
     * @param args command line arguments
     */
    /*public static void main(String[] args) {

        try {

            // DocumentBuilderFactory creates DOM parsers
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            // We don't want to validate file
            dbf.setValidating(false);

            // Creating of DOM parser instance
            DocumentBuilder builder = dbf.newDocumentBuilder();

            // Parser processes input file and creates a DOM tree of objects
            Document doc = builder.parse(INPUT_FILE);

            // DOM tree processing
            processTree(doc);

            // TransformerFactory creates an object for DOM serialization
            TransformerFactory tf = TransformerFactory.newInstance();

            // Transformer serializes DOM tree
            Transformer writer = tf.newTransformer();

            // Setting of output file encoding
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            // Run transformation of DOM tree to XML document
            writer.transform(new DOMSource(doc), new StreamResult(new File(OUTPUT_FILE)));
            

        } catch (Exception e) {

            e.printStackTrace();

        }
    }*/
    
    public void transform(Document doc)
    {
        processTree(doc);
    }
    
    /**
     * Process document tree
     *
     * @param doc Document to be parsed
     */
    private static void processTree(Document doc) {
        //put your code here
        //smaze vojaka rimske narodnosti, ktery se jmenuje Markus
        NodeList jmena=doc.getElementsByTagName("praenomen");
        for(int i=0;i<jmena.getLength();i++)
        {
            Node jmeno=jmena.item(i);
//            System.out.println(jmeno.getTextContent());
            if(jmeno.getTextContent().equals("Marcus"))
            {
                Node vojak=jmeno.getParentNode().getParentNode();
                NamedNodeMap atts=vojak.getAttributes();
                Node narodnost=atts.getNamedItem("narodnost");
//                System.out.println(narodnost.getTextContent());
                if("rimska".equals(narodnost.getTextContent()))
                {
//                    System.out.println("*");
//                    System.out.println(vojak.getTextContent());
                    vojak.getParentNode().removeChild(vojak);
                    i--;
                }
            }
        }
        
        //pridani vojaka
        Element vojak=doc.createElement("vojak");
        vojak.setAttribute("hodnost", "h2");
        vojak.setAttribute("stav", "senator");
        vojak.setAttribute("narodnost", "rimska");
        Element jmeno=doc.createElement("jmeno");
        jmeno.appendChild(doc.createElement("praenomen")).setTextContent("Quintus");
        jmeno.appendChild(doc.createElement("nomen")).setTextContent("Fabius");
        jmeno.appendChild(doc.createElement("cognomen")).setTextContent("Maximus");
        vojak.appendChild(jmeno);
        NodeList listVojak=doc.getElementsByTagName("centurie");
        if(listVojak.getLength()!=0)
        {
            listVojak.item(0).appendChild(vojak);
        }else
        {
            NodeList listKohorta=doc.getElementsByTagName("kohorta");
            if(listKohorta.getLength()!=0)
            {
                Element centrurie=doc.createElement("centurie");
                centrurie.setAttribute("cislo", "I");
                centrurie.appendChild(vojak);
                listKohorta.item(0).appendChild(centrurie);
            }else
            {
                Element centrurie=doc.createElement("centurie");
                centrurie.setAttribute("cislo", "I");
                centrurie.appendChild(vojak);
                Element kohorta=doc.createElement("kohorta");
                kohorta.setAttribute("cislo", "I");
                kohorta.appendChild(centrurie);
                doc.getElementsByTagName("legie").item(0).appendChild(kohorta);
            }
        }
        
    }
}