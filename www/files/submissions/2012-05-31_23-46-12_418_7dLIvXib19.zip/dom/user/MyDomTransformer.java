package user;

import org.w3c.dom.*;

/**
 * Zadani ukolu pro DOM. Prestavba na majetkove orientovanou strukturu, nebo-li
 * seznam majetku, kde kazda polozka ma explicitne uvedeny seznam zodpovednych
 * osob a seznam pronajmu s explicitne uvedenym najemcem, jmenem pronajimatele a
 * s atributy puvodniho elementu prevedenymi do textovych elementu.
 *
 * @author radimbufka@gmail.com
 */
public class MyDomTransformer {

    private Element osoby;
    private Element pronajmy;
    private Element majetek;
    private Element root;
    private Document doc;

    public void transform(Document doc) {
        // code transforming xmlDocument object 
        // (method works on the object itself - no return value) 
        this.doc = doc;

        osoby = (Element) doc.getElementsByTagName("zodpovedne-osoby").item(0);
        setId(osoby);
        majetek = (Element) doc.getElementsByTagName("majetek").item(0);
        pronajmy = (Element) doc.getElementsByTagName("pronajmy").item(0);
        root = doc.getDocumentElement();


        for (Node typMajetku = majetek.getFirstChild(); typMajetku != null; typMajetku = typMajetku.getNextSibling()) {
            for (Node kus = typMajetku.getFirstChild(); kus != null; kus = kus.getNextSibling()) {
                if (kus.getNodeType() == Node.ELEMENT_NODE) {
                    zpracujMajetek((Element) kus);
                }
            }
        }
        for (Node pronajem = pronajmy.getFirstChild(); pronajem != null; pronajem = pronajem.getNextSibling()) {
            if (pronajem.getNodeType() == Node.ELEMENT_NODE) {
                zpracujPronajem((Element) pronajem);
            }
        }


        root.removeChild(osoby);
        root.removeChild(pronajmy);

        NamedNodeMap atts = root.getAttributes();
        root.removeAttribute("xsi:noNamespaceSchemaLocation");
        root.removeAttribute("xmlns:xsi");
    }

    private void zpracujMajetek(Element majetek) {
        Element zo = doc.createElement("zodpovedne-osoby");

        majetek.setIdAttributeNode(majetek.getAttributeNode("id"), true);

        String[] zoIDs = majetek.getAttribute("zodpovovedne-osoby").trim().split(" ");

        for (String id : zoIDs) {
            Element zoEl = doc.getElementById(id);
            zo.appendChild(zoEl.cloneNode(true));
        }
        majetek.appendChild(zo);
        majetek.appendChild(doc.createElement("pronajmy"));
    }

    private void setId(Element osoby) {
        for (Node osoba = osoby.getFirstChild(); osoba != null; osoba = osoba.getNextSibling()) {
            if (osoba.getNodeType() == Node.ELEMENT_NODE) {
                Element osEl = (Element) osoba;
                osEl.setIdAttributeNode(osEl.getAttributeNode("id"), true);
            }
        }
    }

    private void zpracujPronajem(Element pronajem) {
        String predmetId = pronajem.getAttribute("predmet").trim();
        Element pronajmyMajetku = (Element) doc.getElementById(predmetId).getElementsByTagName("pronajmy").item(0);
        Element pron = doc.createElement("pronajem");
        Attr id = doc.createAttribute("id");
        id.setValue(pronajem.getAttribute("id"));
        pron.setAttributeNode(id);
        pron.setIdAttributeNode(id, true);

        // najemnik
        Element najemnik = doc.createElement("najemnik");
        najemnik.appendChild(doc.getElementById(pronajem.getAttribute("najemnik")).cloneNode(true));
        pron.appendChild(najemnik);
        // pronajal
        Element pronajal = doc.createElement("pronajal");
        Node najemce = doc.getElementById(pronajem.getAttribute("pronajal"));
        String jmenoNajemce = "error";
        if (najemce.getNodeName().equals("fo")) {
            Element fo = (Element) najemce;
            Element jmenoFo = (Element) fo.getElementsByTagName("jmeno").item(0);
            Element prijmeniFo = (Element) fo.getElementsByTagName("prijmeni").item(0);
            jmenoNajemce = jmenoFo.getTextContent().trim() + " "
                    + prijmeniFo.getTextContent().trim();
        } else if (najemce.getNodeName().equals("po")) {
            Element po = (Element) najemce;
            jmenoNajemce = ((Element) po.getElementsByTagName("nazev").item(0)).getTextContent().trim();
        }
        pronajal.setTextContent(jmenoNajemce);
        pron.appendChild(pronajal);
        // cena
        Element cena = doc.createElement("cena");
        cena.setTextContent(pronajem.getAttribute("cena"));
        pron.appendChild(cena);
        
        //datum pronajmu 
        Element datum = doc.createElement("pronajato");
        //od
        Element od = doc.createElement("od");
        od.setTextContent(pronajem.getAttribute("od"));
        datum.appendChild(od);
        //do
        Element do2 = doc.createElement("do");
        do2.setTextContent(pronajem.getAttribute("do"));
        datum.appendChild(do2);
        pron.appendChild(datum);
        // popis
        pron.appendChild(pronajem.getElementsByTagName("popis").item(0).cloneNode(true));
        // pridani do pronajmu konkretniho majetku
        pronajmyMajetku.appendChild(pron);
    }
}
