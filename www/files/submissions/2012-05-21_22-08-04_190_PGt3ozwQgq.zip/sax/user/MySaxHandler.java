package user;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

public class MySaxHandler extends DefaultHandler {

    private int elems = 0;
    private int attrs = 0;
    private int elemsWithAttrs = 0;
    private int maxDepth = 0;
    private int depth = 0;
    private Map<String, Integer> elemCount = new HashMap<String, Integer>();
    private Map<String, Integer> attrCount = new HashMap<String, Integer>();
    private String group = null;
    private Map<String, Integer> groupsCount = new HashMap<String, Integer>();
    private Map<String, Integer> usersCount = new HashMap<String, Integer>();
    private int groups = 0;
    private int users = 0;
    private int longestDesc;
    private String longestDescEntry;
    private String curEntry;
    private int descLen = 0;
    private boolean inDescription;
    private boolean inUser=false;
    private String username="";
    

    @Override
    public void endDocument() throws SAXException {
        System.out.println("Pocet elementu: " + elems);
        System.out.println("Z toho elmentu s attributy: " + elemsWithAttrs + " (" + elemsWithAttrs * 100 / elems + "%)");
        System.out.println("Celkovy pocet atributu: " + attrs);
        System.out.println("Maximalni hloubka dokumentu: " + maxDepth);
        int maxCount = 0;
        String maxName = null;
        Set<String> keyset = elemCount.keySet();
        Iterator<String> it = keyset.iterator();
        if (elems != 0) {
            while (it.hasNext()) {
                String k = it.next();
                int cnt = elemCount.get(k);
                if (cnt > maxCount) {
                    maxName = k;
                    maxCount = cnt;
                }
            }
            System.out.println("Nejcasteji se vyskytuje element: " + maxName + " (" + maxCount + "x)");
        }

        if (attrs != 0) {
            maxCount = 0;
            maxName = null;
            keyset = attrCount.keySet();
            it = keyset.iterator();
            while (it.hasNext()) {
                String k = it.next();
                int cnt = attrCount.get(k);
                if (cnt > maxCount) {
                    maxName = k;
                    maxCount = cnt;
                }
            }
            System.out.println("Nejcasteji se vyskytuje atribut: " + maxName + " (" + maxCount + "x)");
        }

        if (groups != 0) {
            System.out.println("Celkem je v dokumentu " + groups + " skupin s dohromady " + users + " uzivateli.");
            System.out.println("Skupina\t\tPocet uzivatelu");
            keyset = groupsCount.keySet();
            it = keyset.iterator();
            while (it.hasNext()) {
                String k = it.next();
                System.out.println(k + "\t\t" + groupsCount.get(k));
            }
        }
        System.out.println("Nejdelsi popisek ma zaznam s id " + longestDescEntry + " (" + longestDesc + " znaku)");
        System.out.println("Uzivatle nachazejici se ve vice nez jedne skupine: ");
            keyset = usersCount.keySet();
            it = keyset.iterator();
            while (it.hasNext()) {
                String k = it.next();
                if(usersCount.get(k)>1)
                System.out.println("\t" + k+ "("+usersCount.get(k)+")");
            }
        
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        depth++;
        elems++;
        int attrCnt = attributes.getLength();
        if (attrCnt > 0) {
            elemsWithAttrs++;
            attrs += attrCnt;
        }
        int count = 0;
        if (elemCount.containsKey(localName)) {
            count = elemCount.get(localName);
        }
        elemCount.put(localName, count + 1);

        for (int i = 0; i < attrCnt; i++) {
            String attrName = attributes.getLocalName(i);
            count = 0;
            if (attrCount.containsKey(attrName)) {
                count = attrCount.get(attrName);
            }
            attrCount.put(attrName, count + 1);
        }
        if (group != null) {
            count = 0;
            if (groupsCount.containsKey(group)) {
                count = groupsCount.get(group);
            }
            groupsCount.put(group, count + 1);
            users++;
        }

        if (localName.equals("group")) {
            group = attributes.getValue("name");
            groups++;
        }

        if (localName.equals("entry")) {
            curEntry = attributes.getValue("id");
        }
        if (localName.equals("description")) {
            inDescription = true;
            descLen = 0;
        }
        if(localName.equals("user")) {
            inUser=true;
            System.out.println("inuser");
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (depth > maxDepth) {
            maxDepth = depth;
        }
        depth--;
        if (localName.equals("group")) {
            group = null;
        }
        if (localName.equals("description")) {
            inDescription = false;
            if(descLen>longestDesc) {
                longestDesc=descLen;
                longestDescEntry=curEntry;
            }
        }
        
        if(localName.equals("user")) {
            int count=0;
            if(usersCount.containsKey(username)) {
                count=usersCount.get(username);
            }
            usersCount.put(username, count+1);
            inUser=false;
            username="";
        }

    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        if (inDescription) {
            descLen+=length;
        }
        if(inUser)
            username=username+String.valueOf(ch, start, length);
    }

    public void start() {
        try {
            XMLReader parser = XMLReaderFactory.createXMLReader();
            parser.setContentHandler(this);
            parser.parse(new InputSource("/home/mrkva/fel/4/xml/dcv/data.xml"));
        } catch (Exception ex) {
            Logger.getLogger(MySaxHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void main(String[] args) throws Exception {
        new MySaxHandler().start();
    }
}