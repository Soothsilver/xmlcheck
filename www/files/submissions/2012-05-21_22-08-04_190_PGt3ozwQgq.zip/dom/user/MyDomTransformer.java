package user;

import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

public class MyDomTransformer {

    public Document doc;
    public Element newRoot;

    public Node getChildByName(Node n, String name) {
        if (n == null) {
            return null;
        }
        Node child = n.getFirstChild();
        while (child != null) {
            if (child.getNodeName().equals(name)) {
                return child;
            }
            child = child.getNextSibling();
        }
        return null;
    }

    public String getEntryOwner(Node entry) {
        Node owner = this.getChildByName(this.getChildByName(entry, "perms"), "owner");
        if (owner == null) {
            return "";
        }
        return owner.getTextContent();
    }

    public String getAttribute(Node n, String attrName) {
        NamedNodeMap attrs = n.getAttributes();
        return attrs.getNamedItem(attrName).getTextContent();
    }

    public Node getOwnerNode(String owner) {
        Node child = newRoot.getFirstChild();
        while (child != null) {
            if (child.getNodeName().equals("owner")
                    && child.hasAttributes() && this.getAttribute(child, "name").equals("owner")) {
                return child;
            }
            child = child.getNextSibling();
        }
        Element to = doc.createElement("owner");
        to.setAttribute("name", owner);
        newRoot.appendChild(to);
        return to;
    }

    public void removeOwner(Node entry) {
        Node owner = this.getChildByName(this.getChildByName(entry, "perms"), "owner");
        owner.getParentNode().removeChild(owner);
    }

    public void reformatDates(Node entry) {
        Node dates = this.getChildByName(entry, "date");
        NodeList children = dates.getChildNodes();

        for (int j = 0; j < children.getLength(); j++) {
            Node oldDate = children.item(j);
            NamedNodeMap attrs = oldDate.getAttributes();
            if (attrs == null) {
                continue;
            }
            Element newDate = doc.createElement(oldDate.getNodeName());

            for (int i = 0; i < attrs.getLength(); i++) {
                Node attr = attrs.item(i);
                String name = attr.getNodeName();
                String value = attr.getNodeValue();
                Element e = doc.createElement(name);
                e.setTextContent(value);
                newDate.appendChild(e);
                attrs.removeNamedItem(name);
            }
            oldDate.getParentNode().replaceChild(newDate, oldDate);
        }
    }

    public void transform(Document doc) {
        this.doc = doc;
        /*
         * prevedeme: <diary> <entry> <perms><owner>$username</owner></perms>
         * ... </entry> ... </diary>
         *
         * na: <userDiary> <owner name="$username"> <entry> ... </entry> ...
         * </owner> ... </userDiary>
         */

        Element root = doc.getDocumentElement();
        Element newRoot = doc.createElement("userDiary");
        this.newRoot = newRoot;

        Node child = root.getFirstChild();
        while (child != null) {
            if (child.getNodeType() != Node.ELEMENT_NODE) {
                newRoot.appendChild(child);
                child = root.getFirstChild();
                continue;
            }
            String owner = this.getEntryOwner(child);
            Node placeTo = this.getOwnerNode(owner);
            if (placeTo == null) {
            }
            placeTo.appendChild(child);

            /*
             * odstranime z <perms></perms> <owner>$username</owner>
             */
            this.removeOwner(child);

            /*
             * preformatujeme datum z <neco day="01" hour="23" minute="59"
             * month="03" notify="yes" second="59" year="2012"/> na
             * <neco><year></year><month></month>....
             */
            this.reformatDates(child);

            child = root.getFirstChild();

        }


        doc.replaceChild(newRoot, root);
    }

    public Document load(String fn) {
        try {
            DocumentBuilderFactory bf = DocumentBuilderFactory.newInstance();
            return bf.newDocumentBuilder().parse(fn);
        } catch (Exception ex) {
            Logger.getLogger(MyDomTransformer.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public void save(Document d, String fn) {
        try {
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer writer = tf.newTransformer();
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            writer.transform(new DOMSource(d), new StreamResult(new File(fn)));
        } catch (Exception ex) {
            Logger.getLogger(MyDomTransformer.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public static void main(String args[]) {
        MyDomTransformer dt = new MyDomTransformer();
        Document d = dt.load("/home/mrkva/fel/4/xml/dcv/data.xml");
        dt.transform(d);
        dt.save(d, "/home/mrkva/fel/4/xml/dcv/dom-out.xml");
    }
}
