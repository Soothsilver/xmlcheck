/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 *
 * @author Gumus
 */
public class MySaxHandler extends DefaultHandler {

    int movieCount = 0;
    int personCount = 0;
    int movieDurSum = 0;
    int maxGenreCount = 0;
    int currentGenreCount = 0;
    int totalGenreCount = 0;
    boolean countingGenres = false;
    boolean firstDuration = false;
    String maxGenreMovie;
    String currentMovie;
    private boolean firstTitle;
    private boolean readTitle;
    private StringBuilder stringBuilder;

    @Override
    public void startDocument() throws SAXException {
        super.startDocument();
        stringBuilder = new StringBuilder();
    }

    @Override
    public void endDocument() throws SAXException {
        super.endDocument();
        System.out.println("Total movie count: " + movieCount);
        System.out.println("Total person count: " + personCount);
        System.out.println("Average movie duration is " + movieDurSum / movieCount + " minutes");
        System.out.println("The movie " + maxGenreMovie + " has highest number of genres, it has " + maxGenreCount);
        
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        super.startElement(uri, localName, qName, attributes);
        if (localName.equals("movie")) {
            movieCount++;
            firstDuration = true;
            firstTitle = true;
        }
        if (localName.equals("title")) {
            if (firstTitle) {
                readTitle = true;
            }
        }
        if (localName.equals("duration") && firstDuration) {
            firstDuration = false;
            movieDurSum += Integer.parseInt(attributes.getValue(0));
        }
        if (localName.equals("person")) {
            personCount++;
        }
        if (countingGenres) {
            currentGenreCount++;
        }
        if (localName.equals("genre")) {
            countingGenres = true;
            currentGenreCount = 0;
        }
        
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        super.endElement(uri, localName, qName);
        if (localName.equals("genre")) {
            if (currentGenreCount > maxGenreCount) {
                maxGenreCount = currentGenreCount;
                maxGenreMovie = currentMovie;
            }
            totalGenreCount += currentGenreCount;
            countingGenres = false;
        }
        if (localName.equals("title")) {
            if (firstTitle) {
                readTitle = false;
                firstTitle = false;
                currentMovie = stringBuilder.toString();
                stringBuilder = new StringBuilder();
            }
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        super.characters(ch, start, length);
        if (readTitle) {
            stringBuilder.append(ch, start, length);
        }
    }

    public static void main(String[] args) {
        try {
            String sourcePath = "data.xml";

          
                XMLReader parser = XMLReaderFactory.createXMLReader();

                InputSource source = new InputSource(sourcePath);

                parser.setContentHandler(new MySaxHandler());

                parser.parse(source);
        } catch (IOException ex) {
            Logger.getLogger(MySaxHandler.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SAXException ex) {
            Logger.getLogger(MySaxHandler.class.getName()).log(Level.SEVERE, null, ex);
        }

      
      
    

    }
}
