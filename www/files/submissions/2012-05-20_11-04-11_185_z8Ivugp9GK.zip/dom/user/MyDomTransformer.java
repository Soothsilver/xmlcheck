/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import org.w3c.dom.*;

/**
 *
 * @author PaHorPC32
 */
public class MyDomTransformer {
    public void transform (Document doc) {
        NodeList list = doc.getElementsByTagName("vypujcka");
        
        if (doc.getElementsByTagName("Skoly").getLength() == 0)
        {
            doc.getElementsByTagName("DB").item(0).appendChild(doc.createElement("Skoly"));            
        }
        
        NodeList studenti;
        
        if ((studenti = doc.getElementsByTagName("Studenti")).getLength() == 0)
        {
            doc.getElementsByTagName("Skoly").item(0).appendChild(doc.createElement("Studenti"));
        }
        
        Element student = doc.createElement("Student");
        Element kontaktniUdajeStudenta = doc.createElement("KontaktniUdajeS");        
        student.appendChild(kontaktniUdajeStudenta);
                
        Node jmeno = doc.createElement("Jmeno");
        jmeno.setTextContent("Pavel");
        
        Node prijmeni = doc.createElement("Prijmeni");
        prijmeni.setTextContent("Hornak");
        
        kontaktniUdajeStudenta.appendChild(jmeno);
        kontaktniUdajeStudenta.appendChild(prijmeni);
        
        
                       
        Node ulice = doc.createElement("Ulice");
        ulice.setTextContent("Kvasnicova");
        
        Node cisloPopisne = doc.createElement("CisloPopisne");
        cisloPopisne.setTextContent("67");
        
        Node mesto = doc.createElement("Mesto");
        mesto.setTextContent("Slichov");
        
        Node psc = doc.createElement("PSC");
        psc.setTextContent("13089");                                                            
        
        Node datum = doc.createElement("Datum");
        datum.setTextContent("8976530087");
        
        Node telefon = doc.createElement("Telefon");
        telefon.setTextContent("nazdar@seznam.cz");
        
        Node pokrik = doc.createElement("Pokrik");
        pokrik.setTextContent("876443298");
        
        kontaktniUdajeStudenta.appendChild(ulice);
        kontaktniUdajeStudenta.appendChild(cisloPopisne);
        kontaktniUdajeStudenta.appendChild(mesto);
        kontaktniUdajeStudenta.appendChild(psc);        
        kontaktniUdajeStudenta.appendChild(telefon);
        kontaktniUdajeStudenta.appendChild(datum);                
        kontaktniUdajeStudenta.appendChild(pokrik);
                
        String s = "c" + doc.getElementsByTagName("Student").getLength() + 1;
        student.setAttribute("id", s);
        
        student.setAttribute("refTridy", "t_1");
                
                
        studenti.item(0).appendChild(student);
    }
}
