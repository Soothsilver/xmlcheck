package dom.user;

import java.io.IOException;
import javax.xml.parsers.*;
import org.w3c.dom.*; 
import javax.xml.transform.*;
import javax.xml.transform.stream.*;
import javax.xml.transform.dom.*;
import org.xml.sax.SAXException;
public class MyDomTransformer {
    public void transform (Document xmlDocument) 
    {
        // DTD ensures the XML document is in expected form
        //System.out.println("1. Deleting all non-New non-OK vehicles");
        NodeList statuses = xmlDocument.getElementsByTagName("status");
        for (int i = statuses.getLength()-1;i>=0;i--)
        {
            Element status = (Element)statuses.item(i);
            if (status.getTextContent().equals("OK") || status.getTextContent().equals("New"))
            {
                // This vehicle is alright.
            }
            else
            {
                Node vehicle = status.getParentNode();
                Node vehicles = vehicle.getParentNode();
                vehicles.removeChild(vehicle);
            }
        }
        
        //System.out.println("2. Adding a new soldier to Heroes:");
        NodeList armies = xmlDocument.getElementsByTagName("army");
        for(int i = 0; i < armies.getLength(); i++)
        {
            Element army = (Element)armies.item(i);
            if (army.getAttribute("id").equals("Heroes"))
            {
                Element infantry = 
                        (Element)army.getElementsByTagName("infantry").item(0);
                
                Element newSoldier = xmlDocument.createElement("soldier");
                Element newPerson = xmlDocument.createElement("person");
                newPerson.setAttribute("name", "George von Bitter");
                newPerson.setAttribute("real", "yes");
                newPerson.setAttribute("friend", "yes");
                newPerson.setAttribute("id", "US213");
                Element country = xmlDocument.createElement("country");
                country.setAttribute("code",
                        "US");
                country.setAttribute("name",
                        "United States of America");
                newPerson.appendChild(country);
                Element rank = xmlDocument.createElement("rank");
                Node rankName = xmlDocument.createTextNode("Colonel");
                rank.appendChild(rankName);
                newPerson.appendChild(rank);
                newSoldier.appendChild(newPerson);
                
                infantry.appendChild(newSoldier);
                
                break;
            }
        }
        
        // code transforming xmlDocument object
        // (method works on the object itself - no return value)
    } 
    /*
    public static void main(String[] args) throws SAXException, ParserConfigurationException, TransformerConfigurationException, IOException, TransformerException
    {
        System.out.println("Test of DOM: ");
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setValidating(true);
        DocumentBuilder builder = dbf.newDocumentBuilder();
        Document doc = builder.parse("data.xml");
        MyDomTransformer transformer = new MyDomTransformer();
        transformer.transform(doc);
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer writer = tf.newTransformer();
        writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
        writer.transform(new DOMSource(doc), new StreamResult(new java.io.File("data.out.xml")));        
    }*/
}