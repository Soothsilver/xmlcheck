package user;

import java.util.LinkedList;
import org.w3c.dom.*;

/**
 * DOM transformer that provides a method to revert order
 * of elements in specified document.
 */
public class MyDomTransformer {
	
	public void transform (Document xmlDocument) {
		revertElementOrder(xmlDocument);
	}
	
	/**
	 * Recursively reverts order of elements in DOM tree where
	 * specified node is the root.
	 * @param node Root of the DOM tree in which element order should be reverted.
	 */
	private void revertElementOrder(Node node) {
		LinkedList<Element> childElements = new LinkedList<Element>();			
		
		// collect and remove current node's child elements
		for (int i = 0; i < node.getChildNodes().getLength(); ++i) {
			Node childNode = node.getChildNodes().item(i);
			if (childNode instanceof Element) {
				Element childElement = (Element)childNode;
				
				node.removeChild(childElement);
				childElements.addLast(childElement);
			}
		}
		
		// insert child elements in reversed order
		while (!childElements.isEmpty()) {
			Element innerElement = childElements.removeFirst();
			node.appendChild(innerElement);
		}
		
		// use recursion to revert element order also for each
		//   child node
		for (int i = 0; i < node.getChildNodes().getLength(); ++i) {
			Node childNode = node.getChildNodes().item(i);
			revertElementOrder(childNode);
		}
	}
}
