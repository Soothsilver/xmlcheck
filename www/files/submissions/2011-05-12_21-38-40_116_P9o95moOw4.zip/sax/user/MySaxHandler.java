package user;

import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Sax event handler that computes shortest, longest and average
 * length of attribute name in the processed document.
 */
public class MySaxHandler extends DefaultHandler {
	
	private int attributeCount = 0;
	private float averageAttributeNameLength = 0;	
	private int longestAttributeNameLength = 0;		
	private int shortestAttributeNameLength = 0;
		
	public void startElement(String uri, String localName, String qName, Attributes attributes) {
		if (attributes == null)
			return;
		
		for (int i = 0; i < attributes.getLength(); ++i) {
			String attributeName = attributes.getLocalName(i);
			
			// update longest name
			if (attributeName.length() > longestAttributeNameLength)
				longestAttributeNameLength = attributeName.length();
			
			// update shortest name
			if (attributeName.length() < shortestAttributeNameLength)
				shortestAttributeNameLength = attributeName.length();
			
			// update average name
			float sumLength = (averageAttributeNameLength * attributeCount) + attributeName.length();
			attributeCount++;
			averageAttributeNameLength = sumLength / attributeCount; 
		}
	}
}
