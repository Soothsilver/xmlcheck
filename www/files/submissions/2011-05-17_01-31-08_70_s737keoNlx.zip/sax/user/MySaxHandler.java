package user;
import java.util.HashMap;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
/**
 * MySaxHandler pocita nasledujici veci:
 * 1) prumernou delku rozdilnych nazvu elementu nebo atributu
 * 2) prumernou delku vsech nazvu elementu a atributu
 * 3) prumernou hloubku dokumentu
 * @author Karel Klima
 */
public class MySaxHandler extends DefaultHandler {
    
    HashMap<String, Integer> occurrences = new HashMap<String, Integer>();

    int currentLevel = 0;
    int totalLevel = 0;
    int elementCount = 0;

    @Override
    public void endDocument() throws SAXException {

        // prumerna delka rozdilnych nazvu elementu nebo atributu
        // nebere se v potaz jejich cetnost
        int totalDistinctLength = 0;
        for (String name : occurrences.keySet()) {
            totalDistinctLength += name.length();
        }
        float averageDistinctLength = (float)totalDistinctLength / (float)occurrences.size();

        // prumerna delka vsech nazvu elementu a atributu
        // bere se v potaz jejich cetnost
        int totalLength = 0;
        int totalCount = 0;
        for (String name : occurrences.keySet()) {
            totalCount += occurrences.get(name);
            totalLength += occurrences.get(name) * name.length();
        }
        float averageLength = (float)totalLength / (float)totalCount;

        // prumerna hloubka dokumentu
        // root je v hloubce 0, jeho potomci v hloubce 1 atd.
        float averageDepth = (float)totalLevel / (float)elementCount;

    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        // priakzy slouzici k vypocteni prumernych delek nazvu
        int count = occurrences.containsKey(localName) ? occurrences.get(localName) : 0;
        occurrences.put(localName, ++count);
        for (int i = 0; i < atts.getLength(); i++) {
            count = occurrences.containsKey(atts.getLocalName(i)) ? occurrences.get(atts.getLocalName(i)) : 0;
            occurrences.put(localName, ++count);
        }

        // prikazy slouzici k vypocteni prumerne hloubky dokumentu
        totalLevel += currentLevel;
        currentLevel++;
        elementCount++;
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        // prikazy slouzici k vypocteni prumerne hloubky dokumentu
        currentLevel--;
    }
}
