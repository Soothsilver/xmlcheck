package user;
import java.util.ArrayList;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
/**
 * MyDomTransformer projde strom a provede pro kazdy element nasledujici cinnosti:
 * 1) prevrati poradi potomku typu Node.ELEMENT_TYPE kazdeho elementu
 * 2) atributy elementu, ktery nema zadne potomky, prevede na potomky
 *    (smaze atribut a misto nich vytvori podelementy se stenym nazvem a obsahem)
 * @author Karel Klima
 */
public class MyDomTransformer {

    public void transform(Document xmlDocument) {
        ProcessNode((Node)xmlDocument.getDocumentElement(), xmlDocument);
    }

    public void ProcessNode(Node Parent, Document xmlDocument) {
        NodeList Children = Parent.getChildNodes();
        ArrayList<Integer> ElementChildNodes = new ArrayList<Integer>();

        // rekurzivne se zpracuji vsichni potomci
        for (int i = 0; i < Children.getLength(); i++) {
            int type = Children.item(i).getNodeType();
            String value = Children.item(i).getNodeValue();
            if (Children.item(i).getNodeType() == Node.ELEMENT_NODE) {
                ProcessNode(Children.item(i), xmlDocument);
                ElementChildNodes.add(i);
            }
        }

        // prevraceni poradi potomku typu Node.ELEMENT_NODE
        Node Temp = xmlDocument.createElement("temp");
        int pos1, pos2;
        for (int i = 0; i < ElementChildNodes.size() / 2; i++) {
            pos1 = ElementChildNodes.get(i);
            pos2 = ElementChildNodes.get(ElementChildNodes.size() - 1 - i);
            Temp = Parent.replaceChild(Temp, Children.item(pos1));
            Temp = Parent.replaceChild(Temp, Children.item(pos2));
            Temp = Parent.replaceChild(Temp, Children.item(pos1));
        }
        
        // nasledne se atributy rodice prevedou na podelementy
        if (Parent.getChildNodes().getLength() < 1) {
            while (Parent.getAttributes().getLength() > 0) {
                Node attr = Parent.getAttributes().item(0);
                Node el = xmlDocument.createElement(attr.getNodeName());
                el.appendChild(xmlDocument.createTextNode(attr.getNodeValue()));
                Parent.appendChild(el);
                Parent.getAttributes().removeNamedItem(attr.getNodeName());
            }
        }
    }
}
