package user;


import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;


import org.w3c.dom.Document;


public class MyDomTransformer {

    public void transform(Document doc) {
        NodeList aa = doc.getElementsByTagName("muzstvo");
        for (int i = 0; i < aa.getLength(); i++) {
            Element v = (Element)aa.item(i);
            

            if (v.getAttribute("soutez").equals("a_muzstvo")) continue;
            
            NodeList hraci = v.getElementsByTagName("hraci");
            Element h = (Element)hraci.item(0);
            NodeList golmani = h.getElementsByTagName("golmani");
            Element g = (Element)golmani.item(0);
            NodeList golman = g.getElementsByTagName("golman");
            
            for (int j = 0; j<golman.getLength(); j++)
            {
                    Element el = (Element)golman.item(j);
                    pridejgolmana(el.getAttribute("name"), el.getAttribute("hul"), doc);
            }
            
            NodeList obranci = h.getElementsByTagName("obranci");
            Element o = (Element)obranci.item(0);
            NodeList obrance = o.getElementsByTagName("obrance");
            
            for (int j = 0; j<obrance.getLength(); j++)
            {
                    Element el = (Element)obrance.item(j);
                    pridejobrance(el.getAttribute("name"), el.getAttribute("hul"), doc);
            }
            
            NodeList utocnici = h.getElementsByTagName("utocnici");
            Element u = (Element)utocnici.item(0);
            NodeList utocnik = u.getElementsByTagName("utocnik");
            
            for (int j = 0; j<utocnik.getLength(); j++)
            {
                    Element el = (Element)utocnik.item(j);
                    pridejutocnika(el.getAttribute("name"), el.getAttribute("hul"), el.getAttribute("pozice"), doc);
            }
            
            
            v.getParentNode().removeChild(v);
        }
    }
    public void pridejgolmana(String jmeno, String hul, Document doc) {
        Element a = doc.createElement("golman");
        a.setAttribute("name", jmeno);
        a.setAttribute("hul", hul);
        NodeList aa = doc.getElementsByTagName("muzstvo");
        
        for (int i = 0; i < aa.getLength(); i++) {
            Element v = (Element)aa.item(i);
            
            
            if (v.getAttribute("soutez").equals("a_muzstvo")) {
                NodeList hraci = v.getElementsByTagName("hraci");
                Element h = (Element)hraci.item(0);
                NodeList golmani = h.getElementsByTagName("golmani");
                Element g = (Element)golmani.item(0);
                g.appendChild(a);
            }

        
        }
        
    }
    
    public void pridejobrance(String jmeno, String hul, Document doc) {
        Element a = doc.createElement("obrance");
        a.setAttribute("name", jmeno);
        a.setAttribute("hul", hul);
        NodeList aa = doc.getElementsByTagName("muzstvo");
        
        for (int i = 0; i < aa.getLength(); i++) {
            Element v = (Element)aa.item(i);
            
            
            if (v.getAttribute("soutez").equals("a_muzstvo")) {
                NodeList hraci = v.getElementsByTagName("hraci");
                Element h = (Element)hraci.item(0);
                NodeList golmani = h.getElementsByTagName("obranci");
                Element g = (Element)golmani.item(0);
                g.appendChild(a);
            }

        
        }
        
    }
        
    public void pridejutocnika(String jmeno, String hul, String pozice, Document doc) {
        Element a = doc.createElement("utocnici");
        a.setAttribute("name", jmeno);
        a.setAttribute("hul", hul);
        a.setAttribute("pozice", pozice);
        NodeList aa = doc.getElementsByTagName("muzstvo");
        
        for (int i = 0; i < aa.getLength(); i++) {
            Element v = (Element)aa.item(i);
            
            
            if (v.getAttribute("soutez").equals("a_muzstvo")) {
                NodeList hraci = v.getElementsByTagName("hraci");
                Element h = (Element)hraci.item(0);
                NodeList golmani = h.getElementsByTagName("utocnici");
                Element g = (Element)golmani.item(0);
                g.appendChild(a);
            }

        
        }
        
    }
            
            
            
            
}