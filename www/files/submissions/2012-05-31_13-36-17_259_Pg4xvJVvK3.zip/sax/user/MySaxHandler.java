package user;

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;
import java.util.*;



public class MySaxHandler extends DefaultHandler {

    // Umoznuje zacilit misto v dokumentu, kde vznikla aktualni udalost
    Locator locator;
    int PocetElementu;
    Map<String,Integer> map;

    /**
     * Nastavi locator
     */     
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Obsluha udalosti "zacatek dokumentu"
     */     
    public void startDocument() throws SAXException {
        PocetElementu = 0;
        map = new TreeMap<String, Integer>();
        // ...
        
    }
    /**
     * Obsluha udalosti "konec dokumentu"
     */     
    public void endDocument() throws SAXException {
        System.out.println("Pocet elementu: " + PocetElementu);
        double prumer = PocetElementu/(double)map.size();
        System.out.println("Prumerny pocet vyskytu: " + prumer);
        
        System.out.println();
        System.out.println("Elementy s nadprumernym vyskytem");
        for (String key : map.keySet()) {
            if (map.get(key) > prumer)
                System.out.println(key + " " + map.get(key));
        }
        // ...
        
    }
    
    /**
     * Obsluha udalosti "zacatek elementu".
     * @param uri URI jmenneho prostoru elementu (prazdne, pokud element neni v zadnem jmennem prostoru)
     * @param localName Lokalni jmeno elementu (vzdy neprazdne)
     * @param qName Kvalifikovane jmeno (tj. prefix-uri + ':' + localName, pokud je element v nejakem jmennem prostoru, nebo localName, pokud element neni v zadnem jmennem prostoru)
     * @param atts Atributy elementu     
     */     
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        PocetElementu++;
        
        if (map.containsKey(localName)) {
            int pocet = map.get(localName);
            map.put(localName, pocet+1);
        }
        else map.put(localName, 1);
        //System.out.println(map.get(uri));

    }
    /**
     * Obsluha udalosti "konec elementu"
     * Parametry maji stejny vyznam jako u @see startElement     
     */     
    public void endElement(String uri, String localName, String qName) throws SAXException {

        // ...

    }
    
    /**
     * Obsluha udalosti "znakova data".
     * SAX parser muze znakova data davkovat jak chce. Nelze tedy pocitat s tim, ze je cely text dorucen v ramci jednoho volani.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakovymi daty
     * @param start Index zacatku useku platnych znakovych dat v poli.
     * @param length Delka useku platnych znakovych dat v poli.
     */               
    public void characters(char[] ch, int start, int length) throws SAXException {

        // ...
        
    }
    
    /**
     * Obsluha udalosti "deklarace jmenneho prostoru".
     * @param prefix Prefix prirazeny jmennemu prostoru.
     * @param uri URI jmenneho prostoru.
     */     
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha udalosti "konec platnosti deklarace jmenneho prostoru".
     */     
    public void endPrefixMapping(String prefix) throws SAXException {
    
        // ...
    
    }

    /**
     * Obsluha udalosti "ignorovane bile znaky".
     * Stejne chovani a parametry jako @see characters     
     */     
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha udalosti "instrukce pro zpracovani".
     */         
    public void processingInstruction(String target, String data) throws SAXException {
      
      // ...
            
    }

    /**
     * Obsluha udalosti "nezpracovana entita"
     */         
    public void skippedEntity(String name) throws SAXException {
    
      // ...
    
    }
}