package user;
//trnap7am
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;

public class MySaxHandler extends DefaultHandler {
  
  /**
   * Počet elementů v dokumentu
   */
  int pocetElementu;
  /**
   * Počet atributů v dokumentu
   */
  int pocetAtributu;
  /**
   * Počet elementů "uzivatel" v dokumentu
   */
  int pocetUzivatelu;
  /**
   * Průměrná délka příjmení uživatele
   */
  double prumerPrijmeni;
  /**
   * Průměrný počet řešitelů obhájených projektů
   */	
  double prumerResitelu;
  /**
   * Nejvyšší počet příloh projektů přihlášených k obhajobě
   */
  int maximumPriloh;



  int delkaTextu;
  int pocetResitelu;
  int pocetPriloh;
  boolean projektObhajeny;
  boolean projektPrihlasenyKObhajobe;
  int pocetObhajenych;

    // Umožňuje zacílit místo v dokumentu, kde vznikla aktualní událost
    Locator locator;

    /**
     * Nastaví locator
     */     
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Obsluha události "začátek dokumentu"
     */     
    public void startDocument() throws SAXException {
        pocetElementu = 0;
        pocetAtributu = 0;
	pocetUzivatelu = 0;
	prumerPrijmeni = 0.0;
        prumerResitelu = 0.0;
	maximumPriloh = 0;

	pocetObhajenych = 0;
    }
    /**
     * Obsluha události "konec dokumentu"
     */     
    public void endDocument() throws SAXException {
        System.out.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        System.out.println("<document>");
        System.out.println("\t<item name=\"Počet elementů\">" + pocetElementu + "</key>");
        System.out.println("\t<item name=\"Počet atributů\">" + pocetAtributu + "</key>");
        System.out.println("\t<item name=\"Počet uživatelů\">" + pocetUzivatelu + "</key>");
        System.out.println("\t<item name=\"Průměrná délka příjmení\">" + prumerPrijmeni + "</key>");
        System.out.println("\t<item name=\"Průměrný počet řešitelů obhájených projektů\">" + prumerResitelu + "</key>");
        System.out.println("\t<item name=\"Největší počet příloh (včetně obrázků) projektů přihlášených k obhajobě\">" + maximumPriloh + "</key>");
        System.out.println("</document>");
    }
    
    /**
     * Obsluha události "začátek elementu".
     * @param uri URI jmenného prostoru elementu (prázdné, pokud element není v žádném jmenném prostoru)
     * @param localName Lokální jméno elementu (vždy neprázdné)
     * @param qName Kvalifikované jméno (tj. prefix-uri + ':' + localName, pokud je element v nějakém jmenném prostoru, nebo localName, pokud element není v žádném jmenném prostoru)
     * @param atts Atributy elementu     
     */     
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
	pocetElementu += 1;
	pocetAtributu += atts.getLength();


	if ("uzivatel".equals(qName)) {
	    pocetUzivatelu += 1;
	}

	if ("prijmeni".equals(qName)) {
	    delkaTextu = 0;
	}
	
	if ("projekt".equals(qName)) {
	    projektObhajeny = false;
	    projektPrihlasenyKObhajobe = false;

	    String stav = atts.getValue(atts.getIndex("stav"));

	    if ("obhajeny".equals(stav)) {
		pocetObhajenych += 1;
		projektObhajeny = true;
		pocetResitelu = 0;
	    }
	    if ("prihlaseny_k_obhajobe".equals(stav)) {
		projektPrihlasenyKObhajobe = true;
		pocetPriloh = 0;
	    }
	}
	
	if (("obrazek".equals(qName) || "priloha".equals(qName)) && projektPrihlasenyKObhajobe) {
	    pocetPriloh += 1;
	}

	if ("resitel".equals(qName) && projektObhajeny) {
	    pocetResitelu += 1;
	}
    }
    /**
     * Obsluha události "konec elementu"
     * Parametry mají stejný význam jako u @see startElement     
     */     
    public void endElement(String uri, String localName, String qName) throws SAXException {
	if ("prijmeni".equals(qName)) {
	    prumerPrijmeni = (prumerPrijmeni * (pocetUzivatelu - 1) + delkaTextu) / pocetUzivatelu;
	}

	if ("resitele".equals(qName) && projektObhajeny) {
	    prumerResitelu = (prumerResitelu * (pocetObhajenych - 1) + pocetResitelu) / pocetObhajenych;
	}

	if ("prilohy".equals(qName) && projektPrihlasenyKObhajobe && (pocetPriloh > maximumPriloh)) {
	    maximumPriloh = pocetPriloh;
	}
    }
    
    /**
     * Obsluha události "znaková data".
     * SAX parser muľe znaková data dávkovat jak chce. Nelze tedy počítat s tím, že je celý text dorucen v rámci jednoho volání.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakovými daty
     * @param start Index zacátku úseku platných znakových dat v poli.
     * @param length Délka úseku platných znakových dat v poli.
     */               
    public void characters(char[] ch, int start, int length) throws SAXException {
	delkaTextu += length;
    }
    
    /**
     * Obsluha události "deklarace jmenného prostoru".
     * @param prefix Prefix prirazený jmennému prostoru.
     * @param uri URI jmenného prostoru.
     */     
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        
    }

    /**
     * Obsluha události "konec platnosti deklarace jmenného prostoru".
     */     
    public void endPrefixMapping(String prefix) throws SAXException {
    
        // ...
    
    }

    /**
     * Obsluha události "ignorované bílé znaky".
     * Stejné chování a parametry jako @see characters     
     */     
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        
        // ...
        
    }

    /**
     * Obsluha události "instrukce pro zpracování".
     */         
    public void processingInstruction(String target, String data) throws SAXException {
      
      // ...
            
    }

    /**
     * Obsluha události "nezpracovaná entita"
     */         
    public void skippedEntity(String name) throws SAXException {
    
      // ...
    
    }
}