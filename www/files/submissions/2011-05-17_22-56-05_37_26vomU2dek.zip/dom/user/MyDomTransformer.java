package user;
//trnap7am
import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

/**
 * ZADANI:
 * Upravte program tak, aby transformoval vstupní XML dokument na výstupní pomocí akcí
 * uvedených v komentářích metody processTree(doc).
 */
public class MyDomTransformer {
    public void transform (Document doc) { 
	
	//Zahodí seznam uživatelů a termínů obhajob
	Node uzivatele = doc.getElementsByTagName("uzivatele").item(0);
	uzivatele.getParentNode().removeChild(uzivatele);
	Node terminy = doc.getElementsByTagName("terminy").item(0);
	terminy.getParentNode().removeChild(terminy);

	
	NodeList projektlist = doc.getElementsByTagName("projekt");

	for (int i = 0; i < projektlist.getLength();) {
	  Node projekt = projektlist.item(i);

	  //Převede PID z atributu na element
	  Element pidelement = doc.createElement("pid");
	  pidelement.appendChild(doc.createTextNode(((Element)projekt).getAttribute("pid")));
	  projekt.insertBefore(pidelement, projekt.getFirstChild());
	  ((Element)projekt).removeAttribute("pid");
	  
	  //Převede NAZEV z elementu na atribut
	  Node nazevnode = ((Element)projekt).getElementsByTagName("nazev").item(0);
	  ((Element)projekt).setAttribute("nazev", ((Text)((Element)nazevnode).getFirstChild()).getData());
	  projekt.removeChild(nazevnode);

	  //Omezí počet příloh na 3
	  Node prilohy = ((Element)projekt).getElementsByTagName("prilohy").item(0);
	  while ((((Element)prilohy).getElementsByTagName("priloha").getLength() + ((Element)prilohy).getElementsByTagName("obrazek").getLength()) > 3) {
	    prilohy.removeChild(prilohy.getLastChild());
	  }

	  //Odstraní zrušené projekty z minulých roků
	  String stav = ((Element)projekt).getAttribute("stav");
	  String zmeneno = ((Element)projekt).getAttribute("zmeneno");
	  if ("zruseny".equals(stav) && "2010-01-01".compareTo(zmeneno) > 0) {
	    projekt.getParentNode().removeChild(projekt);
	  } else {
	    i += 1;
	  }
	}

    }
}
