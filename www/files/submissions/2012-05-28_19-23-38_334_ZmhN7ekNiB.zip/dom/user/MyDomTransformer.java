package user;

import java.io.File;
import java.io.FileInputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;


public class MyDomTransformer {

	public void transform (Document xmlDocument) {
		Element root=xmlDocument.getDocumentElement(); //get root element
		Element concertsElem = getFirstSubNodeByName(root, "concerts"); //get root element for concerts
		NodeList concerts = concertsElem.getElementsByTagName("concert"); //get list of concert
		int count = concerts.getLength();
		for(int i = 0 ; i < count;i++) { //for each concert
			Element concert = (Element)concerts.item(i);
			Element ratingsElem = getFirstSubNodeByName(concert, "ratings");
			NodeList ratings = ratingsElem.getElementsByTagName("rating"); //get list of raings
			int ratingsCount = ratings.getLength();
			double sum = 0.0;
			for(int j = 0; j<ratingsCount;j++) {
				Element rating = (Element)ratings.item(j);
				try {
					sum += Integer.parseInt(rating.getTextContent());
				}
				catch(Exception e) {}
			}
			
			Element avgRatingElement = xmlDocument.createElement("avgRating"); //create an element for the avg rating
			avgRatingElement.appendChild(xmlDocument.createTextNode(Double.toString(sum/ratingsCount))); //insert the value
			concert.appendChild(avgRatingElement); //append to the concert element
			
		}
		//save(xmlDocument);
	}
	
	public void save(Document doc) {
		// TransformerFactory vytvari serializatory DOM stromu
		TransformerFactory tf = TransformerFactory.newInstance ();
		// Transformer serializuje DOM stromy
		Transformer writer = null;
		try {
			writer = tf.newTransformer ();
		} catch (TransformerConfigurationException e1) {
			e1.printStackTrace();
		}
		// nastavime kodovani
		writer.setOutputProperty
		(OutputKeys.ENCODING, "windows-1250");
		// spustime transformaci DOM stromu do XML dokumentu
		try {
			writer.transform
			(new DOMSource (doc),
			new StreamResult (new File ("C:/testy/xml/dom.xml")));
		} catch (TransformerException e) {
			e.printStackTrace();
		}
	}
	
	/*public static void main(String[] args) {
		Document doc = getDocument("C:/testy/xml/data.xml");
		MyDomTransformer transformer = new MyDomTransformer();
		transformer.transform(doc);
	}*/
	
	private static Document getDocument(String data)
	{
		DocumentBuilder db=getDocumentBuilder();
		try
		{
			FileInputStream fIn=new FileInputStream(data);
			return db.parse(fIn);
		}
		catch(Exception e)
		{
			return null;
		}
	}
	
	private static DocumentBuilder getDocumentBuilder()
	{
		try
		{
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			dbf.setCoalescing(true);
			return dbf.newDocumentBuilder();
		}
		catch(Exception e) { return null; }
	}
	
	/**
	 * A helper method to get the first subnode of the given element with the specified name.
	 * @return The element or null if there is no such subnode.
	 */
	private Element getFirstSubNodeByName(Element el, String name)
	{
		try
		{
			NodeList nl = el.getElementsByTagName(name);
			return (Element)nl.item(0);
		}
		catch(Exception e) {return null;}
	}

}
