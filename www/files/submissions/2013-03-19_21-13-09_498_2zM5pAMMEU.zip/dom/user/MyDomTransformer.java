package user;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

//1) prida noveho rezisera Hitchcocka
//2) vymaze vsechny polozky bez nosicu
public class MyDomTransformer {
    public void transform (Document xmlDocument) {
        //1
        NodeList list = xmlDocument.getElementsByTagName("filmari");
        if(list.getLength() > 0) {
            Element filmar = xmlDocument.createElement("filmar");
            filmar.setAttribute("id", "f100");
            filmar.setAttribute("pohlavi", "M");
            filmar.appendChild(xmlDocument.createElement("jmeno")).setTextContent("Alfred");
            filmar.appendChild(xmlDocument.createElement("prijmeni")).setTextContent("Hitchcock");
            filmar.appendChild(xmlDocument.createElement("narozeni")).appendChild(xmlDocument.createElement("datum")).setTextContent("13.8.1899");
            filmar.appendChild(xmlDocument.createElement("umrti")).appendChild(xmlDocument.createElement("datum")).setTextContent("29.4.1980");
            list.item(0).appendChild(filmar);
        }
        //2
        list = xmlDocument.getElementsByTagName("polozka");
        for(int i = 0; i < list.getLength(); ++i) {
            Element item = (Element) list.item(i);
            if (item.getElementsByTagName("nosic").getLength() == 0) {
                //we want nice indentation - remove previous blank text node
                Node prev = item.getPreviousSibling();
                if (prev != null &&
                    prev.getNodeType() == Node.TEXT_NODE &&
                    prev.getNodeValue().trim().length() == 0) {
                    prev.getParentNode().removeChild(prev);
                }
                item.getParentNode().removeChild(item);
                --i; //list is updated!
            }
        }
    }
}
