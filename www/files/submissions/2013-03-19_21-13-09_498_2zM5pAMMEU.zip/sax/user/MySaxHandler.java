package user;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

//na standardni vystup vypise:
//1) prumerne stari filmu v pujcovne
//2) nejvyssi udelenou pokutu
//3) pocet mimoprazskych zakazniku mladsich 30 let (bere v potaz jen rok narozeni, ne presne datum)
public class MySaxHandler extends DefaultHandler {
    //1
    int moviesCount = 0;
    int moviesYearSum = 0;
    //2
    boolean inFine = false;
    double maxFine = Double.NaN;
    StringBuilder fineBuffer = new StringBuilder();
    //3
    boolean inCustomer = false;
    int customerCount = 0;
    StringBuilder cityBuffer = new StringBuilder();
    StringBuilder dateBuffer = new StringBuilder();
    boolean inBirth = false;
    boolean inDate = false;
    boolean inAddress = false;
    boolean inCity = false;

    @Override
    public void endDocument() throws SAXException {
        //1
        if (moviesCount == 0) {
            System.out.println("Nenalezeny zadne filmy s uvedenym datem vydani");
        } else {
            int currentYear = Calendar.getInstance().get(Calendar.YEAR);
            double avgYear = 1.0 * moviesYearSum / moviesCount;
            System.out.printf("Nalezeno %d filmu s rokem vydanim, prumerne stari v rocich je %.2f\n", moviesCount, currentYear-avgYear);
        }
        //2
        if (Double.isNaN(maxFine)) {
            System.out.println("Nenalezeny zadne pokuty");
        } else {
            System.out.printf("Maximalni udelena pokuta je %.2f\n", maxFine);
        }
        //3
        System.out.printf("Pocet mimoprazskych zakazniku mladsich 30 let je %d\n", customerCount);
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        //1
        if ("polozka".equals(localName) && "film".equals(atts.getValue("typ"))) {
            try {
                moviesYearSum += Integer.parseInt(atts.getValue("rok"));
                ++moviesCount;
            } catch(Exception e) { e.printStackTrace(); }
        } else
        //2
        if("pokuta".equals(localName)) {
            inFine = true;
        } else
        //3
        if ("zakaznik".equals(localName)) {
            inCustomer = true;
        } else if ("narozeni".equals(localName) && inCustomer) {
            inBirth = true;
        } else if ("datum".equals(localName) && inBirth) {
            inDate = true;
            dateBuffer.setLength(0);
        } else if ("adresa".equals(localName) && inCustomer) {
            inAddress = true;
        } else if ("mesto".equals(localName) && inAddress) {
            inCity = true;
            cityBuffer.setLength(0);
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        //2
        if ("pokuta".equals(localName)) {
            try {
                double newFine = Double.parseDouble(fineBuffer.toString());
                if (!(newFine < maxFine)) { //NaN compares always false
                    maxFine = newFine;
                }
            } catch(Exception e) { }
            inFine = false;
            fineBuffer.setLength(0);
        } else
        //3
        if ("zakaznik".equals(localName)) {
            if (!"Praha".equals(cityBuffer.toString())) {
                try {
                    Calendar now = Calendar.getInstance();
                    Calendar birth = Calendar.getInstance();
                    SimpleDateFormat formatter = new SimpleDateFormat("d.m.yyyy");
                    birth.setTime(formatter.parse(dateBuffer.toString()));
                    if (now.get(Calendar.YEAR) - birth.get(Calendar.YEAR) < 30) {
                        ++customerCount;
                    }
                } catch(Exception e) { e.printStackTrace(); }
            }
        } else if("narozeni".equals(localName)) {
            inBirth = false;
        } else if("datum".equals(localName)) {
            inDate = false;
        } else if("adresa".equals(localName)) {
            inAddress = false;
        } else if("mesto".equals(localName)) {
            inCity = false;
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        //1
        if (inFine) {
            fineBuffer.append(ch, start, length);
        } else
        //2
        if (inDate) {
            dateBuffer.append(ch, start, length);
        } else if (inCity) {
            cityBuffer.append(ch, start, length);
        }
    }
}