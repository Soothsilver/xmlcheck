package user;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;

/**
 * @author Petr
 * SAX projede zadany XML dokument (v tomto pripade data.xml) a spocita z nej pocet elementu,
 * pocet textovych elementu, pocet atributu, hloubku XML dokumentu, pocet nejcasteji pouzivaneho elementu
 * a nazev nejcasteji pouzivaneho elementu
 */
public class MySaxHandler extends DefaultHandler {
	
	
	public static void main(String[] args) {
        String sourcePath = "data.xml";

        try {
            XMLReader parser = XMLReaderFactory.createXMLReader();
            InputSource source = new InputSource(sourcePath);
            parser.setContentHandler(new MySaxHandler());
            parser.parse(source);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	int currentDepth;
	int maxDepth;
	int attributeCount;
	int elementCount;
	int textElementsCount;
	int mostUsed;
	String mostUsedName;
	
	Map<String, Integer> map = new HashMap<String, Integer>();
	
	String currentName;
    Locator locator;
    
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    @Override
    public void startDocument() throws SAXException {
        System.out.println("Traversing through data.xml");
    }
 
    @Override
    public void endDocument() throws SAXException {
    	System.out.println("Depth of xml document:\t\t"+maxDepth);
    	System.out.println("Number of elements:\t\t"+elementCount);
    	System.out.println("Number of text elements:\t"+textElementsCount);
    	System.out.println("Number of attributes:\t\t"+attributeCount);
    	for (Entry<String, Integer> entry : map.entrySet()){
    	    if(entry.getValue()>mostUsed){
    	    	mostUsed=entry.getValue();
    	    	mostUsedName = entry.getKey();
    	    }
    	}
    	System.out.println("Count of most used element:\t"+mostUsed);
    	System.out.println("Name of most used element:\t"+mostUsedName);
    	System.out.println("Traversing completed");
    }
    
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
    	this.elementCount++;
    	this.attributeCount+=atts.getLength();
    	if(++currentDepth>maxDepth){
    		maxDepth = currentDepth;
    	}
    	currentName = qName;
    	if(!map.containsKey(localName)){
    		map.put(localName, 1);
    	}
    	else{
    		map.put(localName, map.get(localName)+1);
    	}
    	
    }
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
    	currentDepth--;
    }
    
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        String string = new String(ch, start, length);
        if (string.trim().length()> 0) {
            this.textElementsCount++;
        }
    }
}