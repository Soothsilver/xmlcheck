package user;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;


/**
 * @author Petr
 * DOM nejprve smaze textovy obsah elementu RodneCislo, pote smaze atributy elementu MTGPlayer,
 * smaze cele Nody RodneCislo, nasledne vytvori atribut RodneCislo u kazdeho hrace a nakonec vytvori element
 * id (jako nahradu za smazany atribut id)
 */
public class MyDomTransformer {

    private static final String VSTUPNI_SOUBOR = "data.xml";
    private static final String VYSTUPNI_SOUBOR = "data.out.xml";

    public static void main(String[] args) {
        
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setValidating(false);
            DocumentBuilder builder = dbf.newDocumentBuilder();
            Document doc = builder.parse(VSTUPNI_SOUBOR);
            MyDomTransformer mdt = new MyDomTransformer();
            mdt.transform(doc);
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer writer = tf.newTransformer();
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            writer.transform(new DOMSource(doc), new StreamResult(new File(VYSTUPNI_SOUBOR)));


        } catch (Exception e) {
            System.out.println("ERROR!");
            e.printStackTrace();
            
        }
    }
    
    /**
     * @author Petr
     * DOM nejprve smaze textovy obsah elementu RodneCislo, pote smaze atributy elementu MTGPlayer,
     * smaze cele Nody RodneCislo, nasledne vytvori atribut RodneCislo u kazdeho hrace a nakonec vytvori element
     * id (jako nahradu za smazany atribut id)
     */
	public void transform(Document doc) {
		// Smaze textovy obsah elementu RodneCislo
		NodeList IDs = doc.getElementsByTagName("RodneCislo");
		for (int i = 0; i < IDs.getLength(); i++) {
			Node x = IDs.item(i);
			NodeList list2 = x.getChildNodes();
			for (int j = 0; j < list2.getLength(); j++) {
				Node y = list2.item(j);
				x.removeChild(y);
			}
		}

		// Smazani attributu elementu MTGPlayer
		NodeList players = doc.getElementsByTagName("MTGPlayer");
		for (int i = 0; i < players.getLength(); i++) {
			Element player = (Element) players.item(i);

			NamedNodeMap atts = player.getAttributes();
			while (atts.item(0) != null) {
				player.removeAttribute(atts.item(0).getNodeName());
			}
		}

		// Smaze cele elementy RodneCislo
		for (int i = 0; i < players.getLength(); i++) {
			Element x = (Element) players.item(i);
			x.removeChild(x.getElementsByTagName("RodneCislo").item(0));

		}

		// Vytvori attribut RodneCislo u kazdeho hrace
		for (int i = 0; i < players.getLength(); i++) {
			Element player = (Element) players.item(i);
			player.setAttribute("RodneCislo", Long.toString(9005182714L + i));

		}

		// Vytvori elementy id
		for (int i = 0; i < players.getLength(); i++) {
			Element player = (Element) players.item(i);
			player.appendChild(doc.createElement("id"));
			player.getElementsByTagName("id").item(0).setTextContent("id" + Long.toString(0L + i));
		}
	}
}








