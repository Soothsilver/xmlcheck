package user;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MyDomTransformer {
	public void transform(Document xmlDocument) {
		// libovolne transformace objektu 'xmlDocument'
		// (metoda pracuje primo na objektu, nic nevraci)

		NodeList peopleList = xmlDocument.getElementsByTagName("people");
		if (peopleList.getLength() == 0) {
			return;
		}
		Node people = peopleList.item(0);
		List<Node> nodes = getStudentsAndTeachersElements(people);
		Comparator<Node> comparator = new TextContentComparator();
		Collections.sort(nodes, comparator);
		replaceOriginalNodes(people, nodes);
	}

	private void replaceOriginalNodes(Node people, List<Node> nodes) {
		for(Node n: nodes){
			people.appendChild(n);
		}
	}

	private List<Node> getStudentsAndTeachersElements(Node people) {
		List<Node> nodes = new ArrayList<Node>();
		NodeList teachersAndStudents = people.getChildNodes();
		for (int i = 0; i < teachersAndStudents.getLength(); i++) {
			Node person = teachersAndStudents.item(i);
			if (person.getNodeType() == Node.ELEMENT_NODE) {
				nodes.add(person);
			}
		}
		return nodes;
	}
	
	private class TextContentComparator implements Comparator<Node>{
		public int compare(Node o1, Node o2) {
			return o1.getTextContent().compareTo(o2.getTextContent());
		}
		
	}

}
