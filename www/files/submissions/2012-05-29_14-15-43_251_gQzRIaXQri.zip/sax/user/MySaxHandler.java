package user;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
	// override metod DefaultHandleru

	int totalElementNameLength = 0;
	int elementCount = 0;

	public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
		elementCount++;
		totalElementNameLength += localName.length();
	}

	public void endDocument() throws SAXException {
		System.out.println("average element name length: " + totalElementNameLength/(float)elementCount);
	}
}