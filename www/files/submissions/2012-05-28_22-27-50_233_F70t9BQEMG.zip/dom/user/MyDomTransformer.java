package user;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author Petr Babička
 */
public class MyDomTransformer {

    private Document root;

    public void transform(Document xmlDocument) {
        root = xmlDocument;
        // Transform address elements into attributes
        NodeList addresses = xmlDocument.getElementsByTagName("bydliste");
        TransformAddresses(addresses);

        // Add attribute into borrowed element
        // i didn't see attribute stav :)
        NodeList borrowed = xmlDocument.getElementsByTagName("vypujcka");
        TransformBorrowed(borrowed);

        // Replace element ctenar to reder name and surname 
        NodeList notes = xmlDocument.getElementsByTagName("poznamka");
        TransformNotes(notes);
    }

    /**
     * Transform all found notes
     *
     * @param notes Found notes
     */
    private void TransformNotes(NodeList notes) {
        for (int i = 0; i < notes.getLength(); ++i) {
            TransformNote(notes.item(i));
        }
    }

    /**
     * Replace element ctenar to reader name and surname
     *
     * @param note Transformed note, it's multielement
     */
    private void TransformNote(Node note) {
        String SEARCH_NAME = "ctenar";
        NodeList data = note.getChildNodes();
        // Find element ctenar
        for (int i = 0; i < data.getLength(); ++i) {
            Node actual_node = data.item(i);
            String name = actual_node.getNodeName();
            if (name.equals(SEARCH_NAME)) {
                TransformReader(actual_node);
            }
        }
    }

    /**
     * Replace element ctenar to TextNode with name and surname
     *
     * @param reader Element ctenar
     */
    private void TransformReader(Node reader) {
        Node reader_id_attr = reader.getAttributes().getNamedItem("cislo");
        if (reader_id_attr == null) {
            return;
        }
        String reader_id = reader_id_attr.getNodeValue();

        Node parent = reader.getParentNode();
        Node reader_name = GetReaderName(reader_id);
        parent.replaceChild(reader_name, reader);
    }

    /**
     * Return TextNode with reader name and surname using his id
     *
     * @param id Reader id
     * @return If found then return TextNode with name and surname else retun
     * TextNode with unknown name
     */
    private Node GetReaderName(String id) {
        NodeList readers = root.getElementsByTagName("ctenar");
        // Find right reder with given id
        for (int i = 0; i < readers.getLength(); ++i) {
            Node reader = readers.item(i);
            Node reader_id = reader.getAttributes().getNamedItem("cislo");
            if (reader_id != null) {
                if (reader_id.getNodeValue().equals(id)) {
                    NodeList reader_parts = reader.getChildNodes();
                    String name = "";
                    String surname = "";
                    // Find elements with name and surname
                    for (int j = 0; j < reader_parts.getLength(); ++j) {
                        if (reader_parts.item(j).getNodeName().equals("jmeno")) {
                            name = reader_parts.item(j).getFirstChild().getNodeValue();
                        } else if (reader_parts.item(j).getNodeName().equals("prijmeni")) {
                            surname = reader_parts.item(j).getFirstChild().getNodeValue();
                        }
                    }
                    return root.createTextNode(String.format("%s %s", name, surname));
                }
            }
        }
        return root.createTextNode("Neznamy ctenar");
    }

    /**
     * Transform all found borrowed
     *
     * @param borrowed Found brrowed
     */
    private void TransformBorrowed(NodeList borrowed) {
        for (int i = 0; i < borrowed.getLength(); ++i) {
            TransformBorrow(borrowed.item(i));
        }
    }

    /**
     * Check if is borrow returned
     *
     * @param borrow Selected borrow
     * @return If is returned then true else false
     */
    private boolean IsReturned(Node borrow) {
        String SEARCH_NAME = "vraceno";
        NodeList borrow_parts = borrow.getChildNodes();
        for (int i = 0; i < borrow_parts.getLength(); ++i) {
            String name = borrow_parts.item(i).getNodeName();
            if (name.equals(SEARCH_NAME)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Add attribute color into selected borrow. If is return then add green
     * color else red color
     *
     * @param borrow Selected borrow
     */
    private void TransformBorrow(Node borrow) {
        Attr color = root.createAttribute("color");
        if (IsReturned(borrow) == true) {

            color.setValue("green");
        } else {
            color.setValue("red");
        }
        borrow.getAttributes().setNamedItem(color);
    }

    /**
     * Transform all found addresses
     *
     * @param addresses Found addresses
     */
    private void TransformAddresses(NodeList addresses) {
        for (int i = 0; i < addresses.getLength(); ++i) {
            TransformAddress(addresses.item(i));
        }
    }

    /**
     * Transform all address elements into address attributes
     *
     * @param address Selected address
     */
    private void TransformAddress(Node address) {
        NodeList address_parts = address.getChildNodes();
        for (int i = 0; i < address_parts.getLength(); ++i) {
            Node actual_part = address_parts.item(i);
            if (actual_part.getNodeType() == Node.ELEMENT_NODE) {
                String name = actual_part.getNodeName();
                Attr attribute = root.createAttribute(name);
                String value = actual_part.getFirstChild().getNodeValue();
                attribute.setValue(value);
                address.getAttributes().setNamedItem(attribute);
                address.removeChild(actual_part);
            }

        }
    }
}
