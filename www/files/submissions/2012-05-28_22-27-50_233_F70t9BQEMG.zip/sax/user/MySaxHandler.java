/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.util.Stack;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * @author Petr Babicka
 */
public class MySaxHandler extends DefaultHandler {
    Locator locator;
    Stack<ElementStatistic> elements = new Stack<ElementStatistic>();
    int deep = -1;
    int maxDeep = -1;
    int leafCount = 0;
    int leafDeepSum = 0;
    /**
     * Holder of element information
     */
    class ElementStatistic {

        private String elementPath;
        private int subElementCount;
        private int argumentsCount;
        private int elementDeep;

        public ElementStatistic(String elementPath, int argumentsCount, int elementDeep) {
            this.subElementCount = 0;
            this.argumentsCount = argumentsCount;
            this.elementPath = elementPath;
            this.elementDeep = elementDeep;
        }
        
        public void IncSubElementCount() {
            ++subElementCount;
        }
        
        public int GetSubElementCount() {
            return subElementCount;
        }
        
        public int GetArgumentsCount() {
            return argumentsCount;
        }
        
        public String GetPath() {
            return elementPath;
        }
        
        public void AddElementData(ElementStatistic element) {
            this.argumentsCount += element.GetArgumentsCount();
            this.subElementCount += element.GetSubElementCount();
        }
        
        public boolean IsLeaf() {            
            return GetSubElementCount() == 0;
        }
        
        @Override
        public String toString() {
            String description = String.format("%s%s in deep %d: %d subelements, %d arguments in me and subelements",
                    GetTabs(deep), elementPath, elementDeep, subElementCount, argumentsCount);
            return description;
        }
        
        private String GetTabs(int tabs) {
            StringBuilder tabs_string = new StringBuilder();
            for (int i = 0; i < tabs; ++i) {
                tabs_string.append("  ");
            }
            //return tabs_string.toString();
            return "";
        }
    }

    /**
     * Nastavi locator
     */    
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    /**
     * Obsluha udalosti "zacatek dokumentu" Inicializace dat
     */    
    @Override
    public void startDocument() throws SAXException {
        // Nejvyssi dokument, pod kterym jsou vsichni
        elements.push(new ElementStatistic("", 0, deep));
    }

    /**
     * Obsluha udalosti "konec dokumentu" Vypis vsech namerenych statistik
     */    
    @Override
    public void endDocument() throws SAXException {
        --deep;
        System.out.println(elements.pop());
        System.out.println(String.format("Maximalni hloubka: %d", maxDeep));
        System.out.println(String.format("Pocet listu: %d; celkova hloubka listu: %d; Prumerna hloubka listu: %d", leafCount, leafDeepSum, leafDeepSum / leafCount));
    }

    /**
     * Obsluha udalosti "zacatek elementu".
     *
     * @param uri URI jmenneho prostoru elementu (prazdne, pokud element není v
     * zadnem jmenném prostoru)
     * @param localName Lokalni jmeno elementu (vzdy neprazdne)
     * @param qName Kvalifikovane jméno (tj. prefix-uri + ':' + localName, pokud
     * je element v nejakem jmennem prostoru, nebo localName, pokud element neni
     * v zadnem jmennem prostoru)
     * @param atts Atributy elementu
     */    
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        ++deep;
        // Rodic ma o jeden alement navic
        elements.peek().IncSubElementCount();
        // Spracovavanym je aktualni element
        elements.push(new ElementStatistic(elements.peek().GetPath()+"/"+qName, atts.getLength(), deep));
    }

    /**
     * Obsluha udalosti "konec elementu" Parametry maji stejny vyznam jako u
     *
     * @see startElement
     */    
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        // Get last opened element
        ElementStatistic lastElement = elements.pop();
        System.out.println(lastElement);

        // Compute maximal deep
        maxDeep = deep > maxDeep ? deep : maxDeep;

        // Compute leafs
        if (lastElement.IsLeaf()) {
            ++leafCount;
            leafDeepSum += deep;
        }

        // Update parent element
        elements.peek().AddElementData(lastElement);

        // Decrease deep
        --deep;
    }
}
