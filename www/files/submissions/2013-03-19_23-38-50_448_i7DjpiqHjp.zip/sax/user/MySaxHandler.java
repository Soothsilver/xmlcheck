/**
 * Charakteristika dokumentu:
 * - Vypise pocet nabizenych sypanych a sackovych caju.
 * - Vypise prumernou cenu polozek na listku.
 * - Vypise nazev nejdrazsiho vina.
 * - Vypise nazev piv, ktera maji min nez 0,5l a jsou drazsi, nez 29 Kc.
 */

package user;

import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.SAXException;
import org.xml.sax.Locator;

class AttributeHandler {
	int countOfLeavesTea = 0;
	int countOfBagTea = 0;
	
	public void riseLeavesTeaCount() {
		this.countOfLeavesTea++;
	}
	
	public void riseBagTeaCount() {
		this.countOfBagTea++;
	}
	
	public String toString() {
		String returnString = new String("Pocet nabizenych sypanych caju je " + this.countOfLeavesTea + " a pocet nabizenych sackovych caju je " + this.countOfBagTea + ".");
		return returnString;
	}
}

class ElementHandler {
	int countOfPrice = 0;
	int sumOfPrices = 0;
	int mostExpensivePrice = 0;
	
	float currentVolume = 0;
	
	String mostExpensiveItem = "";
	public String currentItemName = "";
	public String currentItemYear = "";
	String expensiveBeer = "";

	public Boolean isInBeerEl = false;
	public Boolean isInWineEl = false;
	public Boolean isInPriceEl = false;
	public Boolean isInNameEl = false;
	public Boolean isInYearEl = false;
	public Boolean isInVolEl = false;
	
	public void addPrice(int price) {
		this.countOfPrice++;
		this.sumOfPrices += price;
		
		if (price > mostExpensivePrice) {
			this.mostExpensivePrice = price;
			this.mostExpensiveItem = this.currentItemName + " " + this.currentItemYear;
		}
		
		if (price > 29 && this.currentVolume < 0.5f && this.isInBeerEl) {
			this.expensiveBeer += this.currentItemName + " ";
		}
	}
	
	public void setVolume(String vol) {
		String[] vol_words = vol.split(" ");
		this.currentVolume = Float.parseFloat(vol_words[0]);
	}
	
	public void addPrice(String price) {
		String[] price_words = price.split(" ");
		this.addPrice(Integer.parseInt(price_words[0]));
	}
	
	public String toString() {
		String returnString = new String("Prumerna cena polozek v jidelnim listku je " + (this.sumOfPrices/(float)this.countOfPrice) + ".\n");
		returnString += "Nejdrazsi vino je " + this.mostExpensiveItem + ".\n";
		returnString += "Piva mensi nez 0.5 litru a drazsi nez 29 Kc jsou: " + this.expensiveBeer + ".\n";
		return returnString;
	}
}

public class MySaxHandler extends DefaultHandler {
	private Locator locator;
	private AttributeHandler attHandler = new AttributeHandler();
	private ElementHandler elHandler = new ElementHandler();
	
    @Override
    public void setDocumentLocator(Locator locator) {
        this.locator = locator;
    }

    @Override
    public void startDocument() throws SAXException {
    }

    @Override
    public void endDocument() throws SAXException {
    	System.out.println(attHandler.toString());
    	System.out.println(elHandler.toString());
    }
    
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
    	if (localName.equals("caj")) {
            String type = atts.getValue("typ");
            if (type.equals("s��kov�")) {
                attHandler.riseBagTeaCount();
            } else if (type.equals("sypan�")) {
            	attHandler.riseLeavesTeaCount();            	
            }
        }
    	
    	if (localName.equals("cena")) {
    		elHandler.isInPriceEl = true;
    	} else if (localName.equals("vino")) {
    		elHandler.isInWineEl = true;
    	} else if (localName.equals("nazev")) {
    		elHandler.isInNameEl = true;
    	} else if (localName.equals("rocnik")) {
    		elHandler.isInYearEl = true;
    	} else if (localName.equals("pivo")) {
    		elHandler.isInBeerEl = true;
    	} else if (localName.equals("mnozstvi")) {
    		elHandler.isInVolEl = true;
    	}
    }

    
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
    	if (localName.equals("cena")) {
    		elHandler.isInPriceEl = false;
    	} else if (localName.equals("vino")) {
    		elHandler.isInWineEl = false;
    	} else if (localName.equals("nazev")) {
    		elHandler.isInNameEl = false;
    	} else if (localName.equals("rocnik")) {
    		elHandler.isInYearEl = false;
    	} else if (localName.equals("pivo")) {
    		elHandler.isInBeerEl = false;
    	} else if (localName.equals("mnozstvi")) {
    		elHandler.isInVolEl = false;
    	}
    }

    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
    	if (elHandler.isInPriceEl) {
    		String price = new String(chars, start, length);
    		elHandler.addPrice(price);
    		elHandler.isInPriceEl = false;
    	} else if (elHandler.isInNameEl) {
    		String name = new String(chars, start, length);
    		elHandler.currentItemName = name;
    	} else if (elHandler.isInWineEl && elHandler.isInYearEl) {
    		String year = new String(chars, start, length);
    		elHandler.currentItemYear = year;
    	} else if (elHandler.isInBeerEl && elHandler.isInVolEl) {
    		String vol = new String(chars, start, length);
    		elHandler.setVolume(vol);
    		elHandler.isInVolEl = false;
    	}
    }

    
    @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
    }

    @Override
    public void endPrefixMapping(String prefix) throws SAXException {
    }

    @Override
    public void ignorableWhitespace(char[] chars, int start, int length) throws SAXException {
    }

    @Override
    public void processingInstruction(String target, String data) throws SAXException {
    }

    @Override
    public void skippedEntity(String name) throws SAXException {
    }
}