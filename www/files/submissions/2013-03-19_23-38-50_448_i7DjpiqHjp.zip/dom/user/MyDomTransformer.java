/**
 Uprava XML:
  - Pridani noveho druhu specialniho piva.
  - Nastavi vsechny oteviraci doby od 11:00 do 4:00.
  - Seradi vina a sestupne podle ceny.
 */

package user; 

import org.w3c.dom.Document; 
import org.w3c.dom.Element; 
import org.w3c.dom.Attr;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.Collections;
import java.util.Comparator;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MyDomTransformer { 
	
	public void transform (Document xmlDocument) {
		
		// Pridani noveho piva
		Element newName = xmlDocument.createElement("nazev");
		newName.setTextContent("Ultrapivo");
		
		Element newDeg = xmlDocument.createElement("stupen");
		newDeg.setTextContent("16");
		
		Element newVol = xmlDocument.createElement("mnozstvi");
		newVol.setTextContent("0.6 l");
		
		Element newPrice = xmlDocument.createElement("cena");
		newPrice.setTextContent("32 K�");
		
		org.w3c.dom.Element newBeer = xmlDocument.createElement("pivo");
		newBeer.appendChild(newName);
		newBeer.appendChild(newDeg);
		newBeer.appendChild(newVol);
		newBeer.appendChild(newPrice);
		Attr at = xmlDocument.createAttribute("id");
		at.setNodeValue("p17");
		newBeer.setAttributeNode(at);
		
		xmlDocument.getElementsByTagName("specialni").item(0).appendChild(newBeer);
		
		// Nastaveni nove otviraci doby
		NodeList els = xmlDocument.getElementsByTagName("co");
		for (int i = 0; i < els.getLength(); i++) {
			Element newOt = xmlDocument.createElement("otevreno");
			Element newOd = xmlDocument.createElement("od");
			newOd.setTextContent("11:00:00");
			Element newDo = xmlDocument.createElement("do");
			newDo.setTextContent("04:00:00");
			newOt.appendChild(newOd);
			newOt.appendChild(newDo);
			
			while (els.item(i).getChildNodes().getLength() >= 1)
		    {
				els.item(i).removeChild(els.item(i).getFirstChild());       
		    } 
			els.item(i).appendChild(newOt);
		}
		
		// Serazeni vina podle ceny
		NodeList wines = xmlDocument.getElementsByTagName("vino");
		List nodes = new ArrayList();
		for (int i = 0; i < wines.getLength(); i++) {
			nodes.add(wines.item(i));
		}
		Comparator comp = new WineNodesComparator();
		Collections.sort(nodes, Collections.reverseOrder(comp));
		Node winesNode = xmlDocument.getElementsByTagName("vina").item(0);
		for (Iterator iter = nodes.iterator(); iter.hasNext();) {
			Node element = (Node) iter.next();
			winesNode.appendChild(element);
		}
	}
}

class WineNodesComparator implements Comparator {
	public int compare(Object wine1, Object wine2) {
		Element nWine1 = (Element)wine1;
		NodeList els = nWine1.getChildNodes();
		String strPrice1 = "";
		for (int i = 0; i < els.getLength(); i++) {
			if (els.item(i).getNodeName().equals("cena")) {
				Node el = els.item(i);
				String nValue = el.getTextContent();
				strPrice1 = nValue.split(" ")[0];
			}
		}
		Integer price1 = Integer.parseInt(strPrice1);

		Element nWine2 = (Element)wine2;
		els = nWine2.getChildNodes();
		String strPrice2 = "";
		for (int i = 0; i < els.getLength(); i++) {
			if (els.item(i).getNodeName().equals("cena")) {
				Node el = els.item(i);
				String nValue = el.getTextContent();
				strPrice2 = nValue.split(" ")[0];
			}
		}
		Integer price2 = 0;
		price2 = Integer.parseInt(strPrice2);
		
		return price1.compareTo(price2);
	}
 
}