package user;

import org.w3c.dom.*;

/*import java.io.File;
import java.io.FileInputStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.xml.sax.InputSource;*/

public class MyDomTransformer {

	public void transform(Document doc) {
		/*** prejmenuje korenovy element z "root" na "main"... */
		// soucasny korenovy element
		Element root = doc.getDocumentElement();
		// novy -||-
		Element newRoot = doc.createElement("main");

		// presuneme vsechny potomky do noveho korene
		while(root.hasChildNodes()) {
			Node node = root.getFirstChild();
			newRoot.appendChild(node);
		}
		
		// nahradime stary koren novym
		root.getParentNode().replaceChild(newRoot, root);
		
		// vsechny elementy jmenem "element"
		final NodeList elements = doc.getElementsByTagName("element");
		// prevedeme obsah jejich atributu "attribute" na text elementu a naopak
		for(int i = 0; i < elements.getLength(); i++) {
			Node node = elements.item(i);
			Node attr = node.getAttributes().getNamedItem("attribute");
			
			String attrValue = attr.getTextContent();
			String textValue = node.getTextContent();
			
			attr.setTextContent(textValue);
			node.setTextContent(attrValue);
		}

		/*** vsechny elementy "value" v elementu "group" prevede na jiny format, napr.
		 * vstup: <item attribute="align" elemName="p">justify</item>
		 * vystup: <p align="justify">text [n]</p>
		 */
		Node group = doc.getElementsByTagName("group").item(0);
		Node html = doc.createElement("html");
		final NodeList items = group.getChildNodes();
		for (int i = 0; i < items.getLength(); i++) {
			Node item = items.item(i);
			
			if (!"item".equals(item.getNodeName()))
				continue;
			
			NamedNodeMap attributes = item.getAttributes();

			String attrValue = attributes.getNamedItem("attribute").getTextContent();
			String elemName = attributes.getNamedItem("elemName").getTextContent();
			String textValue = item.getTextContent();
			
			Element e = doc.createElement(elemName);
			e.setAttribute(attrValue, textValue);
			e.setTextContent("text " + (i/2+1));
			
			html.appendChild(e);
		}
		newRoot.replaceChild(html, group);

		/*** prevede seznam list/value na ul/li */
		Node list = doc.getElementsByTagName("list").item(0);
		final NodeList values = list.getChildNodes();
		Node ul = doc.createElement("ul");
		for (int i = 0; i < values.getLength(); i++) {
			Node value = values.item(i);
			if (!"value".equals(value.getNodeName()))
				continue;
			Element li = doc.createElement("li");
			li.setTextContent(value.getTextContent());
			ul.appendChild(li);
		}
		newRoot.replaceChild(ul, list);

		doc.setXmlStandalone(true);
	}

	/*public Document loadXMLFromFile(String fileName) throws Exception {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

		factory.setNamespaceAware(true);
		DocumentBuilder builder = factory.newDocumentBuilder();

		// :-)
		return builder.parse(new InputSource(new FileInputStream(new File(fileName))));
	}

	public void saveXMLToFile(Document doc, String fileName) throws Exception {
		Source source = new DOMSource(doc);

		File file = new File(fileName);
		Result result = new StreamResult(file);

		Transformer writer = TransformerFactory.newInstance().newTransformer();
		writer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
		writer.setOutputProperty(OutputKeys.INDENT, "yes");
		writer.transform(source, result);
	}

	public static void main(String[] args) throws Exception {
		if (args.length != 2) {
			System.err.println("usage: dom-nb [infile] [outfile]");
			System.exit(args.length);
		}

		MyDomTransformer t = new MyDomTransformer();
		Document doc = t.loadXMLFromFile(args[0]);
		t.transform(doc);
		t.saveXMLToFile(doc, args[1]);
	}*/
}
