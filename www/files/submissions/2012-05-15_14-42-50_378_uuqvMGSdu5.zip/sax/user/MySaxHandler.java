package user;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/*import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;*/

public class MySaxHandler extends DefaultHandler {

	private int elemCount, attrCount;
	private int elemWithAttrCount;
	private final Map<String, Integer> elemOccurrences = new HashMap<String, Integer>();
	private final Map<String, Integer> attrOccurrences = new HashMap<String, Integer>();
	private final Map<String, Integer> elemChildren = new HashMap<String, Integer>();
	private final Stack<String> stackPath = new Stack<String>();

	private String stackToXPath() {
		final int len = stackPath.size();
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < len; i++) {
			sb.append('/');
			sb.append(stackPath.get(i));
		}

		return sb.toString();
	}

	@Override
	public void endDocument() throws SAXException {
		System.out.println("Pocet elementu: " + elemCount);
		System.out.println("Pocet atributu: " + attrCount);
		System.out.println("Pocet elementu s atributy: " + elemWithAttrCount);

		Set<String> keys = elemOccurrences.keySet();
		int tmpMax = 0;
		String moElem = "";
		for (String key : keys) {
			int cnt = elemOccurrences.get(key);
			if (cnt > tmpMax) {
				tmpMax = cnt;
				moElem = key;
			} else if (cnt == tmpMax) {
				// je-li nejcastejsich elementu vice, vypiseme je vsechny, oddelene carkou
				moElem += ", " + key;
			}
		}

		System.out.println("Nejcastejsi element(y): " + (moElem.equals("") ? "(zadny)" : moElem));

		keys = elemChildren.keySet();
		tmpMax = 0;
		moElem = "";
		for (String key : keys) {
			int cnt = elemChildren.get(key);
			if (cnt > tmpMax) {
				tmpMax = cnt;
				moElem = key;
			} else if (cnt == tmpMax) {
				moElem += ", " + key;
			}
		}

		System.out.println("XPath cesty elementu s nejvetsim poctem (" + tmpMax + ") primych potomku: " + moElem);
	}

	@Override
	public void startElement(String namespaceURI, String localName, String qName, Attributes attrs) throws SAXException {
		// pocet atributu, ktere ma tento element
		final int attrLen = attrs.getLength();

		// navysime pocet elementu v dokumentu
		elemCount++;
		// navysime pocet atributu v dokumentu
		attrCount += attrLen;

		// pokud ma element nejake atributy, navysime pocet elementu s atributy
		if (attrLen > 0) {
			elemWithAttrCount++;
		}

		// navysime pocet elementu s danym nazvem
		Integer occurr = elemOccurrences.get(qName);
		elemOccurrences.put(qName, occurr == null ? 1 : occurr + 1);

		// navysime pocet atributu s danymi nazvy
		for (int i = 0; i < attrLen; i++) {
			String attrName = attrs.getQName(i);
			occurr = elemOccurrences.get(qName);
			attrOccurrences.put(attrName, occurr == null ? 1 : occurr + 1);
		}

		// ulozime si do stacku cestu k aktualnimu elementu
		stackPath.add(qName);
	}

	@Override
	public void endElement(String namespaceURI, String localName, String qName) throws SAXException {
		String top = stackPath.peek();

		if (top == null) {
			return;
		}

		// upravime ve stacku aktualni pozici v dokumentu
		while (!stackPath.isEmpty()) {
			if (localName.equals(stackPath.pop())) {
				break;
			}
		}

		// aktualizujeme informaci o poctu primych potomku elementu v dane ceste
		final String key = stackToXPath();
		Integer occurr = elemChildren.get(key);
		elemChildren.put(key, occurr == null ? 1 : occurr + 1);
	}

	/*public void run() throws Exception {
		String sourcePath = "../data.xml";

		XMLReader parser = XMLReaderFactory.createXMLReader();
		InputSource source = new InputSource(sourcePath);
		parser.setContentHandler(this);

		parser.parse(source);
	}

	public static void main(String[] args) throws Exception {
		new MySaxHandler().run();
	}*/
}
