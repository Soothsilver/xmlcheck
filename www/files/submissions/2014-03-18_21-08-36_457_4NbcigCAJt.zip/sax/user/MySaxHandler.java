package user;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.LinkedList;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
    /**
     * Method to handle "document start"
     *
     * @throws SAXException
     */

    private LinkedList<String> path;
    private ArrayList<String> czechCustomers;
    private ArrayList<String> foreignCustomers;
    private int czechRentals;
    private int foreignRentals;
    private String currentCustomer;
    private int rentalCount;
    private long rentalTime;
    private SimpleDateFormat sdparse;
    private int[] prices;
    
    @Override
    public void startDocument() throws SAXException {
        rentalCount = 0;
        rentalTime = 0;
        path = new LinkedList<String>();
        
        czechCustomers = new ArrayList<String>();
        foreignCustomers = new ArrayList<String>();
        
        czechRentals = 0;
        foreignRentals = 0;
        
        currentCustomer = "";
        
        sdparse = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        
        prices = new int[6];
    }

    /**
     * Method to handle "document end"
     *
     * @throws SAXException
     */
    @Override
    public void endDocument() throws SAXException {
        long totalMinutes = (rentalTime / rentalCount) / 60;
        long minutes = totalMinutes % 60;
        long totalHours = totalMinutes / 60;
        long hours = totalHours % 24;
        long days = totalHours / 24;
        System.out.println("Average rental time: " + days + "d " + hours + "h "+ minutes + "m");
        System.out.println("You have "+czechCustomers.size()+" Czech customer(s) who rented "+czechRentals+" bike(s)");
        System.out.println("     and "+foreignCustomers.size()+" foreign customer(s) who rented "+foreignRentals+" bike(s)");
        int exp = prices[0] + prices[1];
        int mid = prices[2] + prices[3];
        int chp = prices[4] + prices[5];
        String priceClass;
        if (exp >= mid && exp >= chp)
        {
            priceClass = "expensive";
        }
        else if (mid >= exp && mid >= chp)
        {
            priceClass = "middle-class";
        }
        else
        {
            priceClass = "cheap";
        }
        System.out.println("You mostly rent " + priceClass + " bikes.");
    }

    /**
     * Method to handle "begin element"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        path.push(qName);
        if ("customer".equals(qName))
                currentCustomer = atts.getValue("id");
        if ("reservations".equals(qName));
                currentCustomer = atts.getValue("cust-id");
        if ("reservation".equals(qName))
        {
            if (czechCustomers.contains(currentCustomer))
            {
                czechRentals++;
            }
            else
            {
                foreignRentals++;
            }
            int priceClass = atts.getValue("price-class").charAt(0) - (int)'A';
            prices[priceClass]++;
        }
    }

    /**
     * Method to handle "element end"
     *
     * @param uri URI of the element namespace (empty if element is no
     * namespace)
     * @param localName local name of the element (never empty)
     * @param qName qualified name (prefix-URI + ':' + localName, if the element
     * is in some namespace or localName otherwise)
     * @param atts Element's attributes
     * @throws SAXException
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        path.pop();
    }

    /**
     * Method to handle "character data" SAX parser can process data in various
     * batches. so we can't rely that whole whole text content will be delivered
     * in one call Text is in array 'chars' from position ('start') to ('start'
     * + 'length' - 1)
     *
     * @param chars Array with char data
     * @param start Index of the begin of valid data
     * @param length Length of the valid data
     * @throws SAXException
     */
    @Override
    public void characters(char[] chars, int start, int length) throws SAXException {
        String currentElement = path.peek();
        try {
            if ("pick-up-time".equals(currentElement))
            {
                rentalTime -= sdparse.parse(new String(chars, start, length)).getTime()/1000;
                rentalCount++;
            }
            if ("return-time".equals(currentElement))
                    rentalTime += sdparse.parse(new String(chars, start, length)).getTime()/1000;
        }
        catch (ParseException pe){};
        if ("country".equals(currentElement))
        {
            if ("Czech Republic".equals(new String(chars, start, length)))
            {
                czechCustomers.add(currentCustomer);
            }
            else
            {
                foreignCustomers.add(currentCustomer);
            }
        }
    }

}