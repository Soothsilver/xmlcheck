package user;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;
import java.util.ArrayList;
import java.util.Random;

public class MyDomTransformer {
	public void transform (Document xmlDocument) {
        // Transformace 1: Smaže všechny zákazníky z ciziny a jejich rezervace.
        NodeList countries = xmlDocument.getElementsByTagName("country");
        ArrayList<String> foreigners = new ArrayList<String>();
        for (int i = countries.getLength() - 1; i >= 0; i--)
        {
            Element country = (Element) countries.item(i);
            if (!("Czech Republic".equals(country.getTextContent())))
            {
                Element customer = (Element) country.getParentNode().getParentNode();
                foreigners.add(customer.getAttribute("id"));
                customer.getParentNode().removeChild(customer);
            }
        }
        NodeList reservationsList = xmlDocument.getElementsByTagName("reservations");
        for (int i = countries.getLength() - 1; i >= 0; i--)
        {
            Element reservation = (Element) reservationsList.item(i);
            if (foreigners.contains(reservation.getAttribute("id")))
            {
                reservation.getParentNode().removeChild(reservation);
            }
        }
        
        // Transformace 2: Vloží nového zákazníka a přidá mu jednu rezervaci.
        Element bikeRental = xmlDocument.getDocumentElement();

        Random rand = new Random();
        String custId = "cust" + Math.abs(rand.nextInt());
        while (xmlDocument.getElementById(custId) != null)
        {
            custId = "res" + Math.abs(rand.nextInt());
        }
        String resId = "res" + Math.abs(rand.nextInt());
        while (xmlDocument.getElementById(custId) != null)
        {
            custId = "res" + Math.abs(rand.nextInt());
        }
        
        Element customer = xmlDocument.createElement("customer");
        customer.setAttribute("id", custId);
        Element address = (Element)customer.appendChild(xmlDocument.createElement("address"));
        
        address.appendChild(xmlDocument.createElement("street")).setTextContent("Freedom Avenue 1");
        address.appendChild(xmlDocument.createElement("post-code")).setTextContent("123 45");
        address.appendChild(xmlDocument.createElement("city")).setTextContent("Washington, DC");
        address.appendChild(xmlDocument.createElement("country")).setTextContent("United States");
        
        customer.appendChild(xmlDocument.createElement("phone-number")).setTextContent("+10244524785");
        
        Element reservations = xmlDocument.createElement("reservations");
        reservations.setAttribute("cust-id", custId);
        Element reservation = (Element)reservations.appendChild(xmlDocument.createElement("reservation"));
        reservation.setAttribute("id", resId);
        reservation.setAttribute("price-class", "B");
        reservation.setAttribute("bike-type", "offroad");
        
        reservation.appendChild(xmlDocument.createElement("rental-code")).setTextContent("786757");
        reservation.appendChild(xmlDocument.createElement("pick-up-time")).setTextContent("2014-01-03 10:00");
        reservation.appendChild(xmlDocument.createElement("return-time")).setTextContent("2014-01-15 09:00");
        reservation.appendChild(xmlDocument.createElement("identity-card-number")).setTextContent("What's an identity card? You mean social security number?");
        reservation.appendChild(xmlDocument.createElement("biker-name")).setTextContent("John Doe");
        reservation.appendChild(xmlDocument.createElement("bike-reg-number")).setTextContent("486756435");
        reservation.appendChild(xmlDocument.createElement("bike-maker")).setTextContent("Author");
        
        NodeList existingReservations = xmlDocument.getElementsByTagName("reservations");
        if (existingReservations.getLength() == 0)
        {
            bikeRental.appendChild(customer);
            bikeRental.appendChild(reservations);
        }
        else
        {
            bikeRental.insertBefore(customer, existingReservations.item(0));
            bikeRental.insertBefore(reservations, existingReservations.item(0));
        }
	}
}