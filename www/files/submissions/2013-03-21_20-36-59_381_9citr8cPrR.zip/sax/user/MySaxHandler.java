package user;
/*
 * Pomoci SAX jsou pocitany 3 charakteristiky dat:
 * 1. Pocet vypujcenych/ nevypujcenych knih (hodnoty atributu)
 * 2. Prumerny rok vydani knihy
 * 3. Pocet vypujcenych ceskych knih
 */

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

public class MySaxHandler extends DefaultHandler {

    public static void main(String args[]) throws Exception {
        XMLReader xr = XMLReaderFactory.createXMLReader();
        MySaxHandler handler = new MySaxHandler();
        xr.setContentHandler(handler);
        xr.setErrorHandler(handler);
        InputSource source = new InputSource("data.xml");
        xr.parse(source);



    }
    int depth = 0;
    //promenne urcujici pocet vypujcenych exemplarua a pocet exemplaru v knihovne   
    int vypujceno = 0;
    int vknihovne = 0;
    //urcuje, zda-li jsme v elementu rokvydani
    boolean jerokvydani = false;
    //pocitani knih a scitani roku vydani pro spocitani prumeru
    int pocetknih = 0;
    int rokvydani = 0;
    //pro pocitani ceskych vypujcenych knih
    boolean dalsikniha = false;
    boolean jevypujcena = false;
    boolean jazyk = false;
    int vypujcenoCeskych = 0;

    void printWithDepth(String s) {
        for (int i = 0; i < depth; i++) {
            System.out.print("  ");
        }
        System.out.println(s);
    }

    @Override
    public void startDocument() {
    }

    @Override
    public void endDocument() {


        System.out.println("Celkove je pujceno " + vypujceno + " knih a v knihovne jich je " + vknihovne + ".");

        System.out.println("Prumerny rok vydani je: " + (rokvydani / pocetknih));

        System.out.println("Prave je vypujceno " + vypujcenoCeskych + " knih v ceskem jazyce.");
    }

    @Override
    public void startElement(String uri, String localName,
            String qName, Attributes atts) {
        if (localName.equals("exemplar")) {
            dalsikniha = true;
        }
        for (int i = 0; i < atts.getLength(); i++) {
            String name = atts.getLocalName(i);
            String val = atts.getValue(i);
            //     printWithDepth("<" + name + ">" + val + "</" + name + ">");

            if (name.equals("vypujcen")) {
                if (val.equals("true")) {
                    vypujceno++;
                    jevypujcena = true;
                } else {
                    vknihovne++;
                }
            }

        }
        if (localName.equals("rokvydani")) {
            pocetknih++;
            jerokvydani = true;
        }
        if (localName.equals("jazyk")) {
            jazyk = true;
        }
        //    printWithDepth("<" + localName + ">");
        {
            depth++;
        }

    }

    @Override
    public void endElement(String uri, String localName, String qName) {
        if (localName.equals("rokvydani")) {
            jerokvydani = false;
        }
        if (localName.equals("jazyk")) {
            jazyk = false;
        }
        if (localName.equals("exemplar")) {
            dalsikniha = false;
        }
        depth--;

        //    printWithDepth("</" + localName + ">");
    }

    @Override
    public void characters(char chars[], int start, int length) {
        String s = new String(chars, start, length).trim();
        if (s.length() > 0) {
            //        printWithDepth(new String(chars, start, length).toUpperCase().trim());
        }
        //pocitani roku vydani
        if (jerokvydani) {
            if (s.length() > 0) {
                int i = Integer.parseInt(s);
                rokvydani += i;
            }
        }
        //pocitani pujcenych ceskych knih
        if (jazyk && dalsikniha) {

            if (s.equals("cs") && jevypujcena) {
                vypujcenoCeskych++;
            }
            jevypujcena = false;

        }
    }
}
