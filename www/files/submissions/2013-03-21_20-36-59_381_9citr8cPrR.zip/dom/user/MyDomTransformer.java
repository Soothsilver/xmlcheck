/*
 * Pomoci DOM jsou provadeny 2 upravz dokumentu
 * 1. Pridani uzivatele se vsemi atributy
 * 2. Odstraneni exemplare s datem vydani mensim nez 1970
 *
 */
package user;

import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author Tom
 */
public class MyDomTransformer {

    public void transform(Document xmlDocument) throws TransformerConfigurationException, TransformerException {
        //root uzel
        Node knihovna = xmlDocument.getElementsByTagName("knihovna").item(0);

        //pridani uzivatele se vsemi atributy
        Element uzivatel = xmlDocument.createElement("uzivatel");
        uzivatel.setAttribute("id", "U3");
        Element username = xmlDocument.createElement("username");
        username.setAttribute("username", "user123");
        uzivatel.appendChild(username);
        Element jmeno = xmlDocument.createElement("jmeno");
        uzivatel.appendChild(jmeno);
        jmeno.appendChild(xmlDocument.createElement("krestni")).setTextContent("Pepa");
        jmeno.appendChild(xmlDocument.createElement("prijmeni")).setTextContent("Z Depa");
        Element datumNarozeni = xmlDocument.createElement("datumnarozeni");
        uzivatel.appendChild(datumNarozeni);
        datumNarozeni.appendChild(xmlDocument.createElement("den")).setTextContent("01");
        datumNarozeni.appendChild(xmlDocument.createElement("mesic")).setTextContent("01");
        datumNarozeni.appendChild(xmlDocument.createElement("rok")).setTextContent("1992");
        knihovna.appendChild(uzivatel);

        
        //mazani vsech exemplaru starsich nez rok 1970
        NodeList list = xmlDocument.getElementsByTagName("exemplar");
        for (int i = list.getLength() - 1; i >= 0; i--) {
            Node node = list.item(i);

            Element exemp = (Element) node;

            String s = exemp.getElementsByTagName("rokvydani").item(0).getTextContent();
            int rok = Integer.parseInt(s);
            System.out.println(rok);
            if (rok < 1970) {
                exemp.getParentNode().removeChild(node);
            }


        }

      


//        TransformerFactory transformerFactory = TransformerFactory.newInstance();
//        Transformer transformer = transformerFactory.newTransformer();
//        DOMSource source = new DOMSource(xmlDocument);
//        StreamResult result = new StreamResult(new File("data1.xml"));
//        transformer.transform(source, result);




        // libovolne transformace objektu 'xmlDocument'
        // (metoda pracuje primo na objektu, nic nevraci)
    }
}
