/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package user;

/**
 *
 * @author Zden�k
 */
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import org.w3c.dom.*;

public class MyDomTransformer { 
   
    public void transform (Document xmlDocument) 
    { // code transforming xmlDocument object // (method works on the object itself - no return value) 
        
       List<Element> zboziAll = GetAllZbozi(xmlDocument);
       Random r = new Random();
       
       // Vyber zbozi, ktere prodam
       Element zbozi = SelectZbozi(zboziAll);
       // Kub zbozi - tj. vytvor nakup
       KupZbozi(zbozi, xmlDocument);
       KupZbozi(zbozi, xmlDocument);
        
    }
    
    private List<Element> GetAllZbozi(Document xmlDocument) {
        
        List<Element> res = new ArrayList<Element>();
        res.addAll(NodeListToList(GetChildNodesFromElName(xmlDocument, "Tricko")));
        res.addAll(NodeListToList(GetChildNodesFromElName(xmlDocument, "Teplaky")));
        res.addAll(NodeListToList(GetChildNodesFromElName(xmlDocument, "Jeans")));
        res.addAll(NodeListToList(GetChildNodesFromElName(xmlDocument, "Bezecke")));
        res.addAll(NodeListToList(GetChildNodesFromElName(xmlDocument, "Baketove")));
        return res;
    }
    
    private NodeList GetChildNodesFromElName(Document xmlDocument, String name) {
        return (xmlDocument.getElementsByTagName(name));
    }
    
    private List<Element> NodeListToList (NodeList l) {
       List<Element> res = new ArrayList<Element>();
        //NodeList l = ((Element)li.item(0)).getChildNodes();
        for( int i = 0; i < l.getLength(); i++) {
            if(l.item(i).getNodeType() == Node.ELEMENT_NODE){
                Element el = (Element) l.item(i);
                String s = el.getTextContent();
                res.add(el);
            }
        }
        return res;
    }
     
    private Element SelectZbozi(List<Element> zboziAll) {
        Random r = new Random();
        Element zbozi = null;
        do {
            zbozi = zboziAll.get(r.nextInt(zboziAll.size()));
            if ("0".equals(zbozi.getNodeValue())) zbozi = null;
        
        } while(zbozi == null);
        return zbozi;
    }
    
    private void KupZbozi(Element zbozi, Document xmlDoc) {
        // sniz pocet na sklade
        Integer count = Integer.parseInt(zbozi.getTextContent());
        count --;
        zbozi.setNodeValue(count.toString());
        
        Element nakupy = (Element)xmlDoc.getElementsByTagName("Nakupy").item(0);
        
        Element nakup = xmlDoc.createElement("Nakup");
        nakup.appendChild(xmlDoc.createElement("Datum")).setTextContent("<?php echo Date(" + new Date().toString() + ") ?>");
        Element polozka = (Element) nakup.appendChild(xmlDoc.createElement("Polozka"));
        polozka.setAttribute("link", zbozi.getAttribute("productNum"));
        
        nakupy.appendChild(nakup);
    }
    
        
}
    
