/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

/**
 *
 * @author Kookie
 */
/*Prostřednictvím rozhraní DOM provést alespoň 2 úpravy XML dokumentu -
 * např. přidání nového zaměstnance se všemi parametry, smazání všech zaměstnanců s platem menším než X,
 * seřazení zaměstnanců podle abecedy apod.
 */
import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
public class MyDomTransformer {
    
    private static final String INPUT_FILE = "data.xml";
    private static final String OUTPUT_FILE = "data.out.xml";

    /**
     * Main method
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {

        try {

            // DocumentBuilderFactory creates DOM parsers
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            // We don't want to validate file
            dbf.setValidating(false);

            // Creating of DOM parser instance
            DocumentBuilder builder = dbf.newDocumentBuilder();

            // Parser processes input file and creates a DOM tree of objects
            Document doc = builder.parse(INPUT_FILE);

            // DOM tree processing
            MyDomTransformer mdt = new MyDomTransformer();
            mdt.transform(doc);

            // TransformerFactory creates an object for DOM serialization
            TransformerFactory tf = TransformerFactory.newInstance();

            // Transformer serializes DOM tree
            Transformer writer = tf.newTransformer();

            // Setting of output file encoding
            writer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            // Run transformation of DOM tree to XML document
            writer.transform(new DOMSource(doc), new StreamResult(new File(OUTPUT_FILE)));


        } catch (Exception e) {

            e.printStackTrace();

        }
    }
    
    /*
     
     * Metoda nejdrive prevede podelementy CIN a VATN elementu purchaser na jeho atributy.
     * Dale smaze cenu, DPH a celkovou cenu cele faktury (textovy obsah) a prida novou polozku 
     * nakonec spocita a vlozi novou cenu (DPH a celkova cena zustavaji prazdne)
     
     */
        public void transform (Document xmlDocument) {
            createAttributes(xmlDocument);
            deleteCINandVATN(xmlDocument);
            deleteTotalPrice(xmlDocument);
            insertNewItem(xmlDocument);
            insertNewPrice(xmlDocument);
          }

        private void createAttributes(Document xmlDocument) {
            Element purchaser = (Element) xmlDocument.getElementsByTagName("purchaser").item(0);
            if(purchaser.getElementsByTagName("CIN").getLength() != 0)
                purchaser.setAttribute("CIN", purchaser.getElementsByTagName("CIN").item(0).getTextContent());
            if(purchaser.getElementsByTagName("VATN").getLength() != 0)
                purchaser.setAttribute("VATN", purchaser.getElementsByTagName("VATN").item(0).getTextContent());
            
        }

        private void deleteCINandVATN(Document xmlDocument) {
            Element purchaser = (Element) xmlDocument.getElementsByTagName("purchaser").item(0);
            purchaser.removeChild(purchaser.getElementsByTagName("CIN").item(0));
            purchaser.removeChild(purchaser.getElementsByTagName("VATN").item(0));
        }

        private void deleteTotalPrice(Document xmlDocument) {
            Element without = (Element) xmlDocument.getElementsByTagName("without_VAT").item(0);
            Element VAT = (Element) xmlDocument.getElementsByTagName("VAT_total").item(0);
            Element total = (Element) xmlDocument.getElementsByTagName("total").item(0);
            
            without.setTextContent("");
            VAT.setTextContent("");
            total.setTextContent("");
        }

        private void insertNewItem(Document xmlDocument) {
            Node root = xmlDocument.getElementsByTagName("invoice").item(0);
            Element item = xmlDocument.createElement("item");
            Element description = xmlDocument.createElement("description");
            Element amount = xmlDocument.createElement("amount");
            Element VAT = xmlDocument.createElement("VAT");
            Element price = xmlDocument.createElement("price");
            description.setTextContent("SEO sluzby");
            amount.setTextContent("1");
            VAT.setTextContent("0.2");
            price.setTextContent("22600");
            item.appendChild(description);
            item.appendChild(amount);
            item.appendChild(VAT);
            item.appendChild(price);
            root.appendChild(item);
        }

        private void insertNewPrice(Document xmlDocument) {
            int price = 0;
            
            NodeList items = xmlDocument.getElementsByTagName("item");
            for (int i = 0; i < items.getLength(); i++) {
                Element e = (Element) items.item(i);
                if(e.getElementsByTagName("amount").getLength() != 0) {
                    int amount = Integer.parseInt(e.getElementsByTagName("amount").item(0).getTextContent());
                    price += (Integer.parseInt(e.getElementsByTagName("price").item(0).getTextContent())*amount);
                }
                else {
                    price += (Integer.parseInt(e.getElementsByTagName("price").item(0).getTextContent()));
                }
            }
            Node total = xmlDocument.getElementsByTagName("total").item(0);
            total.setTextContent(Integer.toString(price));
            
            
        }
}
