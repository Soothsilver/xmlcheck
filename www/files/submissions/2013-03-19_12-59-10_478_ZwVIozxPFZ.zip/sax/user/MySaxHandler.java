/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

/**
 *
 * @author Kookie
 */

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

public class MySaxHandler extends DefaultHandler {
    
    boolean itemStarted = false;
    boolean amountStarted = false;
    boolean VATStarted = false;
    boolean priceStarted = false;
    boolean invoice_priceStarted = false;
    boolean without_VATStarted = false;
    boolean VAT_totalStarted = false;
    boolean totalStarted = false;
    
    int service = 0;
    int goods = 0;
    
    int amount = 1;
    int price = 0;
    double VAT = 0;
    int items;
    int itemless5;
    int itemless5price;
    double without_VAT1;
    double without_VAT2;
    double VAT_total1;
    double VAT_total2;
    double total1;
    double total2;
    
        
    /*
     
     * Tri zvolene charakteristiky:
     * 1. Hodnota atributu: pocet service, pocet goods
     * 2. Hodnota textu: Spocitat invoice_price: without_VAT, VAT_total a total a zkontrolovat, zda sedi s hodnotou, uvedenou v xml dokumentu. Vysledek vypsat na konzoli.
     * 3. Kontext: prumerna cena item, kterych je fakturovano mene nez 5 kusu
     
     */
    
    
    /**
     * Obsluha události "začátek dokumentu"
     */     
    @Override
    public void startDocument() throws SAXException {
                
    }
    /**
     * Obsluha události "konec dokumentu"
     */     
    @Override
    public void endDocument() throws SAXException {
        System.out.println("Amount of \"service type items\" on invoice is "+service);
        System.out.println("Amount of \"goods type items\" on invoice is "+goods);
        total2 = without_VAT2 + VAT_total2;
        if(total1 == total2)
            System.out.println("Items price is stated right: "+total1+".");
        else {
            System.out.println("Items price is stated wrong as "+total1+". Real price is "+total2+".");
        }
        
        System.out.println("Average price of items with amount less then 5 is "+ itemless5price/itemless5);
        
    }
    
    /**
     * Obsluha události "začátek elementu".
     * @param uri URI jmenného prostoru elementu (prázdné, pokud element není v žádném jmenném prostoru)
     * @param localName Lokální jméno elementu (vždy neprázdné)
     * @param qName Kvalifikované jméno (tj. prefix-uri + ':' + localName, pokud je element v nějakém jmenném prostoru, nebo localName, pokud element není v žádném jmenném prostoru)
     * @param atts Atributy elementu     
     */     
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if(qName.equals("item")) {
            itemStarted = true;
            for (int i = 0; i < atts.getLength (); i++ ) {            
                if (atts.getQName(i).equals("type")) {
                    if(atts.getValue(i).equals("service")) 
                        service++;
                    
                    if(atts.getValue(i).equals("goods")) 
                        goods++;
                    
                }        
            }
            
        }
        if(qName.equals("amount") && itemStarted)
            amountStarted = true;
        if(qName.equals("VAT") && itemStarted)
            VATStarted = true;
        if(qName.equals("price") && itemStarted)
            priceStarted = true;
        if(qName.equals("invoice_price"))
            invoice_priceStarted = true;
        if(qName.equals("without_VAT") && invoice_priceStarted)
            without_VATStarted = true;
        if(qName.equals("VAT_total") && invoice_priceStarted)
            VAT_totalStarted = true;
        if(qName.equals("total") && invoice_priceStarted)
            totalStarted = true;
    }
    /**
     * Obsluha události "konec elementu"
     * Parametry mají stejný význam jako u @see startElement     
     */     
    
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if(qName.equals("amount")) {
            amountStarted = false;
        }
        if(qName.equals("price")) {
            priceStarted = false;
        }
        if(qName.equals("VAT")) {
            VATStarted = false;
        }
        
        if(qName.equals("item")) {
            if(amount<5) {
                itemless5++;
                itemless5price += price;
            }
                
            without_VAT2 += amount * price;
            VAT_total2 += amount * price * VAT;
            amount = 1;
            price = 0;
            VAT = 0;
            itemStarted = false;
        }
        
        if(qName.equals("without_VAT")) {
            without_VATStarted = false;
        }
        
        if(qName.equals("VAT_total")) {
            VAT_totalStarted = false;
        }
        
        if(qName.equals("total")) {
            totalStarted = false;
        }
        
        if(qName.equals("invoice_price")) {
            invoice_priceStarted = false;
        }

    }
    
    /**
     * Obsluha události "znaková data".
     * SAX parser muľe znaková data dávkovat jak chce. Nelze tedy počítat s tím, že je celý text dorucen v rámci jednoho volání.
     * Text je v poli (ch) na pozicich (start) az (start+length-1).
     * @param ch Pole se znakovými daty
     * @param start Index zacátku úseku platných znakových dat v poli.
     * @param length Délka úseku platných znakových dat v poli.
     */               
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        
        if(amountStarted) {
            amount = Integer.parseInt(String.valueOf(ch).substring(start, start+length));
        }
        
        if(priceStarted) {
            price = Integer.parseInt(String.valueOf(ch).substring(start, start+length));
        }
        
        if(VATStarted) {
            VAT = Double.parseDouble(String.valueOf(ch).substring(start, start+length));
        }
        
        if(without_VATStarted) {
            without_VAT1 = Double.parseDouble(String.valueOf(ch).substring(start, start+length));
        }
        
        if(VAT_totalStarted) {
            VAT_total1 = Double.parseDouble(String.valueOf(ch).substring(start, start+length));
        }
        
        if(totalStarted) {
            total1 = Double.parseDouble(String.valueOf(ch).substring(start, start+length));
        }

              
    }
  
    
    
    
    public static void main(String[] args) {

        // Cesta ke zdrojovému XML dokumentu  
        String sourcePath = "data.xml";

        try {
            
            // Vytvoríme instanci parseru.
            XMLReader parser = XMLReaderFactory.createXMLReader();
            
            // Vytvoríme vstupní proud XML dat.
            InputSource source = new InputSource(sourcePath);
            
            // Nastavíme náą vlastní content handler pro obsluhu SAX událostí.
            parser.setContentHandler(new MySaxHandler());
            
            // Zpracujeme vstupní proud XML dat.
            parser.parse(source);
            
        } catch (Exception e) {
        
            e.printStackTrace();
            
        }
        
    }
}
