package user; 
import java.util.ArrayList;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler; 

public class MySaxHandler extends DefaultHandler { 
		int allElements = 0;
		int allAttribues = 0;
		int songs = 0;
		int verseLenghtSum = 0;
		int verseLenghtMax = 0;
		int verseLenghtCurrent = 0;
		int versesSum = 0;
		int versesMax = 0;
		int versesCurrent = 0;
		int chorusLenghtSum = 0;
		int chorusLenghtMax = 0;
		int chorusLenghtCurrent = 0;
		int instrumentsSum = 0;
		int instrumentsMax = 0;
		int instrumentsCurrent = 0;
		ArrayList<String> ids = new ArrayList<String>();
		boolean intoBuffer = false;
		StringBuilder buffer = new StringBuilder();
		
	
	    public void endDocument() throws SAXException {
	    	 System.out.println("There is "+allElements+" elements and "+allAttribues+" attributes in this document");
	    	 System.out.println("There is "+songs+" songs in this songbook");
	    	 System.out.println("IDs used in this document: ");
	    	 for (String s:ids) {
	    		 System.out.println("	"+s);
	    	 }
	    	 double verseLengthAverage = verseLenghtSum/songs;
	    	 System.out.println("Average length of verse is: "+verseLengthAverage);
	    	 System.out.println("Maximal length of verse is: "+verseLenghtMax);
	    	 double chorusLengthAverage = chorusLenghtSum/songs;
	    	 System.out.println("Average length of chorus is: "+chorusLengthAverage);
	    	 System.out.println("Maximal length of chorus is: "+chorusLenghtMax);
	    	 double instrumentsAverage = instrumentsSum/songs;
	    	 System.out.println("Average number of instruments is: "+instrumentsAverage);
	    	 System.out.println("Maximal number of intsruments is: "+instrumentsMax);
	    	 double versesAverage = versesSum/songs;
	    	 System.out.println("Average number of verses is: "+versesAverage);
	    	 System.out.println("Maximal number of verses is: "+versesMax);
	    }
	    
	    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
	    	++allElements;
	        int elementAtts = atts.getLength();
	        allAttribues += elementAtts;
	        
	        // <song>
	        if("song".equals(localName)){
	        	++songs;
	        	
	        	//Reset temporary stats
	        	if (verseLenghtCurrent > verseLenghtMax) { 
	        		verseLenghtMax = verseLenghtCurrent;
	        	}
	        	verseLenghtCurrent = 0;
	        	
	        	if (versesCurrent > versesMax) { 
	        		versesMax = versesCurrent;
	        	}
	        	versesCurrent = 0;
	        	
	        	if (chorusLenghtCurrent > chorusLenghtMax) { 
	        		chorusLenghtMax = chorusLenghtCurrent;
	        	}
	        	chorusLenghtCurrent = 0;
	        	
	        	if (instrumentsCurrent > instrumentsMax) { 
	        		instrumentsMax = instrumentsCurrent;
	        	}
	        	instrumentsCurrent = 0;
	        	
	        	//Load ID
	        	for (int i=0; i<atts.getLength(); i++) {
	        		if ("id".equals(atts.getLocalName(i))){
	        			ids.add(atts.getValue(i));
	        		}
	        	}
	        }
	        
	        // <verse>
	        if("verse".equals(localName)){
	        	// new verse
	        	++versesCurrent;
	        	++versesSum;
	        	// begin buffering
	        	intoBuffer = true;
	        	buffer.delete(0, buffer.length());
	        }
	        
	        // <chorus>
	        if("chorus".equals(localName)){
	        	// begin buffering
	        	intoBuffer = true;
	        	buffer.delete(0, buffer.length());
	        }
	        
	     	// <singlePart>
	        if("singlePart".equals(localName)){
	        	// add new instrument
	        	++instrumentsCurrent;
	        	++instrumentsSum;
	        }
	    }
	 
	    public void endElement(String uri, String localName, String qName) throws SAXException {
	    	// <verse>
	        if("verse".equals(localName)){
	        	// stop buffering and count contents of buffer
	        	intoBuffer = false;
	        	int verseLength = buffer.toString().length();
	        	verseLenghtSum += verseLength;
	        	//update temporary stats
	        	if (verseLength > verseLenghtCurrent) { 
	        		verseLenghtCurrent = verseLength;
	        	}
	        	buffer.delete(0, buffer.length());
	        }
	        
	        // <chorus>
	        if("chorus".equals(localName)){
	        	// stop buffering and count contents of buffer
	        	intoBuffer = false;
	        	int chorusLength = buffer.toString().length();
	        	chorusLenghtSum += chorusLength;
	        	//update temporary stats
	        	if (chorusLength > chorusLenghtCurrent) { 
	        		chorusLenghtCurrent = chorusLength;
	        	}
	        	buffer.delete(0, buffer.length());
	        }
	    	
	    }
	    
	    public void characters(char[] ch, int start, int length) throws SAXException {
	    	if(intoBuffer){
	            buffer.append(ch, start, length);
	        }
	    }
	
	
}