package user;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;



public class MyDomTransformer {
//	/**
//	 * @param args
//	 * @throws ParserConfigurationException 
//	 * @throws IOException 
//	 * @throws SAXException 
//	 * @throws TransformerFactoryConfigurationError 
//	 * @throws TransformerException 
//	 */
//	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException, TransformerFactoryConfigurationError, TransformerException {
//		File file = new File("data.xml");
//		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
//		DocumentBuilder db = dbf.newDocumentBuilder();
//		Document doc = db.parse(file);
//		doc.getDocumentElement().normalize();
//		MyDomTransformer mdt = new MyDomTransformer();
//		
//		mdt.transform(doc);
//		
//		Transformer transformer = TransformerFactory.newInstance().newTransformer(); 
//		transformer.setOutputProperty(OutputKeys.INDENT, "yes"); 
//
//		StreamResult result = new StreamResult(new StringWriter()); 
//		DOMSource source = new DOMSource(doc); 
//		transformer.transform(source, result); 
//		String xmlString = result.getWriter().toString(); 
//		System.out.println(xmlString); 
//	}
	
	public void transform (Document xmlDocument) {
		addRandomSinglePart(xmlDocument);
		createSummary(xmlDocument);
		reformatAuthorName(xmlDocument);
		wholeLyrics(xmlDocument);
	}
	
	private void updateLastChangedSongs(Document doc){
		NodeList n = doc.getElementsByTagName("songs");
		Element e = (Element) n.item(0);
		DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
		Date date = new Date();
		e.setAttribute("lastUpdated", dateFormat.format(date));
	}
	
	private void updateLastChangedAuthors(Document doc){
		NodeList n = doc.getElementsByTagName("authors");
		Element e = (Element) n.item(0);
		DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
		Date date = new Date();
		e.setAttribute("lastUpdated", dateFormat.format(date));
	}
	
	private void addRandomSinglePart(Document doc) {
		Random r = new Random();
		String[] instruments =  {"oboe", "drum", "doubleBass", "SAXophone"};
		String[] signatures = {"C", "D", "A", "E", "Fis", "Cis", "As", "Es"};
		String[] clefs = {"treble", "bass"};
        NodeList songs = doc.getElementsByTagName("song");
        int i = 0;
        while (i < songs.getLength()) {
            Node currentNode = songs.item(i);
            String id =  currentNode.getAttributes().getNamedItem("id").getTextContent().substring(5);
            Element newElement = doc.createElement("singlePart");
            
            newElement.setAttribute("clef", clefs[r.nextInt(clefs.length)]);
            newElement.setAttribute("keySignature", signatures[r.nextInt(signatures.length)]);
            int rr = r.nextInt(instruments.length);
            newElement.setAttribute("instrument", instruments[rr]);
            newElement.setAttribute("file", "../sheets/"+id+"_"+instruments[rr]+".pdf");
            
            for (Node child = currentNode.getFirstChild(); child != null; child = child.getNextSibling()) {
                if (child instanceof Element && "score".equals(child.getNodeName())) {
                	child.appendChild(newElement);
                	}
            }
            i++;
        } 
        updateLastChangedSongs(doc);
	}
	
	private void reformatAuthorName(Document doc){
        NodeList authors = doc.getElementsByTagName("author");
        int i = 0;
        while (i < authors.getLength()) {
            Node currentNode = authors.item(i);
            for (Node child = currentNode.getFirstChild(); child != null; child = child.getNextSibling()) {
                if (child instanceof Element && "name".equals(child.getNodeName())) {
                	// get old name
                	String name = child.getTextContent(); 
                	 
                	// remove old name
                	currentNode.removeChild(child);
                	
                	// parse name
                	String givenName = "";
                	String middleName = "";
                	String surName = "";
                	String[] split = name.split(" ",3);
                	switch (split.length){  
                	case 1: 
                		surName = split[0];
                		break;
                	case 2: 
                		givenName = split[0];
                		surName = split[1];
                		break;
                	case 3: 
                		givenName = split[0];
                		middleName = split[1];
                		surName = split[2];
            		break;
                	}
                	
                	//create new name
                	Element eN = doc.createElement("name");
                	Element eGN = doc.createElement("givenName");
                	eGN.appendChild(doc.createTextNode(givenName));
                	Element eMN = doc.createElement("middleName");
                	eMN.appendChild(doc.createTextNode(middleName));
                	Element eSN = doc.createElement("surName");
                	eSN.appendChild(doc.createTextNode(surName));
                	eN.appendChild(eSN);
                	eN.appendChild(eGN);
                	eN.appendChild(eMN);
                	
                	//append new name back into document
                	currentNode.appendChild(eN);                	
                	
                	break;
                	}
            }
            i++;
        } 
        updateLastChangedAuthors(doc);
		
	}

	private void createSummary(Document doc){
		// browse authors
		NodeList authors = doc.getElementsByTagName("author");
		int i = 0;
	    while (i < authors.getLength()) {
	    	Node currentNode = authors.item(i);
	    	String nationality = "";
	    	String name = "";
	    	String cv = "";
	    	
	    	//parse informations
	    	for (Node child = currentNode.getFirstChild(); child != null; child = child.getNextSibling()) {
                if (child instanceof Element && "name".equals(child.getNodeName())) {
                	name = child.getTextContent();
                }
                if (child instanceof Element && "nationality".equals(child.getNodeName())) {
                	nationality = child.getTextContent();
                }
                if (child instanceof Element && "cv".equals(child.getNodeName())) {
                	cv = child.getTextContent();
                }
	    	}
	    	
	    	//create summary
	    	Element summary = doc.createElement("summary");
	    	summary.appendChild(doc.createTextNode(name+" ["+nationality+"]: "+cv));
	    	currentNode.appendChild(summary);
	    	
	        i++;
	    }
	    updateLastChangedAuthors(doc);
		
	    //browse songs
		NodeList songs = doc.getElementsByTagName("song");
		int j = 0;
	    while (j < songs.getLength()) {
	    	Node currentNode = songs.item(j);
	    	String title = "";
	    	String chorus = "";
	    	String verses = "";
	    	
	    	//parse informations
	    	for (Node child = currentNode.getFirstChild(); child != null; child = child.getNextSibling()) {
                if (child instanceof Element && "title".equals(child.getNodeName())) {
                	title = child.getTextContent();
                }
                if (child instanceof Element && "lyrics".equals(child.getNodeName())) {
                	Element e = (Element) child;
                	chorus = e.getAttribute("chorus");
                	verses = e.getAttribute("verses");
                }
	    	}
	    	
	    	if ("yes".equals(chorus)) {
	    		chorus = "does";
	    	} else {
	    		chorus = "doesn't";
	    	}
	    	
	    	//create summary
	    	Element summary = doc.createElement("summary");
	    	summary.appendChild(doc.createTextNode("Song "+title+" has "+verses+" verses and "+chorus+" have a chorus"));
	    	currentNode.appendChild(summary);
	        j++;
	    }
	    updateLastChangedSongs(doc);
		}

	private void wholeLyrics(Document doc){
	    //browse songs
		NodeList songs = doc.getElementsByTagName("song");
		int i = 0;
	    while (i < songs.getLength()) {
	    	Node currentNode = songs.item(i);
	    	String chorus = "\n";
	    	ArrayList<String> verses = new ArrayList<String>();
	    	for (int k=0; k<10; k++){
	    		verses.add("");
	    	}
	    	StringBuilder lyrics = new StringBuilder();
	    	
	    	//parse informations
	    	for (Node child = currentNode.getFirstChild(); child != null; child = child.getNextSibling()) {
                if (child instanceof Element && "lyrics".equals(child.getNodeName())) {
                	for (Node innerChild = child.getFirstChild(); innerChild != null; innerChild = innerChild.getNextSibling()) {
                        if (innerChild instanceof Element && "chorus".equals(innerChild.getNodeName())) {
                        	chorus = innerChild.getTextContent()+"\n";
                        }
                        if (innerChild instanceof Element && "verse".equals(innerChild.getNodeName())) {
                        	Element e = (Element) innerChild;
                        	int j = Integer.parseInt(e.getAttribute("number"));
                        	String verse = innerChild.getTextContent()+"\n";
                        	verses.set(j-1, verse);
                        }
                	}
                }
            }
	    	
	    	 //create lyrics
            for (String s: verses){
            	lyrics.append(s);
            	lyrics.append(chorus);
            }
            Element wL = doc.createElement("wholeLyrics");
	    	wL.appendChild(doc.createTextNode(lyrics.toString()));
	    	currentNode.appendChild(wL);    

	        i++;
	    }
	    updateLastChangedSongs(doc);
	}
}


