package user;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.text.Normalizer;

public class MyDomTransformer {
	public void transform(Document xmlDocument) {

		addLocal(xmlDocument);				//add new <local> element to <locals_base>
		deleteBigBreweries(xmlDocument);	//delete all <brewery> elements with attribute size="big"
        sortBrews(xmlDocument);    			//sort breweries by name
	}


	public void addLocal(Document xmlDocument) {

		Node nodeLocal = xmlDocument.createElement("local");
		Element newLocal = (Element) nodeLocal;
		newLocal.setAttribute("lid", "l_8");

		Node newLocName = xmlDocument.createElement("local_name");
			newLocName.appendChild(xmlDocument.createTextNode("Zly casy"));

				Node newLocAddr = xmlDocument.createElement("local_address");
					Node newStreet = xmlDocument.createElement("street");
						Node newStrName = xmlDocument.createElement("street_name");
							newStrName.appendChild(xmlDocument.createTextNode("Cestmirova"));
						Node newStrNr = xmlDocument.createElement("street_nr");
							newStrNr.appendChild(xmlDocument.createTextNode("21"));
		
					newStreet.appendChild(newStrName);
					newStreet.appendChild(newStrNr);

				Node newCity = xmlDocument.createElement("city");
					newCity.appendChild(xmlDocument.createTextNode("Praha"));

				Node newPostal = xmlDocument.createElement("postcode");
					newPostal.appendChild(xmlDocument.createTextNode("140 00"));

				newLocAddr.appendChild(newStreet);
				newLocAddr.appendChild(newCity);
				newLocAddr.appendChild(newPostal);

			newLocal.appendChild(newLocName);
			newLocal.appendChild(newLocAddr);

		Node x = xmlDocument.getElementsByTagName("locals_base").item(0);
		x.appendChild(newLocal);
	}
	
	public void sortBrews(Document xmlDocument) {
		NodeList brews = xmlDocument.getDocumentElement().getElementsByTagName("brewery");	
		
		if (brews != null)
	    {
		      int len = brews.getLength();
		      String wordj, wordj1;
		      
		      for (int i = 0; i < len; i++) {
				for (int j = 0; j < (len - 1 - i); j++) {
					
					//Following two lines allows to compare untypical sign (eg. ��῟��), but it doesn't work in XMLcheck
					//for clarity, all special sings in data.xml was replaced
					
					wordj=Normalizer.normalize(getText(brews.item(j).getChildNodes().item(1)), Normalizer.Form.NFD);						
					wordj1=Normalizer.normalize(getText(brews.item(j+1).getChildNodes().item(1)), Normalizer.Form.NFD);
					
					if (wordj.compareToIgnoreCase(wordj1) > 0)
				    brews.item(j).getParentNode().insertBefore(brews.item(j+1), brews.item(j));				
				}		    
		      }
	    }		
	}
	
	// auxiliary function, which returns text contents form element 
	public String getText(Node nameElement) {
		StringBuffer returnString = new StringBuffer();

		if (nameElement.getNodeName().equals("name")) {
			NodeList kids = nameElement.getChildNodes();
			if (kids != null)
				if (kids.item(0).getNodeType() == Node.TEXT_NODE)
					returnString.append(kids.item(0).getNodeValue());
		} else
			returnString.setLength(0);

		return new String(returnString);
	}
	  
	public void deleteBigBreweries(Document xmlDocument) {
		NodeList brewList = xmlDocument.getDocumentElement().getElementsByTagName("brewery");
		
		for (int temp = 0; temp < brewList.getLength(); temp++) {			
			Node nNode = brewList.item(temp);		 
			Element eElement = (Element) nNode;
			
			if (eElement.getAttribute("size").equals("big"))
			{
				eElement.getParentNode().removeChild(eElement);			
			}
		}
		
	}


}
