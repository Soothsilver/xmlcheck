package user;

import java.util.ArrayList;
import java.util.Collections;

import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
	public double hl_sum;
	public int brew_counter1, brew_counter3;
	public boolean addToTotal2, addToTotal3, isTour;
	public StringBuffer buffer2, buffer3;
	public int maxplato;
	public ArrayList<Integer> array3max = new ArrayList<Integer>();

	public void startDocument() {
		System.out.println("SAX Assignment: ");
		hl_sum = 0;
		brew_counter1 = 0;
		brew_counter3 = 0;
		maxplato = -1;
		isTour = false;
	}

	public void endDocument() {
		
		Collections.sort(array3max);

		System.out.println("Average production: " + hl_sum / brew_counter1);
		System.out.println("The highest three values of Plato: " + array3max);
		System.out.println("The number of breweries founded before 1900 and organized tours: " + brew_counter3);
	}

	public void startElement(String namespaceURL, String localName,
			String qName, Attributes atts) {
		
		/* 1 - apply to the values ​​of attributes - average annual production */
		if ("brewery".equals(qName)) {
			brew_counter1++; // increase number of breweries
			int hl = Integer.parseInt(atts.getValue("ann_prod"));
			hl_sum += hl; // add actual value to sum
		}

		/* 2 - apply to the content of elements - 3 max plato values */
		if ("plato".equals(qName)) {
			addToTotal2 = true;
			buffer2 = new StringBuffer();
		}
		
		/*
		 * 3 - apply to the context - number of breweries founded before 1900
		 * and organized tours
		 */
		if ("brewery".equals(qName)) {			
			if (atts.getValue("tours").equals("yes")) {
				isTour = true;				
			} else
				isTour = false;
		}
		if ("founded".equals(qName)) {
			addToTotal3 = true;
			buffer3 = new StringBuffer();
		}

	}

	public void endElement(String namespaceURL, String localName, String qName) {

		/* 2 - apply to the content of elements - finding 3 max plato values */
		if ("plato".equalsIgnoreCase(qName)) {
			addToTotal2 = false;

			int newmaxplato = Integer.parseInt(buffer2.toString().trim());

			if (maxplato < newmaxplato) {
				
				// if the array has less than 3 elements and current value is unique
				// add this value to the array
				if ((array3max.size() < 3)
						&& !(array3max.contains(newmaxplato))) {
					array3max.add(newmaxplato);
				}

				// else if current value is bigger than the smallest value from the array 
				// replace this value
				else if (Collections.min(array3max) < newmaxplato) {
					array3max.remove(Collections.min(array3max));
					array3max.add(newmaxplato);
				}
			}
		}
		
		/* 3 - apply to the context - number of breweries founded before 1900 and organized tours */
		if ("founded".equalsIgnoreCase(qName) ) {
			addToTotal3 = false;		
			
			int year = Integer.parseInt(buffer3.toString().trim());
			
			if ((year < 1900) && (isTour==true)) {
				brew_counter3++;
			}
		}
		}

	public void characters(char ch[], int start, int length) {
		if (addToTotal2) {
			buffer2.append(ch, start, length);
		}
		
		if (addToTotal3) {
			buffer3.append(ch, start, length);
		}

	}

}
