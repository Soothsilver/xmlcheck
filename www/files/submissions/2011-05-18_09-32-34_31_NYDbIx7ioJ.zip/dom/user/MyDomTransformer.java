package user;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

/* Prelozi xml tagy dokumentu (obsahujici databazy her), ktere jsou v cestine do anglictiny
 * U tagu web udela z hodnoty atributu url textovy obsah elementu
 * V tagu doporucenyVek prevede tagy minVek a maxVek na atributy
 * V tagu pocetHracu prevede tagy maxPocet a minPocet na atributy
 */

public class MyDomTransformer {
	
	public void transform (Document doc) {
		
        Element gameDB = doc.createElement("gameDatabaze");
        
        
        Element publishers = doc.createElement("publishers");        
        Element designers = doc.createElement("designers");
        Element games = doc.createElement("games");

        gameDB.appendChild(publishers);
        gameDB.appendChild(designers);
        gameDB.appendChild(games);
        
        String tmpContent = null;
        String tmpName = null;
        Element tmpElem = null;
        Node tmpNode = null;

        NodeList publishersNode =  doc.getElementsByTagName("vydavatel");
        
        
        for (int i = 0; i < publishersNode.getLength(); i++) {
        	Element publisher = doc.createElement("publisher");
        	
        	for (Node child = publishersNode.item(i).getFirstChild(); 
        		child != null; 
        		child = child.getNextSibling()) {
        		
        		if (child.getNodeType() == org.w3c.dom.Node.ELEMENT_NODE) {
        			if (child.getNodeName().equals("nazev")) {
        				tmpName = "name";
        				tmpContent = child.getTextContent();
        			} else if (child.getNodeName().equals("web")) {
        				tmpName = "www";
        				//atribut url prevedeme na textovy obsah
        				tmpContent = child.getAttributes().getNamedItem("url").getNodeValue();
        			} else if (child.getNodeName().equals("zeme")) {
        				tmpName = "country";
        				tmpContent = child.getTextContent();
        			}
        			
        			tmpElem = doc.createElement(tmpName);
        			tmpElem.setTextContent(tmpContent);
        			publisher.appendChild(tmpElem);
        			
        		}
        	}
            publishers.appendChild(publisher);
        }
        
        NodeList designersNode =  doc.getElementsByTagName("tvurce");
        
        for (int i = 0; i < designersNode.getLength(); i++) {
        	Element designer = doc.createElement("designer");
        	
        	for (Node child = designersNode.item(i).getFirstChild(); 
        		child != null; 
        		child = child.getNextSibling()) {
        		
        		if (child.getNodeType() == org.w3c.dom.Node.ELEMENT_NODE) {
        			if (child.getNodeName().equals("jmeno")) {
        				tmpName = "name";
        			} else if (child.getNodeName().equals("rokNarozeni")) {
        				tmpName = "birth";
        			} else if (child.getNodeName().equals("zemePuvodu")) {
        				tmpName = "homeland";
        			}
        			
        			tmpElem = doc.createElement(tmpName);
        			tmpElem.setTextContent(child.getTextContent());
        			designer.appendChild(tmpElem);
        			
        		}
        	}
            designers.appendChild(designer);
        }
        
        
        NodeList gamesNode = doc.getElementsByTagName("hra");
        
        for (int i = 0; i < gamesNode.getLength(); i++) {
        	Element game = doc.createElement("game");
        	
        	for (Node child = gamesNode.item(i).getFirstChild(); 
        		child != null; 
        		child = child.getNextSibling()) {
        		
        		if (child.getNodeType() == org.w3c.dom.Node.ELEMENT_NODE) {
        			Element childElm = (Element)child;
        			if (child.getNodeName().equals("nazev")) {
        				tmpElem = doc.createElement("name");
        				tmpElem.setTextContent(child.getTextContent());
        			} else if (child.getNodeName().equals("jmenoTvurce")) {
        				tmpElem = doc.createElement("designerName");
        				tmpElem.setTextContent(child.getTextContent());
        			} else if (child.getNodeName().equals("pocetHracu")) {
        				tmpElem = doc.createElement("numberOfPlayers");
        				Attr attr;
        				
        				//element minPocet prevedeme na hodnotu atributu
        				tmpContent = childElm.getElementsByTagName("minPocet").item(0).getTextContent();
        				attr = doc.createAttribute("minCount");
        				attr.setValue(tmpContent);
        				tmpElem.setAttributeNode(attr);
        				
        				//element maxPocet prevedeme na hodnotu atributu
        				tmpContent = childElm.getElementsByTagName("maxPocet").item(0).getTextContent();
        				attr = doc.createAttribute("maxCount");
        				attr.setValue(tmpContent);
        				tmpElem.setAttributeNode(attr);
        				
        			} else if (child.getNodeName().equals("doporucenyVek")) {
        				tmpElem = doc.createElement("recommendedAge");
        				
        				Attr attr;
        				//element minVek prevedeme na hodnotu atributu
        				tmpContent = childElm.getElementsByTagName("minVek").item(0).getTextContent();
        				attr = doc.createAttribute("minAge");
        				attr.setValue(tmpContent);
        				tmpElem.setAttributeNode(attr);
        				
        				//element maxVek prevedeme na hodnotu atributu
        				tmpContent = childElm.getElementsByTagName("maxVek").item(0).getTextContent();
        				attr = doc.createAttribute("maxAge");
        				attr.setValue(tmpContent);
        				tmpElem.setAttributeNode(attr);
        				
          			} else if (child.getNodeName().equals("rokVydani")) {
        				tmpElem = doc.createElement("year");
        				tmpElem.setTextContent(child.getTextContent());
          			} else if (child.getNodeName().equals("jazyky")) {
        				tmpElem = doc.createElement("languages");
        				
        				NodeList languageNode = childElm.getElementsByTagName("jazyk");
        				
        				for (int j = 0; j < languageNode.getLength(); j++) {
        					Element language = doc.createElement("language");
        					language.setTextContent(languageNode.item(j).getTextContent());
        					tmpElem.appendChild(language);
        				}
        				
          			} else if (child.getNodeName().equals("hraciDoba")) {
        				tmpElem = doc.createElement("playtime");
        				tmpElem.setTextContent(child.getTextContent());
        				
        				Attr attr = doc.createAttribute("time");
        				attr.setValue(childElm.getAttributeNode("cas").getValue());
        				tmpElem.setAttributeNode(attr);
        				
        			} else if (child.getNodeName().equals("seznamVydavatelu")) {
        				tmpElem = doc.createElement("publishers");
        				
        				
        				NodeList pubNode = childElm.getElementsByTagName("vydavatelNazev");
        				
        				for (int j = 0; j < pubNode.getLength(); j++) {
        					Element language = doc.createElement("publisher");
        					language.setTextContent(pubNode.item(j).getTextContent());
        					tmpElem.appendChild(language);
        				}
        			}
        			
        			game.appendChild(tmpElem);
        			
        		}
        	}
            games.appendChild(game);
        }
        
        
        doc.replaceChild(gameDB, doc.getDocumentElement());
        
		
	}
}
