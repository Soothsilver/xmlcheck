package user;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/*
 * 
 * Spocita nekolik charakteristik xml dokumentu: pocet atributu, pocet elementu,
 *  maximalni hloubku, celkovy pocet znaku v textovych elementech
 *
 */
public class MySaxHandler extends DefaultHandler {

	//celkovy pocet atributu
    int attrCount = 0;
    
    //celkovy pocet elementu
	int elemCount = 0;
	
	//maximalni hloubka dokumentu
	int maxDepth = 0;
	
	//celkovy pocet znaku v textovych elementech
	int txtCharCount = 0;

		
	private int ElemNameLenTot = 0;	
	private int tmpDepth = 0;

        
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
    	attrCount += atts.getLength();
    	elemCount++;
    	tmpDepth++;
    	ElemNameLenTot += localName.length();
    }
        
    public void endElement(String uri, String localName, String qName) throws SAXException {
    	maxDepth = java.lang.Math.max(maxDepth,tmpDepth);
    	tmpDepth--;
    }
    
    public void characters(char[] ch, int start, int length)throws SAXException {
    	txtCharCount += length;
    }

    public void endDocument() throws SAXException {
        System.out.println("pocet atributu: " + attrCount);
        System.out.println("pocet elementu: " + elemCount);
        System.out.println("maximalni hloubka: " + maxDepth);
        System.out.println("prumerna delka nazvu elementu: " + (ElemNameLenTot / (float)elemCount));
        System.out.println("celkovy pocet znaku v textovych elementech: " +  txtCharCount);        
    }
}
